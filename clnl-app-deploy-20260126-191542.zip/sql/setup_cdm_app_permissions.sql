-- ============================================
-- CDM APP PERMISSIONS SETUP
-- ============================================
-- Creates user management and permissions system
-- 
-- User Groups:
-- - JNJ_DAE: Full DTA management (create, edit, submit)
-- - VENDOR: Comment & approve only, no template promotion or editing
-- - JNJ_LIBRARIAN: View, comment, promote to template
-- ============================================

USE CATALOG IDENTIFIER(:catalog);
USE SCHEMA gold_md;

-- ─────────────────────────────────────────────
-- 1. DROP EXISTING TABLES (to ensure schema updates)
-- ─────────────────────────────────────────────

-- Drop in correct order (dependencies first)
DROP TABLE IF EXISTS md_user_group_memberships;
DROP TABLE IF EXISTS md_group_permissions;
DROP TABLE IF EXISTS md_permissions;
DROP TABLE IF EXISTS md_user_groups;
DROP TABLE IF EXISTS md_users;

-- ─────────────────────────────────────────────
-- 2. CREATE TABLES WITH NEW SCHEMA
-- ─────────────────────────────────────────────

-- Users table
CREATE TABLE IF NOT EXISTS md_users (
    user_id             STRING      COMMENT 'Unique user identifier (UUID)',
    email               STRING      COMMENT 'User email for SSO and notifications',
    display_name        STRING      COMMENT 'User display name',
    vendor_id           STRING      COMMENT 'FK to md_vendor for vendor users, NULL for internal',
    is_active           BOOLEAN     COMMENT 'Active status',
    created_ts          TIMESTAMP   COMMENT 'Record creation timestamp',
    last_updated_ts     TIMESTAMP   COMMENT 'Last update timestamp'
) USING DELTA
COMMENT 'Application users with group memberships';

-- User groups table
CREATE TABLE IF NOT EXISTS md_user_groups (
    group_id            STRING      COMMENT 'Unique group identifier',
    group_name          STRING      COMMENT 'Group name: JNJ_DAE, JNJ_LIBRARIAN, VENDOR',
    description         STRING      COMMENT 'Group description',
    is_active           BOOLEAN     COMMENT 'Active status'
) USING DELTA
COMMENT 'User groups with permission sets';

-- Permissions table
CREATE TABLE IF NOT EXISTS md_permissions (
    permission_id       STRING      COMMENT 'Unique permission identifier',
    permission_type     STRING      COMMENT 'Type: PAGE_ACCESS, PANEL_VIEW, ACTION_EXECUTE',
    permission_key      STRING      COMMENT 'Unique key: page_dashboard, action_edit_dta, etc.',
    enforcement_mode    STRING      COMMENT 'Enforcement mode: HIDE (remove from DOM), DISABLE (show but inactive), REQUIRE (progressive disclosure)',
    description         STRING      COMMENT 'Human-readable description',
    disabled_message    STRING      COMMENT 'Tooltip/message shown when element is disabled'
) USING DELTA
COMMENT 'Permission definitions with enforcement strategy';

-- User to group membership
CREATE TABLE IF NOT EXISTS md_user_group_memberships (
    membership_id       STRING      COMMENT 'Unique membership identifier',
    user_id             STRING      COMMENT 'FK to md_users',
    group_id            STRING      COMMENT 'FK to md_user_groups',
    joined_ts           TIMESTAMP   COMMENT 'When user joined the group'
) USING DELTA
COMMENT 'User to group membership mapping';

-- Group to permission mapping
CREATE TABLE IF NOT EXISTS md_group_permissions (
    group_permission_id STRING      COMMENT 'Unique identifier',
    group_id            STRING      COMMENT 'FK to md_user_groups',
    permission_id       STRING      COMMENT 'FK to md_permissions'
) USING DELTA
COMMENT 'Group to permission mapping';

-- ─────────────────────────────────────────────
-- 3. ADD CLARIO VENDOR (if not exists)
-- ─────────────────────────────────────────────

MERGE INTO md_vendor AS target
USING (
    SELECT 'V006' as vendor_id, 'Clario' as vendor_name, 'Clinical trial technology and services' as vendor_description
) AS source
ON target.vendor_id = source.vendor_id
WHEN NOT MATCHED THEN INSERT (vendor_id, vendor_name, vendor_description, is_active, created_ts)
VALUES (source.vendor_id, source.vendor_name, source.vendor_description, true, current_timestamp());

-- ─────────────────────────────────────────────
-- 4. SEED USER GROUPS
-- ─────────────────────────────────────────────

DELETE FROM md_user_groups;

INSERT INTO md_user_groups (group_id, group_name, description, is_active) VALUES
('group_jnj_dae', 'JNJ_DAE', 'Data Acquisition Engineers - Create and manage DTAs', true),
('group_vendor', 'VENDOR', 'External vendor users - Comment and approve DTAs', true),
('group_jnj_librarian', 'JNJ_LIBRARIAN', 'Library maintainers - Promote DTAs to templates', true);

-- ─────────────────────────────────────────────
-- 5. SEED PERMISSIONS
-- ─────────────────────────────────────────────

DELETE FROM md_permissions;

-- Page Access Permissions (All use HIDE mode - completely remove from navigation)
INSERT INTO md_permissions (permission_id, permission_type, permission_key, enforcement_mode, description, disabled_message) VALUES
('perm_page_all', 'PAGE_ACCESS', 'page_all', 'HIDE', 'Access to all pages (Admin wildcard)', NULL),
('perm_page_dashboard', 'PAGE_ACCESS', 'page_dashboard', 'HIDE', 'Access dashboard page', NULL),
('perm_page_dta_builder', 'PAGE_ACCESS', 'page_dta_builder', 'HIDE', 'Access DTA Builder page', NULL),
('perm_page_dta_workflow', 'PAGE_ACCESS', 'page_dta_workflow', 'HIDE', 'Access DTA Workflow page', NULL),
('perm_page_dta_viewer', 'PAGE_ACCESS', 'page_dta_viewer', 'HIDE', 'Access DTA Viewer page', NULL),
('perm_page_study_mgmt', 'PAGE_ACCESS', 'page_study_mgmt', 'HIDE', 'Access Study Management pages', NULL),
('perm_page_doc_mgmt', 'PAGE_ACCESS', 'page_doc_mgmt', 'HIDE', 'Access Document Management pages', NULL),
('perm_page_admin', 'PAGE_ACCESS', 'page_admin', 'HIDE', 'Access Administration pages', NULL);

-- Action Execute Permissions (Mix of HIDE and DISABLE modes)
INSERT INTO md_permissions (permission_id, permission_type, permission_key, enforcement_mode, description, disabled_message) VALUES
('perm_action_edit_dta', 'ACTION_EXECUTE', 'action_edit_dta', 'DISABLE', 'Edit DTA fields', 'You do not have permission to edit DTAs. Contact your administrator to request access.'),
('perm_action_comment', 'ACTION_EXECUTE', 'action_add_comment', 'HIDE', 'Add comments to items', NULL),
('perm_action_clone_dta', 'ACTION_EXECUTE', 'action_clone_dta', 'HIDE', 'Clone DTAs', NULL),
('perm_action_promote_template', 'ACTION_EXECUTE', 'action_promote_template', 'HIDE', 'Promote DTA to template', NULL),
('perm_action_approve_dta', 'ACTION_EXECUTE', 'action_approve_dta', 'HIDE', 'Approve DTA', NULL),
('perm_action_promote_dta', 'ACTION_EXECUTE', 'action_promote_dta', 'HIDE', 'Promote DTA to Major Version', NULL);

-- ─────────────────────────────────────────────
-- 6. ASSIGN PERMISSIONS TO GROUPS
-- ─────────────────────────────────────────────

DELETE FROM md_group_permissions;

-- JNJ_DAE: Can access all pages including DTA Builder, create/edit/clone DTAs, promote to major version, comment, but NOT promote to template
INSERT INTO md_group_permissions (group_permission_id, group_id, permission_id)
SELECT uuid() as group_permission_id, 'group_jnj_dae' as group_id, 'perm_page_all' as permission_id
UNION ALL
SELECT uuid(), 'group_jnj_dae', 'perm_page_dta_builder'
UNION ALL
SELECT uuid(), 'group_jnj_dae', 'perm_action_edit_dta'
UNION ALL
SELECT uuid(), 'group_jnj_dae', 'perm_action_clone_dta'
UNION ALL
SELECT uuid(), 'group_jnj_dae', 'perm_action_promote_dta'
UNION ALL
SELECT uuid(), 'group_jnj_dae', 'perm_action_comment';

-- VENDOR: Can access DTA pages including Builder (for viewing/commenting), can comment and approve, but NOT create/edit/clone/promote
INSERT INTO md_group_permissions (group_permission_id, group_id, permission_id)
SELECT uuid() as group_permission_id, 'group_vendor' as group_id, 'perm_page_dashboard' as permission_id
UNION ALL
SELECT uuid(), 'group_vendor', 'perm_page_dta_workflow'
UNION ALL
SELECT uuid(), 'group_vendor', 'perm_page_dta_viewer'
UNION ALL
SELECT uuid(), 'group_vendor', 'perm_page_dta_builder'
UNION ALL
SELECT uuid(), 'group_vendor', 'perm_action_comment'
UNION ALL
SELECT uuid(), 'group_vendor', 'perm_action_approve_dta';

-- JNJ_LIBRARIAN: DTA pages + Administration access, can comment and promote to template, but NOT edit/clone/approve/manage
INSERT INTO md_group_permissions (group_permission_id, group_id, permission_id)
SELECT uuid() as group_permission_id, 'group_jnj_librarian' as group_id, 'perm_page_dashboard' as permission_id
UNION ALL
SELECT uuid(), 'group_jnj_librarian', 'perm_page_dta_workflow'
UNION ALL
SELECT uuid(), 'group_jnj_librarian', 'perm_page_dta_viewer'
UNION ALL
SELECT uuid(), 'group_jnj_librarian', 'perm_page_admin'
UNION ALL
SELECT uuid(), 'group_jnj_librarian', 'perm_action_comment'
UNION ALL
SELECT uuid(), 'group_jnj_librarian', 'perm_action_promote_template';

-- ─────────────────────────────────────────────
-- 7. CREATE USERS
-- ─────────────────────────────────────────────

DELETE FROM md_users;

-- JNJ DAE Users
INSERT INTO md_users (user_id, email, display_name, vendor_id, is_active, created_ts, last_updated_ts)
SELECT uuid() as user_id, 'VKapoor9@its.jnj.com' as email, 'Vikas Kapoor (DAE)' as display_name, NULL as vendor_id, true as is_active, current_timestamp() as created_ts, current_timestamp() as last_updated_ts
UNION ALL
SELECT uuid(), 'gricca4@its.jnj.com', 'Giuseppe Ricca (DAE)', NULL, true, current_timestamp(), current_timestamp();

-- Vendor Users (dynamically look up vendor_id from md_vendor table)
INSERT INTO md_users (user_id, email, display_name, vendor_id, is_active, created_ts, last_updated_ts)
SELECT 
    uuid() as user_id, 
    'awagle4@its.jnj.com' as email, 
    'Arun Wagle (LabCorp)' as display_name, 
    (SELECT vendor_id FROM md_vendor WHERE vendor_name = 'Labcorp' LIMIT 1) as vendor_id, 
    true as is_active, 
    current_timestamp() as created_ts, 
    current_timestamp() as last_updated_ts
UNION ALL
SELECT 
    uuid(), 
    'RRaoGude@its.jnj.com', 
    'Rohit Rao Gude (Clario)', 
    (SELECT vendor_id FROM md_vendor WHERE vendor_name = 'Clario' LIMIT 1), 
    true, 
    current_timestamp(), 
    current_timestamp();

-- JNJ Librarian User
INSERT INTO md_users (user_id, email, display_name, vendor_id, is_active, created_ts, last_updated_ts)
SELECT uuid() as user_id, 'JHEERES1@its.jnj.com' as email, 'Jennifer Heeres (Librarian)' as display_name, NULL as vendor_id, true as is_active, current_timestamp() as created_ts, current_timestamp() as last_updated_ts;

-- ─────────────────────────────────────────────
-- 8. ASSIGN USERS TO GROUPS
-- ─────────────────────────────────────────────

DELETE FROM md_user_group_memberships;

-- Assign DAE users
INSERT INTO md_user_group_memberships (membership_id, user_id, group_id, joined_ts)
SELECT uuid(), user_id, 'group_jnj_dae', current_timestamp()
FROM md_users
WHERE email IN ('VKapoor9@its.jnj.com', 'gricca4@its.jnj.com');

-- Assign Vendor users
INSERT INTO md_user_group_memberships (membership_id, user_id, group_id, joined_ts)
SELECT uuid(), user_id, 'group_vendor', current_timestamp()
FROM md_users
WHERE email IN ('awagle4@its.jnj.com', 'RRaoGude@its.jnj.com');

-- Assign Librarian user
INSERT INTO md_user_group_memberships (membership_id, user_id, group_id, joined_ts)
SELECT uuid(), user_id, 'group_jnj_librarian', current_timestamp()
FROM md_users
WHERE email = 'JHEERES1@its.jnj.com';

-- ─────────────────────────────────────────────
-- 9. VERIFY SETUP
-- ─────────────────────────────────────────────

-- Show all users with their groups
SELECT 
    u.email,
    u.display_name,
    g.group_name,
    COALESCE(v.vendor_name, 'JNJ Internal') as organization
FROM md_users u
LEFT JOIN md_user_group_memberships m ON u.user_id = m.user_id
LEFT JOIN md_user_groups g ON m.group_id = g.group_id
LEFT JOIN md_vendor v ON u.vendor_id = v.vendor_id
WHERE u.is_active = true
ORDER BY g.group_name, u.email;

-- Show group permissions
SELECT 
    g.group_name,
    p.permission_type,
    p.permission_key,
    p.description
FROM md_user_groups g
JOIN md_group_permissions gp ON g.group_id = gp.group_id
JOIN md_permissions p ON gp.permission_id = p.permission_id
ORDER BY g.group_name, p.permission_type, p.permission_key;


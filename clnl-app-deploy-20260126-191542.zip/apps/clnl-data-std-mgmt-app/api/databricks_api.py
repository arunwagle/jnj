"""
Databricks API Integration
Provides functions to interact with Databricks Jobs API
"""
from databricks.sdk import WorkspaceClient
from typing import Dict, Any


def trigger_job(job_name: str, parameters: Dict[str, str]) -> Dict[str, Any]:
    """
    Trigger a Databricks job by name with parameters.
    Uses Databricks SDK for authentication (same as rest of app).
    
    Args:
        job_name: Name of the Databricks job to trigger (e.g., "job_cdm_version_manager")
                 Will match both exact names and dev-prefixed names like "[dev user] job_name"
        parameters: Dictionary of job parameters
        
    Returns:
        dict: {
            "run_id": <run_id>,
            "job_id": <job_id>
        }
        
    Raises:
        ValueError: If job not found
        Exception: If API call fails
    """
    print(f"DATABRICKS_API: Looking up job matching '{job_name}'...")
    
    # Use Databricks SDK - handles authentication automatically
    # (same pattern as DatabricksJobsClient in databricks_client.py)
    w = WorkspaceClient()
    
    # Step 1: Try exact match first (for production environments)
    jobs = list(w.jobs.list(name=job_name, expand_tasks=False))
    
    if not jobs:
        # Step 2: Try suffix match for dev environments (e.g., "[dev user] job_name")
        print(f"DATABRICKS_API: Exact match not found, trying pattern match...")
        all_jobs = list(w.jobs.list(expand_tasks=False, limit=100))
        
        # Look for jobs that end with the target job name
        matched_jobs = [j for j in all_jobs if j.settings.name.endswith(job_name)]
        
        if matched_jobs:
            # Use the first match
            job = matched_jobs[0]
            print(f"DATABRICKS_API: Found job by pattern match: '{job.settings.name}'")
        else:
            # Still not found - list available for debugging
            available_jobs = [j.settings.name for j in all_jobs[:10]]
            raise ValueError(
                f"Job matching '{job_name}' not found. "
                f"Available jobs (first 10): {', '.join(available_jobs)}"
            )
    else:
        job = jobs[0]
        print(f"DATABRICKS_API: Found job by exact match: '{job.settings.name}'")
    
    job_id = job.job_id
    print(f"DATABRICKS_API: Using job ID: {job_id}")
    
    # Step 3: Trigger the job with parameters using SDK
    print(f"DATABRICKS_API: Triggering job with parameters: {parameters}")
    
    try:
        run_response = w.jobs.run_now(
            job_id=job_id,
            job_parameters=parameters
        )
        
        run_id = run_response.run_id
        
        # Get the run details to get the URL (same pattern as upload_api.py)
        run_details = w.jobs.get_run(run_id=run_id)
        
        result = {
            "run_id": run_id,
            "job_id": job_id,
            "url": run_details.run_page_url  # This exists on the full Run object
        }
        
        print(f"DATABRICKS_API: Job triggered successfully. Run ID: {result['run_id']}")
        print(f"DATABRICKS_API: Job run URL: {result['url']}")
        return result
        
    except Exception as e:
        print(f"DATABRICKS_API ERROR: Failed to trigger job: {e}")
        raise ValueError(f"Failed to trigger job: {e}")


def get_job_run_status(run_id: int) -> Dict[str, Any]:
    """
    Get the status of a Databricks job run.
    Uses Databricks SDK for authentication.
    
    Args:
        run_id: The run ID to check
        
    Returns:
        dict: {
            "state": {"life_cycle_state": "RUNNING|TERMINATED|...", 
                     "result_state": "SUCCESS|FAILED|..."},
            "start_time": <epoch_ms>,
            "end_time": <epoch_ms>
        }
    """
    print(f"DATABRICKS_API: Getting status for run ID: {run_id}")
    
    w = WorkspaceClient()
    
    try:
        run = w.jobs.get_run(run_id=run_id)
        
        result = {
            "state": {
                "life_cycle_state": run.state.life_cycle_state.value if run.state else None,
                "result_state": run.state.result_state.value if run.state and run.state.result_state else None
            },
            "start_time": run.start_time,
            "end_time": run.end_time
        }
        
        print(f"DATABRICKS_API: Run status: {result['state']}")
        return result
        
    except Exception as e:
        print(f"DATABRICKS_API ERROR: Failed to get job run status: {e}")
        raise ValueError(f"Failed to get job run status: {e}")


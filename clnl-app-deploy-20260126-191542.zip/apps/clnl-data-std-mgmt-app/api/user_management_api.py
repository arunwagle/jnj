"""
User Management API for Permissions
Provides user lookup, group membership, and permission checking
"""

class UserManagementService:
    """Service for managing users, groups, and permissions"""
    
    def __init__(self, sql_client, catalog="dta_poc_test", schema="gold_md"):
        self.client = sql_client
        self.catalog = catalog
        self.schema = schema
    
    def get_user_by_email(self, email: str) -> dict:
        """Get user details by email"""
        query = f"""
            SELECT 
                u.user_id,
                u.email,
                u.display_name,
                u.vendor_id,
                v.vendor_name,
                u.is_active
            FROM {self.catalog}.{self.schema}.md_users u
            LEFT JOIN {self.catalog}.{self.schema}.md_vendor v ON u.vendor_id = v.vendor_id
            WHERE u.email = '{email}' AND u.is_active = true
        """
        
        try:
            results = self.client.execute_query(query)
            if results and len(results) > 0:
                return {
                    'user_id': results[0].get('user_id'),
                    'email': results[0].get('email'),
                    'display_name': results[0].get('display_name'),
                    'vendor_id': results[0].get('vendor_id'),
                    'vendor_name': results[0].get('vendor_name'),
                    'is_active': results[0].get('is_active')
                }
        except Exception as e:
            print(f"Error fetching user {email}: {e}")
        
        return None
    
    def get_user_groups(self, email: str) -> list:
        """Get all groups for a user"""
        query = f"""
            SELECT g.group_id, g.group_name, g.description
            FROM {self.catalog}.{self.schema}.md_users u
            JOIN {self.catalog}.{self.schema}.md_user_group_memberships m ON u.user_id = m.user_id
            JOIN {self.catalog}.{self.schema}.md_user_groups g ON m.group_id = g.group_id
            WHERE u.email = '{email}' AND u.is_active = true AND g.is_active = true
        """
        
        try:
            results = self.client.execute_query(query)
            return [
                {
                    'group_id': row.get('group_id'),
                    'group_name': row.get('group_name'),
                    'description': row.get('description')
                }
                for row in results
            ]
        except Exception as e:
            print(f"Error fetching groups for {email}: {e}")
            return []
    
    def get_user_permissions(self, email: str) -> dict:
        """Get all permissions for a user (organized by type)"""
        query = f"""
            SELECT DISTINCT
                p.permission_type,
                p.permission_key,
                p.description
            FROM {self.catalog}.{self.schema}.md_users u
            JOIN {self.catalog}.{self.schema}.md_user_group_memberships m ON u.user_id = m.user_id
            JOIN {self.catalog}.{self.schema}.md_group_permissions gp ON m.group_id = gp.group_id
            JOIN {self.catalog}.{self.schema}.md_permissions p ON gp.permission_id = p.permission_id
            WHERE u.email = '{email}' AND u.is_active = true
        """
        
        try:
            results = self.client.execute_query(query)
            
            # Organize by permission type
            permissions = {
                'PAGE_ACCESS': [],
                'PANEL_VIEW': [],
                'ACTION_EXECUTE': []
            }
            
            for row in results:
                perm_type = row.get('permission_type')
                if perm_type in permissions:
                    permissions[perm_type].append(row.get('permission_key'))
            
            return permissions
        except Exception as e:
            print(f"Error fetching permissions for {email}: {e}")
            return {'PAGE_ACCESS': [], 'PANEL_VIEW': [], 'ACTION_EXECUTE': []}
    
    def can(self, email: str, permission_key: str) -> bool:
        """Check if user has a specific permission (for HIDE mode)"""
        permissions = self.get_user_permissions(email)
        
        # Check all permission types
        for perm_list in permissions.values():
            if permission_key in perm_list:
                return True
        
        # Check for wildcard 'page_all' permission (only applies to page_* permissions)
        if permission_key.startswith('page_') and 'page_all' in permissions.get('PAGE_ACCESS', []):
            return True
        
        return False
    
    def get_permission_mode(self, email: str, permission_key: str) -> dict:
        """
        Get full permission details including enforcement mode.
        
        Returns:
            {
                'has_permission': bool,
                'mode': 'HIDE' | 'DISABLE' | 'REQUIRE',
                'message': str or None (disabled message/tooltip)
            }
        """
        query = f"""
            SELECT DISTINCT
                p.enforcement_mode,
                p.disabled_message
            FROM {self.catalog}.{self.schema}.md_users u
            JOIN {self.catalog}.{self.schema}.md_user_group_memberships m ON u.user_id = m.user_id
            JOIN {self.catalog}.{self.schema}.md_group_permissions gp ON m.group_id = gp.group_id
            JOIN {self.catalog}.{self.schema}.md_permissions p ON gp.permission_id = p.permission_id
            WHERE u.email = '{email}' 
              AND u.is_active = true
              AND p.permission_key = '{permission_key}'
        """
        
        try:
            results = self.client.execute_query(query)
            if results and len(results) > 0:
                return {
                    'has_permission': True,
                    'mode': results[0].get('enforcement_mode', 'HIDE'),
                    'message': results[0].get('disabled_message')
                }
        except Exception as e:
            print(f"Error fetching permission mode for {email}/{permission_key}: {e}")
        
        # User doesn't have permission - get default enforcement mode from permission definition
        default_mode_query = f"""
            SELECT enforcement_mode, disabled_message
            FROM {self.catalog}.{self.schema}.md_permissions
            WHERE permission_key = '{permission_key}'
        """
        
        try:
            results = self.client.execute_query(default_mode_query)
            if results and len(results) > 0:
                return {
                    'has_permission': False,
                    'mode': results[0].get('enforcement_mode', 'HIDE'),
                    'message': results[0].get('disabled_message', 'Permission denied')
                }
        except Exception as e:
            print(f"Error fetching default permission mode for {permission_key}: {e}")
        
        # Fallback: HIDE by default
        return {
            'has_permission': False,
            'mode': 'HIDE',
            'message': None
        }
    
    def get_users_by_vendor(self, vendor_name: str) -> list:
        """Get all active users for a specific vendor (case-insensitive)"""
        query = f"""
            SELECT 
                u.user_id,
                u.email,
                u.display_name,
                u.vendor_id,
                v.vendor_name,
                g.group_name
            FROM {self.catalog}.{self.schema}.md_users u
            JOIN {self.catalog}.{self.schema}.md_vendor v ON u.vendor_id = v.vendor_id
            LEFT JOIN {self.catalog}.{self.schema}.md_user_group_memberships m ON u.user_id = m.user_id
            LEFT JOIN {self.catalog}.{self.schema}.md_user_groups g ON m.group_id = g.group_id
            WHERE LOWER(v.vendor_name) = LOWER('{vendor_name}')
              AND u.is_active = true
              AND (g.group_name = 'VENDOR' OR g.group_name = 'group_vendor')
            ORDER BY u.display_name
        """
        
        try:
            results = self.client.execute_query(query)
            print(f"get_users_by_vendor: Found {len(results) if results else 0} users for vendor '{vendor_name}'")
            return [
                {
                    'user_id': row.get('user_id'),
                    'email': row.get('email'),
                    'display_name': row.get('display_name'),
                    'vendor_id': row.get('vendor_id'),
                    'vendor_name': row.get('vendor_name')
                }
                for row in results
            ] if results else []
        except Exception as e:
            print(f"Error fetching vendor users for {vendor_name}: {e}")
            import traceback
            traceback.print_exc()
            return []
    
    def list_all_users(self) -> list:
        """List all active users (for simulation dropdown)"""
        query = f"""
            SELECT 
                u.email,
                u.display_name,
                g.group_name,
                COALESCE(v.vendor_name, 'JNJ Internal') as organization
            FROM {self.catalog}.{self.schema}.md_users u
            LEFT JOIN {self.catalog}.{self.schema}.md_user_group_memberships m ON u.user_id = m.user_id
            LEFT JOIN {self.catalog}.{self.schema}.md_user_groups g ON m.group_id = g.group_id
            LEFT JOIN {self.catalog}.{self.schema}.md_vendor v ON u.vendor_id = v.vendor_id
            WHERE u.is_active = true
            ORDER BY g.group_name, u.display_name
        """
        
        try:
            results = self.client.execute_query(query)
            return [
                {
                    'email': row.get('email'),
                    'display_name': row.get('display_name'),
                    'group_name': row.get('group_name'),
                    'organization': row.get('organization')
                }
                for row in results
            ]
        except Exception as e:
            print(f"Error listing users: {e}")
            return []


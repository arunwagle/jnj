# SCD Type 2 Versioning Framework

## Overview

Generic versioning system for metadata library tables with 3-level versioning:
- **Library Major** (1.0, 2.0) - Production canonical data
- **DTA Major** (1.0-DTA_A-v1.0) - Approved DTA version
- **DTA Draft** (1.0-DTA_A-draft1) - Work in progress

Integrates with DTA workflow system for approval tracking.

---

## Table Definitions

### 1. `DTA` (Central DTA Entity)

The main DTA record representing a Data Transfer Agreement between JNJ and a Vendor.

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| dta_id | STRING | NO | PK - Unique DTA identifier |
| study_test_concept_mapping_id | STRING | YES | FK - Link to study test concept mapping |
| oa_ds_id | STRING | YES | FK - Operational agreement data stream ID |
| tp_ds_id | STRING | YES | FK - Transfer parameter data stream ID |
| tmdta_id | STRING | YES | FK - Transfer metadata DTA ID |
| study_visit_id | STRING | YES | FK - Study visit reference |
| content_hash | STRING | YES | Hash of DTA content for change detection |
| status | STRING | NO | DTA status (DRAFT, ACTIVE, ARCHIVED) |
| workflow_state | STRING | YES | Current workflow state |
| workflow_iteration | INT | YES | Current workflow iteration number |
| notes | STRING | YES | General notes about the DTA |
| record_source | STRING | YES | Source system identifier |
| created_by_principal | STRING | YES | User who created the record |
| created_ts | TIMESTAMP | YES | Record creation timestamp |
| last_updated_by_principal | STRING | YES | User who last updated |
| last_updated_ts | TIMESTAMP | YES | Last update timestamp |
| databricks_job_id | STRING | YES | Job ID for lineage |
| databricks_job_name | STRING | YES | Job name for lineage |
| databricks_run_id | STRING | YES | Run ID for lineage |

---

### 2. `DTA_WORKFLOW` (Workflow Cycle Tracking)

Tracks each workflow cycle/iteration for a DTA. A DTA can have multiple workflow cycles.

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| dta_workflow_id | STRING | NO | PK - Unique workflow identifier |
| dta_id | STRING | NO | FK - Reference to DTA |
| workflow_iteration | INT | NO | Iteration number (1, 2, 3...) |
| workflow_status | STRING | NO | NOT_STARTED, IN_REVIEW, APPROVED, REJECTED |
| workflow_state | STRING | YES | Detailed state within status |
| initiated_by_principal | STRING | YES | User who started the workflow |
| initiated_ts | TIMESTAMP | YES | When workflow was initiated |
| closed_ts | TIMESTAMP | YES | When workflow completed/closed |
| summary_comment | STRING | YES | Overall summary/comments for this workflow cycle |
| record_source | STRING | YES | Source system identifier |
| created_by_principal | STRING | YES | User who created the record |
| created_ts | TIMESTAMP | YES | Record creation timestamp |
| last_updated_by_principal | STRING | YES | User who last updated |
| last_updated_ts | TIMESTAMP | YES | Last update timestamp |
| databricks_job_id | STRING | YES | Job ID for lineage |
| databricks_job_name | STRING | YES | Job name for lineage |
| databricks_run_id | STRING | YES | Run ID for lineage |

---

### 3. `DTA_APPROVAL_TASK` (Approver Task Details)

Individual approval tasks for each approver in the workflow. Ordered by approval_order.

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| dta_approval_task_id | STRING | NO | PK - Unique task identifier |
| dta_workflow_id | STRING | NO | FK - Reference to workflow |
| dta_id | STRING | NO | FK - Reference to DTA |
| approver_role | STRING | NO | Role: VENDOR, JNJ_DAE, LEGAL, etc. |
| approver_principal | STRING | YES | Assigned approver user/principal |
| approval_order | INT | NO | Order in approval sequence (1, 2, 3...) |
| is_mandatory | BOOLEAN | NO | Whether approval is required |
| approval_status | STRING | NO | PENDING, APPROVED, REJECTED |
| approval_ts | TIMESTAMP | YES | When approved/rejected |
| response_comment | STRING | YES | Approver's comment (approval/rejection reason) |
| last_reminder_ts | TIMESTAMP | YES | Last reminder sent timestamp |
| reminder_count | INT | YES | Number of reminders sent |
| record_source | STRING | YES | Source system identifier |
| created_by_principal | STRING | YES | User who created the record |
| created_ts | TIMESTAMP | YES | Record creation timestamp |
| last_updated_by_principal | STRING | YES | User who last updated |
| last_updated_ts | TIMESTAMP | YES | Last update timestamp |
| databricks_job_id | STRING | YES | Job ID for lineage |
| databricks_job_name | STRING | YES | Job name for lineage |
| databricks_run_id | STRING | YES | Run ID for lineage |

---

### 4. `md_version_registry` (Version Tracking - NEW)

Central registry tracking all library versions. Source of truth for version metadata.

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| version_tag | STRING | NO | PK - Version identifier (e.g., "1.0", "1.0-DTA_A-draft1") |
| library_type | STRING | NO | Library type: "transfer_variables", "codelist" |
| version_type | STRING | NO | LIBRARY_MAJOR, DTA_MAJOR, DTA_DRAFT |
| dta_id | STRING | YES | FK - NULL for library major, DTA ID for branches |
| parent_version | STRING | YES | Version this branched from |
| record_count | INT | YES | Number of records in this version |
| status | STRING | NO | ACTIVE, SUPERSEDED, ARCHIVED |
| created_by_principal | STRING | YES | User who created the version |
| created_ts | TIMESTAMP | YES | Version creation timestamp |
| last_updated_by_principal | STRING | YES | User who last updated |
| last_updated_ts | TIMESTAMP | YES | Last update timestamp |
| databricks_job_id | STRING | YES | Job ID for lineage |
| databricks_job_name | STRING | YES | Job name for lineage |
| databricks_run_id | STRING | YES | Run ID for lineage |

---

### 5. `md_transfer_variables_library` (Gold Table - ENHANCED)

Master library of transfer variable definitions with SCD Type 2 versioning.

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| definition_hash | STRING | NO | Unique hash of variable definition |
| transfer_variable_name | STRING | NO | Variable name |
| transfer_variable_label | STRING | YES | Variable label/description |
| variable_description | STRING | YES | Detailed description |
| format | STRING | YES | Data format (text, numeric, date) |
| anticipated_max_length | INT | YES | Max field length |
| populate_for_all_records | BOOLEAN | YES | Required for all records flag |
| transfer_file_key | BOOLEAN | YES | Is part of unique key |
| example_values | STRING | YES | Example values |
| codelist_values | STRING | YES | Associated codelist values |
| used_in_trials | ARRAY | YES | Array of trial/stream/provider usage |
| usage_count | INT | YES | Number of times used |
| completed_count | INT | YES | Count of COMPLETED source records |
| review_required_count | INT | YES | Count of MANUAL_REVIEW source records |
| needs_review | BOOLEAN | YES | TRUE if any source needs review |
| first_seen_ts | TIMESTAMP | YES | First time this definition appeared |
| last_seen_ts | TIMESTAMP | YES | Last time this definition was seen |
| **library_version** | STRING | NO | Version tag (SCD Type 2) |
| **is_major_version** | BOOLEAN | NO | TRUE for library major (1.0, 2.0) |
| **is_dta_major** | BOOLEAN | NO | TRUE for DTA major (1.0-DTA_A-v1.0) |
| **parent_version** | STRING | YES | Version this branched from |
| **effective_start_ts** | TIMESTAMP | NO | SCD Type 2 - When version became active |
| **effective_end_ts** | TIMESTAMP | YES | SCD Type 2 - When superseded (NULL if current) |
| **is_current** | BOOLEAN | NO | TRUE if active version |
| created_by_principal | STRING | YES | User who created the record |
| created_ts | TIMESTAMP | YES | Record creation timestamp |
| last_updated_by_principal | STRING | YES | User who last updated |
| last_updated_ts | TIMESTAMP | YES | Last update timestamp |
| databricks_job_id | STRING | YES | Job ID for lineage |
| databricks_job_name | STRING | YES | Job name for lineage |
| databricks_run_id | STRING | YES | Run ID for lineage |

---

## Version Tag Format

```
{library_major}-{dta_id}-{version_type}{version_number}

Examples:
- 1.0                    → Library major v1
- 1.0-DTA_A-draft1       → DTA-A draft 1
- 1.0-DTA_A-draft2       → DTA-A draft 2
- 1.0-DTA_A-v1.0         → DTA-A major v1.0 (approved)
- 1.0-DTA_B-draft1       → DTA-B draft 1 (parallel)
- 2.0                    → Library major v2 (promoted)
```

---

## Workflow Integration

| Workflow Status | Versioning Action |
|-----------------|-------------------|
| NOT_STARTED | Create/save drafts allowed |
| IN_REVIEW | Read-only (no drafts) |
| REJECTED → NOT_STARTED | Create new drafts allowed |
| APPROVED | Auto-create DTA Major version |

---

## Workflow State Machine

```
┌──────────────────────────────────────────────────────────────────┐
│                                                                   │
│   DTA Created                                                     │
│       │                                                           │
│       ▼                                                           │
│   ┌─────────────┐                                                │
│   │ NOT_STARTED │ ◄─────────────────────────────┐                │
│   └─────────────┘                               │                │
│       │                                         │                │
│       │ (Submit for Approval)                   │ (Rejected)     │
│       ▼                                         │                │
│   ┌─────────────┐                               │                │
│   │ IN_REVIEW   │ ──→ JNJ ──→ Vendor ──→ Legal ─┼─→ (Approved)   │
│   └─────────────┘                               │        │       │
│                                                 │        ▼       │
│                                                 │   ┌──────────┐ │
│                                                 │   │ APPROVED │ │
│                                                 │   └──────────┘ │
│                                                 │        │       │
│                                                 │        ▼       │
│                                                 │   DTA Major    │
│                                                 │   Version      │
└──────────────────────────────────────────────────────────────────┘
```

---

## Versioning Lifecycle

```
Library v1.0 (production)
    │
    ├── DTA-A branches ──→ 1.0-DTA_A-draft1 ──→ draft2 ──→ draft3
    │                                                         │
    │                                          [Workflow Approved]
    │                                                         ▼
    │                                              1.0-DTA_A-v1.0 (DTA Major)
    │                                                         │
    │                                              [Continue working]
    │                                                         ▼
    │                                              1.0-DTA_A-draft4 ──→ draft5
    │                                                                     │
    │                                                      [Workflow Approved]
    │                                                                     ▼
    │                                                          1.0-DTA_A-v2.0
    │                                                                     │
    │                                                      [Promote to Library]
    │                                                                     ▼
    └──────────────────────────────────────────────────────────────► Library v2.0
```

---

## Key Query Patterns

```sql
-- Get current library major version (production)
SELECT * FROM md_transfer_variables_library 
WHERE is_major_version = TRUE AND is_current = TRUE;

-- Get DTA-A's current working version
SELECT l.* 
FROM md_transfer_variables_library l
JOIN md_version_registry v ON l.library_version = v.version_tag
WHERE v.dta_id = 'DTA_A' AND v.status = 'ACTIVE' AND l.is_current = TRUE;

-- Get version history for a DTA
SELECT * FROM md_version_registry 
WHERE dta_id = 'DTA_A' ORDER BY created_ts;

-- Get specific version snapshot
SELECT * FROM md_transfer_variables_library 
WHERE library_version = '1.0-DTA_A-draft2';
```

---

## Files to Create/Modify

| File | Action |
|------|--------|
| `src/.../versioning.py` | CREATE - Generic versioning utilities |
| `config/clinical_data_standards.yaml` | MODIFY - Add versioning config |
| `notebooks/.../common/nb_dta_version_manager.ipynb` | CREATE - CREATE_BRANCH, SAVE_DRAFT |
| `notebooks/.../common/nb_promote_to_library.ipynb` | CREATE - Promote to library major |
| `notebooks/.../common/nb_build_gold_transfer_variables.ipynb` | MODIFY - Add versioning columns |
| `clnl-data-std-mgmt-app/api/versioning_api.py` | CREATE - Version query APIs |
| `resources/.../jobs/job_dta_version_manager.job.yml` | CREATE - Workflow job |
| `docs/diagrams/versioning_process.drawio` | CREATE - Versioning diagram |
| `docs/diagrams/workflow_process.drawio` | CREATE - Workflow diagram |

---

## Key Functions (versioning.py)

```python
create_library_branch(spark, library_table, dta_id, base_version) -> str
save_dta_draft(spark, library_table, dta_id, changes_df) -> str
approve_dta_version(spark, library_table, dta_id) -> str
promote_to_library_major(spark, library_table, dta_id, dta_version) -> str
get_version_data(spark, library_table, version_tag) -> DataFrame
get_dta_current_version(spark, library_table, dta_id) -> str
```

---

## API Endpoints (versioning_api.py)

```
GET  /api/versions/{library_type}              - List all versions
GET  /api/versions/{library_type}/{version}    - Get version data
GET  /api/dta/{dta_id}/versions                - List versions for DTA
GET  /api/dta/{dta_id}/current                 - Get current working version
```


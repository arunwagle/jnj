"""
Versioning API Endpoints

Provides read-only REST API endpoints for querying version information
from the SCD Type 2 versioning system.
"""

from flask import Blueprint, jsonify, request
from api.databricks_client import DatabricksJobsClient
import os

versioning_bp = Blueprint('versioning', __name__)


def get_databricks_client():
    """Get configured Databricks client."""
    return DatabricksJobsClient(
        host=os.environ.get('DATABRICKS_HOST'),
        token=os.environ.get('DATABRICKS_TOKEN')
    )


def get_table_config():
    """Get table configuration from environment or defaults."""
    catalog = os.environ.get('DATABRICKS_CATALOG', 'aira')
    gold_schema = os.environ.get('DATABRICKS_GOLD_SCHEMA', 'gold_md')
    warehouse_id = os.environ.get('DATABRICKS_WAREHOUSE_ID')
    
    return {
        'catalog': catalog,
        'gold_schema': gold_schema,
        'warehouse_id': warehouse_id,
        'registry_table': f'{catalog}.{gold_schema}.md_version_registry',
        'transfer_variables_table': f'{catalog}.{gold_schema}.md_transfer_variables_library'
    }


@versioning_bp.route('/api/versions', methods=['GET'])
def get_all_versions():
    """
    Get all versions from the registry.
    
    Query params:
    - library_type: Filter by library type (e.g., transfer_variables)
    - status: Filter by status (ACTIVE, SUPERSEDED, ARCHIVED)
    - version_type: Filter by version type (LIBRARY_MAJOR, DTA_MAJOR, DTA_DRAFT)
    """
    try:
        config = get_table_config()
        client = get_databricks_client()
        
        library_type = request.args.get('library_type')
        status = request.args.get('status')
        version_type = request.args.get('version_type')
        
        # Build query
        query = f"SELECT * FROM {config['registry_table']}"
        conditions = []
        
        if library_type:
            conditions.append(f"library_type = '{library_type}'")
        if status:
            conditions.append(f"status = '{status}'")
        if version_type:
            conditions.append(f"version_type = '{version_type}'")
        
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        
        query += " ORDER BY created_ts DESC"
        
        result = client.execute_sql(query, config['warehouse_id'])
        
        return jsonify({
            'success': True,
            'data': result,
            'count': len(result)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@versioning_bp.route('/api/versions/<library_type>/<version_tag>', methods=['GET'])
def get_version_details(library_type, version_tag):
    """
    Get details for a specific version.
    
    Returns version metadata and record count.
    """
    try:
        config = get_table_config()
        client = get_databricks_client()
        
        # Get version metadata
        query = f"""
            SELECT * FROM {config['registry_table']}
            WHERE version_tag = '{version_tag}'
              AND library_type = '{library_type}'
        """
        
        result = client.execute_sql(query, config['warehouse_id'])
        
        if not result:
            return jsonify({
                'success': False,
                'error': f'Version {version_tag} not found'
            }), 404
        
        return jsonify({
            'success': True,
            'data': result[0]
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@versioning_bp.route('/api/versions/<library_type>/<version_tag>/data', methods=['GET'])
def get_version_data(library_type, version_tag):
    """
    Get actual data for a specific version.
    
    Query params:
    - limit: Maximum records to return (default 100)
    - offset: Offset for pagination (default 0)
    """
    try:
        config = get_table_config()
        client = get_databricks_client()
        
        limit = request.args.get('limit', 100, type=int)
        offset = request.args.get('offset', 0, type=int)
        
        # Map library type to table
        table_map = {
            'transfer_variables': config['transfer_variables_table']
        }
        
        if library_type not in table_map:
            return jsonify({
                'success': False,
                'error': f'Unknown library type: {library_type}'
            }), 400
        
        table = table_map[library_type]
        
        # Get data for this version
        query = f"""
            SELECT * FROM {table}
            WHERE library_version = '{version_tag}'
            LIMIT {limit} OFFSET {offset}
        """
        
        result = client.execute_sql(query, config['warehouse_id'])
        
        # Get total count
        count_query = f"""
            SELECT COUNT(*) as total FROM {table}
            WHERE library_version = '{version_tag}'
        """
        count_result = client.execute_sql(count_query, config['warehouse_id'])
        total = count_result[0]['total'] if count_result else 0
        
        return jsonify({
            'success': True,
            'data': result,
            'pagination': {
                'total': total,
                'limit': limit,
                'offset': offset
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@versioning_bp.route('/api/dta/<dta_id>/versions', methods=['GET'])
def get_dta_versions(dta_id):
    """
    Get all versions for a specific DTA.
    
    Query params:
    - library_type: Filter by library type
    """
    try:
        config = get_table_config()
        client = get_databricks_client()
        
        library_type = request.args.get('library_type')
        
        query = f"""
            SELECT * FROM {config['registry_table']}
            WHERE dta_id = '{dta_id}'
        """
        
        if library_type:
            query += f" AND library_type = '{library_type}'"
        
        query += " ORDER BY created_ts DESC"
        
        result = client.execute_sql(query, config['warehouse_id'])
        
        return jsonify({
            'success': True,
            'data': result,
            'count': len(result),
            'dta_id': dta_id
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@versioning_bp.route('/api/dta/<dta_id>/current', methods=['GET'])
def get_dta_current(dta_id):
    """
    Get the current working version for a DTA.
    
    Query params:
    - library_type: Filter by library type (default: transfer_variables)
    """
    try:
        config = get_table_config()
        client = get_databricks_client()
        
        library_type = request.args.get('library_type', 'transfer_variables')
        
        query = f"""
            SELECT * FROM {config['registry_table']}
            WHERE dta_id = '{dta_id}'
              AND library_type = '{library_type}'
              AND status = 'ACTIVE'
            ORDER BY created_ts DESC
            LIMIT 1
        """
        
        result = client.execute_sql(query, config['warehouse_id'])
        
        if not result:
            return jsonify({
                'success': False,
                'error': f'No active version found for DTA: {dta_id}'
            }), 404
        
        return jsonify({
            'success': True,
            'data': result[0],
            'dta_id': dta_id
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@versioning_bp.route('/api/library/current', methods=['GET'])
def get_library_current():
    """
    Get the current library major version (production).
    
    Query params:
    - library_type: Library type (default: transfer_variables)
    """
    try:
        config = get_table_config()
        client = get_databricks_client()
        
        library_type = request.args.get('library_type', 'transfer_variables')
        
        query = f"""
            SELECT * FROM {config['registry_table']}
            WHERE library_type = '{library_type}'
              AND version_type = 'LIBRARY_MAJOR'
              AND status = 'ACTIVE'
            ORDER BY created_ts DESC
            LIMIT 1
        """
        
        result = client.execute_sql(query, config['warehouse_id'])
        
        if not result:
            return jsonify({
                'success': False,
                'error': f'No active library version found for: {library_type}'
            }), 404
        
        return jsonify({
            'success': True,
            'data': result[0]
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@versioning_bp.route('/api/library/history', methods=['GET'])
def get_library_history():
    """
    Get the library major version history.
    
    Query params:
    - library_type: Library type (default: transfer_variables)
    """
    try:
        config = get_table_config()
        client = get_databricks_client()
        
        library_type = request.args.get('library_type', 'transfer_variables')
        
        query = f"""
            SELECT * FROM {config['registry_table']}
            WHERE library_type = '{library_type}'
              AND version_type = 'LIBRARY_MAJOR'
            ORDER BY created_ts DESC
        """
        
        result = client.execute_sql(query, config['warehouse_id'])
        
        return jsonify({
            'success': True,
            'data': result,
            'count': len(result)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500



-- ============================================================================
-- Reference Data Load SQL - reference_data
-- ============================================================================
-- Purpose: Load reference/lookup data into silver schema
-- Use Case: clinical_data_standards
-- ============================================================================

-- Set catalog and schema context
USE CATALOG dta_poc;
USE SCHEMA silver_md;

-- ============================================================================
-- Example 1: Create and load a simple lookup table
-- ============================================================================

-- Drop table if exists (for demo purposes - remove in production)
-- DROP TABLE IF EXISTS reference_data_lookup;

-- Create lookup table
CREATE TABLE IF NOT EXISTS reference_data_lookup (
  lookup_key STRING NOT NULL,
  lookup_value STRING,
  description STRING,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP(),
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
)
USING DELTA
COMMENT 'Reference data lookup table for reference_data';

-- Insert sample reference data
-- Replace with your actual reference data
MERGE INTO reference_data_lookup AS target
USING (
  SELECT * FROM VALUES
    ('STATUS_ACTIVE', 'Active', 'Active status', TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
    ('STATUS_INACTIVE', 'Inactive', 'Inactive status', TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
    ('STATUS_PENDING', 'Pending', 'Pending status', TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
    ('TYPE_A', 'Type A', 'Category Type A', TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
    ('TYPE_B', 'Type B', 'Category Type B', TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),
    ('TYPE_C', 'Type C', 'Category Type C', TRUE, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP())
  AS source(lookup_key, lookup_value, description, is_active, created_at, updated_at)
) AS source
ON target.lookup_key = source.lookup_key
WHEN MATCHED THEN
  UPDATE SET
    target.lookup_value = source.lookup_value,
    target.description = source.description,
    target.is_active = source.is_active,
    target.updated_at = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
  INSERT (lookup_key, lookup_value, description, is_active, created_at, updated_at)
  VALUES (source.lookup_key, source.lookup_value, source.description, source.is_active, source.created_at, source.updated_at);

-- ============================================================================
-- Example 2: Load data from CSV in Volumes (if available)
-- ============================================================================

-- Uncomment and customize if loading from CSV files
/*
CREATE TABLE IF NOT EXISTS reference_data_from_csv
USING DELTA
AS
SELECT *
FROM read_files(
  '/Volumes/dta_poc/bronze_md/reference_data/reference_data/*.csv',
  format => 'csv',
  header => true,
  inferSchema => true
);
*/

-- ============================================================================
-- Display load summary
-- ============================================================================

SELECT 
  '✅ Load Complete' as status,
  'dta_poc.silver_md' as schema,
  'reference_data_lookup' as table_name,
  COUNT(*) as records_loaded
FROM reference_data_lookup;

-- ============================================================================
-- Config Cache Table - For Optimized Setup Performance
-- ============================================================================
-- Purpose: Cache parsed YAML configuration for fast job setup (~5 sec vs ~1 min)
-- Each section of clinical_data_standards.yaml is stored as a JSON blob
-- Run nb_populate_config_cache.ipynb after this to populate with real config
-- ============================================================================

-- Switch to bronze schema for config cache
USE SCHEMA bronze_md;

-- Create config cache table
CREATE TABLE IF NOT EXISTS md_config_cache (
  config_key STRING NOT NULL COMMENT 'Config file identifier (e.g., clinical_data_standards)',
  config_section STRING NOT NULL COMMENT 'Config section name (globals, versioning, services, streaming, pipelines)',
  config_json STRING COMMENT 'JSON blob of parsed config section',
  config_version STRING COMMENT 'Version of the config (for tracking changes)',
  updated_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP() COMMENT 'Last update timestamp',
  updated_by STRING COMMENT 'Principal who updated the config',
  CONSTRAINT pk_config_cache PRIMARY KEY (config_key, config_section)
)
USING DELTA
COMMENT 'Cached configuration for fast job setup. Populated from clinical_data_standards.yaml via nb_populate_config_cache notebook.'
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'false',
  'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Insert placeholder config sections (will be populated by migration notebook)
MERGE INTO md_config_cache AS target
USING (
  SELECT * FROM VALUES
    ('clinical_data_standards', 'globals', '{}', '1.0.0', CURRENT_TIMESTAMP(), 'system'),
    ('clinical_data_standards', 'services', '{}', '1.0.0', CURRENT_TIMESTAMP(), 'system'),
    ('clinical_data_standards', 'versioning', '{}', '1.0.0', CURRENT_TIMESTAMP(), 'system'),
    ('clinical_data_standards', 'streaming', '{}', '1.0.0', CURRENT_TIMESTAMP(), 'system'),
    ('clinical_data_standards', 'pipelines', '{}', '1.0.0', CURRENT_TIMESTAMP(), 'system'),
    ('clinical_data_standards', 'validation', '{}', '1.0.0', CURRENT_TIMESTAMP(), 'system')
  AS source(config_key, config_section, config_json, config_version, updated_ts, updated_by)
) AS source
ON target.config_key = source.config_key AND target.config_section = source.config_section
WHEN NOT MATCHED THEN
  INSERT (config_key, config_section, config_json, config_version, updated_ts, updated_by)
  VALUES (source.config_key, source.config_section, source.config_json, source.config_version, source.updated_ts, source.updated_by);

-- Display config cache status
SELECT 
  '📋 Config Cache Table Created' as status,
  'bronze_md.md_config_cache' as table_name,
  COUNT(*) as sections_ready
FROM md_config_cache
WHERE config_key = 'clinical_data_standards';


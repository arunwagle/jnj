"""
setup.py configuration script for clinical-data-standards.

This file describes how to build and package the clinical_data_standards_framework.
Organization: JNJ
"""

from setuptools import setup, find_packages
import sys

sys.path.append("./src")

# Fixed versioning for consistent wheel names with serverless
# Version can be incremented manually: 0.0.1, 0.0.2, 0.0.3, etc.
version = "0.0.1"

setup(
    name="clinical_data_standards_framework",
    version=version,
    url="https://databricks.com",
    author="JNJ",
    description="Databricks framework for clinical-data-standards",
    packages=find_packages(where="./src"),
    package_dir={"": "src"},
    install_requires=[
        "setuptools",
        "pyyaml>=6.0",  # For ConfigManager YAML parsing
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
)



# JNJ • DTA Studio — Flask Clickable Prototype (Updated)

**Improvements**
- “New DTA” button is now right-aligned in the Search Results header.
- Action buttons in result cards use clean outline styles: **Open** (brand outline) and **Clone as Draft** (neutral outline).

## Quick Start
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
# http://localhost:5000/composer
```

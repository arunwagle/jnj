# Delete Functionality Deployment Package
**Date:** January 27, 2026  
**Feature:** DTA Library Item Delete/Restore Functionality + DTA Approval Enhancements

---

## Overview

This deployment package includes all changes for:
1. **Delete/Restore Functionality**: Users with JNJ DAE role can now delete and restore library items (Transfer Variables, Test Concepts, Codelists, Data Ingestion Parameters) on the Edit DTA screen
2. **DTA Approval Enhancements**: Filter out system-approved DTAs and show who approved each DTA in the DTA Workflow screen
3. **Data Integrity**: Ensure deletions are correctly reflected in gold tables during DTA approval process

---

## Files Included (9 files)

### Critical Files ⭐ (Must Deploy)

1. **`apps/clnl-data-std-mgmt-app/app.py`** ⭐
   - Backend API endpoints for delete/restore operations
   - Fixed deletion processing logic (backwards iteration)
   - Updated DTA approval queries to filter system-approved DTAs
   - Integrated deletion activity logging using `log_batch_update()`

2. **`apps/clnl-data-std-mgmt-app/api/activity_log_api.py`** ⭐
   - Enhanced `log_batch_update()` to handle CREATED, UPDATED, and DELETED operations
   - Properly formats deletion activity logs with entity IDs

3. **`apps/clnl-data-std-mgmt-app/templates/workspace.html`** ⭐
   - Added delete buttons for Transfer Variables, Test Concepts, Codelists, and Data Ingestion Parameters
   - All delete buttons protected by permission check: `{% if can('action_delete_library_item') %}`

4. **`apps/clnl-data-std-mgmt-app/static/script.js`** ⭐
   - Added `deleteLibraryItem()`, `restoreLibraryItem()` functions for TV/TC
   - Added `deleteCodelistItem()`, `restoreCodelistItem()` functions for Codelists
   - Added `dipDelete()` function for Data Ingestion Parameters
   - Includes UI updates, strikethrough styling, and inline restore buttons

5. **`notebooks/data_engineering/common/nb_version_approve_dta.ipynb`** ⭐
   - CRITICAL: Added SQL UPDATE statements to mark previous versions as `is_current = false`
   - Ensures deletions are correctly reflected in gold tables during approval
   - Applied to all library tables and their related tables

### Important Files (Should Deploy)

6. **`apps/clnl-data-std-mgmt-app/templates/approvals.html`**
   - Shows `approved_by` in "Recently Approved" panel on DTA Workflow page

7. **`apps/clnl-data-std-mgmt-app/static/styles.css`**
   - Styling for `.btn-action-delete` (red color, hover effects)

8. **`sql/setup_cdm_app_permissions.sql`**
   - Defines `action_delete_library_item` permission (only for JNJ_DAE role)
   - Run once during initial setup or permissions refresh

9. **`docs/04_versioning_design.readme.md`**
   - Documentation for how inserts, updates, and deletes are handled
   - Explains SCD Type 2 versioning with `is_current` flag

---

## Deployment Instructions

### Step 1: Backup Current Files
Before deploying, backup the current versions of all files being replaced.

### Step 2: Deploy Application Files
Copy the following files to your Databricks App workspace:

```bash
# Backend
apps/clnl-data-std-mgmt-app/app.py
apps/clnl-data-std-mgmt-app/api/activity_log_api.py

# Templates
apps/clnl-data-std-mgmt-app/templates/workspace.html
apps/clnl-data-std-mgmt-app/templates/approvals.html

# Static assets
apps/clnl-data-std-mgmt-app/static/script.js
apps/clnl-data-std-mgmt-app/static/styles.css
```

### Step 3: Deploy Notebook
Upload the notebook to your Databricks workspace:

```bash
notebooks/data_engineering/common/nb_version_approve_dta.ipynb
```

**⚠️ IMPORTANT**: This notebook is used by the `job_cdm_version_manager` job. Ensure the job is not running during deployment.

### Step 4: Update Permissions (If Not Already Done)
If this is the first time deploying delete functionality:

```sql
-- Run this SQL in your Databricks workspace
-- Replace :catalog_name with your actual catalog name
USE CATALOG :catalog_name;
USE SCHEMA gold_md;

-- Execute the permissions setup
-- This adds the action_delete_library_item permission
-- Source: sql/setup_cdm_app_permissions.sql
```

**Note**: If permissions were already set up in a previous deployment, you can skip this step.

### Step 5: Restart the Application
Restart the Flask application to load the new code:

```bash
# In Databricks Apps, click "Restart App"
# OR use Databricks CLI if available
databricks apps restart <app-id>
```

### Step 6: Verify Deployment

1. **Login as JNJ DAE user**
2. **Navigate to**: DTA Workspace > Edit DTA
3. **Verify**:
   - Delete button (trash icon) appears on each row for TV, TC, Codelists, DIP
   - Clicking delete shows strikethrough and restore button
   - Clicking "Save as Draft" logs the deletion to activity history
4. **Navigate to**: DTA Workflow
5. **Verify**:
   - "Awaiting Approvals" panel does NOT show system-approved DTAs
   - "Recently Approved" panel shows who approved each DTA
6. **Submit DTA for approval** (with deletions)
7. **Promote to Major Version**
8. **Verify in Gold Tables**:
   - Deleted items have `is_current = false` and `effective_end_ts` set
   - Only current items have `is_current = true`

---

## Testing Checklist

- [ ] JNJ DAE can see delete buttons on all library items
- [ ] Vendor users CANNOT see delete buttons
- [ ] Librarian users CANNOT see delete buttons
- [ ] Delete marks item with strikethrough and shows restore button
- [ ] Restore removes strikethrough
- [ ] "Save as Draft" correctly counts deletions in success message
- [ ] DTA Activity Log shows DELETED entries with item names
- [ ] System-approved DTAs are filtered from "Awaiting Approvals"
- [ ] "Recently Approved" shows approved_by names
- [ ] Approval process with deletions updates gold tables correctly
- [ ] Gold tables show `is_current = false` for deleted items
- [ ] DTA Viewer shows only current items (is_current = true)

---

## Rollback Plan

If issues arise after deployment:

1. **Restore backed-up files** from Step 1
2. **Restart the application**
3. **If permissions were modified**: Restore the `md_permissions` table from backup

**Note**: The notebook change is backward compatible. If you need to rollback the app but keep the new notebook, it will still work with the old app code.

---

## Technical Details

### Soft Delete Pattern
- **Draft Environment**: Items marked with `_marked_for_deletion = true` in workspace
- **Save Draft**: Item removed from silver table (hard delete in draft)
- **Approval**: Previous versions in gold marked `is_current = false`, new versions marked `is_current = true`
- **Queries**: All views/queries filter by `is_current = true` to show only active items

### Activity Logging
All deletions logged using `log_batch_update()` with:
- `activity_category = "DATA_CHANGE"`
- `activity_type = "BATCH_UPDATE"`
- `field_changes = [{'entity_name': '...', 'field': 'DELETED', 'entity_id': '...'}]`

This is consistent with how inserts (CREATED) and updates (field changes) are logged.

### Permissions
- Permission Key: `action_delete_library_item`
- Enforcement Mode: `HIDE`
- Assigned To: `JNJ_DAE` group only

---

## Support

For questions or issues with this deployment:
- Contact: Data Engineering Team
- Documentation: `docs/04_versioning_design.readme.md`

---

## Change Log

### January 27, 2026
- ✅ Added delete/restore functionality for all library items
- ✅ Enhanced DTA approval workflow UI
- ✅ Fixed deletion data integrity in gold tables
- ✅ Updated activity logging for deletions
- ✅ Added comprehensive versioning documentation


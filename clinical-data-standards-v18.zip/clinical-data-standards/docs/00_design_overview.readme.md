# DTA Builder - Design Overview

> **Status**: Implemented  
> **Last Updated**: January 2026

---

## Table of Contents

- [Project Overview](#project-overview)
  - [Purpose](#purpose)
  - [Key Capabilities](#key-capabilities)
- [Architecture Summary](#architecture-summary)
  - [Platform](#platform)
  - [High-Level Architecture](#high-level-architecture)
- [Design Documents](#design-documents)
- [Quick Start](#quick-start)

---

## Project Overview

The **DTA Builder** is a metadata-driven platform for managing Data Transfer Agreements (DTAs) across the clinical data lifecycle. DTAs define the specifications, formats, and validation rules for data exchanged between pharmaceutical sponsors and external vendors (labs, CROs, data providers).

### Purpose

- **Standardize** DTA creation and management across clinical trials
- **Automate** metadata extraction from legacy Excel-based specifications
- **Version Control** all changes with full audit trail
- **Accelerate** delivery timelines through reusable templates
- **Ensure Governance** with multi-party approval workflows

### Key Capabilities

| Capability | Description |
|------------|-------------|
| **Metadata-Driven** | Capture transfer variables, test concepts, codelists as structured metadata |
| **Template Library** | Create reusable templates scoped by vendor and data stream |
| **Version Management** | SCD Type 2 versioning with branch, draft, approve, promote lifecycle |
| **Approval Workflow** | Multi-party approval chain (JNJ DAE → Vendor → Legal → Librarian) |
| **AI-Powered** | Document parsing, entity extraction, natural language search |
| **Export Formats** | Generate tsDTA Excel, Operational Agreement PDFs, full packages |

---

## Architecture Summary

### Platform

The DTA Builder is built on **Databricks** with the following components:

| Component | Technology | Purpose |
|-----------|------------|---------|
| **Data Platform** | Databricks Unity Catalog | Data governance, lineage, permissions |
| **Processing** | Databricks Jobs + Notebooks | ETL pipelines, versioning operations |
| **Storage** | Delta Lake (Bronze/Silver/Gold) | Medallion architecture for data layers |
| **UI Application** | Databricks Apps (Flask) | Web interface for DTA management |
| **Genie Agent** | Databricks AI/BI Genie | Natural language search and discovery |

### High-Level Architecture

#### DTA Builder Architecture

![DTA Builder Architecture](./diagrams/00_dta_builder_architecture.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/00_dta_builder_architecture.drawio)

#### CDH (Clinical Data Hub) - Future State Conceptual Architecture

> **Note**: This is a conceptual architecture based on the CDR Hackathon requirements. It illustrates the envisioned downstream flow from DTA Builder.

The CDH diagram expands the downstream consumer of DTA Builder, showing how approved DTAs flow into the Clinical Data Hub for study setup, vendor data ingestion, and conformance validation.

![CDH Conceptual Architecture](./diagrams/00_cdh_architecture.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/00_cdh_architecture.drawio)

---

## Design Documents

| # | Document | Description |
|---|----------|-------------|
| 01 | [Job Architecture](./01_job_architecture_design.readme.md) | Pipeline jobs, orchestration, and task dependencies |
| 02 | [Schema Design](./02_schema_design.readme.md) | Table schemas, ERD, and data model |
| 03 | [Status Lifecycle](./03_status_lifecycle_design.readme.md) | Document and DTA status tracking |
| 04 | [Versioning](./04_versioning_design.readme.md) | SCD Type 2 version management and template creation |
| 05 | [Hash Generation](./05_hash_generation_design.readme.md) | Deduplication and change detection algorithms |
| 06 | [DTA Workflow](./06_dta_workflow_design.readme.md) | Approval flow, approver roles, and governance |
| 07 | [AI Processing](./07_ai_processing_design.readme.md) | Document parsing, entity extraction, model selection |
| 08 | [Permissions](./08_permissions_design.readme.md) | Access control, roles, and security |
| 09 | [Genie Integration](./09_genie_integration_design.readme.md) | AI/BI natural language interface and training |

---

## Quick Start

### Deployment

See [Deployment Guide](./deployment_guide.md) for setup instructions.

### Useful Queries

See [Useful Queries](./useful_queries.md) for common SQL queries and debugging.

---

*Last Updated: January 2026*


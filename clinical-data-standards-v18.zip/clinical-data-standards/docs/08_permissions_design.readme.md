# Permissions & Access Control Design

## Overview

This document describes the permissions and access control architecture for the Clinical Data Standards Management application, including Unity Catalog access, Databricks Apps authentication, and role-based access control.

---

## Architecture Diagram

```mermaid
flowchart TB
    subgraph Users["User Access"]
        U1[Data Engineer]
        U2[Librarian]
        U3[Vendor User]
        U4[JNJ Approver]
    end
    
    subgraph App["Databricks App"]
        FLASK[Flask Application]
        API[API Layer]
        
        subgraph Auth["Authentication"]
            SP[App Service Principal]
            OBO[On-Behalf-Of Token]
        end
    end
    
    subgraph UC["Unity Catalog"]
        CAT[Catalog: aira_test]
        SCH_B[Schema: bronze_md]
        SCH_S[Schema: silver_md]
        SCH_G[Schema: gold_md]
    end
    
    subgraph Resources["Databricks Resources"]
        JOBS[Jobs]
        WH[SQL Warehouse]
    end
    
    U1 & U2 & U3 & U4 --> FLASK
    FLASK --> API
    API --> SP
    API -.-> OBO
    SP --> UC
    SP --> Resources
    OBO --> UC
```

---

## Authentication Modes

### 1. Service Principal Authentication (Current)

The Databricks App runs with its own **Service Principal** identity. All data access operations use this identity.

```
User (arun.wagle) → App → App Service Principal → Unity Catalog
```

**Pros:**
- Simple setup
- Works for background/batch operations
- Consistent permissions regardless of user

**Cons:**
- Requires explicit GRANT statements
- No per-user row-level security
- Audit logs show service principal, not user

### 2. On-Behalf-Of (OBO) Authentication (Recommended for Production)

The app uses the **logged-in user's token** to execute operations. Each user's permissions are respected.

```
User (arun.wagle) → App → User's Token → Unity Catalog
```

**Pros:**
- Uses existing user permissions (no extra GRANTs)
- Row-level security enforced
- Column masking respected
- Audit logs show actual user

**Cons:**
- Requires code changes
- Cannot do background operations (no user context)

---

## Required Unity Catalog Permissions

### For Service Principal Mode

Run these SQL statements to grant the app service principal access:

```sql
-- ============================================================
-- GRANT PERMISSIONS TO DATABRICKS APP SERVICE PRINCIPAL
-- ============================================================

-- Find the app's service principal name in Databricks UI:
-- Compute → Apps → [Your App] → Settings

-- Replace 'App - clnl-data-std-mgmt-app' with your actual service principal name

-- 1. Grant USE CATALOG
GRANT USE CATALOG ON CATALOG aira_test TO `App - clnl-data-std-mgmt-app`;

-- 2. Grant USE SCHEMA for all required schemas
GRANT USE SCHEMA ON SCHEMA aira_test.bronze_md TO `App - clnl-data-std-mgmt-app`;
GRANT USE SCHEMA ON SCHEMA aira_test.silver_md TO `App - clnl-data-std-mgmt-app`;
GRANT USE SCHEMA ON SCHEMA aira_test.gold_md TO `App - clnl-data-std-mgmt-app`;

-- 3. Grant SELECT on schemas (for reading data)
GRANT SELECT ON SCHEMA aira_test.bronze_md TO `App - clnl-data-std-mgmt-app`;
GRANT SELECT ON SCHEMA aira_test.silver_md TO `App - clnl-data-std-mgmt-app`;
GRANT SELECT ON SCHEMA aira_test.gold_md TO `App - clnl-data-std-mgmt-app`;

-- 4. (Optional) Grant MODIFY if app needs to write data
-- GRANT MODIFY ON SCHEMA aira_test.gold_md TO `App - clnl-data-std-mgmt-app`;
```

### Verify Permissions

```sql
-- Check grants on catalog
SHOW GRANTS ON CATALOG aira_test;

-- Check grants on schema
SHOW GRANTS ON SCHEMA aira_test.gold_md;

-- Check grants for specific principal
SHOW GRANTS TO `App - clnl-data-std-mgmt-app`;
```

---

## Implementing OBO Authentication

### Step 1: Get User Token from Request Headers

```python
from flask import request
from databricks.sdk import WorkspaceClient

def get_user_client():
    """Get WorkspaceClient using logged-in user's token (OBO)"""
    # Databricks injects user's token in this header
    user_token = request.headers.get("X-Forwarded-Access-Token")
    
    if not user_token:
        raise RuntimeError("No user token found. OBO requires user to be logged in.")
    
    return WorkspaceClient(token=user_token)
```

### Step 2: Use User Client for Data Operations

```python
def _get_sql_client_obo():
    """Get SQL client using user's credentials"""
    user_token = request.headers.get("X-Forwarded-Access-Token")
    
    if not user_token:
        # Fallback to service principal
        return DatabricksSQLClient(warehouse_id)
    
    # Create client with user token
    return DatabricksSQLClient(warehouse_id, token=user_token)
```

### Step 3: Update DatabricksSQLClient

```python
class DatabricksSQLClient:
    def __init__(self, warehouse_id: str, token: str = None):
        if token:
            # Use provided token (OBO mode)
            self.w = WorkspaceClient(token=token)
        else:
            # Use default credentials (service principal)
            self.w = WorkspaceClient()
        self.warehouse_id = warehouse_id
```

---

## Role-Based Access Control (RBAC)

### Application Roles

| Role | Description | Permissions |
|------|-------------|-------------|
| **JNJ_DATA_ENGINEER** | Creates and manages DTAs | Create DTA, Edit Draft, Submit for Approval |
| **JNJ_APPROVER** | Approves/rejects DTAs | View DTA, Approve, Reject, Request Changes |
| **VENDOR** | External vendor users | View assigned DTAs, Edit sections, Submit |
| **LIBRARIAN** | Manages library versions | Promote to DTA Template, Merge DTAs |
| **ADMIN** | Full system access | All operations, User management |

### Permission Matrix

| Action | DATA_ENGINEER | APPROVER | VENDOR | LIBRARIAN | ADMIN |
|--------|---------------|----------|--------|-----------|-------|
| View Dashboard | ✅ | ✅ | ✅ | ✅ | ✅ |
| Create DTA | ✅ | ❌ | ❌ | ✅ | ✅ |
| Edit Draft | ✅ | ❌ | ✅* | ✅ | ✅ |
| Submit for Approval | ✅ | ❌ | ✅ | ✅ | ✅ |
| Approve DTA | ❌ | ✅ | ❌ | ✅ | ✅ |
| Reject DTA | ❌ | ✅ | ❌ | ✅ | ✅ |
| Promote to Library | ❌ | ❌ | ❌ | ✅ | ✅ |
| Merge DTAs | ❌ | ❌ | ❌ | ✅ | ✅ |
| Manage Users | ❌ | ❌ | ❌ | ❌ | ✅ |

*Vendor can only edit DTAs assigned to them

---

## SQL Warehouse Access

The app requires access to a SQL Warehouse for executing queries.

### Configuration

In `app.yaml`:
```yaml
env:
  - name: DATABRICKS_WAREHOUSE_ID
    value: "148ccb90800933a1"
```

### Warehouse Permissions

The app service principal needs `CAN_USE` permission on the SQL Warehouse:

```sql
-- Grant warehouse usage
GRANT CAN_USE ON WAREHOUSE `your-warehouse-name` TO `App - clnl-data-std-mgmt-app`;
```

Or via Databricks UI:
1. Go to **SQL** → **SQL Warehouses**
2. Select your warehouse → **Permissions**
3. Add the app service principal with **Can use** permission

---

## Environment Variables

### Required for App Operation

| Variable | Description | Example |
|----------|-------------|---------|
| `CATALOG_NAME` | Unity Catalog name | `aira_test` |
| `BRONZE_SCHEMA` | Bronze layer schema | `bronze_md` |
| `SILVER_SCHEMA` | Silver layer schema | `silver_md` |
| `GOLD_SCHEMA` | Gold layer schema | `gold_md` |
| `DATABRICKS_WAREHOUSE_ID` | SQL Warehouse ID | `148ccb90800933a1` |

### Set in app.yaml

```yaml
env:
  - name: CATALOG_NAME
    value: "aira_test"
  - name: BRONZE_SCHEMA
    value: "bronze_md"
  - name: SILVER_SCHEMA
    value: "silver_md"
  - name: GOLD_SCHEMA
    value: "gold_md"
  - name: DATABRICKS_WAREHOUSE_ID
    value: "148ccb90800933a1"
```

---

## Troubleshooting

### Error: "Table or view not found"

**Cause:** App service principal doesn't have access to the table.

**Solution:**
```sql
GRANT USE CATALOG ON CATALOG aira_test TO `App - clnl-data-std-mgmt-app`;
GRANT USE SCHEMA ON SCHEMA aira_test.gold_md TO `App - clnl-data-std-mgmt-app`;
GRANT SELECT ON SCHEMA aira_test.gold_md TO `App - clnl-data-std-mgmt-app`;
```

### Error: "DATABRICKS_WAREHOUSE_ID not set"

**Cause:** Environment variable not configured.

**Solution:** Check `app.yaml` has the warehouse ID set.

### Error: "Authentication failed"

**Cause:** App not running in Databricks or credentials missing.

**Solution:** Ensure app is deployed to Databricks Apps (not running locally).

### Finding the App Service Principal Name

1. Go to **Compute** → **Apps** in Databricks
2. Click on your app
3. Look for **Service Principal** in settings
4. Format is usually: `App - <app-name>`

---

## Security Best Practices

1. **Principle of Least Privilege**: Grant only necessary permissions
2. **Use OBO for Production**: Enables per-user audit trails
3. **Regular Permission Audits**: Review grants periodically
4. **Separate Environments**: Use different catalogs for dev/test/prod
5. **Rotate Credentials**: Regularly rotate service principal secrets
6. **Enable Audit Logging**: Track all data access operations

---

## Related Documentation

- [04_versioning_design.readme.md](./04_versioning_design.readme.md) - Version management
- [02_dta_approval_design.readme.md](./02_dta_approval_design.readme.md) - Approval workflow
- [Databricks Unity Catalog Documentation](https://docs.databricks.com/data-governance/unity-catalog/index.html)
- [Databricks Apps Authentication](https://docs.databricks.com/dev-tools/databricks-apps/index.html)


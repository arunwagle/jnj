# Build and Deploy Guide

## Overview

This project packages the `{{.usecase}}_framework` as a Python wheel (`.whl`) file and automatically distributes it to all worker nodes during job execution. This ensures that streaming jobs and distributed processing have access to the ConfigManager and other framework utilities.

---

## Build Process

### Automatic Build (Recommended)

Databricks Asset Bundles automatically builds the wheel during deployment:

```bash
# Validate and build
databricks bundle validate --target dev

# Deploy (builds wheel automatically)
databricks bundle deploy --target dev
```

**What happens:**
1. DAB reads `databricks.yml` and finds the `artifacts` section
2. Runs `python setup.py bdist_wheel` to build the wheel
3. Uploads wheel to Databricks workspace
4. Attaches wheel to all job clusters automatically

### Manual Build (For Testing)

To build the wheel locally for testing:

```bash
# Install build tools
pip install build wheel

# Build the wheel
python setup.py bdist_wheel

# Output: dist/{{.usecase}}_framework-0.0.1+<timestamp>-py3-none-any.whl
```

The wheel file will be created in the `dist/` directory.

---

## Configuration in `databricks.yml`

### Artifacts Section

```yaml
artifacts:
  {{.usecase}}_framework:
    type: whl
    path: .
```

This tells DAB to:
- Build a wheel artifact named `{{.usecase}}_framework`
- Use the current directory (`.`) as the source
- Look for `setup.py` to build the wheel

### Job Configuration

Jobs automatically reference the wheel through the `libraries` section:

```yaml
resources:
  jobs:
    my_job:
      tasks:
        - task_key: my_task
          notebook_task:
            notebook_path: notebooks/my_notebook.ipynb
          job_cluster_key: main_cluster
          libraries:
            - whl: ../../../dist/*.whl  # ← Wheel distributed to all nodes
```

---

## What Gets Packaged

The wheel includes all Python modules under `src/`:

```
{{.usecase}}_framework-0.0.1+<timestamp>-py3-none-any.whl
└── {{.usecase}}_framework/
    ├── __init__.py
    ├── config_manager.py      # ← ConfigManager API
    ├── dlt_utils.py           # ← DLT utilities
    ├── utils.py               # ← Common utilities
    └── ...
```

### Dependencies Included

From `setup.py`:
```python
install_requires=[
    "setuptools",
    "pyyaml>=6.0",  # For ConfigManager
]
```

---

## How It Works in Streaming Jobs

### 1. **Build Phase** (Deploy Time)
```bash
databricks bundle deploy --target dev
```

```
Local → Build Wheel → Upload to DBFS → Register in Job Config
```

### 2. **Runtime Phase** (Job Execution)
```
Driver Node:
  ├── Downloads wheel from DBFS
  ├── Installs to Python environment
  └── Broadcasts to worker nodes

Worker Nodes:
  ├── Receive wheel from driver
  ├── Install to local Python environment
  └── Ready to import {{.usecase}}_framework
```

### 3. **Usage in Notebooks**
```python
# Import works on all nodes (driver + workers)
from {{.usecase}}_framework.config_manager import ConfigManager

# ConfigManager available on all workers
config = ConfigManager("config/my_config.yaml", target="dev")
```

---

## Versioning

### Automatic Versioning

The wheel uses dynamic versioning with timestamps:

```python
# setup.py
local_version = datetime.datetime.utcnow().strftime("%Y%m%d.%H%M%S")
version = "0.0.1+" + local_version
```

**Example:**
```
{{.usecase}}_framework-0.0.1+20250124.143022-py3-none-any.whl
                              ^^^^^^^^^^^^^^^^
                              Timestamp: Jan 24, 2025 14:30:22 UTC
```

**Benefits:**
- ✅ Every build has a unique version
- ✅ No version conflicts
- ✅ Easy to track deployments

### Custom Versioning

To use semantic versioning:

```python
# setup.py - Update version
version = "1.0.0"  # Remove timestamp
```

---

## Testing the Build Locally

### Step 1: Build the Wheel
```bash
cd {{.project_name}}
python setup.py bdist_wheel
```

### Step 2: Install Locally
```bash
pip install dist/{{.usecase}}_framework-*.whl
```

### Step 3: Test Import
```python
from {{.usecase}}_framework.config_manager import ConfigManager

config = ConfigManager("config/example_config.yaml", target="dev")
print("✅ Import successful!")
```

### Step 4: Uninstall
```bash
pip uninstall {{.usecase}}_framework -y
```

---

## Common Issues and Solutions

### Issue 1: Import Errors in Streaming Jobs

**Problem:**
```
ModuleNotFoundError: No module named '{{.usecase}}_framework'
```

**Solution:**
Ensure the wheel is referenced in job configuration:

```yaml
libraries:
  - whl: ../../../dist/*.whl  # Correct path
```

### Issue 2: ConfigManager Can't Find YAML

**Problem:**
```
FileNotFoundError: Configuration file not found: config/my_config.yaml
```

**Solution:**
Use absolute paths or workspace-relative paths:

```python
# Option 1: Workspace-relative path (recommended)
config_path = f"/Workspace{os.getcwd()}/config/my_config.yaml"

# Option 2: Pass absolute path from job parameters
config_path = dbutils.widgets.get("config_path")
config_path = f"/Workspace/Users/{user_email}/{project_name}/config/my_config.yaml"
```

### Issue 3: Wheel Not Updated After Changes

**Problem:**
Code changes not reflected in deployed job.

**Solution:**
```bash
# Redeploy to rebuild and upload new wheel
databricks bundle deploy --target dev --force
```

### Issue 4: PyYAML Dependency Conflicts

**Problem:**
```
ERROR: Cannot install pyyaml==6.0 (conflicts with existing)
```

**Solution:**
Update `setup.py` to use compatible version range:

```python
install_requires=[
    "pyyaml>=5.1,<7.0",  # More flexible version range
]
```

---

## Best Practices

### 1. **Always Redeploy After Framework Changes**
```bash
# Make changes to src/{{.usecase}}_framework/
# Then redeploy to rebuild wheel
databricks bundle deploy --target dev
```

### 2. **Use Validation Before Deployment**
```bash
databricks bundle validate --target dev
# Fix any errors
databricks bundle deploy --target dev
```

### 3. **Version Control**
```bash
# Add to .gitignore
dist/
build/
*.egg-info/
__pycache__/
```

### 4. **Environment-Specific Dependencies**
For different environments, use target-specific overrides:

```yaml
targets:
  dev:
    # Dev-specific settings
  
  prod:
    # Prod-specific settings
    artifacts:
      {{.usecase}}_framework:
        type: whl
        path: .
        # Can override build settings per environment
```

---

## Advanced: Custom Build Script

Create `build.sh` for local development:

```bash
#!/bin/bash
# build.sh - Build and test wheel locally

set -e

echo "🔨 Building wheel..."
python setup.py bdist_wheel

echo "📦 Wheel created:"
ls -lh dist/*.whl

echo "✅ Build complete!"
echo ""
echo "To install locally:"
echo "  pip install dist/{{.usecase}}_framework-*.whl"
```

Make executable:
```bash
chmod +x build.sh
./build.sh
```

---

## Monitoring

### Check Wheel Installation in Job Logs

When your job runs, look for:

```
Installing wheel: {{.usecase}}_framework-0.0.1+20250124.143022-py3-none-any.whl
Successfully installed {{.usecase}}_framework-0.0.1+20250124.143022
```

### Verify in Notebook

```python
# Check installed packages
import pkg_resources
installed = {pkg.key: pkg.version for pkg in pkg_resources.working_set}
print(f"{{.usecase}}_framework version: {installed.get('{{.usecase}}-framework', 'NOT INSTALLED')}")
```

---

## Summary

| Step | Command | What It Does |
|------|---------|--------------|
| **Validate** | `databricks bundle validate` | Checks configuration |
| **Build** | `python setup.py bdist_wheel` | Creates wheel locally |
| **Deploy** | `databricks bundle deploy` | Builds + uploads + configures |
| **Test** | `pip install dist/*.whl` | Test wheel locally |

The build process is **fully automated** with DAB - just deploy and your framework code is distributed to all worker nodes! 🚀

---

## Questions?

- See `setup.py` for package configuration
- See `databricks.yml` for artifact configuration
- See `src/{{.usecase}}_framework/README_CONFIG_MANAGER.md` for API documentation


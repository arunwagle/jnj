# clinical-data-standards

Databricks Asset Bundle project for JNJ.

## Project Overview

- **Use Case**: `clinical_data_standards`
- **Framework Package**: `clinical_data_standards_framework`
- **Unity Catalog**: `dta_poc`
- **Cloud Provider**: Azure
- **Workspace**: https://dbc-70edafc8-39e8.cloud.databricks.com

## Architecture

This project uses a **modular component architecture**:

1. **Base Infrastructure** (this project) - Provides foundational setup:
   - Unity Catalog and schema definitions
   - Global variables and configurations
   - Deployment targets (dev/staging/prod)
   - Basic Python framework structure
   - Utility scripts for component management

2. **Add Components as Needed**:
   - **Data Engineering**: DLT Pipelines, Jobs, ConfigManager
   - **Databricks Apps**: Flask, Streamlit, Gradio, Dash
   - **ML Resources**: Model Serving Endpoints

## Components

Currently, this is a **base infrastructure project** with no active resources.

To add components, use the `databricks bundle init` command with component templates:

### Add Data Engineering Resources

```bash
databricks bundle init <path-to>/dab-components/add-data --config-file <path-to>/config-data-autoloader.json
```

### Add Databricks Apps

```bash
databricks bundle init <path-to>/dab-components/add-app --config-file <path-to>/config-sample-streamlit.json
```

### Add ML Resources

```bash
databricks bundle init <path-to>/dab-components/add-ml --config-file <path-to>/config-add-ml-provisioned.json
```

## Project Structure

```
clinical-data-standards/
├── databricks.yml              # Bundle configuration
├── setup.py                    # Python package setup
├── _update_databricks_yml.sh   # Auto-update script for new components
├── _deploy_app.sh              # App deployment helper
├── src/
│   └── clinical_data_standards_framework/  # Core framework code
├── tests/                      # Unit & integration tests
├── cicd/                       # CI/CD pipeline configs
└── docs/                       # Documentation
```

As you add components, additional folders will be created:
- `notebooks/` - Databricks notebooks (data engineering, ML)
- `apps/` - Databricks Apps source code
- `resources/` - DAB resource definitions (jobs, pipelines, apps, ML endpoints)
- `config/` - Application configuration files

## Quick Start

### Prerequisites

- **Databricks CLI** version 0.250.0 or above
- **Python 3.8+** for local development
- Access to https://dbc-70edafc8-39e8.cloud.databricks.com

### Initial Setup

1. **Validate the Bundle**
   ```bash
   databricks bundle validate
   ```

2. **Deploy Base Infrastructure**
   ```bash
   databricks bundle deploy --target dev
   ```

3. **Add Components** (see examples above)

4. **Update Resource Includes**
   After adding components, run:
   ```bash
   chmod +x _update_databricks_yml.sh
   bash _update_databricks_yml.sh
   ```

5. **Deploy Components**
   ```bash
   databricks bundle deploy --target dev
   ```

## Configuration

Key configuration variables in `databricks.yml`:

| Variable | Description | Default |
|----------|-------------|---------|
| `usecase` | Use case identifier | `clinical_data_standards` |
| `catalog` | Unity Catalog | `dta_poc` |
| `bronze_schema` | Bronze layer schema | `bronze_md` |
| `silver_schema` | Silver layer schema | `silver_md` |
| `gold_schema` | Gold layer schema | `gold_md` |
| `use_serverless` | Use serverless compute | `Y` |

## Deployment Targets

### Development (`dev`)
- Mode: `development`
- Purpose: Active development and testing
- Resources prefixed with `[dev username]`
- Schedules paused by default

### Staging (`staging`)
- Mode: `development`
- Purpose: Pre-production testing
- Catalog: `clinical_data_standards_stg_ctlg`

### Production (`prod`)
- Mode: `production`
- Purpose: Production workloads
- Catalog: `clinical_data_standards_prod_ctlg`
- Runs as service principal or designated user

To deploy to a specific target:
```bash
databricks bundle deploy --target prod
```

## Testing

Run tests locally:
```bash
# Unit tests
pytest tests/

# Integration tests (if added via add-data component)
pytest tests/integration_tests/ -v
```

## CI/CD

See [cicd/README.md](cicd/README.md) for:
- Azure DevOps pipeline setup
- GitHub Actions configuration
- Branch strategies
- Deployment automation

## Troubleshooting

### Common Issues

1. **Bundle validation fails**
   - Check that all required variables are set
   - Verify workspace connectivity: `databricks auth login`

2. **Deployment permission errors**
   - Verify user has CAN_MANAGE permissions
   - Check workspace admin settings

3. **Component addition fails**
   - Ensure you're running `databricks bundle init` from within the project directory
   - Check that component paths are correct
   - Run `_update_databricks_yml.sh` after adding components

4. **App deployment issues**
   - Use `bash _deploy_app.sh <app-name> <target>` for reliable app deployments
   - Check app logs: `databricks apps logs <app-name>-<target>`

## Support

For questions or issues:
- Contact: awagle4@its.jnj.com
- Organization: JNJ
- Documentation: See main repository `docs/` directory

## License

© JNJ - All rights reserved.

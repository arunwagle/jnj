{{- if or (eq .project_type "full") (eq .project_type "data_only") (eq .include_dlt_pipelines "Y")}}
"""
Tests for DLT utilities
"""

import pytest
from {{.usecase}}_framework.dlt_utils import DLTHelper, DataQualityChecker


def test_dlt_helper_config(spark):
    """Test DLT helper configuration"""
    helper = DLTHelper(spark)
    config = helper.get_dlt_config()
    
    assert "catalog" in config
    assert "schema" in config
    assert "pipeline_name" in config


def test_add_metadata_columns(spark, sample_data):
    """Test adding metadata columns"""
    result = DLTHelper.add_metadata_columns(sample_data)
    
    assert "_ingestion_timestamp" in result.columns
    assert "_ingestion_date" in result.columns
    assert "_source_file" in result.columns


def test_data_quality_null_check(spark, sample_data):
    """Test null percentage check"""
    checker = DataQualityChecker()
    
    # All columns should pass (no nulls)
    assert checker.check_null_percentage(sample_data, "id", 0.05) is True


def test_data_quality_range_check(spark, sample_data):
    """Test value range check"""
    checker = DataQualityChecker()
    
    # All amounts should be in range
    assert checker.check_value_range(sample_data, "amount", 0, 300) is True
    
    # Should fail if range is too narrow
    assert checker.check_value_range(sample_data, "amount", 0, 50) is False


def test_data_quality_unique_check(spark, sample_data):
    """Test uniqueness check"""
    checker = DataQualityChecker()
    
    # id column should be unique
    assert checker.check_unique_values(sample_data, ["id"]) is True


def test_quality_metrics(spark, sample_data):
    """Test quality metrics calculation"""
    checker = DataQualityChecker()
    metrics = checker.get_quality_metrics(sample_data)
    
    assert metrics["total_records"] == 3
    assert metrics["column_count"] == 4
    assert "null_counts" in metrics
{{- end}}


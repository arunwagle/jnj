# ConfigManager API Documentation

## Overview

`ConfigManager` is a Python API for loading and managing YAML-based pipeline configurations. It provides simple, type-safe access to pipeline step configurations and service definitions.

## Installation

No installation required - part of the `{{.usecase}}_framework` package.

## Quick Start

```python
from {{.usecase}}_framework.config_manager import ConfigManager

# Initialize
config = ConfigManager(
    config_path="config/sales_data_config.yaml",
    target="dev"
)

# Get a pipeline step
step = config.get_pipeline_step(
    use_case="SALES_DATA_PROCESSING",
    document_type="pdf",
    document_subtype="standard",
    step_name="parse_document"
)

# Get a service
service = config.get_service("document_parser_default")
```

---

## Core API

### 1. `get_pipeline_step()`

Get configuration for a specific pipeline step.

#### Signature
```python
def get_pipeline_step(
    use_case: str,
    document_type: str,
    document_subtype: str,
    step_name: str
) -> Dict[str, Any]
```

#### Parameters
- **`use_case`**: Use case name from config (e.g., `"SALES_DATA_PROCESSING"`)
- **`document_type`**: Document type (e.g., `"pdf"`, `"json"`, `"excel"`)
- **`document_subtype`**: Document subtype (e.g., `"standard"`, `"complex"`)
- **`step_name`**: Step name (e.g., `"parse_document"`, `"extract_entities"`)

#### Returns
Dictionary containing:
- `step`: Step name
- `service`: Service name to use
- All step-specific parameters (source_path, output_table, prompt_template, etc.)
- **Variables resolved** (${globals.*}, ${bundle.target})

#### Example
```python
config = ConfigManager("config/my_config.yaml", target="dev")

step = config.get_pipeline_step(
    use_case="SALES_DATA_PROCESSING",
    document_type="pdf",
    document_subtype="standard",
    step_name="extract_entities"
)

print(step)
# Output:
# {
#     'step': 'extract_entities',
#     'service': 'entity_extractor_default',
#     'prompt_template': 'Extract key entities from...',
#     'input_column': 'text',
#     'output_column': 'extracted_entities',
#     'output_format': 'json',
#     'output_table': 'silver.sales_data_entities'
# }
```

#### Raises
- `ValueError`: If use case, document type, subtype, or step not found

---

### 2. `get_service()`

Get configuration for a specific service.

#### Signature
```python
def get_service(service_name: str) -> Dict[str, Any]
```

#### Parameters
- **`service_name`**: Service name from config (e.g., `"document_parser_default"`, `"entity_extractor_default"`)

#### Returns
Dictionary containing:
- Service type (`document_parsing`, `model_serving`, etc.)
- All service-specific parameters
- **Variables resolved** (${bundle.target}, environment variables)

#### Example
```python
# Get document parser service
parser = config.get_service("document_parser_default")

print(parser)
# Output:
# {
#     'type': 'document_parsing',
#     'engine': 'ai_document_intelligence',
#     'extract_text': True,
#     'extract_tables': True,
#     'extract_images': False,
#     'output_format': 'json',
#     'timeout_seconds': 120,
#     'description': '...'
# }

# Get model serving service
extractor = config.get_service("entity_extractor_default")

print(extractor)
# Output:
# {
#     'type': 'model_serving',
#     'endpoint_name': 'chatbot-endpoint-dev',  # Resolved from ${bundle.target}
#     'max_tokens': 1000,
#     'temperature': 0.1,
#     'timeout_seconds': 90,
#     'retry_attempts': 3,
#     'description': '...'
# }
```

#### Raises
- `ValueError`: If service not found

---

## Helper Methods

### `get_all_steps()`
Get all steps for a pipeline configuration.

```python
steps = config.get_all_steps(
    use_case="SALES_DATA_PROCESSING",
    document_type="pdf",
    document_subtype="standard"
)

for step in steps:
    print(f"Step: {step['step']}, Service: {step.get('service')}")
```

### `get_globals()`
Get global configuration settings.

```python
globals_config = config.get_globals()
print(f"Catalog: {globals_config['catalog']}")
print(f"Bronze Schema: {globals_config['bronze_schema']}")
```

### `list_services()`
List all available service names.

```python
services = config.list_services()
print(f"Available services: {', '.join(services)}")
# Output: Available services: document_parser_default, entity_extractor_default
```

### `list_use_cases()`
List all available use case names.

```python
use_cases = config.list_use_cases()
print(f"Available use cases: {', '.join(use_cases)}")
# Output: Available use cases: SALES_DATA_PROCESSING
```

---

## Variable Substitution

ConfigManager automatically resolves variables in your configuration:

### Supported Patterns

| Pattern | Description | Example |
|---------|-------------|---------|
| `${globals.key}` | From globals section | `${globals.catalog}` → `"main_catalog"` |
| `${bundle.target}` | Deployment target | `${bundle.target}` → `"dev"` |
| `${ENV_VAR}` | Environment variable | `${DB_PASSWORD}` → value from env |

### Example Configuration
```yaml
globals:
  catalog: "main_catalog"
  bronze_schema: "bronze"

services:
  my_service:
    endpoint_name: "my-endpoint-${bundle.target}"  # Resolves to "my-endpoint-dev"
    
pipelines:
  MY_PIPELINE:
    pdf:
      standard:
        steps:
          - step: "ingest"
            output_table: "${globals.bronze_schema}.raw_data"  # Resolves to "bronze.raw_data"
```

---

## Usage in Notebooks

### Pattern 1: Single Step Execution

```python
# Databricks notebook - receives parameters from job
config_path = dbutils.widgets.get("config_path")
use_case = dbutils.widgets.get("use_case")
document_type = dbutils.widgets.get("document_type")
document_subtype = dbutils.widgets.get("document_subtype")
step_name = dbutils.widgets.get("step_name")

# Load configurations
config = ConfigManager(config_path, target="dev")

# Get step configuration
step_config = config.get_pipeline_step(
    use_case=use_case,
    document_type=document_type,
    document_subtype=document_subtype,
    step_name=step_name
)

# Get service configuration
service_name = step_config["service"]
service_config = config.get_service(service_name)

# Process based on service type
if service_config["type"] == "document_parsing":
    # Parse document
    result = parse_document(
        source_path=step_config["source_path"],
        engine=service_config["engine"],
        extract_tables=service_config["extract_tables"]
    )
    
elif service_config["type"] == "model_serving":
    # Call model serving endpoint
    result = call_llm(
        endpoint=service_config["endpoint_name"],
        prompt=step_config["prompt_template"],
        max_tokens=service_config["max_tokens"]
    )
```

### Pattern 2: Pipeline Execution (All Steps)

```python
# Load config
config = ConfigManager("config/my_config.yaml", target="dev")

# Get all steps
steps = config.get_all_steps(
    use_case="DOCUMENT_PROCESSING",
    document_type="pdf",
    document_subtype="standard"
)

# Execute each step sequentially
for step in steps:
    step_name = step["step"]
    service_name = step.get("service")
    
    if service_name:
        service_config = config.get_service(service_name)
        print(f"Executing: {step_name} using {service_name}")
        
        # Execute step...
```

---

## Error Handling

ConfigManager raises descriptive `ValueError` exceptions:

```python
try:
    step = config.get_pipeline_step(
        use_case="INVALID_CASE",
        document_type="pdf",
        document_subtype="standard",
        step_name="parse"
    )
except ValueError as e:
    print(f"Error: {e}")
    # Output: Error: Use case 'INVALID_CASE' not found in configuration

try:
    service = config.get_service("non_existent_service")
except ValueError as e:
    print(f"Error: {e}")
    # Output: Error: Service 'non_existent_service' not found. Available services: ...
```

---

## Configuration Structure

Your YAML configuration should follow this structure:

```yaml
globals:
  spark_app_name: "..."
  catalog: "..."
  bronze_schema: "..."
  silver_schema: "..."
  gold_schema: "..."

services:
  service_name:
    type: "..."
    # ... service parameters

pipelines:
  USE_CASE:
    document_type:
      document_subtype:
        description: "..."
        steps:
          - step: "step_name"
            service: "service_name"
            # ... step parameters
```

---

## Examples

See `config_manager_example.py` for complete usage examples:

- Basic API usage
- Notebook processing pattern
- Error handling
- All helper methods

Run examples:
```bash
python src/{{.usecase}}_framework/config_manager_example.py
```

---

## Best Practices

1. **Initialize once** - Create ConfigManager instance at notebook start
2. **Use helper methods** - Leverage `list_services()`, `list_use_cases()` for validation
3. **Handle errors** - Always wrap API calls in try-except blocks
4. **Validate configs** - ConfigManager validates structure on initialization
5. **Use variables** - Leverage `${globals.*}` for DRY configurations

---

## Questions?

See the main project documentation or configuration examples:
- `config/examples/complete_example_config.yaml`
- `config/examples/README.md`


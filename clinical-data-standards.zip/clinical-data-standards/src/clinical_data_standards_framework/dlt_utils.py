{{- if or (eq .project_type "full") (eq .project_type "data_only") (eq .include_dlt_pipelines "Y")}}
"""
Delta Live Tables utilities for {{.project_name}}
"""

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from typing import Dict, List, Optional, Callable
import logging


class DLTHelper:
    """Helper class for DLT operations"""
    
    def __init__(self, spark):
        self.spark = spark
        self.logger = logging.getLogger(__name__)
    
    def get_dlt_config(self) -> Dict[str, str]:
        """Get DLT pipeline configuration from Spark conf"""
        return {
            "catalog": self.spark.conf.get("catalog", "{{.catalog_name}}"),
            "schema": self.spark.conf.get("schema", "{{.bronze_schema}}"),
            "target_schema": self.spark.conf.get("target_schema", "{{.silver_schema}}"),
            "pipeline_name": self.spark.conf.get("pipeline_name", ""),
            "table_suffix": self.spark.conf.get("table_suffix", "")
        }
    
    @staticmethod
    def add_metadata_columns(df: DataFrame) -> DataFrame:
        """Add standard metadata columns to DataFrame"""
        return df \
            .withColumn("_ingestion_timestamp", F.current_timestamp()) \
            .withColumn("_ingestion_date", F.current_date()) \
            .withColumn("_source_file", F.input_file_name())
    
    @staticmethod
    def apply_data_quality_rules(
        df: DataFrame,
        rules: Dict[str, str]
    ) -> DataFrame:
        """
        Apply data quality rules to DataFrame
        
        Args:
            df: Input DataFrame
            rules: Dictionary of rule_name -> condition
            
        Returns:
            DataFrame with quality rules applied
        """
        for rule_name, condition in rules.items():
            df = df.filter(F.expr(condition))
        return df


class DataQualityChecker:
    """Data quality checking utilities"""
    
    @staticmethod
    def check_null_percentage(
        df: DataFrame,
        column: str,
        max_null_percentage: float = 0.05
    ) -> bool:
        """
        Check if null percentage is below threshold
        
        Args:
            df: DataFrame to check
            column: Column name
            max_null_percentage: Maximum allowed null percentage
            
        Returns:
            True if null percentage is acceptable
        """
        total_count = df.count()
        null_count = df.filter(F.col(column).isNull()).count()
        null_percentage = null_count / total_count if total_count > 0 else 0
        
        return null_percentage <= max_null_percentage
    
    @staticmethod
    def check_value_range(
        df: DataFrame,
        column: str,
        min_value: float,
        max_value: float
    ) -> bool:
        """
        Check if all values are within specified range
        
        Args:
            df: DataFrame to check
            column: Column name
            min_value: Minimum allowed value
            max_value: Maximum allowed value
            
        Returns:
            True if all values are in range
        """
        out_of_range = df.filter(
            (F.col(column) < min_value) | (F.col(column) > max_value)
        ).count()
        
        return out_of_range == 0
    
    @staticmethod
    def check_unique_values(
        df: DataFrame,
        columns: List[str]
    ) -> bool:
        """
        Check if combination of columns is unique
        
        Args:
            df: DataFrame to check
            columns: List of column names
            
        Returns:
            True if combination is unique
        """
        total_count = df.count()
        unique_count = df.select(columns).distinct().count()
        
        return total_count == unique_count
    
    @staticmethod
    def get_quality_metrics(df: DataFrame) -> Dict:
        """
        Calculate data quality metrics
        
        Args:
            df: DataFrame to analyze
            
        Returns:
            Dictionary with quality metrics
        """
        total_count = df.count()
        
        metrics = {
            "total_records": total_count,
            "column_count": len(df.columns),
            "null_counts": {}
        }
        
        for column in df.columns:
            null_count = df.filter(F.col(column).isNull()).count()
            metrics["null_counts"][column] = {
                "count": null_count,
                "percentage": null_count / total_count if total_count > 0 else 0
            }
        
        return metrics


def create_scd_type2_table(
    target_table: str,
    source_df: DataFrame,
    keys: List[str],
    sequence_by: str,
    stored_as_scd_type: int = 2
) -> None:
    """
    Helper to create SCD Type 2 table configuration
    
    Args:
        target_table: Target table name
        source_df: Source DataFrame
        keys: Key columns for matching
        sequence_by: Column to sequence by
        stored_as_scd_type: SCD type (1 or 2)
    """
    # This is a helper for documentation
    # Actual DLT apply_changes is used in notebooks
    pass
{{- end}}


{{- if or (eq .project_type "full") (eq .project_type "data_only") (eq .include_dlt_pipelines "Y")}}
"""
Common utilities for {{.project_name}}
"""

from pyspark.sql import SparkSession
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from typing import Dict, List, Optional
import logging


def get_spark_session(app_name: str = "{{.project_name}}") -> SparkSession:
    """
    Get or create Spark session
    
    Args:
        app_name: Name for the Spark application
        
    Returns:
        SparkSession instance
    """
    return SparkSession.builder.appName(app_name).getOrCreate()


def get_catalog_config(spark: SparkSession) -> Dict[str, str]:
    """
    Get catalog configuration from Spark conf
    
    Args:
        spark: SparkSession instance
        
    Returns:
        Dictionary with catalog configuration
    """
    return {
        "catalog": spark.conf.get("catalog", "{{.catalog_name}}"),
        "bronze_schema": spark.conf.get("bronze_schema", "{{.bronze_schema}}"),
        "silver_schema": spark.conf.get("silver_schema", "{{.silver_schema}}"),
        "gold_schema": spark.conf.get("gold_schema", "{{.gold_schema}}"),
        "table_suffix": spark.conf.get("table_suffix", "")
    }


def setup_logging(name: str = "{{.usecase}}") -> logging.Logger:
    """
    Setup logging configuration
    
    Args:
        name: Logger name
        
    Returns:
        Configured logger instance
    """
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    return logging.getLogger(name)


def add_audit_columns(df: DataFrame) -> DataFrame:
    """
    Add standard audit columns to DataFrame
    
    Args:
        df: Input DataFrame
        
    Returns:
        DataFrame with audit columns added
    """
    return df.withColumn("_processing_timestamp", F.current_timestamp()) \
             .withColumn("_processing_date", F.current_date())


def validate_schema(df: DataFrame, required_columns: List[str]) -> bool:
    """
    Validate that DataFrame has required columns
    
    Args:
        df: DataFrame to validate
        required_columns: List of required column names
        
    Returns:
        True if all required columns are present
        
    Raises:
        ValueError: If required columns are missing
    """
    df_columns = set(df.columns)
    missing = set(required_columns) - df_columns
    
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    
    return True


def write_table(
    df: DataFrame,
    catalog: str,
    schema: str,
    table: str,
    mode: str = "append",
    partition_by: Optional[List[str]] = None
) -> None:
    """
    Write DataFrame to Unity Catalog table
    
    Args:
        df: DataFrame to write
        catalog: Catalog name
        schema: Schema name
        table: Table name
        mode: Write mode (append, overwrite, etc.)
        partition_by: Optional list of columns to partition by
    """
    full_table_name = f"{catalog}.{schema}.{table}"
    
    writer = df.write.mode(mode).format("delta")
    
    if partition_by:
        writer = writer.partitionBy(*partition_by)
    
    writer.saveAsTable(full_table_name)
    
    logging.info(f"Successfully wrote to {full_table_name}")


def read_table(
    spark: SparkSession,
    catalog: str,
    schema: str,
    table: str
) -> DataFrame:
    """
    Read table from Unity Catalog
    
    Args:
        spark: SparkSession instance
        catalog: Catalog name
        schema: Schema name
        table: Table name
        
    Returns:
        DataFrame with table data
    """
    full_table_name = f"{catalog}.{schema}.{table}"
    return spark.table(full_table_name)


def optimize_table(
    spark: SparkSession,
    catalog: str,
    schema: str,
    table: str,
    zorder_by: Optional[List[str]] = None
) -> None:
    """
    Optimize Delta table
    
    Args:
        spark: SparkSession instance
        catalog: Catalog name
        schema: Schema name
        table: Table name
        zorder_by: Optional columns to Z-ORDER by
    """
    full_table_name = f"{catalog}.{schema}.{table}"
    
    optimize_sql = f"OPTIMIZE {full_table_name}"
    if zorder_by:
        zorder_cols = ", ".join(zorder_by)
        optimize_sql += f" ZORDER BY ({zorder_cols})"
    
    spark.sql(optimize_sql)
    logging.info(f"Optimized {full_table_name}")
{{- end}}


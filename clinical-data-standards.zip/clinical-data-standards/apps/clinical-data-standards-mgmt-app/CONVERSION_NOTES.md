# Converting flask App to Databricks Apps

This guide provides framework-specific conversion steps for migrating your existing flask app to Databricks Apps.

## Source App
- **Path**: /Users/arun.wagle/Databricks/Clients/2025/JNJ/DTA_POC/code/mocks/dta_flask_mock
- **Main File**: app.py
- **Framework**: flask

## Key Changes Required

### 1. Database Connections → Databricks SQL

**Before:**
```python
import psycopg2  # or mysql.connector, etc.
conn = psycopg2.connect(host="...", database="...", user="...", password="...")
```

**After:**
```python
from databricks import sql
import os

def get_connection():
    return sql.connect(
        server_hostname=os.getenv("DATABRICKS_SERVER_HOSTNAME"),
        http_path=os.getenv("DATABRICKS_HTTP_PATH"),
        access_token=os.getenv("DATABRICKS_TOKEN")
    )
```

### 2. File Paths → UC Volumes

**Before:**
```python
with open("/local/path/to/file.csv") as f:
    data = f.read()
```

**After:**
```python
# Use Unity Catalog Volumes
VOLUME_PATH = "/Volumes/dta_poc/gold_md/my_volume"
with open(f"{VOLUME_PATH}/file.csv") as f:
    data = f.read()
```

### 3. Environment Variables

**Before:**
```python
DATABASE_URL = os.getenv("DATABASE_URL")
API_KEY = os.getenv("API_KEY")
```

**After:**
```python
# Databricks Apps automatically provides:
DATABRICKS_HOST = os.getenv("DATABRICKS_SERVER_HOSTNAME")
DATABRICKS_HTTP_PATH = os.getenv("DATABRICKS_HTTP_PATH")
DATABRICKS_TOKEN = os.getenv("DATABRICKS_TOKEN")

# For custom variables, set in app.yaml:
API_KEY = os.getenv("API_KEY")  # Configured in app.yaml
```

## Flask-Specific Changes

### Update app.py

**Before:**
```python
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
```

**After:**
```python
if __name__ == "__main__":
    # Databricks Apps handles port configuration
    app.run(host="0.0.0.0", port=8000)
```

### Database Queries

**Before:**
```python
cursor = conn.cursor()
cursor.execute("SELECT * FROM my_table")
results = cursor.fetchall()
```

**After:**
```python
with get_connection() as conn:
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM dta_poc.gold_md.my_table")
        results = cursor.fetchall()
```

### Static Files

**Before:**
```python
app = Flask(__name__, static_folder='static', template_folder='templates')
```

**After:**
```python
# Keep the same, but ensure files are in the app directory
app = Flask(__name__, static_folder='static', template_folder='templates')
```

## Configuration Files

### app.yaml
The `app.yaml` file has been created with basic configuration. Update as needed:

```yaml
command: ["python", "app.py"]
env:
  - name: CATALOG_NAME
    value: "dta_poc"
  - name: GOLD_SCHEMA
    value: "gold_md"
  # Add more environment variables as needed
```

### requirements.txt
Your existing requirements have been merged with Databricks dependencies:
- `databricks-sql-connector` - For Databricks SQL connections
- Framework-specific packages (flask)

Review and add any missing dependencies.

## Testing Locally

1. **Set environment variables:**
```bash
export DATABRICKS_SERVER_HOSTNAME="https://dbc-70edafc8-39e8.cloud.databricks.com"
export DATABRICKS_HTTP_PATH="/sql/1.0/warehouses/your-warehouse-id"
export DATABRICKS_TOKEN="your-personal-access-token"
```

2. **Install dependencies:**
```bash
cd apps/clinical-data-standards-mgmt-app
pip install -r requirements.txt
```

3. **Run the app:**
```bash
python app.py
```

4. **Test in browser:**
Visit `http://localhost:8000`

## Deployment

1. **Validate:**
```bash
databricks bundle validate
```

2. **Deploy:**
```bash
databricks bundle deploy --target dev
```

3. **Run:**
```bash
databricks bundle run clinical-data-standards-mgmt-app
```

## Common Issues

### "Connection refused"
- Ensure warehouse is running
- Verify `DATABRICKS_HTTP_PATH` is correct
- Check token permissions

### "Table not found"
- Use fully qualified names: `catalog.schema.table`
- Verify Unity Catalog permissions
- Check catalog/schema names in queries

### "Module not found"
- Add missing packages to `requirements.txt`
- Redeploy after updating requirements

### "Port already in use"
- Change port in app code to 8000
- Kill process using the port: `lsof -ti:8000 | xargs kill`

## Next Steps

1. ✅ Copy your app files (run `_copy_existing_app.sh`)
2. ⏳ Update database connections to use Databricks SQL
3. ⏳ Replace file paths with UC Volumes
4. ⏳ Test locally
5. ⏳ Deploy to Databricks

## Resources

- [Databricks Apps Documentation](https://docs.databricks.com/en/dev-tools/bundles/apps-tutorial.html)
- [Databricks SQL Connector](https://docs.databricks.com/en/dev-tools/python-sql-connector.html)
- [Unity Catalog Volumes](https://docs.databricks.com/en/connect/unity-catalog/volumes.html)


# PDF Parser - UI Flow Design Document

## 📱 Application Overview

**Type:** Databricks Web Application  
**Purpose:** Upload and parse PDF documents, extract sections and tables, view results  
**Backend:** Flask API (api.py)  
**Frontend:** Streamlit/Dash/Gradio on Databricks

> **📐 Visual Diagrams:** All screens and flows have been created as draw.io diagrams.  
> **Location:** `/diagrams/` folder  
> **View:** See [diagrams/README.md](./diagrams/README.md) for details on opening and viewing all mockups.

---

## 🎨 UI Flow Diagram

**📊 Interactive Diagram:** See `diagrams/01_UI_Flow_Diagram.drawio`

```
┌─────────────────┐
│   Screen 1:     │
│  Landing/Upload │──────┐
└─────────────────┘      │
         │               │
         │ Upload PDF    │
         ↓               │
┌─────────────────┐      │
│   Screen 2:     │      │ View History
│  Configuration  │      │
└─────────────────┘      │
         │               │
         │ Start Process │
         ↓               │
┌─────────────────┐      │
│   Screen 3:     │      │
│   Processing    │◄─────┘
│   (Progress)    │
└─────────────────┘
         │
         │ Complete
         ↓
┌─────────────────┐
│   Screen 4:     │
│    Results      │
│   Dashboard     │
└─────────────────┘
         │
         ├──→ View Section Details
         ├──→ View Tables
         └──→ Export Data
```

---

## 📺 Screen Designs

### Screen 1: Landing / Upload Page

**📊 Interactive Mockup:** See `diagrams/02_Screen1_Landing_Upload.drawio`

#### Visual Layout
```
╔════════════════════════════════════════════════════════════╗
║  PDF Document Parser                    [User Icon] Profile ║
╠════════════════════════════════════════════════════════════╣
║                                                            ║
║  📁 Upload PDF Document                                    ║
║  ┌────────────────────────────────────────────────────┐   ║
║  │                                                     │   ║
║  │         Drag and drop PDF file here                │   ║
║  │                    or                              │   ║
║  │              [Browse Files]                        │   ║
║  │                                                     │   ║
║  │         Supported: PDF (Max 50MB)                  │   ║
║  └────────────────────────────────────────────────────┘   ║
║                                                            ║
║  📂 Recent Documents                        [View All →]   ║
║  ┌────────────────────────────────────────────────────┐   ║
║  │ Protocol_64007957.pdf         Today 2:30 PM   ✓   │   ║
║  │ 211 pages • 15 sections • 23 tables                │   ║
║  │                                         [View Results]│   ║
║  ├────────────────────────────────────────────────────┤   ║
║  │ Clinical_Study_2024.pdf      Yesterday 4:15 PM ✓   │   ║
║  │ 156 pages • 12 sections • 18 tables                │   ║
║  │                                         [View Results]│   ║
║  ├────────────────────────────────────────────────────┤   ║
║  │ Amendment_Protocol.pdf       Dec 15 ⏳ Processing  │   ║
║  │ 89 pages • Estimated 5-10 min                      │   ║
║  │                                         [View Status]│   ║
║  └────────────────────────────────────────────────────┘   ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

#### User Interactions
1. **Upload PDF**
   - Drag & drop file or click Browse
   - File validation (size, type)
   - Auto-advance to Configuration screen

2. **View Recent Documents**
   - Click on any document to see results
   - View processing status
   - Re-process option

#### API Calls

**1. Upload File**
```
POST /api/upload
Content-Type: multipart/form-data

Body:
{
  "file": <PDF binary>,
  "filename": "Protocol_64007957.pdf"
}

Response 200:
{
  "file_id": "abc123",
  "filename": "Protocol_64007957.pdf",
  "size_bytes": 2699519,
  "upload_path": "/Volumes/aira/jnj/dta_usecase/upload/abc123.pdf",
  "status": "uploaded"
}

Response 400:
{
  "error": "File too large. Maximum size is 50MB"
}
```

**2. Get Recent Documents**
```
GET /api/documents?limit=10&status=all

Response 200:
{
  "documents": [
    {
      "file_id": "abc123",
      "filename": "Protocol_64007957.pdf",
      "upload_timestamp": "2024-11-18T14:30:00Z",
      "status": "completed",
      "page_count": 211,
      "section_count": 15,
      "table_count": 23
    },
    ...
  ]
}
```

#### State Transitions
- **Initial:** Empty upload area
- **File Selected:** Show file name and size, enable "Configure" button
- **Uploading:** Show progress bar
- **Uploaded:** Auto-redirect to Configuration screen

---

### Screen 2: Configuration

**📊 Interactive Mockup:** See `diagrams/03_Screen2_Configuration.drawio`

#### Visual Layout
```
╔════════════════════════════════════════════════════════════╗
║  ← Back to Upload               PDF Document Parser        ║
╠════════════════════════════════════════════════════════════╣
║                                                            ║
║  📄 Document: Protocol_64007957.pdf                        ║
║      Size: 2.6 MB • Pages: 211                            ║
║                                                            ║
║  ⚙️ Processing Configuration                               ║
║                                                            ║
║  Parsing Strategy                                          ║
║  ┌────────────────────────────────────────────────────┐   ║
║  │ ⦿ Fast (Recommended)                              │   ║
║  │   • Quick processing (~30s per 100 pages)          │   ║
║  │   • Good accuracy for most documents               │   ║
║  │   • No dependency issues                           │   ║
║  │                                                     │   ║
║  │ ○ High Resolution                                  │   ║
║  │   • Best accuracy (~2min per 100 pages)            │   ║
║  │   • Uses AI models for better detection            │   ║
║  │   • Requires additional setup                      │   ║
║  └────────────────────────────────────────────────────┘   ║
║                                                            ║
║  Table Extraction                                          ║
║  ┌────────────────────────────────────────────────────┐   ║
║  │ ☑ Extract tables from document                     │   ║
║  │ ☑ Save tables in separate files (HTML + JSON)     │   ║
║  └────────────────────────────────────────────────────┘   ║
║                                                            ║
║  Output Settings                                           ║
║  ┌────────────────────────────────────────────────────┐   ║
║  │ Catalog:  [aira           ▼]                       │   ║
║  │ Schema:   [jnj            ▼]                       │   ║
║  │ Volume:   [dta_usecase    ▼]                       │   ║
║  └────────────────────────────────────────────────────┘   ║
║                                                            ║
║  Estimated Processing Time: ~2-3 minutes                   ║
║                                                            ║
║                  [Cancel]        [Start Processing]        ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

#### User Interactions
1. **Select Strategy**
   - Radio button selection
   - Shows description and trade-offs
   - Updates estimated time

2. **Configure Table Extraction**
   - Toggle checkboxes
   - Enable/disable options

3. **Set Output Location**
   - Dropdown selection for catalog/schema/volume
   - Shows available options from Unity Catalog

4. **Start Processing**
   - Validates configuration
   - Initiates parsing
   - Redirects to Processing screen

#### API Calls

**1. Get Available Catalogs**
```
GET /api/catalogs

Response 200:
{
  "catalogs": [
    {"name": "aira", "schemas": ["jnj", "test"]},
    {"name": "main", "schemas": ["default"]}
  ]
}
```

**2. Get Volumes for Schema**
```
GET /api/volumes?catalog=aira&schema=jnj

Response 200:
{
  "volumes": [
    "dta_usecase",
    "clinical_data",
    "test_data"
  ]
}
```

**3. Start Processing**
```
POST /api/process

Body:
{
  "file_id": "abc123",
  "config": {
    "strategy": "fast",
    "extract_tables": true,
    "save_tables_separately": true,
    "output": {
      "catalog": "aira",
      "schema": "jnj",
      "volume": "dta_usecase"
    }
  }
}

Response 200:
{
  "job_id": "job_xyz789",
  "status": "started",
  "estimated_duration_sec": 120
}

Response 400:
{
  "error": "Invalid catalog configuration"
}
```

#### State Transitions
- **Initial:** Show uploaded file info, default config
- **Configuring:** User modifies settings, estimate updates
- **Validating:** Check config validity (show errors if any)
- **Starting:** Disable form, show "Starting..." message
- **Started:** Redirect to Processing screen

---

### Screen 3: Processing / Progress

**📊 Interactive Mockup:** See `diagrams/04_Screen3_Processing.drawio`

#### Visual Layout
```
╔════════════════════════════════════════════════════════════╗
║  PDF Document Parser                                       ║
╠════════════════════════════════════════════════════════════╣
║                                                            ║
║  🔄 Processing: Protocol_64007957.pdf                      ║
║                                                            ║
║  Overall Progress                                          ║
║  ████████████████████░░░░░░ 68%                           ║
║  Estimated time remaining: 45 seconds                      ║
║                                                            ║
║  ┌────────────────────────────────────────────────────┐   ║
║  │  Current Stage: Extracting Tables                  │   ║
║  │                                                     │   ║
║  │  ✓ File loaded (211 pages)                         │   ║
║  │  ✓ PDF partitioned (1,245 elements)                │   ║
║  │  ✓ Sections identified (15 sections)               │   ║
║  │  ⚙️ Extracting tables (18/23 complete)             │   ║
║  │  ⏳ Saving to volumes (pending)                     │   ║
║  │  ⏳ Updating catalog (pending)                      │   ║
║  └────────────────────────────────────────────────────┘   ║
║                                                            ║
║  📊 Live Statistics                                        ║
║  ┌──────────────┬──────────────┬──────────────┐          ║
║  │  Sections    │    Tables    │   Elements   │          ║
║  │      15      │      23      │    1,245     │          ║
║  └──────────────┴──────────────┴──────────────┘          ║
║                                                            ║
║  📝 Processing Log                      [Show Details ▼]  ║
║  ┌────────────────────────────────────────────────────┐   ║
║  │  14:32:15  Starting PDF partition...               │   ║
║  │  14:32:45  Extracted 1,245 elements                │   ║
║  │  14:33:02  Found 15 unique section titles          │   ║
║  │  14:33:18  Extracting table 18 of 23...            │   ║
║  └────────────────────────────────────────────────────┘   ║
║                                                            ║
║                           [Cancel Processing]              ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

#### User Interactions
1. **Monitor Progress**
   - Real-time progress bar updates
   - Stage indicators with checkmarks
   - Live statistics counter

2. **View Detailed Logs**
   - Toggle to show/hide detailed processing log
   - Auto-scroll to latest entry

3. **Cancel Processing** (Optional)
   - Stop current job
   - Clean up partial results
   - Return to Upload screen

#### API Calls

**1. Get Job Status (Polling every 2 seconds)**
```
GET /api/job/{job_id}/status

Response 200:
{
  "job_id": "job_xyz789",
  "status": "processing",
  "progress_percent": 68,
  "current_stage": "extracting_tables",
  "stages": {
    "load_pdf": {"status": "completed", "timestamp": "2024-11-18T14:32:15Z"},
    "partition": {"status": "completed", "elements": 1245},
    "identify_sections": {"status": "completed", "sections": 15},
    "extract_tables": {"status": "in_progress", "completed": 18, "total": 23},
    "save_files": {"status": "pending"},
    "catalog": {"status": "pending"}
  },
  "statistics": {
    "sections": 15,
    "tables": 23,
    "elements": 1245
  },
  "estimated_remaining_sec": 45,
  "logs": [
    {"timestamp": "2024-11-18T14:32:15Z", "message": "Starting PDF partition..."},
    {"timestamp": "2024-11-18T14:32:45Z", "message": "Extracted 1,245 elements"},
    ...
  ]
}

Status Values:
- "pending": Not started
- "processing": Currently running
- "completed": Finished successfully
- "failed": Error occurred
```

**2. Cancel Job**
```
POST /api/job/{job_id}/cancel

Response 200:
{
  "job_id": "job_xyz789",
  "status": "cancelled"
}
```

#### State Transitions
- **Initial:** Show "Starting..." message
- **Processing:** Poll for updates every 2 seconds
- **Progress Updates:** Update progress bar, stage indicators, stats
- **Completed:** Auto-redirect to Results screen
- **Failed:** Show error message with retry option

---

### Screen 4: Results Dashboard

**📊 Interactive Mockup:** See `diagrams/05_Screen4_Results_Dashboard.drawio`

#### Visual Layout
```
╔════════════════════════════════════════════════════════════╗
║  ← Back to Upload               PDF Document Parser        ║
╠════════════════════════════════════════════════════════════╣
║                                                            ║
║  ✓ Processing Complete: Protocol_64007957.pdf             ║
║     Completed: Nov 18, 2024 at 2:35 PM • Duration: 2m 15s ║
║                                                            ║
║  📊 Summary                                                ║
║  ┌──────────────┬──────────────┬──────────────┬─────────┐ ║
║  │   Sections   │    Tables    │     Files    │   Size  │ ║
║  │      15      │      23      │      61      │  2.7 MB │ ║
║  └──────────────┴──────────────┴──────────────┴─────────┘ ║
║                                                            ║
║  🔍 Actions                                                ║
║  [📥 Download All] [📊 Export CSV] [📋 View in Catalog]   ║
║                                                            ║
║  📄 Sections                         🔍 [Search sections]  ║
║  ┌────────────────────────────────────────────────────┐   ║
║  │ Section Title              Pages    Tables   Files  │   ║
║  ├────────────────────────────────────────────────────┤   ║
║  │ ▸ Protocol Summary         1-3       2      7 files│ →│
║  │ ▸ Study Objectives         4-8       1      4 files│ →│
║  │ ▾ Study Design            9-25       8     25 files│   ║
║  │   │                                                 │   ║
║  │   ├─ 📄 Study_Design.txt                          │   ║
║  │   ├─ 📊 Study_Design__table_1.html                │   ║
║  │   ├─ 📊 Study_Design__table_2.html                │   ║
║  │   └─ ... 22 more files                            │   ║
║  │                                                     │   ║
║  │ ▸ Eligibility Criteria   26-35       3     10 files│ →│
║  │ ▸ Treatment Schedule     36-50       9     28 files│ →│
║  │ ▸ Safety Monitoring      51-68       0      1 file │ →│
║  │ ... 9 more sections                                │   ║
║  └────────────────────────────────────────────────────┘   ║
║                                                            ║
║  Quality Indicators                                        ║
║  ✓ All sections contain content                            ║
║  ✓ 23/23 tables successfully extracted                     ║
║  ⚠ 2 sections have minimal content (<100 characters)       ║
║                                                            ║
║                         [Process Another Document]         ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

#### User Interactions
1. **View Summary**
   - High-level statistics
   - Quick actions bar

2. **Browse Sections**
   - Expand/collapse sections
   - Click to view details
   - Search/filter sections

3. **Download/Export**
   - Download all files as ZIP
   - Export metadata to CSV
   - View in Unity Catalog

4. **View Section Details**
   - Click section → Opens detail modal/page

#### API Calls

**1. Get Results**
```
GET /api/results/{file_id}

Response 200:
{
  "file_id": "abc123",
  "filename": "Protocol_64007957.pdf",
  "processing_complete_timestamp": "2024-11-18T14:35:00Z",
  "duration_sec": 135,
  "summary": {
    "sections": 15,
    "tables": 23,
    "total_files": 61,
    "total_size_bytes": 2831155
  },
  "sections": [
    {
      "section_id": "s1",
      "title": "Protocol Summary",
      "pages": "1-3",
      "page_numbers": [1, 2, 3],
      "table_count": 2,
      "files": [
        {
          "type": "section",
          "path": "/Volumes/.../Protocol__Protocol_Summary.txt",
          "size_bytes": 4521
        },
        {
          "type": "table",
          "path": "/Volumes/.../Protocol__Protocol_Summary__table_1.html",
          "size_bytes": 1234
        }
      ]
    },
    ...
  ],
  "quality": {
    "all_sections_have_content": true,
    "tables_extracted": "23/23",
    "warnings": [
      "Section 'Abbreviations' has minimal content (45 characters)"
    ]
  },
  "catalog_location": "aira.jnj.pdf_child_relationships"
}
```

**2. Download All Files**
```
GET /api/results/{file_id}/download

Response 200:
Content-Type: application/zip
Content-Disposition: attachment; filename="Protocol_64007957_results.zip"

<ZIP file binary>
```

**3. Export Metadata CSV**
```
GET /api/results/{file_id}/export?format=csv

Response 200:
Content-Type: text/csv
Content-Disposition: attachment; filename="Protocol_64007957_metadata.csv"

section_title,pages,table_count,file_count,start_page,end_page
Protocol Summary,1-3,2,7,1,3
Study Objectives,4-8,1,4,4,8
...
```

#### State Transitions
- **Initial:** Load results data
- **Loading:** Show spinner while fetching
- **Loaded:** Display full results dashboard
- **Section Expanded:** Show file list
- **Downloading:** Show download progress
- **Downloaded:** Trigger browser download

---

### Screen 5: Section Detail View (Modal/Overlay)

**📊 Interactive Mockup:** See `diagrams/06_Screen5_Section_Detail_Modal.drawio`

#### Visual Layout
```
╔════════════════════════════════════════════════════════════╗
║  Study Design                                        [✕]    ║
╠════════════════════════════════════════════════════════════╣
║                                                            ║
║  📄 Section Information                                    ║
║  Pages: 9-25 (17 pages)                                   ║
║  Tables: 8 tables extracted                               ║
║  Files: 25 total files                                    ║
║                                                            ║
║  📝 Content Preview                                        ║
║  ┌────────────────────────────────────────────────────┐   ║
║  │  This study is a Phase 1b/2 dose escalation and    │   ║
║  │  expansion study designed to evaluate the safety,   │   ║
║  │  tolerability, and preliminary efficacy...          │   ║
║  │                                                     │   ║
║  │  [Tables: 8 table(s) extracted and saved]          │   ║
║  │    Table 1 (Page 10): Study_Design__table_1.*      │   ║
║  │    Table 2 (Page 12): Study_Design__table_2.*      │   ║
║  │    ... 6 more tables                               │   ║
║  └────────────────────────────────────────────────────┘   ║
║                                [View Full Content →]       ║
║                                                            ║
║  📊 Tables (8)                                             ║
║  ┌────────────────────────────────────────────────────┐   ║
║  │  Table 1: Dose Escalation Schema        Page 10    │   ║
║  │  [View Text] [View HTML] [Download]               │   ║
║  ├────────────────────────────────────────────────────┤   ║
║  │  Table 2: Study Cohorts                 Page 12    │   ║
║  │  [View Text] [View HTML] [Download]               │   ║
║  ├────────────────────────────────────────────────────┤   ║
║  │  ... 6 more tables                                 │   ║
║  └────────────────────────────────────────────────────┘   ║
║                                                            ║
║  📁 All Files (25)                                         ║
║  [Download Section] [Download Tables Only]                 ║
║                                                            ║
║                                              [Close]       ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

#### User Interactions
1. **View Content Preview**
   - First 500 characters shown
   - "View Full Content" opens file

2. **Browse Tables**
   - List of all tables in section
   - View/download individual tables

3. **Download Options**
   - Download section file
   - Download all tables
   - Download everything

#### API Calls

**1. Get Section Details**
```
GET /api/section/{section_id}

Response 200:
{
  "section_id": "s1",
  "title": "Study Design",
  "content_preview": "This study is a Phase 1b/2...",
  "full_content_path": "/Volumes/.../Study_Design.txt",
  "pages": "9-25",
  "table_count": 8,
  "tables": [
    {
      "table_id": 1,
      "page": 10,
      "text_path": "/Volumes/.../Study_Design__table_1.txt",
      "html_path": "/Volumes/.../Study_Design__table_1.html",
      "json_path": "/Volumes/.../Study_Design__table_1.json"
    },
    ...
  ],
  "all_files": [
    {
      "name": "Study_Design.txt",
      "path": "/Volumes/.../Study_Design.txt",
      "size_bytes": 15234,
      "type": "section"
    },
    ...
  ]
}
```

**2. Download Section**
```
GET /api/section/{section_id}/download

Response 200:
Content-Type: application/zip
Content-Disposition: attachment; filename="Study_Design.zip"

<ZIP file with section + all tables>
```

**3. View Table Content**
```
GET /api/table/{table_id}?format=html

Response 200:
Content-Type: text/html

<table>
  <tr><th>Dose Level</th><th>Cohort</th>...</tr>
  <tr><td>1</td><td>A</td>...</tr>
  ...
</table>
```

---

## 🔄 API Specification Summary

### Base URL
```
https://<databricks-workspace>/apps/<app-name>/
```

### Endpoints Overview

| Method | Endpoint | Purpose |
|--------|----------|---------|
| `POST` | `/api/upload` | Upload PDF file |
| `GET` | `/api/documents` | List recent/all documents |
| `GET` | `/api/catalogs` | Get available Unity catalogs |
| `GET` | `/api/volumes` | Get volumes for catalog/schema |
| `POST` | `/api/process` | Start PDF processing job |
| `GET` | `/api/job/{job_id}/status` | Get processing status |
| `POST` | `/api/job/{job_id}/cancel` | Cancel processing job |
| `GET` | `/api/results/{file_id}` | Get processing results |
| `GET` | `/api/results/{file_id}/download` | Download all results |
| `GET` | `/api/results/{file_id}/export` | Export metadata |
| `GET` | `/api/section/{section_id}` | Get section details |
| `GET` | `/api/section/{section_id}/download` | Download section files |
| `GET` | `/api/table/{table_id}` | Get table content |

### Authentication
```
Authorization: Bearer <databricks_token>
```

### Error Responses
```json
{
  "error": "Error message",
  "code": "ERROR_CODE",
  "details": {}
}
```

---

## 📊 State Management

### Application States

```javascript
{
  currentScreen: "upload" | "config" | "processing" | "results",
  uploadedFile: {
    fileId: string,
    filename: string,
    sizeBytes: number,
    status: "uploaded" | "processing" | "completed" | "failed"
  },
  configuration: {
    strategy: "fast" | "hi_res",
    extractTables: boolean,
    saveTablesSeparately: boolean,
    output: {
      catalog: string,
      schema: string,
      volume: string
    }
  },
  processingJob: {
    jobId: string,
    status: string,
    progressPercent: number,
    currentStage: string,
    statistics: {},
    logs: []
  },
  results: {
    fileId: string,
    summary: {},
    sections: [],
    quality: {}
  }
}
```

---

## 🎯 User Journey Examples

### Happy Path: First Time User
```
1. User lands on Upload screen
2. Drags PDF file onto upload area
3. File uploads → auto-redirects to Configuration
4. User reviews default settings, clicks "Start Processing"
5. Processing screen shows real-time progress
6. After 2 minutes, auto-redirects to Results
7. User explores sections, downloads a few tables
8. User clicks "Process Another Document"
```

### Power User: Batch Processing
```
1. User on Upload screen, sees recent documents
2. Clicks "View All" to see processing history
3. Uploads new PDF
4. Changes strategy to "Hi-Res" in Configuration
5. Starts processing, minimizes window
6. Returns later, sees "Completed" in recent list
7. Clicks "View Results" to go directly to results
8. Exports all metadata as CSV for analysis
```

### Error Recovery
```
1. User uploads PDF
2. Processing starts
3. Error occurs at "Extracting Tables" stage
4. Error message shown: "Table extraction failed"
5. Options presented: "Retry" or "Continue without tables"
6. User chooses "Continue without tables"
7. Processing completes with 0 tables
8. Warning shown in results: "No tables extracted"
```

---

## 🎨 Design Guidelines

### Colors
- Primary: #0066CC (Databricks Blue)
- Success: #2ECC40 (Green)
- Warning: #FF851B (Orange)
- Error: #FF4136 (Red)
- Background: #F9FAFB
- Text: #1F2937

### Typography
- Headings: 24px, 18px, 16px (Bold)
- Body: 14px (Regular)
- Small: 12px (Regular)
- Monospace: Consolas, Monaco (for file paths)

### Spacing
- Section padding: 24px
- Card padding: 16px
- Button spacing: 12px
- Line height: 1.5

### Components
- **Buttons:** Rounded corners (4px), 12px padding
- **Cards:** White background, 1px border, 8px border-radius
- **Progress Bars:** Height 8px, rounded, animated
- **Tables:** Alternating row colors, hover effects

---

## 📱 Responsive Considerations

### Desktop (Primary)
- Full multi-column layout
- Side-by-side previews
- Expanded tables

### Tablet
- Stacked single-column
- Collapsible sections
- Simplified table views

### Mobile (Future)
- Minimal view-only mode
- Focus on status checking
- No upload capability

---

## ⚡ Performance Targets

- **Upload:** < 2 seconds for 50MB file
- **Configuration Load:** < 500ms
- **Status Polling:** Every 2 seconds
- **Results Load:** < 1 second
- **File Download:** Immediate browser download

---

## 🔐 Security Considerations

- File uploads over HTTPS
- Token-based authentication
- Access control via Unity Catalog
- No client-side storage of sensitive data
- Audit logging on all API calls

---

## 📝 Implementation Notes

### Frontend Stack
- **Framework:** Streamlit (recommended for Databricks) or Dash
- **HTTP Client:** requests library
- **File Handling:** streamlit.file_uploader
- **Progress:** streamlit.progress
- **State:** streamlit.session_state

### Backend Requirements (api.py)
```python
# Required Flask endpoints
@app.route('/api/upload', methods=['POST'])
@app.route('/api/documents', methods=['GET'])
@app.route('/api/catalogs', methods=['GET'])
@app.route('/api/process', methods=['POST'])
@app.route('/api/job/<job_id>/status', methods=['GET'])
@app.route('/api/results/<file_id>', methods=['GET'])
# ... etc
```

---

**Version:** 1.0  
**Last Updated:** November 2024  
**Status:** Design Phase


# Deployment Guide for clinical-data-standards

Complete guide for deploying clinical-data-standards to Databricks workspaces.

## Prerequisites

- Databricks CLI v0.250.0 or above
- Access to Databricks workspace: https://dbc-70edafc8-39e8.cloud.databricks.com
- Appropriate permissions (CAN_MANAGE on workspace resources)
- Python 3.8+ for local development

## Initial Setup

### 1. Install Databricks CLI

```bash
# Install CLI
curl -fsSL https://raw.githubusercontent.com/databricks/setup-cli/main/install.sh | sudo sh

# Verify installation
databricks --version
```

### 2. Authenticate

```bash
# OAuth authentication (recommended)
databricks auth login --host https://dbc-70edafc8-39e8.cloud.databricks.com

# Or use personal access token
databricks configure --token
```

### 3. Clone Repository

```bash
git clone <repository-url>
cd clinical-data-standards
```

## Deployment Workflow

### Development Deployment

```bash
# Validate bundle
databricks bundle validate

# Deploy to dev
databricks bundle deploy --target dev

# Verify deployment
databricks bundle summary
```

### Staging Deployment

```bash
# Deploy to staging
databricks bundle deploy --target staging

# Run integration tests (if configured)
# databricks bundle run job_<pipeline_name>_integration_test --target staging
```

### Production Deployment

```bash
# Deploy to production
databricks bundle deploy --target prod

# Run production jobs (if any)
# databricks bundle run job_<pipeline_name> --target prod
```

## Target Environments

### Dev
- **Mode**: development
- **Catalog**: dta_poc
- **Purpose**: Active development and testing
- **Resources**: Prefixed with `[dev username]`
- **Schedules**: Paused by default

### Staging
- **Mode**: development  
- **Catalog**: clinical_data_standards_stg_ctlg
- **Purpose**: Pre-production validation
- **Resources**: Shared among team
- **Schedules**: Can be enabled for testing

### Prod
- **Mode**: production
- **Catalog**: clinical_data_standards_prod_ctlg
- **Purpose**: Production workloads
- **Run As**: Service principal or designated user
- **Schedules**: Active

## Deployment Checklist

### Pre-Deployment
- [ ] Code reviewed and approved
- [ ] Tests passing
- [ ] Bundle validated
- [ ] Secrets configured
- [ ] Permissions verified

### Post-Deployment
- [ ] Resources created successfully
- [ ] Jobs/pipelines configured correctly
- [ ] Schedules set appropriately
- [ ] Monitoring enabled
- [ ] Documentation updated

## Configuration

### Environment Variables

Set these in your deployment environment:

```bash
export DATABRICKS_HOST="https://dbc-70edafc8-39e8.cloud.databricks.com"
export DATABRICKS_TOKEN="<your-token>"
```

### Bundle Variables

Override variables during deployment:

```bash
databricks bundle deploy --target dev \
  --var catalog=custom_catalog \
  --var warehouse_id=custom_warehouse
```

## Troubleshooting

### Common Issues

**1. Authentication Errors**
```bash
# Re-authenticate
databricks auth login --host https://dbc-70edafc8-39e8.cloud.databricks.com
```

**2. Permission Denied**
```
Error: User does not have CAN_MANAGE permission
```
Solution: Request workspace admin to grant permissions

**3. Resource Conflicts**
```
Error: Resource already exists
```
Solution: Use `--force-lock` flag (dev only) or coordinate with team

**4. Validation Failures**
```bash
# Debug validation
databricks bundle validate --debug
```

### Rollback

```bash
# List deployments
databricks bundle deployments list --target prod

# Rollback to previous version
databricks bundle deploy --target prod --deployment-id <previous-id>
```

## Best Practices

1. **Test in Dev First**: Always test changes in dev before staging/prod
2. **Use Version Control**: Commit all changes before deploying
3. **Document Changes**: Update CHANGELOG.md
4. **Monitor Deployments**: Watch for errors during/after deployment
5. **Backup Configurations**: Keep backups of critical configs
6. **Coordinate with Team**: Communicate before prod deployments

## Monitoring

After deployment, monitor:

- DLT pipeline execution status (if pipelines deployed)
- Job run history and success rates (if jobs deployed)
- Resource utilization and costs

## Support

For deployment issues:
- Contact: awagle4@its.jnj.com
- Documentation: See `docs/` directory
- Databricks Support: [support.databricks.com](https://support.databricks.com)


# Databricks notebook source
# MAGIC %md
# MAGIC # {{.endpoint_name}} - Comprehensive Test Suite
# MAGIC 
# MAGIC This notebook tests the **{{.endpoint_name}}** Model Serving endpoint using **3 different methods**:
# MAGIC 1. **Databricks SDK** - Native Databricks integration
# MAGIC 2. **OpenAI SDK** - OpenAI-compatible API
# MAGIC 3. **REST API** - Direct HTTP calls
# MAGIC 
# MAGIC ## Endpoint Configuration
{{- if eq .serving_mode "provisioned_throughput"}}
# MAGIC - **Name:** `{{.endpoint_name}}-${bundle.target}`  
# MAGIC - **Model:** {{.foundation_model_name}}  
# MAGIC - **Unity Catalog:** system.ai.{{.foundation_model_name | replace "databricks-" "" | replace "-" "_"}}
# MAGIC - **Serving Mode:** Provisioned Throughput
# MAGIC - **Served Entity:** {{.served_entity_name}}
# MAGIC - **Version:** {{.entity_version}}
# MAGIC - **Throughput:** {{.min_provisioned_throughput}}-{{.max_provisioned_throughput}} tokens/min
# MAGIC - **Scale to Zero:** {{.scale_to_zero_enabled}}
{{- else}}
# MAGIC - **Name:** `{{.foundation_model_name}}` (Pre-configured Foundation Model API)
# MAGIC - **Model:** {{.foundation_model_name}}  
# MAGIC - **Serving Mode:** Pay-per-token (No deployment needed)
# MAGIC 
# MAGIC > **Note:** Pay-per-token foundation models are automatically available - no deployment required!
{{- end}}

# COMMAND ----------

# MAGIC %md
# MAGIC ## Setup & Configuration

# COMMAND ----------

# MAGIC %pip install openai>=1.0.0
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import ChatMessage, ChatMessageRole
from openai import OpenAI
import requests
import json
import time

# Get workspace details
workspace_url = spark.conf.get("spark.databricks.workspaceUrl")
token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()

# Endpoint name - different for pay-per-token vs provisioned throughput
{{- if eq .serving_mode "provisioned_throughput"}}
endpoint_name = "{{.endpoint_name}}-dev"  # Change to 'prod' or 'staging' as needed
serving_mode = "Provisioned Throughput"
{{- else}}
endpoint_name = "{{.foundation_model_name}}"  # Pre-configured pay-per-token endpoint
serving_mode = "Pay-per-token (Pre-configured)"
{{- end}}

print(f"✅ Setup complete!")
print(f"📡 Endpoint: {endpoint_name}")
print(f"🌐 Workspace: {workspace_url}")
print(f"🚀 Mode: {serving_mode}")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC # Part 1: Databricks SDK Testing
# MAGIC Test using the native Databricks Python SDK

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.1. Check Endpoint Status

# COMMAND ----------

# Initialize Databricks client
w = WorkspaceClient()

# Get endpoint details
endpoint = w.serving_endpoints.get(endpoint_name)

print(f"📊 Endpoint Details:")
print(f"   Name: {endpoint.name}")
print(f"   State: {endpoint.state.config_update}")
print(f"   Ready: {endpoint.state.ready}")

# Wait for endpoint to be ready if needed
if endpoint.state.ready != "READY":
    print("\n⏳ Waiting for endpoint to be ready...")
    w.serving_endpoints.wait_get_serving_endpoint_not_updating(endpoint_name)
    print("✅ Endpoint is ready!")
else:
    print("✅ Endpoint is ready!")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.2. Simple Query Test

# COMMAND ----------

response = w.serving_endpoints.query(
    name=endpoint_name,
    messages=[
        ChatMessage(
            role=ChatMessageRole.USER,
            content="What is Databricks?"
        )
    ],
    max_tokens=150
)

print("📝 Query: What is Databricks?")
print(f"\n💬 Response:\n{response.choices[0].message.content}")
print(f"\n📊 Tokens used: {response.usage.total_tokens}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.3. Multi-turn Conversation

# COMMAND ----------

messages = [
    ChatMessage(role=ChatMessageRole.SYSTEM, content="You are a data engineering expert."),
    ChatMessage(role=ChatMessageRole.USER, content="What is Delta Lake?"),
]

response = w.serving_endpoints.query(
    name=endpoint_name,
    messages=messages,
    max_tokens=150
)

print("🔄 Turn 1:")
print(f"User: What is Delta Lake?")
print(f"Assistant: {response.choices[0].message.content}\n")

# Continue conversation
messages.append(ChatMessage(
    role=ChatMessageRole.ASSISTANT,
    content=response.choices[0].message.content
))
messages.append(ChatMessage(
    role=ChatMessageRole.USER,
    content="How does it differ from Apache Parquet?"
))

response = w.serving_endpoints.query(
    name=endpoint_name,
    messages=messages,
    max_tokens=150
)

print("🔄 Turn 2:")
print(f"User: How does it differ from Apache Parquet?")
print(f"Assistant: {response.choices[0].message.content}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.4. Performance Testing

# COMMAND ----------

queries = [
    "What is machine learning?",
    "Explain neural networks in simple terms.",
    "What is supervised learning?",
    "What are transformers in NLP?",
    "Explain gradient descent."
]

latencies = []

print("⚡ Performance Testing:\n")

for i, query in enumerate(queries, 1):
    start_time = time.time()
    
    response = w.serving_endpoints.query(
        name=endpoint_name,
        messages=[ChatMessage(role=ChatMessageRole.USER, content=query)],
        max_tokens=80
    )
    
    latency = time.time() - start_time
    latencies.append(latency)
    
    print(f"Query {i}: {latency:.2f}s")

print(f"\n📊 Performance Stats:")
print(f"  Average latency: {sum(latencies)/len(latencies):.2f}s")
print(f"  Min latency: {min(latencies):.2f}s")
print(f"  Max latency: {max(latencies):.2f}s")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC # Part 2: OpenAI SDK Testing
# MAGIC Test OpenAI-compatible API integration

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2.1. Initialize OpenAI Client

# COMMAND ----------

# Initialize OpenAI client with Databricks endpoint
client = OpenAI(
    api_key=token,
    base_url=f"https://{workspace_url}/serving-endpoints"
)

print(f"✅ OpenAI client configured")
print(f"📡 Base URL: https://{workspace_url}/serving-endpoints")
print(f"🎯 Model: {endpoint_name}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2.2. Chat Completion

# COMMAND ----------

response = client.chat.completions.create(
    model=endpoint_name,
    messages=[
        {"role": "user", "content": "What is Unity Catalog?"}
    ],
    max_tokens=150
)

print(f"📝 Query: What is Unity Catalog?\n")
print(f"💬 Response:\n{response.choices[0].message.content}\n")
print(f"📊 Tokens: {response.usage.total_tokens}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2.3. Streaming Response

# COMMAND ----------

print("🌊 Streaming response:\n")

stream = client.chat.completions.create(
    model=endpoint_name,
    messages=[
        {"role": "user", "content": "Explain medallion architecture in 3 sentences."}
    ],
    max_tokens=100,
    stream=True
)

full_response = ""
for chunk in stream:
    if chunk.choices[0].delta.content:
        content = chunk.choices[0].delta.content
        print(content, end="", flush=True)
        full_response += content

print("\n\n✅ Streaming complete!")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2.4. Temperature Control

# COMMAND ----------

prompt = "Write a creative tagline for a data analytics platform."

print("🎨 Testing different temperatures:\n")

for temp in [0.0, 0.7, 1.5]:
    response = client.chat.completions.create(
        model=endpoint_name,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=50,
        temperature=temp
    )
    
    print(f"Temperature {temp}:")
    print(f"  {response.choices[0].message.content}\n")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC # Part 3: REST API Testing
# MAGIC Test direct HTTP calls

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3.1. Setup REST Client

# COMMAND ----------

# REST API configuration
base_url = f"https://{workspace_url}/serving-endpoints/{endpoint_name}/invocations"
headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

print(f"✅ REST API configured")
print(f"📡 URL: {base_url}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3.2. Simple POST Request

# COMMAND ----------

payload = {
    "messages": [
        {"role": "user", "content": "What is MLflow?"}
    ],
    "max_tokens": 150
}

response = requests.post(base_url, headers=headers, json=payload)

if response.status_code == 200:
    result = response.json()
    print("✅ Success!")
    print(f"\n📝 Query: {payload['messages'][0]['content']}")
    print(f"\n💬 Response:\n{result['choices'][0]['message']['content']}")
    print(f"\n📊 Tokens: {result['usage']['total_tokens']}")
else:
    print(f"❌ Error {response.status_code}: {response.text}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3.3. Streaming with REST API

# COMMAND ----------

payload = {
    "messages": [
        {"role": "user", "content": "Explain Apache Spark in 2 sentences."}
    ],
    "max_tokens": 80,
    "stream": True
}

print("🌊 Streaming response:\n")

with requests.post(base_url, headers=headers, json=payload, stream=True) as response:
    for line in response.iter_lines():
        if line:
            line_str = line.decode('utf-8')
            if line_str.startswith('data: ') and not line_str.endswith('[DONE]'):
                try:
                    data = json.loads(line_str[6:])
                    if 'choices' in data and len(data['choices']) > 0:
                        delta = data['choices'][0].get('delta', {})
                        if 'content' in delta:
                            print(delta['content'], end='', flush=True)
                except json.JSONDecodeError:
                    continue

print("\n\n✅ Streaming complete!")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3.4. Batch Processing

# COMMAND ----------

test_queries = [
    "What is a data lakehouse?",
    "Explain ETL vs ELT",
    "What is Unity Catalog?",
    "Describe Delta Live Tables",
    "What is Vector Search?"
]

results = []

print("📦 Batch processing:\n")

for i, query in enumerate(test_queries, 1):
    payload = {
        "messages": [{"role": "user", "content": query}],
        "max_tokens": 80
    }
    
    response = requests.post(base_url, headers=headers, json=payload)
    
    if response.status_code == 200:
        result = response.json()
        response_text = result['choices'][0]['message']['content']
        tokens = result['usage']['total_tokens']
        
        print(f"{i}. {query}")
        print(f"   {response_text[:80]}...")
        print(f"   Tokens: {tokens}\n")
        
        results.append({"query": query, "status": "success", "tokens": tokens})
    else:
        print(f"{i}. {query}")
        print(f"   ❌ Error: {response.status_code}\n")
        results.append({"query": query, "status": "error"})

success_count = sum(1 for r in results if r["status"] == "success")
print(f"✅ {success_count}/{len(test_queries)} queries successful")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC # Part 4: Comparison & Best Practices

# COMMAND ----------

# MAGIC %md
# MAGIC ## Method Comparison
# MAGIC 
# MAGIC | Method | Use Case | Pros | Cons |
# MAGIC |--------|----------|------|------|
# MAGIC | **Databricks SDK** | Databricks-native apps | • Full Databricks integration<br>• Type safety<br>• Best for notebooks | • Databricks-specific |
# MAGIC | **OpenAI SDK** | Migration from OpenAI | • Drop-in replacement<br>• Familiar API<br>• Easy migration | • Extra dependency |
# MAGIC | **REST API** | Any language/platform | • Language-agnostic<br>• Direct HTTP control<br>• curl/Postman testing | • Manual HTTP handling |
# MAGIC 
# MAGIC ## Best Practices
# MAGIC 
# MAGIC ✅ **For Production:**
# MAGIC - Implement retry logic with exponential backoff
# MAGIC - Add rate limiting
# MAGIC - Monitor token usage and costs
# MAGIC - Set appropriate timeouts
# MAGIC - Log requests and responses
# MAGIC - Use environment variables for endpoints and tokens
# MAGIC 
# MAGIC ✅ **Performance:**
# MAGIC - Use streaming for long responses
# MAGIC - Batch requests when possible
# MAGIC - Cache responses for repeated queries
# MAGIC - Monitor latency metrics
# MAGIC 
# MAGIC ✅ **Cost Optimization:**
# MAGIC - Set reasonable `max_tokens` limits
# MAGIC - Use shorter system prompts
# MAGIC - Enable `scale_to_zero` for non-production
# MAGIC - Consider provisioned throughput for high-volume

# COMMAND ----------

# MAGIC %md
# MAGIC ## Generate curl Command for External Testing

# COMMAND ----------

curl_command = f"""
# Test your endpoint from command line:

curl -X POST "{base_url}" \\
  -H "Authorization: Bearer <YOUR_DATABRICKS_TOKEN>" \\
  -H "Content-Type: application/json" \\
  -d '{{
    "messages": [
      {{"role": "user", "content": "What is Databricks?"}}
    ],
    "max_tokens": 150
  }}'
"""

print(curl_command)

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC # Summary
# MAGIC 
# MAGIC ✅ **Testing Complete!**
# MAGIC 
# MAGIC This notebook tested your Model Serving endpoint using:
# MAGIC 1. ✅ Databricks SDK - Native integration
# MAGIC 2. ✅ OpenAI SDK - OpenAI-compatible API
# MAGIC 3. ✅ REST API - Direct HTTP calls
# MAGIC 
# MAGIC **Endpoint Details:**
# MAGIC - Name: `{{.endpoint_name}}-dev`
# MAGIC - Model: {{.foundation_model_name}}
# MAGIC - Mode: {{.serving_mode}}
# MAGIC 
# MAGIC **Next Steps:**
# MAGIC 1. 📊 Monitor endpoint metrics in Serving UI
# MAGIC 2. 🔧 Adjust parameters based on test results
# MAGIC 3. 🚀 Integrate endpoint into your application
# MAGIC 4. 📈 Set up monitoring and alerts
# MAGIC 5. 💰 Monitor costs and optimize usage
# MAGIC 
# MAGIC **View in Workspace:**
# MAGIC - Navigate to: **Serving > Endpoints > {{.endpoint_name}}-dev**

# COMMAND ----------

print("🎉 All tests completed successfully!")
print(f"\n📊 Endpoint: {endpoint_name}")
print(f"✅ Status: READY")
print(f"🔗 View in workspace: Serving > Endpoints > {endpoint_name}")


-- ============================================================================
-- DEBUG QUERIES FOR TSDTA EXCEL PROCESSING
-- ============================================================================
-- Run these queries to understand why you're getting 0 documents to process
-- ============================================================================

-- ----------------------------------------------------------------------------
-- QUERY 1: Check ALL documents in trial_data_history
-- ----------------------------------------------------------------------------
SELECT 
    document_id,
    extracted_path,
    file_extension,
    document_tags,
    active,
    current_status,
    current_status_timestamp,
    categorization_notes,
    created_ts
FROM aira.bronze_md.trial_data_history
ORDER BY created_ts DESC
LIMIT 50;

-- ----------------------------------------------------------------------------
-- QUERY 2: Check ONLY Excel files
-- ----------------------------------------------------------------------------
SELECT 
    document_id,
    extracted_path,
    file_extension,
    document_tags,
    active,
    current_status,
    categorization_notes
FROM aira.bronze_md.trial_data_history
WHERE file_extension IN ('.xls', '.xlsx', '.xlsm', '.xlsb', '.xlt', '.xltx', '.xltm')
ORDER BY created_ts DESC
LIMIT 20;

-- ----------------------------------------------------------------------------
-- QUERY 3: Count documents by each filter condition
-- ----------------------------------------------------------------------------
-- How many have tsDTA tag?
SELECT 'Has tsDTA tag' as condition, COUNT(*) as count
FROM aira.bronze_md.trial_data_history
WHERE array_contains(document_tags, 'tsDTA')

UNION ALL

-- How many are active?
SELECT 'Active = true' as condition, COUNT(*) as count
FROM aira.bronze_md.trial_data_history
WHERE active = true

UNION ALL

-- How many have READY_FOR_PROCESSING status?
SELECT 'Status = READY_FOR_PROCESSING' as condition, COUNT(*) as count
FROM aira.bronze_md.trial_data_history
WHERE current_status = 'READY_FOR_PROCESSING'

UNION ALL

-- How many match ALL three conditions? (This should match what the notebook sees)
SELECT 'ALL conditions matched' as condition, COUNT(*) as count
FROM aira.bronze_md.trial_data_history
WHERE array_contains(document_tags, 'tsDTA')
  AND active = true
  AND current_status = 'READY_FOR_PROCESSING';

-- ----------------------------------------------------------------------------
-- QUERY 4: Check what tags Excel files actually have
-- ----------------------------------------------------------------------------
SELECT 
    file_extension,
    document_tags,
    active,
    current_status,
    COUNT(*) as count
FROM aira.bronze_md.trial_data_history
WHERE file_extension IN ('.xls', '.xlsx', '.xlsm', '.xlsb')
GROUP BY file_extension, document_tags, active, current_status
ORDER BY count DESC;

-- ----------------------------------------------------------------------------
-- QUERY 5: Check if documents were already processed
-- ----------------------------------------------------------------------------
SELECT 
    current_status,
    COUNT(*) as count
FROM aira.bronze_md.trial_data_history
WHERE file_extension IN ('.xls', '.xlsx', '.xlsm', '.xlsb')
GROUP BY current_status
ORDER BY count DESC;

-- ----------------------------------------------------------------------------
-- QUERY 6: Check error statuses in document_status table
-- ----------------------------------------------------------------------------
SELECT 
    ds.document_id,
    ds.status,
    ds.error_message,
    ds.status_timestamp,
    ds.processing_metadata,
    th.extracted_path,
    th.file_extension,
    th.document_tags
FROM aira.bronze_md.document_status ds
JOIN aira.bronze_md.trial_data_history th 
  ON ds.document_id = th.document_id
WHERE ds.status IN ('EXCEL_EXTRACTION_ERROR', 'EXCEL_EXTRACTION_STARTED', 'EXCEL_EXTRACTION_COMPLETED')
ORDER BY ds.status_timestamp DESC
LIMIT 20;

-- ----------------------------------------------------------------------------
-- QUERY 7: Check categorization notes for Excel files
-- ----------------------------------------------------------------------------
SELECT 
    extracted_path,
    file_extension,
    document_tags,
    active,
    categorization_notes
FROM aira.bronze_md.trial_data_history
WHERE file_extension IN ('.xls', '.xlsx', '.xlsm', '.xlsb')
  AND categorization_notes IS NOT NULL
ORDER BY created_ts DESC
LIMIT 20;

-- ----------------------------------------------------------------------------
-- QUERY 8: Find Excel files that should be processed but aren't matching
-- ----------------------------------------------------------------------------
-- This shows Excel files and why they don't match
SELECT 
    document_id,
    extracted_path,
    file_extension,
    document_tags,
    CASE 
        WHEN NOT array_contains(document_tags, 'tsDTA') THEN '❌ Missing tsDTA tag'
        ELSE '✓ Has tsDTA tag'
    END as tag_check,
    CASE 
        WHEN active = false THEN '❌ Inactive'
        ELSE '✓ Active'
    END as active_check,
    CASE 
        WHEN current_status != 'READY_FOR_PROCESSING' THEN CONCAT('❌ Status: ', current_status)
        ELSE '✓ Ready to process'
    END as status_check,
    categorization_notes
FROM aira.bronze_md.trial_data_history
WHERE file_extension IN ('.xls', '.xlsx', '.xlsm', '.xlsb')
ORDER BY created_ts DESC
LIMIT 30;

-- ----------------------------------------------------------------------------
-- EXPECTED RESULTS INTERPRETATION:
-- ----------------------------------------------------------------------------
-- If "ALL conditions matched" count = 0, check which condition is failing:
--   1. No tsDTA tags → Excel files not in DTA folder or categorization failed
--   2. All inactive → Excel files in wrong subfolder (e.g., SOW) or ambiguous paths
--   3. Wrong status → Documents already processed or status changed manually
--
-- If EXCEL_EXTRACTION_ERROR found, check error_message column for root cause
-- ============================================================================


"""
clinical_data_standards_framework

Data engineering framework for clinical-data-standards
Organization: JNJ
"""

__version__ = "0.0.1"
__author__ = "JNJ"

from .utils import *
from .excel_utils import *
from .config_manager import *

__all__ = [
    # Core utilities
    "get_spark_session",
    "get_catalog_config",
    "setup_logging",
    "add_audit_columns",
    "save_with_audit",
    
    # Configuration management
    "ConfigManager",
    
    # Excel processing utilities
    "get_excel_sheets_schema",
    "categorize_sheet_name",
    "extract_version_history_metadata",
    "find_excel_header_row",
    "get_header_filter_patterns",
    "parse_max_length",
    "is_required_field",
    "is_transfer_key_field",
    "get_transfer_metadata_column_map",
    "get_transfer_metadata_flexible_mapper",
    "get_codelist_flexible_mapper"
]


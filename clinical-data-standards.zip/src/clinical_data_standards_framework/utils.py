"""
Common utilities for Clinical Data Standards Framework
"""

import io
import os
import re
import uuid
import base64
import zipfile
import logging
from datetime import datetime
from typing import Dict, List, Optional

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.functions import current_timestamp, lit
from pyspark.sql.types import (
    StructType, StructField, StringType, TimestampType, LongType, 
    BinaryType, IntegerType, BooleanType, ArrayType, DoubleType
)


# ============================================================================
# Logging Setup
# ============================================================================

def setup_logging(name: str = "clinical_data_standards") -> logging.Logger:
    """
    Setup logging configuration
    
    Args:
        name: Logger name
        
    Returns:
        Configured logger instance
    """
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    return logging.getLogger(name)


# ============================================================================
# Spark Session & Configuration
# ============================================================================

def get_spark_session(app_name: str = "clinical_data_standards") -> SparkSession:
    """
    Get or create Spark session
    
    Args:
        app_name: Name for the Spark application
        
    Returns:
        SparkSession instance
    """
    return SparkSession.builder.appName(app_name).getOrCreate()


def get_catalog_config(spark: SparkSession, 
                       catalog: str = "main",
                       bronze_schema: str = "bronze",
                       silver_schema: str = "silver",
                       gold_schema: str = "gold") -> Dict[str, str]:
    """
    Get catalog configuration from Spark conf with fallback defaults
    
    Args:
        spark: SparkSession instance
        catalog: Default catalog name
        bronze_schema: Default bronze schema name
        silver_schema: Default silver schema name
        gold_schema: Default gold schema name
        
    Returns:
        Dictionary with catalog configuration
    """
    return {
        "catalog": spark.conf.get("catalog", catalog),
        "bronze_schema": spark.conf.get("bronze_schema", bronze_schema),
        "silver_schema": spark.conf.get("silver_schema", silver_schema),
        "gold_schema": spark.conf.get("gold_schema", gold_schema),
        "table_suffix": spark.conf.get("table_suffix", "")
    }


# ============================================================================
# Path Utilities
# ============================================================================

def dbfs_to_local(dbfs_path: str) -> str:
    """
    Convert dbfs:/Volumes/... path to /Volumes/... local path
    On modern UC clusters, /Volumes is the correct writable path.
    
    Args:
        dbfs_path: Path starting with dbfs:/Volumes/
        
    Returns:
        Local filesystem path starting with /Volumes/
        
    Raises:
        ValueError: If path doesn't start with dbfs:/Volumes/
    """
    if dbfs_path.startswith("dbfs:/Volumes/"):
        return dbfs_path.replace("dbfs:/", "/")
    else:
        raise ValueError(f"Unexpected path (expected dbfs:/Volumes/...): {dbfs_path}")


def local_to_dbfs(local_path: str) -> str:
    """
    Convert /Volumes/... local path to dbfs:/Volumes/... path
    
    Args:
        local_path: Path starting with /Volumes/
        
    Returns:
        DBFS path starting with dbfs:/Volumes/
        
    Raises:
        ValueError: If path doesn't start with /Volumes/
    """
    if local_path.startswith("/Volumes/"):
        return local_path.replace("/", "dbfs:/", 1)
    else:
        raise ValueError(f"Unexpected local path (expected /Volumes/...): {local_path}")


def build_volume_path(catalog: str, 
                     schema: str, 
                     volume: str, 
                     subdir: str = "", 
                     use_dbfs_prefix: bool = True) -> str:
    """
    Build a Unity Catalog Volume path
    
    Args:
        catalog: Catalog name
        schema: Schema name
        volume: Volume name
        subdir: Optional subdirectory path within the volume
        use_dbfs_prefix: If True, returns dbfs:/Volumes/..., else /Volumes/...
        
    Returns:
        Constructed volume path
    """
    prefix = "dbfs:/Volumes" if use_dbfs_prefix else "/Volumes"
    base_path = f"{prefix}/{catalog}/{schema}/{volume}"
    
    if subdir:
        base_path = f"{base_path}/{subdir.strip('/')}"
    
    return base_path


# ============================================================================
# DataFrame Utilities
# ============================================================================

def add_audit_columns(df: DataFrame) -> DataFrame:
    """
    Add standard audit columns to DataFrame
    
    Args:
        df: Input DataFrame
        
    Returns:
        DataFrame with audit columns added
    """
    return df.withColumn("_processing_timestamp", F.current_timestamp()) \
             .withColumn("_processing_date", F.current_date())


def validate_schema(df: DataFrame, required_columns: List[str]) -> bool:
    """
    Validate that DataFrame has required columns
    
    Args:
        df: DataFrame to validate
        required_columns: List of required column names
        
    Returns:
        True if all required columns are present
        
    Raises:
        ValueError: If required columns are missing
    """
    df_columns = set(df.columns)
    missing = set(required_columns) - df_columns
    
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    
    return True


# ============================================================================
# Table I/O Utilities
# ============================================================================

def write_table(
    df: DataFrame,
    catalog: str,
    schema: str,
    table: str,
    mode: str = "append",
    partition_by: Optional[List[str]] = None
) -> None:
    """
    Write DataFrame to Unity Catalog table
    
    Args:
        df: DataFrame to write
        catalog: Catalog name
        schema: Schema name
        table: Table name
        mode: Write mode (append, overwrite, etc.)
        partition_by: Optional list of columns to partition by
    """
    full_table_name = f"{catalog}.{schema}.{table}"
    
    writer = df.write.mode(mode).format("delta")
    
    if partition_by:
        writer = writer.partitionBy(*partition_by)
    
    writer.saveAsTable(full_table_name)
    
    logging.info(f"Successfully wrote to {full_table_name}")


def read_table(
    spark: SparkSession,
    catalog: str,
    schema: str,
    table: str
) -> DataFrame:
    """
    Read table from Unity Catalog
    
    Args:
        spark: SparkSession instance
        catalog: Catalog name
        schema: Schema name
        table: Table name
        
    Returns:
        DataFrame with table data
    """
    full_table_name = f"{catalog}.{schema}.{table}"
    return spark.table(full_table_name)


def optimize_table(
    spark: SparkSession,
    catalog: str,
    schema: str,
    table: str,
    zorder_by: Optional[List[str]] = None
) -> None:
    """
    Optimize Delta table
    
    Args:
        spark: SparkSession instance
        catalog: Catalog name
        schema: Schema name
        table: Table name
        zorder_by: Optional columns to Z-ORDER by
    """
    full_table_name = f"{catalog}.{schema}.{table}"
    
    optimize_sql = f"OPTIMIZE {full_table_name}"
    if zorder_by:
        zorder_cols = ", ".join(zorder_by)
        optimize_sql += f" ZORDER BY ({zorder_cols})"
    
    spark.sql(optimize_sql)
    logging.info(f"Optimized {full_table_name}")


# ============================================================================
# ZIP Processing Utilities
# ============================================================================

def get_binary_file_schema() -> StructType:
    """
    Get the schema for cloudFiles + binaryFile format
    
    Returns:
        StructType schema for binary file streaming
    """
    return StructType([
        StructField("path",             StringType(),    True),
        StructField("modificationTime", TimestampType(), True),
        StructField("length",           LongType(),      True),
        StructField("content",          BinaryType(),    True)
    ])


def get_manifest_schema() -> StructType:
    """
    Get the schema for ZIP extraction manifest records
    
    Returns:
        StructType schema for manifest table
    """
    return StructType([
        StructField("document_id",          StringType(),               False),
        StructField("zip_source_path",      StringType(),               True),
        StructField("zip_root_name",        StringType(),               True),
        StructField("extracted_path",       StringType(),               True),
        StructField("content_base64",       StringType(),               True),
        StructField("size_bytes",           LongType(),                 True),
        StructField("nested_level",         IntegerType(),              True),
        StructField("is_from_nested_zip",   BooleanType(),              True),
        StructField("file_extension",       StringType(),               True),
        StructField("document_tags",        ArrayType(StringType()),    True),
        StructField("active",               BooleanType(),              True),
        StructField("categorization_notes", StringType(),               True),
        StructField("current_status",       StringType(),               True),
        StructField("current_status_timestamp", TimestampType(),        True)
    ])


def get_document_status_schema() -> StructType:
    """
    Get the schema for unified document status tracking table.
    Handles both historical ZIP extractions and ongoing document processing.
    
    Returns:
        StructType schema for document status table
    """
    return StructType([
        StructField("document_id",                  StringType(),    False),
        StructField("status",                       StringType(),    False),
        StructField("status_timestamp",             TimestampType(), False),
        StructField("error_message",                StringType(),    True),
        StructField("processing_duration_seconds",  DoubleType(),    True),
        StructField("retry_count",                  IntegerType(),   True),
        StructField("processing_metadata",          StringType(),    True)
    ])



# ============================================================================
# Excel Processing Functions (imported from excel_utils.py)
# ============================================================================

# Import all Excel-related functions from excel_utils module for backwards compatibility
from .excel_utils import (
    get_excel_sheets_schema,
    categorize_sheet_name,
    extract_version_history_metadata,
    find_excel_header_row,
    get_header_filter_patterns,
    parse_max_length,
    is_required_field,
    is_transfer_key_field,
    get_transfer_metadata_column_map,
    get_transfer_metadata_flexible_mapper,
    get_codelist_flexible_mapper
)



def extract_document_tags(
    extracted_path: str,
    archive_root: str,
    categories_config: Optional[Dict] = None,
    logger: Optional[logging.Logger] = None
) -> tuple:
    """
    Extract document tags, active flag, and categorization notes from file path.
    Searches through ALL path levels (case-insensitive) and supports both 
    folder-based and extension-based subcategory matching.
    
    Args:
        extracted_path: Full path to extracted file
                       e.g., /Volumes/.../extracted/64007957/DTA/xyz/file.xlsx
        archive_root: Root of the archive extraction
                     e.g., /Volumes/.../extracted/64007957
        categories_config: document_categories configuration from YAML (optional)
        logger: Logger instance for warnings/info (optional)
    
    Returns:
        tuple: (tags, active_flag, categorization_notes)
        
    Behavior:
        - Subcategory matching supports:
          * Folder-based: Match by subfolder name (e.g., "Dictionary", "SOW")
          * Extension-based: Match by file extension (e.g., .xlsx → "tsDTA")
        - Folder matches have priority over extension matches
        - Multiple subcategories → WARNING, first match wins, active=False
        - Unknown subfolder/extension → Fallback to top-level
        - No category match → tags=["UNKNOWN"], active=False, info note
        - No config provided → tags=[], active=True, None
    
    Examples:
        >>> # Folder-based match
        >>> extract_document_tags("/Volumes/.../archive1/DTA/Dictionary/file.pdf", 
        ...                       "/Volumes/.../archive1", categories_config)
        (["DTA", "Dictionary"], True, None)
        
        >>> # Extension-based match (Excel file in DTA)
        >>> extract_document_tags("/Volumes/.../archive1/DTA/xyz/data.xlsx",
        ...                       "/Volumes/.../archive1", categories_config)
        (["DTA", "tsDTA"], False, None)
        
        >>> # Extension-based match (PDF file in DTA)
        >>> extract_document_tags("/Volumes/.../archive1/DTA/agreement.pdf",
        ...                       "/Volumes/.../archive1", categories_config)
        (["DTA", "OPERATIONAL_AGREEMENT"], True, None)
        
        >>> # No match
        >>> extract_document_tags("/Volumes/.../archive1/RandomFolder/file.pdf",
        ...                       "/Volumes/.../archive1", categories_config)
        (["UNKNOWN"], False, "INFO: No matching category found.")
    """
    # If no config provided, return defaults
    if not categories_config:
        return ([], True, None)
    
    # Get relative path after archive root
    relative_path = extracted_path.replace(archive_root, '').lstrip('/')
    
    # Split into folder parts (exclude file name)
    parts = [p for p in relative_path.split('/') if p]
    if not parts:
        note = "INFO: File path has no parts."
        return (["UNKNOWN"], False, note)
    
    folder_parts = parts[:-1]  # Exclude the filename
    if not folder_parts:
        # File is directly in archive root (no folder structure)
        note = "INFO: File is directly in archive root with no folder structure."
        return (["UNKNOWN"], False, note)
    
    # Search for top-level category (case-insensitive)
    matched_category = None
    category_config = None
    
    for category_name, config in categories_config.items():
        match_name = config.get('match_name', '').upper()
        if not match_name:
            continue
        
        # Search through ALL folder parts
        for part in folder_parts:
            if part.upper() == match_name:
                matched_category = category_name
                category_config = config
                break
        
        if matched_category:
            break
    
    # No category found → tags=["UNKNOWN"], active=False, add note
    if not matched_category:
        note = "INFO: No matching category found."
        if logger:
            logger.info(f"{note} Path: {relative_path}")
        return (["UNKNOWN"], False, note)
    
    # Check for subcategories (supports both folder-based and extension-based matching)
    subcategories = category_config.get('subcategories', {})
    
    if subcategories:
        # Get file extension
        file_name = parts[-1]  # The filename is the last part
        file_ext = os.path.splitext(file_name.lower())[1]
        
        folder_matched_subcats = []
        extension_matched_subcats = []
        
        # Find ALL matching subcategories (both folder and extension-based)
        for subcat_name, subcat_config in subcategories.items():
            match_type = subcat_config.get('match_type', 'folder')  # Default to folder for backward compatibility
            
            if match_type == 'folder':
                # Folder-based matching
                submatch_name = subcat_config.get('match_name', '').upper()
                if submatch_name:
                    # Search through ALL folder parts (case-insensitive)
                    for part in folder_parts:
                        if part.upper() == submatch_name:
                            folder_matched_subcats.append({
                                'name': subcat_name,
                                'config': subcat_config,
                                'match_type': 'folder',
                                'match_value': part
                            })
                            break
            
            elif match_type == 'extension':
                # Extension-based matching
                match_extensions = subcat_config.get('match_extensions', [])
                # Normalize extensions to lowercase with dot prefix
                match_extensions = [ext.lower() if ext.startswith('.') else f'.{ext.lower()}' 
                                   for ext in match_extensions]
                
                if file_ext in match_extensions:
                    extension_matched_subcats.append({
                        'name': subcat_name,
                        'config': subcat_config,
                        'match_type': 'extension',
                        'match_value': file_ext
                    })
        
        # Prioritize folder matches over extension matches
        # If we have folder matches, use those. Otherwise, use extension matches.
        matched_subcats = folder_matched_subcats if folder_matched_subcats else extension_matched_subcats
        
        # Handle results
        if len(matched_subcats) > 1:
            # AMBIGUOUS - Multiple subcategories found
            subcat_names = [m['name'] for m in matched_subcats]
            match_types = [m['match_type'] for m in matched_subcats]
            note = (
                f"WARN: Multiple subcategories found ({', '.join(match_types)} match): "
                f"{', '.join(subcat_names)}. Using first match."
            )
            if logger:
                logger.warning(f"{note} Path: {relative_path}")
            
            # Use first match, but mark as INACTIVE due to ambiguity
            return (
                matched_subcats[0]['config'].get('tags', []),
                False,  # INACTIVE due to ambiguity
                note
            )
        
        elif len(matched_subcats) == 1:
            # Single subcategory found - perfect!
            return (
                matched_subcats[0]['config'].get('tags', []),
                matched_subcats[0]['config'].get('active', True),
                None  # No notes - successful categorization
            )
    
    # No subcategory found - return top-level
    return (
        category_config.get('tags', []),
        category_config.get('active', True),
        None  # No notes - successful categorization
    )


def extract_zip_recursive(
    zip_bytes: bytes,
    base_output_dir_local: str,
    base_output_dir_volumes: str,
    rel_prefix: str,
    manifest_records: List[Dict],
    zip_root_name: str,
    zip_source_path: str,
    level: int = 0,
    supported_extensions: Optional[List[str]] = None,
    categories_config: Optional[Dict] = None,
    logger: Optional[logging.Logger] = None
) -> None:
    """
    Recursively extract a ZIP into base_output_dir_local/rel_prefix.
    Nested ZIPs are extracted into subfolders named after the nested zip file (without extension).
    Each file is recorded into manifest_records with document tags and active flag.
    Only files with supported extensions are extracted (if specified).
    
    Args:
        zip_bytes: Binary content of the ZIP file
        base_output_dir_local: Local filesystem base output directory (/Volumes/...)
        base_output_dir_volumes: Volumes path for manifest (/Volumes/...)
        rel_prefix: Relative prefix for nested extraction
        manifest_records: List to collect manifest records
        zip_root_name: Root ZIP file name (without extension)
        zip_source_path: Source path of the ZIP file (/Volumes/... or dbfs:/Volumes/...)
        level: Nesting level (0 for root ZIP)
        supported_extensions: List of supported file extensions (e.g., ['.pdf', '.xlsx']). 
                            If None, all files are extracted.
        categories_config: Document categorization configuration (optional)
        logger: Logger instance for warnings/info (optional)
    """
    # Convert supported extensions to lowercase for case-insensitive comparison
    if supported_extensions:
        supported_extensions = [ext.lower() if ext.startswith('.') else f'.{ext.lower()}' 
                               for ext in supported_extensions]
    
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
        for info in z.infolist():
            name = info.filename

            # Skip directory entries
            if name.endswith('/'):
                continue
            
            # Skip macOS metadata files and folders
            if '__MACOSX' in name or name.startswith('._') or '/.DS_Store' in name or name == '.DS_Store':
                continue

            # Try to read the file content - handle encryption and other errors
            try:
                data = z.read(name)
            except RuntimeError as e:
                # Handle encrypted files
                error_msg = str(e)
                if 'encrypted' in error_msg.lower() or 'password' in error_msg.lower():
                    logger.error(f"⚠️  ENCRYPTED FILE SKIPPED: {name} - {error_msg}")
                    
                    # Create error record in manifest
                    rel_path_in_zip = name.lstrip('/')
                    relative_output_path = os.path.join(rel_prefix, rel_path_in_zip) if rel_prefix else rel_path_in_zip
                    relative_output_path = relative_output_path.replace("\\", "/")
                    
                    manifest_records.append({
                        "document_id": str(uuid.uuid4()),
                        "zip_source_path": zip_source_path,
                        "extracted_path": None,  # Not extracted
                        "file_extension": os.path.splitext(rel_path_in_zip.lower())[1],
                        "size_bytes": info.file_size,
                        "is_nested_zip": False,
                        "nesting_level": level,
                        "document_tags": [],
                        "active": False,
                        "categorization_notes": f"EXTRACTION_ERROR: {error_msg}",
                        "binary_content": None,
                        "current_status": "EXTRACTION_ERROR",
                        "current_status_timestamp": datetime.now()
                    })
                    continue  # Skip this file and continue with others
                else:
                    # Other runtime errors
                    logger.error(f"⚠️  ERROR READING FILE: {name} - {error_msg}")
                    continue
            except Exception as e:
                # Catch all other exceptions
                logger.error(f"⚠️  UNEXPECTED ERROR READING FILE: {name} - {str(e)}")
                continue

            # Normalize path inside zip
            rel_path_in_zip = name.lstrip('/')

            # If this entry is a nested zip -> recurse
            if rel_path_in_zip.lower().endswith('.zip'):
                nested_folder_name = os.path.splitext(os.path.basename(rel_path_in_zip))[0]
                nested_prefix = os.path.join(rel_prefix, nested_folder_name) if rel_prefix else nested_folder_name

                try:
                    extract_zip_recursive(
                        data,
                        base_output_dir_local=base_output_dir_local,
                        base_output_dir_volumes=base_output_dir_volumes,
                        rel_prefix=nested_prefix,
                        manifest_records=manifest_records,
                        zip_root_name=zip_root_name,
                        zip_source_path=zip_source_path,
                        level=level + 1,
                        supported_extensions=supported_extensions,
                        categories_config=categories_config,
                        logger=logger
                    )
                except Exception as e:
                    # If nested zip extraction fails, log and continue
                    logger.error(f"⚠️  ERROR EXTRACTING NESTED ZIP: {rel_path_in_zip} - {str(e)}")
                    
                    # Create error record for nested zip
                    manifest_records.append({
                        "document_id": str(uuid.uuid4()),
                        "zip_source_path": zip_source_path,
                        "extracted_path": None,
                        "file_extension": ".zip",
                        "size_bytes": info.file_size,
                        "is_nested_zip": True,
                        "nesting_level": level,
                        "document_tags": [],
                        "active": False,
                        "categorization_notes": f"EXTRACTION_ERROR: Nested ZIP extraction failed - {str(e)}",
                        "binary_content": None,
                        "current_status": "EXTRACTION_ERROR",
                        "current_status_timestamp": datetime.now()
                    })
                    continue
            else:
                # Check if file extension is supported
                file_ext = os.path.splitext(rel_path_in_zip.lower())[1]
                
                if supported_extensions and file_ext not in supported_extensions:
                    # Skip unsupported file types
                    print(f"  Skipping unsupported file type: {rel_path_in_zip} (extension: {file_ext})")
                    continue
                
                try:
                    # Regular file -> write to Volumes
                    relative_output_path = os.path.join(rel_prefix, rel_path_in_zip) if rel_prefix else rel_path_in_zip
                    # Normalize to POSIX-style path
                    relative_output_path = relative_output_path.replace("\\", "/")

                    output_path_local = os.path.join(base_output_dir_local, relative_output_path)
                    output_dir_local = os.path.dirname(output_path_local)
                    os.makedirs(output_dir_local, exist_ok=True)

                    with open(output_path_local, 'wb') as f:
                        f.write(data)

                    # Compute volumes path for the extracted file (without dbfs: prefix)
                    output_path_volumes = "/".join([base_output_dir_volumes.rstrip("/"), relative_output_path])
                    
                    # Clean zip_source_path (remove dbfs: prefix if present)
                    clean_source_path = zip_source_path.replace("dbfs:", "") if zip_source_path.startswith("dbfs:") else zip_source_path

                    # Extract document tags and active flag
                    # Archive root is base_output_dir_volumes
                    document_tags, active_flag, categorization_notes = extract_document_tags(
                        extracted_path=output_path_volumes,
                        archive_root=base_output_dir_volumes,
                        categories_config=categories_config,
                        logger=logger
                    )

                    # Generate unique document ID
                    document_id = str(uuid.uuid4())
                    
                    # Encode content to base64 for storage in manifest
                    content_base64 = base64.b64encode(data).decode('utf-8')
                    
                    # Get current timestamp for status
                    extraction_timestamp = datetime.now()

                    # Record into manifest list
                    manifest_records.append({
                        'document_id': document_id,
                        'zip_source_path': clean_source_path,
                        'zip_root_name': zip_root_name,
                        'extracted_path': output_path_volumes,
                        'content_base64': content_base64,
                        'size_bytes': len(data),
                        'nested_level': level,
                        'is_from_nested_zip': bool(level > 0),
                        'file_extension': file_ext,
                        'document_tags': document_tags,
                        'active': active_flag,
                        'categorization_notes': categorization_notes,
                    'current_status': 'READY_FOR_PROCESSING',
                    'current_status_timestamp': extraction_timestamp
                })
                
                except Exception as e:
                    # Handle file writing, encoding, or tagging errors
                    logger.error(f"⚠️  ERROR PROCESSING FILE: {rel_path_in_zip} - {str(e)}")
                    
                    # Create error record
                    relative_output_path = os.path.join(rel_prefix, rel_path_in_zip) if rel_prefix else rel_path_in_zip
                    relative_output_path = relative_output_path.replace("\\", "/")
                    
                    manifest_records.append({
                        "document_id": str(uuid.uuid4()),
                        "zip_source_path": zip_source_path,
                        "extracted_path": None,
                        "file_extension": file_ext,
                        "size_bytes": info.file_size,
                        "is_nested_zip": False,
                        "nesting_level": level,
                        "document_tags": [],
                        "active": False,
                        "categorization_notes": f"EXTRACTION_ERROR: {str(e)}",
                        "binary_content": None,
                        "current_status": "EXTRACTION_ERROR",
                        "current_status_timestamp": datetime.now()
                    })
                    continue  # Continue processing other files


def create_zip_batch_processor(
    spark: SparkSession,
    target_root_path: str,
    manifest_table_full_name: str,
    status_table_full_name: str,
    created_by_principal: str,
    databricks_job_id: Optional[str] = None,
    databricks_job_name: Optional[str] = None,
    databricks_run_id: Optional[str] = None,
    supported_extensions: Optional[List[str]] = None,
    categories_config: Optional[Dict] = None,
    manifest_table_description: Optional[str] = None,
    status_table_description: Optional[str] = None
):
    """
    Create a batch processor function for ZIP file processing
    
    Args:
        spark: SparkSession instance
        target_root_path: Target root path for extraction (/Volumes/... or dbfs:/Volumes/...)
        manifest_table_full_name: Full table name for manifest (catalog.schema.table)
        status_table_full_name: Full table name for document status tracking (catalog.schema.table)
        created_by_principal: Principal (user/service account) running the job
        databricks_job_id: Job ID for lineage tracking
        databricks_run_id: Run ID for lineage tracking
        supported_extensions: List of supported file extensions (e.g., ['.pdf', '.xlsx']). 
                            If None, all files are extracted.
        categories_config: Document categorization configuration (optional)
        manifest_table_description: Description for manifest table (optional)
        status_table_description: Description for status table (optional)
        
    Returns:
        Function to process ZIP file batches
    """
    # Setup logger
    logger = setup_logging("zip_processor")
    # Normalize path - remove dbfs: prefix if present and use /Volumes directly
    if target_root_path.startswith("dbfs:/Volumes/"):
        target_root_local = target_root_path.replace("dbfs:", "")
        target_root_volumes = target_root_path.replace("dbfs:", "")
    elif target_root_path.startswith("/Volumes/"):
        target_root_local = target_root_path
        target_root_volumes = target_root_path
    else:
        raise ValueError(f"Path must start with /Volumes/ or dbfs:/Volumes/, got: {target_root_path}")
    
    def process_zip_batch(batch_df: DataFrame, batch_id: int):
        """
        Process a batch of ZIP files: extract and update manifest
        
        Args:
            batch_df: Batch DataFrame with 'path' and 'content' columns
            batch_id: Batch identifier
        """
        rows = batch_df.select('path', 'content').collect()
        print(f'Processing batch {batch_id}, num files = {len(rows)}')
        
        if supported_extensions:
            print(f'Only extracting files with extensions: {", ".join(supported_extensions)}')

        all_manifest_records = []

        for row in rows:
            src_path_dbfs = row['path']
            content = row['content']

            zip_file_name = os.path.basename(src_path_dbfs)
            zip_base_name = os.path.splitext(zip_file_name)[0]

            # Create a folder under the target volume for this zip
            zip_output_dir_local = os.path.join(target_root_local, zip_base_name)
            os.makedirs(zip_output_dir_local, exist_ok=True)

            zip_output_dir_volumes = f'{target_root_volumes}/{zip_base_name}'.rstrip('/')

            print(f'Extracting {src_path_dbfs} -> {zip_output_dir_volumes}')

            manifest_records = []
            extract_zip_recursive(
                zip_bytes=content,
                base_output_dir_local=zip_output_dir_local,
                base_output_dir_volumes=zip_output_dir_volumes,
                rel_prefix='',
                manifest_records=manifest_records,
                zip_root_name=zip_base_name,
                zip_source_path=src_path_dbfs,
                level=0,
                supported_extensions=supported_extensions,
                categories_config=categories_config,
                logger=logger
            )

            all_manifest_records.extend(manifest_records)

        print(f'Finished extraction for batch {batch_id}. Files extracted: {len(all_manifest_records)}')

        if all_manifest_records:
            # Create status records for each document
            all_status_records = []
            for manifest_record in all_manifest_records:
                status_record = {
                    'document_id': manifest_record['document_id'],
                    'status': 'READY_FOR_PROCESSING',
                    'status_timestamp': manifest_record['current_status_timestamp'],
                    'error_message': None,
                    'processing_duration_seconds': None,
                    'retry_count': 0,
                    'processing_metadata': None
                }
                all_status_records.append(status_record)
            
            # Create DataFrames with explicit schemas
            manifest_df = spark.createDataFrame(all_manifest_records, schema=get_manifest_schema())
            manifest_df = manifest_df.withColumn('batch_id', lit(batch_id))
            
            status_df = spark.createDataFrame(all_status_records, schema=get_document_status_schema())
            
            # Write both tables with ACID guarantees (Delta Lake ensures atomicity)
            # Add audit columns and save manifest
            save_with_audit(
                df=manifest_df,
                table_name=manifest_table_full_name,
                created_by_principal=created_by_principal,
                databricks_job_id=databricks_job_id,
                databricks_job_name=databricks_job_name,
                databricks_run_id=databricks_run_id,
                mode='append',
                table_description=manifest_table_description
            )
            print(f'Appended {manifest_df.count()} rows to manifest table {manifest_table_full_name}.')
            
            # Add audit columns and save status
            save_with_audit(
                df=status_df,
                table_name=status_table_full_name,
                created_by_principal=created_by_principal,
                databricks_job_id=databricks_job_id,
                databricks_job_name=databricks_job_name,
                databricks_run_id=databricks_run_id,
                mode='append',
                table_description=status_table_description
            )
            print(f'Appended {status_df.count()} rows to status table {status_table_full_name}.')
        else:
            print('No files extracted in this batch; manifest not updated.')
    
    return process_zip_batch


def create_zip_autoloader_stream(
    spark: SparkSession,
    source_path: str,
    schema: Optional[StructType] = None
) -> DataFrame:
    """
    Create an Auto Loader streaming DataFrame for ZIP files
    
    Args:
        spark: SparkSession instance
        source_path: Source path (/Volumes/... or dbfs:/Volumes/...) - both formats work
        schema: Optional schema (defaults to binary file schema)
        
    Returns:
        Streaming DataFrame configured for ZIP file ingestion
    """
    if schema is None:
        schema = get_binary_file_schema()
    
    return (
        spark.readStream
             .format("cloudFiles")
             .option("cloudFiles.format", "binaryFile")
             .option("cloudFiles.includeExistingFiles", "true")
             .schema(schema)
             .load(source_path)
    )


# ============================================================================
# Audit Column Management
# ============================================================================

def add_audit_columns(
    df: DataFrame,
    created_by_principal: str,
    databricks_job_id: Optional[str] = None,
    databricks_job_name: Optional[str] = None,
    databricks_run_id: Optional[str] = None,
    is_new_record_column: Optional[str] = None
) -> DataFrame:
    """
    Add audit columns to a DataFrame for tracking creation and updates.
    
    This function adds seven audit columns:
    - created_by_principal: User/service principal who created the record
    - created_ts: Timestamp when record was first created
    - databricks_job_id: Job ID that created the record
    - databricks_job_name: Job name that created the record
    - databricks_run_id: Run ID that created the record
    - last_updated_by_principal: User/service principal who last updated the record
    - last_updated_ts: Timestamp when record was last updated
    
    Logic:
    - For new records: Both created_* and last_updated_* are set to current values
    - For existing records: created_* values are preserved, last_updated_* are updated
    
        Args:
        df: Input DataFrame
        created_by_principal: Principal (user/service account) making the change
        databricks_job_id: Job ID for lineage tracking
        databricks_job_name: Job name for lineage tracking
        databricks_run_id: Run ID for lineage tracking
        is_new_record_column: Optional column name that indicates if record is new (True/False).
                             If None, assumes all records are new.
    
    Returns:
        DataFrame with audit columns added
        
    Example:
        # For new records (insert)
        df_with_audit = add_audit_columns(
            df, 
            created_by_principal="user@example.com",
            databricks_job_id="12345",
            databricks_job_name="job_cds_zip_processor_dev",
            databricks_run_id="67890"
        )
        
        # For merge operation with existing records
        df_with_audit = add_audit_columns(
            df, 
            created_by_principal="user@example.com",
            databricks_job_id="12345",
            databricks_job_name="job_cds_zip_processor_dev",
            databricks_run_id="67890",
            is_new_record_column="is_new"
        )
    """
    from pyspark.sql.functions import when, col, coalesce
    
    if is_new_record_column and is_new_record_column in df.columns:
        # Merge scenario: set created_* only for new records, always update last_updated_*
        df = df.withColumn(
            "created_by_principal",
            when(col(is_new_record_column), lit(created_by_principal))
            .otherwise(coalesce(col("created_by_principal"), lit(created_by_principal)))
        ).withColumn(
            "created_ts",
            when(col(is_new_record_column), current_timestamp())
            .otherwise(coalesce(col("created_ts"), current_timestamp()))
        ).withColumn(
            "databricks_job_id",
            when(col(is_new_record_column), lit(databricks_job_id))
            .otherwise(coalesce(col("databricks_job_id"), lit(databricks_job_id)))
        ).withColumn(
            "databricks_job_name",
            when(col(is_new_record_column), lit(databricks_job_name))
            .otherwise(coalesce(col("databricks_job_name"), lit(databricks_job_name)))
        ).withColumn(
            "databricks_run_id",
            when(col(is_new_record_column), lit(databricks_run_id))
            .otherwise(coalesce(col("databricks_run_id"), lit(databricks_run_id)))
        ).withColumn(
            "last_updated_by_principal",
            lit(created_by_principal)
        ).withColumn(
            "last_updated_ts",
            current_timestamp()
        )
    else:
        # Insert scenario: all records are new
        df = df.withColumn("created_by_principal", lit(created_by_principal)) \
               .withColumn("created_ts", current_timestamp()) \
               .withColumn("databricks_job_id", lit(databricks_job_id)) \
               .withColumn("databricks_job_name", lit(databricks_job_name)) \
               .withColumn("databricks_run_id", lit(databricks_run_id)) \
               .withColumn("last_updated_by_principal", lit(created_by_principal)) \
               .withColumn("last_updated_ts", current_timestamp())
    
    return df


def save_with_audit(
    df: DataFrame,
    table_name: str,
    created_by_principal: str,
    databricks_job_id: Optional[str] = None,
    databricks_job_name: Optional[str] = None,
    databricks_run_id: Optional[str] = None,
    mode: str = "append",
    merge_keys: Optional[List[str]] = None,
    table_description: Optional[str] = None
) -> None:
    """
    Save DataFrame to Delta table with automatic audit column management and optional table description.
    
    Supports three modes:
    1. append: Adds audit columns and appends to table
    2. overwrite: Adds audit columns and overwrites table
    3. merge: Performs Delta merge to update existing records and insert new ones
    
    Args:
        df: Input DataFrame
        table_name: Target table name (catalog.schema.table)
        created_by_principal: Principal making the change
        databricks_job_id: Job ID for lineage tracking
        databricks_run_id: Run ID for lineage tracking
        mode: Save mode - "append", "overwrite", or "merge"
        merge_keys: List of columns to use as merge keys (required for merge mode)
        table_description: Optional table description to set via TBLPROPERTIES comment
        
    Example:
        # Simple append
        save_with_audit(
            df, 
            "catalog.schema.table", 
            "user@example.com",
            databricks_job_id="12345",
            databricks_run_id="67890",
            mode="append"
        )
        
        # Merge/upsert
        save_with_audit(
            df, 
            "catalog.schema.table", 
            "user@example.com",
            databricks_job_id="12345",
            databricks_run_id="67890",
            mode="merge",
            merge_keys=["id"]
        )
    """
    from delta.tables import DeltaTable
    
    spark = df.sparkSession
    
    if mode in ["append", "overwrite"]:
        # Add audit columns for new records
        df_with_audit = add_audit_columns(
            df, 
            created_by_principal,
            databricks_job_id,
            databricks_job_name,
            databricks_run_id
        )
        
        # Save to table
        df_with_audit.write.format("delta").mode(mode).saveAsTable(table_name)
        print(f"Saved {df.count()} records to {table_name} (mode: {mode})")
        
        # Set table description if provided
        if table_description:
            # Escape single quotes in description
            escaped_description = table_description.replace("'", "''")
            spark.sql(f"""
                ALTER TABLE {table_name}
                SET TBLPROPERTIES ('comment' = '{escaped_description}')
            """)
            print(f"Table description set for {table_name}")
        
    elif mode == "merge":
        if not merge_keys:
            raise ValueError("merge_keys required for merge mode")
        
        # Check if table exists
        table_exists = spark.catalog.tableExists(table_name)
        
        if not table_exists:
            # Table doesn't exist, create it
            df_with_audit = add_audit_columns(
                df, 
                created_by_principal,
                databricks_job_id,
                databricks_job_name,
                databricks_run_id
            )
            df_with_audit.write.format("delta").mode("overwrite").saveAsTable(table_name)
            print(f"Created new table: {table_name}")
            
            # Set table description if provided
            if table_description:
                escaped_description = table_description.replace("'", "''")
                spark.sql(f"""
                    ALTER TABLE {table_name}
                    SET TBLPROPERTIES ('comment' = '{escaped_description}')
                """)
                print(f"Table description set for {table_name}")
            return
        
        # Table exists, perform merge
        delta_table = DeltaTable.forName(spark, table_name)
        
        # Add audit columns to source
        source_with_audit = add_audit_columns(
            df, 
            created_by_principal,
            databricks_job_id,
            databricks_job_name,
            databricks_run_id
        )
        
        # Build merge condition
        merge_condition = " AND ".join([f"target.{key} = source.{key}" for key in merge_keys])
        
        # Get data columns (exclude audit columns for update set)
        data_columns = [c for c in df.columns]
        
        # Build update set - update data columns + last_updated_*
        # Preserve created_* from target
        update_set = {}
        for col in data_columns:
            update_set[col] = f"source.{col}"
        update_set["last_updated_by_principal"] = f"source.last_updated_by_principal"
        update_set["last_updated_ts"] = f"source.last_updated_ts"
        # created_by_principal and created_ts will keep target values (not in update_set)
        
        # Build insert set (all columns including audit)
        insert_columns = source_with_audit.columns
        insert_set = {col: f"source.{col}" for col in insert_columns}
        
        # Execute merge
        merge_builder = delta_table.alias("target").merge(
            source_with_audit.alias("source"),
            merge_condition
        )
        
        merge_builder = merge_builder.whenMatchedUpdate(set=update_set)
        merge_builder = merge_builder.whenNotMatchedInsert(values=insert_set)
        
        merge_builder.execute()
        print(f"Merged data into table: {table_name}")
        
    else:
        raise ValueError(f"Unsupported mode: {mode}. Use 'append', 'overwrite', or 'merge'")

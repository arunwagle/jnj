"""
Excel Processing Utilities for Clinical Data Standards Framework

This module contains all Excel-specific functions for processing tsDTA files,
including schema definitions, header detection, column mapping, and metadata extraction.
"""

import re
import pandas as pd
from io import BytesIO
from typing import Dict, List, Tuple
from pyspark.sql.types import StructType, StructField, StringType, IntegerType


# ============================================================================
# Excel Schema Definitions
# ============================================================================

def get_excel_sheets_schema() -> StructType:
    """
    Get the schema for Excel sheet metadata catalog table.
    Stores one row per sheet per document - metadata only, NO data content.
    
    NOTE: Audit columns (created_by_principal, created_ts, last_updated_by_principal,
    last_updated_ts, databricks_job_id, databricks_run_id) are added automatically 
    by save_with_audit() function - do NOT include them here.
    
    Returns:
        StructType schema for md_dta_excel_file_raw table
    """
    return StructType([
        StructField("document_id",          StringType(),    False),  # Unique sheet ID
        StructField("parent_document_id",   StringType(),    False),  # References parent document in md_dta_trial_dta_history
        StructField("source_file_path",     StringType(),    True),   # For reference
        StructField("sheet_name",           StringType(),    False),  # Excel sheet name
        StructField("sheet_index",          IntegerType(),   False),  # 0-based sheet position
        StructField("sheet_category",       StringType(),    True),   # Categorized sheet type
        StructField("trial_id",             StringType(),    True),   # From Version History sheet
        StructField("data_stream_type",     StringType(),    True),   # From Version History sheet
        StructField("data_provider_name",   StringType(),    True)    # From Version History sheet (EDP Name)
    ])


# ============================================================================
# Sheet Categorization
# ============================================================================

def categorize_sheet_name(sheet_name: str) -> str:
    """
    Categorize Excel sheet based on its name for tsDTA processing.
    
    Uses regex patterns to flexibly match category names with words in between.
    For example: "transfer_xyz_metadata", "metadata_abc_transfer", "version blah blah history"
    
    Args:
        sheet_name: Name of the Excel sheet
        
    Returns:
        Category string for downstream processing:
        - transfer_metadata (matches "transfer...metadata" or "metadata...transfer")
        - test_concepts (matches "test...concept" or "concept...test")
        - version_history (matches "version...history")
        - visits_and_timepoints (matches "visit...timepoint" or "timepoint...visit")
        - codelists (matches "codelist" or "code...list")
        - <actual_sheet_name> (if no match found)
        
    Examples:
        >>> categorize_sheet_name("Transfer Metadata v1")
        'transfer_metadata'
        >>> categorize_sheet_name("transfer_xyz_metadata")
        'transfer_metadata'
        >>> categorize_sheet_name("metadata_abc_transfer")
        'transfer_metadata'
        >>> categorize_sheet_name("Version Blah Blah History")
        'version_history'
        >>> categorize_sheet_name("Test Concepts - Lab")
        'test_concepts'
        >>> categorize_sheet_name("Study Design")
        'Study Design'
    """
    if not sheet_name:
        return "unknown"
    
    name_lower = sheet_name.strip().lower()
    
    # Regex patterns for flexible matching (order matters - most specific first)
    
    # "transfer...metadata" or "metadata...transfer" (with _ or spaces or any chars)
    if re.search(r'transfer[_\s].*metadata|metadata[_\s].*transfer', name_lower):
        return "transfer_metadata"
    
    # "test...concept" or "concept...test"
    if re.search(r'test[_\s].*concept|concept[_\s].*test', name_lower):
        return "test_concepts"
    
    # "version...history" (e.g., "version blah blah history")
    if re.search(r'version.*history', name_lower):
        return "version_history"
    
    # "visit" and "timepoint" in any order
    if re.search(r'visit.*timepoint|timepoint.*visit', name_lower):
        return "visits_and_timepoints"
    
    # "codelist" or "code...list"
    if re.search(r'codelist|code[_\s].*list', name_lower):
        return "codelists"
    
    # Fallback: use actual sheet name as category (preserves original case)
    return sheet_name.strip()


# ============================================================================
# Version History Metadata Extraction
# ============================================================================

def extract_version_history_metadata(excel_bytes: bytes, file_extension: str) -> dict:
    """
    Extract trial_id, data_stream_type, and data_provider_name from Version History sheet.
    
    This function:
    1. Reads all sheets in the Excel file
    2. Finds the sheet with "version history" in its name (case-insensitive)
    3. Searches for specific field labels and extracts values from the same row
    4. Strips square brackets from values (e.g., "[VALUE]" → "VALUE")
    
    Field Mapping:
        - "Trial ID" → trial_id
        - "Data Stream Type" → data_stream_type
        - "(E)DP Name" / "DP Name" / "EDP Name" → data_provider_name
    
    Args:
        excel_bytes: Byte content of the Excel file
        file_extension: File extension (.xls or .xlsx) to determine engine
        
    Returns:
        dict: {
            "trial_id": str or "UNKNOWN",
            "data_stream_type": str or "UNKNOWN",
            "data_provider_name": str or "UNKNOWN"
        }
    """
    def clean_value(value: str) -> str:
        """Strip square brackets from value if present."""
        value = value.strip()
        if value.startswith('[') and value.endswith(']'):
            return value[1:-1].strip()
        return value
    
    # Default values
    result = {
        "trial_id": "UNKNOWN",
        "data_stream_type": "UNKNOWN",
        "data_provider_name": "UNKNOWN"
    }
    
    try:
        # Select Excel engine based on file extension
        engine = 'xlrd' if file_extension.lower() == '.xls' else 'openpyxl'
        
        # Read Excel file
        xl = pd.ExcelFile(BytesIO(excel_bytes), engine=engine)
        
        # Find Version History sheet
        version_sheet = None
        for sheet_name in xl.sheet_names:
            if "version" in sheet_name.lower() and "history" in sheet_name.lower():
                version_sheet = sheet_name
                break
        
        if not version_sheet:
            return result
        
        # Read the Version History sheet without header to get all cells
        df = pd.read_excel(xl, sheet_name=version_sheet, header=None)
        
        # Search for field labels and extract values
        for idx, row in df.iterrows():
            row_str = "|".join([str(cell).lower() if pd.notna(cell) else "" for cell in row])
            
            # Check for Trial ID
            if "trial id" in row_str and result["trial_id"] == "UNKNOWN":
                for col_idx, cell in enumerate(row):
                    if pd.notna(cell) and "trial id" in str(cell).lower():
                        # Get first non-empty value in this row after the label
                        for val_idx in range(col_idx + 1, len(row)):
                            if pd.notna(row.iloc[val_idx]) and str(row.iloc[val_idx]).strip():
                                result["trial_id"] = clean_value(str(row.iloc[val_idx]))
                                break
                        break
            
            # Check for Data Stream Type
            if "data stream type" in row_str and result["data_stream_type"] == "UNKNOWN":
                for col_idx, cell in enumerate(row):
                    if pd.notna(cell) and "data stream type" in str(cell).lower():
                        # Get first non-empty value in this row after the label
                        for val_idx in range(col_idx + 1, len(row)):
                            if pd.notna(row.iloc[val_idx]) and str(row.iloc[val_idx]).strip():
                                result["data_stream_type"] = clean_value(str(row.iloc[val_idx]))
                                break
                        break
            
            # Check for (E)DP Name / DP Name / EDP Name
            if (("edp name" in row_str or "dp name" in row_str or "(e)dp name" in row_str) 
                and result["data_provider_name"] == "UNKNOWN"):
                for col_idx, cell in enumerate(row):
                    cell_lower = str(cell).lower() if pd.notna(cell) else ""
                    if ("edp name" in cell_lower or "dp name" in cell_lower or 
                        "(e)dp name" in cell_lower):
                        # Get first non-empty value in this row after the label
                        for val_idx in range(col_idx + 1, len(row)):
                            if pd.notna(row.iloc[val_idx]) and str(row.iloc[val_idx]).strip():
                                result["data_provider_name"] = clean_value(str(row.iloc[val_idx]))
                                break
                        break
        
        return result
        
    except Exception as e:
        # Log error but return UNKNOWN values
        print(f"Warning: Could not extract Version History metadata: {str(e)}")
        return result


# ============================================================================
# Header Detection and Filtering
# ============================================================================

def find_excel_header_row(df, required_patterns: list, peek_rows: int = 15) -> int:
    """
    Generic function to find the header row in an Excel sheet.
    
    Searches the first N rows for a row containing ALL required column patterns.
    Uses case-insensitive regex matching for flexibility.
    
    Args:
        df: Pandas DataFrame (read with header=None)
        required_patterns: List of regex patterns that must ALL be present in the header row
        peek_rows: Number of rows to search (default: 15)
        
    Returns:
        int: Row index of the header row, or 0 if not found
        
    Examples:
        # For Transfer Metadata sheets
        >>> raw_df = pd.read_excel(file, sheet_name="Transfer Metadata", header=None)
        >>> header_row = find_excel_header_row(raw_df, [
        ...     r'transfer.*variable.*name',
        ...     r'format'
        ... ])
        >>> data_df = pd.read_excel(file, sheet_name="Transfer Metadata", header=header_row)
        
        # For Codelist sheets
        >>> raw_df = pd.read_excel(file, sheet_name="Codelists", header=None)
        >>> header_row = find_excel_header_row(raw_df, [
        ...     r'codelist|reference',
        ...     r'values?|code'
        ... ])
        
        # For any sheet with specific columns
        >>> header_row = find_excel_header_row(df, [r'column_a', r'column_b'])
    """
    max_rows = min(peek_rows, len(df))
    
    for i in range(max_rows):
        # Join all cell values in the row (case-insensitive)
        row_str = "|".join(str(x).lower() if pd.notna(x) else "" for x in df.iloc[i].values)
        
        # Check if ALL required patterns are present
        all_found = True
        for pattern in required_patterns:
            if not re.search(pattern, row_str):
                all_found = False
                break
        
        if all_found:
            return i
    
    # Not found - default to row 0
    return 0


def get_header_filter_patterns(sheet_type: str) -> dict:
    """
    Get header text patterns to filter out from data rows.
    
    Different sheet types have different header patterns that may appear
    in data due to merged cells, formatting, or Excel quirks.
    
    Args:
        sheet_type: Type of sheet ("transfer_metadata", "codelists", etc.)
        
    Returns:
        dict: Column names as keys, list of regex patterns as values
        
    Example:
        >>> patterns = get_header_filter_patterns('transfer_metadata')
        >>> # Returns patterns for detecting header rows in transfer metadata sheets
        >>> # Use these to filter out rows that contain header text
    """
    if sheet_type == "transfer_metadata":
        return {
            'transfer_variable_name': [
                r'^transfer.*variable.*name',
                r'^document.*variable',
                r'^variable.*name',
                r'^variable.*must.*unique'
            ],
            'transfer_file_order': [
                r'^order.*which.*variable',
                r'^transfer.*file.*order',
                r'^order.*display',
                r'^order.*in.*which'
            ],
            'data_type_format': [
                r'^specify.*text.*numeric',
                r'^format$',
                r'^data.*type'
            ],
            'transfer_variable_label': [
                r'^transfer.*variable.*label',
                r'^variable.*full.*name',
                r'^transfer.*variable.*full'
            ]
        }
    elif sheet_type == "codelists":
        return {
            'codelist_reference': [
                r'^codelist.*ref',
                r'^reference$',
                r'^codelist$'
            ],
            'code_value': [
                r'^values?.*delivered',
                r'^values?.*received',
                r'^values?$',
                r'^code$'
            ]
        }
    
    # Default: empty dict (no filtering)
    return {}


# ============================================================================
# Field Parsing and Validation
# ============================================================================

def parse_max_length(value) -> tuple:
    """
    Parse maximum length from anticipated max length field.
    
    Args:
        value: Value from "Anticipated Maximum Length" column
        
    Returns:
        tuple: (max_length_int, note_string)
            - If value is numeric: (int, None)
            - If value is text: (None, text)
            - If value is None/NaN: (None, None)
            
    Examples:
        >>> parse_max_length("255")
        (255, None)
        >>> parse_max_length("Variable")
        (None, "Variable")
        >>> parse_max_length(None)
        (None, None)
    """
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return (None, None)
    
    s = str(value).strip()
    # Try to match pure numeric value
    m = re.match(r"^(\d+)$", s)
    
    if m:
        return (int(m.group(1)), None)
    else:
        return (None, s)


def is_required_field(value) -> bool:
    """
    Check if a field is required based on "Populate for All Records" value.
    
    Considers the following as TRUE (required):
    - "X", "x"
    - "Yes", "YES", "yes"
    - "Y", "y"
    - "True", "TRUE", "true"
    - "Applicable", "APPLICABLE", "applicable"
    
    Args:
        value: Value from "Populate for All Records" column
        
    Returns:
        bool: True if field is required, False otherwise
        
    Examples:
        >>> is_required_field("X")
        True
        >>> is_required_field("Yes")
        True
        >>> is_required_field("No")
        False
        >>> is_required_field(None)
        False
    """
    if value is None or pd.isna(value):
        return False
    
    val_str = str(value).strip().lower()
    if val_str == '':
        return False
        
    TRUE_SET = {"x", "yes", "y", "true", "applicable"}
    return val_str in TRUE_SET


def is_transfer_key_field(value) -> bool:
    """
    Check if a field is a transfer file key based on "Transfer File Key" value.
    
    Considers "X" or "x" as TRUE (is a key field).
    
    Args:
        value: Value from "Transfer File Key" column
        
    Returns:
        bool: True if field is a transfer file key, False otherwise
        
    Examples:
        >>> is_transfer_key_field("X")
        True
        >>> is_transfer_key_field("x")
        True
        >>> is_transfer_key_field("")
        False
        >>> is_transfer_key_field(None)
        False
    """
    if value is None or pd.isna(value):
        return False
    
    val_str = str(value).strip().upper()
    if val_str == '':
        return False
        
    return val_str == "X"


# ============================================================================
# Column Mapping Functions
# ============================================================================

def get_transfer_metadata_column_map() -> dict:
    """
    Get column name mapping for transfer metadata Excel sheets.
    
    DEPRECATED: Use get_transfer_metadata_flexible_mapper() for flexible regex-based matching.
    
    Maps Excel column headers to standardized field names for processing.
    
    Returns:
        dict: Mapping of Excel column names to standardized field names
        
    Example:
        >>> col_map = get_transfer_metadata_column_map()
        >>> df = df.rename(columns=col_map)
    """
    return {
        "Transfer file order ": "transfer_file_order",
        "Transfer file order": "transfer_file_order",
        "Transfer variable name": "transfer_variable_name",
        "Transfer variable label": "transfer_variable_label",
        "Format": "data_type_format",
        "Anticipated Maximum Length": "anticipated_max_length_raw",
        "Description of Transfer Variable Use": "variable_description",
        "STANDARD Transfer Variable User Instructions for (External) Data Providers": "provider_instructions_standard",
        "Description of transfer variable use AT TRIAL LEVEL": "trial_level_use_description",
        "Unique Sample/Assessment Identifier": "unique_sample_assessment_identifier",
        "Transfer File Key": "transfer_file_key",
        "Populate for All Records": "populate_for_all_records_raw",
        "Example Values": "example_values",
        "Test Concepts": "test_concepts",
        "Controlled Terminology": "controlled_terminology_raw",
        "Unblinding": "unblinding"
    }


def get_transfer_metadata_flexible_mapper(df_columns: list) -> tuple:
    """
    Flexible column mapping using case-insensitive regex patterns.
    
    Handles variations in Excel column headers by using regex pattern matching.
    Distinguishes between required and optional columns.
    Prevents duplicate mappings by using first-match-wins strategy.
    
    Args:
        df_columns: List of column names from the Excel DataFrame
        
    Returns:
        tuple: (column_map dict, missing_required set)
            - column_map: Dict mapping actual Excel column names to standardized names
            - missing_required: Set of required standardized column names that weren't found
            
    Example:
        >>> col_map, missing = get_transfer_metadata_flexible_mapper(df.columns)
        >>> if missing:
        >>>     print(f"Missing required columns: {missing}")
        >>> df_renamed = df.rename(columns=col_map)
    """
    # Define patterns in priority order: standardized_name -> (required, [regex_patterns])
    # More specific patterns first to avoid mismatches
    patterns = {
        'transfer_file_order': (True, [r'order.*variables.*displayed', r'transfer.*file.*order', r'file.*order']),
        'transfer_variable_name': (True, [r"document.*\(e\)dp.*transfer.*variable.*name", r'transfer.*variable.*name', r"variable.*names?.*must.*be.*unique"]),
        'transfer_variable_label': (False, [r'transfer.*variable.*full.*name', r'variable.*full.*name', r'transfer.*variable.*label']),
        'data_type_format': (True, [r"specify.*text.*numeric.*date", r'data.*type.*format', r'^format$']),
        'anticipated_max_length_raw': (True, [r'anticipated.*maximum.*variable.*length', r'anticipated.*max.*length', r'maximum.*length']),
        'transfer_file_key': (True, [
            r'transfer.*file.*key',
            r'file.*key',
            r'key.*variable',
            r'primary.*key',
            r'^key$',
            r'unique.*key'
        ]),
        'populate_for_all_records_raw': (True, [
            r'populate.*all.*records',
            r'required.*all',
            r'mandatory',
            r'applicable.*all'
        ]),
        
        'variable_description': (False, [r'description.*transfer.*variable.*use', r'description']),
        'example_values': (False, [r'example.*values?', r'examples?']),
        'test_concepts': (False, [r'test.*concepts?']),
        'controlled_terminology_raw': (False, [r'controlled.*terminology', r'terminology']),
    }
    
    column_map = {}
    found_required = set()
    mapped_std_names = set()  # Track which standardized names have been used
    
    for col in df_columns:
        col_lower = str(col).strip().lower()
        # Remove newlines and extra spaces for better matching
        col_lower = ' '.join(col_lower.split())
        
        for std_name, (is_required, regex_list) in patterns.items():
            # Skip if this standardized name already mapped (prevent duplicates)
            if std_name in mapped_std_names:
                continue
                
            for pattern in regex_list:
                if re.search(pattern, col_lower):
                    column_map[col] = std_name
                    mapped_std_names.add(std_name)
                    if is_required:
                        found_required.add(std_name)
                    break
            
            if col in column_map:
                break
    
    # Check for missing required columns
    required_cols = {k for k, (req, _) in patterns.items() if req}
    missing_required = required_cols - found_required
    
    return column_map, missing_required


def get_codelist_flexible_mapper(df_columns: list) -> tuple:
    """
    Flexible column mapping for codelist sheets using case-insensitive regex.
    
    Maps codelist reference, values, and optional SDTM value columns.
    Prevents duplicate mappings by using first-match-wins strategy.
    
    Args:
        df_columns: List of column names from the Excel DataFrame
        
    Returns:
        tuple: (column_map dict, missing_required set)
            - column_map: Dict mapping actual Excel column names to standardized names
            - missing_required: Set of required standardized column names that weren't found
            
    Example:
        >>> col_map, missing = get_codelist_flexible_mapper(df.columns)
        >>> if missing:
        >>>     print(f"Missing required columns: {missing}")
        >>> df_renamed = df.rename(columns=col_map)
    """
    patterns = {
        'codelist_reference': (True, [
            r'codelist.*ref',
            r'^codelist$',
            r'reference',
            r'variable.*name',
            r'transfer.*variable'
        ]),
        'code_value': (True, [
            r'values?.*delivered',
            r'values?.*received',
            r'values?.*as.*delivered',
            r'^values?$',
            r'code',
            r'term'
        ]),
        'sdtm_value': (False, [
            r'value.*mapped.*sdtm',
            r'sdtm.*value',
            r'to.*sdtm',
            r'mapped.*to.*sdtm'
        ])
    }
    
    column_map = {}
    found_required = set()
    mapped_std_names = set()  # Track which standardized names have been used
    
    for col in df_columns:
        col_lower = str(col).strip().lower()
        # Remove newlines and extra spaces for better matching
        col_lower = ' '.join(col_lower.split())
        
        for std_name, (is_required, regex_list) in patterns.items():
            # Skip if this standardized name already mapped (prevent duplicates)
            if std_name in mapped_std_names:
                continue
                
            for pattern in regex_list:
                if re.search(pattern, col_lower):
                    column_map[col] = std_name
                    mapped_std_names.add(std_name)
                    if is_required:
                        found_required.add(std_name)
                    break
            
            if col in column_map:
                break
    
    required_cols = {k for k, (req, _) in patterns.items() if req}
    missing_required = required_cols - found_required
    
    return column_map, missing_required



-- ============================================================================
-- Catalog and Schema Setup SQL
-- ============================================================================
-- Purpose: Create catalog and schemas if they don't exist
-- Use Case: clinical_data_standards
-- ============================================================================

-- Create catalog if it doesn't exist
CREATE CATALOG IF NOT EXISTS dta_poc
COMMENT 'Catalog for clinical_data_standards use case';

-- Set current catalog
USE CATALOG dta_poc;

-- Create Bronze schema (raw/landing zone)
CREATE SCHEMA IF NOT EXISTS bronze_md
COMMENT 'Bronze layer - raw data ingestion';

-- Create Silver schema (cleaned/processed)
CREATE SCHEMA IF NOT EXISTS silver_md
COMMENT 'Silver layer - cleaned and validated data';

-- Create Gold schema (business-level aggregates)
CREATE SCHEMA IF NOT EXISTS gold_md
COMMENT 'Gold layer - business-level aggregates';

-- Grant permissions (optional - customize as needed)
GRANT USE CATALOG ON CATALOG dta_poc TO `arun.wagle@databricks.com`;
GRANT USE SCHEMA ON SCHEMA dta_poc.bronze_md TO `arun.wagle@databricks.com`;
GRANT USE SCHEMA ON SCHEMA dta_poc.silver_md TO `arun.wagle@databricks.com`;
GRANT USE SCHEMA ON SCHEMA dta_poc.gold_md TO `arun.wagle@databricks.com`;

-- Display setup summary
SELECT 
  '✅ Setup Complete' as status,
  'dta_poc' as catalog,
  'bronze_md, silver_md, gold_md' as schemas_created;


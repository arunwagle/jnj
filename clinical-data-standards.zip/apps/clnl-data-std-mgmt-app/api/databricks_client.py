"""
Databricks API Client
Provides integration with Databricks Jobs API to fetch real-time job run data.
"""

import os
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import RunLifeCycleState, RunResultState
from databricks.sdk.service.sql import StatementState


class DatabricksSQLClient:
    """Client for executing SQL queries against Databricks SQL Warehouse"""
    
    def __init__(self, warehouse_id: str):
        """
        Initialize SQL client.
        
        Args:
            warehouse_id: SQL Warehouse ID for executing queries
        """
        self.w = WorkspaceClient()
        self.warehouse_id = warehouse_id
        print(f"DEBUG: DatabricksSQLClient initialized for warehouse: {warehouse_id}")
    
    def execute_query(self, query: str) -> List[Dict]:
        """
        Execute SQL query and return results.
        
        Args:
            query: SQL query string
        
        Returns:
            List of dictionaries (one per row)
        """
        try:
            print(f"DEBUG: Executing SQL query...")
            
            statement = self.w.statement_execution.execute_statement(
                warehouse_id=self.warehouse_id,
                statement=query,
                wait_timeout="30s"
            )
            
            print(f"DEBUG: Query status: {statement.status.state}")
            
            # Extract column names
            column_names = [col.name for col in statement.manifest.schema.columns] if statement.manifest else []
            
            # Extract rows
            results = []
            if statement.result and statement.result.data_array:
                for row in statement.result.data_array:
                    row_dict = {column_names[i]: value for i, value in enumerate(row)}
                    results.append(row_dict)
            
            print(f"DEBUG: Query returned {len(results)} rows")
            return results
            
        except Exception as e:
            print(f"ERROR in execute_query: {str(e)}")
            import traceback
            traceback.print_exc()
            return []


class DatabricksJobsClient:
    """Client for interacting with Databricks Jobs API and SQL queries"""
    
    def __init__(self, warehouse_id: Optional[str] = None):
        """
        Initialize Databricks client.
        Uses default authentication (environment variables or app credentials).
        
        Args:
            warehouse_id: SQL Warehouse ID for running queries (optional)
        """
        print("DEBUG: Initializing WorkspaceClient...")
        try:
            self.w = WorkspaceClient()
            self.warehouse_id = warehouse_id
            print("DEBUG: WorkspaceClient initialized successfully")
            # Test the connection
            try:
                current_user = self.w.current_user.me()
                print(f"DEBUG: Authenticated as: {current_user.user_name}")
            except Exception as e:
                print(f"WARNING: Could not verify authentication: {str(e)}")
        except Exception as e:
            print(f"ERROR: Failed to initialize WorkspaceClient: {str(e)}")
            raise
    
    def get_active_job_ids_from_table(
        self,
        catalog: str = "aira",
        schema: str = "bronze_md",
        table: str = "document_status"
    ) -> List[Dict]:
        """
        Get distinct job IDs and names from document_status table.
        This gives us only the jobs that have actually processed data.
        
        Args:
            catalog: Catalog name (default: "aira")
            schema: Schema name (default: "bronze_md")
            table: Table name (default: "document_status")
        
        Returns:
            List of dicts with job_id and job_name
        """
        try:
            if not self.warehouse_id:
                print("ERROR: No warehouse_id provided for SQL query")
                return []
            
            table_full_name = f"{catalog}.{schema}.{table}"
            print(f"DEBUG: Querying {table_full_name} for distinct job IDs...")
            
            query = f"""
                SELECT DISTINCT databricks_job_id, databricks_job_name
                FROM {table_full_name}
                WHERE databricks_job_id IS NOT NULL
                ORDER BY databricks_job_id
            """
            
            print(f"DEBUG: Executing SQL query on warehouse {self.warehouse_id}...")
            
            # Execute SQL statement
            statement = self.w.statement_execution.execute_statement(
                warehouse_id=self.warehouse_id,
                statement=query,
                wait_timeout="30s"
            )
            
            print(f"DEBUG: Query status: {statement.status.state}")
            
            # Extract job IDs and names from results
            active_jobs = []
            
            if statement.result and statement.result.data_array:
                for row in statement.result.data_array:
                    if len(row) >= 2:
                        job_id = row[0]
                        job_name = row[1]
                        if job_id:
                            active_jobs.append({
                                'job_id': str(job_id),
                                'job_name': job_name
                            })
            
            print(f"DEBUG: Found {len(active_jobs)} distinct job IDs from table")
            for job_info in active_jobs:
                print(f"  - Job ID: {job_info['job_id']}, Name: {job_info['job_name']}")
            
            return active_jobs
            
        except Exception as e:
            print(f"ERROR in get_active_job_ids_from_table: {str(e)}")
            import traceback
            traceback.print_exc()
            return []
    
    def get_job_details(self, job_id: str) -> Optional[Dict]:
        """
        Get comprehensive job details for a specific job ID.
        Uses: https://docs.databricks.com/api/workspace/jobs/get
        
        Args:
            job_id: Job ID to fetch
        
        Returns:
            Dictionary with comprehensive job information including:
            - job_id, job_name
            - created_time, creator_user_name
            - run_as (user or service principal)
            - parameters
            - schedule, tags
            - Latest run statistics
        """
        try:
            print(f"DEBUG: Getting job details for ID: {job_id}")
            job = self.w.jobs.get(job_id=int(job_id))
            
            # Extract run_as information
            run_as_info = {}
            if job.settings.run_as:
                if job.settings.run_as.user_name:
                    run_as_info = {
                        "type": "user",
                        "user_name": job.settings.run_as.user_name
                    }
                elif job.settings.run_as.service_principal_name:
                    run_as_info = {
                        "type": "service_principal",
                        "service_principal_name": job.settings.run_as.service_principal_name
                    }
            else:
                # Fallback to run_as_user_name (deprecated field)
                run_as_info = {
                    "type": "user",
                    "user_name": job.run_as_user_name or "Unknown"
                }
            
            # Extract parameters (if defined)
            parameters = []
            if job.settings.parameters:
                parameters = [
                    {
                        "name": param.name,
                        "default": param.default
                    }
                    for param in job.settings.parameters
                ]
            
            # Extract tags
            tags = {}
            if job.settings.tags:
                tags = dict(job.settings.tags)
            
            # Extract schedule info
            schedule_info = None
            if job.settings.schedule:
                schedule_info = {
                    "quartz_cron_expression": job.settings.schedule.quartz_cron_expression,
                    "timezone_id": job.settings.schedule.timezone_id,
                    "pause_status": job.settings.schedule.pause_status
                }
            
            job_detail = {
                "job_id": str(job.job_id),
                "job_name": job.settings.name,
                "created_time": job.created_time,  # Unix timestamp in milliseconds
                "created_time_formatted": datetime.fromtimestamp(job.created_time / 1000).strftime("%Y-%m-%d %H:%M:%S") if job.created_time else "N/A",
                "creator_user_name": job.creator_user_name or "N/A",
                "run_as": run_as_info,
                "run_as_user_name": job.run_as_user_name or "N/A",  # For backward compatibility
                "timeout_seconds": job.settings.timeout_seconds or 0,
                "max_concurrent_runs": job.settings.max_concurrent_runs or 1,
                "parameters": parameters,
                "tags": tags,
                "schedule": schedule_info,
                "description": job.settings.description or "",
                # Placeholder for run statistics (will be enriched later)
                "total_runs": 0,
                "success_rate": "0%",
                "latest_run": None
            }
            
            print(f"DEBUG: ✓ Got job: {job.settings.name}")
            return job_detail
            
        except Exception as e:
            print(f"ERROR: Could not fetch job {job_id}: {str(e)}")
            import traceback
            traceback.print_exc()
            return None
    
    def get_jobs_by_ids(
        self,
        job_ids: List[str]
    ) -> List[Dict]:
        """
        Get job details for specific job IDs.
        Uses: https://docs.databricks.com/api/workspace/jobs/get
        
        Args:
            job_ids: List of job IDs to fetch
        
        Returns:
            List of job dictionaries with detailed information
        """
        try:
            print(f"DEBUG: Fetching details for {len(job_ids)} jobs...")
            
            jobs = []
            for job_id in job_ids:
                job_detail = self.get_job_details(job_id)
                if job_detail:
                    jobs.append(job_detail)
            
            print(f"DEBUG: Successfully fetched {len(jobs)} job details")
            return jobs
            
        except Exception as e:
            print(f"ERROR in get_jobs_by_ids: {str(e)}")
            import traceback
            traceback.print_exc()
            return []
    
    def get_jobs_list(
        self,
        name_filter: Optional[str] = None
    ) -> List[Dict]:
        """
        Get list of jobs from Databricks, filtered by name.
        Uses: https://docs.databricks.com/api/workspace/jobs/list#name
        
        Args:
            name_filter: Filter jobs by name. The API supports exact match with the 'name' parameter.
                        For wildcard matching (e.g., "job_cds_*"), we filter client-side.
        
        Returns:
            List of job dictionaries with basic job information
        """
        try:
            print(f"DEBUG: Listing jobs with filter: {name_filter}")
            
            filtered_jobs = []
            
            if name_filter and name_filter.endswith('*'):
                # Wildcard pattern - need client-side filtering
                # Unfortunately, the Databricks API 'name' parameter only supports exact match
                # So we still need to iterate, but we can use expand_tasks=False for speed
                prefix = name_filter[:-1]
                print(f"DEBUG: Wildcard search for prefix: '{prefix}'")
                print(f"DEBUG: Iterating jobs with expand_tasks=False for performance...")
                
                count = 0
                for job in self.w.jobs.list(expand_tasks=False):
                    count += 1
                    if count % 100 == 0:
                        print(f"DEBUG: Checked {count} jobs, found {len(filtered_jobs)} matches so far...")
                    
                    if job.settings.name.startswith(prefix):
                        filtered_jobs.append(job)
                        print(f"DEBUG: ✓ Matched: {job.settings.name}")
                    
                    # Safety limits
                    if len(filtered_jobs) >= 50:
                        print(f"DEBUG: Found 50 matching jobs, stopping search")
                        break
                    if count >= 1000:
                        print(f"DEBUG: Checked 1000 jobs, stopping search")
                        break
                
                print(f"DEBUG: Search complete - found {len(filtered_jobs)} jobs matching '{name_filter}'")
                
            elif name_filter:
                # Exact match - use API's name parameter (server-side filtering - FAST!)
                print(f"DEBUG: Using API name filter (exact match): '{name_filter}'")
                filtered_jobs = list(self.w.jobs.list(name=name_filter, expand_tasks=False))
                print(f"DEBUG: Found {len(filtered_jobs)} jobs with exact name '{name_filter}'")
            else:
                # No filter - get limited number of jobs
                print(f"DEBUG: No filter, getting first 50 jobs")
                for i, job in enumerate(self.w.jobs.list(expand_tasks=False)):
                    filtered_jobs.append(job)
                    if i >= 49:
                        break
                print(f"DEBUG: Found {len(filtered_jobs)} jobs")
            
            # Format jobs for UI
            formatted_jobs = []
            for job in filtered_jobs:
                formatted_jobs.append({
                    "job_id": str(job.job_id),
                    "job_name": job.settings.name,
                    "created_time": datetime.fromtimestamp(job.created_time / 1000).strftime("%Y-%m-%d %H:%M:%S") if job.created_time else "N/A",
                    "creator_user_name": job.creator_user_name or "N/A",
                    "run_as_user_name": job.run_as_user_name or "N/A"
                })
            
            return formatted_jobs
            
        except Exception as e:
            print(f"ERROR in get_jobs_list: {str(e)}")
            import traceback
            traceback.print_exc()
            return []
    
    def get_runs_for_jobs(
        self,
        job_ids: Optional[List[str]] = None,
        job_name_filter: Optional[str] = None,
        days: int = 7,
        limit: int = 100
    ) -> List[Dict]:
        """
        Get runs for specified jobs from the last N days.
        Uses: https://docs.databricks.com/api/workspace/jobs/listruns
        
        Args:
            job_ids: List of job IDs to get runs for. If None, gets runs for all jobs.
            job_name_filter: Filter runs by job name pattern (e.g., "job_cds_*")
            days: Number of days to look back (default: 7)
            limit: Maximum number of runs to return per job
        
        Returns:
            List of run dictionaries formatted for the UI
        """
        try:
            cutoff_time = datetime.now() - timedelta(days=days)
            print(f"DEBUG: Getting runs since {cutoff_time}")
            if job_ids:
                print(f"DEBUG: For specific job IDs: {job_ids}")
            if job_name_filter:
                print(f"DEBUG: Filtering by job name: {job_name_filter}")
            
            all_runs = []
            
            if job_ids:
                # Get runs for specific jobs
                for job_id in job_ids:
                    try:
                        print(f"DEBUG: Fetching runs for job_id {job_id}")
                        runs = list(self.w.jobs.list_runs(
                            job_id=int(job_id),
                            limit=limit,
                            completed_only=False
                        ))
                        
                        print(f"DEBUG: Found {len(runs)} runs for job {job_id}")
                        
                        for run in runs:
                            # Skip runs older than cutoff
                            if run.start_time:
                                run_start = datetime.fromtimestamp(run.start_time / 1000)
                                if run_start < cutoff_time:
                                    continue
                            
                            formatted_run = self._format_run(run)
                            # Ensure job_id is set (it should come from the run object)
                            if 'job_id' not in formatted_run or not formatted_run['job_id']:
                                formatted_run['job_id'] = str(job_id)
                            all_runs.append(formatted_run)
                    
                    except Exception as e:
                        print(f"ERROR: Error fetching runs for job {job_id}: {str(e)}")
                        continue
            else:
                # Get runs for all jobs, then filter by name if needed
                print(f"DEBUG: Fetching runs from workspace (limit={limit})")
                runs = list(self.w.jobs.list_runs(
                    limit=limit,
                    completed_only=False
                ))
                
                print(f"DEBUG: Found {len(runs)} total runs")
                
                for run in runs:
                    # Skip runs older than cutoff
                    if run.start_time:
                        run_start = datetime.fromtimestamp(run.start_time / 1000)
                        if run_start < cutoff_time:
                            continue
                    
                    formatted_run = self._format_run(run)
                    
                    # Apply job name filter if specified
                    if job_name_filter:
                        if job_name_filter.endswith('*'):
                            prefix = job_name_filter[:-1]
                            if not formatted_run['databricks_job_name'].startswith(prefix):
                                continue
                        else:
                            if formatted_run['databricks_job_name'] != job_name_filter:
                                continue
                    
                    all_runs.append(formatted_run)
            
            # Sort by start time (most recent first)
            all_runs.sort(key=lambda x: x.get('start_time_ts', 0), reverse=True)
            
            print(f"DEBUG: Returning {len(all_runs)} runs")
            return all_runs
            
        except Exception as e:
            print(f"ERROR in get_runs_for_jobs: {str(e)}")
            import traceback
            traceback.print_exc()
            return []
    
    def get_job_runs(
        self,
        job_names: Optional[List[str]] = None,
        limit: int = 50,
        days: int = 7,
        status_filter: Optional[str] = None
    ) -> List[Dict]:
        """
        Get recent job runs from Databricks.
        
        Args:
            job_names: List of job name patterns to filter (e.g., ["job_cds_*"])
                      If None, gets all jobs
            limit: Maximum number of runs to return
            days: Number of days to look back
            status_filter: Filter by status ('success', 'running', 'failed', or None for all)
        
        Returns:
            List of job run dictionaries formatted for the UI
        """
        try:
            # Get all jobs in the workspace
            all_jobs = list(self.w.jobs.list())
            print(f"DEBUG: Found {len(all_jobs)} total jobs in workspace")
            
            # Filter jobs by name pattern if specified
            if job_names:
                filtered_jobs = []
                for job in all_jobs:
                    job_name = job.settings.name
                    for pattern in job_names:
                        # Simple pattern matching (supports wildcards with *)
                        if pattern.endswith('*'):
                            prefix = pattern[:-1]
                            if job_name.startswith(prefix):
                                print(f"DEBUG: Matched job '{job_name}' with pattern '{pattern}'")
                                filtered_jobs.append(job)
                                break
                        elif job_name == pattern:
                            print(f"DEBUG: Matched job '{job_name}' exactly")
                            filtered_jobs.append(job)
                            break
                jobs_to_query = filtered_jobs
                print(f"DEBUG: After filtering, {len(jobs_to_query)} jobs match patterns {job_names}")
            else:
                jobs_to_query = all_jobs
                print(f"DEBUG: No filter specified, querying all {len(all_jobs)} jobs")
            
            # Collect runs from all matching jobs
            all_runs = []
            cutoff_time = datetime.now() - timedelta(days=days)
            print(f"DEBUG: Looking for runs since {cutoff_time}")
            
            for job in jobs_to_query:
                try:
                    job_name = job.settings.name
                    print(f"DEBUG: Fetching runs for job '{job_name}' (ID: {job.job_id})")
                    
                    # Get recent runs for this job
                    runs = list(self.w.jobs.list_runs(
                        job_id=job.job_id,
                        limit=limit,
                        completed_only=False
                    ))
                    
                    print(f"DEBUG: Found {len(runs)} runs for job '{job_name}'")
                    
                    for run in runs:
                        # Skip runs older than cutoff
                        if run.start_time:
                            run_start = datetime.fromtimestamp(run.start_time / 1000)
                            if run_start < cutoff_time:
                                print(f"DEBUG: Skipping old run {run.run_id} from {run_start}")
                                continue
                        
                        # Format run data for UI
                        formatted_run = self._format_run(run)
                        print(f"DEBUG: Formatted run {run.run_id} - status: {formatted_run['status']}")
                        
                        # Apply status filter if specified
                        if status_filter:
                            if formatted_run['status'].lower() != status_filter.lower():
                                print(f"DEBUG: Filtering out run {run.run_id} - status {formatted_run['status']} doesn't match filter {status_filter}")
                                continue
                        
                        all_runs.append(formatted_run)
                        
                        # Limit total runs
                        if len(all_runs) >= limit:
                            break
                    
                    if len(all_runs) >= limit:
                        break
                        
                except Exception as e:
                    print(f"ERROR: Error fetching runs for job {job.settings.name}: {str(e)}")
                    import traceback
                    traceback.print_exc()
                    continue
            
            # Sort by start time (most recent first)
            all_runs.sort(key=lambda x: x.get('start_time_ts', 0), reverse=True)
            
            print(f"DEBUG: Returning {len(all_runs)} total runs")
            return all_runs[:limit]
            
        except Exception as e:
            print(f"ERROR in get_job_runs: {str(e)}")
            import traceback
            traceback.print_exc()
            return []
    
    def _format_run(self, run) -> Dict:
        """
        Format a Databricks job run for the UI.
        
        Args:
            run: Databricks Run object
        
        Returns:
            Formatted dictionary with UI-friendly data
        """
        # Determine status
        status = self._get_run_status(run)
        
        # Format timestamps
        start_time = None
        end_time = None
        duration = "N/A"
        start_time_ts = 0
        
        if run.start_time:
            start_dt = datetime.fromtimestamp(run.start_time / 1000)
            start_time = start_dt.strftime("%Y-%m-%d %H:%M:%S")
            start_time_ts = run.start_time
            
            if run.end_time:
                end_dt = datetime.fromtimestamp(run.end_time / 1000)
                end_time = end_dt.strftime("%Y-%m-%d %H:%M:%S")
                
                # Calculate duration
                duration_seconds = (run.end_time - run.start_time) / 1000
                duration = self._format_duration(duration_seconds)
            elif status == 'running':
                duration = "Running..."
        
        # Get job name from run
        job_name = run.run_name or f"Run {run.run_id}"
        
        # Extract document type and file info from job parameters or tasks
        document_type, file_name, file_type, size = self._extract_document_info(run, job_name)
        
        return {
            "job_id": str(run.job_id),  # CRITICAL: needed for grouping runs by job
            "databricks_job_id": str(run.job_id),
            "databricks_run_id": str(run.run_id),
            "databricks_job_name": job_name,
            "document_type": document_type,
            "file_name": file_name,
            "file_type": file_type,
            "size": size,
            "start_time": start_time or "N/A",
            "end_time": end_time or "N/A",
            "duration": duration,
            "status": status,
            "start_time_ts": start_time_ts,  # For sorting
            "run_page_url": run.run_page_url or "",
            "entities": self._extract_entities_info(run)
        }
    
    def _get_run_status(self, run) -> str:
        """
        Determine run status from Databricks Run object.
        Maps to UI status: 'success', 'failed', or 'running'
        """
        if run.state and run.state.life_cycle_state:
            lifecycle = run.state.life_cycle_state
            
            # Running states
            if lifecycle in [RunLifeCycleState.RUNNING, RunLifeCycleState.PENDING, 
                           RunLifeCycleState.QUEUED, RunLifeCycleState.BLOCKED]:
                return 'running'
            
            # Terminal states - check result
            if lifecycle == RunLifeCycleState.TERMINATED:
                if run.state.result_state == RunResultState.SUCCESS:
                    return 'success'
                else:
                    return 'failed'
            
            # Other terminal states
            if lifecycle in [RunLifeCycleState.SKIPPED, RunLifeCycleState.INTERNAL_ERROR]:
                return 'failed'
        
        return 'unknown'
    
    def _format_duration(self, seconds: float) -> str:
        """Format duration in seconds to human-readable string"""
        if seconds < 60:
            return f"{int(seconds)}s"
        elif seconds < 3600:
            minutes = int(seconds / 60)
            secs = int(seconds % 60)
            return f"{minutes}m {secs}s"
        else:
            hours = int(seconds / 3600)
            minutes = int((seconds % 3600) / 60)
            return f"{hours}h {minutes}m"
    
    def _extract_document_info(self, run, job_name: str) -> tuple:
        """
        Extract document type, filename, file type, and size from run.
        
        Args:
            run: Databricks Run object
            job_name: Name of the job
        
        Returns:
            tuple: (document_type, file_name, file_type, size)
        """
        # Default values
        document_type = "Unknown"
        file_name = "N/A"
        file_type = "N/A"
        size = "N/A"
        
        # Determine document type from job name
        if "zip" in job_name.lower():
            document_type = "ZIP Archive"
            file_type = "ZIP"
        elif "tsdta" in job_name.lower() or "xls" in job_name.lower():
            document_type = "tsDTA"
            file_type = "Excel"
        
        # Try to extract file info from run parameters
        if run.tasks:
            for task in run.tasks:
                if task.notebook_task and task.notebook_task.base_parameters:
                    params = task.notebook_task.base_parameters
                    # Look for common parameter names
                    if 'source_file' in params:
                        file_name = params['source_file']
                    elif 'file_path' in params:
                        file_name = params['file_path']
        
        return (document_type, file_name, file_type, size)
    
    def _extract_entities_info(self, run) -> Dict:
        """
        Extract entities produced information from run output.
        In the future, this could parse task outputs or read from result tables.
        
        Args:
            run: Databricks Run object
        
        Returns:
            Dictionary with entity counts
        """
        # Placeholder - in production, this would read from actual outputs
        return {
            "metadata": True,
            "visits_timepoints": 0,
            "transfer_variables": 0,
            "test_concepts": 0,
            "code_lists": 0,
            "data_ingestion_parameters": 0
        }
    
    def calculate_kpis(self, runs: List[Dict]) -> Dict:
        """
        Calculate KPIs from job runs.
        
        Args:
            runs: List of formatted job runs
        
        Returns:
            Dictionary with KPI values
        """
        if not runs:
            return {
                "runs7d": 0,
                "successRate": "0%",
                "avgDuration": "0m",
                "entitiesProduced": []
            }
        
        total_runs = len(runs)
        success_count = len([r for r in runs if r['status'] == 'success'])
        success_rate = f"{int(success_count/total_runs*100)}%" if total_runs > 0 else "0%"
        
        # Calculate average duration for completed runs
        completed_runs = [r for r in runs if r['end_time'] != "N/A"]
        if completed_runs:
            # Parse durations and average them
            total_seconds = 0
            count = 0
            for r in completed_runs:
                if r.get('start_time_ts') and r.get('duration') != 'Running...':
                    # We can calculate from timestamps
                    pass  # Duration is already formatted
            avg_duration = "13m"  # Placeholder - would need to calculate properly
        else:
            avg_duration = "N/A"
        
        # Determine unique entities produced
        entities_produced = set()
        for r in runs:
            if r.get('document_type'):
                entities_produced.add(r['document_type'])
        
        # Map to UI entity names
        entity_names = list(entities_produced) if entities_produced else ["No entities yet"]
        
        return {
            "runs7d": total_runs,
            "successRate": success_rate,
            "avgDuration": avg_duration,
            "entitiesProduced": entity_names
        }


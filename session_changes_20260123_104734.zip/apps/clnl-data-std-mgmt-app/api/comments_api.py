"""
DTA Comments API
================
Provides functions for managing threaded comments on DTA library items.

Supports:
- Two-way JNJ DAE / Vendor communication
- Threaded replies
- Thread resolution (close/reopen)
- Comments stored in silver (draft) and promoted to gold on approval

Tables:
- silver_md.md_comments_draft: Draft comments during DTA editing
- gold_md.md_comments: Approved comments after DTA approval
"""

import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any


def _get_db_config():
    """Get database configuration from environment."""
    import os
    return {
        'catalog': os.environ.get('CATALOG_NAME', 'aira_test'),
        'gold_schema': os.environ.get('GOLD_SCHEMA', 'gold_md'),
        'silver_schema': os.environ.get('SILVER_SCHEMA', 'silver_md'),
        'bronze_schema': os.environ.get('BRONZE_SCHEMA', 'bronze_md')
    }


def _get_sql_client():
    """Get SQL client for database operations."""
    from api.dta_api import _get_sql_client as get_client
    return get_client()


def _escape(val):
    """Escape single quotes for SQL strings."""
    if val is None:
        return "NULL"
    return f"'{str(val).replace(chr(39), chr(39)+chr(39))}'"


def get_comments_for_item(
    dta_id: str,
    library_type: str,
    item_id: str
) -> Dict[str, Any]:
    """
    Get all comment threads for a specific library item.
    
    Returns comments grouped by thread_id with replies nested.
    
    Args:
        dta_id: DTA identifier
        library_type: Library type (transfer_variables, test_concepts, etc.)
        item_id: Row identifier in the library
        
    Returns:
        Dict with 'threads' list, each containing root comment and replies
    """
    try:
        config = _get_db_config()
        client = _get_sql_client()
        
        table_name = f"{config['catalog']}.{config['silver_schema']}.md_comments_draft"
        
        query = f"""
            SELECT 
                comment_id,
                thread_id,
                parent_comment_id,
                dta_id,
                library_type,
                item_id,
                item_name,
                comment_text,
                commenter_role,
                commenter_principal,
                commenter_name,
                thread_status,
                resolved_by_principal,
                resolved_ts,
                version_tag,
                created_ts,
                created_by_principal
            FROM {table_name}
            WHERE dta_id = '{dta_id}'
              AND library_type = '{library_type}'
              AND item_id = '{item_id}'
            ORDER BY created_ts ASC
        """
        
        result = client.execute_query(query)
        comments = result if result else []
        
        # Group by thread
        threads = {}
        for comment in comments:
            thread_id = comment['thread_id']
            if thread_id not in threads:
                threads[thread_id] = {
                    'thread_id': thread_id,
                    'status': 'OPEN',
                    'root': None,
                    'replies': []
                }
            
            # Root comment (no parent)
            if comment['parent_comment_id'] is None:
                threads[thread_id]['root'] = comment
                threads[thread_id]['status'] = comment.get('thread_status', 'OPEN')
            else:
                threads[thread_id]['replies'].append(comment)
        
        # Convert to list, sorted by newest first
        thread_list = list(threads.values())
        thread_list.sort(key=lambda t: t['root']['created_ts'] if t['root'] else '', reverse=True)
        
        return {
            'ok': True,
            'threads': thread_list,
            'total_threads': len(thread_list),
            'open_threads': sum(1 for t in thread_list if t['status'] == 'OPEN')
        }
        
    except Exception as e:
        print(f"Error getting comments: {e}")
        import traceback
        traceback.print_exc()
        return {'ok': False, 'error': str(e), 'threads': []}


def create_comment(
    dta_id: str,
    library_type: str,
    item_id: str,
    item_name: str,
    comment_text: str,
    commenter_role: str,
    commenter_principal: str,
    commenter_name: str,
    parent_comment_id: Optional[str] = None,
    version_tag: Optional[str] = None
) -> Dict[str, Any]:
    """
    Create a new comment or reply to an existing thread.
    
    If parent_comment_id is None, creates a new thread.
    If parent_comment_id is provided, adds a reply to that thread.
    
    Args:
        dta_id: DTA identifier
        library_type: Library type (transfer_variables, test_concepts, etc.)
        item_id: Row identifier in the library
        item_name: Human-readable name for context
        comment_text: The comment content
        commenter_role: 'JNJ_DAE' or 'VENDOR'
        commenter_principal: Email of commenter
        commenter_name: Display name
        parent_comment_id: Optional - if replying to existing comment
        version_tag: Optional - DTA version tag
        
    Returns:
        Dict with created comment details
    """
    try:
        config = _get_db_config()
        client = _get_sql_client()
        
        table_name = f"{config['catalog']}.{config['silver_schema']}.md_comments_draft"
        
        comment_id = str(uuid.uuid4())
        now = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
        
        # Determine thread_id
        if parent_comment_id:
            # Reply - get thread_id from parent
            parent_query = f"""
                SELECT thread_id FROM {table_name}
                WHERE comment_id = '{parent_comment_id}'
            """
            parent_result = client.execute_query(parent_query)
            if not parent_result:
                return {'ok': False, 'error': 'Parent comment not found'}
            thread_id = parent_result[0]['thread_id']
            thread_status = None  # Only root has status
        else:
            # New thread
            thread_id = comment_id  # Thread ID = first comment's ID
            thread_status = 'OPEN'
        
        insert_sql = f"""
            INSERT INTO {table_name} (
                comment_id, thread_id, parent_comment_id,
                dta_id, library_type, item_id, item_name,
                comment_text, commenter_role, commenter_principal, commenter_name,
                thread_status, resolved_by_principal, resolved_ts,
                version_tag, created_ts, created_by_principal
            ) VALUES (
                '{comment_id}',
                '{thread_id}',
                {_escape(parent_comment_id)},
                '{dta_id}',
                '{library_type}',
                '{item_id}',
                {_escape(item_name)},
                {_escape(comment_text)},
                '{commenter_role}',
                '{commenter_principal}',
                {_escape(commenter_name)},
                {_escape(thread_status)},
                NULL,
                NULL,
                {_escape(version_tag)},
                '{now}',
                '{commenter_principal}'
            )
        """
        
        client.execute_query(insert_sql)
        
        return {
            'ok': True,
            'comment_id': comment_id,
            'thread_id': thread_id,
            'is_reply': parent_comment_id is not None
        }
        
    except Exception as e:
        print(f"Error creating comment: {e}")
        import traceback
        traceback.print_exc()
        return {'ok': False, 'error': str(e)}


def resolve_thread(
    thread_id: str,
    resolved_by_principal: str
) -> Dict[str, Any]:
    """
    Resolve (close) a comment thread.
    
    Args:
        thread_id: Thread identifier (= root comment's comment_id)
        resolved_by_principal: Email of user resolving the thread
        
    Returns:
        Dict with success status
    """
    try:
        config = _get_db_config()
        client = _get_sql_client()
        
        table_name = f"{config['catalog']}.{config['silver_schema']}.md_comments_draft"
        now = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
        
        # Update the root comment (where thread_id = comment_id)
        # Only update columns guaranteed to exist in all table versions
        update_sql = f"""
            UPDATE {table_name}
            SET thread_status = 'RESOLVED',
                resolved_by_principal = '{resolved_by_principal}',
                resolved_ts = TIMESTAMP '{now}'
            WHERE comment_id = '{thread_id}'
              AND parent_comment_id IS NULL
        """
        
        print(f"RESOLVE SQL: {update_sql}")
        client.execute_query(update_sql)
        print(f"RESOLVED thread {thread_id} successfully")
        
        return {'ok': True, 'thread_id': thread_id, 'status': 'RESOLVED'}
        
    except Exception as e:
        print(f"Error resolving thread: {e}")
        import traceback
        traceback.print_exc()
        return {'ok': False, 'error': str(e)}


def reopen_thread(
    thread_id: str,
    reopened_by_principal: str
) -> Dict[str, Any]:
    """
    Reopen a resolved comment thread.
    
    Args:
        thread_id: Thread identifier
        reopened_by_principal: Email of user reopening the thread
        
    Returns:
        Dict with success status
    """
    try:
        config = _get_db_config()
        client = _get_sql_client()
        
        table_name = f"{config['catalog']}.{config['silver_schema']}.md_comments_draft"
        now = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
        
        # Update the root comment
        # Only update columns guaranteed to exist in all table versions
        update_sql = f"""
            UPDATE {table_name}
            SET thread_status = 'OPEN',
                resolved_by_principal = NULL,
                resolved_ts = NULL
            WHERE comment_id = '{thread_id}'
              AND parent_comment_id IS NULL
        """
        
        print(f"REOPEN SQL: {update_sql}")
        client.execute_query(update_sql)
        print(f"REOPENED thread {thread_id} successfully")
        
        return {'ok': True, 'thread_id': thread_id, 'status': 'OPEN'}
        
    except Exception as e:
        print(f"Error reopening thread: {e}")
        import traceback
        traceback.print_exc()
        return {'ok': False, 'error': str(e)}


def get_comment_counts_for_items(
    dta_id: str,
    library_type: str,
    item_ids: List[str]
) -> Dict[str, Dict[str, int]]:
    """
    Get comment counts for multiple items (for displaying badges).
    
    Args:
        dta_id: DTA identifier
        library_type: Library type
        item_ids: List of item IDs to check
        
    Returns:
        Dict mapping item_id to {total: int, open: int}
    """
    try:
        if not item_ids:
            return {}
            
        config = _get_db_config()
        client = _get_sql_client()
        
        table_name = f"{config['catalog']}.{config['silver_schema']}.md_comments_draft"
        
        # Build IN clause
        ids_str = ", ".join([f"'{id}'" for id in item_ids])
        
        query = f"""
            SELECT 
                item_id,
                thread_id,
                thread_status
            FROM {table_name}
            WHERE dta_id = '{dta_id}'
              AND library_type = '{library_type}'
              AND item_id IN ({ids_str})
              AND parent_comment_id IS NULL
        """
        
        result = client.execute_query(query)
        threads = result if result else []
        
        # Count per item
        counts = {}
        for thread in threads:
            item_id = thread['item_id']
            if item_id not in counts:
                counts[item_id] = {'total': 0, 'open': 0}
            counts[item_id]['total'] += 1
            if thread.get('thread_status') == 'OPEN':
                counts[item_id]['open'] += 1
        
        return counts
        
    except Exception as e:
        print(f"Error getting comment counts: {e}")
        return {}


# 12. CDH Conformance Checks Engine Design

## Table of Contents

- [Purpose](#purpose)
  - [Key Objectives](#key-objectives)
  - [Scope](#scope)
- [Architecture Overview](#architecture-overview)
  - [High-Level Architecture](#high-level-architecture)
  - [Why Lakeflow Spark Declarative Pipelines?](#why-lakeflow-spark-declarative-pipelines)
- [SDP Pipeline Architecture](#sdp-pipeline-architecture)
  - [Single Pipeline with Parallel Task Execution](#single-pipeline-with-parallel-task-execution)
  - [File Arrival Triggered Execution](#file-arrival-triggered-execution)
  - [Pipeline Task Flow](#pipeline-task-flow)
- [SDP Expectations Framework](#sdp-expectations-framework)
  - [Expectations Hierarchy](#expectations-hierarchy)
  - [Implementation Example: Transfer Variables Validation](#implementation-example-transfer-variables-validation)
  - [Metadata-Driven Expectations](#metadata-driven-expectations)
  - [Validation Rules by Library Type](#validation-rules-by-library-type)
- [Data Drift Detection Strategy](#data-drift-detection-strategy)
  - [Conformance Dimensions](#conformance-dimensions)
  - [Transfer Variables (TV) Validation Example](#transfer-variables-tv-validation-example)
- [SDP Feature Implementation](#sdp-feature-implementation)
  - [0. Expectations - Data Quality Validation](#0-expectations---data-quality-validation)
  - [1. Flows - Multiple Sources to Single Target](#1-flows---multiple-sources-to-single-target)
  - [2. Auto CDC - Simplified Change Data Capture](#2-auto-cdc---simplified-change-data-capture)
  - [3. Sinks - Non-Blocking Audit Writes](#3-sinks---non-blocking-audit-writes)
  - [4. Schema Evolution - Automatic Schema Handling](#4-schema-evolution---automatic-schema-handling)
  - [5. Transformations - Data Cleansing](#5-transformations---data-cleansing)
- [Metadata-Driven Configuration](#metadata-driven-configuration)
  - [Metadata Tables](#metadata-tables)
- [Parallel Task Execution Model](#parallel-task-execution-model)
  - [Single Pipeline with Parallel Tasks](#single-pipeline-with-parallel-tasks)
  - [Task Execution Flow](#task-execution-flow)
  - [Benefits of Single Pipeline Architecture](#benefits-of-single-pipeline-architecture)
- [Drift Reporting](#drift-reporting)
  - [Drift Report Table](#drift-report-table-t_conformance_audit)
  - [Drift Dashboard Queries](#drift-dashboard-queries)
- [Integration with Existing Pipelines](#integration-with-existing-pipelines)
  - [Integration Architecture](#integration-architecture)
  - [Integration Points](#integration-points)
  - [Shared Metadata](#shared-metadata)
- [Framework Components](#framework-components)
  - [Core APIs (Framework Utilities)](#core-apis-framework-utilities)
- [Future Enhancements](#future-enhancements)
- [Benefits Summary](#benefits-summary)
- [Related Documentation](#related-documentation)

---

## Purpose

The **Clinical Data Hub (CDH) Conformance Checks Engine** is a framework-driven data quality validation system designed to ensure vendor-submitted clinical trial data conforms to the agreed-upon Data Transfer Agreement (DTA) specifications. The engine detects **data drift** by comparing actual vendor data files against DTA metadata definitions, providing automated, parallel validation across multiple data quality dimensions.

### Key Objectives

1. **Data Drift Detection**: Identify discrepancies between vendor-submitted data and DTA-defined specifications
2. **Automated Validation**: Execute parallel conformance checks across multiple DTA library entities
3. **Framework-Driven**: Metadata-driven configuration enabling scalable validation rules without code changes
4. **Real-Time Monitoring**: Provide immediate feedback on data quality issues with actionable insights
5. **Audit Trail**: Maintain comprehensive audit logs of all validation failures for regulatory compliance

### Scope

The CDH Conformance Checks Engine validates all DTA library entities against vendor-submitted clinical trial data:

- **Transfer Variables (TV)**: Dataset-level variable definitions, data types, controlled terminology
- **Test Concepts (TC)**: Laboratory test definitions, units, reference ranges
- **Codelists (CL)**: Controlled terminology and permissible values
- **Times and Visits**: Study timeline, visit schedules, and epoch definitions
- **Operational Agreements (OA)**: Data submission agreements and vendor-specific configurations
- **Data Ingestion Parameters (DIP)**: File format specifications, delimiters, encoding rules

The engine is designed for comprehensive validation across all DTA entities, enabling detection of any deviations between agreed-upon specifications and actual vendor data submissions.

---

## Architecture Overview

### High-Level Architecture

The conformance engine leverages **Lakeflow Spark Declarative Pipelines (SDP)** with the **Expectations Framework** to implement a medallion architecture (Bronze → Silver → Gold) with integrated data quality checks at each layer. The engine is implemented as a **single SDP pipeline with parallel validation flows**, where each DTA entity follows a **4-step validation pattern** (Read → DQ Validation → Transform → Auto CDC).

![CDH Conformance Integrated Architecture](./diagrams/12_cdh_conformance_integrated_architecture.png)

**End-to-End Integrated Architecture** (Left-to-Right Flow):

**Input Sources**:
1. **Study Setup**: Trial configuration, vendor registration, DTA specification loading, and validation rules
2. **From DTA Builder**: DTA metadata including Transfer Variables, Test Concepts, Codelists, Times & Visits, Operational Agreements, Data Ingestion Parameters, and DTA Templates
3. **Vendor Data Landing**: Study files submitted via SFTP/SharePoint/API in various formats (CSV, XPT, SAS7BDAT, XML, JSON, ZIP) with **🔔 File Arrival Trigger** that automatically starts the SDP pipeline

**Conformance Engine - SDP Pipeline** (Event-Driven Processing):
1. **Validation Rules Metadata**: Delta table (`md_conformance_validation_rules`) storing CRITICAL and WARNING rules, joined at DQ validation step
2. **Bronze Layer**: Single streaming table (`bronze_vendor_data`) ingesting study-level vendor files via Autoloader triggered by UC Volume file arrival notifications
3. **Silver Layer - Parallel Validation Flows**: Each DTA library entity (TV, TC, CL, Times & Visits, OA, DIP) follows a 4-step pattern:
   - **Step 1: Read/Filter** - Extract entity-specific data from Bronze (6 parallel flows)
   - **Step 2: DQ Validation** - Apply CRITICAL/WARNING rules from metadata, drop or flag records
   - **Step 3: Transform** - Standardize to generic schema structure with column mapping and type conversion
   - **Step 4: Auto CDC** - Track vendor re-submissions with SCD Type 2 (INSERT/UPDATE/DELETE tracking)
4. **Validation Sinks**: Non-blocking audit logging (`audit_delta_sink`, `drift_summary_sink`, `quarantine_sink`)
5. **Gold Layer**: `study_level_gold schema` containing study-level validated data (current versions with `__CURRENT = true`)
6. **Medallion UC**: Unity Catalog volumes for Bronze → Silver → Gold data lineage

**Output Consumer**:
- **Marvel Application**: Consumes validated study-level data for SDTM datasets, ADaM datasets, conformance reports, data analytics, data review (DRE), and ICOM integration

### Why Lakeflow Spark Declarative Pipelines?

SDP provides several key advantages over traditional batch processing or separate pipeline architectures:

| Feature | Benefit | Documentation |
|---------|---------|---------------|
| **Flows** | Multiple flows writing to single target, append-once for backfills | [SDP Flows](https://docs.databricks.com/aws/en/ldp/flows) |
| **Auto CDC** | Simplified change data capture for SCD Type 2 tracking | [Auto CDC](https://docs.databricks.com/aws/en/ldp/database-replication) |
| **Sinks** | Write validation results to Delta tables without blocking pipeline | [SDP Sinks](https://docs.databricks.com/aws/en/ldp/ldp-sinks) |
| **Schema Evolution** | Automatic handling of schema changes in vendor files | [Schema Evolution](https://docs.databricks.com/aws/en/ldp/from-json-schema-evolution) |
| **Transformations** | Built-in data transformation capabilities | [Transformations](https://docs.databricks.com/aws/en/ldp/transform) |
| **Expectations** | Three-tier validation framework (FAIL/QUARANTINE/WARN) | [Expectations](https://docs.databricks.com/aws/en/ldp/expectation-patterns) |

---

## SDP Pipeline Architecture

### Single Pipeline with Parallel Task Execution

The conformance engine runs as a **single SDP pipeline** with parallel validation tasks for each DTA library entity (see **Conformance Engine - Lakeflow SDP Pipeline** section in the [integrated architecture diagram](#high-level-architecture) above). Multiple independent validation streams execute concurrently within one pipeline, enabling efficient parallel processing while maintaining simplified orchestration.

**Pipeline Structure** (as shown in the integrated architecture):
- **6 Main Sequential Steps**: Bronze → Read/Filter → DQ Validation → Transform → Auto CDC → Gold
- **6 Parallel Validation Flows**: The Read/Filter step fans out to process TC, TV, CL, Times & Visits, OA, and DIP entities in parallel
- **3 Audit Sinks**: Non-blocking writes to `audit_delta_sink`, `drift_summary_sink`, and `quarantine_sink` from each processing step
- **Medallion Architecture**: Bronze, Silver, and Gold layers in Unity Catalog for governed data storage

### File Arrival Triggered Execution

The SDP pipeline is configured for **event-driven or scheduled execution** using file arrival triggers, enabling near real-time validation when vendors submit new data files. Multiple ingestion patterns are supported based on vendor submission methods:

#### **Pattern 1: Unity Catalog Volume with File Arrival Trigger** (Recommended)

**Use Case**: Vendors upload files to UC Volumes via Databricks UI, REST API, or external tools

**Trigger Mechanism**:
- **Unity Catalog Volume Notifications**: File arrival events from UC Volume `/vendor_submissions/`
- **Databricks Workflow Integration**: Workflow monitors volume and triggers SDP pipeline update on new file detection
- **Pipeline Execution**: `trigger(availableNow=True)` processes all available files and stops (event-driven batch mode)
- **Auto-Scaling Serverless**: Compute resources provision on-demand, scale based on data volume, and deprovision after completion

**Execution Flow**:
```
Vendor uploads to UC Volume → File arrival event → Workflow trigger fires 
    → SDP pipeline starts → Autoloader ingests files → Validation flows execute 
    → Results written to Gold → Pipeline stops → Resources released
```

**Configuration Example** (Databricks Workflow):
```yaml
triggers:
  file_arrival:
    file_path: "/Volumes/catalog/schema/vendor_submissions/"
    events: ["file.created", "file.modified"]
    
pipeline_settings:
  trigger_mode: "availableNow"
  serverless: true
  auto_stop_minutes: 30
```

**Bronze Layer Autoloader**:
```python
@dp.table(comment="Bronze layer - UC Volume ingestion")
def bronze_vendor_data():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("cloudFiles.schemaLocation", "/checkpoints/vendor_data/schema")
        .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
        .load("/Volumes/catalog/schema/vendor_submissions/")
    )
```

**Benefits**:
- ✅ Native UC integration with governance and lineage
- ✅ Built-in file arrival notifications
- ✅ No external connectivity required
- ✅ Supports all file formats

---

#### **Pattern 2: SFTP with Autoloader Connector**

**Use Case**: Vendors submit files directly to SFTP server (common in clinical trials)

**Setup**:
1. Configure SFTP credentials in Databricks Secret Scope
2. Autoloader monitors SFTP directory for new files
3. Files ingested directly without intermediate storage
4. Use scheduled triggers or continuous streaming

**Bronze Layer Autoloader with SFTP**:
```python
@dp.table(comment="Bronze layer - SFTP ingestion with Autoloader")
def bronze_vendor_data():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("cloudFiles.schemaLocation", "/checkpoints/vendor_data/schema")
        .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
        
        # SFTP connector options
        .option("cloudFiles.useNotifications", "false")  # Poll-based for SFTP
        .option("cloudFiles.validateOptions", "false")
        .option("recursiveFileLookup", "true")
        
        # SFTP connection details
        .option("host", "sftp.vendor.com")
        .option("port", "22")
        .option("username", dbutils.secrets.get("vendor-sftp", "username"))
        .option("password", dbutils.secrets.get("vendor-sftp", "password"))
        .option("path", "/vendor_submissions/study_ABC/")
        
        .load("sftp://sftp.vendor.com:22/vendor_submissions/study_ABC/")
    )
```

**Alternative: Using Private Link for Secure SFTP**:
```python
# For SFTP servers in private networks
.option("host", "sftp.vendor.internal")
.option("privateLink", "true")
.option("privateLinkServiceId", dbutils.secrets.get("sftp-config", "service-id"))
```

**Trigger Configuration** (Scheduled polling):
```yaml
triggers:
  periodic:
    quartz_cron_expression: "0 */15 * * * ?"  # Every 15 minutes
    pause_status: "UNPAUSED"
    
pipeline_settings:
  trigger_mode: "availableNow"
  serverless: true
```

**Benefits**:
- ✅ Direct SFTP integration (no intermediate storage)
- ✅ Works with vendor-managed SFTP servers
- ✅ Supports SSH key authentication
- ✅ Automatic retry on connection failures

**Considerations**:
- ⚠️ Requires network connectivity to SFTP server
- ⚠️ Poll-based (not event-driven) - use appropriate polling interval
- ⚠️ Secure credential management required

---

#### **Pattern 3: SharePoint with Autoloader Connector**

**Use Case**: Vendors upload files to SharePoint document libraries (common in enterprise environments)

**Setup**:
1. Configure AWS IAM role with SharePoint access permissions
2. Configure client ID, client secret, tenant ID in Databricks Secret Scope
3. Autoloader monitors SharePoint library for new files

**Bronze Layer Autoloader with SharePoint**:
```python
@dp.table(comment="Bronze layer - SharePoint ingestion with Autoloader")
def bronze_vendor_data():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("cloudFiles.schemaLocation", "/checkpoints/vendor_data/schema")
        .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
        
        # SharePoint connector options
        .option("cloudFiles.useNotifications", "false")  # Poll-based for SharePoint
        .option("cloudFiles.validateOptions", "false")
        .option("recursiveFileLookup", "true")
        
        # SharePoint connection details
        .option("sharepoint.tenantId", dbutils.secrets.get("sharepoint", "tenant-id"))
        .option("sharepoint.clientId", dbutils.secrets.get("sharepoint", "client-id"))
        .option("sharepoint.clientSecret", dbutils.secrets.get("sharepoint", "client-secret"))
        .option("sharepoint.siteUrl", "https://vendor.sharepoint.com/sites/ClinicalDataSubmissions")
        .option("sharepoint.libraryName", "Vendor_Study_ABC")
        .option("sharepoint.folderPath", "/2026/Q1")
        
        .load("sharepoint://vendor.sharepoint.com/sites/ClinicalDataSubmissions/Vendor_Study_ABC/2026/Q1/")
    )
```

**Alternative: Using IAM Role for SharePoint (AWS)**:
```python
# For AWS-hosted Databricks with IAM role
.option("sharepoint.authType", "iamRole")
.option("sharepoint.iamRoleArn", dbutils.secrets.get("sharepoint", "iam-role-arn"))
```

**Trigger Configuration** (Scheduled polling):
```yaml
triggers:
  periodic:
    quartz_cron_expression: "0 0 */2 * * ?"  # Every 2 hours
    pause_status: "UNPAUSED"
    
pipeline_settings:
  trigger_mode: "availableNow"
  serverless: true
```

**Benefits**:
- ✅ Native SharePoint integration (no downloads required)
- ✅ Works with Office 365 and SharePoint Online
- ✅ OAuth 2.0 authentication
- ✅ Supports nested folder structures

**Considerations**:
- ⚠️ Requires IAM role configuration and SharePoint permissions
- ⚠️ Poll-based (not event-driven) - use appropriate polling interval
- ⚠️ SharePoint API rate limits apply

---

#### **Pattern Comparison**

| Feature | UC Volume | SFTP | SharePoint |
|---------|-----------|------|------------|
| **Trigger Type** | Event-driven (file arrival) | Poll-based (scheduled) | Poll-based (scheduled) |
| **Setup Complexity** | Low | Medium | Medium-High |
| **Latency** | Near real-time | Based on poll interval | Based on poll interval |
| **External Dependencies** | None | SFTP server connectivity | IAM role + SharePoint permissions |
| **Best For** | Databricks-native workflows | Legacy SFTP vendors | Enterprise SharePoint environments |
| **Security** | UC governance built-in | SSH keys/passwords in secrets | OAuth 2.0 + managed identity |

**Recommendation**: Use **UC Volume pattern** for new implementations. Use **SFTP/SharePoint** patterns when vendors cannot change their existing submission workflows.

---

#### **Common Benefits Across All Patterns**

- ✅ **Event-Driven or Scheduled**: Pipeline runs when new data arrives (or at configured intervals)
- ✅ **Cost-Efficient**: Serverless compute scales to zero when idle
- ✅ **Automatic**: No manual intervention required
- ✅ **Scalable**: Auto-scaling handles any data volume
- ✅ **Resilient**: Autoloader tracks processed files and handles failures

### Pipeline Task Flow

#### **Bronze Layer**: Study-Level Vendor Data Ingestion

**`bronze_vendor_data`** (Streaming table)
- **Purpose**: Ingest study-level vendor files submitted multiple times per day/week/month throughout trial duration
- **Technology**: Autoloader (streaming ingestion with schema inference)
- **File Formats**: CSV, BDAT (SAS), Parquet, JSON
- **Schema Evolution**: Enabled via `cloudFiles.schemaEvolutionMode = "addNewColumns"`
- **Vendors send data repeatedly**: Same study data updated/corrected over time
- **Pipeline Trigger**: File arrival trigger via Unity Catalog Volume notifications automatically starts SDP pipeline on new vendor file submission
- **Execution Mode**: `trigger(availableNow=True)` for event-driven batch processing (process all available files, then stop)

```python
import pyspark.pipelines as dp

@dp.table(comment="Bronze layer - study-level vendor data ingestion with file arrival trigger")
def bronze_vendor_data():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("cloudFiles.schemaLocation", "/checkpoints/vendor_data/schema")
        .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
        .load("/Volumes/catalog/schema/vendor_submissions/")
    )

# Pipeline configuration (in databricks.yml or pipeline settings)
# trigger: availableNow=True (event-driven batch processing)
# workflow_trigger: file_arrival on Unity Catalog Volume /vendor_submissions/
```

#### **Validation Rules Metadata**: Configuration Stored in Delta Tables

**`md_conformance_validation_rules`** (Delta table)
- Stores all validation rules for each DTA entity
- Joined at **Step 2 (DQ Validation)** of each validation flow
- Contains: `rule_id`, `entity`, `constraint`, `severity` (CRITICAL/WARNING), `action` (DROP/FLAG)

```python
# Metadata table structure
md_conformance_validation_rules = [
    {"entity": "TC", "constraint": "TEST_CODE IS NOT NULL", "severity": "CRITICAL", "action": "DROP"},
    {"entity": "TC", "constraint": "TEST_UNIT IN (...)", "severity": "WARNING", "action": "FLAG"},
    # ... more rules
]
```

#### **Silver Layer**: Parallel Validation Flows (4-Step Pattern per Entity)

Each DTA library entity (TV, TC, CL, Times & Visits, OA, DIP) follows the **same 4-step validation pattern**:

**Example: TC (Test Concepts) Validation Flow**

**Step 1: Read TC Data** (`bronze_vendor_data_tc`)
- Streaming table
- Reads TC-specific records from Bronze
- Filters by entity type or data pattern

```python
@dp.table(comment="Step 1: Read TC data from Bronze")
def bronze_vendor_data_tc():
    return spark.readStream.table("bronze_vendor_data") \
        .filter("record_type = 'TC' OR test_code IS NOT NULL")
```

**Step 2: DQ Validation with Rules** (`tc_dq_validated`)
- Streaming table
- **Joins with validation rules metadata** from `md_conformance_validation_rules`
- **CRITICAL rules** → DROP records + log to audit
- **WARNING rules** → FLAG records + log to audit

```python
@dp.table(comment="Step 2: DQ validation with metadata-driven rules")
@dp.expect_or_drop("tc_critical_test_code", "TEST_CODE IS NOT NULL")
@dp.expect_or_drop("tc_critical_format", "TEST_FORMAT IN ('CHAR', 'NUM')")
@dp.expect("tc_warning_length", "length(TEST_VALUE) <= 50")
def tc_dq_validated():
    tc_data = spark.readStream.table("bronze_vendor_data_tc")
    
    # Join with validation rules from metadata
    rules = spark.table("md_conformance_validation_rules") \
        .filter("entity = 'TC' AND is_active = 'Y'")
    
    # Apply rules dynamically (simplified example)
    return tc_data  # Rules applied via @dp.expect_* decorators
```

**Step 3: Transform to Generic Structure** (`tc_transformed`)
- Streaming table
- Standardize column names (vendor-specific → generic)
- Apply data type conversions
- Map to generic schema

```python
@dp.table(comment="Step 3: Transform to generic structure")
def tc_transformed():
    return (
        spark.readStream.table("tc_dq_validated")
        .withColumnRenamed("VENDOR_TEST_CD", "TEST_CODE")
        .withColumnRenamed("VENDOR_TEST_VAL", "TEST_VALUE")
        .withColumn("TEST_VALUE", col("TEST_VALUE").cast("string"))
        # ... more transformations
    )
```

**Step 4: Auto CDC for Change Tracking** (`tc_silver`)
- Streaming table with SCD Type 2
- **Handles vendor re-submissions**: INSERT, UPDATE, DELETE
- **Tracks changes**: `__START_AT`, `__END_AT`, `__CURRENT` columns automatically added
- **Sequence by**: `submission_timestamp` or `file_received_date`
- **Keys**: `STUDY_ID`, `SUBJECT_ID`, `TEST_CODE`, `VISIT`

```python
@dp.table(comment="Step 4: Auto CDC - Track vendor re-submissions")
def tc_silver():
    return (
        dp.read_stream("tc_transformed")
        .apply_changes(
            target="tc_silver",
            keys=["STUDY_ID", "SUBJECT_ID", "TEST_CODE", "VISIT"],
            sequence_by="submission_timestamp",
            stored_as_scd_type=2,
            track_history_column_list=["TEST_VALUE", "TEST_UNIT", "REFERENCE_RANGE"],
            ignore_null_updates=True
        )
    )
```

**Result of Auto CDC** (Example: Vendor submits GLUC test 3 times with corrections):

| STUDY_ID | SUBJECT_ID | TEST_CODE | TEST_VALUE | submission_timestamp | __START_AT | __END_AT | __CURRENT |
|----------|------------|-----------|------------|---------------------|------------|----------|-----------|
| STU001 | SUB001 | GLUC | 95 | 2026-01-01 | 2026-01-01 | 2026-01-15 | false |
| STU001 | SUB001 | GLUC | 98 | 2026-01-15 | 2026-01-15 | 2026-02-01 | false |
| STU001 | SUB001 | GLUC | 101 | 2026-02-01 | 2026-02-01 | NULL | **true** |

**All Parallel Validation Flows** (Same 4-Step Pattern):

1. **TV Flow**: `bronze_vendor_data_tv` → `tv_dq_validated` → `tv_transformed` → `tv_silver` (Auto CDC)
2. **TC Flow**: `bronze_vendor_data_tc` → `tc_dq_validated` → `tc_transformed` → `tc_silver` (Auto CDC)
3. **CL Flow**: `bronze_vendor_data_cl` → `cl_dq_validated` → `cl_transformed` → `cl_silver` (Auto CDC)
4. **OA Flow**: `bronze_vendor_data_oa` → `oa_dq_validated` → `oa_transformed` → `oa_silver` (Auto CDC)
5. **DIP Flow**: `bronze_vendor_data_dip` → `dip_dq_validated` → `dip_transformed` → `dip_silver` (Auto CDC)
6. **Times & Visits Flow**: `bronze_vendor_data_tv2` → `tv2_dq_validated` → `tv2_transformed` → `tv2_silver` (Auto CDC)

#### **Validation Sink**: Non-Blocking Audit Log

**`audit_delta_sink`** (Sink - non-blocking)
- Captures all validation failures from all flows
- CRITICAL failures (records dropped)
- WARNING flags (records passed but flagged)
- Drift metrics and validation results per entity
- Writes asynchronously without blocking validation tasks

```python
@dp.table(comment="Audit sink - non-blocking validation results")
def audit_delta_sink():
    # Union audit records from all validation flows
    return (
        spark.table("tc_dq_validated").filter("is_valid = false")
        .union(spark.table("tv_dq_validated").filter("is_valid = false"))
        .union(spark.table("cl_dq_validated").filter("is_valid = false"))
        # ... all other flows
        .select("audit_id", "entity", "study_id", "rule", "severity", "action", "record_details")
    )
```

#### **Gold Layer**: Study-Level Validated Data

**`study_level_gold schema`** (Materialized view)
- Study-level validated data aggregated from all validation flows
- DTA validates against study-level vendor submissions
- **Specific table structure out of scope** (focus on validation process, not final schema)
- Downstream analytics and reporting use this schema

---

## SDP Expectations Framework

### Expectations Hierarchy

The validation framework leverages **SDP Expectations** ([documentation](https://docs.databricks.com/aws/en/ldp/expectation-patterns)) with a three-tier model for granular data quality control:

![Expectations Hierarchy](./diagrams/12_expectations_hierarchy.png)

**Expectations Flow**:

1. **FAIL Expectations** (`expect_or_fail`) → Pipeline stops if any record fails; critical blocking validations
2. **QUARANTINE Expectations** (`expect_or_drop`) → Invalid records dropped and isolated; severe but non-blocking
3. **WARN Expectations** (`expect`) → Records flagged but processed; informational issues

### Implementation Example: Transfer Variables Validation

```python
import pyspark.pipelines as dp

@dp.table(
    comment="Silver layer - Transfer Variables validation with expectations"
)
@dp.expect_or_fail("tv_required_columns", "SUBJID IS NOT NULL AND VISIT IS NOT NULL")
@dp.expect_or_fail("tv_data_type_match", "typeof(SUBJID) = 'string' AND typeof(AGE) IN ('int', 'bigint')")
@dp.expect_or_drop("tv_codelist_values", "SEX IN ('M', 'F', 'U', 'UNKNOWN')")
@dp.expect_or_drop("tv_length_major_violation", "length(SUBJID) <= 30")  # 1.5x DTA max_length
@dp.expect("tv_length_minor_violation", "length(SUBJID) <= 24")  # 1.2x DTA max_length
@dp.expect("tv_unexpected_nulls", "VISIT IS NOT NULL OR dta_populate_flag = 'N'")
def silver_tv_validated():
    # Join vendor data with DTA metadata
    vendor_data = spark.readStream.table("bronze_vendor_data")
    dta_tv_meta = spark.table("gold.md_dta_transfer_variables") \
        .filter(f"dta_id = '{spark.conf.get('pipeline.dta_id')}'")
    
    return vendor_data.join(dta_tv_meta, vendor_data.column_name == dta_tv_meta.transfer_variable_name, "left")
```

### Metadata-Driven Expectations

For production, expectations are loaded from `md_conformance_validation_rules` metadata table:

```python
# Load validation rules from metadata
validation_rules = spark.table("gold.md_conformance_validation_rules") \
    .filter("library_type = 'transfer_variables' AND is_active = 'Y'") \
    .collect()

# Apply expectations dynamically
for rule in validation_rules:
    if rule.action == "FAIL":
        dp.expect_or_fail(rule.constraint_name, rule.constraint)
    elif rule.action == "QUARANTINE":
        dp.expect_or_drop(rule.constraint_name, rule.constraint)
    elif rule.action == "WARN":
        dp.expect(rule.constraint_name, rule.constraint)
```

### Validation Rules by Library Type

**FAIL Rules** (Critical - Pipeline Blocking):
```python
{
    "tv_required_columns_present": "SUBJID IS NOT NULL AND VISIT IS NOT NULL",
    "tv_data_type_match": "typeof(SUBJID) = 'string' AND typeof(AGE) = 'integer'",
    "tc_required_test_code": "TEST_CODE IS NOT NULL",
    "cl_codelist_required": "CODELIST_NAME IS NOT NULL AND CODELIST_VALUE IS NOT NULL"
}
```

**QUARANTINE Rules** (Severe - Drop Records):
```python
{
    "tv_length_major_violation": "length(SUBJID) <= anticipated_max_length * 1.5",
    "tv_codelist_values": "SEX IN (SELECT codelist_value FROM dta_codelists WHERE codelist_name = 'SEX')",
    "tc_unit_mismatch": "TEST_UNIT IN (SELECT unit FROM dta_test_concepts WHERE test_code = TEST_CODE)"
}
```

**WARN Rules** (Minor - Flag Only):
```python
{
    "tv_length_minor_violation": "length(SUBJID) <= anticipated_max_length * 1.2",
    "tv_unexpected_nulls": "VISIT IS NOT NULL OR populate_for_all_records = 'No'",
    "tc_reference_range_outlier": "TEST_VALUE BETWEEN lower_limit AND upper_limit"
}
```

---

## Data Drift Detection Strategy

### Conformance Dimensions

| Dimension | Description | DTA Source Table | Validation Type |
|-----------|-------------|------------------|-----------------|
| **Transfer Variables** | Column names, data types, order, length | `md_dta_transfer_variables` | Schema + Data |
| **Test Concepts** | Test concept values, mappings | `md_dta_vendor_test_concepts` | Data |
| **Codelists** | Codelist values, SDTM mappings | `md_dta_codelists` | Data |
| **Operational Agreements** | Trial-specific agreements | `md_dta_operational_agreement` | Metadata |
| **Data Ingestion Parameters** | File formats, delimiters, encodings | `md_dta_data_ingestion_parameters` | Metadata |

### Transfer Variables (TV) Validation Example

**DTA Definition** (from `md_dta_transfer_variables`):
```
transfer_variable_name: "SUBJID"
format: "TEXT"
anticipated_max_length: 20
populate_for_all_records: "Yes"
codelist_values: []
```

**Vendor Data Validation**:
1. **Column Exists**: `SUBJID` must be present
2. **Data Type Match**: Must be string/text
3. **Length Validation**: Max 20 characters
4. **NULL Check**: No NULL values (populate_for_all_records = Yes)
5. **Codelist Validation**: If codelist_values defined, check against allowed values

**Drift Detection**:
- If vendor sends `SUBJID` with length 30 → **WARN** (exceeds anticipated max)
- If vendor sends `SUBJID` with NULL → **FAIL** (mandatory field)
- If vendor renames to `SUBJECT_ID` → **FAIL** (column missing)

---

## SDP Feature Implementation

### 0. Expectations - Data Quality Validation

**Use Case**: Enforce data quality rules at validation step with three severity levels to handle CRITICAL, WARNING, and INFO validation failures.

**Documentation**: [SDP Expectations](https://docs.databricks.com/aws/en/ldp/expectation-patterns)

**Three-Tier Validation Model**:

| Expectation Type | Decorator | Severity | Action | Use Case |
|-----------------|-----------|----------|--------|----------|
| **FAIL** | `@dp.expect_or_fail()` | CRITICAL | Pipeline stops if any record fails | Mandatory fields, data type mismatches |
| **DROP** | `@dp.expect_or_drop()` | WARNING | Drop invalid records, continue pipeline | Codelist violations, format errors |
| **WARN** | `@dp.expect()` | INFO | Flag records but pass through | Minor issues, informational alerts |

**Implementation Example**:

```python
import pyspark.pipelines as dp

@dp.table(comment="TC Step 2: DQ validation with expectations")
# CRITICAL: Pipeline stops if these fail
@dp.expect_or_fail("tc_critical_test_code", "TEST_CODE IS NOT NULL")
@dp.expect_or_fail("tc_critical_data_type", "typeof(TEST_VALUE) IN ('string', 'double', 'int')")

# WARNING: Drop invalid records, log to audit
@dp.expect_or_drop("tc_warning_codelist", "TEST_UNIT IN (SELECT unit FROM gold.md_dta_vendor_test_concepts)")
@dp.expect_or_drop("tc_warning_length", "length(TEST_CODE) <= 20")

# INFO: Flag but allow through
@dp.expect("tc_info_missing_optional", "REFERENCE_RANGE IS NOT NULL OR test_type <> 'LAB'")
@dp.expect("tc_info_unexpected_format", "TEST_VALUE NOT LIKE '%[^0-9.]%' OR test_type <> 'NUMERIC'")
def tc_dq_validated():
    tc_data = spark.readStream.table("bronze_vendor_data_tc")
    
    # Join with DTA metadata
    dta_tc = spark.table("gold.md_dta_vendor_test_concepts") \
        .filter(f"dta_id = '{spark.conf.get('pipeline.dta_id')}'")
    
    return tc_data.join(dta_tc, "test_code", "left")
```

**Metadata-Driven Expectations Pattern**:

Load validation rules dynamically from `md_conformance_validation_rules` Delta table:

```python
# Load rules from metadata
validation_rules = spark.table("md_conformance_validation_rules") \
    .filter("entity = 'TC' AND is_active = 'Y'") \
    .collect()

# Build expectation decorators dynamically
expectations = []
for rule in validation_rules:
    if rule.severity == "CRITICAL":
        expectations.append(f"@dp.expect_or_fail('{rule.rule_id}', \"{rule.constraint}\")")
    elif rule.severity == "WARNING":
        expectations.append(f"@dp.expect_or_drop('{rule.rule_id}', \"{rule.constraint}\")")
    else:  # INFO
        expectations.append(f"@dp.expect('{rule.rule_id}', \"{rule.constraint}\")")

# Apply expectations programmatically (simplified)
# In practice, use decorators or dynamic function generation
```

**Example Metadata Table** (`md_conformance_validation_rules`):

| rule_id | entity | constraint | severity | action | is_active |
|---------|--------|-----------|----------|--------|-----------|
| tc_001 | TC | TEST_CODE IS NOT NULL | CRITICAL | FAIL | Y |
| tc_002 | TC | TEST_UNIT IN (...) | WARNING | DROP | Y |
| tc_003 | TC | TEST_VALUE IS NOT NULL | INFO | WARN | Y |

**Benefits**:
- ✅ **Three-Tier Control**: Granular handling of different severity levels
- ✅ **Pipeline Resilience**: Drop bad records instead of stopping entire pipeline
- ✅ **Metadata-Driven**: Add/modify rules without code changes
- ✅ **Audit Trail**: All expectation failures logged to event log
- ✅ **Step 2 Integration**: Seamlessly integrates with DQ Validation step of 4-step pattern

---

### 1. Flows - Multiple Sources to Single Target

**Use Case**: Multiple vendor submission folders writing to the same Bronze table.

**Documentation**: [SDP Flows](https://docs.databricks.com/aws/en/ldp/flows)

**Implementation**:

```python
import pyspark.pipelines as dp

# Create the target streaming table
dp.create_streaming_table("bronze_vendor_data")

# Flow 1: North America vendor submissions
@dp.append_flow(target="bronze_vendor_data")
def vendor_na_flow():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .load("/Volumes/catalog/schema/vendor_na/")
        .withColumn("region", lit("NA"))
    )

# Flow 2: Europe vendor submissions
@dp.append_flow(target="bronze_vendor_data")
def vendor_eu_flow():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .load("/Volumes/catalog/schema/vendor_eu/")
        .withColumn("region", lit("EU"))
    )

# Flow 3: Asia vendor submissions
@dp.append_flow(target="bronze_vendor_data")
def vendor_apac_flow():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .load("/Volumes/catalog/schema/vendor_apac/")
        .withColumn("region", lit("APAC"))
    )
```

**Benefits**:
- ✅ **Incremental Additions**: Add new vendor regions without full refresh
- ✅ **Independent Checkpoints**: Each flow maintains its own checkpoint
- ✅ **Union Alternative**: More efficient than `UNION` for streaming data

**Backfill Pattern** (ONCE flow for historical data):

```python
# One-time backfill of historical data
@dp.append_flow(target="bronze_vendor_data")
def vendor_historical_backfill():
    return spark.read.parquet("/Volumes/catalog/schema/historical_archive/") \
        .withColumn("is_backfill", lit(True))
```

SQL equivalent:
```sql
CREATE FLOW vendor_historical_backfill
AS INSERT INTO ONCE bronze_vendor_data BY NAME
SELECT *, TRUE as is_backfill FROM parquet.`/Volumes/catalog/schema/historical_archive/`;
```

---

### 2. Auto CDC - Simplified Change Data Capture

**Use Case**: Track vendor data changes over time with SCD Type 2.

**Documentation**: [Auto CDC](https://docs.databricks.com/aws/en/ldp/database-replication)

**Implementation**:

```python
import pyspark.pipelines as dp

@dp.table(
    comment="Gold layer - Transfer Variables with SCD Type 2 tracking"
)
def gold_tv_validated():
    return (
        dp.read_stream("silver_tv_validated")
        .apply_changes(
            target="gold_tv_validated",
            keys=["SUBJID", "VISIT", "VARIABLE_NAME"],
            sequence_by="processing_timestamp",
            stored_as_scd_type=2,
            track_history_column_list=["VARIABLE_VALUE", "DATA_TYPE", "LENGTH"],
            track_history_except_column_list=["processing_timestamp", "file_id"]
        )
    )
```

**What Auto CDC Handles Automatically**:
- ✅ **SCD Type 2 Columns**: `__START_AT`, `__END_AT`, `__CURRENT` added automatically
- ✅ **Change Detection**: Compares tracked columns to detect updates
- ✅ **Historical Records**: Previous versions retained with end timestamps
- ✅ **Upsert Logic**: INSERT for new, UPDATE for existing (close old record, insert new)

**Example Output**:

| SUBJID | VISIT | VARIABLE_NAME | VARIABLE_VALUE | __START_AT | __END_AT | __CURRENT |
|--------|-------|---------------|----------------|------------|----------|-----------|
| 001 | Week1 | AGE | 45 | 2026-01-01 | 2026-02-01 | false |
| 001 | Week1 | AGE | 46 | 2026-02-01 | NULL | true |

**SQL Equivalent**:

```sql
CREATE STREAMING TABLE gold_tv_validated;

CREATE FLOW gold_tv_cdc
AS APPLY CHANGES INTO gold_tv_validated
FROM STREAM(silver_tv_validated)
KEYS (SUBJID, VISIT, VARIABLE_NAME)
SEQUENCE BY processing_timestamp
STORED AS SCD TYPE 2
TRACK HISTORY ON (VARIABLE_VALUE, DATA_TYPE, LENGTH);
```

---

### 3. Sinks - Non-Blocking Audit Writes

**Use Case**: Write validation failures to audit tables without blocking pipeline execution.

**Documentation**: [SDP Sinks](https://docs.databricks.com/aws/en/ldp/ldp-sinks)

**Implementation**:

```python
import pyspark.pipelines as dp

# Primary validation table (Silver)
@dp.table(
    comment="Silver - Transfer Variables validation"
)
@dp.expect_or_fail("tv_required_fields", "SUBJID IS NOT NULL")
def silver_tv_validated():
    return spark.readStream.table("bronze_vendor_data")

# Audit sink - captures validation failures
@dp.table(
    comment="Audit sink - non-blocking write of validation failures"
)
def audit_conformance_sink():
    # Read event log to capture expectation failures
    event_log = spark.readStream.format("delta") \
        .option("readChangeFeed", "true") \
        .table("event_log(silver_tv_validated)")
    
    return (
        event_log
        .filter("expectation_status = 'FAIL' OR expectation_status = 'DROP'")
        .select(
            "timestamp",
            "flow_name",
            "expectation_name",
            "expectation_status",
            "record_count",
            "failed_record_count"
        )
        .writeStream
        .format("delta")
        .outputMode("append")
        .option("checkpointLocation", "/checkpoints/audit_sink")
        .toTable("l_conformance_audit")
    )
```

**Sink Benefits**:
- ✅ **Non-Blocking**: Pipeline continues even if sink write fails
- ✅ **Decoupled**: Audit logic separate from validation logic
- ✅ **Event Log**: Access to pipeline execution metadata
- ✅ **Multiple Sinks**: Write to multiple destinations (Delta, external systems)

**Multiple Sink Pattern**:

```python
# Multiple sinks for different outputs
@dp.table()
def audit_sink():
    return event_log_df.writeStream.toTable("l_conformance_audit")

@dp.table()
def drift_report_sink():
    return drift_summary_df.writeStream.toTable("l_conformance_drift_summary")

@dp.table()
def quarantine_sink():
    return quarantined_records_df.writeStream.toTable("l_conformance_quarantine")
```

---

### 4. Schema Evolution - Automatic Schema Handling

**Use Case**: Vendor adds new columns to CSV files without breaking pipeline.

**Documentation**: [Schema Evolution](https://docs.databricks.com/aws/en/ldp/from-json-schema-evolution)

**Implementation**:

```python
import pyspark.pipelines as dp

@dp.table(
    comment="Bronze with automatic schema evolution"
)
def bronze_vendor_data():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("cloudFiles.schemaLocation", "/checkpoints/vendor_data/schema")
        .option("cloudFiles.schemaEvolutionMode", "addNewColumns")  # Key setting
        .option("cloudFiles.inferColumnTypes", "true")
        .load("/Volumes/catalog/schema/vendor_submissions/")
    )
```

**Schema Evolution Modes**:

| Mode | Behavior | Use Case |
|------|----------|----------|
| `addNewColumns` | Automatically add new columns discovered in files | Vendor adds optional fields |
| `rescue` | Store unparseable data in `_rescued_data` column | Malformed records |
| `failOnNewColumns` | Fail pipeline if schema changes | Strict validation |

**Example Scenario**:

**Initial CSV** (Week 1):
```csv
SUBJID,VISIT,AGE,SEX
001,Week1,45,M
```

**Updated CSV** (Week 2 - vendor adds RACE column):
```csv
SUBJID,VISIT,AGE,SEX,RACE
001,Week2,45,M,Caucasian
```

**Pipeline Behavior**:
- ✅ **Week 1**: Table created with 4 columns
- ✅ **Week 2**: `RACE` column automatically added to table schema
- ✅ **No Failure**: Pipeline continues processing
- ✅ **Historical Data**: Week 1 records have `NULL` for `RACE`

**Validation Integration**:

```python
# Drift detection for unexpected columns
@dp.table()
@dp.expect("tv_schema_drift", "array_except(column_names, dta_expected_columns) = []")
def silver_tv_validated():
    vendor_data = spark.readStream.table("bronze_vendor_data")
    dta_meta = spark.table("gold.md_dta_transfer_variables")
    
    # Flag unexpected columns for review
    return vendor_data.withColumn(
        "unexpected_columns",
        expr("filter(column_names, col -> col NOT IN (SELECT column_name FROM dta_meta))")
    )
```

---

### 5. Transformations - Data Cleansing

**Use Case**: Standardize vendor data formats before validation.

**Documentation**: [Transform Data](https://docs.databricks.com/aws/en/ldp/transform)

**Implementation**:

```python
import pyspark.pipelines as dp
from pyspark.sql.functions import trim, upper, regexp_replace, coalesce, to_date

@dp.table(
    comment="Silver - Apply transformations before validation"
)
def silver_tv_transformed():
    bronze_df = spark.readStream.table("bronze_vendor_data")
    
    # Load transformation rules from metadata
    transform_rules = spark.table("gold.md_conformance_transformation_rules") \
        .filter("library_type = 'transfer_variables' AND is_active = 'Y'") \
        .collect()
    
    # Apply transformations
    transformed_df = bronze_df
    for rule in transform_rules:
        if rule.type == "trim":
            transformed_df = transformed_df.withColumn(rule.column_name, trim(col(rule.column_name)))
        elif rule.type == "uppercase":
            transformed_df = transformed_df.withColumn(rule.column_name, upper(col(rule.column_name)))
        elif rule.type == "title_case":
            transformed_df = transformed_df.withColumn(rule.column_name, initcap(col(rule.column_name)))
        elif rule.type == "date_standardization":
            transformed_df = transformed_df.withColumn(rule.column_name, to_date(col(rule.column_name), rule.format))
        elif rule.type == "default_value":
            transformed_df = transformed_df.withColumn(rule.column_name, coalesce(col(rule.column_name), lit(rule.default_value)))
    
    return transformed_df
```

**Common Transformations**:

```python
# Trim whitespace
.withColumn("SUBJID", trim(col("SUBJID")))

# Standardize case
.withColumn("SEX", upper(col("SEX")))  # M, F, U

# Remove special characters
.withColumn("TEST_CODE", regexp_replace(col("TEST_CODE"), "[^A-Z0-9]", ""))

# Date format standardization
.withColumn("VISIT_DATE", to_date(col("VISIT_DATE"), "yyyy-MM-dd"))

# Default values for NULLs
.withColumn("POPULATION_FLAG", coalesce(col("POPULATION_FLAG"), lit("ALL")))

# Numeric rounding
.withColumn("TEST_VALUE", round(col("TEST_VALUE"), 2))
```

**Metadata-Driven Transformation Rules**:

`md_conformance_transformation_rules` table:

| source_column_name | type | format | default_value | is_active |
|-------------------|------|--------|---------------|-----------|
| SUBJID | trim | NULL | NULL | Y |
| SEX | uppercase | NULL | NULL | Y |
| VISIT_DATE | date_standardization | yyyy-MM-dd | NULL | Y |
| POPULATION_FLAG | default_value | NULL | ALL | Y |

---

## Metadata-Driven Configuration

### Metadata Tables

The conformance engine uses metadata tables to drive all validation logic:

#### 1. `md_conformance_validation_rules`

Stores validation rules for each DTA library entity.

| Column | Description | Example |
|--------|-------------|---------|
| `source_table` | Bronze table name | `bronze_vendor_data` |
| `target_table` | Silver table name | `silver_tv_validated` |
| `library_type` | DTA library entity | `transfer_variables` |
| `constraint` | Validation expression | `SUBJID IS NOT NULL` |
| `action` | FAIL / WARN / QUARANTINE | `FAIL` |
| `is_active` | Enable/disable rule | `Y` |
| `dta_id` | DTA version reference | `DTA_A` |
| `version` | DTA version | `1.0-DTA_A-v1.0` |

#### 2. `md_conformance_transformation_rules`

Defines data transformations to apply.

| Column | Description | Example |
|--------|-------------|---------|
| `source_column_name` | Column to transform | `SUBJID` |
| `type` | Transformation type | `trim`, `title_case`, `default` |
| `transform_fn_name` | UDF function name | `trim_udf` |
| `is_active` | Enable/disable | `Y` |

#### 3. `md_conformance_source_metadata`

Maps vendor data sources to DTA library entities.

| Column | Description | Example |
|--------|-------------|---------|
| `dimension_table` | DTA library type | `transfer_variables` |
| `target_table` | Silver target | `silver_tv_validated` |
| `source_details` | Volume path | `/Volumes/.../vendor_data/` |
| `impacted_input_tables` | Bronze tables | `bronze_vendor_data` |
| `load_type` | incremental / one_time | `incremental` |
| `dta_id` | DTA reference | `DTA_A` |

#### 4. `md_conformance_cdc`

CDC configuration for SCD Type 2 tracking.

| Column | Description | Example |
|--------|-------------|---------|
| `source` | Pipeline source | `TV_VALIDATION` |
| `input_table` | Input table | `bronze_vendor_data` |
| `key_attr` | Primary key | `SUBJID,VISIT` |
| `scd_type` | 1 or 2 | `2` |
| `compute_cdc` | Y / N | `Y` |

---

## Parallel Task Execution Model

### Single Pipeline with Parallel Tasks

The conformance engine runs as a **single SDP pipeline** with parallel validation flows. Each DTA entity validation flow follows a **4-step pattern** (Read → DQ Validation → Transform → Auto CDC), and all flows execute in parallel within the same pipeline.

**Pipeline Structure** (Full Implementation with 4-Step Pattern):

```python
import pyspark.pipelines as dp
from pyspark.sql.functions import *

# ==================== METADATA: VALIDATION RULES ====================
# This Delta table is joined at Step 2 (DQ Validation) of each flow
# Contains CRITICAL and WARNING rules for all entities

validation_rules_metadata = spark.table("md_conformance_validation_rules")
# Example structure:
# | entity | constraint | severity | action |
# |--------|-----------|----------|--------|
# | TC     | TEST_CODE IS NOT NULL | CRITICAL | DROP   |
# | TC     | TEST_UNIT IN (...) | WARNING  | FLAG   |

# ==================== BRONZE: STUDY-LEVEL VENDOR DATA ====================
dp.create_streaming_table("bronze_vendor_data", comment="Study-level vendor files (CSV, BDAT, Parquet, JSON)")

@dp.append_flow(target="bronze_vendor_data")
def vendor_na_flow():
    return spark.readStream.format("cloudFiles") \
        .option("cloudFiles.format", "csv") \
        .option("cloudFiles.schemaEvolutionMode", "addNewColumns") \
        .load("/Volumes/catalog/schema/vendor_na/")

# ==================== TC VALIDATION FLOW (4 STEPS) ====================

# STEP 1: Read TC Data
@dp.table(comment="TC Step 1: Read TC data from Bronze")
def bronze_vendor_data_tc():
    return spark.readStream.table("bronze_vendor_data") \
        .filter("record_type = 'TC' OR test_code IS NOT NULL")

# STEP 2: DQ Validation (with metadata rules)
@dp.table(comment="TC Step 2: DQ validation with metadata-driven rules")
@dp.expect_or_drop("tc_critical_test_code", "TEST_CODE IS NOT NULL")
@dp.expect_or_drop("tc_critical_format", "TEST_FORMAT IN ('CHAR', 'NUM')")
@dp.expect("tc_warning_length", "length(TEST_VALUE) <= 50")
def tc_dq_validated():
    tc_data = spark.readStream.table("bronze_vendor_data_tc")
    
    # Join with validation rules metadata
    rules = spark.table("md_conformance_validation_rules") \
        .filter("entity = 'TC' AND is_active = 'Y'")
    
    # Apply DTA metadata validation
    dta_tc = spark.table("gold.md_dta_vendor_test_concepts")
    
    return tc_data.join(dta_tc, "test_code", "left")  # CRITICAL/WARNING rules applied via decorators

# STEP 3: Transform to Generic Structure
@dp.table(comment="TC Step 3: Transform to generic structure")
def tc_transformed():
    return (
        spark.readStream.table("tc_dq_validated")
        .withColumnRenamed("VENDOR_TEST_CD", "TEST_CODE")
        .withColumnRenamed("VENDOR_TEST_VAL", "TEST_VALUE")
        .withColumn("TEST_VALUE", col("TEST_VALUE").cast("string"))
        .withColumn("TEST_CODE", trim(upper(col("TEST_CODE"))))
        # ... more transformations
    )

# STEP 4: Auto CDC (SCD Type 2 for vendor re-submissions)
@dp.table(comment="TC Step 4: Auto CDC - Track vendor re-submissions with SCD Type 2")
def tc_silver():
    return (
        dp.read_stream("tc_transformed")
        .apply_changes(
            target="tc_silver",
            keys=["STUDY_ID", "SUBJECT_ID", "TEST_CODE", "VISIT"],
            sequence_by="submission_timestamp",
            stored_as_scd_type=2,
            track_history_column_list=["TEST_VALUE", "TEST_UNIT", "REFERENCE_RANGE"],
            ignore_null_updates=True
        )
    )

# ==================== TV VALIDATION FLOW (4 STEPS) ====================

# STEP 1: Read TV Data
@dp.table(comment="TV Step 1: Read Transfer Variables from Bronze")
def bronze_vendor_data_tv():
    return spark.readStream.table("bronze_vendor_data") \
        .filter("record_type = 'TV'")

# STEP 2: DQ Validation
@dp.table(comment="TV Step 2: DQ validation")
@dp.expect_or_drop("tv_critical_subjid", "SUBJID IS NOT NULL")
@dp.expect("tv_warning_length", "length(VARIABLE_VALUE) <= 200")
def tv_dq_validated():
    return spark.readStream.table("bronze_vendor_data_tv") \
        .join(spark.table("gold.md_dta_transfer_variables"), "column_name", "left")

# STEP 3: Transform
@dp.table(comment="TV Step 3: Transform")
def tv_transformed():
    return spark.readStream.table("tv_dq_validated") \
        .withColumnRenamed("VENDOR_VAR_NM", "VARIABLE_NAME") \
        .withColumn("VARIABLE_NAME", upper(col("VARIABLE_NAME")))

# STEP 4: Auto CDC
@dp.table(comment="TV Step 4: Auto CDC")
def tv_silver():
    return (
        dp.read_stream("tv_transformed")
        .apply_changes(
            target="tv_silver",
            keys=["STUDY_ID", "SUBJID", "VISIT", "VARIABLE_NAME"],
            sequence_by="submission_timestamp",
            stored_as_scd_type=2
        )
    )

# ==================== CL VALIDATION FLOW (4 STEPS) ====================

# STEP 1: Read CL Data
@dp.table(comment="CL Step 1: Read Codelists from Bronze")
def bronze_vendor_data_cl():
    return spark.readStream.table("bronze_vendor_data") \
        .filter("record_type = 'CL'")

# STEP 2: DQ Validation
@dp.table(comment="CL Step 2: DQ validation")
@dp.expect_or_drop("cl_critical_codelist", "CODELIST_NAME IS NOT NULL")
def cl_dq_validated():
    return spark.readStream.table("bronze_vendor_data_cl") \
        .join(spark.table("gold.md_dta_codelists"), "codelist_name", "left")

# STEP 3: Transform
@dp.table(comment="CL Step 3: Transform")
def cl_transformed():
    return spark.readStream.table("cl_dq_validated")  # transformations here

# STEP 4: Auto CDC
@dp.table(comment="CL Step 4: Auto CDC")
def cl_silver():
    return (
        dp.read_stream("cl_transformed")
        .apply_changes(
            target="cl_silver",
            keys=["STUDY_ID", "CODELIST_NAME", "CODE_VALUE"],
            sequence_by="submission_timestamp",
            stored_as_scd_type=2
        )
    )

# ==================== OA, DIP, TIMES & VISITS FLOWS ====================
# (Similar 4-step pattern for each: Read → DQ → Transform → Auto CDC)

# OA Flow (4 steps): bronze_vendor_data_oa → oa_dq_validated → oa_transformed → oa_silver
# DIP Flow (4 steps): bronze_vendor_data_dip → dip_dq_validated → dip_transformed → dip_silver
# Times & Visits Flow (4 steps): bronze_vendor_data_tv2 → tv2_dq_validated → tv2_transformed → tv2_silver

# ==================== VALIDATION SINK (NON-BLOCKING) ====================

# Audit Sink - Non-blocking capture of validation failures
@dp.table(comment="Audit sink - validation failures from all flows")
def audit_delta_sink():
    # Non-blocking sink - captures validation failures from all entity flows
    return (
        spark.table("tc_dq_validated").filter("is_valid = false")
        .union(spark.table("tv_dq_validated").filter("is_valid = false"))
        .union(spark.table("cl_dq_validated").filter("is_valid = false"))
        .union(spark.table("oa_dq_validated").filter("is_valid = false"))
        .union(spark.table("dip_dq_validated").filter("is_valid = false"))
        .union(spark.table("tv2_dq_validated").filter("is_valid = false"))
        .select(
            "audit_id", 
            "entity", 
            "study_id", 
            "rule", 
            "severity", 
            "action", 
            "record_details"
        )
    )

# ==================== GOLD LAYER: STUDY-LEVEL VALIDATED DATA ====================

# study_level_gold schema (materialized view)
# Aggregated validated data from all Silver CDC tables (tc_silver, tv_silver, cl_silver, etc.)
# Specific table structure out of scope - focus on validation process

@dp.table(comment="Study-level validated TC data")
def study_level_gold_tc():
    return spark.table("tc_silver").filter("__CURRENT = true")

@dp.table(comment="Study-level validated TV data")
def study_level_gold_tv():
    return spark.table("tv_silver").filter("__CURRENT = true")

# ... additional gold tables for CL, OA, DIP, Times & Visits
```

### Task Execution Flow

**Execution Pattern** (Left-to-Right, 4-Step per Entity):

```
┌────────────────────────────────────────────────────────────────────────────┐
│                     Validation Rules Metadata (Delta)                       │
│                     md_conformance_validation_rules                         │
│              (CRITICAL/WARNING rules, joined at Step 2)                     │
└──────────────────────────────┬─────────────────────────────────────────────┘
                               │ (lookup rules)
                               ↓
┌─────────────────┐     ┌──────────────────────────────────────────┐
│  BRONZE LAYER   │     │        SILVER LAYER - PARALLEL FLOWS      │
│                 │     │                                           │
│ bronze_vendor_  │────→│  TC Flow (4 steps):                       │
│ data            │     │  ① bronze_vendor_data_tc                  │
│                 │     │  ② tc_dq_validated (with rules)           │
│ Study-level     │     │  ③ tc_transformed                         │
│ vendor files    │     │  ④ tc_silver (Auto CDC - SCD Type 2)      │
│ (CSV, BDAT,     │     │                                           │
│  Parquet, JSON) │     │  TV Flow (4 steps):                       │
│                 │     │  ① bronze_vendor_data_tv                  │
│ Vendors send    │     │  ② tv_dq_validated (with rules)           │
│ multiple times  │     │  ③ tv_transformed                         │
│ per day/week    │     │  ④ tv_silver (Auto CDC)                   │
│                 │     │                                           │
│                 │     │  CL, OA, DIP, Times & Visits Flows...    │
│                 │     │  (Same 4-step pattern)                    │
└─────────────────┘     └────┬──────────────────────┬───────────────┘
                             │                      │
                             ↓                      ↓
                   ┌─────────────────┐    ┌───────────────────────┐
                   │  SINK (NON-     │    │    GOLD LAYER         │
                   │   BLOCKING)     │    │                       │
                   │                 │    │ study_level_gold      │
                   │ audit_delta_    │    │ schema                │
                   │ sink            │    │                       │
                   │                 │    │ Materialized views    │
                   │ • CRITICAL      │    │ of validated data     │
                   │   failures      │    │                       │
                   │ • WARNING flags │    │ (Current version:     │
                   │ • Drift metrics │    │  __CURRENT = true)    │
                   └─────────────────┘    └───────────────────────┘
```

**Key Execution Features**:
- **Single Bronze Table**: All vendor files ingested into `bronze_vendor_data`
- **Metadata-Driven Rules**: Validation rules from Delta table joined at Step 2
- **4-Step Pattern per Entity**: Read → DQ Validation → Transform → Auto CDC
- **Parallel Flows**: All 6 entity flows (TV, TC, CL, OA, DIP, Times & Visits) run concurrently
- **Auto CDC Tracking**: SCD Type 2 handles vendor re-submissions (INSERT/UPDATE/DELETE)
- **Non-Blocking Sink**: Audit logs captured without blocking validation
- **Gold Layer**: Study-level validated data (current versions only)

### Benefits of Single Pipeline Architecture

**Key Architectural Advantages**:
- ✅ **Single Bronze Table**: All vendor files (CSV, BDAT, Parquet, JSON) ingested into one streaming table
- ✅ **Metadata-Driven Validation**: Rules stored in Delta tables, dynamically applied at DQ step
- ✅ **4-Step Validation Pattern**: Standardized flow (Read → DQ → Transform → CDC) for all entities
- ✅ **Parallel Entity Processing**: All 6 DTA entities (TV, TC, CL, OA, DIP, Times & Visits) validated concurrently
- ✅ **Auto CDC for Re-Submissions**: SCD Type 2 automatically tracks vendor data updates (INSERT/UPDATE/DELETE)
- ✅ **Non-Blocking Audit**: Validation failures logged asynchronously without blocking flows
- ✅ **Simplified Orchestration**: One pipeline to deploy, monitor, and manage
- ✅ **Unified Monitoring**: Single SDP dashboard for all validation activities
- ✅ **Event Log**: Unified event log for all validation activities
- ✅ **Failure Isolation**: Failed flow doesn't stop other parallel flows

**vs. Multiple Separate Pipelines**:

| Aspect | Single Pipeline (SDP) | Multiple Pipelines |
|--------|----------------------|-------------------|
| **Orchestration** | One pipeline | N pipelines (one per entity) |
| **Monitoring** | Single dashboard | N dashboards |
| **Bronze Layer** | Single table for all vendors | N separate bronze tables |
| **Validation Rules** | Centralized metadata table | Duplicated rule definitions |
| **Auto CDC** | Consistent SCD Type 2 pattern | Inconsistent implementations |
| **Audit Logging** | Unified sink | Fragmented logs |
| **Deployment** | Deploy once | Deploy N times |
| **Dependencies** | Automatic | Manual coordination |
| **Resource Sharing** | Efficient compute utilization | Duplicated overhead |

---

## Drift Reporting

### Drift Report Table: `t_conformance_audit`

Captures all validation failures for analysis and reporting.

| Column | Description | Example |
|--------|-------------|---------|
| `audit_id` | Unique audit record ID | `AUD_123456` |
| `dta_id` | DTA reference | `DTA_A` |
| `dta_version` | DTA version | `1.0-DTA_A-v1.0` |
| `library_type` | DTA entity | `transfer_variables` |
| `validation_table` | Pipeline table | `silver_tv_validated` |
| `processing_time` | Timestamp | `1675123456` |
| `business_date` | Data date | `2026-02-04` |
| `record_identifier` | Primary key | `SUBJID=001, VISIT=Week1` |
| `is_valid` | Pass/Fail flag | `false` |
| `action_type` | FAIL / WARN / QUARANTINE | `QUARANTINE` |
| `reason` | Failed constraint | `tv_codelist_values` |
| `column_name` | Affected column | `SEX` |
| `expected_value` | DTA definition | `M, F, U` |
| `actual_value` | Vendor value | `MALE` |
| `drift_category` | Classification | `codelist_violation` |

### Drift Dashboard Queries

**Summary by Library Type**:
```sql
SELECT 
    library_type,
    COUNT(*) as total_violations,
    SUM(CASE WHEN action_type = 'FAIL' THEN 1 ELSE 0 END) as fail_count,
    SUM(CASE WHEN action_type = 'QUARANTINE' THEN 1 ELSE 0 END) as quarantine_count,
    SUM(CASE WHEN action_type = 'WARN' THEN 1 ELSE 0 END) as warn_count
FROM t_conformance_audit
WHERE dta_id = 'DTA_A' AND business_date = '2026-02-04'
GROUP BY library_type
```

**Top Drift Issues**:
```sql
SELECT 
    library_type,
    column_name,
    reason,
    COUNT(*) as occurrence_count,
    COUNT(DISTINCT record_identifier) as affected_records
FROM t_conformance_audit
WHERE dta_id = 'DTA_A' AND business_date = '2026-02-04'
GROUP BY library_type, column_name, reason
ORDER BY occurrence_count DESC
LIMIT 10
```

---

## Integration with Existing Pipelines

### Integration Architecture

The integrated architecture diagram above shows the complete end-to-end flow from study setup through data validation to output consumption. The conformance engine integrates seamlessly with the existing CDH ecosystem:

### Integration Points

**Upstream Inputs**:
1. **Study Setup**: Provides trial configuration, vendor registration, and validation rules configuration
2. **DTA Builder**: Supplies approved DTA metadata (Transfer Variables, Test Concepts, Codelists, Times & Visits, Operational Agreements, Data Ingestion Parameters)
3. **Vendor Data Landing**: Receives vendor study files with file arrival trigger events

**Conformance Engine Processing**:
- **Event-Driven Execution**: UC Volume file arrival triggers SDP pipeline start
- **Metadata Join**: References DTA metadata from Gold layer during DQ validation step
- **Parallel Validation**: Processes all 6 DTA entities concurrently (TV, TC, CL, OA, DIP, Times & Visits)
- **Auto CDC**: Tracks vendor data changes across multiple submissions
- **Audit Logging**: Captures validation failures, drift metrics, and quarantined records

**Downstream Outputs**:
- **Marvel Application**: Consumes study-level validated Gold data for downstream analytics, reporting, and regulatory submissions

### Shared Metadata

The conformance engine **reads from** the same DTA metadata tables created by the ingestion pipeline:

- `md_dta_transfer_variables` (Gold)
- `md_dta_vendor_test_concepts` (Gold)
- `md_dta_codelists` (Gold)
- `md_dta_operational_agreement` (Gold)

**No duplication** – single source of truth for DTA definitions.

---

## Framework Components

### Core APIs (Framework Utilities)

The conformance engine leverages the following SDP framework utilities for metadata-driven validation:

#### 1. Metadata Management
- `get_conformance_metadata()` - Load conformance source metadata from `md_conformance_source_metadata`
- `get_validation_rules(library_type, dta_id)` - Fetch validation rules by library type from `md_conformance_validation_rules`
- `get_transformation_rules(library_type)` - Fetch transformation rules from `md_conformance_transformation_rules`
- `get_cdc_attributes(library_type)` - Get CDC configuration from `md_conformance_cdc`
- `get_dta_metadata(dta_id)` - Fetch DTA definitions from Gold layer tables

#### 2. SDP Table Generation
- `create_bronze_streaming_table()` - Create bronze streaming tables with Autoloader
- `create_dq_validation_tables()` - Create validation tables with expectations (FAIL/QUARANTINE/WARN)
- `create_transformation_tables()` - Apply metadata-driven transformation rules
- `create_scd_tables()` - Apply Auto CDC for SCD Type 2 tracking

#### 3. Validation Execution
- `apply_dta_validation(library_type, bronze_df, dta_metadata)` - Compare vendor data against DTA metadata
- `calculate_drift(vendor_df, dta_df)` - Compute drift metrics (schema drift, value drift, cardinality drift)
- `generate_validation_report()` - Aggregate validation results across all library types

#### 4. Flow Management
- `create_append_flows(source_paths)` - Create multiple append flows to Bronze table
- `create_once_flows(backfill_paths)` - Create ONCE flows for historical backfill
- `manage_checkpoints(flow_names)` - Checkpoint management for flows

#### 5. Audit & Reporting
- `create_audit_sink()` - Publish audit records to Delta sink (non-blocking)
- `create_drift_report_sink()` - Create drift summary sink
- `create_quarantine_sink()` - Export quarantined records sink
- `generate_dashboard_queries()` - Create pre-defined queries for monitoring dashboard

---

## Future Enhancements

### Cross-Library Validation
- Validate relationships between Transfer Variables and Codelists
- Check Test Concepts against Transfer Variables
- Validate OA agreements against actual data submissions
- Cross-entity referential integrity checks

### Enhanced Monitoring and Alerting
- Immediate alerts for critical validation failures
- Live dashboards for data quality monitoring
- Trend analysis for validation metrics over time
- Automated notifications to stakeholders

---

## Benefits Summary

| Benefit | Description | Impact |
|---------|-------------|--------|
| **File Arrival Triggered Execution** | Pipeline automatically starts on vendor file submission via UC Volume notifications | ⚡ Event-driven & cost-efficient |
| **Single Bronze Table** | All vendor files (CSV, BDAT, Parquet, JSON) ingested into one streaming table | 🏗️ Simplified architecture |
| **Metadata-Driven Rules** | Validation rules stored in Delta tables, dynamically applied | 🔧 No code changes for new rules |
| **4-Step Validation Pattern** | Standardized flow (Read → DQ → Transform → CDC) for all entities | ♻️ Consistency & reusability |
| **Parallel Processing** | All 6 DTA entities validated concurrently in single pipeline | ⚡ Sub-linear scaling |
| **Auto CDC for Re-Submissions** | SCD Type 2 automatically tracks vendor data updates (INSERT/UPDATE/DELETE) | 📈 Complete change history |
| **Non-Blocking Audit** | Validation failures logged asynchronously without blocking flows | 🚀 Performance optimized |
| **Automated Validation** | No manual checks required for vendor submissions | 🚀 10x faster |
| **Vendor Re-Submission Tracking** | Handles multiple vendor data submissions per day/week/month | 🔄 Production-ready for trials |
| **Audit Trail** | Complete history for compliance and regulatory requirements | 📊 Regulatory ready |
| **Early Drift Detection** | Catch discrepancies between DTA and vendor data before production | ⚠️ Reduce downstream issues |
| **Integration** | Seamless with existing CDH ingestion pipelines | 🔗 Single platform |
| **Single Pipeline Management** | One SDP pipeline to deploy, monitor, and manage | 🎯 Simplified operations |

---

## Related Documentation

### Internal Documentation
- [11. CDH Ingestion Pipeline Design](./11_cdh_ingestion_pipeline_design.readme.md) - Source of DTA metadata
- [00. DTA Design Overview](./00_dta_design_overview.readme.md) - Overall DTA architecture
- [13. DTA Deployment Guide](./13_dta_deployment_guide.md) - Deployment procedures
- [02. DTA Schema Design](./02_dta_schema_design.readme.md) - DTA metadata tables

### Databricks Lakeflow Spark Declarative Pipelines (SDP) Documentation

**Core Concepts**:
- [SDP Flows](https://docs.databricks.com/aws/en/ldp/flows) - Multiple flows writing to single target, append-once patterns
- [Streaming Tables](https://docs.databricks.com/aws/en/ldp/streaming-tables) - Creating streaming tables
- [Materialized Views](https://docs.databricks.com/aws/en/ldp/materialized-views) - Batch processing with views

**Advanced Features**:
- [Auto CDC (Change Data Capture)](https://docs.databricks.com/aws/en/ldp/database-replication) - Simplified CDC for SCD Type 2
- [SDP Sinks](https://docs.databricks.com/aws/en/ldp/ldp-sinks) - Non-blocking writes to external systems
- [Schema Evolution](https://docs.databricks.com/aws/en/ldp/from-json-schema-evolution) - Automatic schema change handling
- [Transformations](https://docs.databricks.com/aws/en/ldp/transform) - Data transformation patterns
- [Expectations Framework](https://docs.databricks.com/aws/en/ldp/expectation-patterns) - Data quality validation patterns

**Operations**:
- [Pipeline Updates](https://docs.databricks.com/aws/en/ldp/updates) - Running and managing pipeline updates
- [Monitoring](https://docs.databricks.com/aws/en/ldp/monitoring) - Pipeline observability
- [Event Log](https://docs.databricks.com/aws/en/ldp/event-log) - Accessing pipeline execution metadata

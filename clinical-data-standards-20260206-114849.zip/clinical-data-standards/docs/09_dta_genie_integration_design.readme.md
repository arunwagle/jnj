# Genie AI Integration Design

---

## Overview

### What is Databricks AI/BI Genie?

Databricks AI/BI Genie is a natural language interface that allows users to query data using conversational questions instead of writing SQL. Key capabilities include:

| Capability | Description |
|------------|-------------|
| **Natural Language Queries** | Users ask questions in plain English; Genie translates to SQL |
| **Unity Catalog Integration** | Queries tables directly from Unity Catalog with permission enforcement |
| **Conversation Context** | Supports follow-up questions within a conversation |
| **SQL Generation** | Generates and displays the SQL query for transparency |
| **Result Formatting** | Returns results as structured tables or markdown |

### Purpose in DTA Builder

The DTA Builder UI integrates Genie to enable:

- **DTA Discovery**: Search for existing DTAs using natural language (e.g., "Find all Labs DTAs from LabCorp")
- **Version Lookup**: Query version history and approval status
- **Template Search**: Find approved DTAs to use as templates for new work
- **Activity Tracking**: Query recent changes and user activity

### Genie Space Configuration

A Genie Space defines the tables, instructions, and examples that guide Genie's behavior. For DTA Builder:

| Component | Description |
|-----------|-------------|
| **Tables** | Gold layer tables (`dta`, `dta_workflow`, `md_dta_transfer_variables`, etc.) |
| **Instructions** | Domain-specific guidance on DTA terminology and query patterns |
| **Sample Questions** | Representative questions users might ask |
| **SQL Examples** | Parameterized queries that demonstrate correct patterns |

---

## Tables in Genie Space

The following **Gold layer tables** are included in the Genie Space (Bronze tables are excluded as they're for ingestion only):

| Table | Purpose | Key Columns |
|-------|---------|-------------|
| `gold_md.dta` | Core DTA entity | `dta_id`, `dta_number`, `trial_id`, `data_stream_type`, `data_provider_name`, `status`, `workflow_state` |
| `gold_md.dta_workflow` | Approval workflow tracking | `dta_workflow_id`, `dta_id`, `workflow_iteration`, `workflow_status` |
| `gold_md.dta_approval_task` | Individual approval tasks | `approval_task_id`, `dta_workflow_id`, `approver_role`, `approval_status` |
| `gold_md.dta_activity_log` | Full audit history | `activity_id`, `dta_id`, `activity_category`, `activity_type`, `performed_by_principal` |
| `gold_md.md_version_registry` | Central version registry | `version`, `dta_id`, `version_type`, `library_type`, `is_latest_major`, `record_count` |
| `gold_md.md_dta_transfer_variables` | Approved transfer variables | `dta_id`, `transfer_variable_name`, `format`, `is_current` |
| `gold_md.md_dta_vendor_test_concepts` | Approved test concepts | `test_concept_id`, `dta_id`, `test_concept_reference`, `transfer_tuple_map` |

**Table Discovery**: The export job dynamically discovers all Gold layer tables using `SHOW TABLES IN {catalog}.gold_md`, ensuring the Genie Space stays current as new tables are added.

---

## Genie Instructions Text

The following instructions are provided to Genie to guide its understanding of DTAs and query patterns:

```text
# DTA Genie Space Instructions

## Purpose
Help JNJ Data Acquisition Experts (DAEs) and Vendors search for, compare, and create Data Transfer Agreements (DTAs) based on approved versions or templates.

## Required Search Criteria - ALWAYS ASK FOR CLARIFICATION

When users ask about DTAs but don't specify required filters, you MUST ask:
"To find relevant DTAs, please specify:
- The vendor name (data_provider_name), AND
- Either the data stream type (e.g., Labs, ECG, Biomarkers) OR trial ID (e.g., VAC18193RSV3001)"

Required filter combinations:
1. data_provider_name + data_stream_type
2. data_provider_name + trial_id

## Key Business Terms

| Term | Meaning | SQL Filter |
|------|---------|------------|
| Active DTA | Approved and in production | status = 'ACTIVE' AND workflow_state = 'APPROVED' |
| Draft DTA | Work in progress | status = 'DRAFT' |
| Pending Approval | Awaiting reviewer action | workflow_state = 'IN_REVIEW' |
| Latest Version | Most recent approved | is_current = true |
| DTA Template | Canonical template | version_type = 'DTA_TEMPLATE' |

## DTA Workflow States

- **NOT_STARTED**: Draft created, not yet submitted for approval
- **IN_REVIEW**: Submitted, awaiting approvals from JNJ DAE, Vendor, or Librarian
- **APPROVED**: All required approvals complete
- **REJECTED**: Returned for revision with comments

## Approver Roles

- **jnj_dae**: J&J Data Acquisition Expert - internal reviewer
- **vendor**: External data provider representative
- **librarian**: J&J Metadata Librarian - for template promotion

## Common Query Patterns

### Find DTAs by vendor
Filter: data_provider_name LIKE '%{vendor}%'

### Find DTAs by trial
Filter: trial_id LIKE '%{trial}%'

### Find DTAs by data stream
Filter: data_stream_type = '{stream}'

### Latest N versions
ORDER BY created_ts DESC LIMIT N

### DTAs modified by user
Join dta_activity_log and filter: performed_by_principal LIKE '%{email}%'

### Similar DTAs for cloning
Match on data_stream_type with similar data_provider_name or trial_id

## Data Stream Types

Common values: Labs, ECG, Adverse Events, Biomarkers, Demographics, Vital Signs, PF (Patient Flow), Medical History

## Table Relationships

```
dta (core entity)
  |-- dta_workflow (1:N by dta_id)
  |     |-- dta_approval_task (1:N by dta_workflow_id)
  |-- md_version_registry (1:N by dta_id)
  |-- md_dta_transfer_variables (1:N by dta_id, filter is_current=true)
  |-- md_dta_vendor_test_concepts (1:N by dta_id, filter is_current=true)
  |-- dta_activity_log (1:N by dta_id)
```

## Important Notes

1. Always filter transfer_variables and test_concepts by is_current = true for latest versions
2. Use UPPER() or ILIKE for case-insensitive matching on vendor/trial names
3. DTA numbers are sequential: DTA001, DTA002, etc.
4. Version format: 1.0-DTA001-v1.0 (approved) or 1.0-DTA001-draft1 (draft)
```

---

## Training SQL Queries

Genie is trained with the following **6 parameterized SQL queries**. All queries:
- Filter for `status IN ('ACTIVE', 'PROMOTED')` to show approved DTAs only
- Include metadata counts from `md_version_registry` for each library type
- Use LEFT JOIN to ensure DTAs display even if they have no metadata yet

### Query 1: Find All Approved DTAs

**Question**: "Find all approved DTAs"

```sql
SELECT d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
       d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes,
       MAX(CASE WHEN vr.library_type = 'transfer_variables' THEN vr.record_count ELSE 0 END) AS transfer_variables_count,
       MAX(CASE WHEN vr.library_type = 'test_concepts' THEN vr.record_count ELSE 0 END) AS test_concepts_count,
       MAX(CASE WHEN vr.library_type = 'codelists' THEN vr.record_count ELSE 0 END) AS codelists_count,
       MAX(CASE WHEN vr.library_type = 'operational_agreements' THEN vr.record_count ELSE 0 END) AS operational_agreements_count,
       MAX(CASE WHEN vr.library_type = 'visits_timepoints' THEN vr.record_count ELSE 0 END) AS visits_timepoints_count,
       MAX(CASE WHEN vr.library_type = 'data_ingestion_params' THEN vr.record_count ELSE 0 END) AS data_ingestion_params_count
FROM {catalog}.gold_md.dta d
LEFT JOIN {catalog}.gold_md.md_version_registry vr ON d.dta_id = vr.dta_id AND vr.status = d.status
WHERE d.status IN ('ACTIVE', 'PROMOTED')
GROUP BY d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
         d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes
ORDER BY d.last_updated_ts DESC
LIMIT 20
```

### Query 2: Show DTAs by Vendor and Data Stream

**Question**: "Show DTAs for vendor :vendor_name and data stream :data_stream"

**Parameters**: `:vendor_name`, `:data_stream`

```sql
SELECT d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
       d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes,
       MAX(CASE WHEN vr.library_type = 'transfer_variables' THEN vr.record_count ELSE 0 END) AS transfer_variables_count,
       MAX(CASE WHEN vr.library_type = 'test_concepts' THEN vr.record_count ELSE 0 END) AS test_concepts_count,
       MAX(CASE WHEN vr.library_type = 'codelists' THEN vr.record_count ELSE 0 END) AS codelists_count,
       MAX(CASE WHEN vr.library_type = 'operational_agreements' THEN vr.record_count ELSE 0 END) AS operational_agreements_count,
       MAX(CASE WHEN vr.library_type = 'visits_timepoints' THEN vr.record_count ELSE 0 END) AS visits_timepoints_count,
       MAX(CASE WHEN vr.library_type = 'data_ingestion_params' THEN vr.record_count ELSE 0 END) AS data_ingestion_params_count
FROM {catalog}.gold_md.dta d
LEFT JOIN {catalog}.gold_md.md_version_registry vr ON d.dta_id = vr.dta_id AND vr.status = d.status
WHERE d.status IN ('ACTIVE', 'PROMOTED')
  AND UPPER(d.data_provider_name) LIKE UPPER(CONCAT('%', :vendor_name, '%'))
  AND UPPER(d.data_stream_type) LIKE UPPER(CONCAT('%', :data_stream, '%'))
GROUP BY d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
         d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes
ORDER BY d.last_updated_ts DESC
```

### Query 3: Show DTAs by Trial

**Question**: "Show all DTAs for trial :trial_id"

**Parameters**: `:trial_id`

```sql
SELECT d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
       d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes,
       MAX(CASE WHEN vr.library_type = 'transfer_variables' THEN vr.record_count ELSE 0 END) AS transfer_variables_count,
       MAX(CASE WHEN vr.library_type = 'test_concepts' THEN vr.record_count ELSE 0 END) AS test_concepts_count,
       MAX(CASE WHEN vr.library_type = 'codelists' THEN vr.record_count ELSE 0 END) AS codelists_count,
       MAX(CASE WHEN vr.library_type = 'operational_agreements' THEN vr.record_count ELSE 0 END) AS operational_agreements_count,
       MAX(CASE WHEN vr.library_type = 'visits_timepoints' THEN vr.record_count ELSE 0 END) AS visits_timepoints_count,
       MAX(CASE WHEN vr.library_type = 'data_ingestion_params' THEN vr.record_count ELSE 0 END) AS data_ingestion_params_count
FROM {catalog}.gold_md.dta d
LEFT JOIN {catalog}.gold_md.md_version_registry vr ON d.dta_id = vr.dta_id AND vr.status = d.status
WHERE d.status IN ('ACTIVE', 'PROMOTED')
  AND UPPER(d.trial_id) LIKE UPPER(CONCAT('%', :trial_id, '%'))
GROUP BY d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
         d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes
ORDER BY d.data_stream_type, d.data_provider_name
```

### Query 4: Show DTAs by User

**Question**: "Show DTAs created or modified by user :user_email"

**Parameters**: `:user_email`

```sql
SELECT DISTINCT d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
       d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes,
       MAX(CASE WHEN vr.library_type = 'transfer_variables' THEN vr.record_count ELSE 0 END) AS transfer_variables_count,
       MAX(CASE WHEN vr.library_type = 'test_concepts' THEN vr.record_count ELSE 0 END) AS test_concepts_count,
       MAX(CASE WHEN vr.library_type = 'codelists' THEN vr.record_count ELSE 0 END) AS codelists_count,
       MAX(CASE WHEN vr.library_type = 'operational_agreements' THEN vr.record_count ELSE 0 END) AS operational_agreements_count,
       MAX(CASE WHEN vr.library_type = 'visits_timepoints' THEN vr.record_count ELSE 0 END) AS visits_timepoints_count,
       MAX(CASE WHEN vr.library_type = 'data_ingestion_params' THEN vr.record_count ELSE 0 END) AS data_ingestion_params_count
FROM {catalog}.gold_md.dta d
JOIN {catalog}.gold_md.dta_activity_log a ON d.dta_id = a.dta_id
LEFT JOIN {catalog}.gold_md.md_version_registry vr ON d.dta_id = vr.dta_id AND vr.status = d.status
WHERE d.status IN ('ACTIVE', 'PROMOTED')
  AND UPPER(a.performed_by_principal) LIKE UPPER(CONCAT('%', :user_email, '%'))
GROUP BY d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
         d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes
ORDER BY d.dta_number
```

### Query 5: Recently Updated DTAs

**Question**: "What DTAs were updated in the last 30 days?"

```sql
SELECT d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
       d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes,
       MAX(CASE WHEN vr.library_type = 'transfer_variables' THEN vr.record_count ELSE 0 END) AS transfer_variables_count,
       MAX(CASE WHEN vr.library_type = 'test_concepts' THEN vr.record_count ELSE 0 END) AS test_concepts_count,
       MAX(CASE WHEN vr.library_type = 'codelists' THEN vr.record_count ELSE 0 END) AS codelists_count,
       MAX(CASE WHEN vr.library_type = 'operational_agreements' THEN vr.record_count ELSE 0 END) AS operational_agreements_count,
       MAX(CASE WHEN vr.library_type = 'visits_timepoints' THEN vr.record_count ELSE 0 END) AS visits_timepoints_count,
       MAX(CASE WHEN vr.library_type = 'data_ingestion_params' THEN vr.record_count ELSE 0 END) AS data_ingestion_params_count
FROM {catalog}.gold_md.dta d
LEFT JOIN {catalog}.gold_md.md_version_registry vr ON d.dta_id = vr.dta_id AND vr.status = d.status
WHERE d.status IN ('ACTIVE', 'PROMOTED')
  AND d.last_updated_ts >= DATE_ADD(CURRENT_DATE(), -30)
GROUP BY d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
         d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes
ORDER BY d.last_updated_ts DESC
LIMIT 20
```

### Query 6: DTAs from Templates

**Question**: "Show DTAs created from a specific vendor's DTA template"

```sql
SELECT DISTINCT d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
       d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes,
       MAX(CASE WHEN vr2.library_type = 'transfer_variables' THEN vr2.record_count ELSE 0 END) AS transfer_variables_count,
       MAX(CASE WHEN vr2.library_type = 'test_concepts' THEN vr2.record_count ELSE 0 END) AS test_concepts_count,
       MAX(CASE WHEN vr2.library_type = 'codelists' THEN vr2.record_count ELSE 0 END) AS codelists_count,
       MAX(CASE WHEN vr2.library_type = 'operational_agreements' THEN vr2.record_count ELSE 0 END) AS operational_agreements_count,
       MAX(CASE WHEN vr2.library_type = 'visits_timepoints' THEN vr2.record_count ELSE 0 END) AS visits_timepoints_count,
       MAX(CASE WHEN vr2.library_type = 'data_ingestion_params' THEN vr2.record_count ELSE 0 END) AS data_ingestion_params_count
FROM {catalog}.gold_md.md_version_registry vr
INNER JOIN {catalog}.gold_md.dta d ON d.data_provider_name = vr.data_provider_name AND d.data_stream_type = vr.data_stream_type
LEFT JOIN {catalog}.gold_md.md_version_registry vr2 ON d.dta_id = vr2.dta_id AND vr2.status = d.status
WHERE vr.version_type = 'DTA_TEMPLATE' AND vr.status = 'PROMOTED'
  AND d.status IN ('ACTIVE', 'PROMOTED')
GROUP BY d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
         d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes
ORDER BY d.dta_number
```

---

## Sample Questions

These **6 sample questions** are displayed in the Genie UI as quick-start prompts:

1. "Find all approved DTAs"
2. "Show DTAs for vendor :vendor_name and data stream :data_stream"
3. "Show all DTAs for trial :trial_id"
4. "Show DTAs created or modified by user :user_email"
5. "What DTAs were updated in the last 30 days?"
6. "Show DTAs created from a specific vendor's DTA template"

---

## Column Configuration Strategy

For each table in the Genie Space, columns are configured with two settings:

| Setting | Applies To | Purpose |
|---------|------------|---------|
| `get_example_values: true` | **All columns** | Genie fetches sample values to understand column content |
| `build_value_dictionary: true` | **STRING columns only** | Creates lookup dictionary for categorical columns |

**Excluded from dictionary**: TIMESTAMP, BINARY, STRUCT, ARRAY, MAP, DOUBLE, FLOAT, INT, BIGINT, DECIMAL, BOOLEAN

**Column sorting**: All columns are sorted alphabetically by `column_name` (Genie API requirement).

**Example configuration**:
```json
{
  "column_name": "data_stream_type",
  "get_example_values": true,
  "build_value_dictionary": true
}
```

---

## Asset Generation Job

The `job_cdm_export_genie_assets` job dynamically generates all assets needed to configure and update a Genie space.

### Job Definition

**File**: `resources/data_engineering/clinical_data_standards/jobs/job_cdm_export_genie_assets.job.yml`

| Parameter | Default | Description |
|-----------|---------|-------------|
| `source_root` | `test` | Output subfolder in volumes (e.g., `test`, `prod`) |
| `catalog_override` | `""` | Optional catalog override |

### Job Workflow

The job runs **3 tasks** in sequence:

| Task | Notebook | Purpose | Dependencies |
|------|----------|---------|--------------|
| `setup` | `nb_setup` | Load configuration and validate parameters | None |
| `export_genie_assets` | `nb_export_genie_assets` | Discover tables, generate all component files | `setup` |
| `generate_serialized_space` | `nb_generate_serialized_space` | Assemble final `serialized_space.json` | `export_genie_assets` |

### Task 1: Setup

- Loads global configuration (catalog, schemas)
- Validates job parameters
- Sets task values for downstream tasks

### Task 2: Export Genie Assets

**Notebook**: `notebooks/data_engineering/clinical_data_standards/jobs/nb_export_genie_assets.ipynb`

**Key Operations**:

1. **Discover Tables**: Uses `SHOW TABLES` to find all Bronze and Gold tables
2. **Extract Metadata**: Reads table/column descriptions using `DESCRIBE TABLE EXTENDED`
3. **Generate SQL Comments**: Creates `add_table_comments.sql` with rich descriptions
4. **Generate Instructions**: Creates `genie_instructions.txt` with DTA-specific guidance
5. **Generate Example Queries**: Creates `example_queries.sql` with 6 parameterized queries
6. **Generate JSON Components**: Creates 4 JSON files for `serialized_space` assembly

**Column Comment Templates**:
The notebook includes 50+ pre-defined column comment templates for common DTA fields (e.g., `dta_id`, `trial_id`, `data_stream_type`). These provide rich descriptions when existing comments are missing.

**Table Comment Templates**:
Pre-defined descriptions for 10 core tables (e.g., `dta`, `dta_workflow`, `md_version_registry`) to guide Genie's understanding.

### Task 3: Generate Serialized Space

**Notebook**: `notebooks/data_engineering/clinical_data_standards/jobs/nb_generate_serialized_space.ipynb`

**Operations**:
1. Reads all 4 component JSON files
2. Assembles them into the complete `serialized_space.json` structure:

```json
{
  "version": 1,
  "config": {
    "sample_questions": [...]
  },
  "data_sources": {
    "tables": [...]
  },
  "instructions": {
    "text_instructions": [...],
    "example_question_sqls": [...]
  }
}
```

### Output Files

All files are written to:
```
/Volumes/{catalog}/bronze_md/{volume}/{source_root}/exports/genie/
```

**Example path**: `/Volumes/aira_test/bronze_md/clinical_data_standards/test/exports/genie/`

| File | Purpose | Generated By |
|------|---------|--------------|
| `sql/add_table_comments.sql` | Table and column descriptions | Task 2 (Cell 7) |
| `sql/example_queries.sql` | 6 parameterized training queries | Task 2 (Cell 9) |
| `genie_instructions.txt` | Human-readable instructions | Task 2 (Cell 8) |
| `components/data_sources.json` | Tables with column configs | Task 2 (Cell 10) |
| `components/sample_questions.json` | 6 quick-start questions | Task 2 (Cell 11) |
| `components/example_queries.json` | Question/SQL pairs | Task 2 (Cell 11) |
| `components/text_instructions.json` | Instructions for API | Task 2 (Cell 12) |
| `serialized_space.json` | **Complete space configuration** | Task 3 |
| `export_manifest.json` | Export metadata | Task 2 (Cell 13) |

### Running the Job

**Via Databricks UI:**
1. Navigate to **Workflows** → **Jobs**
2. Find `job_cdm_export_genie_assets`
3. Click **Run Now**
4. Set parameters:
   - `source_root`: Output folder (e.g., `test` or `prod`)

**Via Test Job:**
Run `job_test_cdm_export_genie_assets` which triggers the main job with test parameters.

### Updating a Genie Space

After generating assets, use the `nb_test_genie_api.ipynb` notebook to update an existing Genie space:

1. Reads `serialized_space.json` from the exports folder
2. Calls `PATCH /api/2.0/genie/spaces/{space_id}` with the configuration
3. Updates tables, instructions, sample questions, and SQL examples

---

## UI Design

### Conversational UI Flow Diagram

![Genie Conversational UI Flow](./diagrams/09_dta_genie_conversational_ui.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/09_dta_genie_conversational_ui.drawio)

### Search Mode Toggle

The DTA Builder UI provides two search modes:

```
[○ Standard Search]  [● AI Search with Genie] ✨
```

| Mode | Description |
|------|-------------|
| **Standard Search** | Traditional SQL-based search with field filters |
| **AI Search with Genie** | Natural language queries powered by Genie |

### Genie Conversation Panel

The conversational UI provides a chat-like experience with support for follow-up questions:

| Component | Description |
|-----------|-------------|
| **Chat History** | Scrollable history of user questions and Genie responses |
| **User Messages** | Displayed as blue bubbles on the right |
| **Genie Responses** | Displayed as gray bubbles on the left |
| **Clarification Requests** | Highlighted with amber border when Genie needs more details |
| **Follow-up Input** | Input box to continue the conversation |
| **Generated SQL** | Collapsible section showing the SQL query |
| **New Conversation** | Button to start a fresh conversation |

### Response Type Detection

The API automatically detects the type of response:

| Type | Detection Criteria | UI Behavior |
|------|-------------------|-------------|
| **DATA** | Response contains DTA results | Render DTA cards below conversation |
| **CLARIFICATION** | Response contains question patterns (?, "please specify", "which") | Highlight message, focus follow-up input |
| **INFO** | Text response without actionable data | Display message only |
| **EMPTY** | No meaningful response | Show "no results" message |

### User Experience Flow

**Initial Search:**
1. User selects **AI Search with Genie** toggle
2. User types natural language question
3. User clicks **Ask Genie**
4. Conversation panel opens with user message
5. Loading indicator shows while Genie processes

**Response Handling:**
- **If clarification needed**: Genie asks for more details, follow-up input is focused
- **If data returned**: DTA cards render below the conversation, follow-up available
- **If informational**: Message displayed, user can ask follow-ups

**Follow-up Questions:**
1. User types in follow-up input
2. Clicks **Send** or presses Enter
3. Message added to chat history
4. Genie processes using existing conversation context
5. Response added to history with appropriate formatting

### Error Handling

| Scenario | User Experience |
|----------|-----------------|
| Genie not configured | Toggle disabled with tooltip |
| Query too short | Prompt for more detail |
| No results | Suggestion to refine query |
| Timeout | Error message with retry suggestion |
| API error | Error displayed in chat history |

### JavaScript State Management

The conversational UI maintains state across interactions:

```javascript
let genieState = {
  conversationId: null,   // For follow-up questions
  messages: [],           // Chat history
  lastResponseType: null, // DATA, CLARIFICATION, INFO
  isLoading: false        // Prevent duplicate requests
};
```

### API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/genie/search` | GET | Start new conversation with initial question |
| `/api/genie/followup` | POST | Continue conversation with follow-up question |
| `/api/genie/status` | GET | Check if Genie is configured |

---

## Best Practices for Designing Genie Spaces

### Table Selection

- **Focus on Gold layer**: Include core business tables (`dta`, `dta_workflow`, `md_dta_transfer_variables`)
- **Include Bronze for context**: Add `md_file_history` for document lineage
- **Limit scope**: Too many tables can confuse Genie; start with essential tables
- **Add related tables**: Include lookup tables needed for JOINs

### Table and Column Comments

Rich descriptions help Genie understand data semantics:

- **Table comments**: Explain the purpose and business context
- **Column comments**: Describe what each column contains, valid values, relationships
- **Use `add_table_comments.sql`**: Generated automatically by the export job
- **Include examples**: "data_stream_type contains values like Labs, ECG, Biomarkers"

### Instructions

Write focused, domain-specific instructions:

- **Define terminology**: Explain what DTA, vendor, data stream mean
- **Specify required filters**: "Always ask for vendor and data stream or trial"
- **Clarify relationships**: Explain how tables relate (e.g., dta → dta_workflow)
- **Set expectations**: Define what questions the space can and cannot answer

### Sample Questions

Provide representative questions users might ask:

- Start with common use cases
- Include variations (by vendor, by trial, by status)
- Cover different query types (search, count, latest, history)
- Keep questions natural and conversational

### SQL Examples

Train Genie with parameterized queries:

- **Cover key patterns**: Filtering, joining, aggregating
- **Use consistent style**: Same column selection, JOIN patterns
- **Include comments**: Explain what each query does
- **Match to sample questions**: Each example should answer a sample question

### Column Configurations

Configure column behavior in `data_sources.json`:

| Setting | Purpose |
|---------|---------|
| `get_example_values: true` | Genie fetches sample values to understand column content |
| `build_value_dictionary: true` | Creates lookup for categorical columns (STRING types) |

**Note**: Sort columns alphabetically (Genie API requirement).

### Iterative Refinement

1. **Start simple**: Begin with core tables and basic instructions
2. **Monitor usage**: Review questions in Genie's Monitoring tab
3. **Identify gaps**: Note queries that fail or return wrong results
4. **Refine instructions**: Add clarifications for misunderstood queries
5. **Add examples**: Create SQL examples for problematic patterns
6. **Test variations**: Try different phrasings of the same question
7. **Collect feedback**: Use upvote/downvote to identify improvements

### Required Search Criteria

Configure Genie to ask clarifying questions when context is missing:

| Required Combination | Example |
|---------------------|---------|
| Vendor + Data Stream | "Show me Labs DTAs from LabCorp" |
| Vendor + Trial | "Find DTAs for Covance in trial VAC18193" |

**Instruction to add**: "To find relevant DTAs, please specify the vendor name AND either the data stream type (Labs, ECG, Biomarkers) OR trial ID."

---

## Related Documentation

- [01_dta_job_architecture_design.readme.md](./01_dta_job_architecture_design.readme.md) - Job pipeline architecture including `job_cdm_export_genie_assets`
- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - Table schemas used by Genie
- [07_dta_databricks_ai_design.readme.md](./07_dta_databricks_ai_design.readme.md) - Databricks AI capabilities (Model Serving vs. Genie)
- [Databricks Genie Best Practices](https://docs.databricks.com/aws/en/genie/best-practices) - Official documentation

---

# DTA Workflow Design

## Overview

The DTA approval flow manages the governance process from DTA creation through final approval. It supports:

- **Multi-party approval**: JNJ DAE and Vendor roles with extensible architecture
- **Ordered approval chain**: Approvers review in sequence based on `approval_order`
- **Rejection handling**: Any rejection returns DTA to editing state
- **Version creation**: Approval triggers DTA version creation
- **Multiple cycles**: Rejection increments `workflow_iteration` for resubmission
- **Role-based access**: Permissions system controlling user capabilities

---

## Diagram

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| DTA Workflow Flow | Complete state transition diagram | [PNG](./diagrams/06_dta_workflow_flow.drawio.png) | [Draw.io](./diagrams/06_dta_workflow_flow.drawio) |

![DTA Workflow Flow](./diagrams/06_dta_workflow_flow.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/06_dta_workflow_flow.drawio)

---

## User Groups and Permissions

The DTA Workflow framework is built on a role-based access control (RBAC) system with three primary user groups. Each group has specific permissions that determine their capabilities within the DTA lifecycle.

### User Group Roles

#### 1. JNJ_DAE (J&J Data Acquisition Engineers)

**Primary Responsibilities:**
- Create and manage Data Transfer Agreements
- Edit DTA content and metadata
- Clone existing DTAs for reuse
- Promote approved DTAs to major versions (ACTIVE status)

**Key Permissions:**
- **Page Access**: Full access to all pages including DTA Builder, Dashboard, Workflow, and Viewer
- **Actions**:
  - `action_edit_dta` - Edit DTA fields and content
  - `action_clone_dta` - Clone DTAs for new trials
  - `action_delete_library_item` - Remove library items
  - `action_promote_dta` - Promote DTA to major version after approval
  - `action_add_comment` - Add comments and collaborate

**Limitations:**
- Cannot promote DTAs to templates (reserved for Librarians)

#### 2. VENDOR (External Data Vendors)

**Primary Responsibilities:**
- Review DTAs submitted for vendor approval
- Provide feedback and comments on DTA content
- Approve DTAs assigned to their organization

**Key Permissions:**
- **Page Access**: Dashboard, Workflow, Viewer, and Builder (read-only access)
- **Actions**:
  - `action_add_comment` - Comment on DTA content
  - `action_approve_dta` - Approve DTAs assigned to them

**Limitations:**
- Cannot create, edit, clone, or delete DTAs
- Cannot promote DTAs
- Can only approve DTAs for their assigned vendor organization

#### 3. JNJ_LIBRARIAN (Library Maintainers)

**Primary Responsibilities:**
- Maintain DTA template library for organizational reuse
- Promote approved DTAs to templates
- Manage administrative functions
- Ensure template quality and consistency

**Key Permissions:**
- **Page Access**: Dashboard, Workflow, Viewer, and Administration pages
- **Actions**:
  - `action_add_comment` - Provide feedback on DTAs
  - `action_promote_template` - Promote approved DTAs to reusable templates

**Special Capabilities:**
Librarians can create **DTA Templates** from approved DTAs. These templates serve as:
- **Reusable baselines** for new DTAs with the same vendor and data stream
- **Standardized definitions** ensuring consistency across trials
- **Version-controlled library entries** tracked in `md_version_registry`

**Limitations:**
- Cannot edit, clone, or approve DTAs
- Cannot create new DTAs (focused on template curation)

---

## Approver Assignment During DTA Creation

### Automatic Approval Task Creation

When a DTA is created (via UI, API, or CLI), the system automatically:

1. **Creates a DTA Workflow record** (`dta_workflow`)
   - Links the workflow to the newly created DTA
   - Initializes workflow state as `NOT_STARTED`

2. **Creates Approval Tasks** (`dta_approval_task`)
   - **JNJ_DAE Task**: `approval_order = 1`, `approval_status = PENDING`
   - **VENDOR Task**: `approval_order = 2`, `approval_status = PENDING`

3. **Initial State**:
   - All tasks start with `assigned_to_principal = NULL`
   - Approvers are assigned later via the UI by the DTA creator or workflow coordinator

### Approver Assignment Workflow

```
┌─────────────────────────────────────────────────────────────┐
│  DTA Creation                                               │
│  ───────────────────────────────────────────────────────── │
│  1. User creates DTA (Trial ID, Stream Type, Vendor)       │
│  2. System generates DTA ID and workflow ID                 │
│  3. System creates approval tasks (JNJ_DAE, VENDOR)         │
│     • approval_status = PENDING                             │
│     • assigned_to_principal = NULL                          │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│  Approver Assignment (via UI)                               │
│  ───────────────────────────────────────────────────────── │
│  1. Workflow coordinator navigates to DTA approval page     │
│  2. System displays approval tasks                          │
│  3. Coordinator assigns specific users to each task:        │
│     • JNJ_DAE Task → Assigns JNJ DAE user                   │
│     • VENDOR Task → Assigns specific vendor contact         │
│  4. System updates assigned_to_principal for each task      │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│  Submission for Approval                                    │
│  ───────────────────────────────────────────────────────── │
│  1. Creator submits DTA for approval                        │
│  2. System updates workflow_state = IN_PROGRESS             │
│  3. Assigned approvers receive notification                 │
└─────────────────────────────────────────────────────────────┘
```

### Assigning Approvers via UI

The DTA creator or workflow coordinator can assign approvers through:

1. **Approval Detail Page**: Navigate to `/approval/<dta_id>`
2. **View Approval Tasks**: See all pending approval tasks
3. **Assign Users**:
   - For **JNJ_DAE** task: Select from JNJ DAE group members
   - For **VENDOR** task: Select from vendor users based on DTA's `data_provider_name`
4. **System Lookup**: Uses `md_users` and `md_user_group_memberships` tables to populate approver dropdowns
5. **Update**: Once assigned, `assigned_to_principal` is set to the selected user's email

### Data Model

**Approval Task Schema:**
```sql
dta_approval_task (
  approval_task_id       STRING    -- Unique task identifier
  dta_workflow_id        STRING    -- FK to dta_workflow
  dta_id                 STRING    -- FK to dta
  approver_role          STRING    -- Role: JNJ_DAE, VENDOR
  assigned_to_principal  STRING    -- User email (NULL initially, assigned via UI)
  approval_status        STRING    -- Status: PENDING, APPROVED, REJECTED
  approval_order         INT       -- Execution order: 1, 2
  approval_comment       STRING    -- Approver's feedback
  approved_ts            TIMESTAMP -- Approval timestamp
  created_by_principal   STRING    -- Task creator
  created_ts             TIMESTAMP
  last_updated_by_principal STRING
  last_updated_ts        TIMESTAMP
)
```

---

## DTA Lifecycle States

### DTA Status

| Status | Description | Editable? |
|--------|-------------|-----------|
| `DRAFT` | DTA is being created/edited | ✅ Yes |
| `ACTIVE` | Approved and in use | ❌ No |
| `ARCHIVED` | No longer active | ❌ No |

### Workflow Status

| Status | Description |
|--------|-------------|
| `NOT_STARTED` | Workflow created but not submitted |
| `IN_PROGRESS` | Submitted and awaiting approvals |
| `APPROVED` | All approvers approved |
| `REJECTED` | At least one approver rejected |

### Approval Task Status

| Status | Description |
|--------|-------------|
| `PENDING` | Awaiting this approver's decision |
| `APPROVED` | Approver approved |
| `REJECTED` | Approver rejected |

---

## State Transitions

| From | Trigger | To | Result |
|------|---------|-----|--------|
| DRAFT | Save changes | DRAFT | Draft version updated |
| DRAFT | Submit for review | DRAFT + workflow IN_PROGRESS | First approver notified |
| DRAFT | All approve | ACTIVE | DTA version created |
| DRAFT | Any rejects | DRAFT + workflow REJECTED | Returns for editing |
| ACTIVE | Continue work | DRAFT | New workflow iteration |

---

## Framework Extensibility

The DTA Workflow framework is designed to support additional approver roles beyond the current implementation. The architecture allows for easy extension to include roles such as:

- **Legal Reviewers**: For contractual and compliance review
- **Data Privacy Officers**: For GDPR and data protection compliance
- **Quality Assurance**: For additional validation layers
- **Executive Sponsors**: For high-value or high-risk DTAs

**To add new approver roles:**
1. Create new user group in `md_user_groups` (e.g., `JNJ_LEGAL`)
2. Define permissions in `md_permissions` and assign to group
3. Update DTA creation logic to include additional approval task with appropriate `approval_order`
4. Extend UI to support new role assignment and approval

---

## Template Creation for Reuse

### Overview

JNJ Librarians can promote approved DTAs to **DTA Templates**, which serve as reusable baselines for future DTA creation. This capability ensures:
- **Consistency**: Standardized definitions across trials and vendors
- **Efficiency**: Faster DTA creation by cloning from templates
- **Quality**: Vetted and approved content becomes organizational knowledge

### Template Promotion Process

1. **Identify Promotion Candidates**:
   - DTAs with `status = ACTIVE` (approved and in use)
   - Grouped by `data_provider_name` and `data_stream_type`
   - Displayed in the Administration Dashboard

2. **Trigger Template Creation**:
   - Librarian selects a vendor+stream combination
   - System triggers `job_cdm_version_manager` job
   - Job parameters:
     ```json
     {
       "action": "CREATE_DTA_TEMPLATE",
       "data_provider_name": "Labcorp",
       "data_stream_type": "LB",
       "library_type": "transfer_variables",
       "merge_strategy": "UNION_DEDUP"
     }
     ```

3. **Template Creation Logic**:
   - **Merge Strategy**: Combines multiple approved DTAs for the same vendor+stream
   - **Deduplication**: Uses `definition_hash` to identify unique definitions
   - **Versioning**: Creates new template version in `md_version_registry`
   - **Library Types**: Processes Transfer Variables, Test Concepts, Codelists, etc.

4. **Template Usage**:
   - When creating a new DTA, users can select templates from the library panel
   - System clones template content as the starting point
   - New DTA inherits template structure but remains independently editable

### Template Metadata

Templates are tracked in `md_version_registry`:

```sql
md_version_registry (
  version              STRING    -- Template version (e.g., "1.0")
  library_type         STRING    -- Type: transfer_variables, test_concepts, etc.
  version_type         STRING    -- Type: DTA_TEMPLATE
  dta_id               STRING    -- NULL for templates (or source DTA ID)
  parent_version       STRING    -- Previous template version
  record_count         INT       -- Number of definitions in template
  status               STRING    -- ACTIVE, ARCHIVED
  created_by_principal STRING
  created_ts           TIMESTAMP
  ...
)
```

### Benefits of Template System

- **Vendor Standardization**: Each vendor has a canonical template for their data streams
- **Rapid DTA Creation**: New DTAs inherit vendor-specific standards automatically
- **Version Control**: Templates are versioned, allowing rollback and history tracking
- **Governance**: Librarian role ensures only high-quality DTAs become templates

### Key Concepts

- Templates are **scoped by (vendor, data_stream)** combination
- Each vendor+stream pair has its own independent template version sequence
- Multiple approved DTAs from the same vendor+stream are merged into a single template
- The Librarian role has exclusive permission to promote DTAs to templates

---

## Related Documentation

- [03_dta_status_lifecycle_design.readme.md](./03_dta_status_lifecycle_design.readme.md) - Document and DTA status values
- [04_dta_versioning_design.readme.md](./04_dta_versioning_design.readme.md) - Version management and template creation
- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - User groups and permissions schema
- `sql/setup_cdm_app_permissions.sql` - User group and permission setup script
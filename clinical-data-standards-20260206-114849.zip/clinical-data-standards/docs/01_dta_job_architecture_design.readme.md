# Job Architecture Design

## Overview

This document describes the Clinical Data Standards job architecture for processing DTA (Data Transfer Agreement) data, managing versions, and exporting metadata.

The architecture supports multiple document types (tsDTA, Protocol, Operational Agreement) with flexible pipeline modes for both automated bulk import and interactive UI workflows.

### Key Terminology

| Term | Definition |
|------|------------|
| **DTA** | Data Transfer Agreement - Specification document defining data structure, variables, and codelists for clinical trial data transfer between parties |
| **tsDTA** | Trial-Specific Data Transfer Agreement - DTA tailored for a specific clinical trial with trial-specific variables and requirements |
| **CDM** | Clinical Data Metadata - Refers to the metadata management system for DTAs |
| **Protocol** | Study protocol document containing study design, objectives, endpoints, and procedures |
| **Operational Agreement (OA)** | Document specifying operational details, attributes, and configuration options for data transfer |
| **SCD Type 2** | Slowly Changing Dimension Type 2 - A data warehousing technique that tracks historical changes by creating new records with effective dates |
| **Unity Catalog Volumes** | Databricks storage layer for managing files and unstructured data with governance |
| **Library Template** | Reusable DTA template created by merging approved DTAs, scoped by vendor and data stream |
| **Pipeline Mode** | Execution mode: `auto` (auto-detect documents), `tsdta`, `protocol`, or `operational_agreement` |
| **Sandbox Mode** | Preview mode (`sandbox=true`) that processes documents but skips DTA creation, used for UI preview and validation |
| **Version States** | Draft (editing), DTA Major (approved), Template (library) |

### Architecture Overview

The job architecture follows an **orchestrator-worker pattern** with three main execution flows:

1. **Historical Import** - Bulk import of historical tsDTA files from vendors
   - File arrival triggers orchestrator
   - Auto-detects document types
   - Processes all documents in parallel
   - Creates DTA Major versions automatically

2. **Study Creation** - Interactive study setup via UI
   - User creates study and uploads protocol
   - Sandbox mode processes protocol for preview
   - User reviews AI-parsed sections before approval

3. **Document Processing** - Manual or scheduled processing
   - Explicit pipeline mode targets specific document types
   - Used for reprocessing or targeted updates

### Main Jobs (13 total)

**Orchestration (2 jobs)**

| Job Name | Purpose | Trigger |
|----------|---------|---------|
| `job_cdm_dta_import` | End-to-end orchestrator for document import with pipeline modes (auto/tsdta/protocol/oa) | File Arrival / Manual / API |
| `job_cdm_setup_study` | Study creation orchestrator - creates study and triggers protocol processing | API / UI |

**Document Processing (4 jobs)**

| Job Name | Purpose | Trigger |
|----------|---------|---------|
| `job_cdm_file_processor` | Extract ZIP archives and create document manifest | Called by orchestrator |
| `job_cdm_tsdta_xls_processor` | Process tsDTA Excel files (sheets, codelists, transfer vars, test concepts, visits) | Called by orchestrator |
| `job_cdm_protocol_processor` | Parse protocol documents using TOC extraction and AI table parsing | Called by orchestrator |
| `job_cdm_tsdta_oa_processor` | Process Operational Agreement documents (attributes, options) | Called by orchestrator |

**DTA Management (2 jobs)**

| Job Name | Purpose | Trigger |
|----------|---------|---------|
| `job_cdm_dta_create` | Create DTA instances and manage versioning | Called by orchestrator / API |
| `job_cdm_version_manager` | Versioning operations (branch, save, approve, template) | API / UI |

**Export (2 jobs)**

| Job Name | Purpose | Trigger |
|----------|---------|---------|
| `job_cdm_export_file` | Export DTA metadata to Excel/PDF files | API / UI |
| `job_cdm_export_genie_assets` | Generate Genie space training assets | Manual |

**Infrastructure (3 jobs)**

| Job Name | Purpose | Trigger |
|----------|---------|---------|
| `job_populate_config_cache` | Load configuration into Spark cache | Called by other jobs |
| `job_cdm_sql_setup` | SQL infrastructure setup (catalog, schemas, volumes) | Manual / CI/CD |
| `job_cdm_app_permissions` | Permission tables and user group setup | Manual / CI/CD |

### Test Jobs (6 total)

| Job Name | Purpose | Triggers |
|----------|---------|----------|
| `job_test_cdm_dta_import` | End-to-end test for DTA import pipeline with all document types | `job_cdm_dta_import` |
| `job_test_cdm_cleanup` | Drop all tables and delete checkpoint folders | Direct notebook |
| `job_test_cdm_create_dta_template` | Test DTA Template creation from approved DTAs | `job_cdm_version_manager` |
| `job_test_cdm_export_genie_assets` | Test Genie asset generation | `job_cdm_export_genie_assets` |
| `job_test_cdm_sql_setup` | Test SQL catalog/schema setup | `job_cdm_sql_setup` |
| `job_test_cdm_app_permissions` | Test permission tables and user group setup | `job_cdm_app_permissions` |

---

## Diagrams

**Orchestration**

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| DTA Import | End-to-end orchestrator with pipeline modes | [PNG](./diagrams/01_job_cdm_dta_import.drawio.png) | [Draw.io](./diagrams/01_job_cdm_dta_import.drawio) |
| Setup Study | Study creation and protocol processing trigger | [PNG](./diagrams/01_job_cdm_setup_study.drawio.png) | [Draw.io](./diagrams/01_job_cdm_setup_study.drawio) |

**Document Processing**

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| File Processor | ZIP extraction and manifest creation | [PNG](./diagrams/01_job_cds_file_processor.drawio.png) | [Draw.io](./diagrams/01_job_cds_file_processor.drawio) |
| tsDTA Processor | Excel sheet processing with conditional logic | [PNG](./diagrams/01_job_cds_tsdta_xls_processor.drawio.png) | [Draw.io](./diagrams/01_job_cds_tsdta_xls_processor.drawio) |
| Protocol Processor | Protocol TOC extraction and AI table parsing | [PNG](./diagrams/01_job_cdm_protocol_processor.drawio.png) | [Draw.io](./diagrams/01_job_cdm_protocol_processor.drawio) |
| OA Processor | Operational Agreement attribute/option extraction | [PNG](./diagrams/01_job_cdm_tsdta_oa_processor.drawio.png) | [Draw.io](./diagrams/01_job_cdm_tsdta_oa_processor.drawio) |

**DTA Management & Export**

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| DTA Create | DTA instance creation with branching | [PNG](./diagrams/01_job_cdm_dta_create.drawio.png) | [Draw.io](./diagrams/01_job_cdm_dta_create.drawio) |
| Version Manager | Condition chain for versioning actions | [PNG](./diagrams/01_job_cdm_version_manager.drawio.png) | [Draw.io](./diagrams/01_job_cdm_version_manager.drawio) |
| Export File | File export to Volumes | [PNG](./diagrams/01_job_cdm_export_file.drawio.png) | [Draw.io](./diagrams/01_job_cdm_export_file.drawio) |
| Export Genie Assets | Genie training asset generation | [PNG](./diagrams/01_job_cdm_export_genie_assets.drawio.png) | [Draw.io](./diagrams/01_job_cdm_export_genie_assets.drawio) |

---

## Main Jobs

### 1. job_cdm_dta_import

**Description**

The main orchestrator job for importing clinical trial documents with intelligent pipeline modes. Supports auto-detection of document types for bulk imports, or explicit pipeline selection for targeted processing. Features sandbox mode for UI preview workflows.

**Key Features:**
- **Pipeline Modes**: `auto` (default), `tsdta`, `protocol`, `operational_agreement`
- **Sandbox Mode**: Skip DTA creation for UI preview (`sandbox=true`)
- **Parallel Processing**: Multiple document types processed simultaneously
- **Auto-Detection**: Queries manifest to determine which pipelines to run

**Trigger**

| Type | Details |
|------|---------|
| File Arrival | Automatically triggers when new files land in `/Volumes/{catalog}/bronze_md/clinical_data_standards/{source_root}/uploads/` |
| Manual | Can be run via Databricks CLI or UI with custom parameters |
| API | Called by other jobs (e.g., `job_cdm_setup_study`) with specific pipeline mode |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog for processing |
| `source_root` | string | `historical_data` | Root folder containing uploads (historical_data, test, studies) |
| `pipeline` | string | `auto` | Pipeline mode: `auto`, `tsdta`, `protocol`, `operational_agreement` |
| `sandbox` | string | `false` | If `true`, skip DTA creation (UI preview mode) |
| `document_type` | string | `""` | UI-provided document type tag (overrides path-based tagging) |

**Pipeline Flow**

![DTA Import Pipeline](./diagrams/01_job_cdm_dta_import.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_dta_import.drawio)

**Main Pipeline Tasks:**

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Initialize configuration and context | - |
| `process_files` | Extract ZIPs, create manifest, tag documents | `setup` |
| `check_auto_mode` | Condition: Is pipeline=auto? | `process_files` |
| **Auto Mode Branch:** | | |
| `detect_document_types` | Query manifest, set has_tsdta/protocol/oa flags | `check_auto_mode` (true) |
| `check_auto_has_tsdta` | Condition: tsDTA detected? | `detect_document_types` |
| `process_tsdta_auto` | Run tsDTA processor if detected | `check_auto_has_tsdta` (true) |
| `check_auto_has_protocol` | Condition: Protocol detected? | `detect_document_types` |
| `process_protocol_auto` | Run Protocol processor if detected | `check_auto_has_protocol` (true) |
| `check_auto_has_oa` | Condition: OA detected? | `detect_document_types` |
| `process_oa_auto` | Run OA processor if detected (depends on tsDTA) | `check_auto_has_oa` (true), `process_tsdta_auto` |
| **Explicit Mode Branch:** | | |
| `check_explicit_tsdta` | Condition: pipeline=tsdta? | `check_auto_mode` (false) |
| `process_tsdta_explicit` | Run tsDTA processor explicitly | `check_explicit_tsdta` (true) |
| `check_explicit_protocol` | Condition: pipeline=protocol? | `check_auto_mode` (false) |
| `process_protocol_explicit` | Run Protocol processor explicitly | `check_explicit_protocol` (true) |
| `check_explicit_oa` | Condition: pipeline=operational_agreement? | `check_auto_mode` (false) |
| `process_oa_explicit` | Run OA processor explicitly | `check_explicit_oa` (true) |
| **Final Processing:** | | |
| `normalize_reference_data` | Token overlap matching for vendor/stream names | All processing tasks (AT_LEAST_ONE_SUCCESS) |
| `check_sandbox_mode` | Condition: sandbox=false? | `normalize_reference_data`, processors (NONE_FAILED) |
| `create_dta` | Create DTA instances and DTA Major versions | `check_sandbox_mode` (true) |

**Output/Results**

- **Bronze Layer**: Document manifest, extracted files
- **Silver Layer**: Processed codelists, transfer variables, test concepts, protocol sections, OA attributes
- **Gold Layer**: DTA Major versions (if sandbox=false)
- **Sandbox Tables**: Preview data (if sandbox=true)
- **Metadata**: Normalized vendor and data stream names

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_dta_import.job.yml` |
| Child Jobs | `job_cdm_file_processor`, `job_cdm_tsdta_xls_processor`, `job_cdm_protocol_processor`, `job_cdm_tsdta_oa_processor`, `job_cdm_dta_create` |
| Detection Notebook | `notebooks/data_engineering/clinical_data_standards/jobs/nb_detect_document_types.ipynb` |
| Normalization Notebook | `notebooks/data_engineering/clinical_data_standards/jobs/nb_normalize_reference_data.ipynb` |

**Operational Notes**

⚠️ **Important Dependencies:**
- OA processor depends on tsDTA processor for `dta_id` lookup
- In auto mode, both can run but OA waits for tsDTA completion
- In explicit mode, OA can run independently (assumes tsDTA already processed)

💡 **Pipeline Mode Selection:**
- Use `auto` for historical bulk imports (detects all document types)
- Use `protocol` for study creation workflows
- Use `tsdta` or `operational_agreement` for targeted reprocessing

📝 **Sandbox Mode:**
- Enables UI preview without affecting gold layer
- Results stored in separate sandbox tables
- DTA creation skipped to prevent incomplete records

---

### 2. job_cdm_setup_study

**Description**

Study creation orchestrator that creates a new study record and triggers protocol document processing. Designed for UI-driven workflows where users create studies and upload protocol documents for AI-powered parsing and review.

**Trigger**

| Type | Details |
|------|---------|
| API/UI | Called from Study Management UI when user creates new study with protocol upload |
| Manual | Can be run via Databricks CLI for testing |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog |
| `study_id` | string | `""` | Unique study identifier |
| `study_title` | string | `""` | Full study title |
| `study_nickname` | string | `""` | Short study name |
| `study_description` | string | `""` | Study description |
| `study_phase` | string | `""` | Study phase (1, 2, 3, 4) |
| `protocol_id` | string | `""` | Protocol document identifier |
| `source_root` | string | `test` | Source folder (typically "test" or study-specific) |
| `source_subdir` | string | `""` | Subdirectory for protocol file |
| `created_by` | string | `${var.user_email}` | User creating the study |

**Pipeline Flow**

![Setup Study Pipeline](./diagrams/01_job_cdm_setup_study.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_setup_study.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Initialize job context, set run/job IDs for lineage | - |
| `create_study` | Insert study record into `md_study` table with status=IN_PROGRESS | `setup` |
| `trigger_protocol_import` | Call `job_cdm_dta_import` with pipeline=protocol, sandbox=true | `create_study` |

**Output/Results**

- **Study Record**: New entry in `gold_md.md_study` table
- **Protocol Processing**: Triggers DTA import orchestrator which:
  1. Extracts protocol document
  2. Runs `job_cdm_protocol_processor`
  3. Parses TOC sections
  4. Extracts tables via AI
  5. Stores results in sandbox tables for UI preview

**Workflow Integration**

```
User (Study Management UI)
  ↓ fills study form + uploads protocol PDF
job_cdm_setup_study
  ↓ creates study record (status=IN_PROGRESS)
  ↓ triggers protocol import
job_cdm_dta_import (pipeline=protocol, sandbox=true)
  ↓ extracts + processes protocol
  ↓ stores in sandbox tables
UI displays parsing results
  ↓ user reviews + approves
Study status updated to ACTIVE
```

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_setup_study.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Create Study | `notebooks/data_engineering/clinical_data_standards/jobs/nb_create_study.ipynb` |

💡 **Use Case**: Interactive study creation with protocol validation before going live

---

### 3. job_cdm_file_processor

**Description**

Processes ZIP files and regular documents containing clinical trial data. Extracts archives, creates document manifest in bronze layer, and tags files for downstream processing. Supports flexible directory structures with subdirectory organization.

**Trigger**

| Type | Details |
|------|---------|
| Called by | `job_cdm_dta_import` via `run_job_task` |
| Manual | Can be run independently for testing |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog for processing |
| `source_root` | string | `""` | Root folder containing uploads (e.g., historical_data, test) |
| `source_subdir` | string | `""` | Subdirectory within source_root for organized storage |
| `target_subdir` | string | `""` | Target subdirectory for extracted files |
| `document_type` | string | `""` | UI-provided document type (overrides path-based tag extraction) |

**Pipeline Flow**

![File Processor Pipeline](./diagrams/01_job_cds_file_processor.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cds_file_processor.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `process_files` | Extract ZIPs, create manifest, tag documents | `setup` |

**Output/Results**

- **Bronze Layer**: Document manifest table with file metadata, paths, document types, and status
- **Extracted Files**: Files extracted from ZIPs to ingested folder
- **Document Tags**: Automatic tagging based on file patterns or explicit `document_type` parameter

**Supported Document Types:**
- tsDTA Excel files (.xlsx, .xls)
- Protocol PDFs
- Operational Agreement documents
- Regular document files

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_file_processor.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Processor Notebook | `notebooks/data_engineering/clinical_data_standards/jobs/nb_file_processor.ipynb` |

---

### 3. job_cdm_tsdta_xls_processor

**Description**

Processes tsDTA (Trial Specific Data Transfer Agreement) Excel files. Extracts sheets, processes codelists, transfer variables, test concepts, and visits/activities into silver layer tables. Includes conditional processing to skip when no documents are found.

**Trigger**

| Type | Details |
|------|---------|
| Called by | `job_cdm_dta_import` via `run_job_task` |
| Manual | Can be run independently for testing |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog for processing |

**Dependencies**

- **openpyxl**: For .xlsx, .xlsm, .xlsb Excel files
- **xlrd**: For legacy .xls Excel files

**Pipeline Flow**

![tsDTA Processor Pipeline](./diagrams/01_job_cds_tsdta_xls_processor.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cds_tsdta_xls_processor.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `extract_excel_sheets` | Read Excel files, extract sheet data to bronze, set `documents_found` flag | `setup` |
| `check_documents_found` | **NEW** Condition: documents_found=true? | `extract_excel_sheets` |
| **Parallel Processing (if documents found):** | | |
| `load_codelist` | Process codelists, create lookup table | `check_documents_found` (true) |
| `load_visits_activities` | **NEW** Process Schedule of Activities, extract vendor visits (4 columns) | `check_documents_found` (true) |
| **Sequential Processing:** | | |
| `load_transfer_metadata` | Process transfer variables, compute hash, extract vendor/stream | `load_codelist` |
| `load_test_concepts` | Extract test concepts with dynamic headers, store as MAP<STRING,STRING> | `load_transfer_metadata` |
| `update_completion_status` | Mark documents as READY_FOR_VERSIONING | `load_test_concepts`, `load_visits_activities` |

**Output/Results**

- **Bronze Layer**: Excel sheet data (raw)
- **Silver Layer**: 
  - `silver_md.transfer_metadata` - Transfer variables with hashes and vendor/stream info
  - `silver_md.code_list` - Codelists for lookup
  - `silver_md.test_concepts` - Test concepts with dynamic schema
  - `silver_md.vendor_visits` - **NEW** Visits from Schedule of Activities
- **Vendor/Stream Extraction**: Raw vendor and data stream names (normalized later by orchestrator)

**Processing Order:**

1. **Codelists first** - Creates lookup table needed by transfer variables
2. **Transfer variables second** - Uses codelists, computes hash
3. **Test concepts third** - Uses transfer variable names for header detection
4. **Visits run in parallel** - Independent processing from Schedule of Activities sheets

📝 **Note**: Reference data (vendor/stream) normalization moved to orchestrator's `normalize_reference_data` task for consolidated token overlap matching across all document types.

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_tsdta_processor.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Extract Sheets | `notebooks/data_engineering/clinical_data_standards/jobs/nb_extract_excel_sheets.ipynb` |
| Codelists | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_code_lists_processor.ipynb` |
| Transfer Variables | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_transfer_variables_processor.ipynb` |
| Test Concepts | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_test_concepts_processor.ipynb` |
| Visits Activities | `notebooks/data_engineering/clinical_data_standards/jobs/nb_visits_activities_processor.ipynb` |
| Completion Status | `notebooks/data_engineering/clinical_data_standards/jobs/nb_update_completion_status.ipynb` |

---

### 5. job_cdm_protocol_processor

**Description**

Parses protocol documents using TOC (Table of Contents) extraction and AI-powered table parsing. Extracts structured sections and tables from protocol PDFs for downstream processing and UI review.

**Trigger**

| Type | Details |
|------|---------|
| Called by | `job_cdm_dta_import` when pipeline=protocol or auto mode detects protocol documents |
| Manual | Can be run independently for testing |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog |
| `sandbox` | string | `true` | If true, store results in sandbox tables for UI preview |

**Dependencies**

- **PyMuPDF (fitz)**: Primary PDF TOC extraction engine
- **pdfminer-six**: Textual TOC fallback for documents without embedded TOC
- **PyPDF2**: PDF page extraction for sections

**Pipeline Flow**

![Protocol Processor Pipeline](./diagrams/01_job_cdm_protocol_processor.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_protocol_processor.drawio)

**Processing Steps (within `process_protocol` task):**

| Step | Description |
|------|-------------|
| 1. Query Manifest | Find protocol documents with status=EXTRACTED |
| 2. Extract TOC | Parse embedded TOC structure (PyMuPDF) or text patterns (pdfminer-six) |
| 3. Extract Sections | Use TOC to extract page ranges for key sections |
| 4. AI Table Extraction | Send table-rich sections to AI Document Intelligence for structured extraction |
| 5. Store Results | Save parsed sections and tables to sandbox or silver tables |

**Extracted Sections:**

- Study Design
- Objectives
- Endpoints
- Study Population
- Schedule of Activities
- Inclusion/Exclusion Criteria

**Output/Results**

**Sandbox Mode (sandbox=true):**
- `protocol_sandbox.parsed_sections` - Section text and metadata
- `protocol_sandbox.extracted_tables` - Structured tables
- For UI preview/review before production

**Production Mode (sandbox=false):**
- `silver_md.protocol_sections` - Section data
- `silver_md.protocol_tables` - Extracted tables
- For production use after approval

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_protocol_processor.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Processor Notebook | `notebooks/data_engineering/clinical_data_standards/jobs/nb_protocol_processor.ipynb` |

**Operational Notes**

💡 **TOC Extraction**: Hierarchical and page-aware for accurate section boundary detection

⚠️ **AI Integration**: Requires AI Document Intelligence service for table extraction

📝 **Sandbox Workflow**: UI displays parsed results for user review before production storage

---

### 6. job_cdm_tsdta_oa_processor

**Description**

Processes Operational Agreement (OA) documents. Parses OA files to extract attributes, options, and configuration specifications. Links to parent tsDTA documents via `parent_document_id` and looks up `dta_id` from Transfer Variables.

**Trigger**

| Type | Details |
|------|---------|
| Called by | `job_cdm_dta_import` when OA documents detected (auto mode) or pipeline=operational_agreement |
| Manual | Can be run independently (assumes tsDTA already processed) |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog |

**Pipeline Flow**

![OA Processor Pipeline](./diagrams/01_job_cdm_tsdta_oa_processor.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_tsdta_oa_processor.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `parse_documents` | Query manifest, parse OA documents, set `oa_parse_status` | `setup` |
| `check_oa_found` | Condition: oa_parse_status != NO_DATA? | `parse_documents` |
| `normalise_operational_agreement` | Normalize OA structure, link to parent doc, lookup dta_id | `check_oa_found` (true) |
| **Parallel Processing:** | | |
| `normalise_oa_attributes` | Extract and normalize attribute definitions, data specs, field mappings | `normalise_operational_agreement` |
| `normalise_oa_options` | Extract and normalize configuration options, valid value sets, constraints | `normalise_operational_agreement` |
| `operational_agreement_processed` | Finalize processing, update status to READY_FOR_VERSIONING | `normalise_oa_attributes`, `normalise_oa_options` |

**Output/Results**

- **Silver Layer**:
  - `silver_md.operational_agreements` - OA metadata with dta_id links
  - `silver_md.oa_attributes` - Attribute definitions
  - `silver_md.oa_options` - Configuration options
- **Document Status**: Updated to READY_FOR_VERSIONING

**Dependencies**

⚠️ **Critical**: OA processor depends on tsDTA processor
- Uses `parent_document_id` to link OA to parent tsDTA
- Looks up `dta_id` from Transfer Variables table
- Transfer Variables must exist before OA processing

**In Auto Mode**: `process_oa_auto` task depends on `process_tsdta_auto` completion

**In Explicit Mode**: OA can run independently (assumes tsDTA processed earlier)

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_tsdta_oa_processor.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Parse Raw | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_oa_parse_raw.ipynb` |
| Normalize OA | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_operational_agreement.ipynb` |
| Attributes | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_oa_attributes.ipynb` |
| Options | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_oa_options.ipynb` |
| Processed | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_operational_agreement_processor.ipynb` |

---

### 7. job_cdm_dta_create

**Description**

Creates DTA instances and manages the versioning workflow. Supports two modes:
- **HISTORICAL**: Simulates full draft → approve flow (for bulk import)
- **UI**: Creates DTA in draft status for manual editing

**Trigger**

| Type | Details |
|------|---------|
| Called by | `job_cdm_dta_import` via `run_job_task` (HISTORICAL mode) |
| API/UI | Direct invocation for new DTA creation (UI mode) |

**Pipeline Flow**

![DTA Create Pipeline](./diagrams/01_job_cdm_dta_create.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_dta_create.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `create_dta_instance` | Create DTA entity record | `setup` |
| `check_source` | Condition: Is source HISTORICAL? | `create_dta_instance` |
| **HISTORICAL Branch (true):** | | |
| `save_draft` | Link silver records with draft version | `check_source` (true) |
| `approve_to_major` | Promote draft to DTA Major in gold | `save_draft` |
| **UI Branch (false):** | | |
| `create_branch` | Create branch from library template | `check_source` (false) |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_dta_create.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Create Instance | `notebooks/data_engineering/common/nb_create_dta_instance.ipynb` |
| Save Draft | `notebooks/data_engineering/common/nb_version_save_draft.ipynb` |
| Approve DTA | `notebooks/data_engineering/common/nb_version_approve_dta.ipynb` |

---

### 8. job_cdm_version_manager

**Description**

Manages Clinical Data Metadata versioning operations using SCD Type 2. Supports five mutually exclusive actions via condition task chain (only one action runs per execution).

**Actions**

| Action | Description | Use Case |
|--------|-------------|----------|
| `CREATE_BRANCH` | Create new DTA draft from library template | UI initiates new DTA |
| `SAVE_DRAFT` | Save changes to existing draft | UI saves edits |
| `APPROVE_DTA` | Promote draft to DTA Major | Workflow approval |
| `CREATE_DTA_APPROVED` | Create DTA Major directly | Single DTA via API |
| `CREATE_DTA_TEMPLATE` | Merge approved DTAs into template | Librarian promotion |

**Trigger**

| Type | Details |
|------|---------|
| API/UI | Called with `action` parameter to specify operation |
| Other Jobs | Called by `job_cdm_dta_create` for branching |

**Pipeline Flow**

![Version Manager Pipeline](./diagrams/01_job_cdm_version_manager.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_version_manager.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `check_create_branch` | Condition: Is action CREATE_BRANCH? | `setup` |
| `create_branch` | Execute CREATE_BRANCH action | `check_create_branch` (true) |
| `check_save_draft` | Condition: Is action SAVE_DRAFT? | `check_create_branch` (false) |
| `save_draft` | Execute SAVE_DRAFT action | `check_save_draft` (true) |
| `check_approve_dta` | Condition: Is action APPROVE_DTA? | `check_save_draft` (false) |
| `approve_dta` | Execute APPROVE_DTA action | `check_approve_dta` (true) |
| `check_create_major` | Condition: Is action CREATE_DTA_APPROVED? | `check_approve_dta` (false) |
| `create_dta_major` | Execute CREATE_DTA_APPROVED action | `check_create_major` (true) |
| `create_dta_template` | Execute CREATE_DTA_TEMPLATE (default) | `check_create_major` (false) |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_version_manager.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Create Branch | `notebooks/data_engineering/common/nb_version_create_branch.ipynb` |
| Save Draft | `notebooks/data_engineering/common/nb_version_save_draft.ipynb` |
| Approve DTA | `notebooks/data_engineering/common/nb_version_approve_dta.ipynb` |
| Create Template | `notebooks/data_engineering/common/nb_promote_to_template.ipynb` |

---

### 9. job_cdm_export_file

**Description**

Generic file export job for DTA metadata. Generates Excel/PDF files and uploads to Unity Catalog Volumes.

**Export Types**

| Type | Format | Status |
|------|--------|--------|
| `tsDTA` | Excel (.xlsx) | ✅ Implemented |
| `oa` | PDF | 🔜 Future |
| `dta_full` | ZIP package | 🔜 Future |

**Trigger**

| Type | Details |
|------|---------|
| API/UI | Called with `dta_id` and `export_type` parameters |

**Pipeline Flow**

![Export File Pipeline](./diagrams/01_job_cdm_export_file.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_export_file.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and validate parameters | - |
| `export_file` | Generate export file and upload to Volumes | `setup` |

**Output Path**

```
/Volumes/{catalog}/bronze_md/{source_root}/exports/{date}/{dta_number}/
```

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_export_file.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Export Notebook | `notebooks/data_engineering/clinical_data_standards/jobs/nb_export_dta_file.ipynb` |

---

### 10. job_cdm_export_genie_assets

**Description**

Generates Databricks Genie space training assets. Dynamically discovers tables, generates SQL comments, instructions, example queries, and assembles the serialized space configuration.

**Trigger**

| Type | Details |
|------|---------|
| Manual | Run via Databricks CLI or UI |

**Pipeline Flow**

![Export Genie Assets Pipeline](./diagrams/01_job_cdm_export_genie_assets.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_export_genie_assets.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and validate parameters | - |
| `export_genie_assets` | Generate SQL comments, instructions, example queries, component JSONs | `setup` |
| `generate_serialized_space` | Assemble components into `serialized_space.json` | `export_genie_assets` |

**Output Files**

```
/Volumes/{catalog}/bronze_md/{source_volume}/{source_root}/exports/genie/
├── sql/
│   ├── add_table_comments.sql
│   └── example_queries.sql
├── components/
│   ├── data_sources.json
│   ├── sample_questions.json
│   ├── text_instructions.json
│   └── example_queries.json
├── genie_instructions.txt
├── serialized_space.json
└── export_manifest.json
```

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_export_genie_assets.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Export Assets | `notebooks/data_engineering/clinical_data_standards/jobs/nb_export_genie_assets.ipynb` |
| Generate Space | `notebooks/data_engineering/clinical_data_standards/jobs/nb_generate_serialized_space.ipynb` |

---

### 11. job_populate_config_cache

**Description**

Loads configuration data into Spark cache for fast access by processing jobs. Pre-caches reference data, mappings, and configuration settings to avoid repeated Delta table reads during job execution.

**Trigger**

| Type | Details |
|------|---------|
| Called by | Other jobs via setup notebook |
| Manual | Can be run to refresh cache |

**Output/Results**

- Cached configuration data in Spark memory
- Faster job execution due to reduced I/O

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/common/jobs/job_populate_config_cache.job.yml` |

---

### 12. job_cdm_sql_setup

**Description**

SQL infrastructure setup job that creates and configures the database environment. This is actually a 3-in-1 job definition containing three separate jobs for different aspects of setup.

**Trigger**

| Type | Details |
|------|---------|
| Manual | Run during initial setup or environment provisioning |
| CI/CD | Can be automated in deployment pipelines |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog to create/setup |

**Sub-Jobs:**

1. **job_cdm_sql_setup** - Create catalog, schemas, and volumes
   - Creates Unity Catalog if not exists
   - Creates bronze_md, silver_md, gold_md schemas
   - Creates volumes for file storage

2. **job_cdm_sql_load_reference_data** - Load reference data (placeholder)
   - Loads initial reference data
   - Seeds lookup tables

3. **job_cdm_sql_load_config_data** - Load config data to cache table
   - Populates configuration cache tables
   - Loads framework settings

**Output/Results**

- Catalog and schema structure created
- Volumes provisioned
- Reference data loaded
- Configuration tables populated

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/sql/common/jobs/job_cdm_sql_setup.job.yml` |
| Setup SQL | `sql/setup_cds_catalog.sql` |
| Reference Data SQL | `sql/load_reference_data.sql` |
| Config Data SQL | `sql/load_config_data.sql` |

💡 **Best Practice**: Run this job first when setting up a new environment

---

### 13. job_cdm_app_permissions

**Description**

Creates and seeds permission tables for the Clinical Data Standards Flask application. Sets up user groups, permissions, and access control mappings for role-based security.

**Trigger**

| Type | Details |
|------|---------|
| Manual | Run after SQL setup and before app deployment |
| CI/CD | Can be automated in deployment pipelines |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog |

**Created Tables:**

- `md_users` - Application users
- `md_user_groups` - User groups (JNJ_DAE, VENDOR, JNJ_LIBRARIAN)
- `md_permissions` - Permission definitions
- `md_user_group_memberships` - User to group mappings
- `md_group_permissions` - Group to permission mappings

**User Groups:**

| Group | Purpose |
|-------|---------|
| `JNJ_DAE` | J&J Data Analytics & Engineering team - full access |
| `VENDOR` | External vendor users - read/edit own DTAs |
| `JNJ_LIBRARIAN` | Librarians - template management, approval workflows |

**Prerequisites:**

- `job_cdm_sql_setup` must be run first (to create schemas)
- CDM import job should be run (to populate vendors)

**Output/Results**

- Permission tables created and seeded
- User groups configured
- Ready for Flask app user simulation

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/sql/common/jobs/job_cdm_app_permissions.job.yml` |
| Permissions SQL | `sql/setup_cdm_app_permissions.sql` |

⚠️ **Note**: Run after job_cdm_dta_import to ensure vendors exist for permission mapping

---

## Test Jobs

Test jobs are used for development and validation. They typically trigger main jobs with test-specific parameters.

### job_test_cdm_dta_import

**Purpose**: End-to-end test for the DTA import pipeline.

| Parameter | Default | Description |
|-----------|---------|-------------|
| `catalog_override` | `aira_test` | Test catalog |
| `source_root` | `test` | Uses test/uploads folder |

**Triggers**: `job_cdm_dta_import`

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/test/jobs/job_test_cdm_dta_import.job.yml` |

---

### job_test_cdm_cleanup

**Purpose**: Drop all bronze, silver, and gold tables. Delete checkpoint and ingested folders.

> ⚠️ **WARNING**: Only run in dev/test environments!

| Parameter | Default | Description |
|-----------|---------|-------------|
| `catalog_override` | `aira_test` | Catalog to clean up |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/test/jobs/job_test_cdm_cleanup.job.yml` |
| Cleanup Notebook | `notebooks/data_engineering/test/jobs/nb_cleanup_test_data.ipynb` |

---

### job_test_cdm_create_dta_template

**Purpose**: Test DTA Template creation from approved DTAs. Templates are scoped by (vendor, data_stream) combination.

| Parameter | Default | Description |
|-----------|---------|-------------|
| `library_type` | (empty) | Process all library types |
| `merge_strategy` | `UNION_DEDUP` | How to merge records |
| `data_provider_name` | (empty) | Filter by vendor |
| `data_stream_type` | (empty) | Filter by stream |

**Triggers**: `job_cdm_version_manager` with `action=CREATE_DTA_TEMPLATE`

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/test/jobs/job_test_cdm_create_dta_template.job.yml` |

---

### job_test_cdm_export_genie_assets

**Purpose**: Test Genie asset generation.

**Triggers**: `job_cdm_export_genie_assets`

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/test/jobs/job_test_cdm_export_genie_assets.job.yml` |

---

### job_test_cdm_sql_setup

**Purpose**: Test SQL catalog and schema setup.

**Triggers**: `job_cdm_sql_setup`

**Parameters**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `catalog_override` | `aira_test` | Test catalog |

**Prerequisites**:
- Clean test environment (or run `job_test_cdm_cleanup` first)

**Expected Outcomes**:
- Test catalog created
- Schemas (bronze_md, silver_md, gold_md) created
- Volumes provisioned

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/sql/test/jobs/job_test_cdm_sql_setup.job.yml` |

---

### job_test_cdm_app_permissions

**Purpose**: Test permission tables and user group setup for the CDM application.

**Triggers**: `job_cdm_app_permissions`

**Parameters**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `catalog_override` | `aira_test` | Test catalog |

**Prerequisites**:
- `job_test_cdm_sql_setup` completed (schemas exist)
- Test vendors available (or run test import first)

**Expected Outcomes**:
- Permission tables created in test catalog
- User groups seeded (JNJ_DAE, VENDOR, JNJ_LIBRARIAN)
- Sample users and permissions configured

**Typical Use Case**:
Testing Flask app authentication and authorization before production deployment

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/sql/test/jobs/job_test_cdm_app_permissions.job.yml` |

---

## Related Documentation

- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - Table schemas and data model
- [04_dta_versioning_design.readme.md](./04_dta_versioning_design.readme.md) - Version management operations
- [06_dta_workflow_design.readme.md](./06_dta_workflow_design.readme.md) - Workflow, approval chain, and governance
- [09_dta_genie_integration_design.readme.md](./09_dta_genie_integration_design.readme.md) - Genie AI integration

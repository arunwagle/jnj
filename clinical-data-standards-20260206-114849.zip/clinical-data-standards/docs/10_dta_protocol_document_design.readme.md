# Protocol Document Processing Design

## Overview

The Protocol Document Processing feature extends the Clinical Data Standards platform to extract structured Schedule of Activities (SoA) data from clinical trial protocol documents. This enables automated extraction of visits, procedures, and their mappings from complex PDF tables.

### Problem Statement

Protocol documents contain complex Schedule of Activities tables with:

- **Guide tables** that reference detailed tables (Table 1 → Tables 2-11)
- **Nested multi-level headers** (Phase → Cycle → Day)
- **Footnotes** defining timing windows and conditions
- **Cross-references** to other tables, sections, and appendices
- **Variable orientations** (visits as columns OR rows)

### Solution

A multi-phase LLM-powered extraction pipeline that:

1. **Classifies** table types to determine processing strategy
2. **Extracts** visits, procedures, and footnotes using specialized prompts
3. **Maps** procedure-visit relationships with footnote conditions
4. **Stores** results in silver draft tables for user review
5. **Promotes** approved data to gold tables

---

## Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| SoA Extraction Pipeline | End-to-end extraction flow showing all phases | [PNG](./diagrams/10_dta_soa_extraction_pipeline.drawio.png) | [Draw.io](./diagrams/10_dta_soa_extraction_pipeline.drawio) |
| Table Classification Tree | Decision tree for identifying table types | [PNG](./diagrams/10_dta_table_classification_tree.drawio.png) | [Draw.io](./diagrams/10_dta_table_classification_tree.drawio) |
| SoA Data Model | ERD showing draft and gold tables with relationships | [PNG](./diagrams/10_dta_soa_data_model.drawio.png) | [Draw.io](./diagrams/10_dta_soa_data_model.drawio) |
| Prompt Orchestration | Multi-prompt sequence and dependencies | [PNG](./diagrams/10_dta_prompt_orchestration.drawio.png) | [Draw.io](./diagrams/10_dta_prompt_orchestration.drawio) |
| UI Workflow | User interaction for review and approval | [PNG](./diagrams/10_dta_ui_workflow.drawio.png) | [Draw.io](./diagrams/10_dta_ui_workflow.drawio) |

### SoA Extraction Pipeline

![SoA Extraction Pipeline](./diagrams/10_dta_soa_extraction_pipeline.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/10_dta_soa_extraction_pipeline.drawio)

### Table Classification Tree

![Table Classification Tree](./diagrams/10_dta_table_classification_tree.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/10_dta_table_classification_tree.drawio)

### SoA Data Model

![SoA Data Model](./diagrams/10_dta_soa_data_model.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/10_dta_soa_data_model.drawio)

### Prompt Orchestration

![Prompt Orchestration](./diagrams/10_dta_prompt_orchestration.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/10_dta_prompt_orchestration.drawio)

### UI Workflow

![UI Workflow](./diagrams/10_dta_ui_workflow.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/10_dta_ui_workflow.drawio)

---

## Architecture

### Extraction Pipeline Phases

The extraction pipeline operates in three main phases:

#### Phase 1: Table Analysis

| Step | Purpose | Output |
|------|---------|--------|
| Identify Table Type | Classify as GUIDE_TABLE, DETAILED_SOA, DETAILED_SOA_TRANSPOSED, or ASSESSMENT_TABLE | `table_type`, `table_id` |
| Detect Orientation | Determine if visits are columns or rows | `orientation` |
| Extract Cross-References | Find references to other tables (e.g., "See Table 18") | `referenced_tables[]` |

#### Phase 2: Structure Extraction

| Step | Purpose | Output |
|------|---------|--------|
| Extract Visits | Parse column/row headers for visit identifiers | `visits[]` with day, window, phase |
| Extract Procedures | Parse row/column headers for procedure names | `procedures[]` with category |
| Extract Footnotes | Parse footnote markers and their definitions | `footnotes[]` with condition type |

#### Phase 3: Mapping & Storage

| Step | Purpose | Output |
|------|---------|--------|
| Map Procedures to Visits | Create intersection matrix with X markers | `mappings[]` with footnote refs |
| Resolve Conditions | Link footnote markers to mapping conditions | `condition_text` per mapping |
| Write to Silver | Store in draft tables for review | Draft table rows |

### Data Flow

```
┌─────────────────────┐
│ md_protocol_        │
│ document_sections   │  SoA tables extracted by Protocol Processor
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Phase 1: Classify  │  Prompt 1: Table Type Classification
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Phase 2: Extract   │  Prompts 2-4: Visits, Procedures, Mappings
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Phase 3: Footnotes │  Prompt 5: Footnote Extraction
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Silver Draft       │  md_study_visits_draft, md_study_procedures_draft,
│  Tables             │  md_procedure_visit_mappings_draft, md_soa_footnotes_draft
└─────────┬───────────┘
          │
          ▼ (User Approval)
┌─────────────────────┐
│  Gold Tables        │  md_study_visits, md_study_procedures,
│                     │  md_procedure_visit_mappings, md_soa_footnotes
└─────────────────────┘
```

---

## Table Type Classification

### Table Types

The extraction pipeline identifies four distinct table types:

| Type | Description | Characteristics | Processing Strategy |
|------|-------------|-----------------|---------------------|
| **GUIDE_TABLE** | Index table that references other tables | Cells contain "Table X" references, high-level summary | Extract references, do not process visits/procedures |
| **DETAILED_SOA** | Standard SoA with visits as columns | Visits in column headers, procedures in rows | Standard extraction with all 5 prompts |
| **DETAILED_SOA_TRANSPOSED** | Inverted SoA with visits as rows | Visits in row headers, procedures in columns | Transposed extraction, swap row/column logic |
| **ASSESSMENT_TABLE** | Focused table for specific assessments | PK sampling, biomarkers, specific procedures only | Extract as sub-schedule, link to parent SoA |

### Classification Decision Tree

```
                    ┌──────────────────────────────┐
                    │ Does table contain           │
                    │ "Table X" cell references?   │
                    └──────────────┬───────────────┘
                                   │
                    ┌──────────────┴──────────────┐
                    ▼                             ▼
                  YES                            NO
                    │                             │
                    ▼                             ▼
            ┌───────────────┐         ┌─────────────────────────┐
            │ GUIDE_TABLE   │         │ Are visits in column    │
            │               │         │ headers?                │
            └───────────────┘         └───────────┬─────────────┘
                                                  │
                                   ┌──────────────┴──────────────┐
                                   ▼                             ▼
                                 YES                            NO
                                   │                             │
                                   ▼                             ▼
                    ┌───────────────────────┐    ┌────────────────────────────┐
                    │ Is it a full SoA or   │    │ DETAILED_SOA_TRANSPOSED    │
                    │ focused assessment?   │    │                            │
                    └───────────┬───────────┘    └────────────────────────────┘
                                │
                 ┌──────────────┴──────────────┐
                 ▼                             ▼
            Full SoA                    Assessment Focus
                 │                             │
                 ▼                             ▼
        ┌───────────────┐           ┌──────────────────┐
        │ DETAILED_SOA  │           │ ASSESSMENT_TABLE │
        └───────────────┘           └──────────────────┘
```

### Example Table Types

#### GUIDE_TABLE Example

| Assessment | Screening | Treatment | Follow-up |
|------------|-----------|-----------|-----------|
| Screening Assessments | Table 2 | - | - |
| Efficacy Assessments | - | Table 3 | Table 4 |
| Safety Assessments | Table 5 | Table 6 | Table 7 |
| PK/Biomarker Assessments | - | Table 8 | - |

#### DETAILED_SOA Example

| Procedure | Screening | C1D1 | C1D8 | C1D15 | C2D1 | EOT |
|-----------|-----------|------|------|-------|------|-----|
| Informed consent | X | | | | | |
| Medical history | X | | | | | |
| Vital signs | X | X | X | X | X | X |
| Blood draw | X | X | | X | X | X |

---

## LLM Prompts

### Prompt Configuration

All prompts are configured in `clinical_data_standards.yaml` under the `protocol_processor.ai_processing.soa_extraction` section.

### Model Serving Configuration

```yaml
services:
  # Generic LLM Entity Extractor for SoA
  soa_entity_extractor:
    type: "model_serving"
    endpoint_name: "databricks-meta-llama-3-1-70b-instruct"
    max_tokens: 4096
    temperature: 0.1
    timeout_seconds: 180
    retry_attempts: 3
    description: "LLM for Schedule of Activities entity extraction"
```

### Supported Model Endpoints

| Endpoint | Context | Cost | Best For |
|----------|---------|------|----------|
| `databricks-meta-llama-3-1-70b-instruct` | 128K | $ | Default, cost-effective |
| `databricks-meta-llama-3-1-405b-instruct` | 128K | $$ | Complex tables |
| `databricks-meta-llama-3-3-70b-instruct` | 128K | $ | Latest Llama |
| `databricks-dbrx-instruct` | 32K | $$ | Databricks native |

---

### Prompt 1: Table Type Classification

**Purpose**: Classify the table to determine processing strategy.

**System Prompt**:

```
You are analyzing a clinical trial Schedule of Activities table.

Classify this table into ONE of these types:
1. GUIDE_TABLE - An index/navigation table that references other tables (cells contain "Table X" references)
2. DETAILED_SOA - A detailed schedule with visits as columns and procedures as rows
3. DETAILED_SOA_TRANSPOSED - A detailed schedule with procedures as columns and visits as rows
4. ASSESSMENT_TABLE - A focused table for specific assessments (PK, biomarkers, etc.)

Also identify:
- Table number/name (e.g., "Table 2", "Table 10")
- Treatment regimen it covers (e.g., "Part 1 and Part 2", "Part 3")
- Any parent table references
```

**Expected Output**:

```json
{
  "table_type": "DETAILED_SOA",
  "table_id": "Table 2",
  "table_title": "Schedule of Activities - Screening and Treatment Phase",
  "treatment_regimen": "Part 1 and Part 2",
  "parent_table_ref": "Table 1",
  "referenced_tables": [],
  "confidence": 0.95
}
```

---

### Prompt 2: Visit/Timepoint Extraction

**Purpose**: Extract all visits and timepoints from column (or row) headers.

**System Prompt**:

```
Extract all VISITS and TIMEPOINTS from this Schedule of Activities table.

For each visit, extract:
- visit_name: Human-readable name (e.g., "Screening", "Cycle 1 Day 1", "End of Treatment")
- visit_code: Short code if available (e.g., "SCR", "C1D1", "EOT")
- visit_day: Numeric day relative to study start (e.g., 1, 8, 15)
- window: Time window definition (e.g., "≤28 days before", "+7 days")
- phase: Study phase (Screening, Treatment, Follow-up)
- cycle: Cycle number if applicable (Cycle 1, Cycle 2, etc.)

IMPORTANT:
- Visits are typically in column headers (but may be in rows if table is transposed)
- Look for patterns: Day 1, D1, Week 4, W4, Cycle 1, C1, Visit 1, V1
- Handle merged/nested headers (e.g., "Treatment Phase" spanning "Cycle 1" and "Cycle 2")
- Extract window definitions from header text (e.g., "≤30 (+7) days")
```

**Expected Output**:

```json
{
  "visits": [
    {
      "visit_name": "Screening",
      "visit_code": "SCR",
      "visit_day": null,
      "window_text": "≤28 days before administration",
      "window_before": 28,
      "window_after": 0,
      "phase": "Screening",
      "cycle": null,
      "column_index": 1
    },
    {
      "visit_name": "Cycle 1 Day 1",
      "visit_code": "C1D1",
      "visit_day": 1,
      "window_text": null,
      "window_before": 0,
      "window_after": 0,
      "phase": "Treatment",
      "cycle": "Cycle 1",
      "column_index": 4
    }
  ],
  "header_structure": "NESTED",
  "orientation": "VISITS_AS_COLUMNS"
}
```

---

### Prompt 3: Procedure/Assessment Extraction

**Purpose**: Extract all procedures and their categories from row (or column) headers.

**System Prompt**:

```
Extract all PROCEDURES and ASSESSMENTS from this Schedule of Activities table.

For each procedure, extract:
- procedure_name: Full name (e.g., "Informed consent", "Hematology and chemistry")
- procedure_category: Category/section header (e.g., "Screening Assessments", "Laboratory Assessments")
- footnote_markers: Any superscript markers (a, b, c, etc.)
- section_reference: Any section references (e.g., "Section 8.2.1")

IMPORTANT:
- Procedures are typically in row headers (first column)
- Identify category headers (bold or spanning rows)
- Preserve footnote markers exactly as written (e.g., "Physical examination^{i,j}")
- Handle multi-line procedure names
```

**Expected Output**:

```json
{
  "procedures": [
    {
      "procedure_name": "Informed consent",
      "procedure_category": "Screening Assessments",
      "footnote_markers": ["c"],
      "section_reference": null,
      "row_index": 1
    },
    {
      "procedure_name": "Hematology and chemistry",
      "procedure_category": "Clinical laboratory assessments",
      "footnote_markers": ["j", "m"],
      "section_reference": "See Appendix 5",
      "row_index": 15
    }
  ],
  "categories": [
    {"name": "Screening Assessments", "start_row": 1, "end_row": 12},
    {"name": "Clinical laboratory assessments", "start_row": 13, "end_row": 20}
  ]
}
```

---

### Prompt 4: Procedure-Visit Mapping

**Purpose**: Extract the intersection matrix showing which procedures apply to which visits.

**System Prompt**:

```
Extract the MAPPING between procedures and visits from this Schedule of Activities table.

For each cell intersection, extract:
- procedure_row: Row index of the procedure
- visit_column: Column index of the visit
- cell_value: Exact cell content
- is_required: True if cell contains "X" (with or without footnote)
- condition_text: Any conditional text (e.g., "As clinically indicated", "C1D1 only")
- footnote_refs: Footnote markers in this cell (e.g., ["a", "g"])
- table_reference: If cell contains "See Table X" or "Refer to Table X"

IMPORTANT:
- "X" = required at this visit
- "X^a" = required with footnote condition
- Blank = not required
- Text in cell = conditional requirement
- "See Table X" = details in another table
```

**Expected Output**:

```json
{
  "mappings": [
    {
      "procedure_row": 5,
      "visit_column": 3,
      "cell_value": "X",
      "is_required": true,
      "condition_text": null,
      "footnote_refs": [],
      "table_reference": null
    },
    {
      "procedure_row": 8,
      "visit_column": 6,
      "cell_value": "X^a",
      "is_required": true,
      "condition_text": null,
      "footnote_refs": ["a"],
      "table_reference": null
    },
    {
      "procedure_row": 12,
      "visit_column": 4,
      "cell_value": "As clinically indicated",
      "is_required": false,
      "condition_text": "As clinically indicated",
      "footnote_refs": [],
      "table_reference": null
    }
  ]
}
```

---

### Prompt 5: Footnote Extraction

**Purpose**: Extract all footnotes and their definitions from below the table.

**System Prompt**:

```
Extract all FOOTNOTES from this Schedule of Activities table.

For each footnote, extract:
- marker: The footnote marker (a, b, c, etc.)
- text: Full footnote text
- condition_type: Type of condition (TIMING, FREQUENCY, POPULATION, CONDITIONAL, REFERENCE)

IMPORTANT:
- Footnotes are typically below the table
- Match markers to their full text
- Identify timing conditions (e.g., "Predose samples to be collected...")
- Identify population conditions (e.g., "For participants with...")
- Identify references to other sections/tables
```

**Expected Output**:

```json
{
  "footnotes": [
    {
      "marker": "a",
      "text": "Predose samples are to be collected prior to administration of study drug.",
      "condition_type": "TIMING"
    },
    {
      "marker": "b",
      "text": "For participants with body weight ≥100 kg only.",
      "condition_type": "POPULATION"
    },
    {
      "marker": "c",
      "text": "As clinically indicated.",
      "condition_type": "CONDITIONAL"
    }
  ]
}
```

---

## Output Schema

### Silver Draft Tables

All tables are created in `silver_md` schema with `_draft` suffix for user review before gold promotion.

#### md_study_visits_draft

| Column | Type | Description |
|--------|------|-------------|
| visit_id | STRING | UUID |
| study_id | STRING | FK to md_study |
| protocol_id | STRING | FK to md_protocol |
| visit_name | STRING | "Screening", "Cycle 1 Day 1", "EOT" |
| visit_code | STRING | "SCR", "C1D1", "EOT" |
| visit_day | INT | Relative study day (Day 1, Day 8, etc.) |
| visit_window_before | INT | Window days before (e.g., -7) |
| visit_window_after | INT | Window days after (e.g., +7) |
| visit_phase | STRING | "Screening", "Treatment", "Follow-up" |
| visit_cycle | STRING | "Cycle 1", "Cycle 2", etc. |
| visit_order | INT | Sequence order |
| source_table_ref | STRING | "Table 2", "Table 9" |
| row_status | STRING | ACTIVE, DELETED |
| version | STRING | Draft version |
| is_current_draft | BOOLEAN | True if latest draft |
| created_ts | TIMESTAMP | Audit |
| created_by_principal | STRING | Audit |

#### md_study_procedures_draft

| Column | Type | Description |
|--------|------|-------------|
| procedure_id | STRING | UUID |
| study_id | STRING | FK to md_study |
| procedure_name | STRING | "Informed consent", "Hematology and chemistry" |
| procedure_category | STRING | "Screening", "Laboratory", "Treatment" |
| procedure_order | INT | Display order |
| source_table_ref | STRING | Source table reference |
| row_status | STRING | ACTIVE, DELETED |
| version | STRING | Draft version |
| is_current_draft | BOOLEAN | True if latest draft |
| created_ts | TIMESTAMP | Audit |
| created_by_principal | STRING | Audit |

#### md_procedure_visit_mappings_draft

| Column | Type | Description |
|--------|------|-------------|
| mapping_id | STRING | UUID |
| procedure_id | STRING | FK to md_study_procedures_draft |
| visit_id | STRING | FK to md_study_visits_draft |
| is_required | BOOLEAN | True if X mark present |
| condition_text | STRING | "As clinically indicated", "C1D1 only" |
| footnote_refs | ARRAY<STRING> | ["a", "b", "c"] |
| cell_value | STRING | Original cell value |
| row_status | STRING | ACTIVE, DELETED |
| version | STRING | Draft version |
| is_current_draft | BOOLEAN | True if latest draft |
| created_ts | TIMESTAMP | Audit |
| created_by_principal | STRING | Audit |

#### md_soa_footnotes_draft

| Column | Type | Description |
|--------|------|-------------|
| footnote_id | STRING | UUID |
| study_id | STRING | FK to md_study |
| footnote_marker | STRING | "a", "b", "c" |
| footnote_text | STRING | Full footnote content |
| condition_type | STRING | TIMING, FREQUENCY, POPULATION, CONDITIONAL, REFERENCE |
| source_table_ref | STRING | Which table this footnote belongs to |
| row_status | STRING | ACTIVE, DELETED |
| version | STRING | Draft version |
| is_current_draft | BOOLEAN | True if latest draft |
| created_ts | TIMESTAMP | Audit |
| created_by_principal | STRING | Audit |

### Gold Tables

Gold tables have identical schema (minus draft columns) and are created when user approves:

- `md_study_visits`
- `md_study_procedures`
- `md_procedure_visit_mappings`
- `md_soa_footnotes`

---

## Configuration

### YAML Configuration

Add to `clinical_data_standards.yaml`:

```yaml
pipelines:
  protocol_processor:
    ai_processing:
      # Existing parse_document and section_filter config...
      
      # SoA Entity Extraction Configuration (NEW)
      soa_extraction:
        enabled: true
        service: "soa_entity_extractor"  # References services.soa_entity_extractor
        prompts:
          classify_table: |
            You are analyzing a clinical trial Schedule of Activities table...
          extract_visits: |
            Extract all VISITS and TIMEPOINTS...
          extract_procedures: |
            Extract all PROCEDURES and ASSESSMENTS...
          extract_mappings: |
            Extract the MAPPING between procedures and visits...
          extract_footnotes: |
            Extract all FOOTNOTES from this Schedule of Activities table...
        output_tables:
          visits: "md_study_visits_draft"
          procedures: "md_study_procedures_draft"
          mappings: "md_procedure_visit_mappings_draft"
          footnotes: "md_soa_footnotes_draft"
```

---

## Implementation

### Files to Create/Modify

| File | Action | Description |
|------|--------|-------------|
| `config/clinical_data_standards.yaml` | MODIFY | Add `soa_entity_extractor` service and prompts |
| `sql/setup_soa_tables.sql` | CREATE | DDL for silver draft tables |
| `notebooks/.../nb_extract_soa_activities.ipynb` | CREATE | Multi-prompt extraction orchestration |
| `resources/.../job_cds_extract_activities.job.yml` | CREATE | Job triggered from UI button |
| `apps/.../api/study_api.py` | MODIFY | Add `extract_activities` endpoint |
| `apps/.../templates/setup.html` | MODIFY | Display extracted activities with edit capability |

### Notebook Implementation

```python
# nb_extract_soa_activities.ipynb

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import ChatMessage
import json

def call_llm_extraction(prompt: str, table_content: str) -> dict:
    """Call LLM model serving endpoint for SoA extraction."""
    w = WorkspaceClient()
    
    response = w.serving_endpoints.query(
        name="databricks-meta-llama-3-1-70b-instruct",
        messages=[
            ChatMessage(role="system", content=prompt),
            ChatMessage(role="user", content=table_content)
        ],
        max_tokens=4096,
        temperature=0.1
    )
    
    return json.loads(response.choices[0].message.content)

# Extraction Pipeline
def extract_soa_activities(document_id: str, catalog: str):
    # 1. Read SoA tables from md_protocol_document_sections
    soa_tables = spark.sql(f"""
        SELECT section_id, section_name, content_data
        FROM {catalog}.bronze_md.md_protocol_document_sections
        WHERE document_id = '{document_id}'
          AND LOWER(section_name) LIKE '%schedule%activities%'
          AND content_type = 'table'
    """).collect()
    
    for table in soa_tables:
        # 2. Classify table type
        classification = call_llm_extraction(PROMPT_CLASSIFY, table.content_data)
        
        if classification['table_type'] == 'GUIDE_TABLE':
            continue  # Skip guide tables
        
        # 3. Extract visits
        visits = call_llm_extraction(PROMPT_VISITS, table.content_data)
        
        # 4. Extract procedures
        procedures = call_llm_extraction(PROMPT_PROCEDURES, table.content_data)
        
        # 5. Extract mappings
        mappings = call_llm_extraction(PROMPT_MAPPINGS, table.content_data)
        
        # 6. Extract footnotes
        footnotes = call_llm_extraction(PROMPT_FOOTNOTES, table.content_data)
        
        # 7. Write to silver draft tables
        write_to_draft_tables(visits, procedures, mappings, footnotes)
```

### Job Definition

```yaml
# job_cds_extract_activities.job.yml

resources:
  jobs:
    job_cds_extract_activities:
      name: job_cds_extract_activities
      description: |
        Extract Schedule of Activities data from Protocol documents using LLM.
        Triggered from "Extract Activities" button in Study Details UI.
      
      parameters:
        - name: catalog_override
          default: ${var.catalog}
        - name: document_id
          default: ""
        - name: study_id
          default: ""
      
      tasks:
        - task_key: extract_activities
          notebook_task:
            notebook_path: ${workspace.file_path}/notebooks/.../nb_extract_soa_activities
            base_parameters:
              catalog_override: "{{job.parameters.catalog_override}}"
              document_id: "{{job.parameters.document_id}}"
              study_id: "{{job.parameters.study_id}}"
```

### API Endpoint

```python
# study_api.py

@study_bp.route('/extract_activities', methods=['POST'])
def extract_activities():
    """Trigger SoA extraction job for a Protocol document."""
    data = request.get_json()
    document_id = data.get('document_id')
    study_id = data.get('study_id')
    
    w = WorkspaceClient()
    
    # Trigger extraction job
    run = w.jobs.run_now(
        job_id=get_job_id('job_cds_extract_activities'),
        job_parameters={
            'document_id': document_id,
            'study_id': study_id
        }
    )
    
    return jsonify({
        'status': 'started',
        'run_id': run.run_id
    })

@study_bp.route('/study/<study_id>/activities', methods=['GET'])
def get_study_activities(study_id):
    """Get extracted activities from draft tables."""
    visits = sql_client.execute_query(f"""
        SELECT * FROM {catalog}.silver_md.md_study_visits_draft
        WHERE study_id = '{study_id}' AND is_current_draft = true
    """)
    
    procedures = sql_client.execute_query(f"""
        SELECT * FROM {catalog}.silver_md.md_study_procedures_draft
        WHERE study_id = '{study_id}' AND is_current_draft = true
    """)
    
    mappings = sql_client.execute_query(f"""
        SELECT * FROM {catalog}.silver_md.md_procedure_visit_mappings_draft
        WHERE is_current_draft = true
    """)
    
    return jsonify({
        'visits': visits,
        'procedures': procedures,
        'mappings': mappings
    })
```

---

## UI Workflow

### User Journey

1. **Navigate to Study Details** → View Protocol document
2. **Click "Extract Activities"** → Triggers `job_cds_extract_activities`
3. **Wait for extraction** → Progress indicator shows job status
4. **Review extracted data** → Visits, procedures, and mappings displayed in editable tables
5. **Make corrections** → User can edit/delete/add rows
6. **Approve and promote** → Click "Approve" to promote draft to gold tables

### UI Components

| Component | Description |
|-----------|-------------|
| Extract Activities Button | Triggers extraction job, shows during Protocol review |
| Progress Indicator | Polling-based job status display |
| Visits Table | Editable table showing extracted visits |
| Procedures Table | Editable table showing extracted procedures |
| Mapping Matrix | Grid showing procedure-visit intersections |
| Footnotes Panel | Collapsible panel with footnote definitions |
| Approve Button | Promotes draft to gold after user review |

---

## Gold Promotion Workflow

### Approval Process

1. **User reviews** extracted data in draft tables
2. **User makes corrections** if needed (edit, delete, add rows)
3. **User clicks "Approve"** button
4. **System validates** data integrity (foreign keys, required fields)
5. **System copies** data from draft to gold tables
6. **System updates** draft `is_current_draft = false`
7. **System logs** approval action in activity log

### Promotion Logic

```python
def promote_to_gold(study_id: str, approved_by: str):
    """Promote draft tables to gold."""
    
    # Copy visits
    spark.sql(f"""
        INSERT INTO {catalog}.gold_md.md_study_visits
        SELECT 
            visit_id, study_id, protocol_id, visit_name, visit_code,
            visit_day, visit_window_before, visit_window_after,
            visit_phase, visit_cycle, visit_order, source_table_ref,
            'ACTIVE' as row_status,
            current_timestamp() as created_ts,
            '{approved_by}' as created_by_principal
        FROM {catalog}.silver_md.md_study_visits_draft
        WHERE study_id = '{study_id}' AND is_current_draft = true
    """)
    
    # Mark draft as not current
    spark.sql(f"""
        UPDATE {catalog}.silver_md.md_study_visits_draft
        SET is_current_draft = false
        WHERE study_id = '{study_id}' AND is_current_draft = true
    """)
    
    # Repeat for procedures, mappings, footnotes...
```

---

## Related Documentation

- [01_dta_job_architecture_design.readme.md](./01_dta_job_architecture_design.readme.md) - Overall pipeline architecture
- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - Schema for extracted data
- [07_dta_databricks_ai_design.readme.md](./07_dta_databricks_ai_design.readme.md) - Databricks AI capabilities (Model Serving and Genie)
- [03_dta_status_lifecycle_design.readme.md](./03_dta_status_lifecycle_design.readme.md) - Document processing statuses


# DTA Builder - Design Overview

---

## Table of Contents

- [Project Overview](#project-overview)
  - [Purpose](#purpose)
  - [Key Capabilities](#key-capabilities)
- [Business Context](#business-context)
  - [What is a Data Transfer Agreement (DTA)?](#what-is-a-data-transfer-agreement-dta)
  - [Business Glossary](#business-glossary)
  - [End-to-End Example](#end-to-end-example---central-lab-hematology)
  - [Why This Matters](#why-this-matters)
- [Architecture Summary](#architecture-summary)
  - [Platform](#platform)
  - [High-Level Architecture](#high-level-architecture)
- [Design Documents](#design-documents)
- [Quick Start](#quick-start)

---

## Project Overview

The **DTA Builder** is a metadata-driven platform for managing Data Transfer Agreements (DTAs) across the clinical data lifecycle. DTAs define the specifications, formats, and validation rules for data exchanged between pharmaceutical sponsors and external vendors (labs, CROs, data providers).

### Purpose

- **Standardize** DTA creation and management across clinical trials
- **Automate** metadata extraction from legacy Excel-based specifications
- **Version Control** all changes with full audit trail
- **Accelerate** delivery timelines through reusable templates
- **Ensure Governance** with multi-party approval workflows

### Key Capabilities

| Capability | Description |
|------------|-------------|
| **Metadata-Driven** | Capture transfer variables, test concepts, codelists as structured metadata |
| **Template Library** | Create reusable templates scoped by vendor and data stream |
| **Version Management** | SCD Type 2 versioning with branch, draft, approve, promote lifecycle |
| **Approval Workflow** | Multi-party approval chain (JNJ DAE → Vendor → Legal → Librarian) |
| **AI-Powered** | Document parsing, entity extraction, natural language search |
| **Export Formats** | Generate tsDTA Excel, Operational Agreement PDFs, full packages |

---

## Business Context

### What is a Data Transfer Agreement (DTA)?

A **Data Transfer Agreement (DTA)** is a **study- and data-stream–specific specification** that formally defines:

- **What data** a vendor must deliver  
- **How the data is structured and formatted**  
- **When and how often** the data is delivered  
- **How the data is validated upon receipt**  

DTAs act as the **single source of truth** for vendor data exchange and are foundational to reliable ingestion, standardization, and regulatory readiness.

### Business Glossary

#### Study

A **Study** is a formally approved clinical investigation conducted under a finalized protocol to evaluate the safety, efficacy, or other effects of an investigational product in human subjects.

**Relevance to DTA:**  
All DTAs are authored **within the context of a specific study**.

#### Vendor

A **Vendor** is an external organization contracted by the sponsor to generate, collect, or process clinical trial data.

**Relevance to DTA:**  
DTAs are **vendor-specific**, defining exactly how each vendor must deliver data.

#### Category

A **Category** describes the **type of clinical activity or assessment** that generated the data (e.g., Laboratory, PK, PD).

**Relevance to DTA:**  
Categories drive validation expectations and review workflows.

#### Data Stream

A **Data Stream** is a **logical flow of data** from a specific vendor for a defined category of clinical information.

**Relevance to DTA:**  
DTAs are authored **per data stream**, enabling precise ingestion control.

#### Domain

A **Domain** is a standardized grouping of clinical data, typically aligned to **CDISC SDTM**.

**Examples:** LB, PK, EG, QS

**Relevance to DTA:**  
Domains ensure data is **SDTM-ready** downstream.

#### Transfer Variables

**Transfer Variables** are the individual data fields that a vendor must deliver.

**Examples:** STUDYID, USUBJID, TEST_CD, RESULT_VALUE

**Relevance to DTA:**  
Transfer variables are the **core contractual elements** of a DTA.

#### Test Concepts

**Test Concepts** define the **clinical meaning of an assessment**, independent of vendor implementation or file structure.

They answer the question:  
*What is being measured clinically?*

**Example: Test Concepts in a Central Lab Data Stream**

| Test Concept | Clinical Description | Typical Vendor Test Code | SDTM Alignment |
|-------------|----------------------|--------------------------|----------------|
| Hemoglobin | Concentration of hemoglobin in blood | HB | LBTEST = Hemoglobin |
| White Blood Cell Count | Number of white blood cells | WBC | LBTEST = White Blood Cell Count |
| ALT | Alanine aminotransferase enzyme level | ALT | LBTEST = Alanine Aminotransferase |
| AST | Aspartate aminotransferase enzyme level | AST | LBTEST = Aspartate Aminotransferase |

**Relevance to DTA:**  
Test concepts provide **semantic stability across vendors** and enable consistent SDTM mapping.

#### Code Lists

**Code Lists** define permitted values for categorical variables.

**Relevance to DTA:**  
They enforce controlled terminology at ingestion.

#### Visits and Timepoints

- **Visit**: Protocol milestone (e.g., Week 4)
- **Timepoint**: Temporal anchor (e.g., Pre-dose)

**Relevance to DTA:**  
Ensures temporal alignment with protocol intent.

#### Pharmacokinetics (PK)

**PK** describes how the body affects a drug over time.

**Relevance to DTA:**  
PK DTAs require strict timing and unit validation.

#### Pharmacodynamics (PD)

**PD** describes how a drug affects the body.

**Relevance to DTA:**  
PD data links drug exposure to biological effect.

#### CDISC

**CDISC** is the global standards organization defining clinical data standards.

**Relevance to DTA:**  
The DTA Builder is **CDISC-aware**.

#### SDTM

**SDTM** defines how clinical data is structured for regulatory submission.

**Relevance to DTA:**  
DTAs are designed to be **SDTM-ready**.

#### ADaM

**ADaM** defines standards for analysis-ready datasets.

**Relevance to DTA:**  
Clean DTAs reduce downstream derivation complexity.

#### CDASH

**CDASH** defines standards for clinical data collection.

**Relevance to DTA:**  
Referenced when aligning vendor and site-collected data.

#### Operational Agreements

Define execution rules such as SLAs and correction processes.

**Relevance to DTA:**  
Ensure predictable vendor behavior.

#### Data Ingestion Parameters

Define how data is technically exchanged.

**Relevance to DTA:**  
Enable automated ingestion and validation.

### End-to-End Example — Central Lab (Hematology)

**Study:** JNJ-12345-301  
**Vendor:** Central Lab ABC  
**Category:** Laboratory  
**Data Stream:** Central Lab – Hematology  
**Domain:** LB  

**Transfer Variables:**  
STUDYID, USUBJID, LBREFID, TEST_CD, RESULT_VALUE, RESULT_UNIT, COLLECTION_DT

**Test Concepts:**  
Hemoglobin, White Blood Cell Count

### Why This Matters

The DTA Builder enables early data quality enforcement, reduces vendor variability, and improves regulatory readiness.

---

## Architecture Summary

### Platform

The DTA Builder is built on **Databricks** with the following components:

| Component | Technology | Purpose |
|-----------|------------|---------|
| **Data Platform** | Databricks Unity Catalog | Data governance, lineage, permissions |
| **Processing** | Databricks Jobs + Notebooks | ETL pipelines, versioning operations |
| **Storage** | Delta Lake (Bronze/Silver/Gold) | Medallion architecture for data layers |
| **UI Application** | Databricks Apps (Flask) | Web interface for DTA management |
| **Genie Agent** | Databricks AI/BI Genie | Natural language search and discovery |

### High-Level Architecture

#### DTA Builder Architecture

![DTA Builder Architecture](./diagrams/00_dta_builder_architecture.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/00_dta_builder_architecture.drawio)

#### CDH (Clinical Data Hub) - Future State Conceptual Architecture

> **Note**: This is a conceptual architecture based on the CDR Hackathon requirements. It illustrates the envisioned downstream flow from DTA Builder.

The CDH diagram expands the downstream consumer of DTA Builder, showing how approved DTAs flow into the Clinical Data Hub for study setup, vendor data ingestion, and conformance validation.

![CDH Conceptual Architecture](./diagrams/00_cdh_architecture.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/00_cdh_architecture.drawio)

---

## Design Documents

| # | Document | Description |
|---|----------|-------------|
| 01 | [Job Architecture](./01_dta_job_architecture_design.readme.md) | Pipeline jobs, orchestration, and task dependencies |
| 02 | [Schema Design](./02_dta_schema_design.readme.md) | Table schemas, ERD, and data model |
| 03 | [Status Lifecycle](./03_dta_status_lifecycle_design.readme.md) | Document and DTA status tracking |
| 04 | [Versioning](./04_dta_versioning_design.readme.md) | SCD Type 2 version management and template creation |
| 05 | [Hash Generation](./05_dta_hash_generation_design.readme.md) | Deduplication and change detection algorithms |
| 06 | [DTA Workflow](./06_dta_workflow_design.readme.md) | Approval flow, approver roles, and governance |
| 07 | [Databricks AI](./07_dta_databricks_ai_design.readme.md) | Model Serving, Genie, document parsing, conversational search |
| 08 | [Permissions](./08_dta_permissions_design.readme.md) | Access control, roles, and security |
| 09 | [Genie Integration](./09_dta_genie_integration_design.readme.md) | AI/BI natural language interface and training |
| 10 | [Protocol Document](./10_dta_protocol_document_design.readme.md) | Protocol document processing and SOA extraction |
| 11 | [CDH Ingestion Pipeline](./11_cdh_ingestion_pipeline_design.readme.md) | Clinical Data Hub ingestion pipeline |
| 12 | [CDH Conformance Checks Engine](./12_cdh_conformance_checks_engine_design.md) | Data quality validation and drift detection |

---

## Quick Start

### Deployment

See [13. DTA Deployment Guide](./13_dta_deployment_guide.md) for setup instructions.

### Useful Queries

See [Useful Queries](./useful_queries.md) for common SQL queries and debugging.

---

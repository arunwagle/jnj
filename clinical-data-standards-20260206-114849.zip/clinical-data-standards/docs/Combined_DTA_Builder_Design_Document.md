# DTA Builder - Complete Design Document

**Comprehensive Design Documentation for Clinical Data Standards Platform**

---

## Document Information

| Property | Details |
|----------|---------|
| **Project** | Clinical Data Standards (DTA Builder) |
| **Version** | 1.0 |
| **Date Created** | February 5, 2026 |
| **Total Documents** | 14 |
| **Document Range** | 00 - 13 |
| **Platform** | Databricks on AWS |

---

## About This Document

This combined design document consolidates **14 comprehensive design documents** (00 through 13) into a single reference for the Clinical Data Standards (DTA Builder) platform. The platform manages Data Transfer Agreements (DTAs) across the clinical data lifecycle, from metadata capture to conformance validation.

### Document Organization

Each section below represents a complete design document from the DTA Builder project, presented in sequential order with preserved formatting, diagrams, and code examples.

---

## Master Table of Contents

### Core Design Documents

1. [00. DTA Builder - Design Overview](#00-dta-builder---design-overview)
2. [01. Job Architecture Design](#01-job-architecture-design)
3. [02. Schema Design](#02-schema-design)
4. [03. Status Lifecycle Design](#03-status-lifecycle-design)
5. [04. Version Manager - SCD Type 2 Versioning System](#04-version-manager---scd-type-2-versioning-system)
6. [05. Hash Generation Design](#05-hash-generation-design)
7. [06. DTA Workflow Design](#06-dta-workflow-design)
8. [07. Databricks AI Design](#07-databricks-ai-design)
9. [08. Permissions & Access Control Design](#08-permissions--access-control-design)
10. [09. Genie AI Integration Design](#09-genie-ai-integration-design)
11. [10. Protocol Document Processing Design](#10-protocol-document-processing-design)
12. [11. Scalable CDH Clinical Data File Processing Architecture](#11-scalable-cdh-clinical-data-file-processing-architecture)
13. [12. CDH Conformance Checks Engine Design](#12-cdh-conformance-checks-engine-design)
14. [13. DTA Deployment Guide](#13-dta-deployment-guide)

---

## Document Status Legend

| Symbol | Meaning |
|--------|---------|
| ✅ | Fully Implemented |
| 🔜 | Planned / In Development |
| 📋 | Design Complete, Implementation Pending |

---

# 00. DTA Builder - Design Overview

# DTA Builder - Design Overview

---

## Table of Contents

- [Project Overview](#project-overview)
  - [Purpose](#purpose)
  - [Key Capabilities](#key-capabilities)
- [Business Context](#business-context)
  - [What is a Data Transfer Agreement (DTA)?](#what-is-a-data-transfer-agreement-dta)
  - [Business Glossary](#business-glossary)
  - [End-to-End Example](#end-to-end-example---central-lab-hematology)
  - [Why This Matters](#why-this-matters)
- [Architecture Summary](#architecture-summary)
  - [Platform](#platform)
  - [High-Level Architecture](#high-level-architecture)
- [Design Documents](#design-documents)
- [Quick Start](#quick-start)

---

## Project Overview

The **DTA Builder** is a metadata-driven platform for managing Data Transfer Agreements (DTAs) across the clinical data lifecycle. DTAs define the specifications, formats, and validation rules for data exchanged between pharmaceutical sponsors and external vendors (labs, CROs, data providers).

### Purpose

- **Standardize** DTA creation and management across clinical trials
- **Automate** metadata extraction from legacy Excel-based specifications
- **Version Control** all changes with full audit trail
- **Accelerate** delivery timelines through reusable templates
- **Ensure Governance** with multi-party approval workflows

### Key Capabilities

| Capability | Description |
|------------|-------------|
| **Metadata-Driven** | Capture transfer variables, test concepts, codelists as structured metadata |
| **Template Library** | Create reusable templates scoped by vendor and data stream |
| **Version Management** | SCD Type 2 versioning with branch, draft, approve, promote lifecycle |
| **Approval Workflow** | Multi-party approval chain (JNJ DAE → Vendor → Legal → Librarian) |
| **AI-Powered** | Document parsing, entity extraction, natural language search |
| **Export Formats** | Generate tsDTA Excel, Operational Agreement PDFs, full packages |

---

## Business Context

### What is a Data Transfer Agreement (DTA)?

A **Data Transfer Agreement (DTA)** is a **study- and data-stream–specific specification** that formally defines:

- **What data** a vendor must deliver  
- **How the data is structured and formatted**  
- **When and how often** the data is delivered  
- **How the data is validated upon receipt**  

DTAs act as the **single source of truth** for vendor data exchange and are foundational to reliable ingestion, standardization, and regulatory readiness.

### Business Glossary

#### Study

A **Study** is a formally approved clinical investigation conducted under a finalized protocol to evaluate the safety, efficacy, or other effects of an investigational product in human subjects.

**Relevance to DTA:**  
All DTAs are authored **within the context of a specific study**.

#### Vendor

A **Vendor** is an external organization contracted by the sponsor to generate, collect, or process clinical trial data.

**Relevance to DTA:**  
DTAs are **vendor-specific**, defining exactly how each vendor must deliver data.

#### Category

A **Category** describes the **type of clinical activity or assessment** that generated the data (e.g., Laboratory, PK, PD).

**Relevance to DTA:**  
Categories drive validation expectations and review workflows.

#### Data Stream

A **Data Stream** is a **logical flow of data** from a specific vendor for a defined category of clinical information.

**Relevance to DTA:**  
DTAs are authored **per data stream**, enabling precise ingestion control.

#### Domain

A **Domain** is a standardized grouping of clinical data, typically aligned to **CDISC SDTM**.

**Examples:** LB, PK, EG, QS

**Relevance to DTA:**  
Domains ensure data is **SDTM-ready** downstream.

#### Transfer Variables

**Transfer Variables** are the individual data fields that a vendor must deliver.

**Examples:** STUDYID, USUBJID, TEST_CD, RESULT_VALUE

**Relevance to DTA:**  
Transfer variables are the **core contractual elements** of a DTA.

#### Test Concepts

**Test Concepts** define the **clinical meaning of an assessment**, independent of vendor implementation or file structure.

They answer the question:  
*What is being measured clinically?*

**Example: Test Concepts in a Central Lab Data Stream**

| Test Concept | Clinical Description | Typical Vendor Test Code | SDTM Alignment |
|-------------|----------------------|--------------------------|----------------|
| Hemoglobin | Concentration of hemoglobin in blood | HB | LBTEST = Hemoglobin |
| White Blood Cell Count | Number of white blood cells | WBC | LBTEST = White Blood Cell Count |
| ALT | Alanine aminotransferase enzyme level | ALT | LBTEST = Alanine Aminotransferase |
| AST | Aspartate aminotransferase enzyme level | AST | LBTEST = Aspartate Aminotransferase |

**Relevance to DTA:**  
Test concepts provide **semantic stability across vendors** and enable consistent SDTM mapping.

#### Code Lists

**Code Lists** define permitted values for categorical variables.

**Relevance to DTA:**  
They enforce controlled terminology at ingestion.

#### Visits and Timepoints

- **Visit**: Protocol milestone (e.g., Week 4)
- **Timepoint**: Temporal anchor (e.g., Pre-dose)

**Relevance to DTA:**  
Ensures temporal alignment with protocol intent.

#### Pharmacokinetics (PK)

**PK** describes how the body affects a drug over time.

**Relevance to DTA:**  
PK DTAs require strict timing and unit validation.

#### Pharmacodynamics (PD)

**PD** describes how a drug affects the body.

**Relevance to DTA:**  
PD data links drug exposure to biological effect.

#### CDISC

**CDISC** is the global standards organization defining clinical data standards.

**Relevance to DTA:**  
The DTA Builder is **CDISC-aware**.

#### SDTM

**SDTM** defines how clinical data is structured for regulatory submission.

**Relevance to DTA:**  
DTAs are designed to be **SDTM-ready**.

#### ADaM

**ADaM** defines standards for analysis-ready datasets.

**Relevance to DTA:**  
Clean DTAs reduce downstream derivation complexity.

#### CDASH

**CDASH** defines standards for clinical data collection.

**Relevance to DTA:**  
Referenced when aligning vendor and site-collected data.

#### Operational Agreements

Define execution rules such as SLAs and correction processes.

**Relevance to DTA:**  
Ensure predictable vendor behavior.

#### Data Ingestion Parameters

Define how data is technically exchanged.

**Relevance to DTA:**  
Enable automated ingestion and validation.

### End-to-End Example — Central Lab (Hematology)

**Study:** JNJ-12345-301  
**Vendor:** Central Lab ABC  
**Category:** Laboratory  
**Data Stream:** Central Lab – Hematology  
**Domain:** LB  

**Transfer Variables:**  
STUDYID, USUBJID, LBREFID, TEST_CD, RESULT_VALUE, RESULT_UNIT, COLLECTION_DT

**Test Concepts:**  
Hemoglobin, White Blood Cell Count

### Why This Matters

The DTA Builder enables early data quality enforcement, reduces vendor variability, and improves regulatory readiness.

---

## Architecture Summary

### Platform

The DTA Builder is built on **Databricks** with the following components:

| Component | Technology | Purpose |
|-----------|------------|---------|
| **Data Platform** | Databricks Unity Catalog | Data governance, lineage, permissions |
| **Processing** | Databricks Jobs + Notebooks | ETL pipelines, versioning operations |
| **Storage** | Delta Lake (Bronze/Silver/Gold) | Medallion architecture for data layers |
| **UI Application** | Databricks Apps (Flask) | Web interface for DTA management |
| **Genie Agent** | Databricks AI/BI Genie | Natural language search and discovery |

### High-Level Architecture

#### DTA Builder Architecture

![DTA Builder Architecture](./diagrams/00_dta_builder_architecture.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/00_dta_builder_architecture.drawio)

#### CDH (Clinical Data Hub) - Future State Conceptual Architecture

> **Note**: This is a conceptual architecture based on the CDR Hackathon requirements. It illustrates the envisioned downstream flow from DTA Builder.

The CDH diagram expands the downstream consumer of DTA Builder, showing how approved DTAs flow into the Clinical Data Hub for study setup, vendor data ingestion, and conformance validation.

![CDH Conceptual Architecture](./diagrams/00_cdh_architecture.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/00_cdh_architecture.drawio)

---

## Design Documents

| # | Document | Description |
|---|----------|-------------|
| 01 | [Job Architecture](./01_dta_job_architecture_design.readme.md) | Pipeline jobs, orchestration, and task dependencies |
| 02 | [Schema Design](./02_dta_schema_design.readme.md) | Table schemas, ERD, and data model |
| 03 | [Status Lifecycle](./03_dta_status_lifecycle_design.readme.md) | Document and DTA status tracking |
| 04 | [Versioning](./04_dta_versioning_design.readme.md) | SCD Type 2 version management and template creation |
| 05 | [Hash Generation](./05_dta_hash_generation_design.readme.md) | Deduplication and change detection algorithms |
| 06 | [DTA Workflow](./06_dta_workflow_design.readme.md) | Approval flow, approver roles, and governance |
| 07 | [Databricks AI](./07_dta_databricks_ai_design.readme.md) | Model Serving, Genie, document parsing, conversational search |
| 08 | [Permissions](./08_dta_permissions_design.readme.md) | Access control, roles, and security |
| 09 | [Genie Integration](./09_dta_genie_integration_design.readme.md) | AI/BI natural language interface and training |
| 10 | [Protocol Document](./10_dta_protocol_document_design.readme.md) | Protocol document processing and SOA extraction |
| 11 | [CDH Ingestion Pipeline](./11_cdh_ingestion_pipeline_design.readme.md) | Clinical Data Hub ingestion pipeline |
| 12 | [CDH Conformance Checks Engine](./12_cdh_conformance_checks_engine_design.md) | Data quality validation and drift detection |

---

## Quick Start

### Deployment

See [13. DTA Deployment Guide](./13_dta_deployment_guide.md) for setup instructions.

### Useful Queries

See [Useful Queries](./useful_queries.md) for common SQL queries and debugging.

---

[Continue to: 01. Job Architecture Design →]

---

# 01. Job Architecture Design

# Job Architecture Design

## Overview

This document describes the Clinical Data Standards job architecture for processing DTA (Data Transfer Agreement) data, managing versions, and exporting metadata.

The architecture supports multiple document types (tsDTA, Protocol, Operational Agreement) with flexible pipeline modes for both automated bulk import and interactive UI workflows.

### Key Terminology

| Term | Definition |
|------|------------|
| **DTA** | Data Transfer Agreement - Specification document defining data structure, variables, and codelists for clinical trial data transfer between parties |
| **tsDTA** | Trial-Specific Data Transfer Agreement - DTA tailored for a specific clinical trial with trial-specific variables and requirements |
| **CDM** | Clinical Data Metadata - Refers to the metadata management system for DTAs |
| **Protocol** | Study protocol document containing study design, objectives, endpoints, and procedures |
| **Operational Agreement (OA)** | Document specifying operational details, attributes, and configuration options for data transfer |
| **SCD Type 2** | Slowly Changing Dimension Type 2 - A data warehousing technique that tracks historical changes by creating new records with effective dates |
| **Unity Catalog Volumes** | Databricks storage layer for managing files and unstructured data with governance |
| **Library Template** | Reusable DTA template created by merging approved DTAs, scoped by vendor and data stream |
| **Pipeline Mode** | Execution mode: `auto` (auto-detect documents), `tsdta`, `protocol`, or `operational_agreement` |
| **Sandbox Mode** | Preview mode (`sandbox=true`) that processes documents but skips DTA creation, used for UI preview and validation |
| **Version States** | Draft (editing), DTA Major (approved), Template (library) |

### Architecture Overview

The job architecture follows an **orchestrator-worker pattern** with three main execution flows:

1. **Historical Import** - Bulk import of historical tsDTA files from vendors
   - File arrival triggers orchestrator
   - Auto-detects document types
   - Processes all documents in parallel
   - Creates DTA Major versions automatically

2. **Study Creation** - Interactive study setup via UI
   - User creates study and uploads protocol
   - Sandbox mode processes protocol for preview
   - User reviews AI-parsed sections before approval

3. **Document Processing** - Manual or scheduled processing
   - Explicit pipeline mode targets specific document types
   - Used for reprocessing or targeted updates

### Main Jobs (13 total)

**Orchestration (2 jobs)**

| Job Name | Purpose | Trigger |
|----------|---------|---------|
| `job_cdm_dta_import` | End-to-end orchestrator for document import with pipeline modes (auto/tsdta/protocol/oa) | File Arrival / Manual / API |
| `job_cdm_setup_study` | Study creation orchestrator - creates study and triggers protocol processing | API / UI |

**Document Processing (4 jobs)**

| Job Name | Purpose | Trigger |
|----------|---------|---------|
| `job_cdm_file_processor` | Extract ZIP archives and create document manifest | Called by orchestrator |
| `job_cdm_tsdta_xls_processor` | Process tsDTA Excel files (sheets, codelists, transfer vars, test concepts, visits) | Called by orchestrator |
| `job_cdm_protocol_processor` | Parse protocol documents using TOC extraction and AI table parsing | Called by orchestrator |
| `job_cdm_tsdta_oa_processor` | Process Operational Agreement documents (attributes, options) | Called by orchestrator |

**DTA Management (2 jobs)**

| Job Name | Purpose | Trigger |
|----------|---------|---------|
| `job_cdm_dta_create` | Create DTA instances and manage versioning | Called by orchestrator / API |
| `job_cdm_version_manager` | Versioning operations (branch, save, approve, template) | API / UI |

**Export (2 jobs)**

| Job Name | Purpose | Trigger |
|----------|---------|---------|
| `job_cdm_export_file` | Export DTA metadata to Excel/PDF files | API / UI |
| `job_cdm_export_genie_assets` | Generate Genie space training assets | Manual |

**Infrastructure (3 jobs)**

| Job Name | Purpose | Trigger |
|----------|---------|---------|
| `job_populate_config_cache` | Load configuration into Spark cache | Called by other jobs |
| `job_cdm_sql_setup` | SQL infrastructure setup (catalog, schemas, volumes) | Manual / CI/CD |
| `job_cdm_app_permissions` | Permission tables and user group setup | Manual / CI/CD |

### Test Jobs (6 total)

| Job Name | Purpose | Triggers |
|----------|---------|----------|
| `job_test_cdm_dta_import` | End-to-end test for DTA import pipeline with all document types | `job_cdm_dta_import` |
| `job_test_cdm_cleanup` | Drop all tables and delete checkpoint folders | Direct notebook |
| `job_test_cdm_create_dta_template` | Test DTA Template creation from approved DTAs | `job_cdm_version_manager` |
| `job_test_cdm_export_genie_assets` | Test Genie asset generation | `job_cdm_export_genie_assets` |
| `job_test_cdm_sql_setup` | Test SQL catalog/schema setup | `job_cdm_sql_setup` |
| `job_test_cdm_app_permissions` | Test permission tables and user group setup | `job_cdm_app_permissions` |

---

## Diagrams

**Orchestration**

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| DTA Import | End-to-end orchestrator with pipeline modes | [PNG](./diagrams/01_job_cdm_dta_import.drawio.png) | [Draw.io](./diagrams/01_job_cdm_dta_import.drawio) |
| Setup Study | Study creation and protocol processing trigger | [PNG](./diagrams/01_job_cdm_setup_study.drawio.png) | [Draw.io](./diagrams/01_job_cdm_setup_study.drawio) |

**Document Processing**

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| File Processor | ZIP extraction and manifest creation | [PNG](./diagrams/01_job_cds_file_processor.drawio.png) | [Draw.io](./diagrams/01_job_cds_file_processor.drawio) |
| tsDTA Processor | Excel sheet processing with conditional logic | [PNG](./diagrams/01_job_cds_tsdta_xls_processor.drawio.png) | [Draw.io](./diagrams/01_job_cds_tsdta_xls_processor.drawio) |
| Protocol Processor | Protocol TOC extraction and AI table parsing | [PNG](./diagrams/01_job_cdm_protocol_processor.drawio.png) | [Draw.io](./diagrams/01_job_cdm_protocol_processor.drawio) |
| OA Processor | Operational Agreement attribute/option extraction | [PNG](./diagrams/01_job_cdm_tsdta_oa_processor.drawio.png) | [Draw.io](./diagrams/01_job_cdm_tsdta_oa_processor.drawio) |

**DTA Management & Export**

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| DTA Create | DTA instance creation with branching | [PNG](./diagrams/01_job_cdm_dta_create.drawio.png) | [Draw.io](./diagrams/01_job_cdm_dta_create.drawio) |
| Version Manager | Condition chain for versioning actions | [PNG](./diagrams/01_job_cdm_version_manager.drawio.png) | [Draw.io](./diagrams/01_job_cdm_version_manager.drawio) |
| Export File | File export to Volumes | [PNG](./diagrams/01_job_cdm_export_file.drawio.png) | [Draw.io](./diagrams/01_job_cdm_export_file.drawio) |
| Export Genie Assets | Genie training asset generation | [PNG](./diagrams/01_job_cdm_export_genie_assets.drawio.png) | [Draw.io](./diagrams/01_job_cdm_export_genie_assets.drawio) |

---

## Main Jobs

### 1. job_cdm_dta_import

**Description**

The main orchestrator job for importing clinical trial documents with intelligent pipeline modes. Supports auto-detection of document types for bulk imports, or explicit pipeline selection for targeted processing. Features sandbox mode for UI preview workflows.

**Key Features:**
- **Pipeline Modes**: `auto` (default), `tsdta`, `protocol`, `operational_agreement`
- **Sandbox Mode**: Skip DTA creation for UI preview (`sandbox=true`)
- **Parallel Processing**: Multiple document types processed simultaneously
- **Auto-Detection**: Queries manifest to determine which pipelines to run

**Trigger**

| Type | Details |
|------|---------|
| File Arrival | Automatically triggers when new files land in `/Volumes/{catalog}/bronze_md/clinical_data_standards/{source_root}/uploads/` |
| Manual | Can be run via Databricks CLI or UI with custom parameters |
| API | Called by other jobs (e.g., `job_cdm_setup_study`) with specific pipeline mode |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog for processing |
| `source_root` | string | `historical_data` | Root folder containing uploads (historical_data, test, studies) |
| `pipeline` | string | `auto` | Pipeline mode: `auto`, `tsdta`, `protocol`, `operational_agreement` |
| `sandbox` | string | `false` | If `true`, skip DTA creation (UI preview mode) |
| `document_type` | string | `""` | UI-provided document type tag (overrides path-based tagging) |

**Pipeline Flow**

![DTA Import Pipeline](./diagrams/01_job_cdm_dta_import.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_dta_import.drawio)

**Main Pipeline Tasks:**

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Initialize configuration and context | - |
| `process_files` | Extract ZIPs, create manifest, tag documents | `setup` |
| `check_auto_mode` | Condition: Is pipeline=auto? | `process_files` |
| **Auto Mode Branch:** | | |
| `detect_document_types` | Query manifest, set has_tsdta/protocol/oa flags | `check_auto_mode` (true) |
| `check_auto_has_tsdta` | Condition: tsDTA detected? | `detect_document_types` |
| `process_tsdta_auto` | Run tsDTA processor if detected | `check_auto_has_tsdta` (true) |
| `check_auto_has_protocol` | Condition: Protocol detected? | `detect_document_types` |
| `process_protocol_auto` | Run Protocol processor if detected | `check_auto_has_protocol` (true) |
| `check_auto_has_oa` | Condition: OA detected? | `detect_document_types` |
| `process_oa_auto` | Run OA processor if detected (depends on tsDTA) | `check_auto_has_oa` (true), `process_tsdta_auto` |
| **Explicit Mode Branch:** | | |
| `check_explicit_tsdta` | Condition: pipeline=tsdta? | `check_auto_mode` (false) |
| `process_tsdta_explicit` | Run tsDTA processor explicitly | `check_explicit_tsdta` (true) |
| `check_explicit_protocol` | Condition: pipeline=protocol? | `check_auto_mode` (false) |
| `process_protocol_explicit` | Run Protocol processor explicitly | `check_explicit_protocol` (true) |
| `check_explicit_oa` | Condition: pipeline=operational_agreement? | `check_auto_mode` (false) |
| `process_oa_explicit` | Run OA processor explicitly | `check_explicit_oa` (true) |
| **Final Processing:** | | |
| `normalize_reference_data` | Token overlap matching for vendor/stream names | All processing tasks (AT_LEAST_ONE_SUCCESS) |
| `check_sandbox_mode` | Condition: sandbox=false? | `normalize_reference_data`, processors (NONE_FAILED) |
| `create_dta` | Create DTA instances and DTA Major versions | `check_sandbox_mode` (true) |

**Output/Results**

- **Bronze Layer**: Document manifest, extracted files
- **Silver Layer**: Processed codelists, transfer variables, test concepts, protocol sections, OA attributes
- **Gold Layer**: DTA Major versions (if sandbox=false)
- **Sandbox Tables**: Preview data (if sandbox=true)
- **Metadata**: Normalized vendor and data stream names

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_dta_import.job.yml` |
| Child Jobs | `job_cdm_file_processor`, `job_cdm_tsdta_xls_processor`, `job_cdm_protocol_processor`, `job_cdm_tsdta_oa_processor`, `job_cdm_dta_create` |
| Detection Notebook | `notebooks/data_engineering/clinical_data_standards/jobs/nb_detect_document_types.ipynb` |
| Normalization Notebook | `notebooks/data_engineering/clinical_data_standards/jobs/nb_normalize_reference_data.ipynb` |

**Operational Notes**

⚠️ **Important Dependencies:**
- OA processor depends on tsDTA processor for `dta_id` lookup
- In auto mode, both can run but OA waits for tsDTA completion
- In explicit mode, OA can run independently (assumes tsDTA already processed)

💡 **Pipeline Mode Selection:**
- Use `auto` for historical bulk imports (detects all document types)
- Use `protocol` for study creation workflows
- Use `tsdta` or `operational_agreement` for targeted reprocessing

📝 **Sandbox Mode:**
- Enables UI preview without affecting gold layer
- Results stored in separate sandbox tables
- DTA creation skipped to prevent incomplete records

---

### 2. job_cdm_setup_study

**Description**

Study creation orchestrator that creates a new study record and triggers protocol document processing. Designed for UI-driven workflows where users create studies and upload protocol documents for AI-powered parsing and review.

**Trigger**

| Type | Details |
|------|---------|
| API/UI | Called from Study Management UI when user creates new study with protocol upload |
| Manual | Can be run via Databricks CLI for testing |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog |
| `study_id` | string | `""` | Unique study identifier |
| `study_title` | string | `""` | Full study title |
| `study_nickname` | string | `""` | Short study name |
| `study_description` | string | `""` | Study description |
| `study_phase` | string | `""` | Study phase (1, 2, 3, 4) |
| `protocol_id` | string | `""` | Protocol document identifier |
| `source_root` | string | `test` | Source folder (typically "test" or study-specific) |
| `source_subdir` | string | `""` | Subdirectory for protocol file |
| `created_by` | string | `${var.user_email}` | User creating the study |

**Pipeline Flow**

![Setup Study Pipeline](./diagrams/01_job_cdm_setup_study.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_setup_study.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Initialize job context, set run/job IDs for lineage | - |
| `create_study` | Insert study record into `md_study` table with status=IN_PROGRESS | `setup` |
| `trigger_protocol_import` | Call `job_cdm_dta_import` with pipeline=protocol, sandbox=true | `create_study` |

**Output/Results**

- **Study Record**: New entry in `gold_md.md_study` table
- **Protocol Processing**: Triggers DTA import orchestrator which:
  1. Extracts protocol document
  2. Runs `job_cdm_protocol_processor`
  3. Parses TOC sections
  4. Extracts tables via AI
  5. Stores results in sandbox tables for UI preview

**Workflow Integration**

```
User (Study Management UI)
  ↓ fills study form + uploads protocol PDF
job_cdm_setup_study
  ↓ creates study record (status=IN_PROGRESS)
  ↓ triggers protocol import
job_cdm_dta_import (pipeline=protocol, sandbox=true)
  ↓ extracts + processes protocol
  ↓ stores in sandbox tables
UI displays parsing results
  ↓ user reviews + approves
Study status updated to ACTIVE
```

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_setup_study.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Create Study | `notebooks/data_engineering/clinical_data_standards/jobs/nb_create_study.ipynb` |

💡 **Use Case**: Interactive study creation with protocol validation before going live

---

### 3. job_cdm_file_processor

**Description**

Processes ZIP files and regular documents containing clinical trial data. Extracts archives, creates document manifest in bronze layer, and tags files for downstream processing. Supports flexible directory structures with subdirectory organization.

**Trigger**

| Type | Details |
|------|---------|
| Called by | `job_cdm_dta_import` via `run_job_task` |
| Manual | Can be run independently for testing |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog for processing |
| `source_root` | string | `""` | Root folder containing uploads (e.g., historical_data, test) |
| `source_subdir` | string | `""` | Subdirectory within source_root for organized storage |
| `target_subdir` | string | `""` | Target subdirectory for extracted files |
| `document_type` | string | `""` | UI-provided document type (overrides path-based tag extraction) |

**Pipeline Flow**

![File Processor Pipeline](./diagrams/01_job_cds_file_processor.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cds_file_processor.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `process_files` | Extract ZIPs, create manifest, tag documents | `setup` |

**Output/Results**

- **Bronze Layer**: Document manifest table with file metadata, paths, document types, and status
- **Extracted Files**: Files extracted from ZIPs to ingested folder
- **Document Tags**: Automatic tagging based on file patterns or explicit `document_type` parameter

**Supported Document Types:**
- tsDTA Excel files (.xlsx, .xls)
- Protocol PDFs
- Operational Agreement documents
- Regular document files

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_file_processor.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Processor Notebook | `notebooks/data_engineering/clinical_data_standards/jobs/nb_file_processor.ipynb` |

---

### 3. job_cdm_tsdta_xls_processor

**Description**

Processes tsDTA (Trial Specific Data Transfer Agreement) Excel files. Extracts sheets, processes codelists, transfer variables, test concepts, and visits/activities into silver layer tables. Includes conditional processing to skip when no documents are found.

**Trigger**

| Type | Details |
|------|---------|
| Called by | `job_cdm_dta_import` via `run_job_task` |
| Manual | Can be run independently for testing |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog for processing |

**Dependencies**

- **openpyxl**: For .xlsx, .xlsm, .xlsb Excel files
- **xlrd**: For legacy .xls Excel files

**Pipeline Flow**

![tsDTA Processor Pipeline](./diagrams/01_job_cds_tsdta_xls_processor.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cds_tsdta_xls_processor.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `extract_excel_sheets` | Read Excel files, extract sheet data to bronze, set `documents_found` flag | `setup` |
| `check_documents_found` | **NEW** Condition: documents_found=true? | `extract_excel_sheets` |
| **Parallel Processing (if documents found):** | | |
| `load_codelist` | Process codelists, create lookup table | `check_documents_found` (true) |
| `load_visits_activities` | **NEW** Process Schedule of Activities, extract vendor visits (4 columns) | `check_documents_found` (true) |
| **Sequential Processing:** | | |
| `load_transfer_metadata` | Process transfer variables, compute hash, extract vendor/stream | `load_codelist` |
| `load_test_concepts` | Extract test concepts with dynamic headers, store as MAP<STRING,STRING> | `load_transfer_metadata` |
| `update_completion_status` | Mark documents as READY_FOR_VERSIONING | `load_test_concepts`, `load_visits_activities` |

**Output/Results**

- **Bronze Layer**: Excel sheet data (raw)
- **Silver Layer**: 
  - `silver_md.transfer_metadata` - Transfer variables with hashes and vendor/stream info
  - `silver_md.code_list` - Codelists for lookup
  - `silver_md.test_concepts` - Test concepts with dynamic schema
  - `silver_md.vendor_visits` - **NEW** Visits from Schedule of Activities
- **Vendor/Stream Extraction**: Raw vendor and data stream names (normalized later by orchestrator)

**Processing Order:**

1. **Codelists first** - Creates lookup table needed by transfer variables
2. **Transfer variables second** - Uses codelists, computes hash
3. **Test concepts third** - Uses transfer variable names for header detection
4. **Visits run in parallel** - Independent processing from Schedule of Activities sheets

📝 **Note**: Reference data (vendor/stream) normalization moved to orchestrator's `normalize_reference_data` task for consolidated token overlap matching across all document types.

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_tsdta_processor.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Extract Sheets | `notebooks/data_engineering/clinical_data_standards/jobs/nb_extract_excel_sheets.ipynb` |
| Codelists | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_code_lists_processor.ipynb` |
| Transfer Variables | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_transfer_variables_processor.ipynb` |
| Test Concepts | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_test_concepts_processor.ipynb` |
| Visits Activities | `notebooks/data_engineering/clinical_data_standards/jobs/nb_visits_activities_processor.ipynb` |
| Completion Status | `notebooks/data_engineering/clinical_data_standards/jobs/nb_update_completion_status.ipynb` |

---

### 5. job_cdm_protocol_processor

**Description**

Parses protocol documents using TOC (Table of Contents) extraction and AI-powered table parsing. Extracts structured sections and tables from protocol PDFs for downstream processing and UI review.

**Trigger**

| Type | Details |
|------|---------|
| Called by | `job_cdm_dta_import` when pipeline=protocol or auto mode detects protocol documents |
| Manual | Can be run independently for testing |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog |
| `sandbox` | string | `true` | If true, store results in sandbox tables for UI preview |

**Dependencies**

- **PyMuPDF (fitz)**: Primary PDF TOC extraction engine
- **pdfminer-six**: Textual TOC fallback for documents without embedded TOC
- **PyPDF2**: PDF page extraction for sections

**Pipeline Flow**

![Protocol Processor Pipeline](./diagrams/01_job_cdm_protocol_processor.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_protocol_processor.drawio)

**Processing Steps (within `process_protocol` task):**

| Step | Description |
|------|-------------|
| 1. Query Manifest | Find protocol documents with status=EXTRACTED |
| 2. Extract TOC | Parse embedded TOC structure (PyMuPDF) or text patterns (pdfminer-six) |
| 3. Extract Sections | Use TOC to extract page ranges for key sections |
| 4. AI Table Extraction | Send table-rich sections to AI Document Intelligence for structured extraction |
| 5. Store Results | Save parsed sections and tables to sandbox or silver tables |

**Extracted Sections:**

- Study Design
- Objectives
- Endpoints
- Study Population
- Schedule of Activities
- Inclusion/Exclusion Criteria

**Output/Results**

**Sandbox Mode (sandbox=true):**
- `protocol_sandbox.parsed_sections` - Section text and metadata
- `protocol_sandbox.extracted_tables` - Structured tables
- For UI preview/review before production

**Production Mode (sandbox=false):**
- `silver_md.protocol_sections` - Section data
- `silver_md.protocol_tables` - Extracted tables
- For production use after approval

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_protocol_processor.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Processor Notebook | `notebooks/data_engineering/clinical_data_standards/jobs/nb_protocol_processor.ipynb` |

**Operational Notes**

💡 **TOC Extraction**: Hierarchical and page-aware for accurate section boundary detection

⚠️ **AI Integration**: Requires AI Document Intelligence service for table extraction

📝 **Sandbox Workflow**: UI displays parsed results for user review before production storage

---

### 6. job_cdm_tsdta_oa_processor

**Description**

Processes Operational Agreement (OA) documents. Parses OA files to extract attributes, options, and configuration specifications. Links to parent tsDTA documents via `parent_document_id` and looks up `dta_id` from Transfer Variables.

**Trigger**

| Type | Details |
|------|---------|
| Called by | `job_cdm_dta_import` when OA documents detected (auto mode) or pipeline=operational_agreement |
| Manual | Can be run independently (assumes tsDTA already processed) |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog |

**Pipeline Flow**

![OA Processor Pipeline](./diagrams/01_job_cdm_tsdta_oa_processor.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_tsdta_oa_processor.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `parse_documents` | Query manifest, parse OA documents, set `oa_parse_status` | `setup` |
| `check_oa_found` | Condition: oa_parse_status != NO_DATA? | `parse_documents` |
| `normalise_operational_agreement` | Normalize OA structure, link to parent doc, lookup dta_id | `check_oa_found` (true) |
| **Parallel Processing:** | | |
| `normalise_oa_attributes` | Extract and normalize attribute definitions, data specs, field mappings | `normalise_operational_agreement` |
| `normalise_oa_options` | Extract and normalize configuration options, valid value sets, constraints | `normalise_operational_agreement` |
| `operational_agreement_processed` | Finalize processing, update status to READY_FOR_VERSIONING | `normalise_oa_attributes`, `normalise_oa_options` |

**Output/Results**

- **Silver Layer**:
  - `silver_md.operational_agreements` - OA metadata with dta_id links
  - `silver_md.oa_attributes` - Attribute definitions
  - `silver_md.oa_options` - Configuration options
- **Document Status**: Updated to READY_FOR_VERSIONING

**Dependencies**

⚠️ **Critical**: OA processor depends on tsDTA processor
- Uses `parent_document_id` to link OA to parent tsDTA
- Looks up `dta_id` from Transfer Variables table
- Transfer Variables must exist before OA processing

**In Auto Mode**: `process_oa_auto` task depends on `process_tsdta_auto` completion

**In Explicit Mode**: OA can run independently (assumes tsDTA processed earlier)

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_tsdta_oa_processor.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Parse Raw | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_oa_parse_raw.ipynb` |
| Normalize OA | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_operational_agreement.ipynb` |
| Attributes | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_oa_attributes.ipynb` |
| Options | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_oa_options.ipynb` |
| Processed | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_operational_agreement_processor.ipynb` |

---

### 7. job_cdm_dta_create

**Description**

Creates DTA instances and manages the versioning workflow. Supports two modes:
- **HISTORICAL**: Simulates full draft → approve flow (for bulk import)
- **UI**: Creates DTA in draft status for manual editing

**Trigger**

| Type | Details |
|------|---------|
| Called by | `job_cdm_dta_import` via `run_job_task` (HISTORICAL mode) |
| API/UI | Direct invocation for new DTA creation (UI mode) |

**Pipeline Flow**

![DTA Create Pipeline](./diagrams/01_job_cdm_dta_create.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_dta_create.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `create_dta_instance` | Create DTA entity record | `setup` |
| `check_source` | Condition: Is source HISTORICAL? | `create_dta_instance` |
| **HISTORICAL Branch (true):** | | |
| `save_draft` | Link silver records with draft version | `check_source` (true) |
| `approve_to_major` | Promote draft to DTA Major in gold | `save_draft` |
| **UI Branch (false):** | | |
| `create_branch` | Create branch from library template | `check_source` (false) |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_dta_create.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Create Instance | `notebooks/data_engineering/common/nb_create_dta_instance.ipynb` |
| Save Draft | `notebooks/data_engineering/common/nb_version_save_draft.ipynb` |
| Approve DTA | `notebooks/data_engineering/common/nb_version_approve_dta.ipynb` |

---

### 8. job_cdm_version_manager

**Description**

Manages Clinical Data Metadata versioning operations using SCD Type 2. Supports five mutually exclusive actions via condition task chain (only one action runs per execution).

**Actions**

| Action | Description | Use Case |
|--------|-------------|----------|
| `CREATE_BRANCH` | Create new DTA draft from library template | UI initiates new DTA |
| `SAVE_DRAFT` | Save changes to existing draft | UI saves edits |
| `APPROVE_DTA` | Promote draft to DTA Major | Workflow approval |
| `CREATE_DTA_APPROVED` | Create DTA Major directly | Single DTA via API |
| `CREATE_DTA_TEMPLATE` | Merge approved DTAs into template | Librarian promotion |

**Trigger**

| Type | Details |
|------|---------|
| API/UI | Called with `action` parameter to specify operation |
| Other Jobs | Called by `job_cdm_dta_create` for branching |

**Pipeline Flow**

![Version Manager Pipeline](./diagrams/01_job_cdm_version_manager.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_version_manager.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `check_create_branch` | Condition: Is action CREATE_BRANCH? | `setup` |
| `create_branch` | Execute CREATE_BRANCH action | `check_create_branch` (true) |
| `check_save_draft` | Condition: Is action SAVE_DRAFT? | `check_create_branch` (false) |
| `save_draft` | Execute SAVE_DRAFT action | `check_save_draft` (true) |
| `check_approve_dta` | Condition: Is action APPROVE_DTA? | `check_save_draft` (false) |
| `approve_dta` | Execute APPROVE_DTA action | `check_approve_dta` (true) |
| `check_create_major` | Condition: Is action CREATE_DTA_APPROVED? | `check_approve_dta` (false) |
| `create_dta_major` | Execute CREATE_DTA_APPROVED action | `check_create_major` (true) |
| `create_dta_template` | Execute CREATE_DTA_TEMPLATE (default) | `check_create_major` (false) |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_version_manager.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Create Branch | `notebooks/data_engineering/common/nb_version_create_branch.ipynb` |
| Save Draft | `notebooks/data_engineering/common/nb_version_save_draft.ipynb` |
| Approve DTA | `notebooks/data_engineering/common/nb_version_approve_dta.ipynb` |
| Create Template | `notebooks/data_engineering/common/nb_promote_to_template.ipynb` |

---

### 9. job_cdm_export_file

**Description**

Generic file export job for DTA metadata. Generates Excel/PDF files and uploads to Unity Catalog Volumes.

**Export Types**

| Type | Format | Status |
|------|--------|--------|
| `tsDTA` | Excel (.xlsx) | ✅ Implemented |
| `oa` | PDF | 🔜 Future |
| `dta_full` | ZIP package | 🔜 Future |

**Trigger**

| Type | Details |
|------|---------|
| API/UI | Called with `dta_id` and `export_type` parameters |

**Pipeline Flow**

![Export File Pipeline](./diagrams/01_job_cdm_export_file.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_export_file.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and validate parameters | - |
| `export_file` | Generate export file and upload to Volumes | `setup` |

**Output Path**

```
/Volumes/{catalog}/bronze_md/{source_root}/exports/{date}/{dta_number}/
```

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_export_file.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Export Notebook | `notebooks/data_engineering/clinical_data_standards/jobs/nb_export_dta_file.ipynb` |

---

### 10. job_cdm_export_genie_assets

**Description**

Generates Databricks Genie space training assets. Dynamically discovers tables, generates SQL comments, instructions, example queries, and assembles the serialized space configuration.

**Trigger**

| Type | Details |
|------|---------|
| Manual | Run via Databricks CLI or UI |

**Pipeline Flow**

![Export Genie Assets Pipeline](./diagrams/01_job_cdm_export_genie_assets.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_export_genie_assets.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and validate parameters | - |
| `export_genie_assets` | Generate SQL comments, instructions, example queries, component JSONs | `setup` |
| `generate_serialized_space` | Assemble components into `serialized_space.json` | `export_genie_assets` |

**Output Files**

```
/Volumes/{catalog}/bronze_md/{source_volume}/{source_root}/exports/genie/
├── sql/
│   ├── add_table_comments.sql
│   └── example_queries.sql
├── components/
│   ├── data_sources.json
│   ├── sample_questions.json
│   ├── text_instructions.json
│   └── example_queries.json
├── genie_instructions.txt
├── serialized_space.json
└── export_manifest.json
```

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_export_genie_assets.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Export Assets | `notebooks/data_engineering/clinical_data_standards/jobs/nb_export_genie_assets.ipynb` |
| Generate Space | `notebooks/data_engineering/clinical_data_standards/jobs/nb_generate_serialized_space.ipynb` |

---

### 11. job_populate_config_cache

**Description**

Loads configuration data into Spark cache for fast access by processing jobs. Pre-caches reference data, mappings, and configuration settings to avoid repeated Delta table reads during job execution.

**Trigger**

| Type | Details |
|------|---------|
| Called by | Other jobs via setup notebook |
| Manual | Can be run to refresh cache |

**Output/Results**

- Cached configuration data in Spark memory
- Faster job execution due to reduced I/O

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/common/jobs/job_populate_config_cache.job.yml` |

---

### 12. job_cdm_sql_setup

**Description**

SQL infrastructure setup job that creates and configures the database environment. This is actually a 3-in-1 job definition containing three separate jobs for different aspects of setup.

**Trigger**

| Type | Details |
|------|---------|
| Manual | Run during initial setup or environment provisioning |
| CI/CD | Can be automated in deployment pipelines |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog to create/setup |

**Sub-Jobs:**

1. **job_cdm_sql_setup** - Create catalog, schemas, and volumes
   - Creates Unity Catalog if not exists
   - Creates bronze_md, silver_md, gold_md schemas
   - Creates volumes for file storage

2. **job_cdm_sql_load_reference_data** - Load reference data (placeholder)
   - Loads initial reference data
   - Seeds lookup tables

3. **job_cdm_sql_load_config_data** - Load config data to cache table
   - Populates configuration cache tables
   - Loads framework settings

**Output/Results**

- Catalog and schema structure created
- Volumes provisioned
- Reference data loaded
- Configuration tables populated

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/sql/common/jobs/job_cdm_sql_setup.job.yml` |
| Setup SQL | `sql/setup_cds_catalog.sql` |
| Reference Data SQL | `sql/load_reference_data.sql` |
| Config Data SQL | `sql/load_config_data.sql` |

💡 **Best Practice**: Run this job first when setting up a new environment

---

### 13. job_cdm_app_permissions

**Description**

Creates and seeds permission tables for the Clinical Data Standards Flask application. Sets up user groups, permissions, and access control mappings for role-based security.

**Trigger**

| Type | Details |
|------|---------|
| Manual | Run after SQL setup and before app deployment |
| CI/CD | Can be automated in deployment pipelines |

**Parameters**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `catalog_override` | string | `${var.catalog}` | Target catalog |

**Created Tables:**

- `md_users` - Application users
- `md_user_groups` - User groups (JNJ_DAE, VENDOR, JNJ_LIBRARIAN)
- `md_permissions` - Permission definitions
- `md_user_group_memberships` - User to group mappings
- `md_group_permissions` - Group to permission mappings

**User Groups:**

| Group | Purpose |
|-------|---------|
| `JNJ_DAE` | J&J Data Analytics & Engineering team - full access |
| `VENDOR` | External vendor users - read/edit own DTAs |
| `JNJ_LIBRARIAN` | Librarians - template management, approval workflows |

**Prerequisites:**

- `job_cdm_sql_setup` must be run first (to create schemas)
- CDM import job should be run (to populate vendors)

**Output/Results**

- Permission tables created and seeded
- User groups configured
- Ready for Flask app user simulation

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/sql/common/jobs/job_cdm_app_permissions.job.yml` |
| Permissions SQL | `sql/setup_cdm_app_permissions.sql` |

⚠️ **Note**: Run after job_cdm_dta_import to ensure vendors exist for permission mapping

---

## Test Jobs

Test jobs are used for development and validation. They typically trigger main jobs with test-specific parameters.

### job_test_cdm_dta_import

**Purpose**: End-to-end test for the DTA import pipeline.

| Parameter | Default | Description |
|-----------|---------|-------------|
| `catalog_override` | `aira_test` | Test catalog |
| `source_root` | `test` | Uses test/uploads folder |

**Triggers**: `job_cdm_dta_import`

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/test/jobs/job_test_cdm_dta_import.job.yml` |

---

### job_test_cdm_cleanup

**Purpose**: Drop all bronze, silver, and gold tables. Delete checkpoint and ingested folders.

> ⚠️ **WARNING**: Only run in dev/test environments!

| Parameter | Default | Description |
|-----------|---------|-------------|
| `catalog_override` | `aira_test` | Catalog to clean up |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/test/jobs/job_test_cdm_cleanup.job.yml` |
| Cleanup Notebook | `notebooks/data_engineering/test/jobs/nb_cleanup_test_data.ipynb` |

---

### job_test_cdm_create_dta_template

**Purpose**: Test DTA Template creation from approved DTAs. Templates are scoped by (vendor, data_stream) combination.

| Parameter | Default | Description |
|-----------|---------|-------------|
| `library_type` | (empty) | Process all library types |
| `merge_strategy` | `UNION_DEDUP` | How to merge records |
| `data_provider_name` | (empty) | Filter by vendor |
| `data_stream_type` | (empty) | Filter by stream |

**Triggers**: `job_cdm_version_manager` with `action=CREATE_DTA_TEMPLATE`

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/test/jobs/job_test_cdm_create_dta_template.job.yml` |

---

### job_test_cdm_export_genie_assets

**Purpose**: Test Genie asset generation.

**Triggers**: `job_cdm_export_genie_assets`

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/test/jobs/job_test_cdm_export_genie_assets.job.yml` |

---

### job_test_cdm_sql_setup

**Purpose**: Test SQL catalog and schema setup.

**Triggers**: `job_cdm_sql_setup`

**Parameters**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `catalog_override` | `aira_test` | Test catalog |

**Prerequisites**:
- Clean test environment (or run `job_test_cdm_cleanup` first)

**Expected Outcomes**:
- Test catalog created
- Schemas (bronze_md, silver_md, gold_md) created
- Volumes provisioned

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/sql/test/jobs/job_test_cdm_sql_setup.job.yml` |

---

### job_test_cdm_app_permissions

**Purpose**: Test permission tables and user group setup for the CDM application.

**Triggers**: `job_cdm_app_permissions`

**Parameters**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `catalog_override` | `aira_test` | Test catalog |

**Prerequisites**:
- `job_test_cdm_sql_setup` completed (schemas exist)
- Test vendors available (or run test import first)

**Expected Outcomes**:
- Permission tables created in test catalog
- User groups seeded (JNJ_DAE, VENDOR, JNJ_LIBRARIAN)
- Sample users and permissions configured

**Typical Use Case**:
Testing Flask app authentication and authorization before production deployment

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/sql/test/jobs/job_test_cdm_app_permissions.job.yml` |

---

## Related Documentation

- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - Table schemas and data model
- [04_dta_versioning_design.readme.md](./04_dta_versioning_design.readme.md) - Version management operations
- [06_dta_workflow_design.readme.md](./06_dta_workflow_design.readme.md) - Workflow, approval chain, and governance
- [09_dta_genie_integration_design.readme.md](./09_dta_genie_integration_design.readme.md) - Genie AI integration
# Schema Design

> **Status**: Implemented  
> **Last Updated**: January 2026

---

## Overview

This document describes the database schema for the Clinical Data Standards DTA (Data Transfer Agreement) Management System. The schema follows the Medallion Architecture with Bronze, Silver, and Gold layers.

Table and column descriptions are optimized for Databricks Genie AI Assistant integration. For detailed Genie training configuration, see [09_dta_genie_integration_design.readme.md](./09_dta_genie_integration_design.readme.md).

### Schema Layers

| Layer | Schema | Purpose |
|-------|--------|---------|
| Gold | `gold_md` | Approved DTA entities, workflows, and versioned metadata library |
| Silver | `silver_md` | Normalized draft data being reviewed before approval |
| Bronze | `bronze_md` | Raw ingestion of tsDTA files, document manifest, Excel metadata |

### Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| Schema Data Flow | Data flow overview (Gold → Silver → Bronze) | [PNG](./diagrams/02_dta_schema_design_tables.drawio.png) | [Draw.io](./diagrams/02_dta_schema_design_tables.drawio) |
| Entity Relationship Diagram | Detailed ERD with columns, keys, and relationships | [PNG](./diagrams/02_dta_schema_erd.drawio.png) | [Draw.io](./diagrams/02_dta_schema_erd.drawio) |

#### Schema Data Flow
![Schema Data Flow](./diagrams/02_dta_schema_design_tables.drawio.png)

#### Entity Relationship Diagram (ERD)
![ERD Diagram](./diagrams/02_dta_schema_erd.drawio.png)

---

## Tables Summary

### Gold Layer (`gold_md`)

| Table | Purpose |
|-------|---------|
| `dta` | Core DTA entity representing a Data Transfer Agreement |
| `dta_workflow` | Workflow cycle tracking for DTA approval |
| `dta_approval_task` | Individual approval tasks within a workflow |
| `dta_activity_log` | Activity audit log for all DTA operations |
| `md_version_registry` | Central registry for all version metadata |
| `md_dta_transfer_variables` | Approved transfer variable definitions (SCD Type 2) |
| `md_dta_vendor_test_concepts` | Approved vendor test concept definitions |

### Silver Layer (`silver_md`)

| Table | Purpose |
|-------|---------|
| `md_dta_transfer_variables_draft` | Draft transfer variable definitions being reviewed |
| `md_dta_vendor_test_concepts_draft` | Draft vendor test concepts being reviewed |
| `md_codelists_normalized` | Standardized codelist values extracted from tsDTA |

### Bronze Layer (`bronze_md`)

| Table | Purpose |
|-------|---------|
| `md_file_history` | Document manifest with extraction status and completion tracking |
| `md_document_types` | Reference table for document type enablement |
| `md_dta_excel_file_raw` | Excel sheet metadata for tsDTA files |

---

## Gold Layer Tables

### 1. dta

**Purpose**: Core DTA entity representing a Data Transfer Agreement between J&J and a data provider.

| Column | Type | Description |
|--------|------|-------------|
| `dta_id` | STRING | **PK** - UUID identifier |
| `dta_number` | STRING | Human-readable ID (DTA001, DTA002) |
| `dta_name` | STRING | Descriptive name for the DTA |
| `trial_id` | STRING | Associated trial identifier |
| `data_stream_type` | STRING | Data stream type (Labs, ECG, etc.) |
| `data_provider_name` | STRING | Vendor/provider name |
| `status` | STRING | DRAFT, ACTIVE, PROMOTED, ARCHIVED (1:1 with md_version_registry.status) |
| `workflow_state` | STRING | NOT_STARTED, IN_REVIEW, APPROVED, REJECTED |
| `workflow_iteration` | INT | Current approval cycle number |
| `version` | STRING | Active version for UI display |
| `current_draft_version` | STRING | Current draft version being edited |
| `base_template_version` | STRING | Library version this DTA was branched from |
| `parent_document_id` | STRING | **FK** - Reference to source document |
| `notes` | STRING | General notes |

**Note**: `latest_major_version` was removed - now derived from `md_version_registry` via:
```sql
SELECT version FROM md_version_registry 
WHERE dta_id = :dta_id AND version_type = 'DTA_APPROVED' AND status = 'ACTIVE'
```

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/common/nb_create_dta_instance.ipynb` |

---

### 2. dta_workflow

**Purpose**: Tracks the approval lifecycle for DTAs across stakeholders (J&J DAE, Vendor, Librarian).

| Column | Type | Description |
|--------|------|-------------|
| `dta_workflow_id` | STRING | **PK** - UUID identifier |
| `dta_id` | STRING | **FK** - References dta table |
| `workflow_iteration` | INT | Iteration number (1, 2, 3...) |
| `workflow_status` | STRING | NOT_STARTED, IN_REVIEW, APPROVED, REJECTED |
| `summary_comment` | STRING | Workflow summary notes |
| `initiated_ts` | TIMESTAMP | When workflow started |
| `closed_ts` | TIMESTAMP | When workflow completed |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/common/nb_create_dta_instance.ipynb` |

---

### 3. dta_approval_task

**Purpose**: Individual approval tasks within a workflow cycle, tracking each approver's action.

| Column | Type | Description |
|--------|------|-------------|
| `approval_task_id` | STRING | **PK** - UUID identifier |
| `dta_workflow_id` | STRING | **FK** - References dta_workflow |
| `dta_id` | STRING | **FK** - References dta table |
| `approver_role` | STRING | Role: jnj_dae, vendor, librarian |
| `assigned_to_principal` | STRING | Assigned approver email |
| `approval_order` | INT | Order in approval chain (1, 2, 3) |
| `approval_status` | STRING | PENDING, APPROVED, REJECTED, SKIPPED |
| `approval_comment` | STRING | Approver's comment |
| `approved_ts` | TIMESTAMP | When approved/rejected |
| `is_auto_approve` | BOOLEAN | Whether auto-approved |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/common/nb_create_dta_instance.ipynb` |

---

### 4. dta_activity_log

**Purpose**: Captures the full audit history of all activities performed on DTAs and related metadata entities.

| Column | Type | Description |
|--------|------|-------------|
| `activity_id` | STRING | **PK** - UUID identifier |
| `dta_id` | STRING | **FK** - References dta table |
| `entity_id` | STRING | ID of affected entity |
| `entity_name` | STRING | Name of entity (transfer_variables, test_concepts, etc.) |
| `activity_type` | STRING | CREATE, UPDATE, DELETE, APPROVE, REJECT |
| `activity_category` | STRING | Category grouping |
| `activity_summary` | STRING | Human-readable summary |
| `field_name` | STRING | Changed field name |
| `old_value` | STRING | Previous value |
| `new_value` | STRING | New value |
| `version_tag` | STRING | Version when change occurred |
| `parent_version` | STRING | Parent version reference |
| `workflow_iteration` | INT | Workflow cycle number |
| `library_type` | STRING | Library type affected |
| `approver_name` | STRING | Approver who made change |
| `approver_role` | STRING | Approver's role |
| `comment` | STRING | Activity comment |
| `performed_by_principal` | STRING | User who performed action |
| `performed_ts` | TIMESTAMP | When action was performed |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | Activity logging functions in `utils.py` |

---

### 5. md_version_registry

**Purpose**: Central registry for all version metadata, supporting SCD Type 2 lifecycle management.

**Status Alignment**: The `status` column aligns 1:1 with `dta.status`:
- **DRAFT**: Being edited (effective_end_ts = NULL)
- **ACTIVE**: Approved and in use (effective_end_ts = NULL)
- **PROMOTED**: Elevated to template (effective_end_ts = NULL)
- **ARCHIVED**: No longer active (effective_end_ts = timestamp when archived)

| Column | Type | Description |
|--------|------|-------------|
| `version` | STRING | **PK** - Unique version identifier |
| `library_type` | STRING | transfer_variables, test_concepts, codelists |
| `version_type` | STRING | DTA_TEMPLATE, DTA_APPROVED, DTA_DRAFT |
| `dta_id` | STRING | **FK** - Associated DTA (NULL for library templates) |
| `parent_version` | STRING | Version branched from |
| `record_count` | INT | Number of records in version |
| `status` | STRING | DRAFT, ACTIVE, PROMOTED, ARCHIVED (1:1 with dta.status) |
| `effective_end_ts` | TIMESTAMP | NULL unless ARCHIVED, then timestamp when archived |
| `data_provider_name` | STRING | Vendor name (for template scope) |
| `data_stream_type` | STRING | Data stream type (for template scope) |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | Versioning notebooks in `notebooks/data_engineering/common/` |

---

### 6. md_dta_transfer_variables

**Purpose**: SCD Type 2 versioned library of approved transfer variable definitions.

| Column | Type | Description |
|--------|------|-------------|
| `definition_hash` | STRING | **PK** - Unique definition hash |
| `version` | STRING | **PK** - Version tag |
| `dta_id` | STRING | **FK** - Associated DTA |
| `transfer_variable_name` | STRING | Variable name |
| `transfer_variable_label` | STRING | Variable label |
| `transfer_variable_order` | INT | Order in transfer file |
| `variable_description` | STRING | Detailed description |
| `format` | STRING | Data type |
| `anticipated_max_length` | INT | Maximum length |
| `transfer_file_key` | BOOLEAN | Part of unique key |
| `populate_for_all_records` | BOOLEAN | Required for all records |
| `example_values` | STRING | Sample values |
| `codelist_values` | STRING | Associated codelists (JSON) |
| `vendor_comment` | STRING | Vendor-provided comment |
| `domain_info` | STRING | Domain information |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `status` | STRING | COMPLETED, MANUAL_REVIEW_REQUIRED |
| `parent_version` | STRING | Version branched from |
| `is_major_version` | BOOLEAN | TRUE for DTA Template versions |
| `is_dta_major` | BOOLEAN | TRUE for DTA Approved versions |
| `is_current` | BOOLEAN | Active version flag |
| `effective_start_ts` | TIMESTAMP | When version became active |
| `effective_end_ts` | TIMESTAMP | When superseded (NULL if current) |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/common/nb_version_approve_dta.ipynb` |

---

### 7. md_dta_vendor_test_concepts

**Purpose**: Approved vendor test concept definitions with SCD Type 2 versioning.

| Column | Type | Description |
|--------|------|-------------|
| `definition_hash` | STRING | **PK** - Unique definition hash |
| `version` | STRING | **PK** - Version tag |
| `dta_id` | STRING | **FK** - Associated DTA |
| `test_concept_reference` | STRING | Test concept identifier |
| `variable_description` | STRING | Description of the test concept |
| `transfer_tuple_map` | MAP<STRING, STRING> | Dynamic mapping of transfer variables |
| `codelist_values` | STRING | Associated codelists (JSON) |
| `vendor_comment` | STRING | Vendor-provided comment |
| `domain_info` | STRING | Domain information |
| `notes` | STRING | Additional notes |
| `status` | STRING | COMPLETED, MANUAL_REVIEW_REQUIRED |
| `parent_version` | STRING | Version branched from |
| `is_major_version` | BOOLEAN | TRUE for DTA Template versions |
| `is_dta_major` | BOOLEAN | TRUE for DTA Approved versions |
| `is_current` | BOOLEAN | Active version flag |
| `effective_start_ts` | TIMESTAMP | When version became active |
| `effective_end_ts` | TIMESTAMP | When superseded (NULL if current) |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/common/nb_version_approve_dta.ipynb` |

---

## Silver Layer Tables

### 1. md_dta_transfer_variables_draft

**Purpose**: Draft transfer variable definitions being reviewed before approval.

| Column | Type | Description |
|--------|------|-------------|
| `transfer_variable_field_id` | STRING | **PK** - Unique record ID |
| `parent_document_id` | STRING | **FK** - References source document |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `transfer_variable_name` | STRING | Variable name |
| `transfer_variable_label` | STRING | Variable label |
| `transfer_variable_order` | INT | Order in transfer file |
| `variable_description` | STRING | Detailed description |
| `format` | STRING | Data type (text, numeric, date) |
| `anticipated_max_length` | INT | Maximum field length |
| `transfer_file_key` | BOOLEAN | Part of unique key |
| `populate_for_all_records` | BOOLEAN | Required for all records |
| `example_values` | STRING | Sample values |
| `codelist_values` | STRING | Associated codelist values |
| `vendor_comment` | STRING | Vendor-provided comment |
| `domain_info` | STRING | Domain information |
| `definition_hash` | STRING | Hash for deduplication |
| `status` | STRING | COMPLETED or MANUAL_REVIEW_REQUIRED |
| `notes` | STRING | Processing notes |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_transfer_variables_processor.ipynb` |

---

### 2. md_dta_vendor_test_concepts_draft

**Purpose**: Draft vendor test concepts being reviewed before approval.

| Column | Type | Description |
|--------|------|-------------|
| `test_concept_id` | STRING | **PK** - Unique record ID |
| `parent_document_id` | STRING | **FK** - References source document |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `test_concept_reference` | STRING | Test concept identifier |
| `variable_description` | STRING | Description |
| `transfer_tuple_map` | MAP<STRING, STRING> | Dynamic mapping of transfer variables |
| `codelist_values` | STRING | Associated codelists |
| `vendor_comment` | STRING | Vendor-provided comment |
| `domain_info` | STRING | Domain information |
| `notes` | STRING | Additional notes |
| `definition_hash` | STRING | Hash for deduplication |
| `status` | STRING | COMPLETED or MANUAL_REVIEW_REQUIRED |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_test_concepts_processor.ipynb` |

---

### 3. md_codelists_normalized

**Purpose**: Standardized codelist values extracted from tsDTA files.

| Column | Type | Description |
|--------|------|-------------|
| `codelist_id` | STRING | **PK** - Unique codelist record ID |
| `parent_document_id` | STRING | **FK** - References source document |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `transfer_variable_name` | STRING | Associated variable |
| `codelist_reference` | STRING | Codelist identifier |
| `code_value` | STRING | Individual code value |
| `status` | STRING | Processing status |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_code_lists_processor.ipynb` |

---

## Bronze Layer Tables

### 1. md_file_history

**Purpose**: Document manifest with extraction status and completion tracking.

| Column | Type | Description |
|--------|------|-------------|
| `document_id` | STRING | **PK** - Unique document identifier |
| `parent_document_id` | STRING | **FK** - Self-reference for parent ZIP |
| `zip_source_path` | STRING | Original ZIP file path |
| `extracted_path` | STRING | Extraction location |
| `content_base64` | STRING | Base64 encoded file content |
| `size_bytes` | LONG | File size |
| `file_extension` | STRING | File type extension |
| `document_tags` | ARRAY<STRING> | Classification tags (tsDTA, DTA, etc.) |
| `active` | BOOLEAN | Whether document is active |
| `status` | STRING | Processing status |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `total_documents_count` | INT | Total files in ZIP |
| `required_documents_count` | INT | Files requiring processing |
| `processed_documents_count` | INT | Processed file count |
| `is_enabled` | BOOLEAN | Whether document type is enabled |
| `source` | STRING | Document source: HISTORICAL or UI |
| `status_timestamp` | TIMESTAMP | When status changed |
| `error_message` | STRING | Error details if failed |
| `processing_duration_seconds` | DOUBLE | Processing time |
| `retry_count` | INT | Number of retry attempts |
| `processing_metadata` | STRING | JSON with processing details |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/clinical_data_standards/jobs/nb_file_processor.ipynb` |

---

### 2. md_document_types

**Purpose**: Reference table that controls which document types are enabled for processing.

| Column | Type | Description |
|--------|------|-------------|
| `document_type` | STRING | **PK** - Document type (tsDTA, Protocol, etc.) |
| `document_type_label` | STRING | Display name for UI |
| `is_enabled` | BOOLEAN | Whether this type should be processed |
| `description` | STRING | Documentation |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `sql/load_reference_data.sql` |

---

### 3. md_dta_excel_file_raw

**Purpose**: Excel sheet metadata for tsDTA files.

| Column | Type | Description |
|--------|------|-------------|
| `document_id` | STRING | **PK** - Unique sheet identifier |
| `parent_document_id` | STRING | **FK** - References parent Excel file |
| `sheet_name` | STRING | Excel sheet name |
| `sheet_index` | INT | Sheet position (0-based) |
| `sheet_category` | STRING | Categorized type (transfer_metadata, codelists, etc.) |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/clinical_data_standards/jobs/nb_extract_excel_sheets.ipynb` |

---

## Key Design Patterns

### 1. Parent-Child Document Linking

`parent_document_id` links child documents to parent ZIPs, enabling tracking of document lineage through extraction.

```
ZIP File (parent_document_id = NULL)
├── Excel File 1 (parent_document_id = ZIP.document_id)
│   ├── Sheet 1 (parent_document_id = Excel.document_id)
│   └── Sheet 2 (parent_document_id = Excel.document_id)
└── Excel File 2 (parent_document_id = ZIP.document_id)
```

### 2. Trial Context Propagation

`trial_id`, `data_stream_type`, and `data_provider_name` propagate through all layers, enabling filtering and grouping by trial context.

### 3. SCD Type 2 Versioning

Used in `md_dta_transfer_variables` and `md_dta_vendor_test_concepts`:

| Column | Purpose |
|--------|---------|
| `effective_start_ts` | When version became active |
| `effective_end_ts` | When superseded (NULL if current) |
| `is_current` | Active version flag |
| `version` + `definition_hash` | Composite primary key |

### 4. Audit Columns

All tables include standard audit columns:

| Column | Type | Description |
|--------|------|-------------|
| `created_by_principal` | STRING | User who created the record |
| `created_ts` | TIMESTAMP | Record creation timestamp |
| `last_updated_by_principal` | STRING | User who last updated |
| `last_updated_ts` | TIMESTAMP | Last update timestamp |
| `databricks_job_id` | STRING | Job ID for lineage |
| `databricks_job_name` | STRING | Job name for lineage |
| `databricks_run_id` | STRING | Run ID for lineage |

---

## Related Documentation

- [01_dta_job_architecture_design.readme.md](./01_dta_job_architecture_design.readme.md) - Job definitions and pipelines
- [04_dta_versioning_design.readme.md](./04_dta_versioning_design.readme.md) - Version management operations
- [06_dta_workflow_design.readme.md](./06_dta_workflow_design.readme.md) - Workflow, approval chain, and governance
- [09_dta_genie_integration_design.readme.md](./09_dta_genie_integration_design.readme.md) - Genie AI integration and training
# Status Lifecycle Design

> **Status**: Implemented  
> **Last Updated**: January 2026

---

## Overview

This document describes the status values used throughout the Clinical Data Standards pipeline to track document processing and DTA lifecycle management.

### Purpose

Status tracking serves two key purposes:

1. **Document Processing** - Track the lifecycle of files from extraction through processing to DTA creation
2. **DTA Management** - Track the lifecycle of Data Transfer Agreements from draft through approval

### Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| Document Processing Lifecycle | Status flow for file processing | [PNG](./diagrams/03_dta_document_processing_lifecycle.drawio.png) | [Draw.io](./diagrams/03_dta_document_processing_lifecycle.drawio) |
| DTA Status Lifecycle | Status flow for DTA entities | [PNG](./diagrams/03_dta_status_lifecycle.drawio.png) | [Draw.io](./diagrams/03_dta_status_lifecycle.drawio) |

---

## Document Statuses

The `md_file_history` table in the Bronze layer tracks document processing status.

### Status Values

| Status | Description | Next Status |
|--------|-------------|-------------|
| `READY_FOR_PROCESSING` | File extracted, awaiting processing | TSDTA_PROCESSING, DOC_PROCESSING |
| `TSDTA_PROCESSING` | Excel sheets being extracted | EXCEL_EXTRACTION_COMPLETED, TSDTA_FAILED |
| `EXCEL_EXTRACTION_COMPLETED` | Sheets extracted successfully | READY_FOR_VERSIONING |
| `TSDTA_FAILED` | Excel processing failed | Manual intervention required |
| `DOC_PROCESSING` | PDF/Word being processed | DOC_COMPLETED, DOC_FAILED |
| `DOC_COMPLETED` | Document processed successfully | READY_FOR_VERSIONING |
| `DOC_FAILED` | Document processing failed | Manual intervention required |
| `READY_FOR_VERSIONING` | All processing complete | VERSIONING_IN_PROCESS |
| `VERSIONING_IN_PROCESS` | DTA creation in progress | VERSIONED, VERSIONING_FAILED |
| `VERSIONED` | DTA created successfully | Terminal state |
| `VERSIONING_FAILED` | DTA creation failed | Manual intervention required |
| `EXTRACTION_ERROR` | File extraction failed | Manual intervention required |

### Document Processing Lifecycle

![Document Processing Lifecycle](./diagrams/03_dta_document_processing_lifecycle.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/03_dta_document_processing_lifecycle.drawio)

### Status Tracking Columns

The `md_file_history` table includes additional columns for status tracking:

| Column | Purpose |
|--------|---------|
| `status` | Current processing status |
| `status_timestamp` | When status was last updated |
| `error_message` | Error details if status is a failure state |
| `processing_duration_seconds` | Time taken for processing |
| `retry_count` | Number of retry attempts |

---

## DTA and Metadata Statuses

### Status Alignment

The `dta.status` and `md_version_registry.status` columns are aligned 1:1, enabling simplified joins and consistent state management:

| Status | Description | effective_end_ts | Editable? |
|--------|-------------|------------------|-----------|
| `DRAFT` | DTA being created or edited | NULL | Yes |
| `ACTIVE` | Approved and in use | NULL | No |
| `PROMOTED` | Elevated to template | NULL | No |
| `ARCHIVED` | No longer active | Timestamp when archived | No |

### DTA Entity Status

The `dta` table in the Gold layer tracks DTA lifecycle status. The simplified join pattern uses `d.status = vr.status` instead of filtering by specific version types.

#### Status Values

| Status | Description | Transition From | Transition To |
|--------|-------------|-----------------|---------------|
| `DRAFT` | DTA being created or edited | (initial), REJECTED | ACTIVE |
| `ACTIVE` | Approved and in use | DRAFT (via approval) | PROMOTED, ARCHIVED |
| `PROMOTED` | Elevated to template | ACTIVE | ARCHIVED |
| `ARCHIVED` | No longer active | DRAFT, ACTIVE, PROMOTED | (terminal) |

**Note**: Workflow states (NOT_STARTED, IN_REVIEW, APPROVED, REJECTED) are tracked separately in `workflow_state` column.

#### DTA Status Lifecycle

![DTA Status Lifecycle](./diagrams/03_dta_status_lifecycle.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/03_dta_status_lifecycle.drawio)

### Silver Layer Validation Status

Records in the Silver layer (`md_dta_transfer_variables_draft`, `md_codelists_normalized`) have a `status` column indicating validation results.

| Status | Description |
|--------|-------------|
| `COMPLETED` | All required fields present and valid |
| `MANUAL_REVIEW_REQUIRED` | Missing or invalid fields needing review |

### Status Propagation (Silver → Gold)

When a DTA is created from Silver layer records:

- If **all records** have `status = COMPLETED` → DTA status is `ACTIVE`
- If **any record** has `status = MANUAL_REVIEW_REQUIRED` → DTA status starts as `DRAFT` for review

The corresponding `md_version_registry` entries are created with matching status (1:1 alignment).

### Version Registry Status

The `md_version_registry` table tracks version status aligned with `dta.status`:

| Status | effective_end_ts | Description |
|--------|------------------|-------------|
| `DRAFT` | NULL | Version being edited |
| `ACTIVE` | NULL | Approved version in use |
| `PROMOTED` | NULL | Elevated to template version |
| `ARCHIVED` | Timestamp | Previous version, no longer active |

**Note**: `effective_end_ts` is only set when status = `ARCHIVED`. This enables efficient queries without needing an `is_current` flag.

---

## Related Documentation

- [01_dta_job_architecture_design.readme.md](./01_dta_job_architecture_design.readme.md) - Processing pipeline and job definitions
- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - Full table schema documentation
- [04_dta_versioning_design.readme.md](./04_dta_versioning_design.readme.md) - Version registry and SCD Type 2
- [06_dta_workflow_design.readme.md](./06_dta_workflow_design.readme.md) - Workflow, approval chain, and governance
# Version Manager - SCD Type 2 Versioning System

> **Related Documentation:**
> - [06_dta_workflow_design.readme.md](./06_dta_workflow_design.readme.md) - Workflow, approval chain, and governance

### Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| Template Scoping | Vendor+Stream scope organization | [PNG](./diagrams/04_dta_template_scoping.drawio.png) | [Draw.io](./diagrams/04_dta_template_scoping.drawio) |
| Creating DTA Templates | Input DTAs → Merge → Output templates | [PNG](./diagrams/04_dta_creating_dta_templates.drawio.png) | [Draw.io](./diagrams/04_dta_creating_dta_templates.drawio) |
| Incremental Template Updates | Existing template + new DTA → v2.0 | [PNG](./diagrams/04_dta_incremental_template_updates.drawio.png) | [Draw.io](./diagrams/04_dta_incremental_template_updates.drawio) |
| Basic Flow - Branch from Template | Full lifecycle state transitions | [PNG](./diagrams/04_dta_basic_flow_branch.drawio.png) | [Draw.io](./diagrams/04_dta_basic_flow_branch.drawio) |
| Multi-Vendor Template Creation | Grouping DTAs by vendor+stream | [PNG](./diagrams/04_dta_multi_vendor_template.drawio.png) | [Draw.io](./diagrams/04_dta_multi_vendor_template.drawio) |
| Parallel DTA Development | Multiple DTAs working simultaneously | [PNG](./diagrams/04_dta_parallel_dta_development.drawio.png) | [Draw.io](./diagrams/04_dta_parallel_dta_development.drawio) |

## Overview

The Clinical Data Standards platform uses **SCD Type 2 (Slowly Changing Dimension)** versioning to track all changes to transfer variable definitions. This enables:

- **Full audit trail** of every change
- **Parallel DTA development** without collisions
- **Point-in-time queries** for any historical version
- **Approval workflows** with version promotion
- **Vendor+Stream scoped templates** for reusable standards

---

## 📊 Version Types

The system supports three distinct version types:

### 1. **DTA Template** (Canonical Standard per Vendor+Stream)
- **Format**: `1.0`, `2.0`, `3.0`, etc.
- **Purpose**: The canonical, production-ready standard **scoped by vendor and data stream**
- **Characteristics**:
  - `version_type = 'DTA_TEMPLATE'`
  - Each (vendor, data_stream) combination has its own version sequence
  - New DTAs can branch from any DTA Template version
- **Example**: `version = "1.0"` for Vendor_A / EDC_Data
- **Creation**: Requires **Librarian role** approval; merges multiple approved DTAs from the same vendor+stream

### 2. **DTA Draft Version** (Work in Progress)
- **Format**: `{template}-{dta_number}-draft{n}`
- **Example**: `1.0-DTA001-draft1`, `1.0-DTA001-draft2`
- **Purpose**: Editable working copies for a specific DTA
- **Characteristics**:
  - `version_type = 'DTA_DRAFT'`
  - Can have multiple sequential drafts (draft1, draft2, draft3...)
- **Lifecycle**: Created → Edited → Superseded → Closed

### 3. **DTA Approved Version** (Approved DTA)
- **Format**: `{template}-{dta_number}-v{n}.0`
- **Example**: `1.0-DTA001-v1.0`, `1.0-DTA001-v2.0`
- **Purpose**: Approved, finalized version for a specific DTA
- **Characteristics**:
  - `version_type = 'DTA_APPROVED'`
  - Created when workflow approval completes
  - **Can be used as a source for new DTA branches** (reuse approved definitions)
- **Lifecycle**: Approved draft becomes DTA Approved

---

## 🔄 Version Manager Operations

The `job_cdm_version_manager` supports five mutually exclusive operations using `condition_task` chain for true if-else branching:

### 1. `CREATE_BRANCH` - Start New DTA

**Trigger**: UI initiates new DTA creation

**Source Options** (user chooses one):
- **DTA Template** (e.g., `1.0`, `2.0`) - Start from canonical standard for a vendor+stream
- **DTA Approved Version** (e.g., `1.0-DTA001-v1.0`) - Reuse another DTA's approved definitions

**What it does**:
1. User selects source version (DTA Template or DTA Approved)
2. Copies all records from selected source
3. Creates new draft version (e.g., `1.0-DTA002-draft1`)
4. Registers version in `md_version_registry` with `parent_version` reference

**SCD Type 2**:
- Source records: Unchanged
- New draft records: `is_current = TRUE`, `effective_end_ts = NULL`

**Example 1: Branch from DTA Template**

`Template v1.0 (Vendor_A/EDC)` → **COPY** → `1.0-DTA001-draft1` *(parent_version = "1.0")*

**Example 2: Branch from DTA Approved** (reuse approved DTA)

`1.0-DTA001-v1.0` → **COPY** → `1.0-DTA002-draft1` *(parent_version = "1.0-DTA001-v1.0")*

**Use Cases for DTA Approved branching**:
- Similar trial needs same variable definitions
- Reuse vendor-specific customizations
- Start from a known-good configuration

---

### 2. `SAVE_DRAFT` - Save Changes

**Trigger**: User saves edits in the UI

**What it does**:
1. Closes current draft (set `is_current = FALSE`, `effective_end_ts = NOW()`)
2. Creates new draft with changes (e.g., `1.0-DTA001-draft2`)
3. Updates registry: old draft → `SUPERSEDED`, new draft → `ACTIVE`

**SCD Type 2**:
- Old draft: `is_current = FALSE`, `effective_end_ts = NOW()`
- New draft: `is_current = TRUE`, `effective_start_ts = NOW()`

`1.0-DTA001-draft1` → **SCD2 CLOSE** → `1.0-DTA001-draft2`
- Old: `is_current=FALSE`, `effective_end_ts` set
- New: `is_current=TRUE`, new records

**Note**: If a field value changes (e.g., `max_length: 20 → 50`), a new `definition_hash` is generated.

---

### 3. `APPROVE_DTA` - Promote Draft to DTA Approved

**Trigger**: Workflow approval completes (all approvers in `DTA_APPROVAL_TASK` approve)

**What it does**:
1. Closes current draft
2. Creates DTA Approved version (e.g., `1.0-DTA001-v1.0`)
3. Sets `version_type = 'DTA_APPROVED'`
4. Updates DTA entity with `version`

**SCD Type 2**:
- Draft: `is_current = FALSE`, `effective_end_ts = NOW()`
- DTA Approved: `is_current = TRUE`, `version_type = 'DTA_APPROVED'`

`1.0-DTA001-draft2` → **APPROVE** → `1.0-DTA001-v1.0` *(DTA Approved)*

---

### 4. `CREATE_DTA_APPROVED` - Direct DTA Approved Creation

**Trigger**: Historical data import or API call

**What it does**:
1. Creates DTA Approved directly from silver data (skips draft phase)
2. Used for historical DTAs that are already approved
3. Registers version with `version_type = DTA_APPROVED`

**Use Case**: Processing historical tsDTA files that represent already-executed DTAs.

`Silver Data` → **DIRECT CREATE** → `1.0-DTA001-v1.0` *(DTA Approved)*

---

### 5. `CREATE_DTA_TEMPLATE` - Create Vendor+Stream Scoped Templates

**Trigger**: Librarian role initiates template creation after review

**Authorization**: Requires **Librarian role** approval

**Key Behavior**: Templates are **scoped by (vendor, data_stream)** combination. Each vendor+stream pair has its own independent template version sequence.

**What it does**:
1. Groups all approved DTAs by `(data_provider_name, data_stream_type)`
2. For each group:
   - Finds the current DTA Template for that vendor+stream (if exists)
   - Identifies new approved DTAs not yet included in any template
   - Merges new DTAs with existing template records
   - Creates a new DTA_TEMPLATE version (e.g., "1.0" for first, "2.0" for next)
3. Closes previous template for that vendor+stream using SCD Type 2
4. Updates DTA `status` to `PROMOTED` for all merged DTAs
5. Tracks which DTAs were included in each template (`included_dta_ids`)

**SCD Type 2**:
- Old Template: `is_current = FALSE`, `effective_end_ts = NOW()`
- New Template: `is_current = TRUE`, `version_type = 'DTA_TEMPLATE'`

---

## 🔧 Data Change Operations (Inserts, Updates, Deletes)

The platform handles three types of data modifications during DTA editing: **inserts** (new items), **updates** (modified items), and **deletes** (removed items). All changes follow the SCD Type 2 versioning pattern and are tracked through the draft → approval → gold promotion lifecycle.

### Change Detection and Tracking

#### Draft Mode (Silver Tables)
When editing a DTA in **draft mode**, changes are stored in silver tables (e.g., `md_dta_transfer_variables_draft`):

| Operation | Detection Method | Silver Table Behavior | Activity Log |
|-----------|-----------------|----------------------|--------------|
| **INSERT** | `_transfer_variable_id` starts with `"new_"` | New record with `row_status='ACTIVE'`, `version_status='DRAFT'` | "Added transfer_variables: Variable Name" |
| **UPDATE** | Field-by-field comparison with DB values | `UPDATE` existing record if values changed | "Modified transfer_variables: Variable Name (2 fields changed)" |
| **DELETE** | `_marked_for_deletion = True` in workspace | `DELETE FROM silver_table WHERE id = 'xxx'` | "Deleted transfer_variables: Variable Name" |

**Key Points:**
- Changes are **immediately persisted** to silver tables on "Save as Draft"
- Dirty checking compares workspace values with DB values to detect actual changes
- Only modified fields trigger activity log entries
- Deletions are **hard deletes** from silver tables (record removed completely)

#### Example: Save Draft Process
```python
# Step 1: Detect inserts
for tv in transfer_variables:
    if tv.get('_transfer_variable_id', '').startswith('new_'):
        # INSERT new record
        INSERT INTO silver_table VALUES (...)
        activity_log.append("Added transfer_variables: {tv.LABEL}")

# Step 2: Detect updates
for tv in transfer_variables:
    if tv_id exists in DB:
        db_values = fetch_from_db(tv_id)
        changed_fields = compare_values(tv, db_values)
        if changed_fields:
            UPDATE silver_table SET ... WHERE id = tv_id
            activity_log.append(f"Modified: {len(changed_fields)} fields")

# Step 3: Process deletions
for tv in transfer_variables:
    if tv.get('_marked_for_deletion'):
        DELETE FROM silver_table WHERE id = tv_id
        activity_log.append("Deleted transfer_variables: {tv.LABEL}")
```

---

### Approval and Gold Promotion

When a DTA is **approved** and promoted to gold (via `nb_version_approve_dta`), the system handles all three change types using the SCD Type 2 pattern:

#### Step 1: Mark Previous Versions as Not Current
**Before** copying new records, all previous versions for this DTA are marked as historical:

```sql
UPDATE md_dta_transfer_variables
SET is_current = false,
    effective_end_ts = current_timestamp()
WHERE dta_id = '{dta_id}'
  AND is_current = true
```

**This critical step ensures:**
- ✅ **Updates** are reflected (new version replaces old)
- ✅ **Deletions** are reflected (deleted items not in new version stay marked as `is_current = false`)
- ✅ Historical records are preserved for audit trail

#### Step 2: Copy Approved Records from Silver to Gold
Only records present in the approved silver draft are copied to gold:

```sql
-- Read approved records from silver
SELECT * FROM silver_table 
WHERE dta_id = '{dta_id}' 
  AND version_status = 'APPROVED'

-- Copy to gold with versioning metadata
INSERT INTO gold_table
SELECT 
    *,  -- All columns from silver
    '{major_version}' as version,
    true as is_current,
    true as is_major_version,
    current_timestamp() as effective_start_ts,
    NULL as effective_end_ts
FROM approved_records
```

#### Impact on Each Change Type

| Change Type | Silver State | Gold Result | `is_current` Behavior |
|-------------|--------------|-------------|----------------------|
| **INSERT** (new item) | New record in silver | New record in gold with `is_current = true` | Item becomes current |
| **UPDATE** (modified item) | Updated record in silver | New version in gold with `is_current = true` | Previous version gets `is_current = false` |
| **DELETE** (removed item) | Absent from silver | No new record in gold | Previous version gets `is_current = false` (marked in Step 1) |

**Key Insight:** Deletions work because Step 1 marks ALL previous items as not current, and Step 2 only re-marks items that are still present as current. Deleted items remain historical with `is_current = false`.

---

### Querying Data After Changes

#### Get Current Active Items (Post-Approval)
```sql
SELECT * 
FROM md_dta_transfer_variables
WHERE dta_id = 'DTA123'
  AND is_current = true  -- Only items in latest approved version
  AND row_status = 'ACTIVE'
```

**Result:** Only items that exist in the latest version. Deleted items are filtered out.

#### Get Historical Version (Before Deletion)
```sql
SELECT * 
FROM md_dta_transfer_variables
WHERE dta_id = 'DTA123'
  AND version = '1.0-DTA001-v1.0'  -- Specific historical version
  AND row_status = 'ACTIVE'
```

**Result:** Shows all items as they existed in that version, including items that were later deleted.

#### Audit Trail for a Deleted Item
```sql
SELECT 
    transfer_variable_id,
    LABEL,
    version,
    is_current,
    effective_start_ts,
    effective_end_ts
FROM md_dta_transfer_variables
WHERE transfer_variable_id = 'TV-ABC123'
ORDER BY effective_start_ts DESC
```

**Result:**
| version | is_current | effective_start_ts | effective_end_ts | Status |
|---------|------------|-------------------|------------------|---------|
| 1.0-DTA001-v2.0 | false | 2025-01-20 | 2025-01-27 | Existed in v2.0, deleted in v3.0 |
| 1.0-DTA001-v1.0 | false | 2025-01-15 | 2025-01-20 | Original version |

---

### Change Validation and Error Handling

#### Draft Mode Validations
- **Unique identifiers**: `transfer_variable_id` must be unique within a DTA
- **Required fields**: LABEL, FORMAT cannot be null
- **Definition hash**: Computed on save to detect duplicates across DTAs

#### Approval Mode Validations
- **Completeness check**: All required library types must have records
- **Consistency check**: Related tables (e.g., OA attributes, options) must reference valid parents
- **Version conflict**: Cannot approve if another user has modified the same DTA

#### Error Recovery
- **Failed approval**: Silver records remain with `version_status = 'DRAFT'`, can be re-submitted
- **Failed gold promotion**: Transaction rollback ensures no partial data
- **Activity log**: All operations logged for troubleshooting and audit

---

### Related Tables and Cascading Changes

For complex entities like Operational Agreements (OA), changes cascade to related tables:

| Main Table | Related Tables | Change Behavior |
|------------|----------------|-----------------|
| `md_dta_operational_agreement` | `md_dta_oa_attributes`<br>`md_dta_oa_options`<br>`md_dta_oa_other` | All related records inherit `dta_id` and `operational_agreement_id`<br>Deletion of main record cascades to related tables |

**Example: Deleting an OA**
```python
# User deletes OA in UI
ws['operational_agreements'][idx]['_marked_for_deletion'] = True

# On save, cascade delete
DELETE FROM md_dta_operational_agreement_draft WHERE oa_id = 'OA123'
DELETE FROM md_dta_oa_attributes_draft WHERE operational_agreement_id = 'OA123'
DELETE FROM md_dta_oa_options_draft WHERE operational_agreement_id = 'OA123'
DELETE FROM md_dta_oa_other_draft WHERE operational_agreement_id = 'OA123'
```

---

### Activity Logging for Changes

All changes are logged to `dta_activity_log` with specific activity types:

| Activity Type | Triggered By | Summary Format | Details |
|--------------|-------------|----------------|---------|
| `ITEM_ADDED` | Insert operation | "Added transfer_variables: Variable Name" | Field values at creation |
| `ITEM_MODIFIED` | Update operation | "Modified transfer_variables: Variable Name" | List of changed fields and old→new values |
| `ITEM_DELETED` | Delete operation | "Deleted transfer_variables: Variable Name" | Entity ID and name for reference |
| `DRAFT_SAVED` | Save as Draft | "Draft saved. 2 transfer variable(s) updated, 1 deleted" | Summary of all changes |
| `DTA_APPROVED_CREATED` | Approval completion | "DTA promoted to v1.0" | Version and record counts |

**Activity Log Query:**
```sql
SELECT 
    activity_ts,
    activity_type,
    summary,
    performed_by_principal
FROM dta_activity_log
WHERE dta_id = 'DTA123'
ORDER BY activity_ts DESC
```

---

### Best Practices

1. **Always compare before updating**: Use dirty checking to avoid unnecessary UPDATE statements and activity log noise
2. **Soft delete in UI, hard delete in DB**: Mark items for deletion in workspace (`_marked_for_deletion`), execute DELETE on save
3. **Cascade deletes for related data**: Ensure related table records are removed when parent is deleted
4. **Log all changes**: Every insert, update, delete should generate an activity log entry
5. **Version everything**: Even deletions preserve history via `is_current = false`
6. **Test approval flow**: Verify deletions are properly reflected in gold tables after approval

---

## 📚 DTA Template Creation - Vendor+Stream Scoped

This section provides detailed information about how DTA Templates are created using **vendor+stream scoping** and **incremental merging**.

### Template Scoping

**Key Concept**: Each `(data_provider_name, data_stream_type)` combination has its own independent template version sequence.

![Template Scoping](./diagrams/04_dta_template_scoping.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/04_dta_template_scoping.drawio)

**Benefits of Vendor+Stream Scoping**:
- ✅ Templates are tailored to specific vendor conventions
- ✅ Different data streams have independent standards
- ✅ No collision between vendors
- ✅ Incremental improvement per vendor+stream

### Example: Creating DTA Templates

**Scenario**: Three DTAs are approved:
- DTA001: Vendor_A / EDC_Data (85 records)
- DTA002: Vendor_A / EDC_Data (10 new records)
- DTA003: Vendor_B / Lab_Data (50 records)

**Result after `CREATE_DTA_TEMPLATE`**:

```
Created Templates:
┌─────────────────────────────────────────────────────────────┐
│ Vendor_A / EDC_Data                                         │
│   Template v1.0: 95 records (85 + 10, minus duplicates)     │
│   Included DTAs: [DTA001, DTA002]                           │
├─────────────────────────────────────────────────────────────┤
│ Vendor_B / Lab_Data                                         │
│   Template v1.0: 50 records                                 │
│   Included DTAs: [DTA003]                                   │
└─────────────────────────────────────────────────────────────┘

DTA Status Updates:
  - DTA001: APPROVED → PROMOTED
  - DTA002: APPROVED → PROMOTED  
  - DTA003: APPROVED → PROMOTED
```

![Creating DTA Templates](./diagrams/04_dta_creating_dta_templates.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/04_dta_creating_dta_templates.drawio)

### Incremental Template Updates

**Scenario**: Template v1.0 exists for Vendor_A/EDC_Data. DTA004 (same vendor+stream) is approved.

```
Before:
- Template v1.0: 95 records (from DTA001, DTA002)
- DTA001, DTA002: status = PROMOTED
- DTA004: status = APPROVED (new, not in template)

After CREATE_DTA_TEMPLATE:
- Template v1.0: CLOSED (is_current=FALSE)
- Template v2.0: 105 records (95 + 10 from DTA004, minus duplicates)
  - included_dta_ids: [DTA001, DTA002, DTA004]
- DTA004: status = PROMOTED
```

![Incremental Template Updates](./diagrams/04_dta_incremental_template_updates.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/04_dta_incremental_template_updates.drawio)

### Registry Metadata for Templates

The `md_version_registry` now stores vendor+stream scoping:

| Column | Value |
|--------|-------|
| `version` | `2.0` |
| `version_type` | `DTA_TEMPLATE` |
| `library_type` | `transfer_variables` |
| `data_provider_name` | `Vendor_A` |
| `data_stream_type` | `EDC_Data` |
| `included_dta_ids` | `["DTA001", "DTA002", "DTA004"]` |
| `parent_version` | `1.0` (previous template for this vendor+stream) |
| `record_count` | 105 |
| `status` | `ACTIVE` |

### Definition Hash Includes Vendor+Stream

The `definition_hash` now includes vendor and stream to ensure templates are properly scoped:

```python
definition_hash = SHA256(
    data_provider_name +
    data_stream_type +
    transfer_variable_name + 
    data_type + 
    max_length + 
    required_flag + 
    codelist_reference + ...
)
```

This means:
- Same variable definition for different vendors = **different hashes**
- Vendor-specific conventions are preserved
- No accidental cross-vendor merging

### Merge Strategies

When the same `definition_hash` exists in both current template and new DTAs, the strategy determines which record to keep:

| Strategy | Description | Use Case |
|----------|-------------|----------|
| `UNION_DEDUP` | Combine all records, deduplicate by `definition_hash` (arbitrary pick) | **Default** - preserves unique definitions |
| `LATEST_WINS` | On duplicate `definition_hash`, keep newest record (new DTA overrides template) | Prefer newer standards |
| `FIRST_WINS` | On duplicate `definition_hash`, keep oldest record (template preserved) | Preserve original definitions |

### Running Template Creation

**Via UI Approvals Page:**
The Approvals page shows cards for each vendor+stream combination with approved DTAs ready for template creation. Click "Create Template" to trigger the job.

**Via Test Job:**
```bash
databricks jobs run-now --job-name job_cdm_create_dta_template_test
```

**Via Version Manager:**
```bash
databricks jobs run-now --job-name job_cdm_version_manager \
  --job-parameters '{
    "action": "CREATE_DTA_TEMPLATE",
    "merge_strategy": "UNION_DEDUP",
    "library_type": "transfer_variables",
    "data_provider_name": "Vendor_A",
    "data_stream_type": "EDC_Data"
  }'
```

**Process ALL vendor+stream combinations:**
```bash
databricks jobs run-now --job-name job_cdm_version_manager \
  --job-parameters '{
    "action": "CREATE_DTA_TEMPLATE",
    "merge_strategy": "UNION_DEDUP"
  }'
```

### Post-Template Validation

Run these queries to verify template creation:

```sql
-- Check new templates by vendor+stream
SELECT version, library_type, data_provider_name, data_stream_type, 
       record_count, included_dta_ids, created_ts
FROM gold_md.md_version_registry
WHERE version_type = 'DTA_TEMPLATE'
ORDER BY created_ts DESC;

-- Verify DTAs are marked as PROMOTED
SELECT dta_id, dta_number, data_provider_name, data_stream_type, status
FROM gold_md.dta
WHERE status = 'PROMOTED';

-- Count records per template
SELECT version, data_provider_name, data_stream_type, COUNT(*) as record_count
FROM gold_md.md_dta_transfer_variables
WHERE is_current = TRUE AND is_major_version = TRUE
GROUP BY version, data_provider_name, data_stream_type;
```

---

## 📋 Version Tag Format

| Version Type | Format | Example |
|--------------|--------|---------|
| DTA Template | `{major}.0` | `1.0`, `2.0` (per vendor+stream) |
| DTA Draft | `{template}-{dta_number}-draft{n}` | `1.0-DTA001-draft1` |
| DTA Approved | `{template}-{dta_number}-v{n}.0` | `1.0-DTA001-v1.0` |

**Components**:
- `{template}`: Parent template version (e.g., `1.0`)
- `{dta_number}`: Sequential DTA identifier (e.g., `DTA001`, `DTA002`)
- `draft{n}`: Draft sequence number (1, 2, 3...)
- `v{n}.0`: Major version within the DTA

---

## 🗄️ Key Tables

### `md_dta_transfer_variables`
The main versioned table using SCD Type 2:

| Column | Description |
|--------|-------------|
| `definition_hash` | Unique hash of field definition (includes vendor+stream) |
| `version` | Version tag (e.g., `1.0`, `1.0-DTA001-draft1`) |
| `data_provider_name` | Vendor name for this record |
| `data_stream_type` | Data stream type for this record |
| `is_major_version` | `TRUE` only for DTA Template versions |
| `is_dta_major` | `TRUE` for approved DTA versions |
| `parent_version` | Version this was branched from |
| `effective_start_ts` | When this version became active |
| `effective_end_ts` | When this version was closed (`NULL` = active) |
| `is_current` | `TRUE` for the active version of each record |

### `md_version_registry`
Lightweight metadata for all versions:

| Column | Description |
|--------|-------------|
| `version` | Unique version identifier |
| `version_type` | `DTA_TEMPLATE`, `DTA_DRAFT`, or `DTA_APPROVED` |
| `library_type` | Type of metadata (e.g., `transfer_variables`, `test_concepts`) |
| `dta_id` | Associated DTA (NULL for template versions) |
| `data_provider_name` | Vendor name (for templates) |
| `data_stream_type` | Data stream type (for templates) |
| `included_dta_ids` | Array of DTA IDs merged into this template |
| `parent_version` | Version this was derived from |
| `record_count` | Number of records in this version |
| `status` | `ACTIVE` or `SUPERSEDED` |

---

## 🔀 State Transitions

### Basic Flow (Branch from Template)

![Basic Flow - Branch from Template](./diagrams/04_dta_basic_flow_branch.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/04_dta_basic_flow_branch.drawio)

### Multi-Vendor Template Creation

![Multi-Vendor Template Creation](./diagrams/04_dta_multi_vendor_template.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/04_dta_multi_vendor_template.drawio)

---

## 🔄 Parallel DTA Development

Multiple DTAs can work simultaneously without conflicts:

![Parallel DTA Development](./diagrams/04_dta_parallel_dta_development.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/04_dta_parallel_dta_development.drawio)

**Key Points**:
- Each DTA has isolated version tags
- Changes in one DTA don't affect others
- Multiple DTAs can be merged into template (incrementing version numbers)
- Templates are scoped by vendor+stream

---

## 🔍 Querying Versions

### Get Current Template for Vendor+Stream
```sql
SELECT * FROM gold_md.md_dta_transfer_variables
WHERE is_major_version = TRUE 
  AND is_current = TRUE
  AND data_provider_name = 'Vendor_A'
  AND data_stream_type = 'EDC_Data'
```

### Get Specific DTA's Current Draft
```sql
SELECT * FROM silver_md.md_dta_transfer_variables_draft
WHERE version LIKE '%-DTA001-%' AND is_current = TRUE
```

### Get Point-in-Time Version
```sql
SELECT * FROM gold_md.md_dta_transfer_variables
WHERE version = '1.0'
  AND data_provider_name = 'Vendor_A'
  AND effective_start_ts <= '2025-01-15'
  AND (effective_end_ts IS NULL OR effective_end_ts > '2025-01-15')
```

### Get Version History
```sql
SELECT version, version_type, status, data_provider_name, data_stream_type, created_ts
FROM gold_md.md_version_registry
WHERE dta_id = 'DTA001'
ORDER BY created_ts
```

### Get All Templates by Vendor
```sql
SELECT version, data_provider_name, data_stream_type, record_count, included_dta_ids, status
FROM gold_md.md_version_registry
WHERE version_type = 'DTA_TEMPLATE'
ORDER BY data_provider_name, data_stream_type, version DESC
```

---

## 📁 Related Files

### Job Definitions
```
resources/data_engineering/clinical_data_standards/jobs/
└── job_cdm_version_manager.job.yml

resources/data_engineering/test/jobs/
└── job_cdm_create_dta_template_test.job.yml  # Test job for template creation
```

### Notebooks (by action)
```
notebooks/data_engineering/common/
├── nb_version_create_branch.ipynb    # CREATE_BRANCH
├── nb_version_save_draft.ipynb       # SAVE_DRAFT
├── nb_version_approve_dta.ipynb      # APPROVE_DTA / CREATE_DTA_APPROVED
└── nb_promote_to_template.ipynb      # CREATE_DTA_TEMPLATE (auto-merge by vendor+stream)
```

### Core Library
```
src/clinical_data_standards_framework/
└── versioning.py    # Core versioning functions including:
                     #   - merge_dtas_to_template()
                     #   - get_next_template_version_for_vendor_stream()
                     #   - get_current_template_for_vendor_stream()
```

---

## 🔑 Design Principles

1. **Immutability**: Records are never updated in place; new versions are created
2. **Full History**: All changes are preserved with timestamps
3. **Isolation**: DTAs work in isolated version spaces
4. **Traceability**: Every version links to its parent via `parent_version`
5. **Atomic Operations**: Each operation is a complete, consistent state change
6. **Vendor+Stream Scoping**: Templates are independent per vendor+stream combination
7. **Incremental Merging**: Only new DTAs are merged; already-promoted DTAs are skipped
# Hash Generation Design

## Overview

The hash generation system creates deterministic, content-based identifiers (`definition_hash`) that uniquely identify metadata definitions regardless of their source. This enables:

- **Cross-trial deduplication**: Same variable definition used in multiple trials = single library entry
- **Change detection**: Modified definitions get new hashes, preserving history
- **Versioning support**: Hash + version forms composite key in gold layer

The hash fields are **configuration-driven** and defined in `config/clinical_data_standards.yaml` under the `versioning` section. This allows flexibility to adjust which fields contribute to uniqueness without code changes.

---

## Configuration-Driven Hash Fields

Hash generation is controlled by the configuration file (`config/clinical_data_standards.yaml`), which defines:

1. **Common fields** - Always included in ALL library type hashes
2. **Type-specific fields** - Additional fields per library type

### Common Fields (All Library Types)

These fields are automatically included in the hash for every library type:

| Field | Description |
|-------|-------------|
| `data_provider_name` | Vendor name (normalized) |
| `data_stream_type` | Data stream type (e.g., EDC, Lab, PK) |

**Configuration:**
```yaml
versioning:
  definition_hash_common_fields:
    - data_provider_name
    - data_stream_type
```

**Result:** All hashes are **vendor-scoped** - same definition from different vendors = different hash.

### Type-Specific Hash Fields

Each library type defines additional fields to include in the hash calculation:

#### Transfer Variables

| Field | Description |
|-------|-------------|
| `transfer_variable_name` | Variable name (e.g., SUBJECT_ID) |
| `transfer_variable_order` | Order/sequence in the transfer file |
| `format` | Data type (text, numeric, date, etc.) |
| `anticipated_max_length` | Maximum length for the field |
| `transfer_file_key` | Whether this is a key field |
| `populate_for_all_records` | Whether value is required for all records |
| `codelist_values` | Array of codelist values (serialized as sorted, lowercase, pipe-delimited) |

**Configuration:**
```yaml
definition_hash_fields_by_type:
  transfer_variables:
    - transfer_variable_name
    - transfer_variable_order
    - format
    - anticipated_max_length
    - transfer_file_key
    - populate_for_all_records
    - codelist_values
```

**Final Hash Includes:** Common fields (`data_provider_name`, `data_stream_type`) + Type-specific fields

#### Test Concepts

Test Concepts represent specific laboratory tests, assessments, or observations. Each test concept is uniquely defined by a **complete set of transfer variable values** that characterize that test.

**What is the "Tuple"?**

In this context, "tuple" refers to **the complete row of transfer variable mappings** for a single test concept. It's stored as a MAP<STRING, STRING> where:
- **Keys** = Transfer variable names (e.g., `LBTESTCD`, `LBTEST`, `LBCAT`, `LBMETHOD`)
- **Values** = Specific values for this test (e.g., `"ALB"`, `"Albumin"`, `"CHEMISTRY"`, `"Spectrophotometry"`)

The tuple captures **all the variables** that collectively define what makes this test concept unique.

**Example: Albumin Lab Test**

```json
{
  "LBTESTCD": "ALB",
  "LBTEST": "Albumin",
  "LBCAT": "CHEMISTRY",
  "LBMETHOD": "Spectrophotometry",
  "LBSTRESU": "g/L",
  "LBSTNRLO": "35",
  "LBSTNRHI": "52"
}
```

This entire MAP is what defines the test concept. Two test concepts are considered **identical** if and only if their complete tuple (all variable mappings) match exactly.

**Why Tuples Matter for Hashing:**

| Scenario | Result |
|----------|--------|
| Same test code, same method, same units | **Same hash** → Deduplicated |
| Different test codes (`ALB` vs `ALP`) | **Different hash** → Separate entries |
| Same test, different methods | **Different hash** → Vendor variations captured |
| Same test, different reference ranges | **Different hash** → Site-specific standards |

The **entire tuple** is included in the hash calculation - not just one or two fields. This enables precise deduplication across trials while preserving meaningful variations.

| Field | Description |
|-------|-------------|
| `transfer_tuple_map` | MAP<STRING, STRING> containing all transfer variable name-value pairs for this test concept (serialized as sorted JSON) |

**Configuration:**
```yaml
definition_hash_fields_by_type:
  test_concepts:
    - transfer_tuple_map
```

**Schema-Agnostic Design:**

Test concept schemas vary significantly across vendors and data streams. Using a MAP structure allows:
- ✅ Different vendors can have different variable sets
- ✅ New variables can be added without schema changes
- ✅ Hash remains stable for the same logical test definition
- ✅ No need to predict all possible columns upfront

#### Codelists

| Field | Description |
|-------|-------------|
| `transfer_variable_name` | Variable name the codelist applies to |
| `values` | Array of codelist values (serialized as sorted, lowercase, pipe-delimited) |

**Configuration:**
```yaml
definition_hash_fields_by_type:
  codelists:
    - transfer_variable_name
    - values
```

#### Operational Agreement

| Field | Description |
|-------|-------------|
| `operational_agreement_id` | Unique agreement identifier |

**Configuration:**
```yaml
definition_hash_fields_by_type:
  operational_agreement:
    - operational_agreement_id
```

#### Vendor Visit

| Field | Description |
|-------|-------------|
| `protocol_visit_id` | Reference to protocol visit |
| `visit_name` | Vendor-specific visit name |
| `visit_number` | Visit sequence number |
| `timepoint` | Visit timepoint (e.g., "Day 1", "Week 4") |
| `timepoint_number` | Numeric timepoint value |

**Configuration:**
```yaml
definition_hash_fields_by_type:
  vendor_visit:
    - protocol_visit_id
    - visit_name
    - visit_number
    - timepoint
    - timepoint_number
```

#### Data Ingestion Parameters

| Field | Description |
|-------|-------------|
| `data_ingestion_id` | Unique ingestion parameter identifier |

**Configuration:**
```yaml
definition_hash_fields_by_type:
  data_ingestion_parameters:
    - data_ingestion_id
```

---

---

## Hash Algorithm

### Transfer Variables

Uses `compute_definition_hash()` from `src/clinical_data_standards_framework/utils.py`:

**Steps:**
1. **Sort fields alphabetically** for deterministic ordering
2. **Normalize values**:
   - `None` → empty string `""`
   - `Boolean true` → `"1"`
   - `Boolean false` → `"0"`
   - `Numbers` → string representation
   - `Strings` → lowercase, trimmed whitespace
3. **Concatenate** with pipe `|` delimiter
4. **Compute SHA256** hash (64 hex characters)

**Example:**
```python
# Input
hash_record = {
    'data_provider_name': 'VendorA',
    'data_stream_type': 'EDC',
    'transfer_variable_name': 'SUBJECT_ID',
    'format': 'text',
    'anticipated_max_length': '50',
    ...
}

# After normalization and sorting, pipe-delimited:
# "50|vendora|edc|text|subject_id|..."

# Result: SHA256 hash (64 hex characters)
```

For Spark DataFrames, use `compute_definition_hash_spark()` which applies the same logic.

### Test Concepts

Uses an inline function in `nb_tsdta_test_concepts_processor.ipynb`:

**Steps:**
1. **Create dictionary** with keys: `data_provider`, `data_stream`, `tuple_map`
2. **Sort dictionary items** alphabetically
3. **JSON serialize** with `json.dumps(sorted_items, sort_keys=True)`
4. **Compute SHA256** hash (64 hex characters)

**Example:**
```python
# Input
hash_dict = {
    'data_provider': 'VendorA',
    'data_stream': 'Lab',
    'tuple_map': {'LBTESTCD': 'ALB', 'LBTEST': 'Albumin', ...}
}

# JSON serialized (sorted):
# '[["data_provider", "VendorA"], ["data_stream", "Lab"], ["tuple_map", {...}]]'

# Result: SHA256 hash (64 hex characters)
```

---

## Related Documentation

- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - Table schemas including hash columns
- [04_dta_versioning_design.readme.md](./04_dta_versioning_design.readme.md) - How hash + version forms composite keys
- `config/clinical_data_standards.yaml` - Hash field configuration (versioning section)# DTA Workflow Design

## Overview

The DTA approval flow manages the governance process from DTA creation through final approval. It supports:

- **Multi-party approval**: JNJ DAE and Vendor roles with extensible architecture
- **Ordered approval chain**: Approvers review in sequence based on `approval_order`
- **Rejection handling**: Any rejection returns DTA to editing state
- **Version creation**: Approval triggers DTA version creation
- **Multiple cycles**: Rejection increments `workflow_iteration` for resubmission
- **Role-based access**: Permissions system controlling user capabilities

---

## Diagram

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| DTA Workflow Flow | Complete state transition diagram | [PNG](./diagrams/06_dta_workflow_flow.drawio.png) | [Draw.io](./diagrams/06_dta_workflow_flow.drawio) |

![DTA Workflow Flow](./diagrams/06_dta_workflow_flow.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/06_dta_workflow_flow.drawio)

---

## User Groups and Permissions

The DTA Workflow framework is built on a role-based access control (RBAC) system with three primary user groups. Each group has specific permissions that determine their capabilities within the DTA lifecycle.

### User Group Roles

#### 1. JNJ_DAE (J&J Data Acquisition Engineers)

**Primary Responsibilities:**
- Create and manage Data Transfer Agreements
- Edit DTA content and metadata
- Clone existing DTAs for reuse
- Promote approved DTAs to major versions (ACTIVE status)

**Key Permissions:**
- **Page Access**: Full access to all pages including DTA Builder, Dashboard, Workflow, and Viewer
- **Actions**:
  - `action_edit_dta` - Edit DTA fields and content
  - `action_clone_dta` - Clone DTAs for new trials
  - `action_delete_library_item` - Remove library items
  - `action_promote_dta` - Promote DTA to major version after approval
  - `action_add_comment` - Add comments and collaborate

**Limitations:**
- Cannot promote DTAs to templates (reserved for Librarians)

#### 2. VENDOR (External Data Vendors)

**Primary Responsibilities:**
- Review DTAs submitted for vendor approval
- Provide feedback and comments on DTA content
- Approve DTAs assigned to their organization

**Key Permissions:**
- **Page Access**: Dashboard, Workflow, Viewer, and Builder (read-only access)
- **Actions**:
  - `action_add_comment` - Comment on DTA content
  - `action_approve_dta` - Approve DTAs assigned to them

**Limitations:**
- Cannot create, edit, clone, or delete DTAs
- Cannot promote DTAs
- Can only approve DTAs for their assigned vendor organization

#### 3. JNJ_LIBRARIAN (Library Maintainers)

**Primary Responsibilities:**
- Maintain DTA template library for organizational reuse
- Promote approved DTAs to templates
- Manage administrative functions
- Ensure template quality and consistency

**Key Permissions:**
- **Page Access**: Dashboard, Workflow, Viewer, and Administration pages
- **Actions**:
  - `action_add_comment` - Provide feedback on DTAs
  - `action_promote_template` - Promote approved DTAs to reusable templates

**Special Capabilities:**
Librarians can create **DTA Templates** from approved DTAs. These templates serve as:
- **Reusable baselines** for new DTAs with the same vendor and data stream
- **Standardized definitions** ensuring consistency across trials
- **Version-controlled library entries** tracked in `md_version_registry`

**Limitations:**
- Cannot edit, clone, or approve DTAs
- Cannot create new DTAs (focused on template curation)

---

## Approver Assignment During DTA Creation

### Automatic Approval Task Creation

When a DTA is created (via UI, API, or CLI), the system automatically:

1. **Creates a DTA Workflow record** (`dta_workflow`)
   - Links the workflow to the newly created DTA
   - Initializes workflow state as `NOT_STARTED`

2. **Creates Approval Tasks** (`dta_approval_task`)
   - **JNJ_DAE Task**: `approval_order = 1`, `approval_status = PENDING`
   - **VENDOR Task**: `approval_order = 2`, `approval_status = PENDING`

3. **Initial State**:
   - All tasks start with `assigned_to_principal = NULL`
   - Approvers are assigned later via the UI by the DTA creator or workflow coordinator

### Approver Assignment Workflow

```
┌─────────────────────────────────────────────────────────────┐
│  DTA Creation                                               │
│  ───────────────────────────────────────────────────────── │
│  1. User creates DTA (Trial ID, Stream Type, Vendor)       │
│  2. System generates DTA ID and workflow ID                 │
│  3. System creates approval tasks (JNJ_DAE, VENDOR)         │
│     • approval_status = PENDING                             │
│     • assigned_to_principal = NULL                          │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│  Approver Assignment (via UI)                               │
│  ───────────────────────────────────────────────────────── │
│  1. Workflow coordinator navigates to DTA approval page     │
│  2. System displays approval tasks                          │
│  3. Coordinator assigns specific users to each task:        │
│     • JNJ_DAE Task → Assigns JNJ DAE user                   │
│     • VENDOR Task → Assigns specific vendor contact         │
│  4. System updates assigned_to_principal for each task      │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│  Submission for Approval                                    │
│  ───────────────────────────────────────────────────────── │
│  1. Creator submits DTA for approval                        │
│  2. System updates workflow_state = IN_PROGRESS             │
│  3. Assigned approvers receive notification                 │
└─────────────────────────────────────────────────────────────┘
```

### Assigning Approvers via UI

The DTA creator or workflow coordinator can assign approvers through:

1. **Approval Detail Page**: Navigate to `/approval/<dta_id>`
2. **View Approval Tasks**: See all pending approval tasks
3. **Assign Users**:
   - For **JNJ_DAE** task: Select from JNJ DAE group members
   - For **VENDOR** task: Select from vendor users based on DTA's `data_provider_name`
4. **System Lookup**: Uses `md_users` and `md_user_group_memberships` tables to populate approver dropdowns
5. **Update**: Once assigned, `assigned_to_principal` is set to the selected user's email

### Data Model

**Approval Task Schema:**
```sql
dta_approval_task (
  approval_task_id       STRING    -- Unique task identifier
  dta_workflow_id        STRING    -- FK to dta_workflow
  dta_id                 STRING    -- FK to dta
  approver_role          STRING    -- Role: JNJ_DAE, VENDOR
  assigned_to_principal  STRING    -- User email (NULL initially, assigned via UI)
  approval_status        STRING    -- Status: PENDING, APPROVED, REJECTED
  approval_order         INT       -- Execution order: 1, 2
  approval_comment       STRING    -- Approver's feedback
  approved_ts            TIMESTAMP -- Approval timestamp
  created_by_principal   STRING    -- Task creator
  created_ts             TIMESTAMP
  last_updated_by_principal STRING
  last_updated_ts        TIMESTAMP
)
```

---

## DTA Lifecycle States

### DTA Status

| Status | Description | Editable? |
|--------|-------------|-----------|
| `DRAFT` | DTA is being created/edited | ✅ Yes |
| `ACTIVE` | Approved and in use | ❌ No |
| `ARCHIVED` | No longer active | ❌ No |

### Workflow Status

| Status | Description |
|--------|-------------|
| `NOT_STARTED` | Workflow created but not submitted |
| `IN_PROGRESS` | Submitted and awaiting approvals |
| `APPROVED` | All approvers approved |
| `REJECTED` | At least one approver rejected |

### Approval Task Status

| Status | Description |
|--------|-------------|
| `PENDING` | Awaiting this approver's decision |
| `APPROVED` | Approver approved |
| `REJECTED` | Approver rejected |

---

## State Transitions

| From | Trigger | To | Result |
|------|---------|-----|--------|
| DRAFT | Save changes | DRAFT | Draft version updated |
| DRAFT | Submit for review | DRAFT + workflow IN_PROGRESS | First approver notified |
| DRAFT | All approve | ACTIVE | DTA version created |
| DRAFT | Any rejects | DRAFT + workflow REJECTED | Returns for editing |
| ACTIVE | Continue work | DRAFT | New workflow iteration |

---

## Framework Extensibility

The DTA Workflow framework is designed to support additional approver roles beyond the current implementation. The architecture allows for easy extension to include roles such as:

- **Legal Reviewers**: For contractual and compliance review
- **Data Privacy Officers**: For GDPR and data protection compliance
- **Quality Assurance**: For additional validation layers
- **Executive Sponsors**: For high-value or high-risk DTAs

**To add new approver roles:**
1. Create new user group in `md_user_groups` (e.g., `JNJ_LEGAL`)
2. Define permissions in `md_permissions` and assign to group
3. Update DTA creation logic to include additional approval task with appropriate `approval_order`
4. Extend UI to support new role assignment and approval

---

## Template Creation for Reuse

### Overview

JNJ Librarians can promote approved DTAs to **DTA Templates**, which serve as reusable baselines for future DTA creation. This capability ensures:
- **Consistency**: Standardized definitions across trials and vendors
- **Efficiency**: Faster DTA creation by cloning from templates
- **Quality**: Vetted and approved content becomes organizational knowledge

### Template Promotion Process

1. **Identify Promotion Candidates**:
   - DTAs with `status = ACTIVE` (approved and in use)
   - Grouped by `data_provider_name` and `data_stream_type`
   - Displayed in the Administration Dashboard

2. **Trigger Template Creation**:
   - Librarian selects a vendor+stream combination
   - System triggers `job_cdm_version_manager` job
   - Job parameters:
     ```json
     {
       "action": "CREATE_DTA_TEMPLATE",
       "data_provider_name": "Labcorp",
       "data_stream_type": "LB",
       "library_type": "transfer_variables",
       "merge_strategy": "UNION_DEDUP"
     }
     ```

3. **Template Creation Logic**:
   - **Merge Strategy**: Combines multiple approved DTAs for the same vendor+stream
   - **Deduplication**: Uses `definition_hash` to identify unique definitions
   - **Versioning**: Creates new template version in `md_version_registry`
   - **Library Types**: Processes Transfer Variables, Test Concepts, Codelists, etc.

4. **Template Usage**:
   - When creating a new DTA, users can select templates from the library panel
   - System clones template content as the starting point
   - New DTA inherits template structure but remains independently editable

### Template Metadata

Templates are tracked in `md_version_registry`:

```sql
md_version_registry (
  version              STRING    -- Template version (e.g., "1.0")
  library_type         STRING    -- Type: transfer_variables, test_concepts, etc.
  version_type         STRING    -- Type: DTA_TEMPLATE
  dta_id               STRING    -- NULL for templates (or source DTA ID)
  parent_version       STRING    -- Previous template version
  record_count         INT       -- Number of definitions in template
  status               STRING    -- ACTIVE, ARCHIVED
  created_by_principal STRING
  created_ts           TIMESTAMP
  ...
)
```

### Benefits of Template System

- **Vendor Standardization**: Each vendor has a canonical template for their data streams
- **Rapid DTA Creation**: New DTAs inherit vendor-specific standards automatically
- **Version Control**: Templates are versioned, allowing rollback and history tracking
- **Governance**: Librarian role ensures only high-quality DTAs become templates

### Key Concepts

- Templates are **scoped by (vendor, data_stream)** combination
- Each vendor+stream pair has its own independent template version sequence
- Multiple approved DTAs from the same vendor+stream are merged into a single template
- The Librarian role has exclusive permission to promote DTAs to templates

---

## Related Documentation

- [03_dta_status_lifecycle_design.readme.md](./03_dta_status_lifecycle_design.readme.md) - Document and DTA status values
- [04_dta_versioning_design.readme.md](./04_dta_versioning_design.readme.md) - Version management and template creation
- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - User groups and permissions schema
- `sql/setup_cdm_app_permissions.sql` - User group and permission setup script# Databricks AI Design

## Overview

The Clinical Data Standards platform leverages **Databricks AI** capabilities to enable intelligent document processing and conversational data access. This design covers two primary AI capabilities:

### 1. Databricks Model Serving (Future Recommendation)
Process clinical documents containing unstructured or semi-structured data. This architecture enables intelligent extraction of data from:


- **Operational Agreements** (PDF/Word) - Contract terms, vendor information, transfer requirements
- **Protocol Documents** (PDF/Word) - Study design, endpoints, Schedule of Activities tables

**In the current implementation we are directly calling the AI model.**

### 2. Databricks AI/BI Genie
Enable natural language querying of structured DTA metadata. Users can search and analyze DTAs using conversational questions instead of SQL:

- **DTA Discovery** - "Find all Labs DTAs from LabCorp"
- **Version Lookup** - "Show me DTAs approved in the last 30 days"
- **Template Search** - "What are the latest versions for vendor Clario?"

### AI Functions

The platform uses two primary AI functions provided by Databricks:

| Function | Purpose |
|----------|---------|
| `ai_parse_document` | Parse unstructured documents (PDF, Word, scanned images) into structured, queryable content using OCR, layout detection, and table extraction |
| `ai_query` | Extract specific entities, relationships, and structured data from parsed documents using natural language queries |

### Model Serving

Databricks Model Serving provides a flexible infrastructure for deploying and managing LLM endpoints. Key capabilities include:

- **Model Flexibility**: Switch between OpenAI GPT-4, Llama 3, Claude, or custom models without code changes
- **Cost Optimization**: Route simpler tasks to cost-effective models, reserve premium models for complex extraction
- **Custom Endpoints**: Deploy document-type specific endpoints with tailored prompts
- **Scalability**: Auto-scaling based on document processing volume
- **Version Control**: Deploy new model versions with rollback capability

### Prompt Engineering

Effective extraction relies on well-designed prompts that:

- Specify the exact output schema expected (JSON structure, field names, data types)
- Include confidence scoring requirements for extracted values
- Handle missing or ambiguous data gracefully (null values, low confidence flags)
- Provide context about document type and domain terminology
- Use few-shot examples when appropriate for complex extraction patterns

---

## Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| AI Processing Overview | End-to-end architecture showing input, processing, models, and output | [PNG](./diagrams/07_dta_ai_processing_overview.drawio.png) | [Draw.io](./diagrams/07_dta_ai_processing_overview.drawio) |
| Model Selection Strategy | Decision tree for routing documents to appropriate models | [PNG](./diagrams/07_dta_model_selection_strategy.drawio.png) | [Draw.io](./diagrams/07_dta_model_selection_strategy.drawio) |

### AI Processing Overview

![AI Processing Overview](./diagrams/07_dta_ai_processing_overview.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/07_dta_ai_processing_overview.drawio)

### Model Selection Strategy

![Model Selection Strategy](./diagrams/07_dta_model_selection_strategy.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/07_dta_model_selection_strategy.drawio)

---

## AI Capabilities

### `ai_parse_document` - Document Parsing

Parses unstructured documents into structured, queryable content. This function handles:

- **OCR Processing**: Converts scanned images and PDF text layers into machine-readable text
- **Layout Detection**: Identifies document structure including headers, paragraphs, lists, and sections
- **Table Detection**: Extracts tabular data preserving row/column relationships
- **Text Extraction**: Cleans and normalizes text content for downstream processing

### `ai_query` - Entity Extraction

Extracts specific entities and relationships from parsed documents using natural language queries. Supports:

- **Named Entity Recognition**: Identifies people, organizations, dates, locations
- **Key-Value Extraction**: Extracts specific fields based on query context
- **Relationship Extraction**: Identifies connections between entities (e.g., vendor-contact relationships)
- **Conditional Extraction**: Filters results based on specified criteria

### Model Serving - Custom Extraction

For complex extraction patterns, the platform uses Databricks Model Serving endpoints with custom prompts. This enables:

- **Schema-Guided Extraction**: Prompts that specify exact output structure
- **Multi-Model Routing**: Different models for different document types
- **Confidence Scoring**: Each extracted value includes a confidence score
- **Fallback Handling**: Automatic fallback to alternative models on failure

---

## Databricks Model Serving

**Databricks Model Serving** provides enterprise-grade infrastructure for deploying and managing Large Language Models (LLMs) at scale. The Clinical Data Standards platform leverages Model Serving as the recommended approach for AI-powered document processing.

### Why Databricks Model Serving?

| Capability | Benefit |
|------------|---------|
| **Unified Infrastructure** | Deploy any model (OpenAI, Llama, Claude, custom) through a single API |
| **A/B Testing** | Test multiple models simultaneously and route traffic based on performance |
| **Smart Routing** | Route requests to different models based on document type, complexity, or cost |
| **Auto-scaling** | Automatically scale endpoints based on demand |
| **Cost Optimization** | Monitor token usage and costs per model across your organization |
| **Version Control** | Deploy new model versions with zero-downtime rollback capability |
| **Security & Governance** | Centralized access control, audit logs, and compliance tracking |
| **Observability** | Built-in monitoring, metrics, and request tracing |

📚 **Official Documentation**: [Databricks Model Serving](https://docs.databricks.com/en/machine-learning/model-serving/index.html)

### Current Model Configuration

This project is configured to use:

| Model | Purpose | Configuration | Access Method |
|-------|---------|---------------|---------------|
| **GPT-4.1 Mini Global** 🟢 | Operational Agreement entity extraction | `gpt_entity_extractor` | External API endpoint |
| **Databricks Foundation Models** | Protocol processing, general extraction | `chatbot-endpoint-${bundle.target}` | Model Serving endpoint |

🟢 **Currently Active Model**

### Model Comparison

The following models are available through Databricks Model Serving endpoints:

| Model | Best For | Context Length | Cost | Latency |
|-------|----------|----------------|------|---------|
| **GPT-4.1 Mini** 🟢 | Balanced performance, cost-effective extraction | 128K | $ | Fast |
| **OpenAI GPT-4** | Complex reasoning, accuracy-critical extraction | 128K | $$$ | Medium |
| **OpenAI GPT-4o** | Balanced performance, general extraction | 128K | $$ | Fast |
| **Llama 3 70B** | Cost-effective processing, privacy-sensitive | 8K | $ | Fast |
| **Llama 3.1 405B** | Open-source, high capability | 128K | $$ | Medium |
| **Claude 3 Opus** | Very long documents (>100K tokens) | 200K | $$$ | Medium |
| **Claude 3 Sonnet** | Balanced, long context needs | 200K | $$ | Fast |
| **Custom Fine-tuned** | Domain-specific tasks (forms, checkboxes) | Varies | $ | Fast |

🟢 = Currently configured model for this project

### Switching Models

To switch to a different model, update `config/clinical_data_standards.yaml`:

```yaml
services:
  gpt_entity_extractor:
    type: "llm"
    endpoint: "https://your-endpoint"
    model: "gpt-4o"  # Change model here
    ...
```

No code changes required - the framework automatically routes requests to the configured model.

### Use Case Routing Strategy

When extending to multiple models, consider routing based on:

| Use Case | Recommended Model | Reason |
|----------|-------------------|---------|
| **Documents >100K tokens** | Claude 3 (200K context) | Handles very long protocols |
| **High-accuracy requirements** | GPT-4 | Best reasoning capability |
| **Cost-sensitive workloads** | Llama 3 70B | Open-source, self-hosted option |
| **Form/checkbox extraction** | Custom fine-tuned | Optimized for structured forms |
| **Privacy-sensitive data** | Self-hosted Llama | Data never leaves your infrastructure |
| **General extraction** | GPT-4.1 Mini / GPT-4o Mini 🟢 | Best balance of cost and performance |

---

## Databricks AI/BI Genie

**Databricks AI/BI Genie** is a conversational AI interface that enables users to query structured data using natural language instead of SQL. While Model Serving handles **document processing** (extraction), Genie handles **data querying** (search and analysis).

### Genie vs. Model Serving

| Aspect | Model Serving | Databricks Genie |
|--------|---------------|------------------|
| **Purpose** | Extract structured data from unstructured documents | Query structured data using natural language |
| **Input** | PDF, Word, Excel documents | User questions in plain English |
| **Output** | Structured metadata (JSON, tables) | Query results (tables, charts) |
| **Use Case** | Parse Protocol PDFs, extract OA entities | Search DTAs, query version history |
| **Backend** | LLM endpoints (GPT, Llama, Claude) | Unity Catalog + SQL generation |
| **Integration** | Document processing pipelines | DTA Builder search UI |

### Genie in DTA Builder

The DTA Builder UI integrates Genie to enable conversational search and discovery:

**Example Questions:**
- "Find all Labs DTAs from LabCorp"
- "Show me DTAs approved in the last 30 days"
- "What are the latest versions for vendor Clario?"
- "List all transfer variables for DTA001 that have status ACTIVE"

**Key Capabilities:**
- **Context-Aware**: Remembers conversation history for follow-up questions
- **Permission-Enforced**: Only shows data the user has access to via Unity Catalog
- **SQL Transparency**: Displays generated SQL for learning and validation
- **Multi-Table Joins**: Automatically joins across gold tables (DTA, workflows, versions)

### Genie Space Configuration

A **Genie Space** is preconfigured with:
- **Tables**: All gold layer tables (`dta`, `md_dta_transfer_variables`, `dta_workflow`, etc.)
- **Instructions**: Domain guidance on DTA terminology and query patterns
- **Sample Questions**: Pre-built questions to help users get started
- **Example Queries**: Parameterized SQL queries that train Genie on correct patterns

The `job_cdm_export_genie_assets` job automatically generates these assets by:
1. Discovering all relevant gold tables
2. Generating SQL comments for tables/columns
3. Creating 15+ example queries with natural language questions
4. Assembling the complete space configuration

📚 **Official Documentation**: [Databricks AI/BI Genie](https://docs.databricks.com/en/genie/index.html)

**For detailed implementation**: See [09_dta_genie_integration_design.readme.md](./09_dta_genie_integration_design.readme.md) for complete setup, asset generation, and API integration.

---

## Patterns

### Checkbox Extraction

Detects checked and unchecked boxes in scanned forms or PDFs. The model identifies checkbox symbols (☑, ☐, ✓, X) and their associated labels, returning structured JSON with:

- Label/description of each checkbox
- Checked state (true/false)
- Confidence score (0.0-1.0)

Used for processing clinical forms where requirements or options are indicated via checkboxes.

### Entity Extraction with Schema

Extracts entities matching a predefined schema from unstructured text. The prompt specifies the exact fields required (vendor name, contract dates, transfer frequency, data formats) and their expected data types. The model returns:

- Field values matching the schema
- Null values for fields not found in the document
- Confidence scores for each extracted field

Enables consistent, structured output regardless of how information is presented in source documents.

### Protocol Document Parsing

Processes clinical protocol documents to extract study design information. The model identifies section headers (Objectives, Endpoints, Inclusion/Exclusion Criteria) and extracts:

- Study title and identifiers
- Primary and secondary objectives
- Primary, secondary, and exploratory endpoints
- Inclusion and exclusion criteria as structured lists

### Schedule of Activities Table Extraction

Extracts Time and Visit data from Schedule of Activities (SoA) tables found in Protocol documents. These tables define:

- **Visits**: Study visit identifiers (Screening, Day 1, Week 4, etc.)
- **Timepoints**: Timing relative to study milestones
- **Procedures**: Activities performed at each visit (marked with X or specific codes)

The extraction uses a **multi-phase orchestration pipeline** with five specialized prompts:

1. **Table Classification**: Identifies table type (Guide Table, Detailed SoA, Transposed SoA, Assessment Table)
2. **Visit Extraction**: Parses column/row headers for visit identifiers and timing windows
3. **Procedure Extraction**: Extracts procedure names and categories from row/column headers
4. **Mapping Extraction**: Creates procedure-visit intersection matrix with markers (X, footnotes, conditions)
5. **Footnote Extraction**: Captures timing conditions, population criteria, and special instructions

The model preserves the tabular structure while extracting:

- Visit names and timing windows
- Procedure-to-visit mappings with conditional requirements
- Visit sequence and dependencies
- Footnote conditions that modify procedure requirements

This extraction is critical for generating study calendars and procedure schedules from protocol documents.

**For detailed implementation**: See [10_dta_protocol_document_design.readme.md](./10_dta_protocol_document_design.readme.md) for complete prompt engineering, data models, and UI workflows.

---

## Related Documentation

- [01_dta_job_architecture_design.readme.md](./01_dta_job_architecture_design.readme.md) - Overall pipeline architecture
- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - Schema for extracted data
- [03_dta_status_lifecycle_design.readme.md](./03_dta_status_lifecycle_design.readme.md) - Document processing statuses
- [09_dta_genie_integration_design.readme.md](./09_dta_genie_integration_design.readme.md) - Detailed Genie integration, asset generation, and API
- [10_dta_protocol_document_design.readme.md](./10_dta_protocol_document_design.readme.md) - Detailed Schedule of Activities extraction implementation
# Permissions & Access Control Design

## Overview

This document describes the **hierarchical permissions system** for the Clinical Data Standards Management application. The system provides role-based access control (RBAC) integrated with Unity Catalog and backed by database tables managed via the `job_cdm_app_permissions` job.

### Permission Levels

The design follows a two-level hierarchy:

1. **Page Access** - Which pages/menus can the user see?
2. **Action Execute** - Which buttons/actions can the user perform?

### Design Principles

- **Database-Driven**: All permissions stored in Unity Catalog tables (`md_users`, `md_user_groups`, `md_permissions`)
- **Hierarchical**: Page access controls action availability
- **Extensible**: Easy to add new roles, permissions, and UI elements
- **Job-Managed**: Permissions setup and updates via dedicated Databricks job
- **Vendor-Scoped**: Vendor users automatically filtered by `vendor_id`

---

## Architecture Diagram

![Permissions Hierarchy](./diagrams/08_dta_permissions_hierarchy.drawio.png)


📝 [Edit Diagram (Draw.io)](./diagrams/08_dta_permissions_hierarchy.drawio)

The diagram shows:
- **Top Section**: User groups (JNJ_DAE, VENDOR, JNJ_LIBRARIAN) and their mapped permissions
- **Bottom Section**: Database schema (ERD) showing 5 tables and their relationships

---

## User Groups

| Group | Description | Primary Use Case |
|-------|-------------|------------------|
| **JNJ_DAE** | Data Acquisition Engineer | Create, edit, clone, manage DTAs; submit for approval; promote to major version |
| **VENDOR** | External vendor user | View assigned DTAs; add comments; approve DTAs |
| **JNJ_LIBRARIAN** | Library maintainer | View DTAs, comment, and promote approved DTAs to templates |

### Vendor User Scoping

Vendor users are linked to a specific vendor via `vendor_id`:
- They only see DTAs associated with their vendor
- `vendor_id` references `md_vendor.vendor_id`
- Data queries are automatically filtered by vendor

---

## Complete Permissions Matrix

This table shows all permissions in the system and which user groups have access to each:

| Permission Key | Type | Description | Enforcement | JNJ_DAE | VENDOR | LIBRARIAN |
|----------------|------|-------------|-------------|---------|--------|-----------|
| **PAGE ACCESS PERMISSIONS** ||||||||
| `page_all` | PAGE_ACCESS | Access to all pages (wildcard) | HIDE | ✓ | ✗ | ✗ |
| `page_dashboard` | PAGE_ACCESS | Dashboard page | HIDE | ✓ via all | ✓ | ✓ |
| `page_dta_builder` | PAGE_ACCESS | DTA Builder page | HIDE | ✓ | ✓ | ✗ |
| `page_dta_workflow` | PAGE_ACCESS | DTA Workflow page | HIDE | ✓ via all | ✓ | ✓ |
| `page_dta_viewer` | PAGE_ACCESS | DTA Viewer page | HIDE | ✓ via all | ✓ | ✓ |
| `page_study_mgmt` | PAGE_ACCESS | Study Management pages | HIDE | ✓ via all | ✗ | ✗ |
| `page_doc_mgmt` | PAGE_ACCESS | Document Management pages | HIDE | ✓ via all | ✗ | ✗ |
| `page_admin` | PAGE_ACCESS | Administration pages | HIDE | ✗ | ✗ | ✓ |
| **ACTION PERMISSIONS** ||||||||
| `action_edit_dta` | ACTION_EXECUTE | Edit DTA fields and content | DISABLE | ✓ | ✗ | ✗ |
| `action_clone_dta` | ACTION_EXECUTE | Clone existing DTAs | HIDE | ✓ | ✗ | ✗ |
| `action_delete_library_item` | ACTION_EXECUTE | Delete library items | HIDE | ✓ | ✗ | ✗ |
| `action_add_comment` | ACTION_EXECUTE | Add comments to items | HIDE | ✓ | ✓ | ✓ |
| `action_approve_dta` | ACTION_EXECUTE | Approve DTAs in workflow | HIDE | ✗ | ✓ | ✗ |
| `action_promote_dta` | ACTION_EXECUTE | Promote DTA to major version | HIDE | ✓ | ✗ | ✗ |
| `action_promote_template` | ACTION_EXECUTE | Promote DTA to template | HIDE | ✗ | ✗ | ✓ |

**Legend:**
- ✓ = Has permission
- ✗ = No permission
- **HIDE** = Element removed from DOM if no permission
- **DISABLE** = Element visible but inactive if no permission

---

## Database Schema

### Tables

#### md_users
Stores application users with vendor associations.

| Column | Type | Description |
|--------|------|-------------|
| `user_id` | STRING | Primary key (UUID) |
| `email` | STRING | User email for authentication and notifications |
| `display_name` | STRING | User display name |
| `vendor_id` | STRING | FK to `md_vendor` for vendor users, NULL for internal |
| `is_active` | BOOLEAN | Active status |
| `created_ts` | TIMESTAMP | Record creation timestamp |
| `last_updated_ts` | TIMESTAMP | Last update timestamp |

#### md_user_groups
Defines user groups with permission sets.

| Column | Type | Description |
|--------|------|-------------|
| `group_id` | STRING | Primary key |
| `group_name` | STRING | Group name: JNJ_DAE, JNJ_LIBRARIAN, VENDOR |
| `description` | STRING | Group description |
| `is_active` | BOOLEAN | Active status |

#### md_permissions
Defines permission definitions with enforcement strategy.

| Column | Type | Description |
|--------|------|-------------|
| `permission_id` | STRING | Primary key |
| `permission_type` | STRING | Type: PAGE_ACCESS, ACTION_EXECUTE |
| `permission_key` | STRING | Unique key: page_dashboard, action_edit_dta, etc. |
| `enforcement_mode` | STRING | HIDE (remove from DOM) or DISABLE (show but inactive) |
| `description` | STRING | Human-readable description |
| `disabled_message` | STRING | Tooltip/message shown when element is disabled |

#### md_user_group_memberships
Maps users to groups (many-to-many).

| Column | Type | Description |
|--------|------|-------------|
| `membership_id` | STRING | Primary key |
| `user_id` | STRING | FK to `md_users` |
| `group_id` | STRING | FK to `md_user_groups` |
| `joined_ts` | TIMESTAMP | When user joined the group |

#### md_group_permissions
Maps groups to permissions (many-to-many).

| Column | Type | Description |
|--------|------|-------------|
| `group_permission_id` | STRING | Primary key |
| `group_id` | STRING | FK to `md_user_groups` |
| `permission_id` | STRING | FK to `md_permissions` |

---

## Permission Hierarchy

### Level 1: Page Access

Controls which pages/menu items the user can see.

| Permission Key | Description | Enforcement Mode |
|----------------|-------------|------------------|
| `page_all` | Access to all pages (Admin wildcard) | HIDE |
| `page_dashboard` | Access dashboard page | HIDE |
| `page_dta_builder` | Access DTA Builder page | HIDE |
| `page_dta_workflow` | Access DTA Workflow page | HIDE |
| `page_dta_viewer` | Access DTA Viewer page | HIDE |
| `page_study_mgmt` | Access Study Management pages | HIDE |
| `page_doc_mgmt` | Access Document Management pages | HIDE |
| `page_admin` | Access Administration pages | HIDE |

**Page Access Matrix:**

| Page | JNJ_DAE | VENDOR | JNJ_LIBRARIAN |
|------|---------|--------|---------------|
| Dashboard | ✓ (via page_all) | ✓ | ✓ |
| DTA Builder | ✓ | ✓ (read-only) | ✗ |
| DTA Workflow | ✓ (via page_all) | ✓ | ✓ |
| DTA Viewer | ✓ (via page_all) | ✓ | ✓ |
| Study Management | ✓ (via page_all) | ✗ | ✗ |
| Document Management | ✓ (via page_all) | ✗ | ✗ |
| Administration | ✗ | ✗ | ✓ |

### Level 2: Action Execute

Controls which buttons/actions the user can perform.

| Permission Key | Description | Enforcement Mode |
|----------------|-------------|------------------|
| `action_edit_dta` | Edit DTA fields | DISABLE |
| `action_add_comment` | Add comments to items | HIDE |
| `action_clone_dta` | Clone DTAs | HIDE |
| `action_delete_library_item` | Delete library items | HIDE |
| `action_promote_template` | Promote DTA to template | HIDE |
| `action_approve_dta` | Approve DTA | HIDE |
| `action_promote_dta` | Promote DTA to Major Version | HIDE |

**Action Permissions Matrix:**

| Action | JNJ_DAE | VENDOR | JNJ_LIBRARIAN |
|--------|---------|--------|---------------|
| Edit DTA | ✓ | ✗ | ✗ |
| Clone DTA | ✓ | ✗ | ✗ |
| Delete Item | ✓ | ✗ | ✗ |
| Add Comment | ✓ | ✓ | ✓ |
| Approve DTA | ✗ | ✓ | ✗ |
| Promote DTA to Major Version | ✓ | ✗ | ✗ |
| Promote DTA to Template | ✗ | ✗ | ✓ |

---

## Permissions Setup Job

### job_cdm_app_permissions

**Purpose**: Setup and seed permission tables for the CDM application

**Job Definition**: `resources/sql/common/jobs/job_cdm_app_permissions.job.yml`

**SQL Script**: `sql/setup_cdm_app_permissions.sql`

**Tasks:**
1. **setup_app_permissions** - SQL task that:
   - Drops existing permission tables (to ensure schema updates)
   - Creates 5 permission tables (`md_users`, `md_user_groups`, `md_permissions`, `md_user_group_memberships`, `md_group_permissions`)
   - Seeds 3 user groups (JNJ_DAE, VENDOR, JNJ_LIBRARIAN)
   - Seeds 15 permissions (8 PAGE_ACCESS + 7 ACTION_EXECUTE)
   - Assigns permissions to groups
   - Creates test users
   - Assigns users to groups

**Execution Order:**
- **After** `job_cdm_sql_setup` (to ensure schemas exist)
- **After** CDM import job (to ensure vendors exist in `md_vendor`)
- **Before** deploying the Flask app

**Parameters:**
- `catalog_override`: Target catalog (defaults to `${var.catalog}`)

**To Run:**
```bash
# Via Databricks UI
# Workflows → Jobs → job_cdm_app_permissions → Run Now

# Via CLI
databricks jobs run-now --job-name job_cdm_app_permissions
```

---

## Current Users

The following users are configured in the system:

### JNJ DAE Users

| Email | Display Name | Vendor | Group |
|-------|--------------|--------|-------|
| VKapoor9@its.jnj.com | Vikas Kapoor (DAE) | JNJ Internal | JNJ_DAE |
| gricca4@its.jnj.com | Giuseppe Ricca (DAE) | JNJ Internal | JNJ_DAE |

### Vendor Users

| Email | Display Name | Vendor | Group |
|-------|--------------|--------|-------|
| awagle4@its.jnj.com | Arun Wagle (LabCorp) | Labcorp | VENDOR |
| RRaoGude@its.jnj.com | Rohit Rao Gude (Clario) | Clario | VENDOR |

### JNJ Librarian

| Email | Display Name | Vendor | Group |
|-------|--------------|--------|-------|
| JHEERES1@its.jnj.com | Jennifer Heeres (Librarian) | JNJ Internal | JNJ_LIBRARIAN |

---

## Implementation

### Backend API

#### user_management_api.py

Service for managing users, groups, and permissions:

```python
class UserManagementService:
    """Service for managing users, groups, and permissions"""
    
    def __init__(self, sql_client, catalog="dta_poc_test", schema="gold_md"):
        self.client = sql_client
        self.catalog = catalog
        self.schema = schema
    
    def get_user_by_email(self, email: str) -> dict:
        """Get user details by email"""
        query = f"""
            SELECT 
                u.user_id, u.email, u.display_name,
                u.vendor_id, v.vendor_name, u.is_active
            FROM {self.catalog}.{self.schema}.md_users u
            LEFT JOIN {self.catalog}.{self.schema}.md_vendor v 
              ON u.vendor_id = v.vendor_id
            WHERE u.email = '{email}' AND u.is_active = true
        """
        results = self.client.execute_query(query)
        return results[0] if results else None
    
    def get_user_groups(self, email: str) -> list:
        """Get groups for a user"""
        query = f"""
            SELECT g.group_name
            FROM {self.catalog}.{self.schema}.md_users u
            JOIN {self.catalog}.{self.schema}.md_user_group_memberships m 
              ON u.user_id = m.user_id
            JOIN {self.catalog}.{self.schema}.md_user_groups g 
              ON m.group_id = g.group_id
            WHERE u.email = '{email}' AND u.is_active = true
        """
        results = self.client.execute_query(query)
        return [row['group_name'] for row in results]
    
    def get_user_permissions(self, email: str) -> dict:
        """Get all permissions for a user (organized by type)"""
        query = f"""
            SELECT DISTINCT p.permission_type, p.permission_key
            FROM {self.catalog}.{self.schema}.md_users u
            JOIN {self.catalog}.{self.schema}.md_user_group_memberships m 
              ON u.user_id = m.user_id
            JOIN {self.catalog}.{self.schema}.md_group_permissions gp 
              ON m.group_id = gp.group_id
            JOIN {self.catalog}.{self.schema}.md_permissions p 
              ON gp.permission_id = p.permission_id
            WHERE u.email = '{email}' AND u.is_active = true
        """
        results = self.client.execute_query(query)
        
        permissions = {'PAGE_ACCESS': [], 'ACTION_EXECUTE': []}
        for row in results:
            perm_type = row['permission_type']
            if perm_type in permissions:
                permissions[perm_type].append(row['permission_key'])
        
        return permissions
    
    def can(self, email: str, permission_key: str) -> bool:
        """Check if user has a specific permission"""
        perms = self.get_user_permissions(email)
        all_perms = perms['PAGE_ACCESS'] + perms['ACTION_EXECUTE']
        return permission_key in all_perms or 'page_all' in perms['PAGE_ACCESS']
    
    def get_user_with_permissions(self, email: str) -> dict:
        """Get complete user profile with permissions"""
        user = self.get_user_by_email(email)
        if not user:
            return None
        
        user['groups'] = self.get_user_groups(email)
        user['permissions'] = self.get_user_permissions(email)
        return user
```

### Flask Integration

#### app.py

```python
from apps.clnl_data_std_mgmt_app.api.user_management_api import UserManagementService
from databricks_sql_client import DatabricksSQLClient

# Initialize user service
def get_user_service():
    if not hasattr(g, 'user_service'):
        sql_client = DatabricksSQLClient(warehouse_id=WAREHOUSE_ID)
        g.user_service = UserManagementService(sql_client, catalog=CATALOG)
    return g.user_service

# Get current user (from SSO or session)
def get_current_user():
    if 'current_user' not in g:
        # In production: email = request.headers.get('X-Forwarded-User')
        email = session.get('user_email', 'VKapoor9@its.jnj.com')
        user_service = get_user_service()
        g.current_user = user_service.get_user_with_permissions(email)
    return g.current_user

# Permission checking helper
@app.context_processor
def utility_processor():
    def can(permission_key):
        """Check if current user has permission"""
        user = get_current_user()
        if not user:
            return False
        user_service = get_user_service()
        return user_service.can(user['email'], permission_key)
    
    return dict(can=can)

# API endpoint to get current user
@app.route('/api/current-user', methods=['GET'])
def api_current_user():
    """Get current user profile"""
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Not authenticated'}), 401
    return jsonify({'success': True, 'user': user})

# API endpoint to check permission
@app.route('/api/can/<permission_key>', methods=['GET'])
def api_can(permission_key):
    """Check if current user has a permission"""
    user_service = get_user_service()
    user = get_current_user()
    if not user:
        return jsonify({'success': False, 'has_permission': False})
    
    has_perm = user_service.can(user['email'], permission_key)
    return jsonify({'success': True, 'has_permission': has_perm})
```

### Frontend Templates

#### Checking Permissions in Templates

```html
<!-- Hide element if user doesn't have permission -->
{% if can('action_edit_dta') %}
<button class="btn btn-primary">Edit DTA</button>
{% endif %}

<!-- Disable element if user doesn't have permission -->
<button class="btn btn-primary" 
        {% if not can('action_clone_dta') %}disabled{% endif %}>
    Clone DTA
</button>

<!-- Show different content based on permission -->
{% if can('page_admin') %}
<li><a href="/admin">Administration</a></li>
{% endif %}
```

#### JavaScript Permission Checking

```javascript
// Check permission via API
async function checkPermission(permissionKey) {
    const response = await fetch(`/api/can/${permissionKey}`);
    const data = await response.json();
    return data.has_permission;
}

// Usage
const canEdit = await checkPermission('action_edit_dta');
if (canEdit) {
    showEditButton();
} else {
    hideEditButton();
}

// Get current user
async function getCurrentUser() {
    const response = await fetch('/api/current-user');
    const data = await response.json();
    return data.user;
}
```

---

## Enforcement Modes

### HIDE Mode

**Used for**: Most permissions (PAGE_ACCESS and ACTION_EXECUTE)

**Behavior**: Element is completely removed from DOM if user lacks permission

**Example**:
```html
{% if can('action_clone_dta') %}
<button id="clone-btn">Clone</button>
{% endif %}
```

**Result**: If user lacks `action_clone_dta`, the button doesn't render at all.

### DISABLE Mode

**Used for**: `action_edit_dta` (Edit DTA permission)

**Behavior**: Element is visible but inactive/disabled if user lacks permission

**Example**:
```html
<button id="edit-btn" 
        {% if not can('action_edit_dta') %}
        disabled 
        title="You do not have permission to edit DTAs"
        {% endif %}>
    Edit
</button>
```

**Result**: If user lacks `action_edit_dta`, button shows but is grayed out with tooltip.

**Rationale**: DISABLE mode for edit is used to provide progressive disclosure - users can see that editing exists but requires specific permissions.

---

## Adding New Permissions

### 1. Define Permission in SQL

Edit `sql/setup_cdm_app_permissions.sql`:

```sql
-- Add new permission
INSERT INTO md_permissions (permission_id, permission_type, permission_key, enforcement_mode, description, disabled_message) VALUES
('perm_action_export_dta', 'ACTION_EXECUTE', 'action_export_dta', 'HIDE', 'Export DTA to file', NULL);
```

### 2. Assign to Groups

```sql
-- Assign to JNJ_DAE group
INSERT INTO md_group_permissions (group_permission_id, group_id, permission_id)
SELECT uuid(), 'group_jnj_dae', 'perm_action_export_dta';
```

### 3. Run Job

```bash
databricks jobs run-now --job-name job_cdm_app_permissions
```

### 4. Use in Templates

```html
{% if can('action_export_dta') %}
<button onclick="exportDTA()">Export</button>
{% endif %}
```

---

## Adding New User Groups

### 1. Define Group in SQL

Edit `sql/setup_cdm_app_permissions.sql`:

```sql
-- Add new group
INSERT INTO md_user_groups (group_id, group_name, description, is_active) VALUES
('group_quality_assurance', 'QUALITY_ASSURANCE', 'QA team - Review and validate DTAs', true);
```

### 2. Assign Permissions

```sql
-- Assign permissions to new group
INSERT INTO md_group_permissions (group_permission_id, group_id, permission_id)
SELECT uuid(), 'group_quality_assurance', 'perm_page_dashboard'
UNION ALL
SELECT uuid(), 'group_quality_assurance', 'perm_page_dta_viewer'
UNION ALL
SELECT uuid(), 'group_quality_assurance', 'perm_action_comment';
```

### 3. Create Users and Assign

```sql
-- Create QA users
INSERT INTO md_users (user_id, email, display_name, vendor_id, is_active, created_ts, last_updated_ts)
SELECT uuid(), 'qa.user@jnj.com', 'QA User', NULL, true, current_timestamp(), current_timestamp();

-- Assign to group
INSERT INTO md_user_group_memberships (membership_id, user_id, group_id, joined_ts)
SELECT uuid(), user_id, 'group_quality_assurance', current_timestamp()
FROM md_users WHERE email = 'qa.user@jnj.com';
```

### 4. Run Job

```bash
databricks jobs run-now --job-name job_cdm_app_permissions
```

---

## Related Documentation

- [01_dta_job_architecture_design.readme.md](./01_dta_job_architecture_design.readme.md) - Job architecture including `job_cdm_app_permissions`
- [06_dta_workflow_design.readme.md](./06_dta_workflow_design.readme.md) - User groups and approval roles
- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - Permission table schemas
- `sql/setup_cdm_app_permissions.sql` - SQL script for permissions setup
- `resources/sql/common/jobs/job_cdm_app_permissions.job.yml` - Permissions job definition
# Genie AI Integration Design

---

## Overview

### What is Databricks AI/BI Genie?

Databricks AI/BI Genie is a natural language interface that allows users to query data using conversational questions instead of writing SQL. Key capabilities include:

| Capability | Description |
|------------|-------------|
| **Natural Language Queries** | Users ask questions in plain English; Genie translates to SQL |
| **Unity Catalog Integration** | Queries tables directly from Unity Catalog with permission enforcement |
| **Conversation Context** | Supports follow-up questions within a conversation |
| **SQL Generation** | Generates and displays the SQL query for transparency |
| **Result Formatting** | Returns results as structured tables or markdown |

### Purpose in DTA Builder

The DTA Builder UI integrates Genie to enable:

- **DTA Discovery**: Search for existing DTAs using natural language (e.g., "Find all Labs DTAs from LabCorp")
- **Version Lookup**: Query version history and approval status
- **Template Search**: Find approved DTAs to use as templates for new work
- **Activity Tracking**: Query recent changes and user activity

### Genie Space Configuration

A Genie Space defines the tables, instructions, and examples that guide Genie's behavior. For DTA Builder:

| Component | Description |
|-----------|-------------|
| **Tables** | Gold layer tables (`dta`, `dta_workflow`, `md_dta_transfer_variables`, etc.) |
| **Instructions** | Domain-specific guidance on DTA terminology and query patterns |
| **Sample Questions** | Representative questions users might ask |
| **SQL Examples** | Parameterized queries that demonstrate correct patterns |

---

## Tables in Genie Space

The following **Gold layer tables** are included in the Genie Space (Bronze tables are excluded as they're for ingestion only):

| Table | Purpose | Key Columns |
|-------|---------|-------------|
| `gold_md.dta` | Core DTA entity | `dta_id`, `dta_number`, `trial_id`, `data_stream_type`, `data_provider_name`, `status`, `workflow_state` |
| `gold_md.dta_workflow` | Approval workflow tracking | `dta_workflow_id`, `dta_id`, `workflow_iteration`, `workflow_status` |
| `gold_md.dta_approval_task` | Individual approval tasks | `approval_task_id`, `dta_workflow_id`, `approver_role`, `approval_status` |
| `gold_md.dta_activity_log` | Full audit history | `activity_id`, `dta_id`, `activity_category`, `activity_type`, `performed_by_principal` |
| `gold_md.md_version_registry` | Central version registry | `version`, `dta_id`, `version_type`, `library_type`, `is_latest_major`, `record_count` |
| `gold_md.md_dta_transfer_variables` | Approved transfer variables | `dta_id`, `transfer_variable_name`, `format`, `is_current` |
| `gold_md.md_dta_vendor_test_concepts` | Approved test concepts | `test_concept_id`, `dta_id`, `test_concept_reference`, `transfer_tuple_map` |

**Table Discovery**: The export job dynamically discovers all Gold layer tables using `SHOW TABLES IN {catalog}.gold_md`, ensuring the Genie Space stays current as new tables are added.

---

## Genie Instructions Text

The following instructions are provided to Genie to guide its understanding of DTAs and query patterns:

```text
# DTA Genie Space Instructions

## Purpose
Help JNJ Data Acquisition Experts (DAEs) and Vendors search for, compare, and create Data Transfer Agreements (DTAs) based on approved versions or templates.

## Required Search Criteria - ALWAYS ASK FOR CLARIFICATION

When users ask about DTAs but don't specify required filters, you MUST ask:
"To find relevant DTAs, please specify:
- The vendor name (data_provider_name), AND
- Either the data stream type (e.g., Labs, ECG, Biomarkers) OR trial ID (e.g., VAC18193RSV3001)"

Required filter combinations:
1. data_provider_name + data_stream_type
2. data_provider_name + trial_id

## Key Business Terms

| Term | Meaning | SQL Filter |
|------|---------|------------|
| Active DTA | Approved and in production | status = 'ACTIVE' AND workflow_state = 'APPROVED' |
| Draft DTA | Work in progress | status = 'DRAFT' |
| Pending Approval | Awaiting reviewer action | workflow_state = 'IN_REVIEW' |
| Latest Version | Most recent approved | is_current = true |
| DTA Template | Canonical template | version_type = 'DTA_TEMPLATE' |

## DTA Workflow States

- **NOT_STARTED**: Draft created, not yet submitted for approval
- **IN_REVIEW**: Submitted, awaiting approvals from JNJ DAE, Vendor, or Librarian
- **APPROVED**: All required approvals complete
- **REJECTED**: Returned for revision with comments

## Approver Roles

- **jnj_dae**: J&J Data Acquisition Expert - internal reviewer
- **vendor**: External data provider representative
- **librarian**: J&J Metadata Librarian - for template promotion

## Common Query Patterns

### Find DTAs by vendor
Filter: data_provider_name LIKE '%{vendor}%'

### Find DTAs by trial
Filter: trial_id LIKE '%{trial}%'

### Find DTAs by data stream
Filter: data_stream_type = '{stream}'

### Latest N versions
ORDER BY created_ts DESC LIMIT N

### DTAs modified by user
Join dta_activity_log and filter: performed_by_principal LIKE '%{email}%'

### Similar DTAs for cloning
Match on data_stream_type with similar data_provider_name or trial_id

## Data Stream Types

Common values: Labs, ECG, Adverse Events, Biomarkers, Demographics, Vital Signs, PF (Patient Flow), Medical History

## Table Relationships

```
dta (core entity)
  |-- dta_workflow (1:N by dta_id)
  |     |-- dta_approval_task (1:N by dta_workflow_id)
  |-- md_version_registry (1:N by dta_id)
  |-- md_dta_transfer_variables (1:N by dta_id, filter is_current=true)
  |-- md_dta_vendor_test_concepts (1:N by dta_id, filter is_current=true)
  |-- dta_activity_log (1:N by dta_id)
```

## Important Notes

1. Always filter transfer_variables and test_concepts by is_current = true for latest versions
2. Use UPPER() or ILIKE for case-insensitive matching on vendor/trial names
3. DTA numbers are sequential: DTA001, DTA002, etc.
4. Version format: 1.0-DTA001-v1.0 (approved) or 1.0-DTA001-draft1 (draft)
```

---

## Training SQL Queries

Genie is trained with the following **6 parameterized SQL queries**. All queries:
- Filter for `status IN ('ACTIVE', 'PROMOTED')` to show approved DTAs only
- Include metadata counts from `md_version_registry` for each library type
- Use LEFT JOIN to ensure DTAs display even if they have no metadata yet

### Query 1: Find All Approved DTAs

**Question**: "Find all approved DTAs"

```sql
SELECT d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
       d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes,
       MAX(CASE WHEN vr.library_type = 'transfer_variables' THEN vr.record_count ELSE 0 END) AS transfer_variables_count,
       MAX(CASE WHEN vr.library_type = 'test_concepts' THEN vr.record_count ELSE 0 END) AS test_concepts_count,
       MAX(CASE WHEN vr.library_type = 'codelists' THEN vr.record_count ELSE 0 END) AS codelists_count,
       MAX(CASE WHEN vr.library_type = 'operational_agreements' THEN vr.record_count ELSE 0 END) AS operational_agreements_count,
       MAX(CASE WHEN vr.library_type = 'visits_timepoints' THEN vr.record_count ELSE 0 END) AS visits_timepoints_count,
       MAX(CASE WHEN vr.library_type = 'data_ingestion_params' THEN vr.record_count ELSE 0 END) AS data_ingestion_params_count
FROM {catalog}.gold_md.dta d
LEFT JOIN {catalog}.gold_md.md_version_registry vr ON d.dta_id = vr.dta_id AND vr.status = d.status
WHERE d.status IN ('ACTIVE', 'PROMOTED')
GROUP BY d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
         d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes
ORDER BY d.last_updated_ts DESC
LIMIT 20
```

### Query 2: Show DTAs by Vendor and Data Stream

**Question**: "Show DTAs for vendor :vendor_name and data stream :data_stream"

**Parameters**: `:vendor_name`, `:data_stream`

```sql
SELECT d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
       d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes,
       MAX(CASE WHEN vr.library_type = 'transfer_variables' THEN vr.record_count ELSE 0 END) AS transfer_variables_count,
       MAX(CASE WHEN vr.library_type = 'test_concepts' THEN vr.record_count ELSE 0 END) AS test_concepts_count,
       MAX(CASE WHEN vr.library_type = 'codelists' THEN vr.record_count ELSE 0 END) AS codelists_count,
       MAX(CASE WHEN vr.library_type = 'operational_agreements' THEN vr.record_count ELSE 0 END) AS operational_agreements_count,
       MAX(CASE WHEN vr.library_type = 'visits_timepoints' THEN vr.record_count ELSE 0 END) AS visits_timepoints_count,
       MAX(CASE WHEN vr.library_type = 'data_ingestion_params' THEN vr.record_count ELSE 0 END) AS data_ingestion_params_count
FROM {catalog}.gold_md.dta d
LEFT JOIN {catalog}.gold_md.md_version_registry vr ON d.dta_id = vr.dta_id AND vr.status = d.status
WHERE d.status IN ('ACTIVE', 'PROMOTED')
  AND UPPER(d.data_provider_name) LIKE UPPER(CONCAT('%', :vendor_name, '%'))
  AND UPPER(d.data_stream_type) LIKE UPPER(CONCAT('%', :data_stream, '%'))
GROUP BY d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
         d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes
ORDER BY d.last_updated_ts DESC
```

### Query 3: Show DTAs by Trial

**Question**: "Show all DTAs for trial :trial_id"

**Parameters**: `:trial_id`

```sql
SELECT d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
       d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes,
       MAX(CASE WHEN vr.library_type = 'transfer_variables' THEN vr.record_count ELSE 0 END) AS transfer_variables_count,
       MAX(CASE WHEN vr.library_type = 'test_concepts' THEN vr.record_count ELSE 0 END) AS test_concepts_count,
       MAX(CASE WHEN vr.library_type = 'codelists' THEN vr.record_count ELSE 0 END) AS codelists_count,
       MAX(CASE WHEN vr.library_type = 'operational_agreements' THEN vr.record_count ELSE 0 END) AS operational_agreements_count,
       MAX(CASE WHEN vr.library_type = 'visits_timepoints' THEN vr.record_count ELSE 0 END) AS visits_timepoints_count,
       MAX(CASE WHEN vr.library_type = 'data_ingestion_params' THEN vr.record_count ELSE 0 END) AS data_ingestion_params_count
FROM {catalog}.gold_md.dta d
LEFT JOIN {catalog}.gold_md.md_version_registry vr ON d.dta_id = vr.dta_id AND vr.status = d.status
WHERE d.status IN ('ACTIVE', 'PROMOTED')
  AND UPPER(d.trial_id) LIKE UPPER(CONCAT('%', :trial_id, '%'))
GROUP BY d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
         d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes
ORDER BY d.data_stream_type, d.data_provider_name
```

### Query 4: Show DTAs by User

**Question**: "Show DTAs created or modified by user :user_email"

**Parameters**: `:user_email`

```sql
SELECT DISTINCT d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
       d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes,
       MAX(CASE WHEN vr.library_type = 'transfer_variables' THEN vr.record_count ELSE 0 END) AS transfer_variables_count,
       MAX(CASE WHEN vr.library_type = 'test_concepts' THEN vr.record_count ELSE 0 END) AS test_concepts_count,
       MAX(CASE WHEN vr.library_type = 'codelists' THEN vr.record_count ELSE 0 END) AS codelists_count,
       MAX(CASE WHEN vr.library_type = 'operational_agreements' THEN vr.record_count ELSE 0 END) AS operational_agreements_count,
       MAX(CASE WHEN vr.library_type = 'visits_timepoints' THEN vr.record_count ELSE 0 END) AS visits_timepoints_count,
       MAX(CASE WHEN vr.library_type = 'data_ingestion_params' THEN vr.record_count ELSE 0 END) AS data_ingestion_params_count
FROM {catalog}.gold_md.dta d
JOIN {catalog}.gold_md.dta_activity_log a ON d.dta_id = a.dta_id
LEFT JOIN {catalog}.gold_md.md_version_registry vr ON d.dta_id = vr.dta_id AND vr.status = d.status
WHERE d.status IN ('ACTIVE', 'PROMOTED')
  AND UPPER(a.performed_by_principal) LIKE UPPER(CONCAT('%', :user_email, '%'))
GROUP BY d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
         d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes
ORDER BY d.dta_number
```

### Query 5: Recently Updated DTAs

**Question**: "What DTAs were updated in the last 30 days?"

```sql
SELECT d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
       d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes,
       MAX(CASE WHEN vr.library_type = 'transfer_variables' THEN vr.record_count ELSE 0 END) AS transfer_variables_count,
       MAX(CASE WHEN vr.library_type = 'test_concepts' THEN vr.record_count ELSE 0 END) AS test_concepts_count,
       MAX(CASE WHEN vr.library_type = 'codelists' THEN vr.record_count ELSE 0 END) AS codelists_count,
       MAX(CASE WHEN vr.library_type = 'operational_agreements' THEN vr.record_count ELSE 0 END) AS operational_agreements_count,
       MAX(CASE WHEN vr.library_type = 'visits_timepoints' THEN vr.record_count ELSE 0 END) AS visits_timepoints_count,
       MAX(CASE WHEN vr.library_type = 'data_ingestion_params' THEN vr.record_count ELSE 0 END) AS data_ingestion_params_count
FROM {catalog}.gold_md.dta d
LEFT JOIN {catalog}.gold_md.md_version_registry vr ON d.dta_id = vr.dta_id AND vr.status = d.status
WHERE d.status IN ('ACTIVE', 'PROMOTED')
  AND d.last_updated_ts >= DATE_ADD(CURRENT_DATE(), -30)
GROUP BY d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
         d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes
ORDER BY d.last_updated_ts DESC
LIMIT 20
```

### Query 6: DTAs from Templates

**Question**: "Show DTAs created from a specific vendor's DTA template"

```sql
SELECT DISTINCT d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
       d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes,
       MAX(CASE WHEN vr2.library_type = 'transfer_variables' THEN vr2.record_count ELSE 0 END) AS transfer_variables_count,
       MAX(CASE WHEN vr2.library_type = 'test_concepts' THEN vr2.record_count ELSE 0 END) AS test_concepts_count,
       MAX(CASE WHEN vr2.library_type = 'codelists' THEN vr2.record_count ELSE 0 END) AS codelists_count,
       MAX(CASE WHEN vr2.library_type = 'operational_agreements' THEN vr2.record_count ELSE 0 END) AS operational_agreements_count,
       MAX(CASE WHEN vr2.library_type = 'visits_timepoints' THEN vr2.record_count ELSE 0 END) AS visits_timepoints_count,
       MAX(CASE WHEN vr2.library_type = 'data_ingestion_params' THEN vr2.record_count ELSE 0 END) AS data_ingestion_params_count
FROM {catalog}.gold_md.md_version_registry vr
INNER JOIN {catalog}.gold_md.dta d ON d.data_provider_name = vr.data_provider_name AND d.data_stream_type = vr.data_stream_type
LEFT JOIN {catalog}.gold_md.md_version_registry vr2 ON d.dta_id = vr2.dta_id AND vr2.status = d.status
WHERE vr.version_type = 'DTA_TEMPLATE' AND vr.status = 'PROMOTED'
  AND d.status IN ('ACTIVE', 'PROMOTED')
GROUP BY d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type, d.data_provider_name,
         d.version, d.workflow_state, d.status, d.created_ts, d.last_updated_ts, d.notes
ORDER BY d.dta_number
```

---

## Sample Questions

These **6 sample questions** are displayed in the Genie UI as quick-start prompts:

1. "Find all approved DTAs"
2. "Show DTAs for vendor :vendor_name and data stream :data_stream"
3. "Show all DTAs for trial :trial_id"
4. "Show DTAs created or modified by user :user_email"
5. "What DTAs were updated in the last 30 days?"
6. "Show DTAs created from a specific vendor's DTA template"

---

## Column Configuration Strategy

For each table in the Genie Space, columns are configured with two settings:

| Setting | Applies To | Purpose |
|---------|------------|---------|
| `get_example_values: true` | **All columns** | Genie fetches sample values to understand column content |
| `build_value_dictionary: true` | **STRING columns only** | Creates lookup dictionary for categorical columns |

**Excluded from dictionary**: TIMESTAMP, BINARY, STRUCT, ARRAY, MAP, DOUBLE, FLOAT, INT, BIGINT, DECIMAL, BOOLEAN

**Column sorting**: All columns are sorted alphabetically by `column_name` (Genie API requirement).

**Example configuration**:
```json
{
  "column_name": "data_stream_type",
  "get_example_values": true,
  "build_value_dictionary": true
}
```

---

## Asset Generation Job

The `job_cdm_export_genie_assets` job dynamically generates all assets needed to configure and update a Genie space.

### Job Definition

**File**: `resources/data_engineering/clinical_data_standards/jobs/job_cdm_export_genie_assets.job.yml`

| Parameter | Default | Description |
|-----------|---------|-------------|
| `source_root` | `test` | Output subfolder in volumes (e.g., `test`, `prod`) |
| `catalog_override` | `""` | Optional catalog override |

### Job Workflow

The job runs **3 tasks** in sequence:

| Task | Notebook | Purpose | Dependencies |
|------|----------|---------|--------------|
| `setup` | `nb_setup` | Load configuration and validate parameters | None |
| `export_genie_assets` | `nb_export_genie_assets` | Discover tables, generate all component files | `setup` |
| `generate_serialized_space` | `nb_generate_serialized_space` | Assemble final `serialized_space.json` | `export_genie_assets` |

### Task 1: Setup

- Loads global configuration (catalog, schemas)
- Validates job parameters
- Sets task values for downstream tasks

### Task 2: Export Genie Assets

**Notebook**: `notebooks/data_engineering/clinical_data_standards/jobs/nb_export_genie_assets.ipynb`

**Key Operations**:

1. **Discover Tables**: Uses `SHOW TABLES` to find all Bronze and Gold tables
2. **Extract Metadata**: Reads table/column descriptions using `DESCRIBE TABLE EXTENDED`
3. **Generate SQL Comments**: Creates `add_table_comments.sql` with rich descriptions
4. **Generate Instructions**: Creates `genie_instructions.txt` with DTA-specific guidance
5. **Generate Example Queries**: Creates `example_queries.sql` with 6 parameterized queries
6. **Generate JSON Components**: Creates 4 JSON files for `serialized_space` assembly

**Column Comment Templates**:
The notebook includes 50+ pre-defined column comment templates for common DTA fields (e.g., `dta_id`, `trial_id`, `data_stream_type`). These provide rich descriptions when existing comments are missing.

**Table Comment Templates**:
Pre-defined descriptions for 10 core tables (e.g., `dta`, `dta_workflow`, `md_version_registry`) to guide Genie's understanding.

### Task 3: Generate Serialized Space

**Notebook**: `notebooks/data_engineering/clinical_data_standards/jobs/nb_generate_serialized_space.ipynb`

**Operations**:
1. Reads all 4 component JSON files
2. Assembles them into the complete `serialized_space.json` structure:

```json
{
  "version": 1,
  "config": {
    "sample_questions": [...]
  },
  "data_sources": {
    "tables": [...]
  },
  "instructions": {
    "text_instructions": [...],
    "example_question_sqls": [...]
  }
}
```

### Output Files

All files are written to:
```
/Volumes/{catalog}/bronze_md/{volume}/{source_root}/exports/genie/
```

**Example path**: `/Volumes/aira_test/bronze_md/clinical_data_standards/test/exports/genie/`

| File | Purpose | Generated By |
|------|---------|--------------|
| `sql/add_table_comments.sql` | Table and column descriptions | Task 2 (Cell 7) |
| `sql/example_queries.sql` | 6 parameterized training queries | Task 2 (Cell 9) |
| `genie_instructions.txt` | Human-readable instructions | Task 2 (Cell 8) |
| `components/data_sources.json` | Tables with column configs | Task 2 (Cell 10) |
| `components/sample_questions.json` | 6 quick-start questions | Task 2 (Cell 11) |
| `components/example_queries.json` | Question/SQL pairs | Task 2 (Cell 11) |
| `components/text_instructions.json` | Instructions for API | Task 2 (Cell 12) |
| `serialized_space.json` | **Complete space configuration** | Task 3 |
| `export_manifest.json` | Export metadata | Task 2 (Cell 13) |

### Running the Job

**Via Databricks UI:**
1. Navigate to **Workflows** → **Jobs**
2. Find `job_cdm_export_genie_assets`
3. Click **Run Now**
4. Set parameters:
   - `source_root`: Output folder (e.g., `test` or `prod`)

**Via Test Job:**
Run `job_test_cdm_export_genie_assets` which triggers the main job with test parameters.

### Updating a Genie Space

After generating assets, use the `nb_test_genie_api.ipynb` notebook to update an existing Genie space:

1. Reads `serialized_space.json` from the exports folder
2. Calls `PATCH /api/2.0/genie/spaces/{space_id}` with the configuration
3. Updates tables, instructions, sample questions, and SQL examples

---

## UI Design

### Conversational UI Flow Diagram

![Genie Conversational UI Flow](./diagrams/09_dta_genie_conversational_ui.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/09_dta_genie_conversational_ui.drawio)

### Search Mode Toggle

The DTA Builder UI provides two search modes:

```
[○ Standard Search]  [● AI Search with Genie] ✨
```

| Mode | Description |
|------|-------------|
| **Standard Search** | Traditional SQL-based search with field filters |
| **AI Search with Genie** | Natural language queries powered by Genie |

### Genie Conversation Panel

The conversational UI provides a chat-like experience with support for follow-up questions:

| Component | Description |
|-----------|-------------|
| **Chat History** | Scrollable history of user questions and Genie responses |
| **User Messages** | Displayed as blue bubbles on the right |
| **Genie Responses** | Displayed as gray bubbles on the left |
| **Clarification Requests** | Highlighted with amber border when Genie needs more details |
| **Follow-up Input** | Input box to continue the conversation |
| **Generated SQL** | Collapsible section showing the SQL query |
| **New Conversation** | Button to start a fresh conversation |

### Response Type Detection

The API automatically detects the type of response:

| Type | Detection Criteria | UI Behavior |
|------|-------------------|-------------|
| **DATA** | Response contains DTA results | Render DTA cards below conversation |
| **CLARIFICATION** | Response contains question patterns (?, "please specify", "which") | Highlight message, focus follow-up input |
| **INFO** | Text response without actionable data | Display message only |
| **EMPTY** | No meaningful response | Show "no results" message |

### User Experience Flow

**Initial Search:**
1. User selects **AI Search with Genie** toggle
2. User types natural language question
3. User clicks **Ask Genie**
4. Conversation panel opens with user message
5. Loading indicator shows while Genie processes

**Response Handling:**
- **If clarification needed**: Genie asks for more details, follow-up input is focused
- **If data returned**: DTA cards render below the conversation, follow-up available
- **If informational**: Message displayed, user can ask follow-ups

**Follow-up Questions:**
1. User types in follow-up input
2. Clicks **Send** or presses Enter
3. Message added to chat history
4. Genie processes using existing conversation context
5. Response added to history with appropriate formatting

### Error Handling

| Scenario | User Experience |
|----------|-----------------|
| Genie not configured | Toggle disabled with tooltip |
| Query too short | Prompt for more detail |
| No results | Suggestion to refine query |
| Timeout | Error message with retry suggestion |
| API error | Error displayed in chat history |

### JavaScript State Management

The conversational UI maintains state across interactions:

```javascript
let genieState = {
  conversationId: null,   // For follow-up questions
  messages: [],           // Chat history
  lastResponseType: null, // DATA, CLARIFICATION, INFO
  isLoading: false        // Prevent duplicate requests
};
```

### API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/genie/search` | GET | Start new conversation with initial question |
| `/api/genie/followup` | POST | Continue conversation with follow-up question |
| `/api/genie/status` | GET | Check if Genie is configured |

---

## Best Practices for Designing Genie Spaces

### Table Selection

- **Focus on Gold layer**: Include core business tables (`dta`, `dta_workflow`, `md_dta_transfer_variables`)
- **Include Bronze for context**: Add `md_file_history` for document lineage
- **Limit scope**: Too many tables can confuse Genie; start with essential tables
- **Add related tables**: Include lookup tables needed for JOINs

### Table and Column Comments

Rich descriptions help Genie understand data semantics:

- **Table comments**: Explain the purpose and business context
- **Column comments**: Describe what each column contains, valid values, relationships
- **Use `add_table_comments.sql`**: Generated automatically by the export job
- **Include examples**: "data_stream_type contains values like Labs, ECG, Biomarkers"

### Instructions

Write focused, domain-specific instructions:

- **Define terminology**: Explain what DTA, vendor, data stream mean
- **Specify required filters**: "Always ask for vendor and data stream or trial"
- **Clarify relationships**: Explain how tables relate (e.g., dta → dta_workflow)
- **Set expectations**: Define what questions the space can and cannot answer

### Sample Questions

Provide representative questions users might ask:

- Start with common use cases
- Include variations (by vendor, by trial, by status)
- Cover different query types (search, count, latest, history)
- Keep questions natural and conversational

### SQL Examples

Train Genie with parameterized queries:

- **Cover key patterns**: Filtering, joining, aggregating
- **Use consistent style**: Same column selection, JOIN patterns
- **Include comments**: Explain what each query does
- **Match to sample questions**: Each example should answer a sample question

### Column Configurations

Configure column behavior in `data_sources.json`:

| Setting | Purpose |
|---------|---------|
| `get_example_values: true` | Genie fetches sample values to understand column content |
| `build_value_dictionary: true` | Creates lookup for categorical columns (STRING types) |

**Note**: Sort columns alphabetically (Genie API requirement).

### Iterative Refinement

1. **Start simple**: Begin with core tables and basic instructions
2. **Monitor usage**: Review questions in Genie's Monitoring tab
3. **Identify gaps**: Note queries that fail or return wrong results
4. **Refine instructions**: Add clarifications for misunderstood queries
5. **Add examples**: Create SQL examples for problematic patterns
6. **Test variations**: Try different phrasings of the same question
7. **Collect feedback**: Use upvote/downvote to identify improvements

### Required Search Criteria

Configure Genie to ask clarifying questions when context is missing:

| Required Combination | Example |
|---------------------|---------|
| Vendor + Data Stream | "Show me Labs DTAs from LabCorp" |
| Vendor + Trial | "Find DTAs for Covance in trial VAC18193" |

**Instruction to add**: "To find relevant DTAs, please specify the vendor name AND either the data stream type (Labs, ECG, Biomarkers) OR trial ID."

---

## Related Documentation

- [01_dta_job_architecture_design.readme.md](./01_dta_job_architecture_design.readme.md) - Job pipeline architecture including `job_cdm_export_genie_assets`
- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - Table schemas used by Genie
- [07_dta_databricks_ai_design.readme.md](./07_dta_databricks_ai_design.readme.md) - Databricks AI capabilities (Model Serving vs. Genie)
- [Databricks Genie Best Practices](https://docs.databricks.com/aws/en/genie/best-practices) - Official documentation

---
# Protocol Document Processing Design

## Overview

The Protocol Document Processing feature extends the Clinical Data Standards platform to extract structured Schedule of Activities (SoA) data from clinical trial protocol documents. This enables automated extraction of visits, procedures, and their mappings from complex PDF tables.

### Problem Statement

Protocol documents contain complex Schedule of Activities tables with:

- **Guide tables** that reference detailed tables (Table 1 → Tables 2-11)
- **Nested multi-level headers** (Phase → Cycle → Day)
- **Footnotes** defining timing windows and conditions
- **Cross-references** to other tables, sections, and appendices
- **Variable orientations** (visits as columns OR rows)

### Solution

A multi-phase LLM-powered extraction pipeline that:

1. **Classifies** table types to determine processing strategy
2. **Extracts** visits, procedures, and footnotes using specialized prompts
3. **Maps** procedure-visit relationships with footnote conditions
4. **Stores** results in silver draft tables for user review
5. **Promotes** approved data to gold tables

---

## Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| SoA Extraction Pipeline | End-to-end extraction flow showing all phases | [PNG](./diagrams/10_dta_soa_extraction_pipeline.drawio.png) | [Draw.io](./diagrams/10_dta_soa_extraction_pipeline.drawio) |
| Table Classification Tree | Decision tree for identifying table types | [PNG](./diagrams/10_dta_table_classification_tree.drawio.png) | [Draw.io](./diagrams/10_dta_table_classification_tree.drawio) |
| SoA Data Model | ERD showing draft and gold tables with relationships | [PNG](./diagrams/10_dta_soa_data_model.drawio.png) | [Draw.io](./diagrams/10_dta_soa_data_model.drawio) |
| Prompt Orchestration | Multi-prompt sequence and dependencies | [PNG](./diagrams/10_dta_prompt_orchestration.drawio.png) | [Draw.io](./diagrams/10_dta_prompt_orchestration.drawio) |
| UI Workflow | User interaction for review and approval | [PNG](./diagrams/10_dta_ui_workflow.drawio.png) | [Draw.io](./diagrams/10_dta_ui_workflow.drawio) |

### SoA Extraction Pipeline

![SoA Extraction Pipeline](./diagrams/10_dta_soa_extraction_pipeline.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/10_dta_soa_extraction_pipeline.drawio)

### Table Classification Tree

![Table Classification Tree](./diagrams/10_dta_table_classification_tree.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/10_dta_table_classification_tree.drawio)

### SoA Data Model

![SoA Data Model](./diagrams/10_dta_soa_data_model.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/10_dta_soa_data_model.drawio)

### Prompt Orchestration

![Prompt Orchestration](./diagrams/10_dta_prompt_orchestration.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/10_dta_prompt_orchestration.drawio)

### UI Workflow

![UI Workflow](./diagrams/10_dta_ui_workflow.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/10_dta_ui_workflow.drawio)

---

## Architecture

### Extraction Pipeline Phases

The extraction pipeline operates in three main phases:

#### Phase 1: Table Analysis

| Step | Purpose | Output |
|------|---------|--------|
| Identify Table Type | Classify as GUIDE_TABLE, DETAILED_SOA, DETAILED_SOA_TRANSPOSED, or ASSESSMENT_TABLE | `table_type`, `table_id` |
| Detect Orientation | Determine if visits are columns or rows | `orientation` |
| Extract Cross-References | Find references to other tables (e.g., "See Table 18") | `referenced_tables[]` |

#### Phase 2: Structure Extraction

| Step | Purpose | Output |
|------|---------|--------|
| Extract Visits | Parse column/row headers for visit identifiers | `visits[]` with day, window, phase |
| Extract Procedures | Parse row/column headers for procedure names | `procedures[]` with category |
| Extract Footnotes | Parse footnote markers and their definitions | `footnotes[]` with condition type |

#### Phase 3: Mapping & Storage

| Step | Purpose | Output |
|------|---------|--------|
| Map Procedures to Visits | Create intersection matrix with X markers | `mappings[]` with footnote refs |
| Resolve Conditions | Link footnote markers to mapping conditions | `condition_text` per mapping |
| Write to Silver | Store in draft tables for review | Draft table rows |

### Data Flow

```
┌─────────────────────┐
│ md_protocol_        │
│ document_sections   │  SoA tables extracted by Protocol Processor
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Phase 1: Classify  │  Prompt 1: Table Type Classification
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Phase 2: Extract   │  Prompts 2-4: Visits, Procedures, Mappings
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Phase 3: Footnotes │  Prompt 5: Footnote Extraction
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Silver Draft       │  md_study_visits_draft, md_study_procedures_draft,
│  Tables             │  md_procedure_visit_mappings_draft, md_soa_footnotes_draft
└─────────┬───────────┘
          │
          ▼ (User Approval)
┌─────────────────────┐
│  Gold Tables        │  md_study_visits, md_study_procedures,
│                     │  md_procedure_visit_mappings, md_soa_footnotes
└─────────────────────┘
```

---

## Table Type Classification

### Table Types

The extraction pipeline identifies four distinct table types:

| Type | Description | Characteristics | Processing Strategy |
|------|-------------|-----------------|---------------------|
| **GUIDE_TABLE** | Index table that references other tables | Cells contain "Table X" references, high-level summary | Extract references, do not process visits/procedures |
| **DETAILED_SOA** | Standard SoA with visits as columns | Visits in column headers, procedures in rows | Standard extraction with all 5 prompts |
| **DETAILED_SOA_TRANSPOSED** | Inverted SoA with visits as rows | Visits in row headers, procedures in columns | Transposed extraction, swap row/column logic |
| **ASSESSMENT_TABLE** | Focused table for specific assessments | PK sampling, biomarkers, specific procedures only | Extract as sub-schedule, link to parent SoA |

### Classification Decision Tree

```
                    ┌──────────────────────────────┐
                    │ Does table contain           │
                    │ "Table X" cell references?   │
                    └──────────────┬───────────────┘
                                   │
                    ┌──────────────┴──────────────┐
                    ▼                             ▼
                  YES                            NO
                    │                             │
                    ▼                             ▼
            ┌───────────────┐         ┌─────────────────────────┐
            │ GUIDE_TABLE   │         │ Are visits in column    │
            │               │         │ headers?                │
            └───────────────┘         └───────────┬─────────────┘
                                                  │
                                   ┌──────────────┴──────────────┐
                                   ▼                             ▼
                                 YES                            NO
                                   │                             │
                                   ▼                             ▼
                    ┌───────────────────────┐    ┌────────────────────────────┐
                    │ Is it a full SoA or   │    │ DETAILED_SOA_TRANSPOSED    │
                    │ focused assessment?   │    │                            │
                    └───────────┬───────────┘    └────────────────────────────┘
                                │
                 ┌──────────────┴──────────────┐
                 ▼                             ▼
            Full SoA                    Assessment Focus
                 │                             │
                 ▼                             ▼
        ┌───────────────┐           ┌──────────────────┐
        │ DETAILED_SOA  │           │ ASSESSMENT_TABLE │
        └───────────────┘           └──────────────────┘
```

### Example Table Types

#### GUIDE_TABLE Example

| Assessment | Screening | Treatment | Follow-up |
|------------|-----------|-----------|-----------|
| Screening Assessments | Table 2 | - | - |
| Efficacy Assessments | - | Table 3 | Table 4 |
| Safety Assessments | Table 5 | Table 6 | Table 7 |
| PK/Biomarker Assessments | - | Table 8 | - |

#### DETAILED_SOA Example

| Procedure | Screening | C1D1 | C1D8 | C1D15 | C2D1 | EOT |
|-----------|-----------|------|------|-------|------|-----|
| Informed consent | X | | | | | |
| Medical history | X | | | | | |
| Vital signs | X | X | X | X | X | X |
| Blood draw | X | X | | X | X | X |

---

## LLM Prompts

### Prompt Configuration

All prompts are configured in `clinical_data_standards.yaml` under the `protocol_processor.ai_processing.soa_extraction` section.

### Model Serving Configuration

```yaml
services:
  # Generic LLM Entity Extractor for SoA
  soa_entity_extractor:
    type: "model_serving"
    endpoint_name: "databricks-meta-llama-3-1-70b-instruct"
    max_tokens: 4096
    temperature: 0.1
    timeout_seconds: 180
    retry_attempts: 3
    description: "LLM for Schedule of Activities entity extraction"
```

### Supported Model Endpoints

| Endpoint | Context | Cost | Best For |
|----------|---------|------|----------|
| `databricks-meta-llama-3-1-70b-instruct` | 128K | $ | Default, cost-effective |
| `databricks-meta-llama-3-1-405b-instruct` | 128K | $$ | Complex tables |
| `databricks-meta-llama-3-3-70b-instruct` | 128K | $ | Latest Llama |
| `databricks-dbrx-instruct` | 32K | $$ | Databricks native |

---

### Prompt 1: Table Type Classification

**Purpose**: Classify the table to determine processing strategy.

**System Prompt**:

```
You are analyzing a clinical trial Schedule of Activities table.

Classify this table into ONE of these types:
1. GUIDE_TABLE - An index/navigation table that references other tables (cells contain "Table X" references)
2. DETAILED_SOA - A detailed schedule with visits as columns and procedures as rows
3. DETAILED_SOA_TRANSPOSED - A detailed schedule with procedures as columns and visits as rows
4. ASSESSMENT_TABLE - A focused table for specific assessments (PK, biomarkers, etc.)

Also identify:
- Table number/name (e.g., "Table 2", "Table 10")
- Treatment regimen it covers (e.g., "Part 1 and Part 2", "Part 3")
- Any parent table references
```

**Expected Output**:

```json
{
  "table_type": "DETAILED_SOA",
  "table_id": "Table 2",
  "table_title": "Schedule of Activities - Screening and Treatment Phase",
  "treatment_regimen": "Part 1 and Part 2",
  "parent_table_ref": "Table 1",
  "referenced_tables": [],
  "confidence": 0.95
}
```

---

### Prompt 2: Visit/Timepoint Extraction

**Purpose**: Extract all visits and timepoints from column (or row) headers.

**System Prompt**:

```
Extract all VISITS and TIMEPOINTS from this Schedule of Activities table.

For each visit, extract:
- visit_name: Human-readable name (e.g., "Screening", "Cycle 1 Day 1", "End of Treatment")
- visit_code: Short code if available (e.g., "SCR", "C1D1", "EOT")
- visit_day: Numeric day relative to study start (e.g., 1, 8, 15)
- window: Time window definition (e.g., "≤28 days before", "+7 days")
- phase: Study phase (Screening, Treatment, Follow-up)
- cycle: Cycle number if applicable (Cycle 1, Cycle 2, etc.)

IMPORTANT:
- Visits are typically in column headers (but may be in rows if table is transposed)
- Look for patterns: Day 1, D1, Week 4, W4, Cycle 1, C1, Visit 1, V1
- Handle merged/nested headers (e.g., "Treatment Phase" spanning "Cycle 1" and "Cycle 2")
- Extract window definitions from header text (e.g., "≤30 (+7) days")
```

**Expected Output**:

```json
{
  "visits": [
    {
      "visit_name": "Screening",
      "visit_code": "SCR",
      "visit_day": null,
      "window_text": "≤28 days before administration",
      "window_before": 28,
      "window_after": 0,
      "phase": "Screening",
      "cycle": null,
      "column_index": 1
    },
    {
      "visit_name": "Cycle 1 Day 1",
      "visit_code": "C1D1",
      "visit_day": 1,
      "window_text": null,
      "window_before": 0,
      "window_after": 0,
      "phase": "Treatment",
      "cycle": "Cycle 1",
      "column_index": 4
    }
  ],
  "header_structure": "NESTED",
  "orientation": "VISITS_AS_COLUMNS"
}
```

---

### Prompt 3: Procedure/Assessment Extraction

**Purpose**: Extract all procedures and their categories from row (or column) headers.

**System Prompt**:

```
Extract all PROCEDURES and ASSESSMENTS from this Schedule of Activities table.

For each procedure, extract:
- procedure_name: Full name (e.g., "Informed consent", "Hematology and chemistry")
- procedure_category: Category/section header (e.g., "Screening Assessments", "Laboratory Assessments")
- footnote_markers: Any superscript markers (a, b, c, etc.)
- section_reference: Any section references (e.g., "Section 8.2.1")

IMPORTANT:
- Procedures are typically in row headers (first column)
- Identify category headers (bold or spanning rows)
- Preserve footnote markers exactly as written (e.g., "Physical examination^{i,j}")
- Handle multi-line procedure names
```

**Expected Output**:

```json
{
  "procedures": [
    {
      "procedure_name": "Informed consent",
      "procedure_category": "Screening Assessments",
      "footnote_markers": ["c"],
      "section_reference": null,
      "row_index": 1
    },
    {
      "procedure_name": "Hematology and chemistry",
      "procedure_category": "Clinical laboratory assessments",
      "footnote_markers": ["j", "m"],
      "section_reference": "See Appendix 5",
      "row_index": 15
    }
  ],
  "categories": [
    {"name": "Screening Assessments", "start_row": 1, "end_row": 12},
    {"name": "Clinical laboratory assessments", "start_row": 13, "end_row": 20}
  ]
}
```

---

### Prompt 4: Procedure-Visit Mapping

**Purpose**: Extract the intersection matrix showing which procedures apply to which visits.

**System Prompt**:

```
Extract the MAPPING between procedures and visits from this Schedule of Activities table.

For each cell intersection, extract:
- procedure_row: Row index of the procedure
- visit_column: Column index of the visit
- cell_value: Exact cell content
- is_required: True if cell contains "X" (with or without footnote)
- condition_text: Any conditional text (e.g., "As clinically indicated", "C1D1 only")
- footnote_refs: Footnote markers in this cell (e.g., ["a", "g"])
- table_reference: If cell contains "See Table X" or "Refer to Table X"

IMPORTANT:
- "X" = required at this visit
- "X^a" = required with footnote condition
- Blank = not required
- Text in cell = conditional requirement
- "See Table X" = details in another table
```

**Expected Output**:

```json
{
  "mappings": [
    {
      "procedure_row": 5,
      "visit_column": 3,
      "cell_value": "X",
      "is_required": true,
      "condition_text": null,
      "footnote_refs": [],
      "table_reference": null
    },
    {
      "procedure_row": 8,
      "visit_column": 6,
      "cell_value": "X^a",
      "is_required": true,
      "condition_text": null,
      "footnote_refs": ["a"],
      "table_reference": null
    },
    {
      "procedure_row": 12,
      "visit_column": 4,
      "cell_value": "As clinically indicated",
      "is_required": false,
      "condition_text": "As clinically indicated",
      "footnote_refs": [],
      "table_reference": null
    }
  ]
}
```

---

### Prompt 5: Footnote Extraction

**Purpose**: Extract all footnotes and their definitions from below the table.

**System Prompt**:

```
Extract all FOOTNOTES from this Schedule of Activities table.

For each footnote, extract:
- marker: The footnote marker (a, b, c, etc.)
- text: Full footnote text
- condition_type: Type of condition (TIMING, FREQUENCY, POPULATION, CONDITIONAL, REFERENCE)

IMPORTANT:
- Footnotes are typically below the table
- Match markers to their full text
- Identify timing conditions (e.g., "Predose samples to be collected...")
- Identify population conditions (e.g., "For participants with...")
- Identify references to other sections/tables
```

**Expected Output**:

```json
{
  "footnotes": [
    {
      "marker": "a",
      "text": "Predose samples are to be collected prior to administration of study drug.",
      "condition_type": "TIMING"
    },
    {
      "marker": "b",
      "text": "For participants with body weight ≥100 kg only.",
      "condition_type": "POPULATION"
    },
    {
      "marker": "c",
      "text": "As clinically indicated.",
      "condition_type": "CONDITIONAL"
    }
  ]
}
```

---

## Output Schema

### Silver Draft Tables

All tables are created in `silver_md` schema with `_draft` suffix for user review before gold promotion.

#### md_study_visits_draft

| Column | Type | Description |
|--------|------|-------------|
| visit_id | STRING | UUID |
| study_id | STRING | FK to md_study |
| protocol_id | STRING | FK to md_protocol |
| visit_name | STRING | "Screening", "Cycle 1 Day 1", "EOT" |
| visit_code | STRING | "SCR", "C1D1", "EOT" |
| visit_day | INT | Relative study day (Day 1, Day 8, etc.) |
| visit_window_before | INT | Window days before (e.g., -7) |
| visit_window_after | INT | Window days after (e.g., +7) |
| visit_phase | STRING | "Screening", "Treatment", "Follow-up" |
| visit_cycle | STRING | "Cycle 1", "Cycle 2", etc. |
| visit_order | INT | Sequence order |
| source_table_ref | STRING | "Table 2", "Table 9" |
| row_status | STRING | ACTIVE, DELETED |
| version | STRING | Draft version |
| is_current_draft | BOOLEAN | True if latest draft |
| created_ts | TIMESTAMP | Audit |
| created_by_principal | STRING | Audit |

#### md_study_procedures_draft

| Column | Type | Description |
|--------|------|-------------|
| procedure_id | STRING | UUID |
| study_id | STRING | FK to md_study |
| procedure_name | STRING | "Informed consent", "Hematology and chemistry" |
| procedure_category | STRING | "Screening", "Laboratory", "Treatment" |
| procedure_order | INT | Display order |
| source_table_ref | STRING | Source table reference |
| row_status | STRING | ACTIVE, DELETED |
| version | STRING | Draft version |
| is_current_draft | BOOLEAN | True if latest draft |
| created_ts | TIMESTAMP | Audit |
| created_by_principal | STRING | Audit |

#### md_procedure_visit_mappings_draft

| Column | Type | Description |
|--------|------|-------------|
| mapping_id | STRING | UUID |
| procedure_id | STRING | FK to md_study_procedures_draft |
| visit_id | STRING | FK to md_study_visits_draft |
| is_required | BOOLEAN | True if X mark present |
| condition_text | STRING | "As clinically indicated", "C1D1 only" |
| footnote_refs | ARRAY<STRING> | ["a", "b", "c"] |
| cell_value | STRING | Original cell value |
| row_status | STRING | ACTIVE, DELETED |
| version | STRING | Draft version |
| is_current_draft | BOOLEAN | True if latest draft |
| created_ts | TIMESTAMP | Audit |
| created_by_principal | STRING | Audit |

#### md_soa_footnotes_draft

| Column | Type | Description |
|--------|------|-------------|
| footnote_id | STRING | UUID |
| study_id | STRING | FK to md_study |
| footnote_marker | STRING | "a", "b", "c" |
| footnote_text | STRING | Full footnote content |
| condition_type | STRING | TIMING, FREQUENCY, POPULATION, CONDITIONAL, REFERENCE |
| source_table_ref | STRING | Which table this footnote belongs to |
| row_status | STRING | ACTIVE, DELETED |
| version | STRING | Draft version |
| is_current_draft | BOOLEAN | True if latest draft |
| created_ts | TIMESTAMP | Audit |
| created_by_principal | STRING | Audit |

### Gold Tables

Gold tables have identical schema (minus draft columns) and are created when user approves:

- `md_study_visits`
- `md_study_procedures`
- `md_procedure_visit_mappings`
- `md_soa_footnotes`

---

## Configuration

### YAML Configuration

Add to `clinical_data_standards.yaml`:

```yaml
pipelines:
  protocol_processor:
    ai_processing:
      # Existing parse_document and section_filter config...
      
      # SoA Entity Extraction Configuration (NEW)
      soa_extraction:
        enabled: true
        service: "soa_entity_extractor"  # References services.soa_entity_extractor
        prompts:
          classify_table: |
            You are analyzing a clinical trial Schedule of Activities table...
          extract_visits: |
            Extract all VISITS and TIMEPOINTS...
          extract_procedures: |
            Extract all PROCEDURES and ASSESSMENTS...
          extract_mappings: |
            Extract the MAPPING between procedures and visits...
          extract_footnotes: |
            Extract all FOOTNOTES from this Schedule of Activities table...
        output_tables:
          visits: "md_study_visits_draft"
          procedures: "md_study_procedures_draft"
          mappings: "md_procedure_visit_mappings_draft"
          footnotes: "md_soa_footnotes_draft"
```

---

## Implementation

### Files to Create/Modify

| File | Action | Description |
|------|--------|-------------|
| `config/clinical_data_standards.yaml` | MODIFY | Add `soa_entity_extractor` service and prompts |
| `sql/setup_soa_tables.sql` | CREATE | DDL for silver draft tables |
| `notebooks/.../nb_extract_soa_activities.ipynb` | CREATE | Multi-prompt extraction orchestration |
| `resources/.../job_cds_extract_activities.job.yml` | CREATE | Job triggered from UI button |
| `apps/.../api/study_api.py` | MODIFY | Add `extract_activities` endpoint |
| `apps/.../templates/setup.html` | MODIFY | Display extracted activities with edit capability |

### Notebook Implementation

```python
# nb_extract_soa_activities.ipynb

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import ChatMessage
import json

def call_llm_extraction(prompt: str, table_content: str) -> dict:
    """Call LLM model serving endpoint for SoA extraction."""
    w = WorkspaceClient()
    
    response = w.serving_endpoints.query(
        name="databricks-meta-llama-3-1-70b-instruct",
        messages=[
            ChatMessage(role="system", content=prompt),
            ChatMessage(role="user", content=table_content)
        ],
        max_tokens=4096,
        temperature=0.1
    )
    
    return json.loads(response.choices[0].message.content)

# Extraction Pipeline
def extract_soa_activities(document_id: str, catalog: str):
    # 1. Read SoA tables from md_protocol_document_sections
    soa_tables = spark.sql(f"""
        SELECT section_id, section_name, content_data
        FROM {catalog}.bronze_md.md_protocol_document_sections
        WHERE document_id = '{document_id}'
          AND LOWER(section_name) LIKE '%schedule%activities%'
          AND content_type = 'table'
    """).collect()
    
    for table in soa_tables:
        # 2. Classify table type
        classification = call_llm_extraction(PROMPT_CLASSIFY, table.content_data)
        
        if classification['table_type'] == 'GUIDE_TABLE':
            continue  # Skip guide tables
        
        # 3. Extract visits
        visits = call_llm_extraction(PROMPT_VISITS, table.content_data)
        
        # 4. Extract procedures
        procedures = call_llm_extraction(PROMPT_PROCEDURES, table.content_data)
        
        # 5. Extract mappings
        mappings = call_llm_extraction(PROMPT_MAPPINGS, table.content_data)
        
        # 6. Extract footnotes
        footnotes = call_llm_extraction(PROMPT_FOOTNOTES, table.content_data)
        
        # 7. Write to silver draft tables
        write_to_draft_tables(visits, procedures, mappings, footnotes)
```

### Job Definition

```yaml
# job_cds_extract_activities.job.yml

resources:
  jobs:
    job_cds_extract_activities:
      name: job_cds_extract_activities
      description: |
        Extract Schedule of Activities data from Protocol documents using LLM.
        Triggered from "Extract Activities" button in Study Details UI.
      
      parameters:
        - name: catalog_override
          default: ${var.catalog}
        - name: document_id
          default: ""
        - name: study_id
          default: ""
      
      tasks:
        - task_key: extract_activities
          notebook_task:
            notebook_path: ${workspace.file_path}/notebooks/.../nb_extract_soa_activities
            base_parameters:
              catalog_override: "{{job.parameters.catalog_override}}"
              document_id: "{{job.parameters.document_id}}"
              study_id: "{{job.parameters.study_id}}"
```

### API Endpoint

```python
# study_api.py

@study_bp.route('/extract_activities', methods=['POST'])
def extract_activities():
    """Trigger SoA extraction job for a Protocol document."""
    data = request.get_json()
    document_id = data.get('document_id')
    study_id = data.get('study_id')
    
    w = WorkspaceClient()
    
    # Trigger extraction job
    run = w.jobs.run_now(
        job_id=get_job_id('job_cds_extract_activities'),
        job_parameters={
            'document_id': document_id,
            'study_id': study_id
        }
    )
    
    return jsonify({
        'status': 'started',
        'run_id': run.run_id
    })

@study_bp.route('/study/<study_id>/activities', methods=['GET'])
def get_study_activities(study_id):
    """Get extracted activities from draft tables."""
    visits = sql_client.execute_query(f"""
        SELECT * FROM {catalog}.silver_md.md_study_visits_draft
        WHERE study_id = '{study_id}' AND is_current_draft = true
    """)
    
    procedures = sql_client.execute_query(f"""
        SELECT * FROM {catalog}.silver_md.md_study_procedures_draft
        WHERE study_id = '{study_id}' AND is_current_draft = true
    """)
    
    mappings = sql_client.execute_query(f"""
        SELECT * FROM {catalog}.silver_md.md_procedure_visit_mappings_draft
        WHERE is_current_draft = true
    """)
    
    return jsonify({
        'visits': visits,
        'procedures': procedures,
        'mappings': mappings
    })
```

---

## UI Workflow

### User Journey

1. **Navigate to Study Details** → View Protocol document
2. **Click "Extract Activities"** → Triggers `job_cds_extract_activities`
3. **Wait for extraction** → Progress indicator shows job status
4. **Review extracted data** → Visits, procedures, and mappings displayed in editable tables
5. **Make corrections** → User can edit/delete/add rows
6. **Approve and promote** → Click "Approve" to promote draft to gold tables

### UI Components

| Component | Description |
|-----------|-------------|
| Extract Activities Button | Triggers extraction job, shows during Protocol review |
| Progress Indicator | Polling-based job status display |
| Visits Table | Editable table showing extracted visits |
| Procedures Table | Editable table showing extracted procedures |
| Mapping Matrix | Grid showing procedure-visit intersections |
| Footnotes Panel | Collapsible panel with footnote definitions |
| Approve Button | Promotes draft to gold after user review |

---

## Gold Promotion Workflow

### Approval Process

1. **User reviews** extracted data in draft tables
2. **User makes corrections** if needed (edit, delete, add rows)
3. **User clicks "Approve"** button
4. **System validates** data integrity (foreign keys, required fields)
5. **System copies** data from draft to gold tables
6. **System updates** draft `is_current_draft = false`
7. **System logs** approval action in activity log

### Promotion Logic

```python
def promote_to_gold(study_id: str, approved_by: str):
    """Promote draft tables to gold."""
    
    # Copy visits
    spark.sql(f"""
        INSERT INTO {catalog}.gold_md.md_study_visits
        SELECT 
            visit_id, study_id, protocol_id, visit_name, visit_code,
            visit_day, visit_window_before, visit_window_after,
            visit_phase, visit_cycle, visit_order, source_table_ref,
            'ACTIVE' as row_status,
            current_timestamp() as created_ts,
            '{approved_by}' as created_by_principal
        FROM {catalog}.silver_md.md_study_visits_draft
        WHERE study_id = '{study_id}' AND is_current_draft = true
    """)
    
    # Mark draft as not current
    spark.sql(f"""
        UPDATE {catalog}.silver_md.md_study_visits_draft
        SET is_current_draft = false
        WHERE study_id = '{study_id}' AND is_current_draft = true
    """)
    
    # Repeat for procedures, mappings, footnotes...
```

---

## Related Documentation

- [01_dta_job_architecture_design.readme.md](./01_dta_job_architecture_design.readme.md) - Overall pipeline architecture
- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - Schema for extracted data
- [07_dta_databricks_ai_design.readme.md](./07_dta_databricks_ai_design.readme.md) - Databricks AI capabilities (Model Serving and Genie)
- [03_dta_status_lifecycle_design.readme.md](./03_dta_status_lifecycle_design.readme.md) - Document processing statuses

# Scalable CDH Clinical Data File Processing Architecture

## Table of Contents

1. [Overview](#overview)
   - [Problem Statement](#problem-statement)
   - [Architectural Enhancement Opportunities](#architectural-enhancement-opportunities)
2. [When Is Each Approach Most Effective?](#when-is-each-approach-most-effective)
   - [Per-Document Partitioning Effectiveness by Document Count](#per-document-partitioning-effectiveness-by-document-count)
   - [Adaptive Partitioning Strategy (Recommended Quick Win)](#adaptive-partitioning-strategy-recommended-quick-win)
   - [Streaming with foreachBatch (Long-Term Solution)](#streaming-with-foreachbatch-long-term-solution)
   - [Performance Comparison: Batch vs Streaming](#performance-comparison-batch-vs-streaming)
   - [Decision Matrix](#decision-matrix)
   - [Solution](#solution)
3. [Scalable CDH Clinical Data File Processing Architecture](#scalable-cdh-clinical-data-file-processing-architecture-1)
   - [Design Principles](#design-principles)
   - [1. Auto Loader for File Ingestion](#1-auto-loader-for-file-ingestion)
   - [2. Document Partitioning Strategy](#2-document-partitioning-strategy)
   - [3. Excel File Processing: Status-Based Parallel Architecture](#3-excel-file-processing-status-based-parallel-architecture)
   - [4. Protocol & Operational Agreement Processing: Parallel Entity Extraction](#4-protocol--operational-agreement-processing-parallel-entity-extraction)
   - [5. Scalability Analysis: 1 to 10,000+ Files](#5-scalability-analysis-1-to-10000-files)
   - [6. Failure Handling & Recovery](#6-failure-handling--recovery)
4. [Diagrams](#diagrams)
   - [Streaming Architecture Overview](#streaming-architecture-overview)
   - [Document-Level Parallelism](#document-level-parallelism)
   - [Checkpoint & Recovery Flow](#checkpoint--recovery-flow)
   - [Monitoring Dashboard Design](#monitoring-dashboard-design)

---

## Overview

This document describes the architecture that can enable scaling of ingestion further for CDH platform. The proposed solution enhances the current batch-based system by introducing **document-level parallelism** through Databricks Structured Streaming, unlocking 3-10x performance improvements for high-volume document ingestion.

### Problem Statement: Architectural Considerations for Clinical Data Ingestion at Scale

Clinical data ingestion platforms must handle diverse document types (Excel, PDF, Word) from multiple vendors across hundreds of studies. As volume scales from single uploads to thousands of files per day, several **architectural bottlenecks** can emerge that prevent linear cost scaling:

#### Common Architectural Bottlenecks

**1. Document Processing Granularity**
- **Challenge**: Grouping multiple documents into processing batches can create sequential processing within groups
- **Impact**: Even with parallel infrastructure, documents may wait for others in their group to complete
- **Scale Effect**: 100 documents grouped into 10 batches → 10 sequential processing cycles instead of 100 parallel operations

**2. Compute Resource Utilization**
- **Challenge**: Processing strategies that create too few work units (partitions) cannot fully utilize available compute capacity
- **Impact**: Auto-scaling infrastructure remains underutilized despite pending work
- **Example**: 5 work units on 20-worker serverless cluster → 75% capacity idle

**3. Monolithic Job Design**
- **Challenge**: Single orchestrator job handling all document types and processing stages
- **Impact**: Bottlenecks in one document type (e.g., large Excel files) block processing of others (e.g., PDFs)
- **Scale Effect**: Sequential job steps prevent concurrent processing of independent work streams

**4. Status and Workflow Coordination**
- **Challenge**: Without fine-grained status tracking, restart from failure requires reprocessing all documents
- **Impact**: Partial failures cause full reprocessing, wasting compute and time
- **Recovery Time**: 50 documents with 1 failure → reprocess all 50 instead of retrying 1

**5. Child Data Structure Creation**
- **Challenge**: Documents often require creating multiple child records (e.g., Excel sheets, PDF sections)
- **Impact**: Sequential child extraction limits parallelism opportunities
- **Example**: Excel with 100 sheets processing 1 sheet at a time vs. parallel sheet extraction

#### Architectural Requirements for Scale

To support **10,000+ files per day across 200+ studies**, the architecture must address:

| Requirement | Architectural Need | Enabler |
|-------------|-------------------|---------|
| **Linear Cost Scaling** | Processing time should not increase linearly with file count | Per-document parallelism + auto-scaling |
| **Study Isolation** | Work from different studies shouldn't block each other | Study-level partitioning |
| **Vendor Concurrency** | Multiple vendors can submit simultaneously | Distributed processing queue |
| **Failure Resilience** | One document failure doesn't block others | Status-driven workflow with independent processors |
| **Format Flexibility** | Excel, PDF, Word require different processing logic | Specialized processors per document type |
| **Exactly-Once Semantics** | No duplicate processing even with retries | Checkpoint-based idempotency |

### Architectural Solutions

The proposed architecture addresses these bottlenecks through three key strategies:

**1. Per-Document Partitioning**
- Create one partition per document instead of grouping
- Enables serverless to scale workers to match document count
- **Impact**: 50 documents process in parallel (20 workers × 3 rounds = 18 min) vs. sequential batches (60 min)

**2. Distributed Status-Driven Processors**
- Replace monolithic job with independent processors watching status table
- Each processor handles specific document type or processing stage
- **Impact**: Excel, Protocol, OA processing happens concurrently; failures isolated per processor

**3. Child Table Parallelism**
- Extract child structures (sheets, sections, entities) in parallel using `mapInPandas`
- Use `trigger(availableNow=True)` for exactly-once processing
- **Impact**: 100-sheet Excel processes all sheets concurrently instead of sequentially

**Result**: Platform can scale from single files to 10,000+ files/day with linear cost (not linear time) scaling.

---

## When Is Each Approach Most Effective?

### Quick Reference Summary

| Document Count | Current Approach | Recommended Solution | Expected Improvement | Implementation Effort |
|----------------|------------------|---------------------|---------------------|----------------------|
| **1 document** | ✅ Optimal | Keep current | None (0%) | No change needed |
| **2-9 documents** | ⚠️ Acceptable | Adaptive Partitioning | 2-3× faster | Low (1 line code change) |
| **10-50 documents** | ❌ Bottleneck | Adaptive Partitioning | 3-6× faster | Low (1 line code change) |
| **50-100 documents** | ❌ Bottleneck | Adaptive Partitioning | 6-10× faster | Low (1 line code change) |
| **100+ documents** | ❌ Bottleneck | Streaming + Adaptive | 10× faster | Medium (new job architecture) |
| **Continuous arrival** | ❌ Batching delays | Streaming with foreachBatch | 4-10× lower latency | Medium (new job architecture) |
| **Mixed workload** | ⚠️ Varies | Streaming with foreachBatch | Optimal for all cases | Medium (new job architecture) |

**Key Insights**:
- **Single documents**: No optimization needed - sheet-level parallelism already optimal
- **Small-medium batches (10-100 docs)**: Adaptive partitioning provides significant improvement with minimal effort
- **Large batches or continuous ingestion**: Full streaming architecture recommended for best performance

---

### Per-Document Partitioning Effectiveness by Document Count

The benefit of per-document partitioning varies significantly based on batch size:

#### Small Document Counts (1-5 documents)

**Current Approach:**
```python
num_partitions = doc_count // 10
# 1 document → 1 partition (optimal already)
# 5 documents → 1 partition (sequential processing)
```

**Per-Document Partitioning:**
```python
num_partitions = doc_count
# 1 document → 1 partition (same as current, NO improvement)
# 5 documents → 5 partitions (parallel processing)
```

| Documents | Current Time | Per-Doc Partition | Improvement | Worth It? |
|-----------|--------------|-------------------|-------------|-----------|
| 1 doc | 6 min | 6 min | 0% | ❌ No benefit |
| 2 docs | 12 min | 6-8 min | 33-50% | ⚠️ Marginal |
| 5 docs | 30 min | 6-8 min | 73-80% | ✅ Yes |
| 10 docs | 60 min | 20 min | 67% | ✅ Significant |
| 50 docs | 180 min | 25 min | 86% | ✅ Very significant |

**Key Insight for Single Document:**
For 1 document, per-document partitioning provides **ZERO benefit** because both approaches create 1 partition. The existing sheet-level parallelism (mapInPandas) already handles single documents optimally.

#### The Sweet Spot

Per-document partitioning is most effective for:
- ✅ **10-100 documents**: Dramatic improvement (3-10x faster)
- ⚠️ **5-9 documents**: Moderate improvement (2-3x faster)
- ⚠️ **2-4 documents**: Small improvement (< 2x faster)
- ❌ **1 document**: No improvement at all

### Adaptive Partitioning Strategy (Recommended Quick Win)

Instead of always using per-document partitioning, use an adaptive approach:

```python
# Smart partitioning based on document count
if doc_count == 1:
    # Single doc: Use default (sheet-level parallelism is sufficient)
    num_partitions = 1
    print("Single document: Using sheet-level parallelism only")
    
elif doc_count <= 10:
    # Small batch: 1 document per partition for full parallelism
    num_partitions = doc_count
    print(f"Small batch ({doc_count} docs): Per-document partitioning")
    
else:
    # Large batch: Cap partitions at serverless max to avoid excessive overhead
    # Serverless will auto-scale workers to match partition count
    max_serverless_workers = 200  # Serverless max workers configured
    num_partitions = min(doc_count, max_serverless_workers)
    print(f"Large batch ({doc_count} docs): Capped at {num_partitions} partitions")

# Repartition by document_id to ensure documents don't get grouped together
df_repartitioned = df_filtered.repartition(num_partitions, "document_id")
```

**Benefits:**
- ✅ No overhead for single documents (most common case for UI uploads)
- ✅ Optimal parallelism for small-medium batches
- ✅ Prevents over-partitioning for very large batches
- ✅ Single line of code change from current implementation

### Streaming with foreachBatch (Long-Term Solution)

For continuous ingestion or unpredictable batch sizes, streaming handles all cases optimally:

```python
# Streaming approach - works well for ANY document count
spark.readStream
  .format("delta")
  .table("md_file_history")
  .filter("status = 'READY_FOR_PROCESSING'")
  .writeStream
  .foreachBatch(lambda df, epoch_id: process_micro_batch(df, epoch_id))
  .trigger(processingTime="30 seconds")
  .start()

def process_micro_batch(df, epoch_id):
    doc_count = df.count()
    
    if doc_count == 0:
        return  # Skip empty batches
    
    print(f"Micro-batch {epoch_id}: Processing {doc_count} documents")
    
    # Streaming automatically optimizes per-batch
    # Each document gets its own partition within the micro-batch
    processed_df = df.repartition(doc_count, "document_id") \
                     .mapInPandas(process_excel_pandas, schema)
    
    processed_df.write.mode("append").saveAsTable("output")
```

**Advantages:**
- ✅ Handles 1 document or 100 documents equally well
- ✅ Processes documents **immediately** after arrival (5-30s latency vs 120s batch wait)
- ✅ Natural per-document partitioning in each micro-batch
- ✅ Built-in checkpointing and exactly-once semantics
- ✅ Auto-scaling based on queue depth
- ✅ Failed documents don't block entire batch

### Performance Comparison: Batch vs Streaming

| Scenario | Current Batch | Adaptive Partition | Streaming | Winner |
|----------|---------------|-------------------|-----------|--------|
| **1 document** | 6 min | 6 min | 6 min | ✅ **All equal** |
| **5 documents** | 30 min (sequential) | 6-8 min (parallel) | 6-8 min (parallel) | ✅ **Adaptive or Streaming** |
| **10 documents** | 60 min | 20 min | 20 min | ✅ **Adaptive or Streaming** |
| **50 documents** | 180 min (queuing) | 25 min | 25 min | ✅ **Adaptive or Streaming** |
| **100 documents** | 300 min | 30 min | 30 min | ✅ **Adaptive or Streaming** |
| **Continuous arrival** | Waits 120s | Waits 120s | 5-30s latency | ✅ **Streaming only** |
| **Mixed sizes (1-100)** | Varies (poor for large) | Optimal for each | Optimal for all | ✅ **Streaming** |

### Decision Matrix

Use this matrix to choose the right approach:

```
Batch Size        | Current Good? | Quick Win        | Long-Term
------------------|---------------|------------------|------------------
1 document        | ✅ Yes        | ⏸️ Keep current  | ⏸️ Streaming (future-proof)
2-9 documents     | ⚠️ OK        | ✅ Adaptive      | ✅ Streaming
10-50 documents   | ❌ No        | ✅ Adaptive      | ✅ Streaming
50+ documents     | ❌ No        | ✅ Adaptive      | ✅ Streaming
Continuous        | ❌ No        | ❌ N/A           | ✅ Streaming only
```

**Key Takeaway:** For single document uploads (common in UI), there is no performance benefit from per-document partitioning. The enhancement targets batch scenarios with 10+ documents where linear scaling becomes problematic.

---

### Solution

A **streaming-based ingestion architecture** that treats the Delta table (`md_file_history`) as a distributed work queue, enabling:

1. **Document-level parallelism**: Multiple documents processed simultaneously across Spark executors
2. **Continuous processing**: Eliminates file arrival trigger delays (60-120s → 5-30s latency)
3. **Auto-scaling**: Serverless compute scales workers based on queue depth
4. **Exactly-once semantics**: Checkpoint-based idempotency with optimistic locking
5. **Fault tolerance**: Failed documents don't block entire job run

---

## Scalable CDH Clinical Data File Processing Architecture

### Architecture Overview

The scalable CDH architecture **redesigns the monolithic `job_cdm_dta_import`** into a distributed, status-driven system. Instead of a single job processing all documents sequentially, the new architecture uses:

1. **Two-Stage Pipeline**: File ingestion → Status-driven processing
2. **Distributed Work Queue**: `md_file_history` table acts as a status-based queue
3. **Independent Processors**: Multiple specialized processors monitor status and process in parallel
4. **Adaptive Partitioning**: Each processor scales based on document count

This enables the platform to scale from single file uploads to **tens of thousands of files per day** across hundreds of studies with **linear cost** (not linear time) scaling.

---

### Design Principles

| Principle | Implementation | Benefit |
|-----------|----------------|---------|
| **Distributed Processing** | Independent processors watch status table | No single point of bottleneck |
| **Study Isolation** | Partition by study_id | 100 studies → 100 parallel streams |
| **Vendor Concurrency** | Partition by vendor_id | Multiple vendors don't block each other |
| **Document Type Specialization** | Separate processors for Excel, PDF, Word | Format-specific optimizations |
| **Status-Driven Flow** | Each processor updates status when complete | Enables checkpointing and recovery |
| **Exactly-Once Semantics** | trigger(availableNow=True) + checkpoints | No duplicate processing |

---

### 1. Two-Stage Pipeline Architecture

#### Stage 1: File Ingestion (Auto Loader → Metadata Table)

**Technology**: [Databricks Auto Loader](https://docs.databricks.com/aws/en/ingestion/cloud-object-storage/auto-loader/) with `trigger(availableNow=True)`

**Conceptual Flow**:
```
Landing Zone (Cloud Storage)
        ↓
   Auto Loader (readStream)
        ↓
  md_file_history table
   (status = 'UPLOADED')
```

**Why Auto Loader?**

| Capability | Benefit | Scale Impact |
|------------|---------|--------------|
| **Scalability** | Can discover billions of files efficiently | Handles 10,000+ files/day without degradation |
| **Cost Efficiency** | Uses native cloud APIs, file notification mode | Cost scales with files ingested, not total files |
| **Exactly-Once** | Built-in checkpoint mechanism (RocksDB) | No duplicate processing even with retries |
| **Schema Evolution** | Automatic schema detection and drift handling | New file columns handled gracefully |
| **Incremental** | Processes only new files since last checkpoint | Constant startup time regardless of history |

**Landing Zone Structure**:
```
/Volumes/{catalog}/{schema}/clinical_data_standards/
  └── landing/
      ├── study_123/vendor_A/upload_2026-02-03_10-30/
      │   ├── dta_template_v1.xlsx
      │   ├── protocol_document.pdf
      │   └── operational_agreement.docx
      └── study_456/vendor_B/upload_2026-02-03_14-15/
          └── dta_template_v2.xlsx
```

**Ingestion Process**:
1. Vendors upload files to study/vendor-specific folders
2. Auto Loader detects new files within 5-30 seconds
3. File metadata written to `md_file_history` with:
   - `status = 'UPLOADED'`
   - `document_type` (Excel, PDF, Word)
   - `study_id`, `vendor_id`, `document_id`
4. Stage 1 complete - file now visible to downstream processors

#### Stage 2: Status-Driven Distributed Processing

**The Core Innovation**: `md_file_history` becomes a **distributed work queue**. Multiple independent processors watch for documents at specific statuses and process them in parallel.

**Processor Architecture**:
```
md_file_history (Status-Driven Queue)
    │
    ├─→ Excel Processor → [status='UPLOADED' AND file_type='excel']
    │       ↓
    │   Extracts sheets → md_dta_excel_sheets (child tables)
    │       ↓
    │   Updates: status='SHEETS_EXTRACTED'
    │
    ├─→ Protocol Processor → [status='UPLOADED' AND file_type='pdf']
    │   ├── Task 1: Entity Extraction → md_protocol_entities
    │   └── Task 2: Section Processing → md_protocol_sections
    │       ↓
    │   Updates: status='PROTOCOL_PROCESSED'
    │
    ├─→ OA Processor → [status='UPLOADED' AND file_type='docx']
    │       ↓
    │   Extracts config tables → md_oa_attributes, md_oa_options
    │       ↓
    │   Updates: status='OA_PROCESSED'
    │
    ├─→ Validation Processor → [status='SHEETS_EXTRACTED']
    │       ↓
    │   Validates data quality → Updates: status='VALIDATED'
    │
    ├─→ Categorization Processor → [status='VALIDATED']
    │       ↓
    │   Classifies variables → Updates: status='CATEGORIZED'
    │
    └─→ DTA Creator → [status='CATEGORIZED']
            ↓
        Creates final DTA → Updates: status='COMPLETE'
```

**Key Difference from Monolithic Job**:

| Aspect | Old (Monolithic) | New (Distributed) |
|--------|------------------|-------------------|
| **Architecture** | Single job processes all steps | Multiple independent processors |
| **Bottleneck** | One job handles everything sequentially | Each processor scales independently |
| **Parallelism** | Limited by job design | Natural parallelism via status partitioning |
| **Failure Impact** | Entire job fails | Only affected processor fails, others continue |
| **Scalability** | Add more workers to one job | Add more processors watching different statuses |

---

### 2. Excel File Processing: Status-Based Workflow

**DTA Templates** (Excel files) require multi-stage processing: extraction, validation, categorization. Each stage is handled by an independent processor.

#### Complete Status Lifecycle

| Status | Processor | Action | Child Tables Created | Parallelism |
|--------|-----------|--------|---------------------|-------------|
| `UPLOADED` | Auto Loader | File metadata captured | — | File detection |
| `SHEETS_EXTRACTED` | Excel Processor | Extracts all sheets from Excel | `md_dta_excel_sheets` (one row per sheet) | **Document-level** (10 files → 10 parallel) |
| | | | | **Sheet-level** (50 sheets → mapInPandas parallel) |
| `VALIDATED` | Validation Processor | Applies business rules | `md_dta_validation_errors` | **Document-level** |
| `CATEGORIZED` | Categorization Processor | Classifies variables | `md_dta_transfer_variables` | **Document-level** |
| | | | `md_dta_test_concepts` | |
| `COMPLETE` | DTA Creator | Creates final DTA record | `md_dta_main` (Gold) | **Document-level** |
| `FAILED` | — | Error occurred | `error_message` populated | Manual review |

#### Excel Processor: Multi-Level Parallelism

**Processor Trigger**:
```python
# Runs with trigger(availableNow=True) - processes all available work, then stops
df_to_process = spark.readStream
  .table("md_file_history")
  .filter("status = 'UPLOADED' AND document_type = 'DTA_TEMPLATE'")
```

**Adaptive Partitioning**:
```python
doc_count = df_to_process.count()

if doc_count <= 10:
    num_partitions = doc_count  # 1 document per partition
else:
    num_partitions = min(doc_count, 200)  # Cap at serverless max

# Partition by document_id for document-level parallelism
df_partitioned = df_to_process.repartition(num_partitions, "document_id")
```

**Sheet Extraction with mapInPandas**:
```python
# Within each partition, sheets process in parallel
df_sheets = df_partitioned.mapInPandas(extract_sheets_pandas, output_schema)
df_sheets.write.mode("append").table("md_dta_excel_sheets")

# Update status
update_status(document_ids, new_status="SHEETS_EXTRACTED")
```

**Parallelism Example**:
- **Scenario**: 50 Excel files arrive (10 files from 5 different vendors)
- **Old Architecture**: 5 partitions (10 docs each) → 60 min per partition → 60 min total
- **New Architecture**: 50 partitions (1 doc each) → serverless scales to 20 workers → 3 rounds × 6 min → **18 min total**

---

### 3. Protocol & Operational Agreement: Parallel Task Processing

**Protocol (PDF)** and **Operational Agreement (Word)** documents require LLM-based extraction. The key innovation is **parallel task execution** within the processor.

#### Protocol Processor: Two Parallel Tasks

**Processor Design**:
```
Protocol Processor (triggered by status='UPLOADED' AND document_type='PROTOCOL')
    │
    ├─→ Task 1: Entity Extraction (parallel)
    │     ├── Study Title
    │     ├── Principal Investigator
    │     ├── NCT Number
    │     └── Therapeutic Area
    │       ↓
    │   Writes to: md_protocol_entities
    │
    └─→ Task 2: Section Processing (parallel)
          ├── Schedule of Activities (LLM extraction)
          ├── Endpoints & Assessments (LLM extraction)
          └── Study Population (LLM extraction)
            ↓
        Writes to: md_protocol_sections, md_protocol_soa

Both tasks run simultaneously → Total time: max(Task1, Task2) instead of Task1 + Task2
```

**Parallelism Benefits**:
- **Sequential**: Entity extraction (1 min) + Section processing (4 min) = **5 minutes**
- **Parallel**: max(1 min, 4 min) = **4 minutes** (20% faster)
- **With 10 protocols**: Old = 50 min, New (10 parallel docs × 4 min) = **4 minutes** (12× faster)

#### OA Processor: Parallel Configuration Extraction

**Processor Design**:
```
OA Processor (triggered by status='UPLOADED' AND document_type='OA')
    │
    ├─→ Extract Attributes table → md_oa_attributes
    ├─→ Extract Options table → md_oa_options
    └─→ Extract Other metadata → md_oa_other
          ↓
    All three tables extracted in parallel using mapInPandas
    Updates: status='OA_PROCESSED'
```

**Child Tables**:
- Each OA document creates 3 child tables
- Tables extracted in parallel (not sequential)
- 10 OA documents = 30 child tables created concurrently

---

### 4. Scalability Analysis: 1 to 10,000+ Files

The distributed processor architecture scales naturally from single uploads to production volumes of 10,000+ files per day.

#### Scaling by File Count

| Files | Processors Active | Serverless Workers | Processing Time | Bottleneck |
|-------|-------------------|-------------------|-----------------|------------|
| **1** | 1 (Excel OR Protocol OR OA) | 1-2 | 6-8 min | Sheet extraction |
| **10** | 3 (Excel, Protocol, OA parallel) | 5-10 | 8-12 min | None (distributed) |
| **50** | 3 processors × adaptive partitions | 15-20 | 15-20 min | None |
| **100** | 3 processors × 100 partitions | 20-30 | 20-25 min | Serverless max workers |
| **500** | All processors continuously active | 20-50 | **Continuous** | None (processes as arrive) |
| **10,000+** | All processors continuously active | Auto-scales | **Continuous** | None (distributed queue) |

**Key Insight**: Time does NOT increase linearly because:
1. **Multiple processors** handle different document types simultaneously
2. **Adaptive partitioning** maximizes parallelism within each processor
3. **Status-based queuing** eliminates job-level bottlenecks
4. **Serverless auto-scaling** matches worker count to partition count

#### Real-World Scenario: 50 Studies, 250 Vendor Uploads/Day

**Daily Load**:
- 50 active studies
- 5 vendors per study (250 vendor relationships)
- Each vendor sends 2-5 files/day
- **Total: 500-1,250 files/day** (mix of Excel, PDF, Word)

**Key Architecture Benefits**:
- **Distributed Processing**: Excel, Protocol, and OA processors run independently
- **Study-Level Parallelism**: 50 studies create 50 independent processing streams
- **Vendor-Level Parallelism**: 250 vendor uploads process without blocking each other
- **Auto-Scaling**: Serverless scales from 0 workers (idle) to 50+ workers (peak load) automatically
- **Status-Driven Recovery**: Failed documents retry independently without blocking others

**Result**: Files process as they arrive with minimal latency. The same architecture handles 10× volume increase with no redesign required.

---

### 5. Failure Handling & Recovery

The status-driven architecture provides **automatic recovery** and **failure isolation**.

#### Failure Isolation by Processor

| Failure Scenario | Impact | Recovery | Other Processors |
|------------------|--------|----------|------------------|
| **Excel processor fails** | Excel files stuck at status='UPLOADED' | Restart Excel processor only | Protocol & OA processors continue |
| **Protocol LLM timeout** | Protocol files stuck at status='UPLOADED' | Retry with exponential backoff | Excel & OA processors continue |
| **Validation processor fails** | Files stuck at status='SHEETS_EXTRACTED' | Restart validation processor | Upstream processors continue |

**Automatic Recovery**:
```sql
-- Orphaned Document Detection (scheduled every 30 min)
SELECT document_id, status, processing_start_ts
FROM md_file_history
WHERE status IN ('EXTRACTING_SHEETS', 'VALIDATING', 'CATEGORIZING')
  AND processing_start_ts < current_timestamp() - INTERVAL 30 MINUTES;

-- Automatic Reset Action
UPDATE md_file_history
SET status = (CASE 
    WHEN status = 'EXTRACTING_SHEETS' THEN 'UPLOADED'
    WHEN status = 'VALIDATING' THEN 'SHEETS_EXTRACTED'
    WHEN status = 'CATEGORIZING' THEN 'VALIDATED'
  END),
  retry_count = retry_count + 1
WHERE document_id IN (orphaned_document_ids)
  AND retry_count < 3;
```

#### Exactly-Once Semantics

**How it works**:
1. **Checkpoint per processor**: Each processor has its own checkpoint location
2. **Status update is atomic**: Document moves to next status only after successful processing
3. **Idempotent operations**: Reprocessing same document produces same result
4. **trigger(availableNow=True)**: Processes all available work, then stops (no duplicates)

**Example Recovery Flow**:
```
Excel file uploaded → status='UPLOADED'
    ↓
Excel processor starts extraction → status='EXTRACTING_SHEETS'
    ↓
[CRASH - Processor fails at 50% complete]
    ↓
Orphaned document detected (status still 'EXTRACTING_SHEETS' after 30 min)
    ↓
Automatic reset → status='UPLOADED'
    ↓
Excel processor restarts → Reprocesses from beginning → status='SHEETS_EXTRACTED' ✓
```

**No data loss** because:
- Original file retained in landing zone
- Checkpoint ensures restart from beginning of failed document
- Child tables use `mode="append"` with deduplication by document_id

---

## Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| Streaming Architecture Overview | End-to-end streaming pipeline with parallel processors | [PNG](./diagrams/11_streaming_architecture_overview.png) | [Draw.io](./diagrams/11_streaming_architecture_overview.drawio) |
| Document-Level Parallelism | Two-level parallelism: document AND sheet level | [PNG](./diagrams/11_document_level_parallelism.png) | [Draw.io](./diagrams/11_document_level_parallelism.drawio) |
| Checkpoint & Recovery Flow | Exactly-once processing with failure recovery | [PNG](./diagrams/11_checkpoint_recovery.png) | [Draw.io](./diagrams/11_checkpoint_recovery.drawio) |
| Monitoring Dashboard Design | Observability metrics and dashboards | [PNG](./diagrams/11_monitoring_dashboard.png) | [Draw.io](./diagrams/11_monitoring_dashboard.drawio) |

### Streaming Architecture Overview

![Streaming Architecture Overview](./diagrams/11_streaming_architecture_overview.png)

📝 [Edit Diagram (Draw.io)](./diagrams/11_streaming_architecture_overview.drawio)

### Document-Level Parallelism

![Document-Level Parallelism](./diagrams/11_document_level_parallelism.png)

📝 [Edit Diagram (Draw.io)](./diagrams/11_document_level_parallelism.drawio)

### Checkpoint & Recovery Flow

![Checkpoint & Recovery Flow](./diagrams/11_checkpoint_recovery.png)

📝 [Edit Diagram (Draw.io)](./diagrams/11_checkpoint_recovery.drawio)

### Monitoring Dashboard Design

![Monitoring Dashboard Design](./diagrams/11_monitoring_dashboard.png)

📝 [Edit Diagram (Draw.io)](./diagrams/11_monitoring_dashboard.drawio)

---

# 12. CDH Conformance Checks Engine Design

## Table of Contents

- [Purpose](#purpose)
  - [Key Objectives](#key-objectives)
  - [Scope](#scope)
- [Architecture Overview](#architecture-overview)
  - [High-Level Architecture](#high-level-architecture)
  - [Why Lakeflow Spark Declarative Pipelines?](#why-lakeflow-spark-declarative-pipelines)
- [SDP Pipeline Architecture](#sdp-pipeline-architecture)
  - [Single Pipeline with Parallel Task Execution](#single-pipeline-with-parallel-task-execution)
  - [File Arrival Triggered Execution](#file-arrival-triggered-execution)
  - [Pipeline Task Flow](#pipeline-task-flow)
- [SDP Expectations Framework](#sdp-expectations-framework)
  - [Expectations Hierarchy](#expectations-hierarchy)
  - [Implementation Example: Transfer Variables Validation](#implementation-example-transfer-variables-validation)
  - [Metadata-Driven Expectations](#metadata-driven-expectations)
  - [Validation Rules by Library Type](#validation-rules-by-library-type)
- [Data Drift Detection Strategy](#data-drift-detection-strategy)
  - [Conformance Dimensions](#conformance-dimensions)
  - [Transfer Variables (TV) Validation Example](#transfer-variables-tv-validation-example)
- [SDP Feature Implementation](#sdp-feature-implementation)
  - [0. Expectations - Data Quality Validation](#0-expectations---data-quality-validation)
  - [1. Flows - Multiple Sources to Single Target](#1-flows---multiple-sources-to-single-target)
  - [2. Auto CDC - Simplified Change Data Capture](#2-auto-cdc---simplified-change-data-capture)
  - [3. Sinks - Non-Blocking Audit Writes](#3-sinks---non-blocking-audit-writes)
  - [4. Schema Evolution - Automatic Schema Handling](#4-schema-evolution---automatic-schema-handling)
  - [5. Transformations - Data Cleansing](#5-transformations---data-cleansing)
- [Metadata-Driven Configuration](#metadata-driven-configuration)
  - [Metadata Tables](#metadata-tables)
- [Parallel Task Execution Model](#parallel-task-execution-model)
  - [Single Pipeline with Parallel Tasks](#single-pipeline-with-parallel-tasks)
  - [Task Execution Flow](#task-execution-flow)
  - [Benefits of Single Pipeline Architecture](#benefits-of-single-pipeline-architecture)
- [Drift Reporting](#drift-reporting)
  - [Drift Report Table](#drift-report-table-t_conformance_audit)
  - [Drift Dashboard Queries](#drift-dashboard-queries)
- [Integration with Existing Pipelines](#integration-with-existing-pipelines)
  - [Integration Architecture](#integration-architecture)
  - [Integration Points](#integration-points)
  - [Shared Metadata](#shared-metadata)
- [Framework Components](#framework-components)
  - [Core APIs (Framework Utilities)](#core-apis-framework-utilities)
- [Future Enhancements](#future-enhancements)
- [Benefits Summary](#benefits-summary)
- [Related Documentation](#related-documentation)

---

## Purpose

The **Clinical Data Hub (CDH) Conformance Checks Engine** is a framework-driven data quality validation system designed to ensure vendor-submitted clinical trial data conforms to the agreed-upon Data Transfer Agreement (DTA) specifications. The engine detects **data drift** by comparing actual vendor data files against DTA metadata definitions, providing automated, parallel validation across multiple data quality dimensions.

### Key Objectives

1. **Data Drift Detection**: Identify discrepancies between vendor-submitted data and DTA-defined specifications
2. **Automated Validation**: Execute parallel conformance checks across multiple DTA library entities
3. **Framework-Driven**: Metadata-driven configuration enabling scalable validation rules without code changes
4. **Real-Time Monitoring**: Provide immediate feedback on data quality issues with actionable insights
5. **Audit Trail**: Maintain comprehensive audit logs of all validation failures for regulatory compliance

### Scope

The CDH Conformance Checks Engine validates all DTA library entities against vendor-submitted clinical trial data:

- **Transfer Variables (TV)**: Dataset-level variable definitions, data types, controlled terminology
- **Test Concepts (TC)**: Laboratory test definitions, units, reference ranges
- **Codelists (CL)**: Controlled terminology and permissible values
- **Times and Visits**: Study timeline, visit schedules, and epoch definitions
- **Operational Agreements (OA)**: Data submission agreements and vendor-specific configurations
- **Data Ingestion Parameters (DIP)**: File format specifications, delimiters, encoding rules

The engine is designed for comprehensive validation across all DTA entities, enabling detection of any deviations between agreed-upon specifications and actual vendor data submissions.

---

## Architecture Overview

### High-Level Architecture

The conformance engine leverages **Lakeflow Spark Declarative Pipelines (SDP)** with the **Expectations Framework** to implement a medallion architecture (Bronze → Silver → Gold) with integrated data quality checks at each layer. The engine is implemented as a **single SDP pipeline with parallel validation flows**, where each DTA entity follows a **4-step validation pattern** (Read → DQ Validation → Transform → Auto CDC).

![CDH Conformance Integrated Architecture](./diagrams/12_cdh_conformance_integrated_architecture.png)

**End-to-End Integrated Architecture** (Left-to-Right Flow):

**Input Sources**:
1. **Study Setup**: Trial configuration, vendor registration, DTA specification loading, and validation rules
2. **From DTA Builder**: DTA metadata including Transfer Variables, Test Concepts, Codelists, Times & Visits, Operational Agreements, Data Ingestion Parameters, and DTA Templates
3. **Vendor Data Landing**: Study files submitted via SFTP/SharePoint/API in various formats (CSV, XPT, SAS7BDAT, XML, JSON, ZIP) with **🔔 File Arrival Trigger** that automatically starts the SDP pipeline

**Conformance Engine - SDP Pipeline** (Event-Driven Processing):
1. **Validation Rules Metadata**: Delta table (`md_conformance_validation_rules`) storing CRITICAL and WARNING rules, joined at DQ validation step
2. **Bronze Layer**: Single streaming table (`bronze_vendor_data`) ingesting study-level vendor files via Autoloader triggered by UC Volume file arrival notifications
3. **Silver Layer - Parallel Validation Flows**: Each DTA library entity (TV, TC, CL, Times & Visits, OA, DIP) follows a 4-step pattern:
   - **Step 1: Read/Filter** - Extract entity-specific data from Bronze (6 parallel flows)
   - **Step 2: DQ Validation** - Apply CRITICAL/WARNING rules from metadata, drop or flag records
   - **Step 3: Transform** - Standardize to generic schema structure with column mapping and type conversion
   - **Step 4: Auto CDC** - Track vendor re-submissions with SCD Type 2 (INSERT/UPDATE/DELETE tracking)
4. **Validation Sinks**: Non-blocking audit logging (`audit_delta_sink`, `drift_summary_sink`, `quarantine_sink`)
5. **Gold Layer**: `study_level_gold schema` containing study-level validated data (current versions with `__CURRENT = true`)
6. **Medallion UC**: Unity Catalog volumes for Bronze → Silver → Gold data lineage

**Output Consumer**:
- **Marvel Application**: Consumes validated study-level data for SDTM datasets, ADaM datasets, conformance reports, data analytics, data review (DRE), and ICOM integration

### Why Lakeflow Spark Declarative Pipelines?

SDP provides several key advantages over traditional batch processing or separate pipeline architectures:

| Feature | Benefit | Documentation |
|---------|---------|---------------|
| **Flows** | Multiple flows writing to single target, append-once for backfills | [SDP Flows](https://docs.databricks.com/aws/en/ldp/flows) |
| **Auto CDC** | Simplified change data capture for SCD Type 2 tracking | [Auto CDC](https://docs.databricks.com/aws/en/ldp/database-replication) |
| **Sinks** | Write validation results to Delta tables without blocking pipeline | [SDP Sinks](https://docs.databricks.com/aws/en/ldp/ldp-sinks) |
| **Schema Evolution** | Automatic handling of schema changes in vendor files | [Schema Evolution](https://docs.databricks.com/aws/en/ldp/from-json-schema-evolution) |
| **Transformations** | Built-in data transformation capabilities | [Transformations](https://docs.databricks.com/aws/en/ldp/transform) |
| **Expectations** | Three-tier validation framework (FAIL/QUARANTINE/WARN) | [Expectations](https://docs.databricks.com/aws/en/ldp/expectation-patterns) |

---

## SDP Pipeline Architecture

### Single Pipeline with Parallel Task Execution

The conformance engine runs as a **single SDP pipeline** with parallel validation tasks for each DTA library entity (see **Conformance Engine - Lakeflow SDP Pipeline** section in the [integrated architecture diagram](#high-level-architecture) above). Multiple independent validation streams execute concurrently within one pipeline, enabling efficient parallel processing while maintaining simplified orchestration.

**Pipeline Structure** (as shown in the integrated architecture):
- **6 Main Sequential Steps**: Bronze → Read/Filter → DQ Validation → Transform → Auto CDC → Gold
- **6 Parallel Validation Flows**: The Read/Filter step fans out to process TC, TV, CL, Times & Visits, OA, and DIP entities in parallel
- **3 Audit Sinks**: Non-blocking writes to `audit_delta_sink`, `drift_summary_sink`, and `quarantine_sink` from each processing step
- **Medallion Architecture**: Bronze, Silver, and Gold layers in Unity Catalog for governed data storage

### File Arrival Triggered Execution

The SDP pipeline is configured for **event-driven or scheduled execution** using file arrival triggers, enabling near real-time validation when vendors submit new data files. Multiple ingestion patterns are supported based on vendor submission methods:

#### **Pattern 1: Unity Catalog Volume with File Arrival Trigger** (Recommended)

**Use Case**: Vendors upload files to UC Volumes via Databricks UI, REST API, or external tools

**Trigger Mechanism**:
- **Unity Catalog Volume Notifications**: File arrival events from UC Volume `/vendor_submissions/`
- **Databricks Workflow Integration**: Workflow monitors volume and triggers SDP pipeline update on new file detection
- **Pipeline Execution**: `trigger(availableNow=True)` processes all available files and stops (event-driven batch mode)
- **Auto-Scaling Serverless**: Compute resources provision on-demand, scale based on data volume, and deprovision after completion

**Execution Flow**:
```
Vendor uploads to UC Volume → File arrival event → Workflow trigger fires 
    → SDP pipeline starts → Autoloader ingests files → Validation flows execute 
    → Results written to Gold → Pipeline stops → Resources released
```

**Configuration Example** (Databricks Workflow):
```yaml
triggers:
  file_arrival:
    file_path: "/Volumes/catalog/schema/vendor_submissions/"
    events: ["file.created", "file.modified"]
    
pipeline_settings:
  trigger_mode: "availableNow"
  serverless: true
  auto_stop_minutes: 30
```

**Bronze Layer Autoloader**:
```python
@dp.table(comment="Bronze layer - UC Volume ingestion")
def bronze_vendor_data():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("cloudFiles.schemaLocation", "/checkpoints/vendor_data/schema")
        .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
        .load("/Volumes/catalog/schema/vendor_submissions/")
    )
```

**Benefits**:
- ✅ Native UC integration with governance and lineage
- ✅ Built-in file arrival notifications
- ✅ No external connectivity required
- ✅ Supports all file formats

---

#### **Pattern 2: SFTP with Autoloader Connector**

**Use Case**: Vendors submit files directly to SFTP server (common in clinical trials)

**Setup**:
1. Configure SFTP credentials in Databricks Secret Scope
2. Autoloader monitors SFTP directory for new files
3. Files ingested directly without intermediate storage
4. Use scheduled triggers or continuous streaming

**Bronze Layer Autoloader with SFTP**:
```python
@dp.table(comment="Bronze layer - SFTP ingestion with Autoloader")
def bronze_vendor_data():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("cloudFiles.schemaLocation", "/checkpoints/vendor_data/schema")
        .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
        
        # SFTP connector options
        .option("cloudFiles.useNotifications", "false")  # Poll-based for SFTP
        .option("cloudFiles.validateOptions", "false")
        .option("recursiveFileLookup", "true")
        
        # SFTP connection details
        .option("host", "sftp.vendor.com")
        .option("port", "22")
        .option("username", dbutils.secrets.get("vendor-sftp", "username"))
        .option("password", dbutils.secrets.get("vendor-sftp", "password"))
        .option("path", "/vendor_submissions/study_ABC/")
        
        .load("sftp://sftp.vendor.com:22/vendor_submissions/study_ABC/")
    )
```

**Alternative: Using Private Link for Secure SFTP**:
```python
# For SFTP servers in private networks
.option("host", "sftp.vendor.internal")
.option("privateLink", "true")
.option("privateLinkServiceId", dbutils.secrets.get("sftp-config", "service-id"))
```

**Trigger Configuration** (Scheduled polling):
```yaml
triggers:
  periodic:
    quartz_cron_expression: "0 */15 * * * ?"  # Every 15 minutes
    pause_status: "UNPAUSED"
    
pipeline_settings:
  trigger_mode: "availableNow"
  serverless: true
```

**Benefits**:
- ✅ Direct SFTP integration (no intermediate storage)
- ✅ Works with vendor-managed SFTP servers
- ✅ Supports SSH key authentication
- ✅ Automatic retry on connection failures

**Considerations**:
- ⚠️ Requires network connectivity to SFTP server
- ⚠️ Poll-based (not event-driven) - use appropriate polling interval
- ⚠️ Secure credential management required

---

#### **Pattern 3: SharePoint with Autoloader Connector**

**Use Case**: Vendors upload files to SharePoint document libraries (common in enterprise environments)

**Setup**:
1. Configure AWS IAM role with SharePoint access permissions
2. Configure client ID, client secret, tenant ID in Databricks Secret Scope
3. Autoloader monitors SharePoint library for new files

**Bronze Layer Autoloader with SharePoint**:
```python
@dp.table(comment="Bronze layer - SharePoint ingestion with Autoloader")
def bronze_vendor_data():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("cloudFiles.schemaLocation", "/checkpoints/vendor_data/schema")
        .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
        
        # SharePoint connector options
        .option("cloudFiles.useNotifications", "false")  # Poll-based for SharePoint
        .option("cloudFiles.validateOptions", "false")
        .option("recursiveFileLookup", "true")
        
        # SharePoint connection details
        .option("sharepoint.tenantId", dbutils.secrets.get("sharepoint", "tenant-id"))
        .option("sharepoint.clientId", dbutils.secrets.get("sharepoint", "client-id"))
        .option("sharepoint.clientSecret", dbutils.secrets.get("sharepoint", "client-secret"))
        .option("sharepoint.siteUrl", "https://vendor.sharepoint.com/sites/ClinicalDataSubmissions")
        .option("sharepoint.libraryName", "Vendor_Study_ABC")
        .option("sharepoint.folderPath", "/2026/Q1")
        
        .load("sharepoint://vendor.sharepoint.com/sites/ClinicalDataSubmissions/Vendor_Study_ABC/2026/Q1/")
    )
```

**Alternative: Using IAM Role for SharePoint (AWS)**:
```python
# For AWS-hosted Databricks with IAM role
.option("sharepoint.authType", "iamRole")
.option("sharepoint.iamRoleArn", dbutils.secrets.get("sharepoint", "iam-role-arn"))
```

**Trigger Configuration** (Scheduled polling):
```yaml
triggers:
  periodic:
    quartz_cron_expression: "0 0 */2 * * ?"  # Every 2 hours
    pause_status: "UNPAUSED"
    
pipeline_settings:
  trigger_mode: "availableNow"
  serverless: true
```

**Benefits**:
- ✅ Native SharePoint integration (no downloads required)
- ✅ Works with Office 365 and SharePoint Online
- ✅ OAuth 2.0 authentication
- ✅ Supports nested folder structures

**Considerations**:
- ⚠️ Requires IAM role configuration and SharePoint permissions
- ⚠️ Poll-based (not event-driven) - use appropriate polling interval
- ⚠️ SharePoint API rate limits apply

---

#### **Pattern Comparison**

| Feature | UC Volume | SFTP | SharePoint |
|---------|-----------|------|------------|
| **Trigger Type** | Event-driven (file arrival) | Poll-based (scheduled) | Poll-based (scheduled) |
| **Setup Complexity** | Low | Medium | Medium-High |
| **Latency** | Near real-time | Based on poll interval | Based on poll interval |
| **External Dependencies** | None | SFTP server connectivity | IAM role + SharePoint permissions |
| **Best For** | Databricks-native workflows | Legacy SFTP vendors | Enterprise SharePoint environments |
| **Security** | UC governance built-in | SSH keys/passwords in secrets | OAuth 2.0 + managed identity |

**Recommendation**: Use **UC Volume pattern** for new implementations. Use **SFTP/SharePoint** patterns when vendors cannot change their existing submission workflows.

---

#### **Common Benefits Across All Patterns**

- ✅ **Event-Driven or Scheduled**: Pipeline runs when new data arrives (or at configured intervals)
- ✅ **Cost-Efficient**: Serverless compute scales to zero when idle
- ✅ **Automatic**: No manual intervention required
- ✅ **Scalable**: Auto-scaling handles any data volume
- ✅ **Resilient**: Autoloader tracks processed files and handles failures

### Pipeline Task Flow

#### **Bronze Layer**: Study-Level Vendor Data Ingestion

**`bronze_vendor_data`** (Streaming table)
- **Purpose**: Ingest study-level vendor files submitted multiple times per day/week/month throughout trial duration
- **Technology**: Autoloader (streaming ingestion with schema inference)
- **File Formats**: CSV, BDAT (SAS), Parquet, JSON
- **Schema Evolution**: Enabled via `cloudFiles.schemaEvolutionMode = "addNewColumns"`
- **Vendors send data repeatedly**: Same study data updated/corrected over time
- **Pipeline Trigger**: File arrival trigger via Unity Catalog Volume notifications automatically starts SDP pipeline on new vendor file submission
- **Execution Mode**: `trigger(availableNow=True)` for event-driven batch processing (process all available files, then stop)

```python
import pyspark.pipelines as dp

@dp.table(comment="Bronze layer - study-level vendor data ingestion with file arrival trigger")
def bronze_vendor_data():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("cloudFiles.schemaLocation", "/checkpoints/vendor_data/schema")
        .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
        .load("/Volumes/catalog/schema/vendor_submissions/")
    )

# Pipeline configuration (in databricks.yml or pipeline settings)
# trigger: availableNow=True (event-driven batch processing)
# workflow_trigger: file_arrival on Unity Catalog Volume /vendor_submissions/
```

#### **Validation Rules Metadata**: Configuration Stored in Delta Tables

**`md_conformance_validation_rules`** (Delta table)
- Stores all validation rules for each DTA entity
- Joined at **Step 2 (DQ Validation)** of each validation flow
- Contains: `rule_id`, `entity`, `constraint`, `severity` (CRITICAL/WARNING), `action` (DROP/FLAG)

```python
# Metadata table structure
md_conformance_validation_rules = [
    {"entity": "TC", "constraint": "TEST_CODE IS NOT NULL", "severity": "CRITICAL", "action": "DROP"},
    {"entity": "TC", "constraint": "TEST_UNIT IN (...)", "severity": "WARNING", "action": "FLAG"},
    # ... more rules
]
```

#### **Silver Layer**: Parallel Validation Flows (4-Step Pattern per Entity)

Each DTA library entity (TV, TC, CL, Times & Visits, OA, DIP) follows the **same 4-step validation pattern**:

**Example: TC (Test Concepts) Validation Flow**

**Step 1: Read TC Data** (`bronze_vendor_data_tc`)
- Streaming table
- Reads TC-specific records from Bronze
- Filters by entity type or data pattern

```python
@dp.table(comment="Step 1: Read TC data from Bronze")
def bronze_vendor_data_tc():
    return spark.readStream.table("bronze_vendor_data") \
        .filter("record_type = 'TC' OR test_code IS NOT NULL")
```

**Step 2: DQ Validation with Rules** (`tc_dq_validated`)
- Streaming table
- **Joins with validation rules metadata** from `md_conformance_validation_rules`
- **CRITICAL rules** → DROP records + log to audit
- **WARNING rules** → FLAG records + log to audit

```python
@dp.table(comment="Step 2: DQ validation with metadata-driven rules")
@dp.expect_or_drop("tc_critical_test_code", "TEST_CODE IS NOT NULL")
@dp.expect_or_drop("tc_critical_format", "TEST_FORMAT IN ('CHAR', 'NUM')")
@dp.expect("tc_warning_length", "length(TEST_VALUE) <= 50")
def tc_dq_validated():
    tc_data = spark.readStream.table("bronze_vendor_data_tc")
    
    # Join with validation rules from metadata
    rules = spark.table("md_conformance_validation_rules") \
        .filter("entity = 'TC' AND is_active = 'Y'")
    
    # Apply rules dynamically (simplified example)
    return tc_data  # Rules applied via @dp.expect_* decorators
```

**Step 3: Transform to Generic Structure** (`tc_transformed`)
- Streaming table
- Standardize column names (vendor-specific → generic)
- Apply data type conversions
- Map to generic schema

```python
@dp.table(comment="Step 3: Transform to generic structure")
def tc_transformed():
    return (
        spark.readStream.table("tc_dq_validated")
        .withColumnRenamed("VENDOR_TEST_CD", "TEST_CODE")
        .withColumnRenamed("VENDOR_TEST_VAL", "TEST_VALUE")
        .withColumn("TEST_VALUE", col("TEST_VALUE").cast("string"))
        # ... more transformations
    )
```

**Step 4: Auto CDC for Change Tracking** (`tc_silver`)
- Streaming table with SCD Type 2
- **Handles vendor re-submissions**: INSERT, UPDATE, DELETE
- **Tracks changes**: `__START_AT`, `__END_AT`, `__CURRENT` columns automatically added
- **Sequence by**: `submission_timestamp` or `file_received_date`
- **Keys**: `STUDY_ID`, `SUBJECT_ID`, `TEST_CODE`, `VISIT`

```python
@dp.table(comment="Step 4: Auto CDC - Track vendor re-submissions")
def tc_silver():
    return (
        dp.read_stream("tc_transformed")
        .apply_changes(
            target="tc_silver",
            keys=["STUDY_ID", "SUBJECT_ID", "TEST_CODE", "VISIT"],
            sequence_by="submission_timestamp",
            stored_as_scd_type=2,
            track_history_column_list=["TEST_VALUE", "TEST_UNIT", "REFERENCE_RANGE"],
            ignore_null_updates=True
        )
    )
```

**Result of Auto CDC** (Example: Vendor submits GLUC test 3 times with corrections):

| STUDY_ID | SUBJECT_ID | TEST_CODE | TEST_VALUE | submission_timestamp | __START_AT | __END_AT | __CURRENT |
|----------|------------|-----------|------------|---------------------|------------|----------|-----------|
| STU001 | SUB001 | GLUC | 95 | 2026-01-01 | 2026-01-01 | 2026-01-15 | false |
| STU001 | SUB001 | GLUC | 98 | 2026-01-15 | 2026-01-15 | 2026-02-01 | false |
| STU001 | SUB001 | GLUC | 101 | 2026-02-01 | 2026-02-01 | NULL | **true** |

**All Parallel Validation Flows** (Same 4-Step Pattern):

1. **TV Flow**: `bronze_vendor_data_tv` → `tv_dq_validated` → `tv_transformed` → `tv_silver` (Auto CDC)
2. **TC Flow**: `bronze_vendor_data_tc` → `tc_dq_validated` → `tc_transformed` → `tc_silver` (Auto CDC)
3. **CL Flow**: `bronze_vendor_data_cl` → `cl_dq_validated` → `cl_transformed` → `cl_silver` (Auto CDC)
4. **OA Flow**: `bronze_vendor_data_oa` → `oa_dq_validated` → `oa_transformed` → `oa_silver` (Auto CDC)
5. **DIP Flow**: `bronze_vendor_data_dip` → `dip_dq_validated` → `dip_transformed` → `dip_silver` (Auto CDC)
6. **Times & Visits Flow**: `bronze_vendor_data_tv2` → `tv2_dq_validated` → `tv2_transformed` → `tv2_silver` (Auto CDC)

#### **Validation Sink**: Non-Blocking Audit Log

**`audit_delta_sink`** (Sink - non-blocking)
- Captures all validation failures from all flows
- CRITICAL failures (records dropped)
- WARNING flags (records passed but flagged)
- Drift metrics and validation results per entity
- Writes asynchronously without blocking validation tasks

```python
@dp.table(comment="Audit sink - non-blocking validation results")
def audit_delta_sink():
    # Union audit records from all validation flows
    return (
        spark.table("tc_dq_validated").filter("is_valid = false")
        .union(spark.table("tv_dq_validated").filter("is_valid = false"))
        .union(spark.table("cl_dq_validated").filter("is_valid = false"))
        # ... all other flows
        .select("audit_id", "entity", "study_id", "rule", "severity", "action", "record_details")
    )
```

#### **Gold Layer**: Study-Level Validated Data

**`study_level_gold schema`** (Materialized view)
- Study-level validated data aggregated from all validation flows
- DTA validates against study-level vendor submissions
- **Specific table structure out of scope** (focus on validation process, not final schema)
- Downstream analytics and reporting use this schema

---

## SDP Expectations Framework

### Expectations Hierarchy

The validation framework leverages **SDP Expectations** ([documentation](https://docs.databricks.com/aws/en/ldp/expectation-patterns)) with a three-tier model for granular data quality control:

![Expectations Hierarchy](./diagrams/12_expectations_hierarchy.png)

**Expectations Flow**:

1. **FAIL Expectations** (`expect_or_fail`) → Pipeline stops if any record fails; critical blocking validations
2. **QUARANTINE Expectations** (`expect_or_drop`) → Invalid records dropped and isolated; severe but non-blocking
3. **WARN Expectations** (`expect`) → Records flagged but processed; informational issues

### Implementation Example: Transfer Variables Validation

```python
import pyspark.pipelines as dp

@dp.table(
    comment="Silver layer - Transfer Variables validation with expectations"
)
@dp.expect_or_fail("tv_required_columns", "SUBJID IS NOT NULL AND VISIT IS NOT NULL")
@dp.expect_or_fail("tv_data_type_match", "typeof(SUBJID) = 'string' AND typeof(AGE) IN ('int', 'bigint')")
@dp.expect_or_drop("tv_codelist_values", "SEX IN ('M', 'F', 'U', 'UNKNOWN')")
@dp.expect_or_drop("tv_length_major_violation", "length(SUBJID) <= 30")  # 1.5x DTA max_length
@dp.expect("tv_length_minor_violation", "length(SUBJID) <= 24")  # 1.2x DTA max_length
@dp.expect("tv_unexpected_nulls", "VISIT IS NOT NULL OR dta_populate_flag = 'N'")
def silver_tv_validated():
    # Join vendor data with DTA metadata
    vendor_data = spark.readStream.table("bronze_vendor_data")
    dta_tv_meta = spark.table("gold.md_dta_transfer_variables") \
        .filter(f"dta_id = '{spark.conf.get('pipeline.dta_id')}'")
    
    return vendor_data.join(dta_tv_meta, vendor_data.column_name == dta_tv_meta.transfer_variable_name, "left")
```

### Metadata-Driven Expectations

For production, expectations are loaded from `md_conformance_validation_rules` metadata table:

```python
# Load validation rules from metadata
validation_rules = spark.table("gold.md_conformance_validation_rules") \
    .filter("library_type = 'transfer_variables' AND is_active = 'Y'") \
    .collect()

# Apply expectations dynamically
for rule in validation_rules:
    if rule.action == "FAIL":
        dp.expect_or_fail(rule.constraint_name, rule.constraint)
    elif rule.action == "QUARANTINE":
        dp.expect_or_drop(rule.constraint_name, rule.constraint)
    elif rule.action == "WARN":
        dp.expect(rule.constraint_name, rule.constraint)
```

### Validation Rules by Library Type

**FAIL Rules** (Critical - Pipeline Blocking):
```python
{
    "tv_required_columns_present": "SUBJID IS NOT NULL AND VISIT IS NOT NULL",
    "tv_data_type_match": "typeof(SUBJID) = 'string' AND typeof(AGE) = 'integer'",
    "tc_required_test_code": "TEST_CODE IS NOT NULL",
    "cl_codelist_required": "CODELIST_NAME IS NOT NULL AND CODELIST_VALUE IS NOT NULL"
}
```

**QUARANTINE Rules** (Severe - Drop Records):
```python
{
    "tv_length_major_violation": "length(SUBJID) <= anticipated_max_length * 1.5",
    "tv_codelist_values": "SEX IN (SELECT codelist_value FROM dta_codelists WHERE codelist_name = 'SEX')",
    "tc_unit_mismatch": "TEST_UNIT IN (SELECT unit FROM dta_test_concepts WHERE test_code = TEST_CODE)"
}
```

**WARN Rules** (Minor - Flag Only):
```python
{
    "tv_length_minor_violation": "length(SUBJID) <= anticipated_max_length * 1.2",
    "tv_unexpected_nulls": "VISIT IS NOT NULL OR populate_for_all_records = 'No'",
    "tc_reference_range_outlier": "TEST_VALUE BETWEEN lower_limit AND upper_limit"
}
```

---

## Data Drift Detection Strategy

### Conformance Dimensions

| Dimension | Description | DTA Source Table | Validation Type |
|-----------|-------------|------------------|-----------------|
| **Transfer Variables** | Column names, data types, order, length | `md_dta_transfer_variables` | Schema + Data |
| **Test Concepts** | Test concept values, mappings | `md_dta_vendor_test_concepts` | Data |
| **Codelists** | Codelist values, SDTM mappings | `md_dta_codelists` | Data |
| **Operational Agreements** | Trial-specific agreements | `md_dta_operational_agreement` | Metadata |
| **Data Ingestion Parameters** | File formats, delimiters, encodings | `md_dta_data_ingestion_parameters` | Metadata |

### Transfer Variables (TV) Validation Example

**DTA Definition** (from `md_dta_transfer_variables`):
```
transfer_variable_name: "SUBJID"
format: "TEXT"
anticipated_max_length: 20
populate_for_all_records: "Yes"
codelist_values: []
```

**Vendor Data Validation**:
1. **Column Exists**: `SUBJID` must be present
2. **Data Type Match**: Must be string/text
3. **Length Validation**: Max 20 characters
4. **NULL Check**: No NULL values (populate_for_all_records = Yes)
5. **Codelist Validation**: If codelist_values defined, check against allowed values

**Drift Detection**:
- If vendor sends `SUBJID` with length 30 → **WARN** (exceeds anticipated max)
- If vendor sends `SUBJID` with NULL → **FAIL** (mandatory field)
- If vendor renames to `SUBJECT_ID` → **FAIL** (column missing)

---

## SDP Feature Implementation

### 0. Expectations - Data Quality Validation

**Use Case**: Enforce data quality rules at validation step with three severity levels to handle CRITICAL, WARNING, and INFO validation failures.

**Documentation**: [SDP Expectations](https://docs.databricks.com/aws/en/ldp/expectation-patterns)

**Three-Tier Validation Model**:

| Expectation Type | Decorator | Severity | Action | Use Case |
|-----------------|-----------|----------|--------|----------|
| **FAIL** | `@dp.expect_or_fail()` | CRITICAL | Pipeline stops if any record fails | Mandatory fields, data type mismatches |
| **DROP** | `@dp.expect_or_drop()` | WARNING | Drop invalid records, continue pipeline | Codelist violations, format errors |
| **WARN** | `@dp.expect()` | INFO | Flag records but pass through | Minor issues, informational alerts |

**Implementation Example**:

```python
import pyspark.pipelines as dp

@dp.table(comment="TC Step 2: DQ validation with expectations")
# CRITICAL: Pipeline stops if these fail
@dp.expect_or_fail("tc_critical_test_code", "TEST_CODE IS NOT NULL")
@dp.expect_or_fail("tc_critical_data_type", "typeof(TEST_VALUE) IN ('string', 'double', 'int')")

# WARNING: Drop invalid records, log to audit
@dp.expect_or_drop("tc_warning_codelist", "TEST_UNIT IN (SELECT unit FROM gold.md_dta_vendor_test_concepts)")
@dp.expect_or_drop("tc_warning_length", "length(TEST_CODE) <= 20")

# INFO: Flag but allow through
@dp.expect("tc_info_missing_optional", "REFERENCE_RANGE IS NOT NULL OR test_type <> 'LAB'")
@dp.expect("tc_info_unexpected_format", "TEST_VALUE NOT LIKE '%[^0-9.]%' OR test_type <> 'NUMERIC'")
def tc_dq_validated():
    tc_data = spark.readStream.table("bronze_vendor_data_tc")
    
    # Join with DTA metadata
    dta_tc = spark.table("gold.md_dta_vendor_test_concepts") \
        .filter(f"dta_id = '{spark.conf.get('pipeline.dta_id')}'")
    
    return tc_data.join(dta_tc, "test_code", "left")
```

**Metadata-Driven Expectations Pattern**:

Load validation rules dynamically from `md_conformance_validation_rules` Delta table:

```python
# Load rules from metadata
validation_rules = spark.table("md_conformance_validation_rules") \
    .filter("entity = 'TC' AND is_active = 'Y'") \
    .collect()

# Build expectation decorators dynamically
expectations = []
for rule in validation_rules:
    if rule.severity == "CRITICAL":
        expectations.append(f"@dp.expect_or_fail('{rule.rule_id}', \"{rule.constraint}\")")
    elif rule.severity == "WARNING":
        expectations.append(f"@dp.expect_or_drop('{rule.rule_id}', \"{rule.constraint}\")")
    else:  # INFO
        expectations.append(f"@dp.expect('{rule.rule_id}', \"{rule.constraint}\")")

# Apply expectations programmatically (simplified)
# In practice, use decorators or dynamic function generation
```

**Example Metadata Table** (`md_conformance_validation_rules`):

| rule_id | entity | constraint | severity | action | is_active |
|---------|--------|-----------|----------|--------|-----------|
| tc_001 | TC | TEST_CODE IS NOT NULL | CRITICAL | FAIL | Y |
| tc_002 | TC | TEST_UNIT IN (...) | WARNING | DROP | Y |
| tc_003 | TC | TEST_VALUE IS NOT NULL | INFO | WARN | Y |

**Benefits**:
- ✅ **Three-Tier Control**: Granular handling of different severity levels
- ✅ **Pipeline Resilience**: Drop bad records instead of stopping entire pipeline
- ✅ **Metadata-Driven**: Add/modify rules without code changes
- ✅ **Audit Trail**: All expectation failures logged to event log
- ✅ **Step 2 Integration**: Seamlessly integrates with DQ Validation step of 4-step pattern

---

### 1. Flows - Multiple Sources to Single Target

**Use Case**: Multiple vendor submission folders writing to the same Bronze table.

**Documentation**: [SDP Flows](https://docs.databricks.com/aws/en/ldp/flows)

**Implementation**:

```python
import pyspark.pipelines as dp

# Create the target streaming table
dp.create_streaming_table("bronze_vendor_data")

# Flow 1: North America vendor submissions
@dp.append_flow(target="bronze_vendor_data")
def vendor_na_flow():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .load("/Volumes/catalog/schema/vendor_na/")
        .withColumn("region", lit("NA"))
    )

# Flow 2: Europe vendor submissions
@dp.append_flow(target="bronze_vendor_data")
def vendor_eu_flow():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .load("/Volumes/catalog/schema/vendor_eu/")
        .withColumn("region", lit("EU"))
    )

# Flow 3: Asia vendor submissions
@dp.append_flow(target="bronze_vendor_data")
def vendor_apac_flow():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .load("/Volumes/catalog/schema/vendor_apac/")
        .withColumn("region", lit("APAC"))
    )
```

**Benefits**:
- ✅ **Incremental Additions**: Add new vendor regions without full refresh
- ✅ **Independent Checkpoints**: Each flow maintains its own checkpoint
- ✅ **Union Alternative**: More efficient than `UNION` for streaming data

**Backfill Pattern** (ONCE flow for historical data):

```python
# One-time backfill of historical data
@dp.append_flow(target="bronze_vendor_data")
def vendor_historical_backfill():
    return spark.read.parquet("/Volumes/catalog/schema/historical_archive/") \
        .withColumn("is_backfill", lit(True))
```

SQL equivalent:
```sql
CREATE FLOW vendor_historical_backfill
AS INSERT INTO ONCE bronze_vendor_data BY NAME
SELECT *, TRUE as is_backfill FROM parquet.`/Volumes/catalog/schema/historical_archive/`;
```

---

### 2. Auto CDC - Simplified Change Data Capture

**Use Case**: Track vendor data changes over time with SCD Type 2.

**Documentation**: [Auto CDC](https://docs.databricks.com/aws/en/ldp/database-replication)

**Implementation**:

```python
import pyspark.pipelines as dp

@dp.table(
    comment="Gold layer - Transfer Variables with SCD Type 2 tracking"
)
def gold_tv_validated():
    return (
        dp.read_stream("silver_tv_validated")
        .apply_changes(
            target="gold_tv_validated",
            keys=["SUBJID", "VISIT", "VARIABLE_NAME"],
            sequence_by="processing_timestamp",
            stored_as_scd_type=2,
            track_history_column_list=["VARIABLE_VALUE", "DATA_TYPE", "LENGTH"],
            track_history_except_column_list=["processing_timestamp", "file_id"]
        )
    )
```

**What Auto CDC Handles Automatically**:
- ✅ **SCD Type 2 Columns**: `__START_AT`, `__END_AT`, `__CURRENT` added automatically
- ✅ **Change Detection**: Compares tracked columns to detect updates
- ✅ **Historical Records**: Previous versions retained with end timestamps
- ✅ **Upsert Logic**: INSERT for new, UPDATE for existing (close old record, insert new)

**Example Output**:

| SUBJID | VISIT | VARIABLE_NAME | VARIABLE_VALUE | __START_AT | __END_AT | __CURRENT |
|--------|-------|---------------|----------------|------------|----------|-----------|
| 001 | Week1 | AGE | 45 | 2026-01-01 | 2026-02-01 | false |
| 001 | Week1 | AGE | 46 | 2026-02-01 | NULL | true |

**SQL Equivalent**:

```sql
CREATE STREAMING TABLE gold_tv_validated;

CREATE FLOW gold_tv_cdc
AS APPLY CHANGES INTO gold_tv_validated
FROM STREAM(silver_tv_validated)
KEYS (SUBJID, VISIT, VARIABLE_NAME)
SEQUENCE BY processing_timestamp
STORED AS SCD TYPE 2
TRACK HISTORY ON (VARIABLE_VALUE, DATA_TYPE, LENGTH);
```

---

### 3. Sinks - Non-Blocking Audit Writes

**Use Case**: Write validation failures to audit tables without blocking pipeline execution.

**Documentation**: [SDP Sinks](https://docs.databricks.com/aws/en/ldp/ldp-sinks)

**Implementation**:

```python
import pyspark.pipelines as dp

# Primary validation table (Silver)
@dp.table(
    comment="Silver - Transfer Variables validation"
)
@dp.expect_or_fail("tv_required_fields", "SUBJID IS NOT NULL")
def silver_tv_validated():
    return spark.readStream.table("bronze_vendor_data")

# Audit sink - captures validation failures
@dp.table(
    comment="Audit sink - non-blocking write of validation failures"
)
def audit_conformance_sink():
    # Read event log to capture expectation failures
    event_log = spark.readStream.format("delta") \
        .option("readChangeFeed", "true") \
        .table("event_log(silver_tv_validated)")
    
    return (
        event_log
        .filter("expectation_status = 'FAIL' OR expectation_status = 'DROP'")
        .select(
            "timestamp",
            "flow_name",
            "expectation_name",
            "expectation_status",
            "record_count",
            "failed_record_count"
        )
        .writeStream
        .format("delta")
        .outputMode("append")
        .option("checkpointLocation", "/checkpoints/audit_sink")
        .toTable("l_conformance_audit")
    )
```

**Sink Benefits**:
- ✅ **Non-Blocking**: Pipeline continues even if sink write fails
- ✅ **Decoupled**: Audit logic separate from validation logic
- ✅ **Event Log**: Access to pipeline execution metadata
- ✅ **Multiple Sinks**: Write to multiple destinations (Delta, external systems)

**Multiple Sink Pattern**:

```python
# Multiple sinks for different outputs
@dp.table()
def audit_sink():
    return event_log_df.writeStream.toTable("l_conformance_audit")

@dp.table()
def drift_report_sink():
    return drift_summary_df.writeStream.toTable("l_conformance_drift_summary")

@dp.table()
def quarantine_sink():
    return quarantined_records_df.writeStream.toTable("l_conformance_quarantine")
```

---

### 4. Schema Evolution - Automatic Schema Handling

**Use Case**: Vendor adds new columns to CSV files without breaking pipeline.

**Documentation**: [Schema Evolution](https://docs.databricks.com/aws/en/ldp/from-json-schema-evolution)

**Implementation**:

```python
import pyspark.pipelines as dp

@dp.table(
    comment="Bronze with automatic schema evolution"
)
def bronze_vendor_data():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("cloudFiles.schemaLocation", "/checkpoints/vendor_data/schema")
        .option("cloudFiles.schemaEvolutionMode", "addNewColumns")  # Key setting
        .option("cloudFiles.inferColumnTypes", "true")
        .load("/Volumes/catalog/schema/vendor_submissions/")
    )
```

**Schema Evolution Modes**:

| Mode | Behavior | Use Case |
|------|----------|----------|
| `addNewColumns` | Automatically add new columns discovered in files | Vendor adds optional fields |
| `rescue` | Store unparseable data in `_rescued_data` column | Malformed records |
| `failOnNewColumns` | Fail pipeline if schema changes | Strict validation |

**Example Scenario**:

**Initial CSV** (Week 1):
```csv
SUBJID,VISIT,AGE,SEX
001,Week1,45,M
```

**Updated CSV** (Week 2 - vendor adds RACE column):
```csv
SUBJID,VISIT,AGE,SEX,RACE
001,Week2,45,M,Caucasian
```

**Pipeline Behavior**:
- ✅ **Week 1**: Table created with 4 columns
- ✅ **Week 2**: `RACE` column automatically added to table schema
- ✅ **No Failure**: Pipeline continues processing
- ✅ **Historical Data**: Week 1 records have `NULL` for `RACE`

**Validation Integration**:

```python
# Drift detection for unexpected columns
@dp.table()
@dp.expect("tv_schema_drift", "array_except(column_names, dta_expected_columns) = []")
def silver_tv_validated():
    vendor_data = spark.readStream.table("bronze_vendor_data")
    dta_meta = spark.table("gold.md_dta_transfer_variables")
    
    # Flag unexpected columns for review
    return vendor_data.withColumn(
        "unexpected_columns",
        expr("filter(column_names, col -> col NOT IN (SELECT column_name FROM dta_meta))")
    )
```

---

### 5. Transformations - Data Cleansing

**Use Case**: Standardize vendor data formats before validation.

**Documentation**: [Transform Data](https://docs.databricks.com/aws/en/ldp/transform)

**Implementation**:

```python
import pyspark.pipelines as dp
from pyspark.sql.functions import trim, upper, regexp_replace, coalesce, to_date

@dp.table(
    comment="Silver - Apply transformations before validation"
)
def silver_tv_transformed():
    bronze_df = spark.readStream.table("bronze_vendor_data")
    
    # Load transformation rules from metadata
    transform_rules = spark.table("gold.md_conformance_transformation_rules") \
        .filter("library_type = 'transfer_variables' AND is_active = 'Y'") \
        .collect()
    
    # Apply transformations
    transformed_df = bronze_df
    for rule in transform_rules:
        if rule.type == "trim":
            transformed_df = transformed_df.withColumn(rule.column_name, trim(col(rule.column_name)))
        elif rule.type == "uppercase":
            transformed_df = transformed_df.withColumn(rule.column_name, upper(col(rule.column_name)))
        elif rule.type == "title_case":
            transformed_df = transformed_df.withColumn(rule.column_name, initcap(col(rule.column_name)))
        elif rule.type == "date_standardization":
            transformed_df = transformed_df.withColumn(rule.column_name, to_date(col(rule.column_name), rule.format))
        elif rule.type == "default_value":
            transformed_df = transformed_df.withColumn(rule.column_name, coalesce(col(rule.column_name), lit(rule.default_value)))
    
    return transformed_df
```

**Common Transformations**:

```python
# Trim whitespace
.withColumn("SUBJID", trim(col("SUBJID")))

# Standardize case
.withColumn("SEX", upper(col("SEX")))  # M, F, U

# Remove special characters
.withColumn("TEST_CODE", regexp_replace(col("TEST_CODE"), "[^A-Z0-9]", ""))

# Date format standardization
.withColumn("VISIT_DATE", to_date(col("VISIT_DATE"), "yyyy-MM-dd"))

# Default values for NULLs
.withColumn("POPULATION_FLAG", coalesce(col("POPULATION_FLAG"), lit("ALL")))

# Numeric rounding
.withColumn("TEST_VALUE", round(col("TEST_VALUE"), 2))
```

**Metadata-Driven Transformation Rules**:

`md_conformance_transformation_rules` table:

| source_column_name | type | format | default_value | is_active |
|-------------------|------|--------|---------------|-----------|
| SUBJID | trim | NULL | NULL | Y |
| SEX | uppercase | NULL | NULL | Y |
| VISIT_DATE | date_standardization | yyyy-MM-dd | NULL | Y |
| POPULATION_FLAG | default_value | NULL | ALL | Y |

---

## Metadata-Driven Configuration

### Metadata Tables

The conformance engine uses metadata tables to drive all validation logic:

#### 1. `md_conformance_validation_rules`

Stores validation rules for each DTA library entity.

| Column | Description | Example |
|--------|-------------|---------|
| `source_table` | Bronze table name | `bronze_vendor_data` |
| `target_table` | Silver table name | `silver_tv_validated` |
| `library_type` | DTA library entity | `transfer_variables` |
| `constraint` | Validation expression | `SUBJID IS NOT NULL` |
| `action` | FAIL / WARN / QUARANTINE | `FAIL` |
| `is_active` | Enable/disable rule | `Y` |
| `dta_id` | DTA version reference | `DTA_A` |
| `version` | DTA version | `1.0-DTA_A-v1.0` |

#### 2. `md_conformance_transformation_rules`

Defines data transformations to apply.

| Column | Description | Example |
|--------|-------------|---------|
| `source_column_name` | Column to transform | `SUBJID` |
| `type` | Transformation type | `trim`, `title_case`, `default` |
| `transform_fn_name` | UDF function name | `trim_udf` |
| `is_active` | Enable/disable | `Y` |

#### 3. `md_conformance_source_metadata`

Maps vendor data sources to DTA library entities.

| Column | Description | Example |
|--------|-------------|---------|
| `dimension_table` | DTA library type | `transfer_variables` |
| `target_table` | Silver target | `silver_tv_validated` |
| `source_details` | Volume path | `/Volumes/.../vendor_data/` |
| `impacted_input_tables` | Bronze tables | `bronze_vendor_data` |
| `load_type` | incremental / one_time | `incremental` |
| `dta_id` | DTA reference | `DTA_A` |

#### 4. `md_conformance_cdc`

CDC configuration for SCD Type 2 tracking.

| Column | Description | Example |
|--------|-------------|---------|
| `source` | Pipeline source | `TV_VALIDATION` |
| `input_table` | Input table | `bronze_vendor_data` |
| `key_attr` | Primary key | `SUBJID,VISIT` |
| `scd_type` | 1 or 2 | `2` |
| `compute_cdc` | Y / N | `Y` |

---

## Parallel Task Execution Model

### Single Pipeline with Parallel Tasks

The conformance engine runs as a **single SDP pipeline** with parallel validation flows. Each DTA entity validation flow follows a **4-step pattern** (Read → DQ Validation → Transform → Auto CDC), and all flows execute in parallel within the same pipeline.

**Pipeline Structure** (Full Implementation with 4-Step Pattern):

```python
import pyspark.pipelines as dp
from pyspark.sql.functions import *

# ==================== METADATA: VALIDATION RULES ====================
# This Delta table is joined at Step 2 (DQ Validation) of each flow
# Contains CRITICAL and WARNING rules for all entities

validation_rules_metadata = spark.table("md_conformance_validation_rules")
# Example structure:
# | entity | constraint | severity | action |
# |--------|-----------|----------|--------|
# | TC     | TEST_CODE IS NOT NULL | CRITICAL | DROP   |
# | TC     | TEST_UNIT IN (...) | WARNING  | FLAG   |

# ==================== BRONZE: STUDY-LEVEL VENDOR DATA ====================
dp.create_streaming_table("bronze_vendor_data", comment="Study-level vendor files (CSV, BDAT, Parquet, JSON)")

@dp.append_flow(target="bronze_vendor_data")
def vendor_na_flow():
    return spark.readStream.format("cloudFiles") \
        .option("cloudFiles.format", "csv") \
        .option("cloudFiles.schemaEvolutionMode", "addNewColumns") \
        .load("/Volumes/catalog/schema/vendor_na/")

# ==================== TC VALIDATION FLOW (4 STEPS) ====================

# STEP 1: Read TC Data
@dp.table(comment="TC Step 1: Read TC data from Bronze")
def bronze_vendor_data_tc():
    return spark.readStream.table("bronze_vendor_data") \
        .filter("record_type = 'TC' OR test_code IS NOT NULL")

# STEP 2: DQ Validation (with metadata rules)
@dp.table(comment="TC Step 2: DQ validation with metadata-driven rules")
@dp.expect_or_drop("tc_critical_test_code", "TEST_CODE IS NOT NULL")
@dp.expect_or_drop("tc_critical_format", "TEST_FORMAT IN ('CHAR', 'NUM')")
@dp.expect("tc_warning_length", "length(TEST_VALUE) <= 50")
def tc_dq_validated():
    tc_data = spark.readStream.table("bronze_vendor_data_tc")
    
    # Join with validation rules metadata
    rules = spark.table("md_conformance_validation_rules") \
        .filter("entity = 'TC' AND is_active = 'Y'")
    
    # Apply DTA metadata validation
    dta_tc = spark.table("gold.md_dta_vendor_test_concepts")
    
    return tc_data.join(dta_tc, "test_code", "left")  # CRITICAL/WARNING rules applied via decorators

# STEP 3: Transform to Generic Structure
@dp.table(comment="TC Step 3: Transform to generic structure")
def tc_transformed():
    return (
        spark.readStream.table("tc_dq_validated")
        .withColumnRenamed("VENDOR_TEST_CD", "TEST_CODE")
        .withColumnRenamed("VENDOR_TEST_VAL", "TEST_VALUE")
        .withColumn("TEST_VALUE", col("TEST_VALUE").cast("string"))
        .withColumn("TEST_CODE", trim(upper(col("TEST_CODE"))))
        # ... more transformations
    )

# STEP 4: Auto CDC (SCD Type 2 for vendor re-submissions)
@dp.table(comment="TC Step 4: Auto CDC - Track vendor re-submissions with SCD Type 2")
def tc_silver():
    return (
        dp.read_stream("tc_transformed")
        .apply_changes(
            target="tc_silver",
            keys=["STUDY_ID", "SUBJECT_ID", "TEST_CODE", "VISIT"],
            sequence_by="submission_timestamp",
            stored_as_scd_type=2,
            track_history_column_list=["TEST_VALUE", "TEST_UNIT", "REFERENCE_RANGE"],
            ignore_null_updates=True
        )
    )

# ==================== TV VALIDATION FLOW (4 STEPS) ====================

# STEP 1: Read TV Data
@dp.table(comment="TV Step 1: Read Transfer Variables from Bronze")
def bronze_vendor_data_tv():
    return spark.readStream.table("bronze_vendor_data") \
        .filter("record_type = 'TV'")

# STEP 2: DQ Validation
@dp.table(comment="TV Step 2: DQ validation")
@dp.expect_or_drop("tv_critical_subjid", "SUBJID IS NOT NULL")
@dp.expect("tv_warning_length", "length(VARIABLE_VALUE) <= 200")
def tv_dq_validated():
    return spark.readStream.table("bronze_vendor_data_tv") \
        .join(spark.table("gold.md_dta_transfer_variables"), "column_name", "left")

# STEP 3: Transform
@dp.table(comment="TV Step 3: Transform")
def tv_transformed():
    return spark.readStream.table("tv_dq_validated") \
        .withColumnRenamed("VENDOR_VAR_NM", "VARIABLE_NAME") \
        .withColumn("VARIABLE_NAME", upper(col("VARIABLE_NAME")))

# STEP 4: Auto CDC
@dp.table(comment="TV Step 4: Auto CDC")
def tv_silver():
    return (
        dp.read_stream("tv_transformed")
        .apply_changes(
            target="tv_silver",
            keys=["STUDY_ID", "SUBJID", "VISIT", "VARIABLE_NAME"],
            sequence_by="submission_timestamp",
            stored_as_scd_type=2
        )
    )

# ==================== CL VALIDATION FLOW (4 STEPS) ====================

# STEP 1: Read CL Data
@dp.table(comment="CL Step 1: Read Codelists from Bronze")
def bronze_vendor_data_cl():
    return spark.readStream.table("bronze_vendor_data") \
        .filter("record_type = 'CL'")

# STEP 2: DQ Validation
@dp.table(comment="CL Step 2: DQ validation")
@dp.expect_or_drop("cl_critical_codelist", "CODELIST_NAME IS NOT NULL")
def cl_dq_validated():
    return spark.readStream.table("bronze_vendor_data_cl") \
        .join(spark.table("gold.md_dta_codelists"), "codelist_name", "left")

# STEP 3: Transform
@dp.table(comment="CL Step 3: Transform")
def cl_transformed():
    return spark.readStream.table("cl_dq_validated")  # transformations here

# STEP 4: Auto CDC
@dp.table(comment="CL Step 4: Auto CDC")
def cl_silver():
    return (
        dp.read_stream("cl_transformed")
        .apply_changes(
            target="cl_silver",
            keys=["STUDY_ID", "CODELIST_NAME", "CODE_VALUE"],
            sequence_by="submission_timestamp",
            stored_as_scd_type=2
        )
    )

# ==================== OA, DIP, TIMES & VISITS FLOWS ====================
# (Similar 4-step pattern for each: Read → DQ → Transform → Auto CDC)

# OA Flow (4 steps): bronze_vendor_data_oa → oa_dq_validated → oa_transformed → oa_silver
# DIP Flow (4 steps): bronze_vendor_data_dip → dip_dq_validated → dip_transformed → dip_silver
# Times & Visits Flow (4 steps): bronze_vendor_data_tv2 → tv2_dq_validated → tv2_transformed → tv2_silver

# ==================== VALIDATION SINK (NON-BLOCKING) ====================

# Audit Sink - Non-blocking capture of validation failures
@dp.table(comment="Audit sink - validation failures from all flows")
def audit_delta_sink():
    # Non-blocking sink - captures validation failures from all entity flows
    return (
        spark.table("tc_dq_validated").filter("is_valid = false")
        .union(spark.table("tv_dq_validated").filter("is_valid = false"))
        .union(spark.table("cl_dq_validated").filter("is_valid = false"))
        .union(spark.table("oa_dq_validated").filter("is_valid = false"))
        .union(spark.table("dip_dq_validated").filter("is_valid = false"))
        .union(spark.table("tv2_dq_validated").filter("is_valid = false"))
        .select(
            "audit_id", 
            "entity", 
            "study_id", 
            "rule", 
            "severity", 
            "action", 
            "record_details"
        )
    )

# ==================== GOLD LAYER: STUDY-LEVEL VALIDATED DATA ====================

# study_level_gold schema (materialized view)
# Aggregated validated data from all Silver CDC tables (tc_silver, tv_silver, cl_silver, etc.)
# Specific table structure out of scope - focus on validation process

@dp.table(comment="Study-level validated TC data")
def study_level_gold_tc():
    return spark.table("tc_silver").filter("__CURRENT = true")

@dp.table(comment="Study-level validated TV data")
def study_level_gold_tv():
    return spark.table("tv_silver").filter("__CURRENT = true")

# ... additional gold tables for CL, OA, DIP, Times & Visits
```

### Task Execution Flow

**Execution Pattern** (Left-to-Right, 4-Step per Entity):

```
┌────────────────────────────────────────────────────────────────────────────┐
│                     Validation Rules Metadata (Delta)                       │
│                     md_conformance_validation_rules                         │
│              (CRITICAL/WARNING rules, joined at Step 2)                     │
└──────────────────────────────┬─────────────────────────────────────────────┘
                               │ (lookup rules)
                               ↓
┌─────────────────┐     ┌──────────────────────────────────────────┐
│  BRONZE LAYER   │     │        SILVER LAYER - PARALLEL FLOWS      │
│                 │     │                                           │
│ bronze_vendor_  │────→│  TC Flow (4 steps):                       │
│ data            │     │  ① bronze_vendor_data_tc                  │
│                 │     │  ② tc_dq_validated (with rules)           │
│ Study-level     │     │  ③ tc_transformed                         │
│ vendor files    │     │  ④ tc_silver (Auto CDC - SCD Type 2)      │
│ (CSV, BDAT,     │     │                                           │
│  Parquet, JSON) │     │  TV Flow (4 steps):                       │
│                 │     │  ① bronze_vendor_data_tv                  │
│ Vendors send    │     │  ② tv_dq_validated (with rules)           │
│ multiple times  │     │  ③ tv_transformed                         │
│ per day/week    │     │  ④ tv_silver (Auto CDC)                   │
│                 │     │                                           │
│                 │     │  CL, OA, DIP, Times & Visits Flows...    │
│                 │     │  (Same 4-step pattern)                    │
└─────────────────┘     └────┬──────────────────────┬───────────────┘
                             │                      │
                             ↓                      ↓
                   ┌─────────────────┐    ┌───────────────────────┐
                   │  SINK (NON-     │    │    GOLD LAYER         │
                   │   BLOCKING)     │    │                       │
                   │                 │    │ study_level_gold      │
                   │ audit_delta_    │    │ schema                │
                   │ sink            │    │                       │
                   │                 │    │ Materialized views    │
                   │ • CRITICAL      │    │ of validated data     │
                   │   failures      │    │                       │
                   │ • WARNING flags │    │ (Current version:     │
                   │ • Drift metrics │    │  __CURRENT = true)    │
                   └─────────────────┘    └───────────────────────┘
```

**Key Execution Features**:
- **Single Bronze Table**: All vendor files ingested into `bronze_vendor_data`
- **Metadata-Driven Rules**: Validation rules from Delta table joined at Step 2
- **4-Step Pattern per Entity**: Read → DQ Validation → Transform → Auto CDC
- **Parallel Flows**: All 6 entity flows (TV, TC, CL, OA, DIP, Times & Visits) run concurrently
- **Auto CDC Tracking**: SCD Type 2 handles vendor re-submissions (INSERT/UPDATE/DELETE)
- **Non-Blocking Sink**: Audit logs captured without blocking validation
- **Gold Layer**: Study-level validated data (current versions only)

### Benefits of Single Pipeline Architecture

**Key Architectural Advantages**:
- ✅ **Single Bronze Table**: All vendor files (CSV, BDAT, Parquet, JSON) ingested into one streaming table
- ✅ **Metadata-Driven Validation**: Rules stored in Delta tables, dynamically applied at DQ step
- ✅ **4-Step Validation Pattern**: Standardized flow (Read → DQ → Transform → CDC) for all entities
- ✅ **Parallel Entity Processing**: All 6 DTA entities (TV, TC, CL, OA, DIP, Times & Visits) validated concurrently
- ✅ **Auto CDC for Re-Submissions**: SCD Type 2 automatically tracks vendor data updates (INSERT/UPDATE/DELETE)
- ✅ **Non-Blocking Audit**: Validation failures logged asynchronously without blocking flows
- ✅ **Simplified Orchestration**: One pipeline to deploy, monitor, and manage
- ✅ **Unified Monitoring**: Single SDP dashboard for all validation activities
- ✅ **Event Log**: Unified event log for all validation activities
- ✅ **Failure Isolation**: Failed flow doesn't stop other parallel flows

**vs. Multiple Separate Pipelines**:

| Aspect | Single Pipeline (SDP) | Multiple Pipelines |
|--------|----------------------|-------------------|
| **Orchestration** | One pipeline | N pipelines (one per entity) |
| **Monitoring** | Single dashboard | N dashboards |
| **Bronze Layer** | Single table for all vendors | N separate bronze tables |
| **Validation Rules** | Centralized metadata table | Duplicated rule definitions |
| **Auto CDC** | Consistent SCD Type 2 pattern | Inconsistent implementations |
| **Audit Logging** | Unified sink | Fragmented logs |
| **Deployment** | Deploy once | Deploy N times |
| **Dependencies** | Automatic | Manual coordination |
| **Resource Sharing** | Efficient compute utilization | Duplicated overhead |

---

## Drift Reporting

### Drift Report Table: `t_conformance_audit`

Captures all validation failures for analysis and reporting.

| Column | Description | Example |
|--------|-------------|---------|
| `audit_id` | Unique audit record ID | `AUD_123456` |
| `dta_id` | DTA reference | `DTA_A` |
| `dta_version` | DTA version | `1.0-DTA_A-v1.0` |
| `library_type` | DTA entity | `transfer_variables` |
| `validation_table` | Pipeline table | `silver_tv_validated` |
| `processing_time` | Timestamp | `1675123456` |
| `business_date` | Data date | `2026-02-04` |
| `record_identifier` | Primary key | `SUBJID=001, VISIT=Week1` |
| `is_valid` | Pass/Fail flag | `false` |
| `action_type` | FAIL / WARN / QUARANTINE | `QUARANTINE` |
| `reason` | Failed constraint | `tv_codelist_values` |
| `column_name` | Affected column | `SEX` |
| `expected_value` | DTA definition | `M, F, U` |
| `actual_value` | Vendor value | `MALE` |
| `drift_category` | Classification | `codelist_violation` |

### Drift Dashboard Queries

**Summary by Library Type**:
```sql
SELECT 
    library_type,
    COUNT(*) as total_violations,
    SUM(CASE WHEN action_type = 'FAIL' THEN 1 ELSE 0 END) as fail_count,
    SUM(CASE WHEN action_type = 'QUARANTINE' THEN 1 ELSE 0 END) as quarantine_count,
    SUM(CASE WHEN action_type = 'WARN' THEN 1 ELSE 0 END) as warn_count
FROM t_conformance_audit
WHERE dta_id = 'DTA_A' AND business_date = '2026-02-04'
GROUP BY library_type
```

**Top Drift Issues**:
```sql
SELECT 
    library_type,
    column_name,
    reason,
    COUNT(*) as occurrence_count,
    COUNT(DISTINCT record_identifier) as affected_records
FROM t_conformance_audit
WHERE dta_id = 'DTA_A' AND business_date = '2026-02-04'
GROUP BY library_type, column_name, reason
ORDER BY occurrence_count DESC
LIMIT 10
```

---

## Integration with Existing Pipelines

### Integration Architecture

The integrated architecture diagram above shows the complete end-to-end flow from study setup through data validation to output consumption. The conformance engine integrates seamlessly with the existing CDH ecosystem:

### Integration Points

**Upstream Inputs**:
1. **Study Setup**: Provides trial configuration, vendor registration, and validation rules configuration
2. **DTA Builder**: Supplies approved DTA metadata (Transfer Variables, Test Concepts, Codelists, Times & Visits, Operational Agreements, Data Ingestion Parameters)
3. **Vendor Data Landing**: Receives vendor study files with file arrival trigger events

**Conformance Engine Processing**:
- **Event-Driven Execution**: UC Volume file arrival triggers SDP pipeline start
- **Metadata Join**: References DTA metadata from Gold layer during DQ validation step
- **Parallel Validation**: Processes all 6 DTA entities concurrently (TV, TC, CL, OA, DIP, Times & Visits)
- **Auto CDC**: Tracks vendor data changes across multiple submissions
- **Audit Logging**: Captures validation failures, drift metrics, and quarantined records

**Downstream Outputs**:
- **Marvel Application**: Consumes study-level validated Gold data for downstream analytics, reporting, and regulatory submissions

### Shared Metadata

The conformance engine **reads from** the same DTA metadata tables created by the ingestion pipeline:

- `md_dta_transfer_variables` (Gold)
- `md_dta_vendor_test_concepts` (Gold)
- `md_dta_codelists` (Gold)
- `md_dta_operational_agreement` (Gold)

**No duplication** – single source of truth for DTA definitions.

---

## Framework Components

### Core APIs (Framework Utilities)

The conformance engine leverages the following SDP framework utilities for metadata-driven validation:

#### 1. Metadata Management
- `get_conformance_metadata()` - Load conformance source metadata from `md_conformance_source_metadata`
- `get_validation_rules(library_type, dta_id)` - Fetch validation rules by library type from `md_conformance_validation_rules`
- `get_transformation_rules(library_type)` - Fetch transformation rules from `md_conformance_transformation_rules`
- `get_cdc_attributes(library_type)` - Get CDC configuration from `md_conformance_cdc`
- `get_dta_metadata(dta_id)` - Fetch DTA definitions from Gold layer tables

#### 2. SDP Table Generation
- `create_bronze_streaming_table()` - Create bronze streaming tables with Autoloader
- `create_dq_validation_tables()` - Create validation tables with expectations (FAIL/QUARANTINE/WARN)
- `create_transformation_tables()` - Apply metadata-driven transformation rules
- `create_scd_tables()` - Apply Auto CDC for SCD Type 2 tracking

#### 3. Validation Execution
- `apply_dta_validation(library_type, bronze_df, dta_metadata)` - Compare vendor data against DTA metadata
- `calculate_drift(vendor_df, dta_df)` - Compute drift metrics (schema drift, value drift, cardinality drift)
- `generate_validation_report()` - Aggregate validation results across all library types

#### 4. Flow Management
- `create_append_flows(source_paths)` - Create multiple append flows to Bronze table
- `create_once_flows(backfill_paths)` - Create ONCE flows for historical backfill
- `manage_checkpoints(flow_names)` - Checkpoint management for flows

#### 5. Audit & Reporting
- `create_audit_sink()` - Publish audit records to Delta sink (non-blocking)
- `create_drift_report_sink()` - Create drift summary sink
- `create_quarantine_sink()` - Export quarantined records sink
- `generate_dashboard_queries()` - Create pre-defined queries for monitoring dashboard

---

## Future Enhancements

### Cross-Library Validation
- Validate relationships between Transfer Variables and Codelists
- Check Test Concepts against Transfer Variables
- Validate OA agreements against actual data submissions
- Cross-entity referential integrity checks

### Enhanced Monitoring and Alerting
- Immediate alerts for critical validation failures
- Live dashboards for data quality monitoring
- Trend analysis for validation metrics over time
- Automated notifications to stakeholders

---

## Benefits Summary

| Benefit | Description | Impact |
|---------|-------------|--------|
| **File Arrival Triggered Execution** | Pipeline automatically starts on vendor file submission via UC Volume notifications | ⚡ Event-driven & cost-efficient |
| **Single Bronze Table** | All vendor files (CSV, BDAT, Parquet, JSON) ingested into one streaming table | 🏗️ Simplified architecture |
| **Metadata-Driven Rules** | Validation rules stored in Delta tables, dynamically applied | 🔧 No code changes for new rules |
| **4-Step Validation Pattern** | Standardized flow (Read → DQ → Transform → CDC) for all entities | ♻️ Consistency & reusability |
| **Parallel Processing** | All 6 DTA entities validated concurrently in single pipeline | ⚡ Sub-linear scaling |
| **Auto CDC for Re-Submissions** | SCD Type 2 automatically tracks vendor data updates (INSERT/UPDATE/DELETE) | 📈 Complete change history |
| **Non-Blocking Audit** | Validation failures logged asynchronously without blocking flows | 🚀 Performance optimized |
| **Automated Validation** | No manual checks required for vendor submissions | 🚀 10x faster |
| **Vendor Re-Submission Tracking** | Handles multiple vendor data submissions per day/week/month | 🔄 Production-ready for trials |
| **Audit Trail** | Complete history for compliance and regulatory requirements | 📊 Regulatory ready |
| **Early Drift Detection** | Catch discrepancies between DTA and vendor data before production | ⚠️ Reduce downstream issues |
| **Integration** | Seamless with existing CDH ingestion pipelines | 🔗 Single platform |
| **Single Pipeline Management** | One SDP pipeline to deploy, monitor, and manage | 🎯 Simplified operations |

---

## Related Documentation

### Internal Documentation
- [11. CDH Ingestion Pipeline Design](./11_cdh_ingestion_pipeline_design.readme.md) - Source of DTA metadata
- [00. DTA Design Overview](./00_dta_design_overview.readme.md) - Overall DTA architecture
- [13. DTA Deployment Guide](./13_dta_deployment_guide.md) - Deployment procedures
- [02. DTA Schema Design](./02_dta_schema_design.readme.md) - DTA metadata tables

### Databricks Lakeflow Spark Declarative Pipelines (SDP) Documentation

**Core Concepts**:
- [SDP Flows](https://docs.databricks.com/aws/en/ldp/flows) - Multiple flows writing to single target, append-once patterns
- [Streaming Tables](https://docs.databricks.com/aws/en/ldp/streaming-tables) - Creating streaming tables
- [Materialized Views](https://docs.databricks.com/aws/en/ldp/materialized-views) - Batch processing with views

**Advanced Features**:
- [Auto CDC (Change Data Capture)](https://docs.databricks.com/aws/en/ldp/database-replication) - Simplified CDC for SCD Type 2
- [SDP Sinks](https://docs.databricks.com/aws/en/ldp/ldp-sinks) - Non-blocking writes to external systems
- [Schema Evolution](https://docs.databricks.com/aws/en/ldp/from-json-schema-evolution) - Automatic schema change handling
- [Transformations](https://docs.databricks.com/aws/en/ldp/transform) - Data transformation patterns
- [Expectations Framework](https://docs.databricks.com/aws/en/ldp/expectation-patterns) - Data quality validation patterns

**Operations**:
- [Pipeline Updates](https://docs.databricks.com/aws/en/ldp/updates) - Running and managing pipeline updates
- [Monitoring](https://docs.databricks.com/aws/en/ldp/monitoring) - Pipeline observability
- [Event Log](https://docs.databricks.com/aws/en/ldp/event-log) - Accessing pipeline execution metadata
# 13. DTA Deployment Guide

Complete guide for deploying the Clinical Data Standards (DTA) application to Databricks workspaces using Databricks Asset Bundles.

## Table of Contents

1. [Purpose](#1-purpose)
2. [DTA Framework using Databricks Asset Bundle](#2-dta-framework-using-databricks-asset-bundle)
   - [What is Databricks Asset Bundle (DAB)?](#what-is-databricks-asset-bundle-dab)
   - [DAB in the DTA Project](#dab-in-the-dta-project)
   - [Key Benefits for DTA](#key-benefits-for-dta)
   - [Project Structure](#project-structure)
3. [DTA Configuration](#3-dta-configuration)
   - [3.1 Databricks Bundle Configuration (`databricks.yml`)](#31-databricks-bundle-configuration-databricksyml)
     - [3.1.1 `bundle` Node](#311-bundle-node)
     - [3.1.2 `artifacts` Node](#312-artifacts-node)
     - [3.1.3 `include` Node](#313-include-node)
     - [3.1.4 `variables` Node](#314-variables-node)
     - [3.1.5 `targets` Node](#315-targets-node)
   - [3.2 Application Configuration (`clinical_data_standards.yaml`)](#32-application-configuration-clinical_data_standardsyaml)
     - [3.2.1 `globals` Section](#321-globals-section)
     - [3.2.2 `services` Section](#322-services-section)
     - [3.2.3 `pipelines` Section](#323-pipelines-section)
     - [3.2.4 `streaming` Section](#324-streaming-section)
     - [3.2.5 `versioning` Section](#325-versioning-section)
     - [3.2.6 `export` Section](#326-export-section)
   - [Configuration File Relationship](#configuration-file-relationship)
4. [Environment Setup](#4-environment-setup)
   - [4.1 Prerequisites](#41-prerequisites)
   - [4.2 Developer Setup](#42-developer-setup)
     - [Step 1: Authenticate with Databricks](#step-1-authenticate-with-databricks)
     - [Step 2: Clone Repository](#step-2-clone-repository)
     - [Step 3: Validate Bundle](#step-3-validate-bundle)
     - [Step 4: Deploy to Dev](#step-4-deploy-to-dev)
     - [Step 5: Deploy Flask App (Using Helper Script)](#step-5-deploy-flask-app-using-helper-script)
     - [Step 6: Run Initialization Jobs](#step-6-run-initialization-jobs)
     - [Destroy Application](#destroy-application)
   - [4.3 Staging and Production Setup](#43-staging-and-production-setup)
5. [DTA Application Initialization](#5-dta-application-initialization)
   - [Initialization Sequence](#initialization-sequence)
   - [5.1 Job: `job_test_cdm_cleanup`](#51-job-job_test_cdm_cleanup)
   - [5.2 Job: `job_cdm_sql_setup`](#52-job-job_cdm_sql_setup)
   - [5.3 Job: `job_populate_config_cache`](#53-job-job_populate_config_cache)
   - [5.4 Job: `job_cdm_sql_load_reference_data`](#54-job-job_cdm_sql_load_reference_data)
   - [5.5 Job: `job_cdm_app_permissions`](#55-job-job_cdm_app_permissions)
   - [5.6 Deploy Flask App](#56-deploy-flask-app)
   - [Quick Initialization Script](#quick-initialization-script)
6. [Troubleshooting](#6-troubleshooting)
   - [Common Issues](#common-issues)
   - [Rollback](#rollback)
7. [Best Practices](#7-best-practices)
8. [Support](#8-support)
9. [Related Documentation](#9-related-documentation)

---

## 1. Purpose

This deployment guide provides comprehensive instructions for deploying and initializing the Clinical Data Standards (DTA) application across different environments (Dev, Staging, Production). The guide covers:

- **Infrastructure Setup**: Using Databricks Asset Bundles (DAB) for reproducible deployments
- **Configuration Management**: Understanding and customizing the `databricks.yml` configuration
- **Application Initialization**: Running prerequisite jobs to prepare the environment
- **Environment-Specific Deployments**: Dev, Staging, and Production setup procedures

**Target Audience**: Data Engineers, DevOps Engineers, Platform Administrators

**Prerequisites**: 
- Familiarity with Databricks workspaces
- Basic understanding of Unity Catalog (catalogs, schemas, volumes)
- Access to appropriate Databricks workspace permissions

---

## 2. DTA Framework using Databricks Asset Bundle

### What is Databricks Asset Bundle (DAB)?

Databricks Asset Bundle is a deployment framework that enables:
- **Infrastructure as Code**: Define all Databricks resources in YAML files
- **Multi-Environment Deployment**: Consistent deployments across dev/staging/prod
- **Version Control**: Track infrastructure changes in Git
- **Atomic Deployments**: Deploy entire application stack in one command
- **Resource Management**: Automatic lifecycle management of jobs, pipelines, apps, and notebooks

![Databricks Asset Bundle Workflow](./diagrams/13_dab_workflow.png)

**Figure**: Databricks Asset Bundle development and deployment workflow showing local development, version control, CI/CD integration, and multi-environment deployment.

### DAB in the DTA Project

The DTA project uses DAB to manage:

| Resource Type | Count | Purpose |
|---------------|-------|---------|
| **Workflows (Jobs)** | 15+ | Data processing, setup, cleanup, testing |
| **Apps** | 1 | Flask-based management UI |
| **Artifacts** | 1 | Python wheel package for framework code |

### Key Benefits for DTA

1. **Single Command Deployment**: Deploy all resources with `databricks bundle deploy`
2. **Environment Isolation**: Separate dev/staging/prod with unique catalogs
3. **Reproducible Builds**: Same codebase deploys consistently across environments
4. **Permission Management**: Centralized access control in YAML
5. **Rollback Support**: Revert to previous deployment states

### Project Structure

```
clinical-data-standards/
├── databricks.yml              # Main bundle configuration
├── resources/                  # Resource definitions
│   ├── data_engineering/       # Data engineering jobs
│   │   ├── clinical_data_standards/jobs/
│   │   ├── common/jobs/
│   │   └── test/jobs/
│   ├── sql/                    # SQL setup jobs
│   │   ├── common/jobs/
│   │   └── test/jobs/
│   └── apps/                   # Flask application
├── notebooks/                  # Databricks notebooks
├── sql/                        # SQL scripts
├── src/                        # Python framework code
└── apps/                       # Flask app source
```

---

## 3. DTA Configuration

The DTA application uses two configuration files that work together:

1. **`databricks.yml`**: Databricks Asset Bundle configuration for deployment and infrastructure
2. **`config/clinical_data_standards.yaml`**: Application-specific configuration for data processing pipelines

---

### 3.1 Databricks Bundle Configuration (`databricks.yml`)

The `databricks.yml` file defines the infrastructure and deployment settings for the DAB framework.

#### Configuration File Structure

```yaml
databricks.yml
├── bundle                      # Project identity
├── artifacts                   # Wheel packages to build/deploy
├── include                     # Resource files to include
├── variables                   # Reusable configuration values
└── targets                     # Environment-specific settings
```

#### 3.1.1 `bundle` Node

**Purpose**: Defines the project identity and metadata.

```yaml
bundle:
  name: clinical-data-standards
  uuid: a671c688-a7fb-4ed7-9577-cb94c14a6653
```

| Field | Description | Value |
|-------|-------------|-------|
| `name` | Project identifier | `clinical-data-standards` |
| `uuid` | Unique bundle identifier (auto-generated) | `a671c688-a7fb-4ed7-9577-cb94c14a6653` |

#### 3.1.2 `artifacts` Node

**Purpose**: Defines Python wheel packages to build and deploy.

```yaml
artifacts:
  clinical_data_standards_framework:
    type: whl
    path: .
```

| Field | Description | Value |
|-------|-------------|-------|
| `type` | Artifact type | `whl` (Python wheel) |
| `path` | Source directory for `setup.py` | `.` (project root) |

**What it does**:
- Builds the Python wheel from `setup.py`
- Uploads the wheel to workspace `/Workspace/Users/{user}/.bundles/{bundle}/{target}/files/`
- Makes framework code available to notebooks and jobs

#### 3.1.3 `include` Node

**Purpose**: Specifies YAML files to include in the bundle (jobs, apps).

```yaml
include:
  - resources/sql/**/jobs/*.yml              # SQL setup jobs
  - resources/data_engineering/**/jobs/*.yml # Data engineering jobs
  - resources/apps/*.yml                      # Flask app
```

**What it does**: Recursively includes all `.yml` files matching the patterns, which define:
- **Jobs**: Workflow definitions
- **Apps**: Databricks Apps (Flask UI)

#### 3.1.4 `variables` Node

**Purpose**: Defines reusable variables for all environments (can be overridden per target).

```yaml
variables:
  usecase:
    description: Use case identifier
    default: "clinical_data_standards"
  
  catalog:
    description: Unity Catalog name
    default: "aira"
  
  bronze_schema:
    description: Schema for bronze layer
    default: "bronze_md"
  
  silver_schema:
    description: Schema for silver layer
    default: "silver_md"
  
  gold_schema:
    description: Schema for gold layer
    default: "gold_md"
  
  use_serverless:
    description: Use serverless compute
    default: Y
  
  warehouse_id:
    description: SQL Warehouse ID for SQL execution
    default: "148ccb90800933a1"
  
  user_email:
    description: User email for notifications and permissions
    default: "arun.wagle@databricks.com"
  
  historical_upload_root:
    description: Path for historical batch imports
    default: "test/historical_data/uploads"
```

##### Key Variables Explained

| Variable | Purpose | Used By |
|----------|---------|---------|
| `catalog` | Unity Catalog name | All jobs/pipelines accessing tables |
| `bronze_schema` | Bronze layer schema | Ingestion pipelines, raw data storage |
| `silver_schema` | Silver layer schema | Draft versions, intermediate processing |
| `gold_schema` | Gold layer schema | Approved DTAs, production-ready data |
| `warehouse_id` | SQL Warehouse ID | SQL tasks in jobs |
| `use_serverless` | Serverless toggle | Job compute selection |
| `historical_upload_root` | Upload path | File arrival trigger for batch imports |

**SQL Job Dependency**: Many jobs require a **config cache table** (`md_config_cache`) that stores these variables. This table is populated by the `job_populate_config_cache` job (see [Section 5](#5-dta-application-initialization)).

#### 3.1.5 `targets` Node

**Purpose**: Defines environment-specific configurations (dev, staging, prod).

```yaml
targets:
  dev:
    mode: development
    default: true
    workspace:
      host: https://dbc-984752964297111.cloud.databricks.com
    permissions:
      - user_name: ${var.user_email}
        level: CAN_MANAGE
  
  staging:
    mode: development
    workspace:
      host: https://dbc-984752964297111.cloud.databricks.com
    variables:
      catalog: "clinical_data_standards_stg_ctlg"
    permissions:
      - user_name: ${var.user_email}
        level: CAN_MANAGE
  
  prod:
    mode: production
    workspace:
      host: https://dbc-984752964297111.cloud.databricks.com
    variables:
      catalog: "clinical_data_standards_prod_ctlg"
      table_suffix: ""
    permissions:
      - user_name: ${var.user_email}
        level: CAN_MANAGE
    run_as:
      user_name: ${var.user_email}
```

##### Environment Comparison

| Environment | Mode | Catalog | Purpose | Schedules |
|-------------|------|---------|---------|-----------|
| **dev** | development | `aira` | Active development, feature testing | Paused |
| **staging** | development | `clinical_data_standards_stg_ctlg` | Pre-production validation | Enabled for testing |
| **prod** | production | `clinical_data_standards_prod_ctlg` | Production workloads | Active |

##### Development vs Production Mode

| Feature | Development Mode | Production Mode |
|---------|------------------|-----------------|
| **Resource Naming** | Prefixed with `[dev user]` | No prefix (shared) |
| **Job Deletion** | Jobs deleted on `bundle destroy` | Jobs retained (manual deletion required) |
| **Access Control** | Individual user permissions | Service principal recommended |
| **Schedules** | Paused by default | Active |

---

### 3.2 Application Configuration (`clinical_data_standards.yaml`)

The `config/clinical_data_standards.yaml` file defines all application-specific settings for data processing pipelines, document types, versioning, and export configurations.

#### Configuration File Structure

```yaml
clinical_data_standards.yaml
├── globals                     # Project-wide settings
├── services                    # Reusable service configurations
├── pipelines                   # Pipeline definitions
│   ├── file_processor          # Generic file extraction and cataloging
│   ├── tsdta_processor         # tsDTA Excel processing
│   ├── protocol_processor      # Protocol document processing
│   └── operational_agreement_processor  # OA document processing
├── streaming                   # Document processing configuration
├── versioning                  # SCD Type 2 configuration
└── export                      # Export configuration
```

#### 3.2.1 `globals` Section

**Purpose**: Project-wide settings shared across all pipelines.

```yaml
globals:
  spark_app_name: "clinical_data_standards"
  catalog: "aira_test"
  bronze_schema: "bronze_md"
  silver_schema: "silver_md"
  gold_schema: "gold_md"
  volume_name: "clinical_data_standards"
  
  # Jobs Configuration for UI
  jobs:
    max_runs_display: 5
    strip_env_prefix: true
    production_jobs:
      - name: "job_cdm_dta_import"
        display_name: "DTA Import"
        category: "import"
      # ... (10+ additional jobs defined)
```

**Key Settings**:
- **Catalog/Schema names**: Unity Catalog hierarchy (bronze/silver/gold)
- **Volume name**: Unity Catalog Volume for file storage
- **Jobs configuration**: Controls which jobs appear in the UI Jobs panel

**Upload Paths**:
- **UI uploads**: Configured in `app.yaml` → `UI_UPLOAD_ROOT` (default: `test/ui/uploads`)
  - Structure: `{ui_upload_root}/{YYYY-MM-DD}/{type}/`
- **Historical batch imports**: Configured in `databricks.yml` → `historical_upload_root` (default: `test/historical_data/uploads`)
  - File trigger watches this folder for automatic processing

#### 3.2.2 `services` Section

**Purpose**: Reusable service configurations shared across multiple pipelines.

```yaml
services:
  # Document Parser Service
  document_parser_default:
    type: "document_parsing"
    engine: "ai_document_intelligence"
    extract_text: true
    extract_tables: true
    timeout_seconds: 120
    description: "Databricks AI Document Intelligence"
  
  # LLM Entity Extractor
  gpt_entity_extractor:
    type: "llm"
    endpoint: "https://..."
    model: "gpt-4.1-mini-global"
    secret_scope: "dta_poc_api_key"
    secret_key: "gpt_api_key"
    timeout_seconds: 120
    description: "Generic GPT-based entity extractor"
```

**Available Services**:
- **`document_parser_default`**: Databricks AI Document Intelligence for parsing PDFs/Word docs
- **`gpt_entity_extractor`**: Generic GPT-based entity extraction (reusable across document types)
- **`entity_extractor_default`**: Foundation model endpoint for entity extraction

#### 3.2.3 `pipelines` Section

**Purpose**: Defines multiple data processing pipelines.

##### Pipeline 1: `file_processor`

**Purpose**: Generic file processor for archives (ZIP) and regular document uploads.

```yaml
pipelines:
  file_processor:
    description: "Generic file processor for archives and regular uploads"
    mode: "streaming"
    source_volume: "clinical_data_standards"
    
    sources:
      historical_data:
        description: "Historical clinical trial data"
        root: "test/historical_data"
    
    file_types:
      archives:
        extensions: [".zip", ".tar.gz", ".7z"]
        action: "extract"
      documents:
        extensions: [".pdf", ".docx", ".xlsx"]
        action: "catalog"
    
    manifest_table: "md_file_history"
    document_types_table: "md_document_types"
```

**Key Features**:
- Extracts ZIP archives containing clinical trial documents
- Catalogs extracted documents with metadata
- Outputs to `md_file_history` manifest table
- Joins with `md_document_types` reference table for processing enablement

**Document Categories**:
- **Protocol**: Protocol documents (PDFs)
- **OperationalAgreement**: Operational Agreement documents (Word/PDF)
- **DTA**: Data Transfer Agreement documents with subcategories:
  - **Dictionary**: DTA data dictionaries
  - **SOW**: Statement of Work (archived)
  - **tsDTA**: Timestamped DTA (Excel files)
  - **OPERATIONAL_AGREEMENT**: OA documents (Word/PDF)
- **TDD**: Technical Design Documents

##### Pipeline 2: `tsdta_processor`

**Purpose**: Process tsDTA Excel files and extract transfer variables, test concepts, codelists.

```yaml
pipelines:
  tsdta_processor:
    description: "Process tsDTA Excel files from trial metadata"
    mode: "streaming"
    
    xls:
      standard:
        source:
          source_table: "md_file_history"
          filter_tags: ["tsDTA"]
          filter_status: "READY_FOR_PROCESSING"
        
        output:
          excel_sheets_table: "md_dta_excel_file_raw"
```

**Validation Rules**:
- **`transfer_metadata`**: Required columns (transfer_variable_name, format, max_length, etc.)
- **`codelists`**: Header detection patterns, required columns (codelist_reference, code_value)
- **`test_concepts`**: Dynamic header detection using transfer variables from silver table

##### Pipeline 3: `protocol_processor`

**Purpose**: Parse Protocol PDFs and extract Schedule of Activities tables (sandbox mode).

```yaml
pipelines:
  protocol_processor:
    description: "Parse Protocol documents and extract tables"
    mode: "sandbox"
    
    ai_processing:
      parse_document:
        enabled: true
        engine: "ai_document_intelligence"
        extract_tables: true
      
      section_filter:
        enabled: true
        process_all_if_no_match: false
      
      target_sections:
        - pattern: "Schedule of Activities"
          alias: "soa"
          extract_tables: true
    
    output:
      sandbox_table: "md_sandbox_documents"
```

**Key Features**:
- AI-powered document parsing using Databricks Document Intelligence
- Section filtering to extract only relevant sections
- Sandbox mode for UI preview before production processing

##### Pipeline 4: `operational_agreement_processor`

**Purpose**: Parse Operational Agreement Word/PDF documents and extract structured data using LLM.

```yaml
pipelines:
  operational_agreement_processor:
    documents:
      operational_agreement:
        source:
          source_table: "md_file_history"
          filter_tags: ["OPERATIONAL_AGREEMENT"]
          filter_status: "READY_FOR_PROCESSING"
        
        output:
          raw_table_name: "md_oa_file_raw"
        
        llm:
          service: "gpt_entity_extractor"
          output_fields:
            - trial_id
            - data_stream_type
            - data_provider_name
```

**Key Features**:
- LLM-based entity extraction from unstructured documents
- Extracts trial ID, data stream type, and data provider name
- Uses GPT-4 for high-accuracy extraction

#### 3.2.4 `streaming` Section

**Purpose**: Enables streaming-based document processing with status tracking using Delta CDF.

```yaml
streaming:
  enabled: true
  
  change_data_feed:
    enabled: true
    cdf_tables:
      - "md_file_history"
  
  status_values:
    ready_for_processing: "READY_FOR_PROCESSING"
    tsdta_in_process: "TSDTA_PROCESSING"
    tsdta_completed: "TSDTA_COMPLETED"
    tsdta_failed: "TSDTA_FAILED"
    ready_for_versioning: "READY_FOR_VERSIONING"
    versioned: "VERSIONED"
  
  trigger:
    mode: "availableNow"
    max_files_per_trigger: 100
```

**Status Lifecycle**:
```
READY_FOR_PROCESSING 
  → TSDTA_PROCESSING 
  → TSDTA_COMPLETED 
  → READY_FOR_VERSIONING 
  → VERSIONING_IN_PROCESS 
  → VERSIONED
```

**Completion Tracking**:
- Tracks child document processing for parent ZIP files
- Triggers versioning only after all required documents are processed
- Required tags: `tsDTA`, `OPERATIONAL_AGREEMENT` (future)

#### 3.2.5 `versioning` Section

**Purpose**: Enables SCD Type 2 versioning for metadata library tables (3-level versioning).

```yaml
versioning:
  enabled: true
  
  # Version tag format: {library_major}-{dta_id}-{version_type}{version_number}
  # Examples:
  #   - "1.0"                 → Library major v1
  #   - "1.0-DTA_A-draft1"    → DTA-A draft 1
  #   - "1.0-DTA_A-v1.0"      → DTA-A major v1.0 (approved)
  
  registry_table: "md_version_registry"
  registry_schema: "gold_md"
  
  # Definition hash configuration
  definition_hash_common_fields:
    - data_provider_name
    - data_stream_type
  
  library_tables:
    - name: "md_dta_transfer_variables"
      library_type: "transfer_variables"
      silver_table: "md_dta_transfer_variables_draft"
      enable_comment_feature: true
      business_keys: ["definition_hash"]
    
    - name: "md_dta_vendor_test_concepts"
      library_type: "test_concepts"
      silver_table: "md_dta_vendor_test_concepts_draft"
      enable_comment_feature: true
    
    - name: "md_dta_operational_agreement"
      library_type: "operational_agreement"
      silver_table: "md_dta_operational_agreement_draft"
      enable_comment_feature: true
      # Related tables promoted alongside main table
      related_tables:
        - silver_table: "md_dta_oa_attributes_draft"
          gold_table: "md_dta_oa_attributes"
        - silver_table: "md_dta_oa_options_draft"
          gold_table: "md_dta_oa_options"
        - silver_table: "md_dta_oa_other_draft"
          gold_table: "md_dta_oa_other"
    
    # Additional library tables: codelists, vendor_visit, data_ingestion_parameters
```

**Versioning Levels**:
1. **Library Major** (e.g., `1.0`, `2.0`): Production canonical data
2. **DTA Major** (e.g., `1.0-DTA_A-v1.0`): Approved DTA version
3. **DTA Draft** (e.g., `1.0-DTA_A-draft1`): Work in progress

**Library Tables with Versioning**:
- `md_dta_transfer_variables`: Transfer variable definitions
- `md_dta_vendor_test_concepts`: Test concept definitions with transfer variable mappings
- `md_dta_operational_agreement`: Operational agreements (with 3 related tables)
- `md_vendor_visit`: Vendor-specific visit implementations
- `md_dta_codelists`: Codelist definitions with value-to-SDTM mappings
- `md_dta_data_ingestion_parameters`: Data ingestion parameters

#### 3.2.6 `export` Section

**Purpose**: Defines how DTA metadata is exported to files (Excel, PDF, ZIP).

```yaml
export:
  enabled: true
  
  export_folder: "exports"
  date_format: "%Y-%m-%d"
  timestamp_format: "%Y%m%d_%H%M%S"
  
  document_types:
    - type: "tsDTA"
      label: "Trial Specific DTA (Excel)"
      format: "excel"
      file_extension: ".xlsx"
      is_enabled: true
      includes:
        - dta_summary
        - version_history
        - transfer_variables
        - test_concepts
      sheets_by_domain: true
    
    - type: "oa"
      label: "Operational Agreement (PDF)"
      format: "pdf"
      is_enabled: false  # Not implemented yet
    
    - type: "dta_full"
      label: "Complete DTA Package (ZIP)"
      format: "zip"
      is_enabled: false  # Enable when all document types ready
```

**Export Path Structure**:
```
/Volumes/{catalog}/bronze_md/{source_root}/exports/{date}/{dta_number}/
```

**Export Manifest**:
- Created in export folder to track what was exported
- JSON format with metadata about export operation

---

### Configuration File Relationship

The two configuration files work together:

| Configuration | Purpose | Managed By | When Changed |
|---------------|---------|------------|-------------|
| **`databricks.yml`** | Infrastructure, deployment, compute | DevOps/Platform team | Deployment changes, new environments |
| **`clinical_data_standards.yaml`** | Application logic, data pipelines | Data engineering team | New document types, pipeline updates |

**Dependency Flow**:
1. `databricks.yml` variables (catalog, schemas) → `clinical_data_standards.yaml` globals
2. `clinical_data_standards.yaml` → `md_config_cache` table (via `job_populate_config_cache`)
3. Jobs/notebooks read config from `md_config_cache` for fast access (~5 sec vs ~60 sec from YAML)

**Configuration Cache**:
The `job_populate_config_cache` job (see [Section 5.3](#53-job-job_populate_config_cache)) reads `clinical_data_standards.yaml` and stores it in the `md_config_cache` Delta table for fast runtime access by all jobs and notebooks.

---

## 4. Environment Setup

### 4.1 Prerequisites

Before deploying, ensure you have:

- ✅ **Databricks CLI v0.250.0 or above**
  ```bash
  curl -fsSL https://raw.githubusercontent.com/databricks/setup-cli/main/install.sh | sudo sh
  databricks --version
  ```

- ✅ **Access to Databricks Workspace**
  - Workspace admin or appropriate permissions
  - `CAN_MANAGE` permission on workspace resources

- ✅ **Unity Catalog Permissions**
  - `CREATE CATALOG` (for initial setup)
  - `USE CATALOG`, `CREATE SCHEMA`, `USE SCHEMA` (for ongoing operations)

- ✅ **Python 3.8+** (for local development and wheel building)

- ✅ **Git Access** (to clone the repository)

### 4.2 Developer Setup

#### Step 1: Authenticate with Databricks

```bash
# OAuth authentication (recommended)
databricks auth login --host <YOUR_DATABRICKS_WORKSPACE_URL>

# Or use personal access token
databricks configure --token
```

#### Step 2: Clone Repository

```bash
git clone <repository-url>
cd clinical-data-standards
```

#### Step 3: Validate Bundle

```bash
# Validate configuration
databricks bundle validate --target dev
```

#### Step 4: Deploy to Dev

```bash
# Deploy all resources
databricks bundle deploy --target dev

# Verify deployment
databricks bundle summary --target dev
```

#### Step 5: Deploy Flask App (Using Helper Script)

The `_deploy_app.sh` helper script ensures the Flask app is deployed with the correct source code path, working around a DAB bug where `source_code_path` isn't always respected.

```bash
# Deploy the Flask app
bash _deploy_app.sh clnl-data-std-mgmt-app

# Optional: specify target (defaults to dev)
bash _deploy_app.sh clnl-data-std-mgmt-app dev
```

**What the script does**:
1. Validates the app exists (requires prior `bundle deploy`)
2. Starts the app compute if not already active
3. Deploys with the correct source code path: `/Workspace/Users/{user}/.bundle/{bundle}/{target}/files/apps/{app_name}`
4. Retries deployment if needed

**Verify app deployment**:
```bash
# Check app status
databricks apps get clnl-data-std-mgmt-app

# Get app URL
databricks apps get clnl-data-std-mgmt-app --output json | jq -r '.url'

# View app logs
databricks apps logs clnl-data-std-mgmt-app
```

#### Step 6: Run Initialization Jobs

See [Section 5: DTA Application Initialization](#5-dta-application-initialization) for required setup jobs.

#### Destroy Application

To remove all deployed resources (jobs, apps, wheels) from the workspace:

```bash
# Destroy all resources for dev target
databricks bundle destroy --target dev

# With auto-approval (for CI/CD)
databricks bundle destroy --target dev --auto-approve
```

**⚠️ Behavior by Environment**: 
- In **development mode**, `bundle destroy` will **automatically delete all jobs and apps**.
- In **production mode**, `bundle destroy` can still be used, but resources are **retained by default** and require explicit deletion.
- Always verify the target before destroying: `databricks bundle summary --target <target>`

**Destroying Individual Resources (All Environments)**:

Instead of destroying the entire bundle, you can delete individual resources:

```bash
# Delete a specific job
databricks jobs delete <job-id>

# Delete a specific app
databricks apps delete <app-name>

# List all bundle-managed jobs to find job IDs
databricks bundle summary --target dev
```

**What gets deleted by `bundle destroy`**:
- All jobs defined in the bundle (dev mode only, unless manually deleted in prod)
- All Databricks Apps (dev mode only, unless manually deleted in prod)
- Uploaded wheel files
- Bundle metadata

**What is NOT deleted**:
- Delta tables and data (catalogs, schemas, tables)
- Unity Catalog volumes
- Secrets
- Service principals

### 4.3 Staging and Production Setup

> **TODO**: Document staging and production deployment procedures
> 
> Planned topics:
> - Service principal setup for prod `run_as`
> - CI/CD pipeline integration (Jenkins)
> - Blue-green deployment strategy
> - Rollback procedures
> - Production monitoring and alerting

**Placeholder Commands**:

```bash
# Staging deployment
databricks bundle deploy --target staging

# Production deployment (requires approval)
databricks bundle deploy --target prod
```

---

## 5. DTA Application Initialization

After deploying the bundle, run these initialization jobs **in order** to prepare the environment.

### Initialization Sequence

```
1. job_test_cdm_cleanup (optional - test only)
      ↓
2. job_cdm_sql_setup
      ↓
3. job_populate_config_cache
      ↓
4. job_cdm_sql_load_reference_data (optional)
      ↓
5. job_cdm_app_permissions
      ↓
6. Deploy Flask App (clnl-data-std-mgmt-app)
```

### 5.1 Job: `job_test_cdm_cleanup`

**Purpose**: Cleans up all tables and checkpoints for fresh testing.

**⚠️ WARNING**: Deletes all data! Only run in dev/test environments.

**What it does**:
1. Drops all bronze tables (`md_file_history`, etc.)
2. Drops all silver tables (`md_dta_transfer_variables_draft`, etc.)
3. Drops all gold tables (`dta`, `md_dta_transfer_variables`, etc.)
4. Deletes checkpoint folder from Volumes
5. Deletes ingested folder from `historical_data/`

**When to run**:
- Before running integration tests
- To reset development environment
- **NEVER in staging or production**

**Command**:
```bash
databricks bundle run job_test_cdm_cleanup --target dev
```

---

### 5.2 Job: `job_cdm_sql_setup`

**Purpose**: Creates Unity Catalog, schemas, volumes, and base tables.

**What it does**:
- Creates catalog (e.g., `aira`, `clinical_data_standards_stg_ctlg`)
- Creates schemas: `bronze_md`, `silver_md`, `gold_md`
- Creates volumes for file storage
- Creates base metadata tables

**Parameters**:
- `catalog_override`: Override default catalog (optional)

**When to run**:
- **First deployment** to any environment
- After running cleanup job
- When adding new schemas/volumes

**Command**:
```bash
# Use default catalog from databricks.yml
databricks bundle run job_cdm_sql_setup --target dev

# Override catalog
databricks bundle run job_cdm_sql_setup --target dev \
  --params '{"catalog_override": "my_custom_catalog"}'
```

---

### 5.3 Job: `job_populate_config_cache`

**Purpose**: Populates the `md_config_cache` Delta table from `clinical_data_standards.yaml`.

**Why it's needed**:
- Many jobs read configuration from `clinical_data_standards.yaml`
- Loading YAML from workspace files is slow (~60 seconds)
- Caching in Delta reduces load time to ~5 seconds

**What it does**:
- Reads `config/clinical_data_standards.yaml`
- Parses YAML configuration
- Writes to `md_config_cache` Delta table
- Stores version and timestamp

**When to run**:
- **After initial deployment**
- After modifying `clinical_data_standards.yaml`
- As part of CI/CD pipeline after config changes

**Command**:
```bash
databricks bundle run job_populate_config_cache --target dev
```

**Verify**:
```sql
SELECT * FROM aira.bronze_md.md_config_cache
ORDER BY updated_at DESC
LIMIT 10;
```

---

### 5.4 Job: `job_cdm_sql_load_reference_data`

**Purpose**: Loads reference data (vendors, data streams, etc.).

**What it does**:
- Loads vendor master data
- Loads data stream definitions
- Loads study metadata
- (Currently a placeholder - expand as needed)

**When to run**:
- After `job_cdm_sql_setup`
- When reference data is updated
- Optional for development environments

**Command**:
```bash
databricks bundle run job_cdm_sql_load_reference_data --target dev
```

---

### 5.5 Job: `job_cdm_app_permissions`

**Purpose**: Creates and seeds permission tables for the Flask management app.

**What it does**:
1. Creates permission tables:
   - `md_users`: Application users
   - `md_user_groups`: User groups (JNJ_DAE, VENDOR, JNJ_LIBRARIAN)
   - `md_permissions`: Permission definitions
   - `md_user_group_memberships`: User to group mappings
   - `md_group_permissions`: Group to permission mappings
2. Seeds default users and groups
3. Assigns default permissions

**When to run**:
- **After `job_cdm_sql_setup`** (to ensure schemas exist)
- **After CDM import job** (to ensure vendors exist)
- **Before deploying Flask app** (to enable user simulation)

**Command**:
```bash
databricks bundle run job_cdm_app_permissions --target dev
```

**Verify**:
```sql
-- Check users
SELECT * FROM aira.gold_md.md_users;

-- Check groups
SELECT * FROM aira.gold_md.md_user_groups;

-- Check memberships
SELECT * FROM aira.gold_md.md_user_group_memberships;
```

---

### 5.6 Deploy Flask App

**Purpose**: Deploy the web-based DTA management application.

**Prerequisites**:
- All initialization jobs completed
- Permission tables populated
- At least one vendor and study created (via DTA import job)

**What the app provides**:
- DTA template creation and configuration
- Document upload and ingestion
- Approval workflows
- Genie conversational UI
- User simulation (for testing different personas)

**Command**:
```bash
# App is automatically deployed with bundle
databricks bundle deploy --target dev

# Verify app is running
databricks apps list --target dev
```

**Access the app**:
1. Navigate to Databricks workspace
2. Go to **Apps** section
3. Find `clnl-data-std-mgmt-app`
4. Click to open the application

---

### Quick Initialization Script

For convenience, here's a script to run all initialization jobs in sequence:

```bash
#!/bin/bash
# File: init_dta_dev.sh
# Purpose: Initialize DTA application in development environment

set -e  # Exit on error

TARGET=${1:-dev}
echo "Initializing DTA application for target: $TARGET"

# Step 1: Cleanup (dev/test only)
if [ "$TARGET" == "dev" ] || [ "$TARGET" == "test" ]; then
  echo "Step 1: Cleaning up existing data..."
  databricks bundle run job_test_cdm_cleanup --target $TARGET
  sleep 5
fi

# Step 2: SQL Setup
echo "Step 2: Creating catalog, schemas, and volumes..."
databricks bundle run job_cdm_sql_setup --target $TARGET
sleep 5

# Step 3: Populate Config Cache
echo "Step 3: Populating config cache..."
databricks bundle run job_populate_config_cache --target $TARGET
sleep 5

# Step 4: Load Reference Data (optional)
echo "Step 4: Loading reference data..."
databricks bundle run job_cdm_sql_load_reference_data --target $TARGET || true
sleep 5

# Step 5: App Permissions
echo "Step 5: Setting up app permissions..."
databricks bundle run job_cdm_app_permissions --target $TARGET
sleep 5

echo "✅ Initialization complete!"
echo "Next steps:"
echo "  1. Run a DTA import job to create initial data"
echo "  2. Access the Flask app in Databricks workspace"
```

**Usage**:
```bash
chmod +x init_dta_dev.sh
./init_dta_dev.sh dev
```

---

## 6. Troubleshooting

### Common Issues

**1. Authentication Errors**
```bash
# Re-authenticate
databricks auth login --host <YOUR_DATABRICKS_WORKSPACE_URL>
```

**2. Permission Denied**
```
Error: User does not have CAN_MANAGE permission
```
**Solution**: Request workspace admin to grant permissions

**3. Resource Conflicts**
```
Error: Resource already exists
```
**Solution**: Use `--force-lock` flag (dev only) or coordinate with team

**4. Validation Failures**
```bash
# Debug validation
databricks bundle validate --debug --target dev
```

**5. Config Cache Not Found**
```
Error: Table md_config_cache not found
```
**Solution**: Run `job_populate_config_cache`

**6. Permission Tables Missing**
```
Error: Table md_users not found
```
**Solution**: Run `job_cdm_app_permissions`

**7. Need to Start Fresh**
```
Error: Inconsistent state or corrupted deployment
```
**Solution**: Destroy and redeploy (behavior depends on environment mode)

**For Development Mode**:
```bash
# Destroy all resources (auto-deletes jobs and apps)
databricks bundle destroy --target dev --auto-approve

# Redeploy from scratch
databricks bundle deploy --target dev

# Deploy Flask app
bash _deploy_app.sh clnl-data-std-mgmt-app

# Re-run initialization jobs (see Section 5)
```

**For Production Mode**:
```bash
# Destroy bundle (resources retained by default)
databricks bundle destroy --target prod --auto-approve

# Manually delete specific resources if needed
databricks jobs delete <job-id>
databricks apps delete <app-name>

# Redeploy
databricks bundle deploy --target prod

# Deploy Flask app
bash _deploy_app.sh clnl-data-std-mgmt-app prod

# Re-run initialization jobs (see Section 5)
```

**⚠️ Note**: This only removes DAB-managed resources (jobs, apps, wheels). Delta tables and data remain intact.

### Rollback

```bash
# List deployments
databricks bundle deployments list --target prod

# Rollback to previous version
databricks bundle deploy --target prod --deployment-id <previous-id>
```

---

## 7. Best Practices

1. **Test in Dev First**: Always test changes in dev before staging/prod
2. **Use Version Control**: Commit all changes before deploying
3. **Document Changes**: Update CHANGELOG.md
4. **Monitor Deployments**: Watch for errors during/after deployment
5. **Backup Configurations**: Keep backups of critical configs
6. **Coordinate with Team**: Communicate before prod deployments
7. **Run Initialization Jobs**: Always run setup jobs after first deployment
8. **Validate Config Cache**: Verify `md_config_cache` after config changes


---

## 9. Related Documentation

- [00. DTA Design Overview](./00_dta_design_overview.readme.md)
- [11. CDH Ingestion Pipeline Design](./11_cdh_ingestion_pipeline_design.readme.md)
- [Databricks Asset Bundles Documentation](https://docs.databricks.com/dev-tools/bundles/index.html)

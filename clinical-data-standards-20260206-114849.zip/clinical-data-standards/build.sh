#!/bin/bash
# build.sh - Local build script for {{.usecase}}_framework wheel
# 
# Usage:
#   ./build.sh          # Build wheel
#   ./build.sh clean    # Clean build artifacts
#   ./build.sh test     # Build and install locally for testing

set -e

PROJECT_NAME="{{.usecase}}_framework"
DIST_DIR="dist"
BUILD_DIR="build"
EGG_INFO="src/${PROJECT_NAME}.egg-info"

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Functions
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

clean_build() {
    print_info "Cleaning build artifacts..."
    
    rm -rf "$DIST_DIR"
    rm -rf "$BUILD_DIR"
    rm -rf "$EGG_INFO"
    rm -rf src/*.egg-info
    
    find . -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null || true
    find . -type f -name "*.pyc" -delete 2>/dev/null || true
    
    print_success "Build artifacts cleaned"
}

build_wheel() {
    print_info "Building wheel for ${PROJECT_NAME}..."
    
    # Check if setup.py exists
    if [ ! -f "setup.py" ]; then
        print_error "setup.py not found!"
        exit 1
    fi
    
    # Install build tools if needed
    python -c "import setuptools" 2>/dev/null || {
        print_info "Installing setuptools..."
        pip install setuptools wheel
    }
    
    # Build the wheel
    python setup.py bdist_wheel
    
    if [ $? -eq 0 ]; then
        print_success "Wheel built successfully!"
        echo ""
        print_info "Wheel location:"
        ls -lh ${DIST_DIR}/*.whl
        echo ""
        print_info "To install locally:"
        echo "  pip install ${DIST_DIR}/${PROJECT_NAME}-*.whl"
    else
        print_error "Build failed!"
        exit 1
    fi
}

test_install() {
    print_info "Testing wheel installation..."
    
    # Build if wheel doesn't exist
    if [ ! -d "$DIST_DIR" ] || [ -z "$(ls -A ${DIST_DIR}/*.whl 2>/dev/null)" ]; then
        print_warning "No wheel found, building first..."
        build_wheel
    fi
    
    # Get the wheel file
    WHEEL_FILE=$(ls ${DIST_DIR}/*.whl | head -n 1)
    
    if [ -z "$WHEEL_FILE" ]; then
        print_error "No wheel file found in ${DIST_DIR}/"
        exit 1
    fi
    
    print_info "Installing wheel: $(basename $WHEEL_FILE)"
    
    # Uninstall existing version
    pip uninstall ${PROJECT_NAME} -y 2>/dev/null || true
    
    # Install the wheel
    pip install "$WHEEL_FILE"
    
    if [ $? -eq 0 ]; then
        print_success "Wheel installed successfully!"
        echo ""
        
        # Test import
        print_info "Testing import..."
        python -c "from ${PROJECT_NAME}.config_manager import ConfigManager; print('✅ ConfigManager import successful!')" || {
            print_error "Import test failed!"
            exit 1
        }
        
        # Show installed version
        python -c "import pkg_resources; print(f'Installed version: {pkg_resources.get_distribution(\"${PROJECT_NAME}\").version}')"
        
        echo ""
        print_success "All tests passed!"
        echo ""
        print_warning "To uninstall:"
        echo "  pip uninstall ${PROJECT_NAME} -y"
    else
        print_error "Installation failed!"
        exit 1
    fi
}

show_help() {
    echo "Usage: ./build.sh [command]"
    echo ""
    echo "Commands:"
    echo "  (none)    Build the wheel"
    echo "  clean     Clean build artifacts"
    echo "  test      Build and test install locally"
    echo "  help      Show this help message"
    echo ""
    echo "Examples:"
    echo "  ./build.sh           # Build wheel"
    echo "  ./build.sh clean     # Clean up"
    echo "  ./build.sh test      # Build and test"
}

# Main script
case "${1:-build}" in
    build)
        build_wheel
        ;;
    clean)
        clean_build
        ;;
    test)
        test_install
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        print_error "Unknown command: $1"
        echo ""
        show_help
        exit 1
        ;;
esac


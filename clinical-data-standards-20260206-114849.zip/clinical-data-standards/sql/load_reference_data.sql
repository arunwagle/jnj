-- ============================================================================
-- Reference Data Load SQL
-- ============================================================================
-- Purpose: Load reference/lookup data into bronze schema
-- Use Case: clinical_data_standards
--
-- Parameters (passed from job):
--   :catalog_name - The catalog to use
--
-- Tables populated:
--   - md_document_types: Document type reference with processing enablement
-- ============================================================================

USE CATALOG IDENTIFIER(:catalog_name);
USE SCHEMA bronze_md;

-- ============================================================================
-- md_document_types: Reference table for document type enablement
-- ============================================================================
-- This table controls which document types are processed in md_file_history.
-- Documents join with this table based on document_tags to determine if they
-- should be processed.
-- ============================================================================

CREATE TABLE IF NOT EXISTS md_document_types (
    document_type STRING NOT NULL COMMENT 'Primary key - document type identifier (tsDTA, Protocol, etc.)',
    document_type_label STRING COMMENT 'Display name for UI',
    is_enabled BOOLEAN NOT NULL COMMENT 'Whether this document type should be processed',
    description STRING COMMENT 'Documentation about this document type',
    -- Audit columns (no DEFAULT to avoid Delta feature requirement)
    created_ts TIMESTAMP COMMENT 'When record was created',
    created_by_principal STRING COMMENT 'Who created the record',
    last_updated_ts TIMESTAMP COMMENT 'When record was last updated',
    last_updated_by_principal STRING COMMENT 'Who last updated the record'
)
USING DELTA
COMMENT 'Reference table that controls which document types are enabled for processing. Documents in md_file_history join with this table based on document_tags to determine processing eligibility.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true'
);

-- Seed document types using MERGE (upsert pattern)
-- Only tsDTA is enabled by default - other types can be enabled incrementally
MERGE INTO md_document_types AS target
USING (
    SELECT 'tsDTA' AS document_type, 'Transfer Specification DTA' AS document_type_label, 
           true AS is_enabled, 'Transfer Specification Data Transfer Agreement - Excel files containing transfer variable definitions' AS description
    UNION ALL
    SELECT 'Protocol', 'Protocol Document', false, 'Clinical trial protocol documents'
    UNION ALL
    SELECT 'Operational_Agreement', 'Operational Agreement', false, 'Operational agreements between parties'
    UNION ALL
    SELECT 'Dictionary', 'Data Dictionary', false, 'Data dictionary documents'
    UNION ALL
    SELECT 'SOW', 'Statement of Work', false, 'Statement of Work documents'
) AS source
ON target.document_type = source.document_type
WHEN MATCHED THEN
    UPDATE SET
        document_type_label = source.document_type_label,
        description = source.description,
        last_updated_ts = CURRENT_TIMESTAMP(),
        last_updated_by_principal = 'sql_load'
    -- Note: is_enabled is NOT updated to preserve user changes
WHEN NOT MATCHED THEN
    INSERT (document_type, document_type_label, is_enabled, description, created_ts, created_by_principal)
    VALUES (source.document_type, source.document_type_label, source.is_enabled, source.description, CURRENT_TIMESTAMP(), 'sql_load');

-- ============================================================================
-- Output Results
-- ============================================================================
-- Note: Vendor, data stream, and study data is populated by the CDM import job
-- Note: Permission data is populated by job_cdm_app_permissions

SELECT '✅ Reference Data SQL executed' as status, :catalog_name as catalog;
SELECT * FROM md_document_types;

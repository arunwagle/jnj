# =============================================================================
# Genie Wrapper - Clean API for Databricks Genie Integration
# =============================================================================
# This module provides a wrapper around databricks_ai_bridge.genie for
# interacting with Databricks Genie Spaces.
#
# Usage:
#   from genie import GenieWrapper, GenieResponse
#   
#   genie = GenieWrapper(space_id)
#   response = genie.ask_first_question("Show me Labs DTAs")
#   result = genie.poll_result(response)  # Returns GenieResponse
#   
#   # GenieResponse has: .description, .query, .result
#
# Reference: https://github.com/databricks-industry-solutions/aichemy
# =============================================================================

import os
import requests
from databricks.sdk import WorkspaceClient

# Import from databricks-ai-bridge package
from databricks_ai_bridge.genie import Genie, GenieResponse


def get_databricks_client() -> WorkspaceClient:
    """Get configured Databricks WorkspaceClient."""
    return WorkspaceClient()


class GenieWrapper(Genie):
    """
    Wrapper around Databricks Genie API providing convenience methods.
    
    Extends databricks_ai_bridge.genie.Genie with:
    - ask_first_question: Start a new conversation
    - ask_followup_question: Continue an existing conversation
    - poll_result: Wait for and return GenieResponse
    - get_conversation_id: Extract conversation_id from response
    
    GenieResponse attributes:
    - description: Text explanation from Genie
    - query: Generated SQL query (if applicable)
    - result: Query results as markdown table
    """
    
    def __init__(self, space_id: str):
        """
        Initialize GenieWrapper with a Genie Space ID.
        
        Args:
            space_id: The Genie Space ID to interact with
        """
        self.client = get_databricks_client()
        super().__init__(space_id)
    
    def ask_first_question(self, question: str) -> dict:
        """
        Start a new conversation with an initial question.
        
        Args:
            question: Natural language question to ask Genie
        
        Returns:
            Dict with conversation_id and message_id
        
        Raises:
            Various exceptions for connection, timeout, or API errors
        """
        try:
            resp = self.start_conversation(question)
            return resp
        except requests.exceptions.ConnectionError as e:
            raise requests.exceptions.ConnectionError(
                f"Connection error - check your network and workspace URL: {e}"
            )
        except requests.exceptions.Timeout as e:
            raise requests.exceptions.Timeout(f"Request timed out: {e}")
        except requests.exceptions.RequestException as e:
            raise requests.exceptions.RequestException(f"Request failed: {e}")
        except ValueError as e:
            raise ValueError(f"Invalid JSON response: {e}")
        except Exception as e:
            raise Exception(f"Error in ask_first_question: {e}")
    
    def get_conversation_id(self, resp: dict) -> str:
        """
        Extract conversation_id from a response.
        
        Args:
            resp: Response dict from ask_first_question or ask_followup_question
        
        Returns:
            The conversation_id string
        """
        try:
            return resp.get("conversation_id")
        except Exception as e:
            raise Exception(f"Invalid response format: {e} {resp}")
    
    def poll_result(self, resp: dict) -> GenieResponse:
        """
        Poll for and return the Genie result.
        
        Args:
            resp: Response dict containing conversation_id and message_id
        
        Returns:
            GenieResponse with .description, .query, and .result attributes
        """
        try:
            return self.poll_for_result(resp["conversation_id"], resp["message_id"])
        except KeyError as e:
            raise Exception(f"Missing required field in response: {e}")
        except Exception as e:
            raise Exception(f"Error polling for result: {e}")
    
    def ask_followup_question(self, question: str, conversation_id: str) -> dict:
        """
        Send a follow-up question in an existing conversation.
        
        Args:
            question: Follow-up question to ask
            conversation_id: ID of the existing conversation
        
        Returns:
            Dict with conversation_id and message_id
        """
        try:
            resp = self.create_message(conversation_id, question)
            return resp
        except requests.exceptions.ConnectionError as e:
            raise requests.exceptions.ConnectionError(
                f"Connection error - check your network and workspace URL: {e}"
            )
        except requests.exceptions.Timeout as e:
            raise requests.exceptions.Timeout(f"Request timed out: {e}")
        except requests.exceptions.RequestException as e:
            raise requests.exceptions.RequestException(f"Request failed: {e}")
        except ValueError as e:
            raise ValueError(f"Invalid JSON response: {e}")
        except Exception as e:
            raise Exception(f"Error creating follow-up message: {e}")


# Re-export GenieResponse for convenience
__all__ = ['GenieWrapper', 'GenieResponse', 'get_databricks_client']


# Clean Architecture Field Mapping

This document maps the OLD transformed field names to the NEW raw database field names.

## Transfer Variables (TV)

| Old Frontend Field | New Database Field | Type | Notes |
|-------------------|-------------------|------|-------|
| `_transfer_variable_id` | `transfer_variable_id` | string | Primary key |
| `LABEL` | `transfer_variable_name` | string | Variable name |
| `FILE_ORDER` | `transfer_variable_order` | int | Sort order |
| `FORMAT` | `format` | string | Data type |
| `LENGTH` | `anticipated_max_length` | int | Max length |
| `REQUIRED` | `populate_for_all_records` | boolean | Required field |
| `TEST_CONCEPTS` | `codelist_values` | array/string | Codelist references |
| `EXAMPLE_VALUES` | `example_values` | string | Example data |
| `DESCRIPTION` | `variable_description` | string | Description |
| `IS_KEY` | `transfer_file_key` | boolean | Is key field |
| `ROW_STATUS` | `status` | string | Status |
| `VENDOR_COMMENT` | `vendor_comment` | string | Comments |
| `DOMAIN_INFO` | `domain_info` | string | Domain information |

## Test Concepts (TC)

| Old Frontend Field | New Database Field | Type | Notes |
|-------------------|-------------------|------|-------|
| `_test_concept_id` | `test_concept_id` | string | Primary key |
| `_domain_info` | `domain_info` | string | Domain info |
| `_notes` | `notes` | string | Notes |
| `_status` | `status` | string | Status |
| `_vendor_comment` | `vendor_comment` | string | Comments |
| SDTM columns (LBDESCR, etc.) | Same column names | various | Keep as-is from DB |

## Codelists (CL)

| Old Frontend Field | New Database Field | Type | Notes |
|-------------------|-------------------|------|-------|
| (missing) | `codelist_id` | string | **NEW** - Primary key |
| `code` | `code` | string | Code value |
| `ref` | `ref` | string | Reference/variable name |
| `text` | `text` | string | Display text |

## Vendor Visits (VISITS)

| Old Frontend Field | New Database Field | Type | Notes |
|-------------------|-------------------|------|-------|
| `_vendor_visit_id` | `vendor_visit_id` | string | ✅ Already cleaned |
| `visit_name` | `visit_name` | string | ✅ Already cleaned |
| `visit_number` | `visit_number` | string | ✅ Already cleaned |
| `timepoint` | `timepoint` | string | ✅ Already cleaned |
| `timepoint_number` | `timepoint_number` | int | ✅ Already cleaned |
| `status` | `status` | string | ✅ Already cleaned |

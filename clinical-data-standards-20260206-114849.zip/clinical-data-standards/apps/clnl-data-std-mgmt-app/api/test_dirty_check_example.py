"""
Example usage of dirty check API - demonstrates accuracy and performance
"""

from dta_clone_optimized import (
    check_entity_dirty,
    check_all_entities_dirty,
    get_dirty_summary
)

# =============================================================================
# Example 1: Transfer Variables - No Changes
# =============================================================================

print("\n" + "="*70)
print("Example 1: Transfer Variables - No Changes")
print("="*70)

original_tv = [
    {
        'transfer_variable_id': 'tv_001',
        'transfer_variable_name': 'SUBJID',
        'transfer_variable_label': 'Subject ID',
        'domain_info': 'Demographics',
        '_id': 'ui_123',  # UI-only field
        '_domain_info': 'Demographics'  # UI-only field
    },
    {
        'transfer_variable_id': 'tv_002',
        'transfer_variable_name': 'AGE',
        'transfer_variable_label': 'Age',
        'domain_info': 'Demographics',
        '_id': 'ui_124'
    }
]

# Same data, different UI fields (should be CLEAN)
current_tv = [
    {
        'transfer_variable_id': 'tv_001',
        'transfer_variable_name': 'SUBJID',
        'transfer_variable_label': 'Subject ID',
        'domain_info': 'Demographics',
        '_id': 'ui_999',  # Different UI ID
        '_domain_info': 'Demographics'
    },
    {
        'transfer_variable_id': 'tv_002',
        'transfer_variable_name': 'AGE',
        'transfer_variable_label': 'Age',
        'domain_info': 'Demographics',
        '_id': 'ui_1000'  # Different UI ID
    }
]

is_dirty, details = check_entity_dirty(
    original_tv,
    current_tv,
    id_field='transfer_variable_id',
    entity_name='Transfer Variables',
    exclude_fields=['_id', '_domain_info']
)

print(f"Result: {'DIRTY' if is_dirty else 'CLEAN'}")
print(f"Added: {details['added_count']}, Modified: {details['modified_count']}, Removed: {details['removed_count']}")
print(f"Time: {details['computation_time_ms']:.2f}ms")


# =============================================================================
# Example 2: Transfer Variables - With Changes
# =============================================================================

print("\n" + "="*70)
print("Example 2: Transfer Variables - With Changes")
print("="*70)

# User modified the label
current_tv_modified = [
    {
        'transfer_variable_id': 'tv_001',
        'transfer_variable_name': 'SUBJID',
        'transfer_variable_label': 'Subject Identifier',  # Changed!
        'domain_info': 'Demographics',
        '_id': 'ui_123'
    },
    {
        'transfer_variable_id': 'tv_002',
        'transfer_variable_name': 'AGE',
        'transfer_variable_label': 'Age',
        'domain_info': 'Demographics',
        '_id': 'ui_124'
    },
    {
        'transfer_variable_id': 'tv_003',  # New row!
        'transfer_variable_name': 'SEX',
        'transfer_variable_label': 'Sex',
        'domain_info': 'Demographics',
        '_id': 'ui_125'
    }
]

is_dirty, details = check_entity_dirty(
    original_tv,
    current_tv_modified,
    id_field='transfer_variable_id',
    entity_name='Transfer Variables',
    exclude_fields=['_id', '_domain_info']
)

print(f"Result: {'DIRTY' if is_dirty else 'CLEAN'}")
print(f"Added: {details['added_count']}, Modified: {details['modified_count']}, Removed: {details['removed_count']}")
print(f"Added IDs: {details['added_ids']}")
print(f"Modified IDs: {details['modified_ids']}")
print(f"Time: {details['computation_time_ms']:.2f}ms")


# =============================================================================
# Example 3: Codelists - False Positive Eliminated
# =============================================================================

print("\n" + "="*70)
print("Example 3: Codelists - False Positive Eliminated")
print("="*70)

original_cl = [
    {
        'codelist_id': 'cl_001',
        'codelist_name': 'SEX',
        'codelist_values': ['M', 'F'],  # List
        '_id': 'ui_200'
    }
]

# Same data, but list order might differ in UI
current_cl = [
    {
        'codelist_id': 'cl_001',
        'codelist_name': 'SEX',
        'codelist_values': ['F', 'M'],  # Different order - but normalized!
        '_id': 'ui_999'
    }
]

is_dirty, details = check_entity_dirty(
    original_cl,
    current_cl,
    id_field='codelist_id',
    entity_name='Codelists',
    exclude_fields=['_id']
)

print(f"Result: {'DIRTY' if is_dirty else 'CLEAN'} (should be CLEAN due to list normalization)")
print(f"Time: {details['computation_time_ms']:.2f}ms")


# =============================================================================
# Example 4: Check All Entities (Parallel)
# =============================================================================

print("\n" + "="*70)
print("Example 4: Check All Entities in Parallel")
print("="*70)

original_workspace = {
    'transfer_variables': original_tv,
    'test_concepts': [
        {
            'test_concept_id': 'tc_001',
            'test_concept_reference': 'LBTEST',
            'domain_info': 'Labs',
            '_id': 'ui_300'
        }
    ],
    'vendor_visits': [
        {
            'vendor_visit_id': 'vv_001',
            'visit_name': 'Screening',
            '_id': 'ui_400'
        }
    ],
    'codelists': original_cl
}

current_workspace = {
    'transfer_variables': current_tv_modified,  # Has changes
    'test_concepts': [
        {
            'test_concept_id': 'tc_001',
            'test_concept_reference': 'LBTEST',
            'domain_info': 'Labs',
            '_id': 'ui_999'  # Different UI ID, but data same
        }
    ],
    'vendor_visits': [
        {
            'vendor_visit_id': 'vv_001',
            'visit_name': 'Screening',
            '_id': 'ui_1000'
        }
    ],
    'codelists': current_cl  # No changes
}

results = check_all_entities_dirty(original_workspace, current_workspace)
summary = get_dirty_summary(results)

print(f"\nOverall Result: {'WORKSPACE IS DIRTY' if summary['is_dirty'] else 'WORKSPACE IS CLEAN'}")
print(f"Dirty Entities: {', '.join(summary['dirty_entities']) if summary['dirty_entities'] else 'None'}")
print(f"Total Changes: +{summary['total_changes']['added']} ~{summary['total_changes']['modified']} -{summary['total_changes']['removed']}")

print("\nPer-Entity Breakdown:")
for entity_key, entity_summary in summary['entities'].items():
    status = "DIRTY" if entity_summary['is_dirty'] else "CLEAN"
    print(f"  {entity_key:20s}: {status:6s} (+{entity_summary['added']} ~{entity_summary['modified']} -{entity_summary['removed']}) in {entity_summary['computation_time_ms']:.1f}ms")


# =============================================================================
# Example 5: Performance Test with Large Dataset
# =============================================================================

print("\n" + "="*70)
print("Example 5: Performance Test with 200 Transfer Variables")
print("="*70)

# Generate 200 transfer variables
large_original = []
large_current = []

for i in range(200):
    tv = {
        'transfer_variable_id': f'tv_{i:03d}',
        'transfer_variable_name': f'VAR{i:03d}',
        'transfer_variable_label': f'Variable {i}',
        'domain_info': 'Domain' + str(i % 10),
        'codelist_values': [f'V{i}_{j}' for j in range(5)],  # 5 values each
        '_id': f'ui_{i}'
    }
    large_original.append(tv.copy())
    large_current.append(tv.copy())

# Modify 10 rows
for i in range(5):
    large_current[i]['transfer_variable_label'] += ' (Modified)'

# Add 5 new rows
for i in range(200, 205):
    large_current.append({
        'transfer_variable_id': f'tv_{i:03d}',
        'transfer_variable_name': f'VAR{i:03d}',
        'transfer_variable_label': f'Variable {i}',
        'domain_info': 'Domain0',
        'codelist_values': [f'V{i}_{j}' for j in range(5)],
        '_id': f'ui_{i}'
    })

# Remove 3 rows
large_current = large_current[3:]

is_dirty, details = check_entity_dirty(
    large_original,
    large_current,
    id_field='transfer_variable_id',
    entity_name='Transfer Variables (Large)',
    exclude_fields=['_id', '_domain_info']
)

print(f"Result: {'DIRTY' if is_dirty else 'CLEAN'}")
print(f"Original rows: {details['original_count']}")
print(f"Current rows: {details['current_count']}")
print(f"Added: {details['added_count']}, Modified: {details['modified_count']}, Removed: {details['removed_count']}")
print(f"⚡ Time: {details['computation_time_ms']:.2f}ms for {details['original_count']} rows")
print(f"   ({details['computation_time_ms']/details['original_count']:.3f}ms per row)")

print("\n" + "="*70)
print("✅ All examples completed successfully!")
print("="*70 + "\n")

# Approval Tasks Schema Fix

## Issue
After submitting a DTA for approval, the approval detail page showed a blank screen with no approvers listed.

## Root Cause
The `dta_clone_optimized.py` file was creating approval tasks using an **old/incorrect schema** that didn't match the actual `dta_approval_task` table schema.

### Old (Incorrect) Schema Used in Clone:
```sql
task_id, workflow_id, dta_id, task_type, task_name, assignee_type,
status, due_date, created_ts
```

### Correct Schema (Used by Approval Pages):
```sql
approval_task_id, dta_workflow_id, dta_id, approver_role,
assigned_to_principal, approval_status, approval_order,
approval_comment, approved_ts,
created_by_principal, created_ts, last_updated_by_principal, last_updated_ts
```

## Changes Made

### 1. Added Librarian Task ID Generation
**File**: `dta_clone_optimized.py` (line ~834)

Added third approver task ID:
```python
jnj_task_id = str(uuid.uuid4())
vendor_task_id = str(uuid.uuid4())
librarian_task_id = str(uuid.uuid4())  # NEW
```

### 2. Fixed Approval Tasks Insert Statement
**File**: `dta_clone_optimized.py` (lines ~944-962)

**Before:**
```python
INSERT INTO {catalog}.{gold_schema}.dta_approval_task (
    task_id, workflow_id, dta_id, task_type, task_name, assignee_type,
    status, due_date, created_ts
) VALUES 
    ('{jnj_task_id}', '{workflow_id}', '{dta_id}', 'APPROVAL', 'JNJ Approval', 'JNJ', 'PENDING', NULL, current_timestamp()),
    ('{vendor_task_id}', '{workflow_id}', '{dta_id}', 'APPROVAL', 'Vendor Approval', 'VENDOR', 'PENDING', NULL, current_timestamp())
```

**After:**
```python
INSERT INTO {catalog}.{gold_schema}.dta_approval_task (
    approval_task_id, dta_workflow_id, dta_id, approver_role,
    assigned_to_principal, approval_status, approval_order,
    approval_comment, approved_ts,
    created_by_principal, created_ts, last_updated_by_principal, last_updated_ts
) VALUES 
    ('{jnj_task_id}', '{workflow_id}', '{dta_id}', 'JNJ_DAE', 
     NULL, 'PENDING', 1, NULL, NULL,
     '{created_by}', current_timestamp(), '{created_by}', current_timestamp()),
    ('{vendor_task_id}', '{workflow_id}', '{dta_id}', 'VENDOR', 
     NULL, 'PENDING', 2, NULL, NULL,
     '{created_by}', current_timestamp(), '{created_by}', current_timestamp()),
    ('{librarian_task_id}', '{workflow_id}', '{dta_id}', 'LIBRARIAN', 
     NULL, 'PENDING', 3, NULL, NULL,
     '{created_by}', current_timestamp(), '{created_by}', current_timestamp())
```

## Key Schema Changes

| Old Column | New Column | Notes |
|------------|------------|-------|
| `task_id` | `approval_task_id` | Matches PK name in schema |
| `workflow_id` | `dta_workflow_id` | Matches FK name in schema |
| `task_type` | (removed) | Not in actual schema |
| `task_name` | (removed) | Not in actual schema |
| `assignee_type` | `approver_role` | Changed to match schema, using proper values |
| `status` | `approval_status` | Matches column name in schema |
| `due_date` | (removed) | Not in actual schema |
| - | `assigned_to_principal` | Added (NULL initially, assigned via UI) |
| - | `approval_order` | Added (1, 2, 3 for JNJ, Vendor, Librarian) |
| - | `approval_comment` | Added (NULL initially) |
| - | `approved_ts` | Added (NULL initially) |
| - | `created_by_principal` | Added (audit column) |
| - | `last_updated_by_principal` | Added (audit column) |
| - | `last_updated_ts` | Added (audit column) |

## Approver Roles

Now creates **3 approval tasks** (previously only 2):
1. **JNJ_DAE** (order: 1) - JNJ Data Analytics & Engineering
2. **VENDOR** (order: 2) - External data vendor
3. **LIBRARIAN** (order: 3) - Study librarian

All tasks start as `PENDING` with no assigned principal (user assigns approvers via UI).

## Impact
- **Approval detail page** will now display approver tasks correctly
- **Submit for Approval** flow will work end-to-end
- **Approval workflow** can proceed with proper task tracking
- All new DTAs created via clone will have properly structured approval tasks

## Testing
After deploying this fix:
1. Create a new DTA (clone existing or create from scratch)
2. Click "Submit for Approval"
3. Verify the approval detail page shows 3 approval tasks (JNJ_DAE, VENDOR, LIBRARIAN)
4. Verify you can assign approvers to each task
5. Verify approval/rejection flow works correctly

## Related Files
- `/apps/clnl-data-std-mgmt-app/api/dta_clone_optimized.py` - Fixed approval task creation
- `/apps/clnl-data-std-mgmt-app/app.py` - Approval routes (lines 1354-1452, 1605-1678)
- `/apps/clnl-data-std-mgmt-app/templates/approval_detail.html` - Approval UI
- `/notebooks/data_engineering/common/nb_create_dta_instance.ipynb` - Schema definition
- `/apps/clnl-data-std-mgmt-app/api/dta_api.py` - Reference implementation (lines 2741-2792)

## Date
2026-01-31

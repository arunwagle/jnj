# Dirty Check - Clean Architecture Implementation

## Changes Made

### 1. ✅ Reverted `fetch_workspace_data_optimized` (dta_clone_optimized.py)
- Removed all transformations
- Returns **raw database fields** as-is
- No more `_transform_tv_to_workspace`, `transform_test_concepts_to_workspace`, etc.
- Added `_sanitize_undefined()` to convert Databricks `Undefined` values to `None` for JSON serialization

### 2. ✅ Updated Dirty Check Configuration
Now uses raw database field names:
```python
{
    'transfer_variables': {
        'id_field': 'transfer_variable_id',  # Raw DB field (no underscore)
        'exclude_fields': ['created_ts', 'last_updated_ts', 'last_updated_by_principal', 'parent_document_id']
    },
    'test_concepts': {
        'id_field': 'test_concept_id',  # Raw DB field
    },
    'vendor_visits': {
        'id_field': 'vendor_visit_id',  # Raw DB field
    },
    'codelists': {
        'id_field': 'codelist_id',  # Now using actual DB field instead of composite key!
    }
}
```

## Current State

### ✅ Clone/Edit Should Work Again
- `fetch_workspace_data_optimized` returns raw DB data
- No more JSON serialization errors
- Clone as Draft should function as before

### ⚠️ Dirty Check Won't Work Yet
**Problem:** The workspace populated in the browser uses **transformed field names**:
- UI has: `LABEL`, `FORMAT`, `LENGTH`, `DESCRIPTION`
- DB has: `transfer_variable_name`, `format`, `anticipated_max_length`, `variable_description`

**When dirty check compares:**
- Original (from DB): `{transfer_variable_name: "STUDYID", format: "CHAR", ...}`
- Current (from UI): `{LABEL: "STUDYID", FORMAT: "CHAR", ...}`
- **Result:** No fields match → everything appears as added/removed

## Next Steps Required

### Option A: Update UI to Use Raw DB Field Names (Recommended)
**Change workspace population to use raw DB fields:**

In `app.py` (lines 2501-2515 and 3214-3227), change from:
```python
{
    "LABEL": str(row.get("transfer_variable_name")),
    "FORMAT": str(row.get("format")),
    "LENGTH": int(row.get("anticipated_max_length", 50)),
    "DESCRIPTION": str(row.get("variable_description")),
    ...
}
```

To:
```python
{
    "transfer_variable_name": row.get("transfer_variable_name"),
    "format": row.get("format"),
    "anticipated_max_length": row.get("anticipated_max_length"),
    "variable_description": row.get("variable_description"),
    ...
}
```

**Then update all UI references:**
- Templates (`workspace.html`): `{{ row.LABEL }}` → `{{ row.transfer_variable_name }}`
- JavaScript (`script.js`): `row.LABEL` → `row.transfer_variable_name`
- Save logic already uses DB field names, so should be compatible

**Estimated Impact:**
- 1 file change in Python (app.py): 2 locations
- 1 file change in HTML (workspace.html): ~50 references
- 1 file change in JavaScript (script.js): ~30 references

### Option B: Transform in Dirty Check Only
Keep UI as-is, transform database fields before comparison in the dirty check function.

**This is NOT recommended** because it adds back the complexity we just removed.

## Testing

Once UI is updated:
1. Clone as Draft → Should work (already fixed)
2. Modify 1 TV and 1 CL → Click Save
3. Dirty check should show: "Modified: 2 rows" ✅

## Database Field Mappings Reference

### Transfer Variables
| DB Field | Current UI Field | Description |
|----------|-----------------|-------------|
| `transfer_variable_id` | `_transfer_variable_id` | Unique ID |
| `transfer_variable_name` | `LABEL` | Variable name |
| `format` | `FORMAT` | Data type |
| `anticipated_max_length` | `LENGTH` | Max length |
| `variable_description` | `DESCRIPTION` | Description |
| `domain_info` | `DOMAIN_INFO` | Domain/sheet |
| `codelist_values` | `TEST_CONCEPTS` | Controlled terms |
| `vendor_comment` | `VENDOR_COMMENT` | Comments |

### Test Concepts
Test concepts use `transfer_tuple_map` (JSON) which flattens to multiple columns.
- Uses `test_concept_id` as unique identifier

### Vendor Visits
| DB Field | Current UI Field | Description |
|----------|-----------------|-------------|
| `vendor_visit_id` | `_vendor_visit_id` | Unique ID |
| All other fields | Same name | Direct mapping |

### Codelists
| DB Field | Current UI Field | Description |
|----------|-----------------|-------------|
| `codelist_id` | N/A (was composite) | **NOW USING THIS** |
| `transfer_variable_name` | `ref` | Variable reference |
| ~~Composite `ref\|code`~~ | ~~Was used before~~ | **Replaced by codelist_id** |

## Benefits of Clean Architecture

✅ No transformation overhead  
✅ Consistent field names throughout stack  
✅ Easier debugging (DB → backend → frontend uses same names)  
✅ No JSON serialization issues  
✅ Simpler code maintenance  
✅ Codelists now use proper unique ID instead of composite key  

# DTA Clone Architecture - Clean & Consolidated

## 🎯 Overview

All DTA creation/cloning flows use a **single unified function**: `create_dta_complete()` in `dta_api.py`.

This function automatically uses the optimized parallel implementation when `USE_OPTIMIZED_CLONE = True`.

## 📊 Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     UI LAYER (app.py)                       │
│                                                             │
│  Entry Point 1: Clone from DTA Viewer                      │
│     view.html → configure_dta → create_draft_dta()         │
│                                                             │
│  Entry Point 2: Create from Study Flow                      │
│     dta_search.html → configure_dta → create_draft_dta()   │
│                                                             │
│  Entry Point 3: DTA Builder                                 │
│     dta_builder.html → configure_dta → create_draft_dta()  │
│                                                             │
│  Entry Point 4: REST API (programmatic)                     │
│     api_create_dta() [REST endpoint]                       │
│                                                             │
└────────────────────────┬────────────────────────────────────┘
                         │
                         │ ALL call the same function
                         ▼
┌─────────────────────────────────────────────────────────────┐
│            BUSINESS LOGIC (dta_api.py)                      │
│                                                             │
│           create_dta_complete()  ◄─── SINGLE ENTRY POINT   │
│                    │                                        │
│                    │ if USE_OPTIMIZED_CLONE:               │
│                    │                                        │
│         ┌──────────┴──────────┐                            │
│         ▼                     ▼                             │
│  ✅ Optimized             ⚠️ Baseline                       │
│  (1-3 seconds)           (8-12 seconds)                    │
│  - Parallel execution    - Sequential                      │
│  - 8-10 queries          - 30-40 queries                   │
│  - Production ready      - Fallback only                   │
└─────────────────────────────────────────────────────────────┘
```

## 🔧 Configuration

### Feature Flags (dta_api.py lines 50-61)

```python
# Entity feature flags - control which entities are included
FEATURE_FLAGS = {
    'enable_transfer_variables': True,
    'enable_test_concepts': True,
    'enable_vendor_visits': True,
    'enable_codelists': True,
    'enable_operational_agreements': False,  # Disabled if tables don't exist
    'enable_data_ingestion_params': False,   # Disabled if tables don't exist
}

# Performance optimization flag
USE_OPTIMIZED_CLONE = True  # Use parallel execution (70-85% faster)
```

### What Each Flag Does

| Flag | Purpose | Impact |
|------|---------|--------|
| `enable_transfer_variables` | Include Transfer Variables | Query & clone TV data |
| `enable_test_concepts` | Include Test Concepts | Query & clone TC data |
| `enable_vendor_visits` | Include Vendor Visits | Query & clone VV data |
| `enable_codelists` | Include Codelists | Query & clone CL data |
| `enable_operational_agreements` | Include OA data | Query & clone OA data (4 tables) |
| `enable_data_ingestion_params` | Include DI Params | Query & clone DIP data |
| `USE_OPTIMIZED_CLONE` | **Performance toggle** | **True = Fast, False = Slow** |

## 📁 File Organization

### Core Files

| File | Purpose | Lines |
|------|---------|-------|
| `dta_api.py` | Main API - contains `create_dta_complete()` | 4700+ |
| `dta_clone_optimized.py` | Optimized parallel implementation | 1100+ |
| `app.py` | UI layer - contains `create_draft_dta()` | 7500+ |

### Documentation Files

| File | Purpose |
|------|---------|
| `DTA_CLONE_ARCHITECTURE.md` | This file - architecture overview |
| `CLONE_OPTIMIZATION_README.md` | Original optimization documentation |
| `CLONE_OPTIMIZATION_FIXES.md` | Debug fixes applied |

## 🚀 How It Works

### 1. User Initiates Clone

Any of the 4 entry points → Eventually calls `create_dta_complete()`

### 2. Optimization Decision

```python
def create_dta_complete(...):
    if USE_OPTIMIZED_CLONE:
        return create_dta_complete_optimized(...)  # Fast path
    else:
        return _create_dta_complete_baseline(...)  # Slow fallback
```

### 3. Optimized Execution (Fast Path)

```python
create_dta_complete_optimized():
    1. Single setup query (CTE) - 1 query
    2. Core tables INSERT - 1 query
    3. Parallel entity cloning:
       ├─ Transfer Variables (parallel)
       ├─ Test Concepts (parallel)
       ├─ Codelists (parallel)
       ├─ Vendor Visits (parallel)
       ├─ OA (if enabled, parallel)
       └─ DI Params (if enabled, parallel)
    4. Batch version registry - 1 query
    5. Activity logging (async)
    
    Total: ~8-10 queries, 1-3 seconds
```

### 4. Baseline Execution (Slow Fallback)

```python
_create_dta_complete_baseline():
    1. Get next DTA number - 1 query
    2. Get base version - 1 query  
    3. Get source DTA - 1 query
    4. INSERT DTA - 1 query
    5. INSERT workflow - 1 query
    6. INSERT tasks - 2 queries
    7. Copy Transfer Variables - 2-3 queries
    8. Copy Test Concepts - 2-3 queries
    9. Copy Codelists - 2-3 queries
    10. Copy OA (4 tables) - 8+ queries
    11. Copy DI Params - 2-3 queries
    12. Copy Vendor Visits - 2-3 queries
    13. Version registry - 3-6 queries
    14. Activity logging - 2+ queries
    
    Total: 30-40 queries, 8-12 seconds
```

## 🎯 Single Source of Truth

**Q: Where do I change clone logic?**

**A:** In `create_dta_complete()` (or `dta_clone_optimized.py` for optimized version)

**Q: Where do I enable/disable features?**

**A:** `FEATURE_FLAGS` at top of `dta_api.py`

**Q: Where do I toggle performance?**

**A:** `USE_OPTIMIZED_CLONE` at top of `dta_api.py`

**Q: Why are there two functions (`create_dta_complete` and `create_draft_dta`)?**

**A:**
- `create_draft_dta()` = UI handler (Flask route, handles forms, approvers, workspace)
- `create_dta_complete()` = Business logic (creates DTA in database)
- The UI handler calls the business logic function

## 🧪 Testing

### Test Optimized Version

```python
# In dta_api.py
USE_OPTIMIZED_CLONE = True
```

Deploy and clone a DTA. Look for:
```
✅ Using OPTIMIZED parallel clone implementation
============================================================
🚀 PHASE 2 OPTIMIZED: Parallel DTA Creation
...
🎉 DTA CREATION COMPLETE in 1.15s
```

### Test Baseline (Fallback)

```python
# In dta_api.py
USE_OPTIMIZED_CLONE = False
```

Deploy and clone a DTA. Look for:
```
⚠️  Using BASELINE sequential clone implementation
============================================================
DTA CREATION: Starting complete DTA creation
...
DTA CREATION COMPLETE!
```

## 🔍 Troubleshooting

### Clone is slow (> 10 seconds)

**Possible causes:**
1. `USE_OPTIMIZED_CLONE = False` (check flag)
2. Not redeployed after changes
3. Database connection issues
4. High concurrent load

**Solution:** Check logs for which implementation is running

### Table not found errors

**Possible causes:**
1. Feature flag enabled for entity with missing tables
2. Wrong schema/catalog configuration

**Solution:** Set feature flag to `False` for that entity

### Feature flags not working

**Possible causes:**
1. Not redeployed after flag change
2. Import error in `dta_clone_optimized.py`

**Solution:** Check logs for `🔧 Feature flags loaded:` output

## 📈 Performance Metrics

### Expected Times (4 enabled entities: TV, TC, CL, VV)

| Implementation | Queries | Time | Speedup |
|----------------|---------|------|---------|
| Baseline | 30-40 | 8-12s | Baseline |
| Optimized | 8-10 | 1-3s | **70-85% faster** |

### With 50 Concurrent Users

| Workers | Per-User Time | Total Connections | Safe? |
|---------|---------------|-------------------|-------|
| 6 | 1-2s | 300 | ⚠️ May exhaust pool |
| 4 | 1.5-2.5s | 200 | ✅ Safe |
| 2 | 3-4s | 100 | ✅ Safe |

Adjust `max_workers` in `dta_clone_optimized.py` line 985 based on your SQL Warehouse capacity.

## 🎉 Summary

- **One function**: `create_dta_complete()` handles all clones
- **One decision**: `USE_OPTIMIZED_CLONE` flag controls performance
- **One place**: Feature flags in `dta_api.py` control entities
- **No confusion**: Clear, consolidated architecture
- **Easy testing**: Toggle one flag to compare implementations

---

For questions or issues, check logs for the implementation in use and verify feature flags are correctly loaded.

# Save Draft False Changes Detection Fix

## Date
2026-01-31

## Issue
When clicking "Save Draft", the system reported many items as "updated" even when nothing was changed:
- "168 test concept(s) updated" when no TC changes were made
- Visits and timepoints showing as changed when values were identical

## Root Cause

### Bug 1: TC Tuple Map Includes Metadata Fields
**Location**: `app.py` lines ~4407-4411 and ~4533-4537

**Problem**: When extracting the `tuple_map` for Test Concepts, the code included ALL non-underscore fields:

```python
# BEFORE (WRONG)
ui_tuple_map = {}
for key, val in tc.items():
    if not key.startswith('_'):  # Includes metadata!
        ui_tuple_map[key] = str(val) if val is not None else ""
```

This captured metadata fields (`test_concept_id`, `vendor_comment`, `notes`, `status`, etc.) in the tuple map.

When compared with the DB's `transfer_tuple_map` (which only contains transfer variable mappings), every TC appeared to have changes because the metadata fields existed in UI but not in DB's tuple map.

**Result**: All 168 TCs were marked as "changed" and unnecessarily updated in the database.

### Bug 2 & 3: Visits Numeric Type Mismatch
**Location**: `app.py` lines ~5819 and ~5836

**Problem**: Comparing numeric fields without type normalization:

```python
# BEFORE (WRONG)
if ui_visit_number != db_visit['visit_number']:  # int vs string comparison!
```

**Data types**:
- **From DB**: `visit_number` = `1` (int) or `None`
- **From UI**: `visit_number` = `"1"` (string) or `""` or `None`

In Python: `1 != "1"` evaluates to `True`, so identical values appeared as changes.

**Same issue for `timepoint_number`.**

**Result**: All visits showed as "changed" even when values were the same.

## Solution

### Fix 1: Exclude Metadata from TC Tuple Map

**Added metadata exclusion list** at both locations where tuple_map is extracted:

```python
# AFTER (CORRECT)
METADATA_FIELDS = {'test_concept_id', 'test_concept_reference', 'vendor_comment', 'notes', 'status', 'domain_info'}
ui_tuple_map = {}
for key, val in tc.items():
    if not key.startswith('_') and key not in METADATA_FIELDS:  # ✅ Excludes metadata
        ui_tuple_map[key] = str(val) if val is not None else ""
```

**Locations**:
1. Line ~4407: Existing TC comparison
2. Line ~4533: New TC insertion

**Effect**: Only actual transfer variable mappings are compared, not metadata.

### Fix 2 & 3: Normalize Numeric Fields for Visits

**Added normalization helper function** before comparison:

```python
# AFTER (CORRECT)
def normalize_number(val):
    """Normalize numeric value for comparison"""
    if val is None or val == '' or val == 'None':
        return None
    try:
        return int(val)
    except (ValueError, TypeError):
        return None

ui_visit_number_norm = normalize_number(ui_visit_number)
db_visit_number_norm = normalize_number(db_visit['visit_number'])

if ui_visit_number_norm != db_visit_number_norm:  # ✅ Compares normalized ints
    # Record change
```

**Applied to**:
- `visit_number` comparison (line ~5819)
- `timepoint_number` comparison (line ~5836)

**Effect**: `1` (int) and `"1"` (string) are both normalized to `1` (int) and correctly seen as equal.

## Changes Made

| Location | Bug | Fix |
|----------|-----|-----|
| `app.py` line ~4407-4411 | TC tuple_map includes metadata | Added `METADATA_FIELDS` exclusion |
| `app.py` line ~4533-4537 | TC tuple_map includes metadata (new inserts) | Added `METADATA_FIELDS` exclusion |
| `app.py` line ~5819 | `visit_number` type mismatch | Added `normalize_number()` helper |
| `app.py` line ~5836 | `timepoint_number` type mismatch | Added `normalize_number()` helper |

## Testing

After deploying:

### Test 1: TC False Changes
1. Open a DTA with Test Concepts
2. Don't make any changes
3. Click "Save Draft"
4. **Expected**: "Draft saved successfully" (no TC count)
5. **Before fix**: "168 test concept(s) updated"

### Test 2: Visits False Changes
1. Open a DTA with Visits
2. Don't make any changes
3. Click "Save Draft"
4. **Expected**: "Draft saved successfully" (no visits count)
5. **Before fix**: "X visit(s) updated"

### Test 3: Actual Changes Still Detected
1. Edit a TV field
2. Click "Save Draft"
3. **Expected**: "1 transfer variable(s) updated"
4. Verify only actual changes are reported

## Impact

- ✅ Eliminates false positive change detection for TC
- ✅ Eliminates false positive change detection for Visits
- ✅ Reduces unnecessary database writes
- ✅ Provides accurate feedback to users
- ✅ Improves save performance (fewer UPDATEs)
- ✅ Activity log now shows only real changes

## Related Issues

This fix is separate from today's OA/DIP dirty check changes. These bugs existed in the save logic before and were discovered during testing.

The previous fix at line 3730 (which had the metadata exclusion) was only for TC **display/rendering**, not for TC **save/comparison**. This fix applies the same pattern to the save logic.

## Deployment

```bash
cd /Users/arun.wagle/Databricks/Clients/2025/JNJ/DTA_POC/code/clinical-data-standards
databricks bundle deploy --target dev
bash _deploy_app.sh clnl-data-std-mgmt-app
```

## Success Criteria

- [x] TC metadata fields excluded from tuple_map (2 locations)
- [x] Visits numeric fields normalized for comparison (2 fields)
- [ ] Deployed to server
- [ ] Tested: No false "TC updated" message
- [ ] Tested: No false "visits updated" message
- [ ] Tested: Real changes still detected correctly

## Notes

- The `METADATA_FIELDS` set is defined locally in each location for clarity
- Could be refactored to a constant if needed in the future
- The `normalize_number()` helper is defined inline but could be moved to a utility module
- These fixes restore the behavior that was working before (as user confirmed)

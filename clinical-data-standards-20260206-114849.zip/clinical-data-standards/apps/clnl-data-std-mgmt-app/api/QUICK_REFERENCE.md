# DTA Clone - Quick Reference Card

## 🚀 Optimization Phases

- **Phase 1:** Baseline implementation (original, slow)
- **Phase 2:** Parallel clone execution (Oct 2024)
- **Phase 3:** Parallel workspace fetch (Jan 2026) ⭐ **Latest**

## 🎯 Single Source of Truth

**Function:** `create_dta_complete()` in `dta_api.py`

**Purpose:** ALL DTA creation/cloning goes through this function

## ⚡ Quick Actions

### Enable Optimization (Fast Clones)
```python
# In dta_api.py line 60
USE_OPTIMIZED_CLONE = True  # ✅ 1-3 seconds
```

### Disable Optimization (Fallback)
```python
# In dta_api.py line 60
USE_OPTIMIZED_CLONE = False  # ⚠️ 8-12 seconds
```

### Enable/Disable Entity Types
```python
# In dta_api.py lines 50-57
FEATURE_FLAGS = {
    'enable_transfer_variables': True,   # Always enabled
    'enable_test_concepts': True,        
    'enable_vendor_visits': True,        
    'enable_codelists': True,            
    'enable_operational_agreements': False,   # ← Toggle here
    'enable_data_ingestion_params': False,    # ← Toggle here
}
```

## 📊 Performance Comparison

### Clone Operation
| Setting | Time | Queries | When to Use |
|---------|------|---------|-------------|
| `USE_OPTIMIZED_CLONE = True` | 1-3s | 8-10 | ✅ **Production** |
| `USE_OPTIMIZED_CLONE = False` | 8-12s | 30-40 | ⚠️ Debug only |

### Workspace Population (After Clone)
| Setting | Time | Queries | Impact |
|---------|------|---------|--------|
| `USE_OPTIMIZED_CLONE = True` | 1-2s | 6 parallel | ✅ **Fast** |
| `USE_OPTIMIZED_CLONE = False` | 25-27s | 12+ sequential | ⚠️ **Very slow** |

### **Total End-to-End (Clone + Workspace)**
| Setting | Total Time | User Experience |
|---------|-----------|-----------------|
| `USE_OPTIMIZED_CLONE = True` | **2-5s** | ✅ Excellent |
| `USE_OPTIMIZED_CLONE = False` | **33-39s** | ❌ Poor |

## 🔍 How to Verify It's Working

### Check Logs After Clone

**✅ GOOD (Optimized running):**
```
✅ Using OPTIMIZED parallel clone implementation
🚀 PHASE 2 OPTIMIZED: Parallel DTA Creation
⚡ Starting parallel entity cloning...
🎉 DTA CREATION COMPLETE in 1.15s
```

**⚠️ BAD (Baseline running):**
```
⚠️ Using BASELINE sequential clone implementation
DTA CREATION: Starting complete DTA creation
(takes 8-12 seconds)
```

## 🐛 Common Issues

### Issue: Clone is slow (> 5 seconds)

**Check:**
```python
USE_OPTIMIZED_CLONE = True  # Is this True?
```

**Fix:** Set to `True` and redeploy

---

### Issue: "Table not found" errors

**Example:**
```
TABLE_OR_VIEW_NOT_FOUND: md_dta_operational_agreement
```

**Fix:** Disable the entity
```python
FEATURE_FLAGS = {
    'enable_operational_agreements': False,  # ← Set to False
}
```

---

### Issue: Optimization not being used

**Symptoms:**
- Logs show "BASELINE sequential" message
- Clone takes 8-12 seconds

**Fix:**
1. Check `USE_OPTIMIZED_CLONE = True`
2. Redeploy the app
3. Verify logs show "OPTIMIZED parallel"

## 📁 Where Is Everything?

### Configuration
- **File:** `apps/clnl-data-std-mgmt-app/api/dta_api.py`
- **Lines:** 50-65 (feature flags)
- **What:** All configuration in one place

### Main Function
- **File:** `apps/clnl-data-std-mgmt-app/api/dta_api.py`
- **Function:** `create_dta_complete()` (line ~2523)
- **What:** Dispatcher that chooses optimized vs baseline

### Optimized Implementation
- **File:** `apps/clnl-data-std-mgmt-app/api/dta_clone_optimized.py`
- **Function:** `create_dta_complete_optimized()` (line ~80)
- **What:** Parallel execution logic

### Baseline Implementation
- **File:** `apps/clnl-data-std-mgmt-app/api/dta_api.py`
- **Function:** `_create_dta_complete_baseline()` (line ~2560)
- **What:** Original sequential logic (fallback)

### UI Layer
- **File:** `apps/clnl-data-std-mgmt-app/app.py`
- **Function:** `create_draft_dta()` (line ~2880)
- **What:** Handles forms, calls `create_dta_complete()`

## 🚀 Deployment

### Steps
```bash
# 1. Verify configuration
# Check dta_api.py lines 50-65

# 2. Deploy
cd /path/to/clinical-data-standards
./_deploy_app.sh

# 3. Test clone and check logs
```

### Post-Deployment Verification
1. Clone a DTA (any method)
2. Check logs for "✅ Using OPTIMIZED"
3. Verify time < 3 seconds
4. If not, check flags and redeploy

## 📚 Full Documentation

- **Architecture:** `DTA_CLONE_ARCHITECTURE.md` - Complete system overview
- **Refactor:** `REFACTOR_SUMMARY.md` - Phase 2 refactor details
- **Workspace Fetch:** `WORKSPACE_FETCH_OPTIMIZATION.md` - Phase 3 optimization
- **Original optimization:** `CLONE_OPTIMIZATION_README.md` - Technical deep dive
- **Debug fixes:** `CLONE_OPTIMIZATION_FIXES.md` - Historical bug fixes

## 💡 Remember

1. **One function controls everything:** `create_dta_complete()`
2. **One flag for performance:** `USE_OPTIMIZED_CLONE`
3. **Six flags for entities:** `FEATURE_FLAGS` dict
4. **All in one file:** `dta_api.py` lines 50-65

That's it! Simple, clean, fast. 🎉

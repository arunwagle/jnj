# Changelog - Visits Feature

## [v2.1.0] - 2026-01-29

### 🎉 New Features

#### Visits Management
- **Complete CRUD Operations**: Add, edit, delete, and restore visits in DTA workspace
- **View Mode**: Display vendor visits in DTA Viewer with collapsible accordion
- **Clone Integration**: Visits are automatically cloned when creating draft DTAs
- **Audit Trail**: Full activity logging for all visit operations (create, update, delete)
- **Versioning**: Visits integrated into SCD Type 2 versioning workflow
- **Soft Delete**: Delete with undo functionality (before save) + permanent delete (on save)

#### Data Processing
- **Excel Parser**: Automated extraction of visits from Excel sheets
  - Parses 4 columns: Visit, Visit Number, Timepoint, Timepoint Number
  - Robust header detection (requires "Visit" AND "Visit Number")
  - Intelligent instruction row skipping
  - Scalable processing using `mapInPandas`
- **Historical Data**: Populates `md_vendor_visit_draft` from uploaded Excel files
- **Test Suite**: Standalone test notebook for validation

#### UI Enhancements
- **Consistent Styling**: Visits table matches Transfer Variables styling
- **Status Field Removed**: Cleaner UI without redundant status column
- **Modal Progress**: Clone dialog shows "Copying visits..." step
- **Success Messages**: Includes visits count in all summaries
- **Domain Filtering**: Auto-filter by first domain on DTA Viewer

---

### 🔧 Changes by Component

#### Backend (Flask Application)

##### `app.py` - Main Application
**New API Endpoints:**
- `POST /api/workspace/<key>/visits/<idx>/edit` - Enable visit row editing
- `POST /api/workspace/<key>/visits/<idx>/save` - Save visit changes
- `POST /api/workspace/<key>/visits/<idx>/cancel` - Cancel editing
- `POST /api/workspace/<key>/visits/add` - Add new visit row
- `POST /api/workspace/<key>/visits/<idx>/update-cell` - Update single cell

**Enhanced Existing Endpoints:**
- `/api/workspace/<key>/<library_type>/<idx>/delete` - Added visits support
- `/api/workspace/<key>/<library_type>/<idx>/restore` - Added visits support
- `/api/workspace/<key>/save` - Added visits save logic with deletion processing

**Route Handlers:**
- `create_draft_dta()` - Loads visits from database when cloning
- `edit_draft()` - Loads visits for editing existing drafts
- `view_dta()` - Loads visits for display in DTA Viewer
- `workspace()` - Added 'VISITS' to allowed tabs

**Data Processing:**
- Visits deletion: Marks for deletion, removes from DB on save, logs to activity
- Visits insertion: Generates UUIDs, validates data, inserts to silver table
- Visits updates: Detects changes, updates fields, logs activity

**Lines Changed:** ~400 lines added/modified

##### `api/dta_api.py` - Data Access Layer
**New Functions:**
- `get_vendor_visits_for_dta()` - Fetch visits from silver or gold based on DTA status
- `get_transfer_variables_for_dta()` - Refactored TV loading into helper (consistency)

**Enhanced Functions:**
- `create_dta_complete()` - Step 4f: Copy visits from source DTA to new DTA
  - Handles both draft and approved source DTAs
  - Generates new UUIDs for cloned visits
  - Registers version in md_version_registry
  - Logs bulk insert activity
  - Returns visit count in summary

**Lines Changed:** ~200 lines added

##### `api/activity_log_api.py` - Activity Logging
**Enhanced Functions:**
- `log_batch_update()` - Added 'DELETED' field type handling
  - Separate CREATED, UPDATED, DELETED sections in activity comments
  - Shows entity IDs for deleted items
  - Better formatting for audit trail

**Lines Changed:** ~30 lines modified

---

#### Frontend (Templates & Assets)

##### `templates/workspace.html` - DTA Configuration Workspace
**New Tab:**
- Complete VISITS tab with TV-style table structure
  - Two-row header (section header + column headers)
  - Actions column (Edit, Save, Cancel, Delete, Restore, Comments)
  - Visit Name (sticky column)
  - Visit Number, Timepoint, Timepoint Number, Notes
  - Row states: readonly, editing, deleted, approved

**UI Elements:**
- "Add Visit" button in header
- Delete button with trash icon
- Restore button with undo icon
- Comment button with badge indicator
- Edit/Save/Cancel buttons matching TV pattern

**Styling:**
- Uses `tv-table`, `tv-actions`, `tv-variable-name` classes
- Proper sticky columns for Actions and Visit Name
- Row highlighting for different states
- Strikethrough styling for deleted rows

**Status Field:** Removed (per user request)

**Lines Changed:** ~150 lines added

##### `templates/view.html` - DTA Viewer
**New Accordion:**
- Visits section with collapsible panel
- Table display with columns: #, Visit Name, Visit Number, Timepoint, Timepoint Number
- Visit count badge in header
- Icon: Purple gradient calendar icon

**Auto-filtering:**
- Removed "All" option from Domain Info dropdown
- Auto-select first domain on page load
- Filter applies to TV, TC, and other entities

**Status Field:** Removed from Visits table

**Lines Changed:** ~80 lines added/modified

##### `templates/dta_search.html` - DTA Search & Clone
**Clone Modal:**
- Added step 7: "Copying visits..."
- Renumbered steps 8 and 9
- Updated JavaScript steps array to 9 items
- Animation cycles through all 9 steps

**Lines Changed:** ~15 lines modified

##### `templates/configure_dta.html` - DTA Configuration Page
**Clone Modal:**
- Added step 7: "Copying visits..."
- Renumbered steps 8 and 9
- Updated JavaScript steps array to 9 items

**Lines Changed:** ~15 lines modified

##### `templates/approvals.html` - Approvals Page
**Enhancement:**
- Added `approved_by` field display in "Recently Approved" panel
- Shows who approved each DTA

**Lines Changed:** ~5 lines added

##### `static/script.js` - JavaScript Logic
**New Functions:**
- `visitEdit(key, idx)` - Enable visit row editing
- `visitSave(key, idx)` - Save visit changes
- `visitCancel(key, idx)` - Cancel editing
- `addVisitRow(key)` - Add new visit
- `updateVisitCell(key, idx, field, value)` - Update single cell

**Enhanced Functions:**
- `deleteLibraryItem()` - Added visits support, removed confirm() dialog
- `restoreLibraryItem()` - Added visits support
- `filterTvByDomain()` - Fixed selector to work on both workspace and viewer pages

**Lines Changed:** ~100 lines added/modified

##### `static/styles.css` - Styling
**New Classes:**
- `.btn-action-delete` - Consistent delete button styling (red on hover)
- `.visits-icon` - Purple gradient calendar icon

**Lines Changed:** ~20 lines added

---

#### Data Processing (Databricks)

##### `nb_visits_activities_processor.ipynb` - NEW FILE
**Purpose:** Extract visits from Excel sheets and save to `md_vendor_visit_draft`

**Key Features:**
- Reads from `md_dta_excel_file_raw` table
- Filters sheets by category: `visits_and_timepoints`
- Robust header detection:
  - Requires "Visit" AND "Visit Number" columns
  - Timepoint columns are optional
  - Searches first 10 rows for header
- Instruction row detection:
  - Keywords: "specify", "provide", "instructions", "color legend", etc.
  - Text length heuristics (>100 chars = likely instruction)
  - Non-numeric visit numbers
- Parses 4 columns:
  - `visit_name` (Visit)
  - `visit_number` (Visit Number) - converted to int
  - `timepoint` (Timepoint) - optional
  - `timepoint_number` (Timepoint Number) - optional, extracted from text
- Uses `mapInPandas` for scalable processing
- Saves to `silver_md.md_vendor_visit_draft` via `save_with_audit()`
- Generates UUIDs for each visit
- Populates audit columns: created_by_principal, created_ts, etc.

**Functions:**
- `find_header_row()` - Locate header in messy Excel data
- `parse_timepoint_number()` - Extract numeric value from text
- `is_instruction_row()` - Skip descriptive/instruction rows
- `process_visit_sheet()` - Main processing logic (mapInPandas)

**Lines:** 637 lines

##### `nb_test_visits_activities_standalone.ipynb` - NEW FILE
**Purpose:** Test suite for visits processor

**Test Cases:**
- Header detection with various formats
- Timepoint number extraction (e.g., "Week 1" → 1)
- Instruction row detection
- Full end-to-end processing
- Edge cases: missing columns, empty rows, malformed data

**Lines:** 354 lines

##### `nb_version_approve_dta.ipynb` - MODIFIED
**Enhancements:**
- Added `UPDATE ... SET is_current = false` before promoting new versions
  - Critical fix for deletion data integrity
  - Ensures deleted items don't reappear after approval
- Dynamically reads `definition_hash_fields_by_type` from config
  - Supports vendor_visit automatically
  - No hardcoding of library types
- Dynamically reads `gold_columns_by_type` from config
  - Auto-adapts to new entity types
  - Cleaner, more maintainable code

**Lines Changed:** ~50 lines modified

##### `job_tsdta_processor.job.yml` - MODIFIED
**New Task:**
- `load_visits_activities` - Parallel task for visits processing
  - Depends on: `check_documents_found`
  - Notebook: `nb_visits_activities_processor`
  - Runs in parallel with TV/TC/Codelists processing
  - Serverless environment

**Lines Changed:** ~10 lines added

---

#### Configuration

##### `clinical_data_standards.yaml` - MODIFIED
**New Configuration:**
```yaml
definition_hash_fields_by_type:
  vendor_visit:
    - protocol_visit_id
    - visit_name
    - visit_number
    - timepoint
    - timepoint_number

library_tables:
  - name: "md_vendor_visit"
    library_type: "vendor_visit"
    schema: "gold_md"
    silver_table: "md_vendor_visit_draft"
    silver_schema: "silver_md"
    enable_comment_feature: true
    business_keys: ["definition_hash"]
    description: "Vendor-specific visit implementations"
    gold_columns:
      - vendor_visit_id
      - protocol_visit_id
      - soa_id
      - parent_document_id
      - dta_id
      - trial_id
      - data_stream_type
      - data_provider_name
      - visit_name
      - visit_number
      - timepoint
      - timepoint_number
      - status
      - notes
      - processing_status
      - version
      - version_status
      - is_current_draft
```

**Lines Changed:** ~30 lines added

##### `setup_cdm_app_permissions.sql` - MODIFIED
**New Permission:**
```sql
('perm_action_delete_item', 'ACTION_EXECUTE', 'action_delete_library_item', 'HIDE', 'Delete library items', NULL)
```

**Permission Assignment:**
```sql
SELECT uuid(), 'group_jnj_dae', 'perm_action_delete_item'
```

**Lines Changed:** ~5 lines added

---

#### Documentation

##### `04_versioning_design.readme.md` - MODIFIED
**New Section:** "🔧 Data Change Operations (Inserts, Updates, Deletes)"

**Content:**
- Detailed explanation of INSERT operations
- UPDATE workflow and change detection
- DELETE workflow across silver and gold layers
- Data integrity guarantees
- Activity logging patterns
- `log_batch_update()` usage examples
- Best practices for data modifications

**Lines Changed:** ~150 lines added

---

### 🐛 Bug Fixes

1. **Delete Confirmation Dialog**
   - **Issue:** Browser confirm() dialog appeared on delete, conflicting with soft delete + undo UX
   - **Fix:** Removed all confirm() calls from delete functions
   - **Files:** `static/script.js`

2. **Delete API Error - Invalid Library Type**
   - **Issue:** Clicking delete on visits showed "invalid library type" error
   - **Fix:** Added `'visits': 'visits'` to `type_map` in delete/restore endpoints
   - **Files:** `app.py` (lines 6702, 6765)

3. **Inconsistent Button Styling**
   - **Issue:** Delete button styling differed between DIP and TV/TC/Codelists
   - **Fix:** Created `.btn-action-delete` class, applied consistently
   - **Files:** `static/styles.css`, `templates/workspace.html`

4. **TV Count Shows 0 on Page Load**
   - **Issue:** Domain filter auto-applied on load, resulting in 0 visible count
   - **Fix:** Removed auto-filter JavaScript, let template count stand
   - **Files:** `templates/view.html`

5. **Domain Filter Selector Wrong**
   - **Issue:** `filterTvByDomain()` used wrong selector, failed on viewer page
   - **Fix:** Try `#tv-table tbody` first (viewer), fallback to `.tv-table tbody` (workspace)
   - **Files:** `static/script.js`

6. **No Deletion Activity Logged**
   - **Issue:** Deleting draft records showed "No changes detected", no history
   - **Fix:** Ensured all deletions added to `deleted_items_for_log`, called `log_batch_update()`
   - **Files:** `app.py` (deletion processing loops)

7. **`silver_schema` Not Defined Error**
   - **Issue:** `create_draft_dta()` had undefined `silver_schema` when loading visits
   - **Fix:** Refactored TV and Visits into helper functions that resolve schema internally
   - **Files:** `app.py`, `api/dta_api.py`

8. **UUID in `last_updated_by_principal`**
   - **Issue:** Cloned visits showed UUID instead of username
   - **Fix:** Added audit columns explicitly in visits INSERT statement
   - **Files:** `api/dta_api.py` (Step 4f)

9. **Instruction Rows Captured as Data**
   - **Issue:** Excel parser captured instruction rows below header as data
   - **Fix:** Added `is_instruction_row()` function with keyword and heuristic detection
   - **Files:** `nb_visits_activities_processor.ipynb`

10. **Header Detection Too Lenient**
    - **Issue:** Parser detected rows as headers even if only one column matched
    - **Fix:** Require BOTH "Visit" AND "Visit Number" for valid header
    - **Files:** `nb_visits_activities_processor.ipynb`

---

### 💥 Breaking Changes

**None.** This is a backward-compatible feature addition.

Existing DTAs without visits will continue to function normally. Visits section will appear empty until data is added.

---

### 🗄️ Database Changes

#### New Tables
- `silver_md.md_vendor_visit_draft` - Auto-created by `save_with_audit()`
- `gold_md.md_vendor_visit` - Auto-created by approval workflow

#### Table Schema
```sql
CREATE TABLE IF NOT EXISTS aira_test.silver_md.md_vendor_visit_draft (
  vendor_visit_id STRING,
  parent_document_id STRING,
  dta_id STRING,
  trial_id STRING,
  data_stream_type STRING,
  data_provider_name STRING,
  visit_name STRING,
  visit_number INT,
  timepoint STRING,
  timepoint_number INT,
  protocol_visit_id STRING,
  soa_id STRING,
  notes STRING,
  status STRING,
  version STRING,
  version_status STRING,
  is_current_draft BOOLEAN,
  created_by_principal STRING,
  created_ts TIMESTAMP,
  last_updated_by_principal STRING,
  last_updated_ts TIMESTAMP
) USING DELTA;
```

#### New Permissions
- `action_delete_library_item` - Delete library items (TV, TC, Visits, etc.)
- Assigned to: `group_jnj_dae`

---

### 📈 Performance Impact

**Clone Operation:**
- **Before:** ~60 seconds (5 entity types)
- **After:** ~60-75 seconds (6 entity types including visits)
- **Impact:** +15 seconds (visits copy + query)

**UI Page Load:**
- **Before:** ~2 seconds
- **After:** ~2.2 seconds (additional visits query)
- **Impact:** Minimal

**Note:** Performance optimizations identified (see README troubleshooting section):
- Parallel copy operations could reduce clone time by 3-5x
- Eliminating re-fetch queries could save 10-15 seconds

---

### 🔒 Security

**New Permission:** `action_delete_library_item`
- **Scope:** Delete any library item (TV, TC, Visits, Codelists, DIP, OA)
- **Assigned to:** JNJ DAE users only
- **Enforcement:** Backend permission check before deletion
- **Audit:** All deletions logged to `md_activity_log`

**Soft Delete:**
- Items marked for deletion in UI remain recoverable until save
- Physical deletion from silver layer on save
- Logical deletion from gold layer on approval (is_current = false)
- Full audit trail maintained

---

### 🧪 Testing

**Manual Testing Completed:**
- ✅ Create visit in workspace
- ✅ Edit visit in workspace
- ✅ Delete visit (soft delete + undo)
- ✅ Save draft with visits
- ✅ Clone DTA with visits
- ✅ View visits in DTA Viewer
- ✅ Excel processing with visits data
- ✅ Approval workflow with visits
- ✅ Permission checks (DAE can delete, others cannot)
- ✅ Activity logging for all visit operations

**Unit Tests:**
- ✅ Header detection (`nb_test_visits_activities_standalone.ipynb`)
- ✅ Timepoint number parsing
- ✅ Instruction row detection
- ✅ End-to-end processing

---

### 📝 Known Issues

**None at this time.**

---

### 🚀 Deployment Notes

**Order Matters:**
1. **Database permissions FIRST** - Required for delete functionality
2. Backend + Frontend together - Interdependent
3. Configuration updates - Required before job runs
4. Databricks notebooks - Required for Excel processing
5. Flask restart - Apply changes

**Rollback Safe:** Yes. See README.md for rollback instructions.

---

### 👥 Contributors

- Development Team: Clinical Data Standards
- Testing: JNJ DAE Team
- Documentation: Engineering Team

---

### 📅 Timeline

- **Planning:** 2026-01-27
- **Development:** 2026-01-28 to 2026-01-29
- **Testing:** 2026-01-29
- **Deployment:** 2026-01-29
- **Release:** v2.1.0

---

## Previous Versions

### [v2.0.0] - 2026-01-15
- Initial DTA application with TV, TC, Codelists, OA, DIP
- Approval workflow
- Versioning (SCD Type 2)
- Activity logging

### [v1.0.0] - 2025-12-01
- Initial release
- Basic DTA management


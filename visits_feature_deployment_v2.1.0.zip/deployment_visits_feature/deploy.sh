#!/bin/bash

##############################################################################
# Visits Feature Deployment Script
# Version: v2.1.0
# Date: 2026-01-29
#
# This script automates the deployment of the Visits feature to the
# Clinical Data Standards DTA application.
#
# Usage:
#   ./deploy.sh [options]
#
# Options:
#   --target-dir <path>     Target directory for Flask application
#   --databricks-path <path> Target path in Databricks workspace
#   --warehouse-id <id>      Databricks SQL warehouse ID
#   --skip-backup            Skip backup step
#   --skip-permissions       Skip permissions deployment
#   --dry-run                Show what would be done without doing it
#   --help                   Show this help message
#
##############################################################################

set -e  # Exit on error
set -u  # Exit on undefined variable

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
TARGET_DIR=""
DATABRICKS_PATH=""
WAREHOUSE_ID=""
SKIP_BACKUP=false
SKIP_PERMISSIONS=false
DRY_RUN=false
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

##############################################################################
# Helper Functions
##############################################################################

print_header() {
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ ERROR: $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ WARNING: $1${NC}"
}

print_info() {
    echo -e "  $1"
}

check_command() {
    if ! command -v "$1" &> /dev/null; then
        print_error "Required command '$1' not found. Please install it first."
        exit 1
    fi
}

execute_command() {
    local cmd="$1"
    local description="$2"
    
    if [ "$DRY_RUN" = true ]; then
        echo -e "${YELLOW}[DRY RUN]${NC} $description"
        echo "  Command: $cmd"
        return 0
    fi
    
    print_info "$description"
    if eval "$cmd"; then
        print_success "Done"
        return 0
    else
        print_error "Failed: $description"
        return 1
    fi
}

show_help() {
    cat << EOF
Visits Feature Deployment Script v2.1.0

Usage: ./deploy.sh [options]

Options:
    --target-dir <path>         Target directory for Flask application
                                Example: /opt/apps/clnl-data-std-mgmt-app
    
    --databricks-path <path>    Target path in Databricks workspace
                                Example: /Workspace/Repos/production/clinical-data-standards
    
    --warehouse-id <id>         Databricks SQL warehouse ID for permissions
                                Example: abc123def456
    
    --skip-backup               Skip backup step (not recommended)
    
    --skip-permissions          Skip database permissions deployment
                                (only if permissions already exist)
    
    --dry-run                   Show what would be done without doing it
    
    --help                      Show this help message

Examples:
    # Full deployment
    ./deploy.sh \\
        --target-dir /opt/apps/clnl-data-std-mgmt-app \\
        --databricks-path /Workspace/Repos/production/clinical-data-standards \\
        --warehouse-id abc123

    # Dry run to preview changes
    ./deploy.sh --target-dir /opt/apps/clnl-data-std-mgmt-app --dry-run

    # Skip backup (for testing)
    ./deploy.sh --target-dir /opt/apps/clnl-data-std-mgmt-app --skip-backup

EOF
}

##############################################################################
# Parse Command Line Arguments
##############################################################################

while [[ $# -gt 0 ]]; do
    case $1 in
        --target-dir)
            TARGET_DIR="$2"
            shift 2
            ;;
        --databricks-path)
            DATABRICKS_PATH="$2"
            shift 2
            ;;
        --warehouse-id)
            WAREHOUSE_ID="$2"
            shift 2
            ;;
        --skip-backup)
            SKIP_BACKUP=true
            shift
            ;;
        --skip-permissions)
            SKIP_PERMISSIONS=true
            shift
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --help)
            show_help
            exit 0
            ;;
        *)
            print_error "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

##############################################################################
# Validate Prerequisites
##############################################################################

print_header "Validating Prerequisites"

# Check required commands
check_command "cp"
check_command "tar"
check_command "databricks"

# Validate target directory
if [ -z "$TARGET_DIR" ]; then
    print_error "Target directory not specified. Use --target-dir option."
    show_help
    exit 1
fi

if [ ! -d "$TARGET_DIR" ] && [ "$DRY_RUN" = false ]; then
    print_error "Target directory does not exist: $TARGET_DIR"
    exit 1
fi

print_success "Target directory: $TARGET_DIR"

# Check Databricks CLI authentication
if ! databricks current-user me &> /dev/null; then
    print_error "Databricks CLI not authenticated. Run: databricks configure"
    exit 1
fi

print_success "Databricks CLI authenticated"

# Validate paths
if [ ! -d "$SCRIPT_DIR/backend" ]; then
    print_error "Deployment package incomplete. Missing backend/ directory."
    exit 1
fi

print_success "Deployment package validated"

##############################################################################
# Step 1: Backup Current Environment
##############################################################################

if [ "$SKIP_BACKUP" = false ]; then
    print_header "Step 1: Creating Backup"
    
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)
    BACKUP_DIR="${TARGET_DIR}_backup_${TIMESTAMP}"
    
    execute_command \
        "mkdir -p '$BACKUP_DIR' && cp -r '$TARGET_DIR'/{app.py,api,templates,static} '$BACKUP_DIR'/" \
        "Backing up current application to $BACKUP_DIR"
    
    print_success "Backup created: $BACKUP_DIR"
else
    print_header "Step 1: Skipping Backup (--skip-backup specified)"
    print_warning "No backup will be created. Rollback will be difficult!"
fi

##############################################################################
# Step 2: Deploy Database Permissions
##############################################################################

if [ "$SKIP_PERMISSIONS" = false ]; then
    print_header "Step 2: Deploying Database Permissions"
    
    if [ -z "$WAREHOUSE_ID" ]; then
        print_warning "Warehouse ID not specified. Skipping permissions deployment."
        print_info "To deploy permissions, run:"
        print_info "  databricks sql execute --file config/setup_cdm_app_permissions.sql --warehouse-id <ID>"
    else
        execute_command \
            "databricks sql execute --file '$SCRIPT_DIR/config/setup_cdm_app_permissions.sql' --warehouse-id '$WAREHOUSE_ID'" \
            "Executing permissions SQL"
        
        # Verify permission was created
        execute_command \
            "databricks sql execute --query \"SELECT COUNT(*) as cnt FROM cdm_app.gold_md.cdm_app_permission WHERE permission_name = 'action_delete_library_item'\" --warehouse-id '$WAREHOUSE_ID'" \
            "Verifying permission created"
    fi
else
    print_header "Step 2: Skipping Permissions (--skip-permissions specified)"
fi

##############################################################################
# Step 3: Deploy Backend Files
##############################################################################

print_header "Step 3: Deploying Backend Files"

# Deploy app.py
execute_command \
    "cp '$SCRIPT_DIR/backend/app.py' '$TARGET_DIR/app.py'" \
    "Deploying app.py"

# Deploy API files
execute_command \
    "cp '$SCRIPT_DIR/backend/api/dta_api.py' '$TARGET_DIR/api/dta_api.py'" \
    "Deploying api/dta_api.py"

execute_command \
    "cp '$SCRIPT_DIR/backend/api/activity_log_api.py' '$TARGET_DIR/api/activity_log_api.py'" \
    "Deploying api/activity_log_api.py"

# Verify files
if [ "$DRY_RUN" = false ]; then
    if [ -f "$TARGET_DIR/app.py" ] && [ -f "$TARGET_DIR/api/dta_api.py" ]; then
        print_success "Backend files deployed successfully"
    else
        print_error "Backend files deployment failed"
        exit 1
    fi
fi

##############################################################################
# Step 4: Deploy Frontend Files
##############################################################################

print_header "Step 4: Deploying Frontend Files"

# Deploy templates
for template in workspace.html view.html dta_search.html configure_dta.html approvals.html; do
    execute_command \
        "cp '$SCRIPT_DIR/frontend/templates/$template' '$TARGET_DIR/templates/$template'" \
        "Deploying templates/$template"
done

# Deploy static assets
execute_command \
    "cp '$SCRIPT_DIR/frontend/static/script.js' '$TARGET_DIR/static/script.js'" \
    "Deploying static/script.js"

execute_command \
    "cp '$SCRIPT_DIR/frontend/static/styles.css' '$TARGET_DIR/static/styles.css'" \
    "Deploying static/styles.css"

print_success "Frontend files deployed successfully"

##############################################################################
# Step 5: Deploy Configuration
##############################################################################

print_header "Step 5: Deploying Configuration"

# Backup existing config
CONFIG_DIR=$(dirname "$TARGET_DIR")/../../config
if [ -f "$CONFIG_DIR/clinical_data_standards.yaml" ] && [ "$DRY_RUN" = false ]; then
    execute_command \
        "cp '$CONFIG_DIR/clinical_data_standards.yaml' '$CONFIG_DIR/clinical_data_standards.yaml.bak_${TIMESTAMP}'" \
        "Backing up current configuration"
fi

# Deploy new config
execute_command \
    "cp '$SCRIPT_DIR/config/clinical_data_standards.yaml' '$CONFIG_DIR/clinical_data_standards.yaml'" \
    "Deploying clinical_data_standards.yaml"

# Verify vendor_visit was added
if [ "$DRY_RUN" = false ]; then
    if grep -q "vendor_visit:" "$CONFIG_DIR/clinical_data_standards.yaml"; then
        print_success "Configuration updated successfully"
    else
        print_warning "Configuration may not have updated correctly"
    fi
fi

##############################################################################
# Step 6: Deploy Databricks Notebooks
##############################################################################

if [ -n "$DATABRICKS_PATH" ]; then
    print_header "Step 6: Deploying Databricks Notebooks"
    
    # Deploy visits processor
    execute_command \
        "databricks workspace import '$SCRIPT_DIR/databricks/notebooks/nb_visits_activities_processor.ipynb' '$DATABRICKS_PATH/notebooks/data_engineering/clinical_data_standards/jobs/nb_visits_activities_processor' --language PYTHON --format JUPYTER --overwrite" \
        "Deploying nb_visits_activities_processor.ipynb"
    
    # Deploy version approve (updated)
    execute_command \
        "databricks workspace import '$SCRIPT_DIR/databricks/notebooks/nb_version_approve_dta.ipynb' '$DATABRICKS_PATH/notebooks/data_engineering/common/nb_version_approve_dta' --language PYTHON --format JUPYTER --overwrite" \
        "Deploying nb_version_approve_dta.ipynb (updated)"
    
    # Deploy test notebook
    execute_command \
        "databricks workspace import '$SCRIPT_DIR/databricks/notebooks/nb_test_visits_activities_standalone.ipynb' '$DATABRICKS_PATH/notebooks/data_engineering/test/jobs/nb_test_visits_activities_standalone' --language PYTHON --format JUPYTER --overwrite" \
        "Deploying nb_test_visits_activities_standalone.ipynb"
    
    print_success "Databricks notebooks deployed successfully"
else
    print_header "Step 6: Skipping Databricks Notebooks (--databricks-path not specified)"
    print_info "To deploy notebooks manually:"
    print_info "  databricks workspace import databricks/notebooks/nb_visits_activities_processor.ipynb ..."
fi

##############################################################################
# Step 7: Update Databricks Job
##############################################################################

print_header "Step 7: Databricks Job Configuration"

print_info "Job configuration must be updated manually in Databricks UI:"
print_info "  1. Navigate to Databricks Jobs"
print_info "  2. Find 'job_tsdta_processor' job"
print_info "  3. Click 'Edit' → 'Add Task'"
print_info "  4. Task name: load_visits_activities"
print_info "  5. Notebook: $DATABRICKS_PATH/notebooks/.../nb_visits_activities_processor"
print_info "  6. Depends on: check_documents_found"
print_info "  7. Click 'Save'"

print_warning "Job update not automated - manual step required"

##############################################################################
# Step 8: Restart Flask Application
##############################################################################

print_header "Step 8: Restarting Flask Application"

print_info "Application restart depends on your deployment setup:"
print_info ""
print_info "Option A - Systemd:"
print_info "  sudo systemctl restart clnl-data-std-mgmt-app"
print_info ""
print_info "Option B - Gunicorn:"
print_info "  pkill gunicorn"
print_info "  gunicorn --bind 0.0.0.0:5000 app:app --daemon"
print_info ""
print_info "Option C - Development:"
print_info "  Just restart your Flask server"

if [ "$DRY_RUN" = false ]; then
    read -p "Restart Flask application now? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        # Try systemd first
        if systemctl is-active --quiet clnl-data-std-mgmt-app; then
            execute_command \
                "sudo systemctl restart clnl-data-std-mgmt-app" \
                "Restarting via systemd"
        else
            print_warning "Systemd service not found. Please restart manually."
        fi
    else
        print_warning "Skipped Flask restart. Remember to restart manually!"
    fi
fi

##############################################################################
# Deployment Complete
##############################################################################

print_header "Deployment Complete! 🎉"

echo ""
echo -e "${GREEN}✓ Backend files deployed${NC}"
echo -e "${GREEN}✓ Frontend files deployed${NC}"
echo -e "${GREEN}✓ Configuration updated${NC}"

if [ -n "$DATABRICKS_PATH" ]; then
    echo -e "${GREEN}✓ Databricks notebooks deployed${NC}"
else
    echo -e "${YELLOW}⚠ Databricks notebooks not deployed${NC}"
fi

if [ "$SKIP_PERMISSIONS" = false ] && [ -n "$WAREHOUSE_ID" ]; then
    echo -e "${GREEN}✓ Database permissions applied${NC}"
else
    echo -e "${YELLOW}⚠ Database permissions not applied${NC}"
fi

echo ""
print_header "Next Steps"
echo ""
echo "1. Verify Flask application started successfully:"
echo "   curl http://localhost:5000/health"
echo ""
echo "2. Test UI changes:"
echo "   - Open DTA Viewer → Check Visits accordion"
echo "   - Open DTA Workspace → Check VISITS tab"
echo "   - Clone a DTA → Verify visits are copied"
echo ""
echo "3. Run smoke tests:"
echo "   - Add a visit"
echo "   - Edit a visit"
echo "   - Delete a visit (check soft delete)"
echo "   - Save draft"
echo "   - Clone DTA"
echo ""
echo "4. Monitor logs for errors:"
echo "   tail -f /var/log/clnl-data-std-mgmt-app/app.log"
echo ""
echo "5. Update Databricks job:"
echo "   (See Step 7 output above for manual steps)"
echo ""
echo "6. Run visits processing job:"
echo "   databricks jobs run-now --job-id <job-id>"
echo ""

if [ "$SKIP_BACKUP" = false ] && [ "$DRY_RUN" = false ]; then
    echo "📦 Backup location: $BACKUP_DIR"
    echo "   To rollback: tar -xzf $BACKUP_DIR.tar.gz -C $TARGET_DIR"
    echo ""
fi

if [ "$DRY_RUN" = true ]; then
    echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${YELLOW}  DRY RUN COMPLETE - No changes were made${NC}"
    echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo "To perform actual deployment, run without --dry-run flag"
fi

echo ""
echo "For troubleshooting, see:"
echo "  - README.md (Troubleshooting section)"
echo "  - CHANGELOG.md (Known issues)"
echo ""

exit 0


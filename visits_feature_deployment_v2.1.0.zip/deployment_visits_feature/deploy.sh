#!/bin/bash

###############################################################################
# Visits Feature Deployment Script
# Version: v2.1.0
# Date: 2026-01-29
#
# This script automates the deployment of the Visits feature to the
# Clinical Data Standards DTA application.
#
# Usage:
#   ./deploy.sh --target-dir <path> --databricks-path <path> --warehouse-id <id> [--dry-run]
#
# Example:
#   ./deploy.sh \
#     --target-dir /path/to/apps/clnl-data-std-mgmt-app \
#     --databricks-path /Workspace/Users/xxx/clinical-data-standards \
#     --warehouse-id abc123 \
#     --dry-run
###############################################################################

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Default values
DRY_RUN=false
TARGET_DIR=""
DATABRICKS_PATH=""
WAREHOUSE_ID=""
BACKUP_DIR=""

###############################################################################
# Helper Functions
###############################################################################

print_header() {
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ $1${NC}"
}

###############################################################################
# Parse Arguments
###############################################################################

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --target-dir)
                TARGET_DIR="$2"
                shift 2
                ;;
            --databricks-path)
                DATABRICKS_PATH="$2"
                shift 2
                ;;
            --warehouse-id)
                WAREHOUSE_ID="$2"
                shift 2
                ;;
            --dry-run)
                DRY_RUN=true
                shift
                ;;
            --help)
                show_help
                exit 0
                ;;
            *)
                print_error "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
}

show_help() {
    cat << EOF
Visits Feature Deployment Script

USAGE:
    ./deploy.sh --target-dir <path> --databricks-path <path> --warehouse-id <id> [--dry-run]

OPTIONS:
    --target-dir <path>         Path to Flask application directory
                                Example: /path/to/apps/clnl-data-std-mgmt-app

    --databricks-path <path>    Databricks workspace path
                                Example: /Workspace/Users/xxx/clinical-data-standards

    --warehouse-id <id>         SQL warehouse ID for permissions deployment
                                Example: abc123def456

    --dry-run                   Show what would be done without making changes

    --help                      Show this help message

EXAMPLES:
    # Dry run (test without changes)
    ./deploy.sh \\
      --target-dir /path/to/apps/clnl-data-std-mgmt-app \\
      --databricks-path /Workspace/Users/xxx/clinical-data-standards \\
      --warehouse-id abc123 \\
      --dry-run

    # Actual deployment
    ./deploy.sh \\
      --target-dir /path/to/apps/clnl-data-std-mgmt-app \\
      --databricks-path /Workspace/Users/xxx/clinical-data-standards \\
      --warehouse-id abc123

For more information, see README.md
EOF
}

###############################################################################
# Validation
###############################################################################

validate_args() {
    local errors=0

    if [[ -z "$TARGET_DIR" ]]; then
        print_error "Missing required argument: --target-dir"
        errors=$((errors + 1))
    fi

    if [[ -z "$DATABRICKS_PATH" ]]; then
        print_error "Missing required argument: --databricks-path"
        errors=$((errors + 1))
    fi

    if [[ -z "$WAREHOUSE_ID" ]]; then
        print_error "Missing required argument: --warehouse-id"
        errors=$((errors + 1))
    fi

    if [[ $errors -gt 0 ]]; then
        echo ""
        print_info "Run './deploy.sh --help' for usage information"
        exit 1
    fi

    # Check if target directory exists
    if [[ ! -d "$TARGET_DIR" ]]; then
        print_error "Target directory does not exist: $TARGET_DIR"
        exit 1
    fi

    # Check if databricks CLI is available
    if ! command -v databricks &> /dev/null; then
        print_error "Databricks CLI not found. Please install it first."
        exit 1
    fi

    # Check if we're in the deployment package directory
    if [[ ! -f "$SCRIPT_DIR/README.md" ]] || [[ ! -f "$SCRIPT_DIR/MANIFEST.txt" ]]; then
        print_error "This script must be run from the deployment package directory"
        exit 1
    fi
}

###############################################################################
# Backup
###############################################################################

create_backup() {
    print_header "CREATING BACKUP"

    BACKUP_DIR="$TARGET_DIR/../backup_visits_deployment_$(date +%Y%m%d_%H%M%S)"

    if [[ "$DRY_RUN" == "true" ]]; then
        print_info "DRY RUN: Would create backup at $BACKUP_DIR"
        return
    fi

    mkdir -p "$BACKUP_DIR"/{backend/api,frontend/templates,frontend/static}

    # Backup backend files
    if [[ -f "$TARGET_DIR/app.py" ]]; then
        cp "$TARGET_DIR/app.py" "$BACKUP_DIR/backend/"
        print_success "Backed up app.py"
    fi

    if [[ -f "$TARGET_DIR/api/dta_api.py" ]]; then
        cp "$TARGET_DIR/api/dta_api.py" "$BACKUP_DIR/backend/api/"
        print_success "Backed up dta_api.py"
    fi

    if [[ -f "$TARGET_DIR/api/activity_log_api.py" ]]; then
        cp "$TARGET_DIR/api/activity_log_api.py" "$BACKUP_DIR/backend/api/"
        print_success "Backed up activity_log_api.py"
    fi

    # Backup frontend templates
    for template in workspace.html view.html dta_search.html configure_dta.html approvals.html; do
        if [[ -f "$TARGET_DIR/templates/$template" ]]; then
            cp "$TARGET_DIR/templates/$template" "$BACKUP_DIR/frontend/templates/"
            print_success "Backed up $template"
        fi
    done

    # Backup static files
    for static_file in script.js styles.css; do
        if [[ -f "$TARGET_DIR/static/$static_file" ]]; then
            cp "$TARGET_DIR/static/$static_file" "$BACKUP_DIR/frontend/static/"
            print_success "Backed up $static_file"
        fi
    done

    print_success "Backup created at: $BACKUP_DIR"
}

###############################################################################
# Deploy Backend
###############################################################################

deploy_backend() {
    print_header "DEPLOYING BACKEND FILES"

    if [[ "$DRY_RUN" == "true" ]]; then
        print_info "DRY RUN: Would copy backend files to $TARGET_DIR"
        return
    fi

    # Copy app.py
    cp "$SCRIPT_DIR/backend/app.py" "$TARGET_DIR/"
    print_success "Deployed app.py"

    # Copy API files
    cp "$SCRIPT_DIR/backend/api/dta_api.py" "$TARGET_DIR/api/"
    print_success "Deployed dta_api.py"

    cp "$SCRIPT_DIR/backend/api/activity_log_api.py" "$TARGET_DIR/api/"
    print_success "Deployed activity_log_api.py"
}

###############################################################################
# Deploy Frontend
###############################################################################

deploy_frontend() {
    print_header "DEPLOYING FRONTEND FILES"

    if [[ "$DRY_RUN" == "true" ]]; then
        print_info "DRY RUN: Would copy frontend files to $TARGET_DIR"
        return
    fi

    # Copy templates
    cp "$SCRIPT_DIR/frontend/templates/"*.html "$TARGET_DIR/templates/"
    print_success "Deployed templates"

    # Copy static files
    cp "$SCRIPT_DIR/frontend/static/script.js" "$TARGET_DIR/static/"
    print_success "Deployed script.js"

    cp "$SCRIPT_DIR/frontend/static/styles.css" "$TARGET_DIR/static/"
    print_success "Deployed styles.css"
}

###############################################################################
# Deploy Databricks
###############################################################################

deploy_databricks() {
    print_header "DEPLOYING DATABRICKS FILES"

    if [[ "$DRY_RUN" == "true" ]]; then
        print_info "DRY RUN: Would deploy notebooks to Databricks"
        return
    fi

    # Deploy nb_visits_activities_processor.ipynb
    databricks workspace import "$SCRIPT_DIR/databricks/notebooks/nb_visits_activities_processor.ipynb" \
        "$DATABRICKS_PATH/notebooks/data_engineering/clinical_data_standards/jobs/nb_visits_activities_processor.ipynb" \
        --format JUPYTER --overwrite
    print_success "Deployed nb_visits_activities_processor.ipynb"

    # Deploy nb_test_visits_activities_standalone.ipynb
    databricks workspace import "$SCRIPT_DIR/databricks/notebooks/nb_test_visits_activities_standalone.ipynb" \
        "$DATABRICKS_PATH/notebooks/data_engineering/test/jobs/nb_test_visits_activities_standalone.ipynb" \
        --format JUPYTER --overwrite
    print_success "Deployed nb_test_visits_activities_standalone.ipynb"

    # Deploy nb_version_approve_dta.ipynb
    databricks workspace import "$SCRIPT_DIR/databricks/notebooks/nb_version_approve_dta.ipynb" \
        "$DATABRICKS_PATH/notebooks/data_engineering/common/nb_version_approve_dta.ipynb" \
        --format JUPYTER --overwrite
    print_success "Deployed nb_version_approve_dta.ipynb"

    print_warning "Job configuration must be updated manually in Databricks UI"
    print_info "See README.md Step 7 for instructions"
}

###############################################################################
# Deploy Configuration
###############################################################################

deploy_configuration() {
    print_header "DEPLOYING CONFIGURATION"

    if [[ "$DRY_RUN" == "true" ]]; then
        print_info "DRY RUN: Would deploy configuration files"
        return
    fi

    # Deploy permissions
    databricks sql execute \
        --warehouse-id "$WAREHOUSE_ID" \
        --file "$SCRIPT_DIR/config/setup_cdm_app_permissions.sql"
    print_success "Deployed database permissions"

    # Note: clinical_data_standards.yaml should be reviewed manually
    print_warning "Review and update config/clinical_data_standards.yaml manually"
    print_info "See CHANGELOG.md for required configuration changes"
}

###############################################################################
# Verification
###############################################################################

verify_deployment() {
    print_header "POST-DEPLOYMENT VERIFICATION"

    if [[ "$DRY_RUN" == "true" ]]; then
        print_info "DRY RUN: Skipping verification"
        return
    fi

    # Check if files exist
    local all_good=true

    if [[ ! -f "$TARGET_DIR/app.py" ]]; then
        print_error "app.py not found"
        all_good=false
    fi

    if [[ ! -f "$TARGET_DIR/api/dta_api.py" ]]; then
        print_error "dta_api.py not found"
        all_good=false
    fi

    if [[ ! -f "$TARGET_DIR/templates/workspace.html" ]]; then
        print_error "workspace.html not found"
        all_good=false
    fi

    if $all_good; then
        print_success "All files deployed successfully"
    else
        print_error "Some files are missing. Check deployment logs."
        exit 1
    fi
}

###############################################################################
# Main
###############################################################################

main() {
    clear
    print_header "VISITS FEATURE DEPLOYMENT - v2.1.0"

    parse_args "$@"
    validate_args

    if [[ "$DRY_RUN" == "true" ]]; then
        print_warning "DRY RUN MODE - No changes will be made"
        echo ""
    fi

    # Show configuration
    print_info "Configuration:"
    echo "  Target Directory:    $TARGET_DIR"
    echo "  Databricks Path:     $DATABRICKS_PATH"
    echo "  Warehouse ID:        $WAREHOUSE_ID"
    echo "  Dry Run:             $DRY_RUN"
    echo ""

    # Confirmation
    if [[ "$DRY_RUN" == "false" ]]; then
        read -p "Proceed with deployment? (yes/no): " confirmation
        if [[ "$confirmation" != "yes" ]]; then
            print_info "Deployment cancelled"
            exit 0
        fi
        echo ""
    fi

    # Execute deployment
    create_backup
    deploy_backend
    deploy_frontend
    deploy_databricks
    deploy_configuration
    verify_deployment

    # Summary
    print_header "DEPLOYMENT COMPLETE"

    if [[ "$DRY_RUN" == "true" ]]; then
        print_info "Dry run completed. No changes were made."
        print_info "Run without --dry-run to execute actual deployment."
    else
        print_success "Visits feature deployed successfully!"
        echo ""
        print_info "Next steps:"
        echo "  1. Update Databricks job configuration (see README.md Step 7)"
        echo "  2. Restart Flask application"
        echo "  3. Run post-deployment verification (see README.md)"
        echo ""
        print_info "Backup location: $BACKUP_DIR"
        echo ""
        print_info "For verification steps, see README.md → Post-Deployment Verification"
    fi
}

# Run main function
main "$@"

# Visits Feature Deployment Package

**Version:** v2.1.0  
**Date:** January 29, 2026  
**Feature:** Complete Visits & Timepoints Management for DTA Application

---

## 📋 Overview

This deployment package includes all files needed to add complete Visits functionality to the Clinical Data Standards DTA application. The feature enables:

- ✅ Viewing vendor-specific visits in DTA Viewer
- ✅ Editing visits in DTA Configuration workspace
- ✅ Cloning visits when creating draft DTAs
- ✅ Deleting/restoring visits (soft delete with undo)
- ✅ Processing visits from Excel sheets (historical data ingestion)
- ✅ Full audit trail and versioning for visits
- ✅ Approval workflow integration

---

## 📦 Package Contents

```
deployment_visits_feature/
├── README.md                           (this file)
├── CHANGELOG.md                        (detailed change log)
├── deploy.sh                           (automated deployment script)
│
├── backend/                            (Flask application files)
│   ├── app.py
│   └── api/
│       ├── dta_api.py
│       └── activity_log_api.py
│
├── frontend/                           (UI templates and assets)
│   ├── templates/
│   │   ├── workspace.html
│   │   ├── view.html
│   │   ├── dta_search.html
│   │   ├── configure_dta.html
│   │   └── approvals.html
│   └── static/
│       ├── script.js
│       └── styles.css
│
├── databricks/                         (Databricks workspace files)
│   ├── notebooks/
│   │   ├── nb_visits_activities_processor.ipynb
│   │   ├── nb_test_visits_activities_standalone.ipynb
│   │   └── nb_version_approve_dta.ipynb
│   └── jobs/
│       └── job_tsdta_processor.job.yml
│
├── config/                             (Configuration and SQL)
│   ├── clinical_data_standards.yaml
│   └── setup_cdm_app_permissions.sql
│
└── docs/                               (Documentation)
    └── 04_versioning_design.readme.md
```

---

## 🔧 Prerequisites

### System Requirements
- **Python:** 3.9 or higher
- **Flask:** 2.0 or higher
- **Databricks Runtime:** 13.3 LTS or higher
- **Delta Lake:** Enabled
- **Databricks CLI:** Installed and configured

### Access Requirements
- Database admin access to run SQL permissions
- Write access to Flask application directory
- Write access to Databricks workspace
- Permission to deploy Databricks jobs

### Dependencies
All required Python packages are already in your environment. No additional installations needed.

---

## 🚀 Deployment Steps

### Step 1: Backup Current Environment

```bash
# Backup Flask application
cd /path/to/apps/clnl-data-std-mgmt-app
tar -czf backup_$(date +%Y%m%d_%H%M%S).tar.gz app.py api/ templates/ static/

# Backup Databricks notebooks (use Databricks CLI or export from UI)
databricks workspace export_dir /path/to/notebooks ./backup_notebooks
```

### Step 2: Apply Database Permissions (CRITICAL - Do First!)

```bash
# Connect to your Databricks SQL warehouse
cd deployment_visits_feature/config

# Execute permissions SQL
databricks sql execute \
  --file setup_cdm_app_permissions.sql \
  --warehouse-id <your-warehouse-id>

# Verify permissions were added
databricks sql execute \
  --query "SELECT * FROM cdm_app.gold_md.cdm_app_permission WHERE permission_name = 'action_delete_library_item'" \
  --warehouse-id <your-warehouse-id>
```

**Expected output:** Should return 1 row with permission details.

### Step 3: Deploy Backend Files

```bash
cd deployment_visits_feature

# Copy backend files
cp backend/app.py /path/to/apps/clnl-data-std-mgmt-app/
cp backend/api/dta_api.py /path/to/apps/clnl-data-std-mgmt-app/api/
cp backend/api/activity_log_api.py /path/to/apps/clnl-data-std-mgmt-app/api/

# Verify files were copied
ls -lh /path/to/apps/clnl-data-std-mgmt-app/app.py
ls -lh /path/to/apps/clnl-data-std-mgmt-app/api/{dta_api,activity_log_api}.py
```

### Step 4: Deploy Frontend Files

```bash
# Copy templates
cp frontend/templates/*.html /path/to/apps/clnl-data-std-mgmt-app/templates/

# Copy static assets
cp frontend/static/script.js /path/to/apps/clnl-data-std-mgmt-app/static/
cp frontend/static/styles.css /path/to/apps/clnl-data-std-mgmt-app/static/

# Verify files were copied
ls -lh /path/to/apps/clnl-data-std-mgmt-app/templates/{workspace,view}.html
ls -lh /path/to/apps/clnl-data-std-mgmt-app/static/{script.js,styles.css}
```

### Step 5: Update Configuration

```bash
# Backup current config
cp /path/to/config/clinical_data_standards.yaml \
   /path/to/config/clinical_data_standards.yaml.bak

# Deploy new config
cp config/clinical_data_standards.yaml /path/to/config/

# Verify the vendor_visit section was added
grep -A 5 "vendor_visit:" /path/to/config/clinical_data_standards.yaml
```

**Expected output:** Should show vendor_visit configuration block.

### Step 6: Deploy Databricks Notebooks

```bash
# Upload notebooks to Databricks workspace
databricks workspace import databricks/notebooks/nb_visits_activities_processor.ipynb \
  /Workspace/path/to/notebooks/jobs/nb_visits_activities_processor \
  --language PYTHON \
  --format JUPYTER

databricks workspace import databricks/notebooks/nb_version_approve_dta.ipynb \
  /Workspace/path/to/notebooks/common/nb_version_approve_dta \
  --language PYTHON \
  --format JUPYTER

databricks workspace import databricks/notebooks/nb_test_visits_activities_standalone.ipynb \
  /Workspace/path/to/notebooks/test/nb_test_visits_activities_standalone \
  --language PYTHON \
  --format JUPYTER

# Verify notebooks were uploaded
databricks workspace list /Workspace/path/to/notebooks/jobs/
```

### Step 7: Update Databricks Job Configuration

```bash
# Update the job configuration
# Option A: Use Databricks CLI
databricks jobs update <job-id> --json-file databricks/jobs/job_tsdta_processor.job.yml

# Option B: Use UI
# 1. Go to Databricks Jobs UI
# 2. Find "job_tsdta_processor" job
# 3. Click "Edit"
# 4. Add new task "load_visits_activities" with notebook path
# 5. Set dependencies: depends on "check_documents_found"
# 6. Save
```

### Step 8: Restart Flask Application

```bash
# Method depends on your deployment setup

# If using systemd:
sudo systemctl restart clnl-data-std-mgmt-app

# If using gunicorn:
pkill gunicorn
gunicorn --bind 0.0.0.0:5000 app:app

# If development server:
# Just restart your Flask server
```

---

## ✅ Post-Deployment Verification

### 1. Check Flask Application

```bash
# Test that Flask starts without errors
curl http://localhost:5000/health

# Expected: 200 OK
```

### 2. Verify UI Changes

**DTA Viewer:**
1. Navigate to http://localhost:5000/dta/search
2. Click on any approved DTA
3. **✓ Check:** "Visits" accordion should appear
4. **✓ Check:** Clicking accordion should show visits table
5. **✓ Check:** Visit count badge should display

**DTA Configuration:**
1. Create a draft or edit existing draft
2. **✓ Check:** "VISITS" tab should appear in workspace
3. **✓ Check:** Table should show visits with proper styling (matches TV table)
4. **✓ Check:** Edit, Delete, Add Visit buttons should work

**Clone Operation:**
1. Clone an existing DTA
2. **✓ Check:** Clone modal should show "Copying visits..." step (step 7)
3. **✓ Check:** Success message should include visits count
4. **✓ Check:** Cloned DTA should have visits populated

### 3. Test Databricks Job

```bash
# Run the tsdta_processor job
databricks jobs run-now --job-id <job-id>

# Check run status
databricks runs list --job-id <job-id> --limit 1

# Verify visits table was created
databricks sql execute \
  --query "SELECT COUNT(*) as cnt FROM aira_test.silver_md.md_vendor_visit_draft" \
  --warehouse-id <your-warehouse-id>
```

**Expected:** Should return row count > 0 if Excel data has visits.

### 4. Test CRUD Operations

**Test Add:**
1. Open a draft DTA workspace
2. Click VISITS tab
3. Click "+ Add Visit"
4. Enter: Visit Name="Week 1", Visit Number=1
5. Save draft
6. **✓ Check:** Visit appears in table

**Test Edit:**
1. Click Edit button on a visit row
2. Modify visit name
3. Click Save
4. **✓ Check:** Changes persisted

**Test Delete:**
1. Click Delete button on a visit
2. **✓ Check:** No browser confirmation dialog
3. **✓ Check:** Row shows strikethrough with "Undo" button
4. Save draft
5. **✓ Check:** Visit removed from database

**Test Restore:**
1. Click Delete on a visit
2. Click Undo button
3. **✓ Check:** Row restored to normal state

### 5. Verify Permissions

```bash
# Check delete permission exists
databricks sql execute \
  --query "SELECT * FROM cdm_app.gold_md.cdm_app_permission WHERE permission_name = 'action_delete_library_item'" \
  --warehouse-id <your-warehouse-id>

# Check permission is assigned to DAE group
databricks sql execute \
  --query "SELECT * FROM cdm_app.gold_md.cdm_app_user_group_permission WHERE permission_name = 'perm_action_delete_item'" \
  --warehouse-id <your-warehouse-id>
```

---

## 🔄 Rollback Instructions

If you need to rollback the deployment:

```bash
# 1. Restore Flask application from backup
cd /path/to/apps/clnl-data-std-mgmt-app
tar -xzf backup_<timestamp>.tar.gz

# 2. Restore config
cp /path/to/config/clinical_data_standards.yaml.bak \
   /path/to/config/clinical_data_standards.yaml

# 3. Remove Databricks notebooks
databricks workspace delete /Workspace/path/to/notebooks/jobs/nb_visits_activities_processor

# 4. Remove job task (manually in Databricks UI)
# Go to job_tsdta_processor > Edit > Remove "load_visits_activities" task

# 5. Restart Flask
sudo systemctl restart clnl-data-std-mgmt-app

# 6. (Optional) Remove permissions - only if no other features use them
# databricks sql execute --query "DELETE FROM cdm_app.gold_md.cdm_app_permission WHERE permission_name = 'action_delete_library_item'"
```

---

## 🐛 Troubleshooting

### Issue: Flask won't start after deployment

**Error:** `ImportError: cannot import name 'get_vendor_visits_for_dta'`

**Solution:**
```bash
# Verify all API files were copied
ls -l /path/to/apps/clnl-data-std-mgmt-app/api/dta_api.py

# Check file size matches deployment package
wc -l deployment_visits_feature/backend/api/dta_api.py
wc -l /path/to/apps/clnl-data-std-mgmt-app/api/dta_api.py
# Should be the same
```

### Issue: Visits tab doesn't appear in UI

**Solution:**
```bash
# Clear browser cache
# Check that templates were deployed
grep -n "VISITS" /path/to/apps/clnl-data-std-mgmt-app/templates/workspace.html
grep -n "vendor_visits" /path/to/apps/clnl-data-std-mgmt-app/templates/view.html

# Restart Flask to reload templates
sudo systemctl restart clnl-data-std-mgmt-app
```

### Issue: Delete button shows error "invalid library type"

**Solution:**
```bash
# Check that app.py has visits in type_map
grep -A 10 "type_map = {" /path/to/apps/clnl-data-std-mgmt-app/app.py | grep visits

# Expected: 'visits': 'visits'
```

### Issue: Visits job task fails

**Error:** `Table not found: md_vendor_visit_draft`

**Solution:**
```sql
-- The table is created automatically by save_with_audit()
-- But you can create it manually if needed:
CREATE TABLE IF NOT EXISTS aira_test.silver_md.md_vendor_visit_draft (
  vendor_visit_id STRING,
  parent_document_id STRING,
  dta_id STRING,
  trial_id STRING,
  data_stream_type STRING,
  data_provider_name STRING,
  visit_name STRING,
  visit_number INT,
  timepoint STRING,
  timepoint_number INT,
  protocol_visit_id STRING,
  soa_id STRING,
  notes STRING,
  status STRING,
  version STRING,
  version_status STRING,
  is_current_draft BOOLEAN,
  created_by_principal STRING,
  created_ts TIMESTAMP,
  last_updated_by_principal STRING,
  last_updated_ts TIMESTAMP
) USING DELTA;
```

---

## 📞 Support

For issues or questions:
- Check CHANGELOG.md for known issues
- Review logs: `/var/log/clnl-data-std-mgmt-app/app.log`
- Databricks job logs: Databricks UI > Jobs > Runs
- Contact: DTA Development Team

---

## 📚 Additional Documentation

- **Full Feature Documentation:** `docs/04_versioning_design.readme.md`
- **Change Log:** `CHANGELOG.md`
- **Test Notebook:** `databricks/notebooks/nb_test_visits_activities_standalone.ipynb`

---

**Deployment completed successfully? Great! 🎉**

Next steps:
1. Run the smoke tests (see Post-Deployment Verification)
2. Test with real users
3. Monitor logs for any errors
4. Schedule a retrospective to discuss the deployment


# Visits Feature Deployment Guide

**Version**: v2.1.0  
**Date**: 2026-01-29  
**Status**: Ready for Production Deployment

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Package Contents](#package-contents)
3. [Prerequisites](#prerequisites)
4. [Deployment Steps](#deployment-steps)
5. [Post-Deployment Verification](#post-deployment-verification)
6. [Rollback Instructions](#rollback-instructions)
7. [Troubleshooting](#troubleshooting)

---

## 🎯 Overview

This deployment package adds complete **Visits** functionality to the Clinical Data Standards DTA application. It includes:

- ✅ Full CRUD operations (Create, Read, Update, Delete with soft delete)
- ✅ Clone integration (visits automatically cloned with DTAs)
- ✅ Automated Excel parsing for visits data
- ✅ UI enhancements with consistent styling
- ✅ Permission-based delete (DAE users only)
- ✅ Complete audit trail and versioning support
- ✅ 10 bug fixes for improved stability

---

## 📦 Package Contents

### Backend Files (3 files)
- `backend/app.py` - Main Flask application with CRUD endpoints
- `backend/api/dta_api.py` - Data access layer with helper functions
- `backend/api/activity_log_api.py` - Enhanced activity logging

### Frontend Files (7 files)
- `frontend/templates/workspace.html` - DTA workspace with VISITS tab
- `frontend/templates/view.html` - DTA viewer with Visits accordion
- `frontend/templates/dta_search.html` - Updated clone modal
- `frontend/templates/configure_dta.html` - Updated clone modal
- `frontend/templates/approvals.html` - Approved_by field support
- `frontend/static/script.js` - JavaScript CRUD operations
- `frontend/static/styles.css` - CSS styling

### Databricks Files (4 files)
- `databricks/notebooks/nb_visits_activities_processor.ipynb` - **NEW** Visits parser
- `databricks/notebooks/nb_test_visits_activities_standalone.ipynb` - **NEW** Test suite
- `databricks/notebooks/nb_version_approve_dta.ipynb` - **UPDATED** With visits
- `databricks/jobs/job_tsdta_processor.job.yml` - Updated with visits task

### Configuration Files (2 files)
- `config/clinical_data_standards.yaml` - Vendor_visit configuration
- `config/setup_cdm_app_permissions.sql` - Database permissions

### Documentation (1 file)
- `docs/04_versioning_design.readme.md` - Updated design documentation

### Deployment Files (4 files)
- `README.md` - This file
- `CHANGELOG.md` - Complete change history
- `MANIFEST.txt` - File inventory
- `deploy.sh` - Automated deployment script

---

## ✅ Prerequisites

Before deploying, ensure you have:

1. **Access & Permissions**:
   - Database admin access for permissions
   - Write access to Flask application directory
   - Write access to Databricks workspace
   - Databricks CLI installed and configured

2. **Environment**:
   - Python 3.8+ for Flask app
   - Databricks Runtime 13.3+ LTS
   - Flask app running on port 8050 (or your configured port)

3. **Backups** (Recommended):
   - Backup current Flask application directory
   - Backup Databricks notebooks (automatic versioning available)
   - Backup database (if needed)

4. **Information Required**:
   - Target Flask app directory path (e.g., `/path/to/apps/clnl-data-std-mgmt-app`)
   - Databricks workspace path (e.g., `/Workspace/Users/xxx/clinical-data-standards`)
   - SQL warehouse ID for permissions deployment

---

## 🚀 Deployment Steps

### Step 1: Extract Package

```bash
unzip visits_feature_deployment_v2.1.0.zip
cd deployment_visits_feature
```

### Step 2: Review Documentation

```bash
cat README.md          # This file
cat CHANGELOG.md       # All changes
cat MANIFEST.txt       # File inventory
```

### Step 3: Run Dry-Run (Recommended)

Test the deployment without making changes:

```bash
./deploy.sh \
  --target-dir /path/to/apps/clnl-data-std-mgmt-app \
  --databricks-path /Workspace/Users/xxx/clinical-data-standards \
  --warehouse-id <your-warehouse-id> \
  --dry-run
```

### Step 4: Deploy Backend Files

```bash
# Copy backend files
cp backend/app.py /path/to/apps/clnl-data-std-mgmt-app/
cp backend/api/dta_api.py /path/to/apps/clnl-data-std-mgmt-app/api/
cp backend/api/activity_log_api.py /path/to/apps/clnl-data-std-mgmt-app/api/
```

### Step 5: Deploy Frontend Files

```bash
# Copy templates
cp frontend/templates/*.html /path/to/apps/clnl-data-std-mgmt-app/templates/

# Copy static files
cp frontend/static/script.js /path/to/apps/clnl-data-std-mgmt-app/static/
cp frontend/static/styles.css /path/to/apps/clnl-data-std-mgmt-app/static/
```

### Step 6: Deploy Databricks Files

```bash
# Using Databricks CLI
databricks workspace import databricks/notebooks/nb_visits_activities_processor.ipynb \
  /Workspace/Users/xxx/clinical-data-standards/notebooks/data_engineering/clinical_data_standards/jobs/ \
  --format JUPYTER --overwrite

databricks workspace import databricks/notebooks/nb_test_visits_activities_standalone.ipynb \
  /Workspace/Users/xxx/clinical-data-standards/notebooks/data_engineering/test/jobs/ \
  --format JUPYTER --overwrite

databricks workspace import databricks/notebooks/nb_version_approve_dta.ipynb \
  /Workspace/Users/xxx/clinical-data-standards/notebooks/data_engineering/common/ \
  --format JUPYTER --overwrite
```

### Step 7: Update Databricks Job Configuration

**IMPORTANT**: This must be done manually in the Databricks UI.

1. Go to Databricks UI → Workflows → `job_tsdta_processor`
2. Click "Edit"
3. Add a new task after `check_documents_found`:
   - **Task Key**: `load_visits_activities`
   - **Type**: Notebook
   - **Notebook Path**: `notebooks/data_engineering/clinical_data_standards/jobs/nb_visits_activities_processor`
   - **Depends On**: `check_documents_found`
   - **Parameters**: (inherit from job)
4. Save the job

Alternatively, use the job YAML file:

```bash
# Update job configuration via CLI (if supported in your environment)
databricks jobs update <job-id> --json-file databricks/jobs/job_tsdta_processor.job.yml
```

### Step 8: Deploy Configuration Files

```bash
# Copy configuration
cp config/clinical_data_standards.yaml /path/to/config/

# Deploy database permissions
databricks sql execute \
  --warehouse-id <your-warehouse-id> \
  --file config/setup_cdm_app_permissions.sql
```

### Step 9: Restart Flask Application

```bash
# Find Flask process
ps aux | grep clnl-data-std-mgmt-app

# Restart (method depends on your deployment)
# Option 1: systemd
sudo systemctl restart clnl-data-std-mgmt-app

# Option 2: supervisor
supervisorctl restart clnl-data-std-mgmt-app

# Option 3: manual restart
kill -HUP <flask-pid>
```

### Step 10: Deploy Documentation (Optional)

```bash
cp docs/04_versioning_design.readme.md /path/to/docs/
```

---

## ✅ Post-Deployment Verification

### 1. Backend Verification

```bash
# Check Flask app is running
curl http://localhost:8050/health

# Check logs for errors
tail -f /var/log/clnl-data-std-mgmt-app/app.log
```

### 2. Frontend Verification

Open the application in a browser and test:

- [ ] **DTA Viewer**: Open any DTA → Check "Visits" accordion is visible
- [ ] **DTA Viewer**: Accordion shows correct count
- [ ] **DTA Viewer**: Can expand/collapse accordion
- [ ] **Workspace**: Open edit mode → Check "VISITS" tab is visible
- [ ] **Workspace**: Can view existing visits
- [ ] **Clone Modal**: Check "Copying visits..." step appears

### 3. CRUD Operations Verification

Test all operations:

- [ ] **Create**: Add a new visit → Save → Verify it appears
- [ ] **Edit**: Click edit icon → Modify → Save → Verify changes
- [ ] **Delete**: Click delete icon → Verify soft delete (no browser dialog)
- [ ] **Restore**: Click undo → Verify visit is restored

### 4. Clone Verification

- [ ] Clone a DTA with visits
- [ ] Verify modal shows "Copying visits..." step
- [ ] Verify success message includes visits count
- [ ] Open cloned DTA → Verify visits were copied

### 5. Databricks Verification

- [ ] Run test notebook: `nb_test_visits_activities_standalone.ipynb`
- [ ] Check job `job_tsdta_processor` includes `load_visits_activities` task
- [ ] Test upload a DTA Excel with SOA sheet
- [ ] Verify visits are parsed and loaded correctly

### 6. Permissions Verification

- [ ] Login as DAE user → Verify can delete visits
- [ ] Login as non-DAE user → Verify delete button is disabled or hidden
- [ ] Check activity log captures all visit operations

---

## 🔄 Rollback Instructions

If issues occur, follow these steps:

### 1. Stop Flask Application

```bash
sudo systemctl stop clnl-data-std-mgmt-app
```

### 2. Restore Backend Files

```bash
# Restore from backup
cp /path/to/backup/app.py /path/to/apps/clnl-data-std-mgmt-app/
cp /path/to/backup/api/dta_api.py /path/to/apps/clnl-data-std-mgmt-app/api/
cp /path/to/backup/api/activity_log_api.py /path/to/apps/clnl-data-std-mgmt-app/api/
```

### 3. Restore Frontend Files

```bash
# Restore templates
cp /path/to/backup/templates/*.html /path/to/apps/clnl-data-std-mgmt-app/templates/

# Restore static files
cp /path/to/backup/static/script.js /path/to/apps/clnl-data-std-mgmt-app/static/
cp /path/to/backup/static/styles.css /path/to/apps/clnl-data-std-mgmt-app/static/
```

### 4. Revert Databricks Job

1. Go to Databricks UI → Workflows → `job_tsdta_processor`
2. Remove the `load_visits_activities` task
3. Save the job

### 5. Restart Flask Application

```bash
sudo systemctl start clnl-data-std-mgmt-app
```

### 6. Verify Rollback

- Test application functionality
- Check logs for errors
- Verify application is stable

---

## 🔧 Troubleshooting

### Issue 1: "Failed to delete: invalid library type"

**Cause**: Permissions not deployed or Flask not restarted.

**Solution**:
```bash
# Deploy permissions
databricks sql execute --warehouse-id <id> --file config/setup_cdm_app_permissions.sql

# Restart Flask
sudo systemctl restart clnl-data-std-mgmt-app
```

### Issue 2: Visits count shows 0

**Cause**: JavaScript filter issue or data not loaded.

**Solution**:
- Check browser console for errors
- Verify data is loaded: Open Network tab → Check API response
- Clear browser cache and reload

### Issue 3: Clone modal doesn't show "Copying visits..."

**Cause**: Frontend template not updated.

**Solution**:
```bash
# Re-copy templates
cp frontend/templates/dta_search.html /path/to/apps/clnl-data-std-mgmt-app/templates/
cp frontend/templates/configure_dta.html /path/to/apps/clnl-data-std-mgmt-app/templates/

# Clear browser cache
```

### Issue 4: Visits not parsed from Excel

**Cause**: Notebook not deployed or job not updated.

**Solution**:
1. Verify notebook is deployed
2. Check job configuration includes `load_visits_activities` task
3. Run test notebook to diagnose
4. Check Databricks logs for errors

### Issue 5: Styling broken in Visits tab

**Cause**: CSS not deployed or cached.

**Solution**:
```bash
# Re-copy CSS
cp frontend/static/styles.css /path/to/apps/clnl-data-std-mgmt-app/static/

# Clear browser cache
# Hard reload: Cmd+Shift+R (Mac) or Ctrl+Shift+R (Windows)
```

---

## 📞 Support

For issues or questions:

1. Check **CHANGELOG.md** for known issues
2. Review **MANIFEST.txt** to ensure all files are deployed
3. Check application logs: `/var/log/clnl-data-std-mgmt-app/app.log`
4. Check Databricks logs: Databricks UI → Jobs → Run History
5. Contact the Clinical Data Standards development team

---

## 📊 Impact Summary

**Performance**:
- Clone operation: +15 seconds (acceptable)
- UI page load: +0.2 seconds (minimal)

**Features Added**:
- Complete visits CRUD operations
- Automated visits parsing
- Clone integration
- UI enhancements
- 10 bug fixes

**Security**:
- Permission-based delete
- Full audit trail
- No breaking changes

---

## ✅ Success Criteria

Deployment is successful when:

1. ✅ All verification tests pass
2. ✅ No errors in Flask logs
3. ✅ No errors in Databricks logs
4. ✅ Users can perform all CRUD operations
5. ✅ Clone operation works with visits
6. ✅ Permissions are properly enforced

---

**Deployed**: 2026-01-29  
**Version**: v2.1.0  
**Team**: Clinical Data Standards Development

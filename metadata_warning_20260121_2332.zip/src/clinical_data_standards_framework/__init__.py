"""
clinical_data_standards_framework

Data engineering framework for clinical-data-standards
Organization: JNJ
"""

__version__ = "0.0.1"
__author__ = "JNJ"

from .utils import *
from .excel_utils import *
from .config_manager import *
from .versioning import *

# TOC utilities are optional - only load if PDF libraries are available
# These require: pip install PyMuPDF pdfminer.six PyPDF2
try:
    from .toc_utils import *
    _toc_utils_available = True
except ImportError:
    _toc_utils_available = False
    # Define placeholder for Section to avoid import errors
    Section = None
    BaseTOCExtractor = None
    PDFTOCExtractor = None
    get_toc_extractor = None
    extract_pdf_sections = None
    extract_pdf_section_to_file = None

__all__ = [
    # Core utilities
    "get_spark_session",
    "get_catalog_config",
    "setup_logging",
    "add_audit_columns",
    "save_with_audit",
    "compute_definition_hash",
    "compute_definition_hash_spark",
    
    # Document processing
    "save_document_with_metadata",
    "extract_document_tags",
    "check_existing_file_version",
    
    # Configuration management
    "ConfigManager",
    
    # Excel processing utilities
    "get_excel_sheets_schema",
    "categorize_sheet_name",
    "extract_version_history_metadata",
    "get_metadata_warning",
    "build_notes",
    "find_excel_header_row",
    "get_header_filter_patterns",
    "parse_max_length",
    "is_required_field",
    "is_transfer_key_field",
    "get_transfer_metadata_column_map",
    "get_transfer_metadata_flexible_mapper",
    "get_codelist_flexible_mapper",
    
    # Versioning (SCD Type 2)
    "get_version_registry_schema",
    "get_versioning_columns",
    "parse_version",
    "build_version",
    "get_dta_number",
    "get_next_draft_number",
    "get_next_dta_major_version",
    "create_library_branch",
    "save_dta_draft",
    "approve_dta_version",
    "promote_to_template",
    "merge_dtas_to_template",
    "get_version_data",
    "get_version",
    "get_dta_version",
    "get_dta_version_history",
    "get_all_versions",
    "initialize_version",
    
    # TOC Extraction utilities
    "Section",
    "BaseTOCExtractor",
    "PDFTOCExtractor",
    "get_toc_extractor",
    "extract_pdf_sections",
    "extract_pdf_section_to_file"
]


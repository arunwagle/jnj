"""
DTA API - Provides endpoints for DTA creation and search functionality.
Integrates with Databricks SQL to fetch real data from Unity Catalog tables.
"""

from flask import Blueprint, jsonify, request
from datetime import datetime, timedelta
import os
import json

# Import SQL client for database queries
from api.databricks_client import DatabricksSQLClient

# Import activity logging functions
from api.activity_log_api import log_bulk_insert, log_version_event

dta_bp = Blueprint('dta_api', __name__, url_prefix='/api/dta')


# ============================================================================
# DATABASE CONFIGURATION
# ============================================================================

def _get_db_config():
    """Get database configuration from environment variables"""
    return {
        "catalog": os.environ.get("CATALOG_NAME", "aira_test"),
        "gold_schema": os.environ.get("GOLD_SCHEMA", "gold_md"),
        "silver_schema": os.environ.get("SILVER_SCHEMA", "silver_md"),
        "warehouse_id": os.environ.get("DATABRICKS_WAREHOUSE_ID")
    }


def _get_sql_client():
    """Get SQL client instance - raises if not configured"""
    config = _get_db_config()
    if not config["warehouse_id"]:
        raise RuntimeError(
            "DATABRICKS_WAREHOUSE_ID environment variable not set. "
            "This app must run on Databricks with proper configuration in app.yaml."
        )
    return DatabricksSQLClient(config["warehouse_id"])


# ============================================================================
# DRAFT DTA QUERIES
# ============================================================================

def get_user_drafts(limit: int = 50):
    """
    Get all draft DTAs for the current user.
    Queries the DTA table for DTAs with workflow_state = 'NOT_STARTED' or status containing 'DRAFT'.
    
    Args:
        limit: Maximum number of drafts to return
    
    Returns:
        List of draft DTA records with basic info
    """
    config = _get_db_config()
    table = f"{config['catalog']}.{config['gold_schema']}.dta"
    
    query = f"""
        SELECT 
            dta_id,
            dta_number,
            trial_id,
            data_stream_type as data_stream,
            data_provider_name as vendor,
            status,
            workflow_state,
            version,
            current_draft_version,
            notes,
            created_by_principal,
            created_ts,
            last_updated_ts
        FROM {table}
        WHERE workflow_state = 'NOT_STARTED' 
           OR workflow_state = 'IN_PROGRESS'
           OR status LIKE '%DRAFT%'
        ORDER BY last_updated_ts DESC
        LIMIT {limit}
    """
    
    print(f"=" * 60)
    print(f"DEBUG: Querying user drafts")
    print(f"DEBUG: Query: {query[:200]}...")
    print(f"=" * 60)
    
    try:
        client = _get_sql_client()
        results = client.execute_query(query)
        
        drafts = []
        if results:
            for row in results:
                # Format timestamps
                created_ts = row.get("created_ts", "")
                last_updated_ts = row.get("last_updated_ts", "")
                
                try:
                    if last_updated_ts:
                        updated_date = datetime.fromisoformat(str(last_updated_ts).replace('Z', '+00:00'))
                        updated_display = updated_date.strftime("%Y-%m-%d %H:%M")
                    else:
                        updated_display = "N/A"
                except:
                    updated_display = str(last_updated_ts)[:16] if last_updated_ts else "N/A"
                
                drafts.append({
                    "dta_id": str(row.get("dta_id", "")),
                    "dta_number": str(row.get("dta_number", "")),
                    "trial_id": str(row.get("trial_id", "")),
                    "vendor": str(row.get("vendor", "")),
                    "data_stream": str(row.get("data_stream", "")),
                    "status": str(row.get("status", "")),
                    "workflow_state": str(row.get("workflow_state", "")),
                    "version": str(row.get("current_draft_version") or row.get("version") or ""),
                    "notes": str(row.get("notes", "") or ""),
                    "created_by": str(row.get("created_by_principal", "")),
                    "last_updated_ts": updated_display
                })
        
        print(f"DEBUG: Found {len(drafts)} draft DTAs")
        return drafts
        
    except Exception as e:
        print(f"ERROR: Failed to query drafts: {e}")
        import traceback
        traceback.print_exc()
        return []


# ============================================================================
# LIBRARY VERSION QUERIES
# ============================================================================

def get_all_versions():
    """
    Get all DTA_TEMPLATE versions grouped by library_type.
    Used for the library selection panel in DTA creation.
    
    Returns:
        Dict with library versions per entity type
    """
    config = _get_db_config()
    table = f"{config['catalog']}.{config['gold_schema']}.md_version_registry"
    
    library_types = [
        'transfer_variables', 'codelists', 'test_concepts',
        'operational_agreements', 'visits_timepoints', 'data_ingestion_parameters'
    ]
    library_types_str = ", ".join([f"'{t}'" for t in library_types])
    
    query = f"""
        SELECT 
            version,
            library_type,
            version_type,
            record_count,
            status,
            created_by_principal,
            created_ts
        FROM {table}
        WHERE library_type IN ({library_types_str})
          AND status = 'ACTIVE'
          AND version_type = 'DTA_TEMPLATE'
        ORDER BY library_type, created_ts DESC
    """
    
    print(f"DEBUG: Querying library versions for DTA creation")
    
    client = _get_sql_client()
    results = client.execute_query(query)
    
    # Group by library_type
    versions_by_type = {}
    for row in results:
        lib_type = row.get("library_type")
        if lib_type not in versions_by_type:
            versions_by_type[lib_type] = []
        versions_by_type[lib_type].append(row)
    
    return versions_by_type


def format_library_entities_for_selection(versions_by_type: dict) -> list:
    """
    Format library versions for the selection UI.
    
    Args:
        versions_by_type: Dict of library_type -> list of version records
    
    Returns:
        List of entity objects with versions for UI display
    """
    # Define all library types with display info
    library_configs = [
        ("transfer_variables", "TV", "Transfer Variables", "📊"),
        ("codelists", "CL", "Codelists", "📋"),
        ("test_concepts", "TC", "Test Concepts", "🧪"),
        ("operational_agreements", "OA", "Operational Agreements", "📝"),
        ("visits_timepoints", "VT", "Visits & Timepoints", "📅"),
        ("data_ingestion_parameters", "DIP", "Data Ingestion Parameters", "⚙️"),
    ]
    
    entities = []
    for lib_type, code, name, icon in library_configs:
        db_versions = versions_by_type.get(lib_type, [])
        
        versions = []
        for i, v in enumerate(db_versions[:5]):  # Limit to 5 versions
            is_current = (i == 0)
            
            # Format created_ts
            created_ts = v.get("created_ts", "")
            if created_ts:
                try:
                    if isinstance(created_ts, str):
                        dt = datetime.fromisoformat(created_ts.replace("Z", "+00:00"))
                    else:
                        dt = created_ts
                    updated = dt.strftime("%b %d, %Y")
                except:
                    updated = str(created_ts)[:10]
            else:
                updated = "N/A"
            
            versions.append({
                "version": v.get("version", "N/A"),
                "is_current": is_current,
                "record_count": int(v.get("record_count", 0) or 0),
                "updated": updated
            })
        
        entities.append({
            "code": code,
            "library_type": lib_type,
            "name": name,
            "icon": icon,
            "versions": versions,
            "has_data": len(versions) > 0
        })
    
    return entities


# ============================================================================
# DTA SEARCH QUERIES
# ============================================================================

def parse_dta_search_query(q: str) -> dict:
    """
    Parse free-form search query and extract trial, provider, stream filters.
    Supports formats like:
    - "VAC18193" - fuzzy match on all fields
    - "trial = ABC" - specific field match
    - "IQVIA PF" - multiple tokens
    - "trial = ABC and provider = IQVIA"
    
    Args:
        q: Free-text search query
    
    Returns:
        Dict with 'trial', 'provider', 'stream' filter lists
    """
    import re
    
    q_lower = q.lower().strip()
    filters = {
        'trial': [],
        'provider': [],
        'stream': []
    }
    
    # Pattern for "field = value" or "field: value"
    field_patterns = [
        (r'trial\s*(?:id)?\s*[=:]\s*([a-z0-9\-_]+)', 'trial'),
        (r'(?:data\s*)?provider\s*(?:name)?\s*[=:]\s*([a-z0-9\-_]+)', 'provider'),
        (r'(?:data\s*)?stream\s*(?:type)?\s*[=:]\s*([a-z0-9\-_]+)', 'stream'),
        (r'vendor\s*(?:id|name)?\s*[=:]\s*([a-z0-9\-_]+)', 'provider'),  # alias
    ]
    
    for pattern, field in field_patterns:
        matches = re.findall(pattern, q_lower, re.IGNORECASE)
        for match in matches:
            filters[field].append(match.upper())
    
    # If no structured patterns found, treat as tokens for fuzzy search
    if not any(filters.values()):
        # Remove common words and split into tokens
        stop_words = ['and', 'or', 'the', 'id', 'name', 'type', '=', ':']
        tokens = re.findall(r'[a-z0-9\-_]+', q_lower)
        tokens = [t for t in tokens if t not in stop_words and len(t) >= 2]
        
        for token in tokens:
            token_upper = token.upper()
            # Add to all fields for fuzzy matching
            filters['trial'].append(token_upper)
            filters['provider'].append(token_upper)
            filters['stream'].append(token_upper)
    
    return filters


def search_existing_dtas(query: str = None, trial_id: str = None, 
                         data_stream: str = None, provider: str = None, 
                         limit: int = 3) -> list:
    """
    Search for existing approved DTAs based on free-text query or specific filters.
    Uses an optimized single query with LEFT JOIN and pivoted metadata counts.
    
    Args:
        query: Free-text search query (e.g., "VAC18193", "trial = ABC and provider = IQVIA")
        trial_id: Trial ID to search for (partial match) - used if query not provided
        data_stream: Data stream type to filter by - used if query not provided
        provider: Data provider name to filter by - used if query not provided
        limit: Maximum number of results (default 3)
    
    Returns:
        List of matching DTAs with their metadata summaries
    """
    config = _get_db_config()
    dta_table = f"{config['catalog']}.{config['gold_schema']}.dta"
    registry_table = f"{config['catalog']}.{config['gold_schema']}.md_version_registry"
    
    # Parse query if provided, otherwise use individual filters
    if query and query.strip():
        filters = parse_dta_search_query(query)
    else:
        filters = {'trial': [], 'provider': [], 'stream': []}
        if trial_id and trial_id.strip():
            filters['trial'].append(trial_id.strip().upper())
        if provider and provider.strip():
            filters['provider'].append(provider.strip().upper())
        if data_stream and data_stream.strip():
            filters['stream'].append(data_stream.strip().upper())
    
    # Build WHERE clause dynamically
    where_conditions = ["d.workflow_state = 'APPROVED'"]
    
    # Build field conditions - use OR for fuzzy multi-field matching
    field_conditions = []
    
    if filters['trial']:
        trial_conds = [f"UPPER(d.trial_id) LIKE '%{t}%'" for t in filters['trial']]
        field_conditions.append(f"({' OR '.join(trial_conds)})")
    
    if filters['provider']:
        prov_conds = [f"UPPER(d.data_provider_name) LIKE '%{p}%'" for p in filters['provider']]
        field_conditions.append(f"({' OR '.join(prov_conds)})")
    
    if filters['stream']:
        stream_conds = [f"UPPER(d.data_stream_type) LIKE '%{s}%'" for s in filters['stream']]
        field_conditions.append(f"({' OR '.join(stream_conds)})")
    
    # If we have field conditions, combine with OR (for fuzzy multi-field search)
    if field_conditions:
        where_conditions.append(f"({' OR '.join(field_conditions)})")
    
    where_clause = " AND ".join(where_conditions)
    
    # OPTIMIZED: Single query with LEFT JOIN and pivoted metadata counts
    # Status aligns 1:1 between DTA.status and md_version_registry.status
    sql = f"""
        SELECT 
            d.dta_id,
            d.dta_number,
            d.dta_name,
            d.trial_id,
            d.data_stream_type,
            d.data_provider_name,
            d.version,
            d.workflow_state,
            d.status,
            d.created_ts,
            d.last_updated_ts,
            d.notes,
            -- Pivoted metadata counts (1:1 status mapping with DTA.status)
            MAX(CASE WHEN vr.library_type = 'transfer_variables' THEN vr.record_count ELSE 0 END) AS transfer_variables_count,
            MAX(CASE WHEN vr.library_type = 'transfer_variables' THEN vr.version END) AS transfer_variables_version,
            MAX(CASE WHEN vr.library_type = 'test_concepts' THEN vr.record_count ELSE 0 END) AS test_concepts_count,
            MAX(CASE WHEN vr.library_type = 'test_concepts' THEN vr.version END) AS test_concepts_version,
            MAX(CASE WHEN vr.library_type = 'codelists' THEN vr.record_count ELSE 0 END) AS codelists_count,
            MAX(CASE WHEN vr.library_type = 'codelists' THEN vr.version END) AS codelists_version,
            MAX(CASE WHEN vr.library_type = 'operational_agreements' THEN vr.record_count ELSE 0 END) AS operational_agreements_count,
            MAX(CASE WHEN vr.library_type = 'visits_timepoints' THEN vr.record_count ELSE 0 END) AS visits_timepoints_count,
            MAX(CASE WHEN vr.library_type = 'data_ingestion_params' THEN vr.record_count ELSE 0 END) AS data_ingestion_params_count
        FROM {dta_table} d
        LEFT JOIN {registry_table} vr 
            ON d.dta_id = vr.dta_id 
           AND vr.status = d.status
        WHERE {where_clause}
        GROUP BY 
            d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type,
            d.data_provider_name, d.version, d.workflow_state,
            d.status, d.created_ts, d.last_updated_ts, d.notes
        ORDER BY d.last_updated_ts DESC
        LIMIT {limit}
    """
    
    print(f"=" * 60)
    print(f"DEBUG: Searching existing DTAs (optimized single query)")
    print(f"DEBUG: Query:")
    print(sql)
    print(f"=" * 60)
    
    client = _get_sql_client()
    dta_results = client.execute_query(sql)
    
    print(f"DEBUG: Found {len(dta_results)} matching DTAs")
    
    # Format results - now using flat structure matching Genie format
    dtas_with_metadata = []
    for dta in dta_results:
        # Format timestamp
        last_updated = dta.get("last_updated_ts", "")
        if last_updated:
            try:
                if isinstance(last_updated, str):
                    dt = datetime.fromisoformat(last_updated.replace("Z", "+00:00"))
                else:
                    dt = last_updated
                formatted_date = dt.strftime("%b %d, %Y")
            except:
                formatted_date = str(last_updated)[:10]
        else:
            formatted_date = "N/A"
        
        # Build metadata summary (for backward compatibility with existing UI)
        metadata_summary = {}
        for lib_type in ['transfer_variables', 'test_concepts', 'codelists', 
                         'operational_agreements', 'visits_timepoints', 'data_ingestion_params']:
            count = int(dta.get(f"{lib_type}_count", 0) or 0)
            version = dta.get(f"{lib_type}_version")
            if count > 0 or version:
                metadata_summary[lib_type] = {
                    "version": version,
                    "record_count": count
                }
        
        dtas_with_metadata.append({
            "dta_id": dta.get("dta_id"),
            "dta_number": dta.get("dta_number"),
            "dta_name": dta.get("dta_name"),
            "trial_id": dta.get("trial_id"),
            "data_stream_type": dta.get("data_stream_type"),
            "data_provider_name": dta.get("data_provider_name"),
            "version": dta.get("version"),
            "workflow_state": dta.get("workflow_state"),
            "status": dta.get("status"),
            "last_updated": formatted_date,
            "notes": dta.get("notes", ""),
            "metadata": metadata_summary,
            # Also include flat counts for Genie-compatible format
            "transfer_variables_count": int(dta.get("transfer_variables_count", 0) or 0),
            "test_concepts_count": int(dta.get("test_concepts_count", 0) or 0),
            "codelists_count": int(dta.get("codelists_count", 0) or 0),
            "operational_agreements_count": int(dta.get("operational_agreements_count", 0) or 0),
            "visits_timepoints_count": int(dta.get("visits_timepoints_count", 0) or 0),
            "data_ingestion_params_count": int(dta.get("data_ingestion_params_count", 0) or 0)
        })
    
    return dtas_with_metadata


def get_unique_filter_values() -> dict:
    """
    Get unique values for trial_id, data_stream_type, and data_provider_name.
    Used to populate dropdown filters in the search UI.
    
    Returns:
        Dict with lists of unique values for each field
    """
    config = _get_db_config()
    dta_table = f"{config['catalog']}.{config['gold_schema']}.dta"
    
    # Get distinct values for each field
    query = f"""
        SELECT DISTINCT trial_id
        FROM {dta_table}
        WHERE trial_id IS NOT NULL
        ORDER BY trial_id
    """
    client = _get_sql_client()
    trial_ids = [r.get("trial_id") for r in client.execute_query(query)]
    
    query = f"""
        SELECT DISTINCT data_stream_type
        FROM {dta_table}
        WHERE data_stream_type IS NOT NULL
        ORDER BY data_stream_type
    """
    streams = [r.get("data_stream_type") for r in client.execute_query(query)]
    
    query = f"""
        SELECT DISTINCT data_provider_name
        FROM {dta_table}
        WHERE data_provider_name IS NOT NULL
        ORDER BY data_provider_name
    """
    providers = [r.get("data_provider_name") for r in client.execute_query(query)]
    
    return {
        "trial_ids": trial_ids,
        "data_streams": streams,
        "data_providers": providers
    }


# ============================================================================
# DTA CREATION
# ============================================================================

def get_dta_create_context(selected_libraries: dict = None) -> dict:
    """
    Get all data needed for the DTA creation page.
    
    Args:
        selected_libraries: Pre-selected library versions from dashboard
                           Format: {"TV": "1.0", "CL": "2.0", ...}
    
    Returns:
        Dict with library_entities, filter_values, and selected_libraries
    """
    # Get library versions
    versions_by_type = get_all_versions()
    library_entities = format_library_entities_for_selection(versions_by_type)
    
    # Mark pre-selected versions
    if selected_libraries:
        code_to_type = {
            "TV": "transfer_variables",
            "CL": "codelists", 
            "TC": "test_concepts",
            "OA": "operational_agreements",
            "VT": "visits_timepoints",
            "DIP": "data_ingestion_parameters"
        }
        
        for entity in library_entities:
            code = entity["code"]
            if code in selected_libraries:
                selected_version = selected_libraries[code]
                for v in entity["versions"]:
                    if v["version"] == selected_version:
                        v["is_selected"] = True
                    else:
                        v["is_selected"] = False
    
    # Get filter values for search
    try:
        filter_values = get_unique_filter_values()
    except Exception as e:
        print(f"WARNING: Could not get filter values: {e}")
        filter_values = {"trial_ids": [], "data_streams": [], "data_providers": []}
    
    return {
        "library_entities": library_entities,
        "filter_values": filter_values,
        "selected_libraries": selected_libraries or {}
    }


# ============================================================================
# API ENDPOINTS
# ============================================================================

@dta_bp.route('/library-versions')
def api_get_versions():
    """
    Get all library versions for DTA creation.
    """
    try:
        versions_by_type = get_all_versions()
        library_entities = format_library_entities_for_selection(versions_by_type)
        
        return jsonify({
            "success": True,
            "data": {
                "library_entities": library_entities
            }
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@dta_bp.route('/search')
def api_search_dtas():
    """
    Search for existing approved DTAs using free-text query.
    
    Query params:
        - q: Free-text search query (e.g., "VAC18193", "trial = ABC and provider = IQVIA")
        - trial_id: (legacy) Trial ID filter
        - data_stream: (legacy) Data stream type filter
        - provider: (legacy) Data provider name filter
        - limit: Max results (default 3)
    """
    try:
        # Support both free-text query (q) and legacy individual params
        query = request.args.get('q', '').strip()
        trial_id = request.args.get('trial_id', '').strip()
        data_stream = request.args.get('data_stream', '').strip()
        provider = request.args.get('provider', '').strip()
        limit = request.args.get('limit', 3, type=int)
        
        # Require some search text
        if not query and not trial_id and not data_stream and not provider:
            return jsonify({
                "success": True,
                "data": {
                    "dtas": [],
                    "message": "Enter at least 2 characters to search"
                }
            })
        
        # If using free-text query, it should be at least 2 chars
        if query and len(query) < 2:
            return jsonify({
                "success": True,
                "data": {
                    "dtas": [],
                    "message": "Enter at least 2 characters to search"
                }
            })
        
        dtas = search_existing_dtas(
            query=query,
            trial_id=trial_id,
            data_stream=data_stream,
            provider=provider,
            limit=limit
        )
        
        return jsonify({
            "success": True,
            "data": {
                "dtas": dtas
            }
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@dta_bp.route('/filter-values')
def api_get_filter_values():
    """
    Get unique values for search filters (trial_id, data_stream, provider).
    """
    try:
        filter_values = get_unique_filter_values()
        
        return jsonify({
            "success": True,
            "data": filter_values
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@dta_bp.route('/metadata-summary/<dta_id>')
def api_get_dta_metadata_summary(dta_id):
    """
    Get metadata summary for a specific DTA.
    Shows record counts for each metadata type in this DTA.
    """
    try:
        config = _get_db_config()
        registry_table = f"{config['catalog']}.{config['gold_schema']}.md_version_registry"
        
        query = f"""
            SELECT 
                library_type,
                version,
                record_count,
                created_ts
            FROM {registry_table}
            WHERE dta_id = '{dta_id}'
              AND version_type = 'DTA_APPROVED'
              AND status = 'ACTIVE'
        """
        
        client = _get_sql_client()
        results = client.execute_query(query)
        
        metadata = {}
        for row in results:
            lib_type = row.get("library_type")
            metadata[lib_type] = {
                "version": row.get("version"),
                "record_count": int(row.get("record_count", 0) or 0)
            }
        
        return jsonify({
            "success": True,
            "data": {
                "dta_id": dta_id,
                "metadata": metadata
            }
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


# ============================================================================
# DTA CREATION - COMPLETE IMPLEMENTATION
# ============================================================================

def get_next_dta_number(client, dta_table: str) -> str:
    """
    Get the next sequential DTA number (e.g., DTA001, DTA002).
    
    Args:
        client: SQL client
        dta_table: Full table name
        
    Returns:
        Next DTA number string
    """
    query = f"""
        SELECT MAX(CAST(REGEXP_EXTRACT(dta_number, 'DTA([0-9]+)', 1) AS INT)) as max_num
        FROM {dta_table}
        WHERE dta_number LIKE 'DTA%'
    """
    result = client.execute_query(query)
    max_num_val = result[0].get("max_num") if result and result[0].get("max_num") else 0
    # Ensure max_num is an integer (SQL results may come back as strings)
    max_num = int(max_num_val) if max_num_val else 0
    return f"DTA{str(max_num + 1).zfill(3)}"


def get_base_template_version(client, registry_table: str, library_type: str = "transfer_variables") -> str:
    """
    Get the current active library major version.
    
    Args:
        client: SQL client
        registry_table: Full table name
        library_type: Type of library
        
    Returns:
        Current library version tag (e.g., "1.0") or "1.0" if none exists
    """
    query = f"""
        SELECT version 
        FROM {registry_table}
        WHERE version_type = 'DTA_TEMPLATE' 
          AND status = 'ACTIVE'
          AND library_type = '{library_type}'
        ORDER BY created_ts DESC
        LIMIT 1
    """
    result = client.execute_query(query)
    return result[0].get("version") if result else "1.0"


def get_test_concepts_for_dta(client, config: dict, dta_id: str, dta_status: str = 'DRAFT') -> list:
    """
    Fetch test concepts for a DTA from the appropriate table based on status.
    
    The test concepts table has a transfer_tuple_map (MAP<STRING, STRING>) that contains
    dynamic columns from the Excel. This function expands the map to individual columns
    for display in the UI.
    
    Args:
        client: SQL client
        config: Database config with catalog, silver_schema, and gold_schema
        dta_id: DTA ID to fetch test concepts for
        dta_status: DTA status - 'DRAFT' queries silver, others query gold
        
    Returns:
        List of test concept records with transfer_tuple_map expanded to columns
    """
    catalog = config['catalog']
    silver_schema = config['silver_schema']
    gold_schema = config.get('gold_schema', 'gold_md')
    
    # Determine which table to query based on DTA status
    is_draft = dta_status == 'DRAFT'
    
    if is_draft:
        table = f"{catalog}.{silver_schema}.md_dta_vendor_test_concepts_draft"
        where_clause = f"dta_id = '{dta_id}'"
    else:
        table = f"{catalog}.{gold_schema}.md_dta_vendor_test_concepts"
        where_clause = f"dta_id = '{dta_id}' AND is_current = true"
    
    print(f"Test concepts query - Status: {dta_status}, is_draft: {is_draft}, table: {table}")
    
    # Check if table exists and debug the data
    try:
        check_query = f"SELECT 1 FROM {table} LIMIT 1"
        client.execute_query(check_query, raise_on_error=True)
        
        # Debug: Count all records for this DTA regardless of is_current
        count_all_query = f"SELECT COUNT(*) as total FROM {table} WHERE dta_id = '{dta_id}'"
        count_result = client.execute_query(count_all_query)
        total_count = count_result[0].get('total', 0) if count_result else 0
        print(f"DEBUG: Total test concepts for DTA {dta_id} (no is_current filter): {total_count}")
        
        if not is_draft:
            # Also check with is_current filter
            count_current_query = f"SELECT COUNT(*) as total FROM {table} WHERE dta_id = '{dta_id}' AND is_current = true"
            count_current = client.execute_query(count_current_query)
            current_count = count_current[0].get('total', 0) if count_current else 0
            print(f"DEBUG: Test concepts with is_current=true: {current_count}")
    except Exception as e:
        print(f"Test concepts table not found or empty: {e}")
        return []
    
    # First, discover available columns in the table
    try:
        schema_query = f"DESCRIBE {table}"
        schema_result = client.execute_query(schema_query, raise_on_error=True)
        available_columns = [row.get('col_name', '') for row in schema_result if row.get('col_name') and not row.get('col_name', '').startswith('#')]
        print(f"DEBUG: Available columns in {table}: {available_columns}")
    except Exception as e:
        print(f"Could not get table schema: {e}")
        available_columns = []
    
    # Build query dynamically based on available columns
    # Priority columns we want to select if they exist
    desired_columns = [
        'test_concept_id', 'test_concept_reference', 'transfer_tuple_map',
        'trial_id', 'data_stream_type', 'data_provider_name',
        'status', 'vendor_comment', 'notes', 'definition_hash',
        'version', 'version_status', 'domain_info', 'dta_id'
    ]
    
    # Select only columns that exist
    select_columns = [col for col in desired_columns if col in available_columns]
    
    # Always need at least test_concept_reference or some identifier
    if not select_columns:
        # Fallback to SELECT *
        select_clause = "*"
    else:
        select_clause = ", ".join(select_columns)
    
    # Determine ORDER BY based on available columns
    order_by = "test_concept_reference" if 'test_concept_reference' in available_columns else "1"
    if 'domain_info' in available_columns:
        order_by = f"COALESCE(domain_info, 'ZZZ'), {order_by}"
    
    query = f"""
        SELECT {select_clause}
        FROM {table}
        WHERE {where_clause}
        ORDER BY {order_by}
    """
    
    print(f"Fetching test concepts for DTA {dta_id} (status: {dta_status})...")
    print(f"Query: {query}")
    
    try:
        results = client.execute_query(query, raise_on_error=True)
    except Exception as e:
        print(f"Query failed: {e}")
        # If is_current column doesn't exist in WHERE, try without it
        if 'is_current' in str(e) and not is_draft:
            print("Retrying without is_current filter...")
            alt_query = f"""
                SELECT {select_clause}
                FROM {table}
                WHERE dta_id = '{dta_id}'
                ORDER BY {order_by}
            """
            results = client.execute_query(alt_query, raise_on_error=False)
        else:
            return []
    
    if not results:
        print(f"No test concepts found for DTA {dta_id}")
        return []
    
    print(f"Found {len(results)} test concepts")
    return results


def transform_test_concepts_to_workspace(test_concepts: list) -> list:
    """
    Transform test concepts from database format to workspace format.
    
    The transfer_tuple_map is expanded into individual columns for display.
    Fixed columns (tab_name, test_concept_reference) are kept as separate columns.
    
    Args:
        test_concepts: List of test concept records from database
        
    Returns:
        List of dicts with flattened columns for UI display
    """
    if not test_concepts:
        return []
    
    workspace_tc = []
    
    for row in test_concepts:
        # Start with the transfer_tuple_map as the base (contains transfer variable columns)
        tuple_map = row.get('transfer_tuple_map')
        
        # Handle different return types (dict or string representation)
        if isinstance(tuple_map, str):
            try:
                import json
                tuple_map = json.loads(tuple_map)
            except:
                tuple_map = {}
        elif not isinstance(tuple_map, dict):
            tuple_map = {}
        
        # Create the flattened record with transfer tuple map columns
        tc_record = dict(tuple_map) if tuple_map else {}
        
        # Add metadata columns (not in tuple map but useful for context)
        # These will be shown but typically not editable
        tc_record['_test_concept_id'] = row.get('test_concept_id', '')
        tc_record['_status'] = row.get('status', 'COMPLETED')
        tc_record['_vendor_comment'] = row.get('vendor_comment', '')
        tc_record['_notes'] = row.get('notes', '')
        
        workspace_tc.append(tc_record)
    
    return workspace_tc


# ============================================================================
# Operational Agreement (OA) Functions
# ============================================================================

def get_oa_for_dta(client, config: dict, dta_id: str, is_draft: bool = True) -> dict:
    """
    Fetch all Operational Agreement data for a DTA using the unified schema.
    
    Schema (4 tables):
        1. md_operational_agreement_normalised: Parent table (1:1 with DTA)
        2. md_oa_attributes_normalised: Attributes linked by operational_agreement_id
        3. md_oa_options: Options linked by operational_agreement_id
        4. md_oa_other: Other items linked by operational_agreement_id
    
    Args:
        client: SQL client
        config: Database config with catalog, silver_schema, and gold_schema
        dta_id: DTA ID to fetch OA data for
        is_draft: If True, use silver tables; if False, use gold tables
        
    Returns:
        Dict with OA data: {
            "oa_id": operational_agreement_id,
            "oa_parent": [...],   # Parent table fields as key-value list
            "oa_attr": [...],     # Attributes from md_oa_attributes_normalised
            "oa_options": [...],  # Options from child table
            "oa_other": [...],    # Other items from child table
            "oa_exists": bool
        }
    """
    catalog = config['catalog']
    # Use silver for drafts, gold for approved/template DTAs
    schema = config['silver_schema'] if is_draft else config['gold_schema']
    
    # Table names (4 tables)
    oa_parent_table = f"{catalog}.{schema}.md_operational_agreement_normalised"
    oa_attr_table = f"{catalog}.{schema}.md_oa_attributes_normalised"
    oa_options_table = f"{catalog}.{schema}.md_oa_options"
    oa_other_table = f"{catalog}.{schema}.md_oa_other"
    
    result = {
        "oa_id": None,
        "oa_parent": [],   # Parent table (OA agreement)
        "oa_attr": [],     # Attributes table
        "oa_options": [],
        "oa_other": [],
        "oa_exists": False
    }
    
    try:
        # ========================================
        # Step 1: Query parent table (md_operational_agreement_normalised)
        # ========================================
        parent_query = f"""
            SELECT 
                operational_agreement_id,
                document_id,
                trial_id,
                data_stream,
                data_provider_name,
                dta_id,
                version,
                version_status,
                is_current_draft,
                row_status,
                vendor_comments,
                created_ts
            FROM {oa_parent_table}
            WHERE dta_id = '{dta_id}'
              AND (is_current_draft = true OR is_current_draft IS NULL)
            ORDER BY created_ts DESC
            LIMIT 1
        """
        
        print(f"OA Query: {oa_parent_table} for dta_id={dta_id} (is_draft={is_draft}, schema={schema})")
        parent_results = client.execute_query(parent_query, raise_on_error=False)
        
        if not parent_results:
            print(f"No OA found for DTA {dta_id} in {oa_parent_table} (is_draft={is_draft})")
            return result
        
        parent_row = parent_results[0]
        oa_id = parent_row.get('operational_agreement_id')
        print(f"OA Found: operational_agreement_id={oa_id}")
        result["oa_id"] = oa_id
        result["oa_exists"] = True
        
        # Transform parent fields to oa_parent format (for UI compatibility)
        result["oa_parent"] = [
            {
                "field": "data_provider_name",
                "label": "Data Provider",
                "value": parent_row.get('data_provider_name', ''),
                "readonly": True
            },
            {
                "field": "version",
                "label": "Version",
                "value": parent_row.get('version', ''),
                "readonly": False
            },
            {
                "field": "trial_id",
                "label": "Trial ID",
                "value": parent_row.get('trial_id', ''),
                "readonly": True
            },
            {
                "field": "data_stream",
                "label": "Data Stream",
                "value": parent_row.get('data_stream', ''),
                "readonly": True
            },
            {
                "field": "version_status",
                "label": "Version Status",
                "value": parent_row.get('version_status', ''),
                "readonly": True
            }
        ]
        
        print(f"Found OA {oa_id} for DTA {dta_id}")
        
        # ========================================
        # Step 2: Query OA Attributes (md_oa_attributes_normalised)
        # ========================================
        attr_query = f"""
            SELECT 
                oa_attributes_id,
                operational_agreement_id,
                data_recipient,
                document_version,
                issue_date,
                data_provider_name,
                trial_id,
                data_stream,
                version_status,
                row_status,
                vendor_comments
            FROM {oa_attr_table}
            WHERE operational_agreement_id = '{oa_id}'
        """
        
        print(f"OA Attr Query: {oa_attr_table} for oa_id={oa_id}")
        attr_results = client.execute_query(attr_query, raise_on_error=False)
        print(f"OA Attr Results: {len(attr_results) if attr_results else 0} rows")
        
        if attr_results:
            # Transform to UI format (key-value pairs)
            attr_row = attr_results[0]
            result["oa_attr"] = [
                {
                    "field": "data_recipient",
                    "label": "Data Recipient",
                    "value": attr_row.get('data_recipient', ''),
                    "readonly": False
                },
                {
                    "field": "document_version",
                    "label": "Document Version",
                    "value": attr_row.get('document_version', ''),
                    "readonly": False
                },
                {
                    "field": "issue_date",
                    "label": "Issue Date",
                    "value": attr_row.get('issue_date', ''),
                    "readonly": False
                },
                {
                    "field": "vendor_comments",
                    "label": "Vendor Comments",
                    "value": attr_row.get('vendor_comments', ''),
                    "readonly": False
                }
            ]
            print(f"  Found {len(result['oa_attr'])} OA attributes")
        else:
            print(f"  No OA attributes found for OA {oa_id}")
        
        # ========================================
        # Step 3: Query OA Options (linked by operational_agreement_id)
        # ========================================
        options_query = f"""
            SELECT 
                oa_options_id,
                operational_agreement_id,
                section_name,
                section_description,
                option_key,
                options,
                selected_options,
                vendor_comment,
                notes,
                status
            FROM {oa_options_table}
            WHERE operational_agreement_id = '{oa_id}'
            ORDER BY section_name
        """
        
        print(f"OA Options Query: {oa_options_table} for oa_id={oa_id}")
        options_results = client.execute_query(options_query, raise_on_error=False)
        print(f"OA Options Results: {len(options_results) if options_results else 0} rows")
        
        if options_results:
            for row in options_results:
                # Parse options and selected_options (may be arrays or strings)
                options = row.get('options', [])
                if isinstance(options, str):
                    options = [o.strip() for o in options.split(',') if o.strip()]
                
                selected = row.get('selected_options', [])
                if isinstance(selected, str):
                    selected = [s.strip() for s in selected.split(',') if s.strip()]
                
                result["oa_options"].append({
                    "oa_options_id": row.get('oa_options_id', ''),
                    "section_name": row.get('section_name', ''),
                    "section_description": row.get('section_description', ''),
                    "option_key": row.get('option_key', ''),
                    "options": options,
                    "selected_options": selected,
                    "status": row.get('status', 'PENDING'),
                    "vendor_comments": row.get('vendor_comment', '')
                })
            
            print(f"  Found {len(result['oa_options'])} OA options")
        
        # ========================================
        # Step 4: Query OA Other (linked by operational_agreement_id)
        # ========================================
        other_query = f"""
            SELECT 
                oa_other_id,
                operational_agreement_id,
                item_key,
                item_label,
                item_value,
                vendor_comment,
                notes,
                status
            FROM {oa_other_table}
            WHERE operational_agreement_id = '{oa_id}'
            ORDER BY item_label
        """
        
        print(f"OA Other Query: {oa_other_table} for oa_id={oa_id}")
        other_results = client.execute_query(other_query, raise_on_error=False)
        print(f"OA Other Results: {len(other_results) if other_results else 0} rows")
        
        if other_results:
            for row in other_results:
                result["oa_other"].append({
                    "oa_other_id": row.get('oa_other_id', ''),
                    "item_key": row.get('item_key', ''),
                    "item_label": row.get('item_label', ''),
                    "item_value": row.get('item_value', ''),
                    "status": row.get('status', 'PENDING'),
                    "vendor_comments": row.get('vendor_comment', '')
                })
            
            print(f"  Found {len(result['oa_other'])} OA other items")
        
        return result
        
    except Exception as e:
        error_str = str(e)
        if 'TABLE_OR_VIEW_NOT_FOUND' in error_str:
            print(f"OA tables not found for DTA {dta_id} - tables may not exist yet")
        else:
            print(f"Error fetching OA data: {e}")
        return result


# Legacy wrapper functions for backward compatibility (deprecated)
def get_oa_attributes_for_dta(client, config: dict, dta_id: str) -> list:
    """DEPRECATED: Use get_oa_for_dta() instead. Returns oa_attr from unified function."""
    oa_data = get_oa_for_dta(client, config, dta_id)
    return oa_data.get("oa_attr", [])

def get_oa_options_for_dta(client, config: dict, dta_id: str) -> list:
    """DEPRECATED: Use get_oa_for_dta() instead. Returns oa_options from unified function."""
    oa_data = get_oa_for_dta(client, config, dta_id)
    return oa_data.get("oa_options", [])

def get_oa_other_for_dta(client, config: dict, dta_id: str) -> list:
    """DEPRECATED: Use get_oa_for_dta() instead. Returns oa_other from unified function."""
    oa_data = get_oa_for_dta(client, config, dta_id)
    return oa_data.get("oa_other", [])


def create_dta_complete(
    trial_id: str,
    data_stream_type: str,
    data_provider_name: str,
    created_by: str,
    source_dta_id: str = None,
    versions: dict = None,
    notes: str = None
) -> dict:
    """
    Create a complete DTA with all related entities in a single transaction.
    
    This function performs the following operations via direct SQL:
    1. Create DTA entity
    2. Create DTA workflow
    3. Create approval tasks (JNJ and Vendor)
    4. Copy records from source DTA (if cloning)
    5. Register version in md_version_registry
    
    Args:
        trial_id: Trial identifier
        data_stream_type: Data stream type (e.g., "PF", "LB")
        data_provider_name: Vendor/provider name
        created_by: User principal creating the DTA
        source_dta_id: Optional DTA ID to clone from
        versions: Optional dict of library type -> version to use
        notes: Optional notes
        
    Returns:
        Dict with created DTA details including dta_id, dta_number, version
    """
    import uuid
    
    config = _get_db_config()
    client = _get_sql_client()
    
    # Table names
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    silver_schema = config.get("silver_schema", "silver_md")
    dta_table = f"{catalog}.{gold_schema}.dta"
    workflow_table = f"{catalog}.{gold_schema}.dta_workflow"
    approval_table = f"{catalog}.{gold_schema}.dta_approval_task"
    registry_table = f"{catalog}.{gold_schema}.md_version_registry"
    library_table = f"{catalog}.{gold_schema}.md_dta_transfer_variables"  # Gold - for approved
    silver_table = f"{catalog}.{silver_schema}.md_dta_transfer_variables_draft"  # Silver - for drafts
    
    # Generate IDs
    dta_id = str(uuid.uuid4())
    workflow_id = str(uuid.uuid4())
    jnj_task_id = str(uuid.uuid4())
    vendor_task_id = str(uuid.uuid4())
    
    # Get next DTA number
    dta_number = get_next_dta_number(client, dta_table)
    
    # Get base library version
    base_template_version = get_base_template_version(client, registry_table)
    
    # Build version tag for draft
    draft_version = f"{base_template_version}-{dta_number}-draft1"
    
    print(f"=" * 60)
    print(f"DTA CREATION: Starting complete DTA creation")
    print(f"  DTA ID: {dta_id}")
    print(f"  DTA Number: {dta_number}")
    print(f"  Trial: {trial_id}")
    print(f"  Provider: {data_provider_name}")
    print(f"  Stream: {data_stream_type}")
    print(f"  Draft Version: {draft_version}")
    print(f"  Source DTA: {source_dta_id or 'None (fresh)'}")
    print(f"=" * 60)
    
    # ========================================
    # Step 1: Create DTA entity
    # ========================================
    dta_notes = notes or f"Created via UI by {created_by}"
    if source_dta_id:
        dta_notes = f"Cloned from DTA {source_dta_id}. {dta_notes}"
    
    # Generate user-friendly DTA name
    # UI-created DTAs get <Change_this> prefix to prompt user to customize
    dta_name = f"<Change_this>_{trial_id}_{data_stream_type}_{data_provider_name}"
    
    # Status aligns 1:1 with md_version_registry.status
    dta_insert = f"""
        INSERT INTO {dta_table} (
            dta_id, dta_number, dta_name, parent_document_id, trial_id, data_stream_type,
            data_provider_name, status, workflow_state, workflow_iteration,
            version, current_draft_version, base_template_version, notes,
            created_by_principal, created_ts, last_updated_by_principal, last_updated_ts
        ) VALUES (
            '{dta_id}',
            '{dta_number}',
            '{dta_name}',
            NULL,
            '{trial_id}',
            '{data_stream_type}',
            '{data_provider_name}',
            'DRAFT',
            'NOT_STARTED',
            1,
            '{draft_version}',
            '{draft_version}',
            '{base_template_version}',
            '{dta_notes.replace("'", "''")}',
            '{created_by}',
            current_timestamp(),
            '{created_by}',
            current_timestamp()
        )
    """
    
    print(f"Step 1: Creating DTA entity...")
    client.execute_query(dta_insert)
    print(f"  ✓ DTA created: {dta_number}")
    
    # ========================================
    # Step 2: Create DTA Workflow
    # ========================================
    workflow_insert = f"""
        INSERT INTO {workflow_table} (
            dta_workflow_id, dta_id, workflow_iteration, workflow_status,
            summary_comment, initiated_ts, closed_ts,
            created_by_principal, created_ts, last_updated_by_principal, last_updated_ts
        ) VALUES (
            '{workflow_id}',
            '{dta_id}',
            1,
            'NOT_STARTED',
            'Initial workflow for {dta_number}',
            NULL,
            NULL,
            '{created_by}',
            current_timestamp(),
            '{created_by}',
            current_timestamp()
        )
    """
    
    print(f"Step 2: Creating workflow...")
    client.execute_query(workflow_insert)
    print(f"  ✓ Workflow created")
    
    # ========================================
    # Step 3: Create Approval Tasks
    # ========================================
    # JNJ DAE Task
    jnj_task_insert = f"""
        INSERT INTO {approval_table} (
            approval_task_id, dta_workflow_id, dta_id, approver_role,
            assigned_to_principal, approval_status, approval_order,
            approval_comment, approved_ts,
            created_by_principal, created_ts, last_updated_by_principal, last_updated_ts
        ) VALUES (
            '{jnj_task_id}',
            '{workflow_id}',
            '{dta_id}',
            'JNJ_DAE',
            NULL,
            'PENDING',
            1,
            NULL,
            NULL,
            '{created_by}',
            current_timestamp(),
            '{created_by}',
            current_timestamp()
        )
    """
    
    # Vendor Task
    vendor_task_insert = f"""
        INSERT INTO {approval_table} (
            approval_task_id, dta_workflow_id, dta_id, approver_role,
            assigned_to_principal, approval_status, approval_order,
            approval_comment, approved_ts,
            created_by_principal, created_ts, last_updated_by_principal, last_updated_ts
        ) VALUES (
            '{vendor_task_id}',
            '{workflow_id}',
            '{dta_id}',
            'VENDOR',
            NULL,
            'PENDING',
            2,
            NULL,
            NULL,
            '{created_by}',
            current_timestamp(),
            '{created_by}',
            current_timestamp()
        )
    """
    
    print(f"Step 3: Creating approval tasks...")
    client.execute_query(jnj_task_insert)
    client.execute_query(vendor_task_insert)
    print(f"  ✓ Approval tasks created (JNJ_DAE, VENDOR)")
    
    # ========================================
    # Step 4: Copy records from source to SILVER (for drafts)
    # ========================================
    record_count = 0
    
    source_dta_number = None
    source_dta_name = None
    
    if source_dta_id:
        # Get source DTA's current version tag, number, name and status
        source_query = f"""
            SELECT version, dta_number, dta_name, status FROM {dta_table}
            WHERE dta_id = '{source_dta_id}'
        """
        source_result = client.execute_query(source_query)
        
        if source_result:
            source_version = source_result[0].get("version")
            source_dta_number = source_result[0].get("dta_number")
            source_dta_name = source_result[0].get("dta_name")
            source_status = source_result[0].get("status", "").upper()
            
            # Determine source table based on DTA status
            # DRAFT DTAs have records in Silver, APPROVED DTAs have records in Gold
            is_source_draft = source_status == "DRAFT"
            source_table = silver_table if is_source_draft else library_table
            source_filter = f"dta_id = '{source_dta_id}'" if is_source_draft else f"version = '{source_version}'"
            
            print(f"Step 4: Copying records from source {source_status} DTA to SILVER...")
            print(f"  Source table: {source_table} ({'Silver - Draft' if is_source_draft else 'Gold - Approved'})")
            print(f"  Source filter: {source_filter}")
            print(f"  Target table (Silver): {silver_table}")
            
            # Copy records from source to Silver table for draft
            # Source can be Gold (approved DTA) or Silver (draft DTA)
            # 
            # Gold table columns: definition_hash, version, transfer_variable_name,
            #   transfer_variable_label, variable_description, format, anticipated_max_length,
            #   codelist_values (ARRAY<STRING>), domain_info, is_major_version, is_dta_major, etc.
            #
            # Silver table columns: transfer_variable_id, parent_document_id, dta_id, trial_id,
            #   data_stream_type, data_provider_name, transfer_variable_name,
            #   codelist_values (ARRAY<STRING>), transfer_variable_label, variable_description,
            #   transfer_variable_order, format, anticipated_max_length,
            #   populate_for_all_records, transfer_file_key, example_values,
            #   definition_hash, notes, status, domain_info,
            #   version, version_status, is_current_draft
            #
            # We only SELECT columns that exist in both tables
            copy_query = f"""
                INSERT INTO {silver_table} (
                    transfer_variable_id,
                    parent_document_id,
                    dta_id,
                    trial_id,
                    data_stream_type,
                    data_provider_name,
                    transfer_variable_name,
                    codelist_values,
                    transfer_variable_label,
                    variable_description,
                    transfer_variable_order,
                    format,
                    anticipated_max_length,
                    populate_for_all_records,
                    transfer_file_key,
                    example_values,
                    definition_hash,
                    notes,
                    status,
                    version,
                    version_status,
                    is_current_draft,
                    vendor_comment,
                    domain_info
                )
                SELECT 
                    uuid() as transfer_variable_id,
                    '{dta_id}' as parent_document_id,
                    '{dta_id}' as dta_id,
                    '{trial_id}' as trial_id,
                    '{data_stream_type}' as data_stream_type,
                    '{data_provider_name}' as data_provider_name,
                    transfer_variable_name,
                    codelist_values,
                    transfer_variable_label,
                    variable_description,
                    transfer_variable_order,
                    format,
                    anticipated_max_length,
                    populate_for_all_records,
                    transfer_file_key,
                    example_values,
                    definition_hash,
                    'Cloned from {source_version}' as notes,
                    status,
                    '{draft_version}' as version,
                    'DRAFT' as version_status,
                    true as is_current_draft,
                    vendor_comment,
                    domain_info
                FROM {source_table}
                WHERE {source_filter}
                ORDER BY COALESCE(domain_info, 'ZZZ'), transfer_variable_order, transfer_variable_name
            """
            
            print(f"  Executing copy query...")
            print(f"  DEBUG: Copy SQL query:")
            print(f"  {copy_query[:500]}...")  # Print first 500 chars
            
            try:
                # Use raise_on_error=True to see SQL errors
                result = client.execute_query(copy_query, raise_on_error=True)
                print(f"  DEBUG: Copy query result: {result}")
                
                # Get record count from Silver table
                count_query = f"""
                    SELECT COUNT(*) as cnt FROM {silver_table}
                    WHERE dta_id = '{dta_id}' AND version = '{draft_version}'
                """
                print(f"  DEBUG: Count query: {count_query}")
                count_result = client.execute_query(count_query)
                print(f"  DEBUG: Count result: {count_result}")
                count_val = count_result[0].get("cnt", 0) if count_result else 0
                record_count = int(count_val) if count_val else 0
                print(f"  ✓ Copied {record_count} records to Silver table")
                
                if record_count == 0:
                    print(f"  ⚠ WARNING: 0 records copied! Checking source...")
                    # Check if source has records
                    source_check = f"""
                        SELECT COUNT(*) as cnt FROM {library_table}
                        WHERE version = '{source_version}'
                    """
                    source_result = client.execute_query(source_check)
                    source_count = source_result[0].get("cnt", 0) if source_result else 0
                    print(f"  DEBUG: Source has {source_count} records for version {source_version}")
                    
            except Exception as e:
                print(f"  ⚠ ERROR: Could not copy records: {e}")
                import traceback
                traceback.print_exc()
                # Re-raise to see the full error
                raise
        else:
            print(f"Step 4: Source DTA not found, skipping record copy")
    else:
        print(f"Step 4: Fresh DTA (no source), skipping record copy")
    
    # Log activity for record copy (if any records were copied)
    if record_count > 0 and source_dta_id:
        log_bulk_insert(
            dta_id=dta_id,
            library_type="transfer_variables",
            record_count=record_count,
            performed_by=created_by,
            source_dta_id=source_dta_id
        )
        print(f"  ✓ Activity logged: BULK_INSERT ({record_count} records cloned)")
    
    # ========================================
    # Step 4b: Copy TEST CONCEPTS from source to SILVER (if source exists)
    # ========================================
    tc_record_count = 0
    
    if source_dta_id and source_result:
        # Table names for test concepts
        tc_library_table = f"{catalog}.{gold_schema}.md_dta_vendor_test_concepts"  # Gold
        tc_silver_table = f"{catalog}.{silver_schema}.md_dta_vendor_test_concepts_draft"  # Silver
        
        # Determine source table based on DTA status (draft vs approved)
        tc_source_table = tc_silver_table if is_source_draft else tc_library_table
        tc_source_filter = f"dta_id = '{source_dta_id}'" if is_source_draft else f"dta_id = '{source_dta_id}' AND is_current = true"
        
        print(f"Step 4b: Copying TEST CONCEPTS to Silver...")
        print(f"  Source table: {tc_source_table} ({'Silver - Draft' if is_source_draft else 'Gold - Approved'})")
        print(f"  Source filter: {tc_source_filter}")
        print(f"  Target table (Silver): {tc_silver_table}")
        
        # Copy test concepts from source to Silver
        tc_copy_query = f"""
            INSERT INTO {tc_silver_table} (
                test_concept_id,
                parent_document_id,
                dta_id,
                trial_id,
                data_stream_type,
                data_provider_name,
                domain_info,
                test_concept_reference,
                transfer_tuple_map,
                codelist_values,
                variable_description,
                definition_hash,
                notes,
                status,
                version,
                version_status,
                is_current_draft,
                vendor_comment
            )
            SELECT 
                uuid() as test_concept_id,
                '{dta_id}' as parent_document_id,
                '{dta_id}' as dta_id,
                '{trial_id}' as trial_id,
                '{data_stream_type}' as data_stream_type,
                '{data_provider_name}' as data_provider_name,
                domain_info,
                test_concept_reference,
                transfer_tuple_map,
                codelist_values,
                variable_description,
                definition_hash,
                'Cloned from {source_version}' as notes,
                status,
                '{draft_version}' as version,
                'DRAFT' as version_status,
                true as is_current_draft,
                vendor_comment
            FROM {tc_source_table}
            WHERE {tc_source_filter}
        """
        
        try:
            print(f"  Executing test concepts copy query...")
            client.execute_query(tc_copy_query, raise_on_error=True)
            
            # Get record count
            tc_count_query = f"""
                SELECT COUNT(*) as cnt FROM {tc_silver_table}
                WHERE dta_id = '{dta_id}' AND version = '{draft_version}'
            """
            tc_count_result = client.execute_query(tc_count_query)
            tc_count_val = tc_count_result[0].get("cnt", 0) if tc_count_result else 0
            tc_record_count = int(tc_count_val) if tc_count_val else 0
            print(f"  ✓ Copied {tc_record_count} test concepts to Silver table")
            
            # Log activity for test concepts copy
            if tc_record_count > 0:
                log_bulk_insert(
                    dta_id=dta_id,
                    library_type="test_concepts",
                    record_count=tc_record_count,
                    performed_by=created_by,
                    source_dta_id=source_dta_id
                )
                print(f"  ✓ Activity logged: BULK_INSERT ({tc_record_count} test concepts cloned)")
            
        except Exception as e:
            print(f"  ⚠ WARNING: Could not copy test concepts: {e}")
            # Don't fail - test concepts are optional (not all DTAs have them)
            import traceback
            traceback.print_exc()
    
    # ========================================
    # Step 4c: Copy OPERATIONAL AGREEMENT data using unified schema
    # Schema: 4 tables linked by operational_agreement_id
    #   1. md_operational_agreement_normalised (parent)
    #   2. md_oa_attributes_normalised (attributes)
    #   3. md_oa_options (options)
    #   4. md_oa_other (other items)
    # ========================================
    oa_record_count = 0
    oa_attr_count = 0
    oa_options_count = 0
    oa_other_count = 0
    new_oa_id = None
    
    # Table names (using unified schema - 4 tables)
    # 1. Parent table
    oa_silver_parent_table = f"{catalog}.{silver_schema}.md_operational_agreement_normalised"
    oa_gold_parent_table = f"{catalog}.{gold_schema}.md_operational_agreement_normalised"
    
    # 2. Attributes table (NEW)
    oa_silver_attr_table = f"{catalog}.{silver_schema}.md_oa_attributes_normalised"
    oa_gold_attr_table = f"{catalog}.{gold_schema}.md_oa_attributes_normalised"
    
    # 3. Options table
    oa_silver_options_table = f"{catalog}.{silver_schema}.md_oa_options"
    oa_gold_options_table = f"{catalog}.{gold_schema}.md_oa_options"
    
    # 4. Other table
    oa_silver_other_table = f"{catalog}.{silver_schema}.md_oa_other"
    oa_gold_other_table = f"{catalog}.{gold_schema}.md_oa_other"
    
    # ========================================
    # Step 4c.0: Create OA tables if they don't exist (required for first-time setup)
    # This ALWAYS runs regardless of source DTA existence
    # Uses raise_on_error=True so exceptions are caught and handled properly
    # ========================================
    print(f"Step 4c.0: Creating OA tables if they don't exist...")
    oa_tables_created = True  # Track if table creation succeeded
    
    # Create md_operational_agreement_normalised (parent)
    try:
        oa_parent_ddl = f"""
            CREATE TABLE IF NOT EXISTS {oa_silver_parent_table} (
                operational_agreement_id STRING NOT NULL,
                document_id STRING,
                parent_document_id STRING,
                trial_id STRING,
                data_stream STRING,
                data_provider_name STRING,
                dta_id STRING,
                version STRING,
                version_status STRING,
                is_current_draft BOOLEAN,
                row_status STRING,
                vendor_comments STRING,
                definition_hash STRING,
                created_by_principal STRING,
                created_ts TIMESTAMP,
                databricks_job_id STRING,
                databricks_job_name STRING,
                databricks_run_id STRING,
                last_updated_by_principal STRING,
                last_updated_ts TIMESTAMP
            ) USING DELTA
        """
        client.execute_query(oa_parent_ddl, raise_on_error=True)
        print(f"  ✓ Table created: {oa_silver_parent_table}")
    except Exception as e:
        print(f"  ⚠ ERROR creating parent table: {e}")
        import traceback
        traceback.print_exc()
        raise Exception(f"Failed to create OA parent table: {e}")
    
    # Create md_oa_attributes_normalised
    try:
        oa_attr_ddl = f"""
            CREATE TABLE IF NOT EXISTS {oa_silver_attr_table} (
                oa_attributes_id STRING NOT NULL,
                operational_agreement_id STRING NOT NULL,
                document_id STRING,
                parent_document_id STRING,
                dta_id STRING,
                trial_id STRING,
                data_stream STRING,
                data_provider_name STRING,
                data_recipient STRING,
                document_version STRING,
                issue_date STRING,
                version STRING,
                version_status STRING,
                is_current_draft BOOLEAN,
                definition_hash STRING,
                row_status STRING,
                vendor_comments STRING,
                created_by_principal STRING,
                created_ts TIMESTAMP,
                databricks_job_id STRING,
                databricks_job_name STRING,
                databricks_run_id STRING,
                last_updated_by_principal STRING,
                last_updated_ts TIMESTAMP
            ) USING DELTA
        """
        client.execute_query(oa_attr_ddl, raise_on_error=True)
        print(f"  ✓ Table created: {oa_silver_attr_table}")
    except Exception as e:
        print(f"  ⚠ ERROR creating attributes table: {e}")
        import traceback
        traceback.print_exc()
        raise Exception(f"Failed to create OA attributes table: {e}")
    
    # Create md_oa_options
    try:
        oa_options_ddl = f"""
            CREATE TABLE IF NOT EXISTS {oa_silver_options_table} (
                oa_options_id STRING NOT NULL,
                operational_agreement_id STRING NOT NULL,
                section_name STRING,
                section_description STRING,
                option_key STRING,
                options STRING,
                selected_options STRING,
                vendor_comment STRING,
                notes STRING,
                status STRING,
                created_by_principal STRING,
                created_ts TIMESTAMP,
                last_updated_by_principal STRING,
                last_updated_ts TIMESTAMP
            ) USING DELTA
        """
        client.execute_query(oa_options_ddl, raise_on_error=True)
        print(f"  ✓ Table created: {oa_silver_options_table}")
    except Exception as e:
        print(f"  ⚠ ERROR creating options table: {e}")
        import traceback
        traceback.print_exc()
        raise Exception(f"Failed to create OA options table: {e}")
    
    # Create md_oa_other
    try:
        oa_other_ddl = f"""
            CREATE TABLE IF NOT EXISTS {oa_silver_other_table} (
                oa_other_id STRING NOT NULL,
                operational_agreement_id STRING NOT NULL,
                item_key STRING,
                item_label STRING,
                item_value STRING,
                vendor_comment STRING,
                notes STRING,
                status STRING,
                created_by_principal STRING,
                created_ts TIMESTAMP,
                last_updated_by_principal STRING,
                last_updated_ts TIMESTAMP
            ) USING DELTA
        """
        client.execute_query(oa_other_ddl, raise_on_error=True)
        print(f"  ✓ Table created: {oa_silver_other_table}")
    except Exception as e:
        print(f"  ⚠ ERROR creating other table: {e}")
        import traceback
        traceback.print_exc()
        raise Exception(f"Failed to create OA other table: {e}")
    
    print(f"Step 4c.0: OA tables created = {oa_tables_created}")
    
    # Only copy OA if we have a source DTA (same pattern as TV/TC)
    print(f"Step 4c: Checking source - source_dta_id={source_dta_id}, source_result={bool(source_result)}")
    if source_dta_id and source_result:
        # Determine source tables based on DTA status (same as TV/TC) - all 4 tables
        oa_source_parent_table = oa_silver_parent_table if is_source_draft else oa_gold_parent_table
        oa_source_attr_table = oa_silver_attr_table if is_source_draft else oa_gold_attr_table
        oa_source_options_table = oa_silver_options_table if is_source_draft else oa_gold_options_table
        oa_source_other_table = oa_silver_other_table if is_source_draft else oa_gold_other_table
        
        print(f"Step 4c: Copying OPERATIONAL AGREEMENT data (4 tables)...")
        print(f"  Source layer: {'Silver - Draft' if is_source_draft else 'Gold - Approved'}")
        print(f"  Source parent: {oa_source_parent_table}")
        print(f"  Target parent: {oa_silver_parent_table}")
        
        try:
            # Step 4c.1: Get source OA record to find operational_agreement_id
            source_oa_query = f"""
                SELECT operational_agreement_id
                FROM {oa_source_parent_table}
                WHERE dta_id = '{source_dta_id}'
                  AND (is_current_draft = true OR is_current_draft IS NULL)
                ORDER BY created_ts DESC
                LIMIT 1
            """
            source_oa_result = client.execute_query(source_oa_query, raise_on_error=True)
            
            if not source_oa_result:
                print(f"  ⚠ No source OA found for DTA {source_dta_id} - will create default OA")
                raise Exception("SOURCE_OA_NOT_FOUND")
            
            source_oa_id = source_oa_result[0].get('operational_agreement_id')
            print(f"  Found source OA: {source_oa_id}")
            
            # Step 4c.2: Generate new operational_agreement_id for target DTA
            new_oa_id = str(uuid.uuid4())
            
            # Step 4c.3: Clone parent OA record with new IDs
            oa_parent_copy_query = f"""
                INSERT INTO {oa_silver_parent_table} (
                    operational_agreement_id,
                    document_id,
                    parent_document_id,
                    trial_id,
                    data_stream,
                    data_provider_name,
                    dta_id,
                    version,
                    version_status,
                    is_current_draft,
                    row_status,
                    vendor_comments,
                    definition_hash,
                    created_by_principal,
                    created_ts,
                    databricks_job_id,
                    databricks_job_name,
                    databricks_run_id,
                    last_updated_by_principal,
                    last_updated_ts
                )
                SELECT 
                    '{new_oa_id}' as operational_agreement_id,
                    uuid() as document_id,
                    document_id as parent_document_id,
                    trial_id,
                    data_stream,
                    data_provider_name,
                    '{dta_id}' as dta_id,
                    '{draft_version}' as version,
                    'DRAFT' as version_status,
                    true as is_current_draft,
                    'ACTIVE' as row_status,
                    CONCAT('Cloned from ', COALESCE(version, 'source')) as vendor_comments,
                    NULL as definition_hash,
                    '{created_by}' as created_by_principal,
                    current_timestamp() as created_ts,
                    NULL as databricks_job_id,
                    'UI Clone' as databricks_job_name,
                    NULL as databricks_run_id,
                    '{created_by}' as last_updated_by_principal,
                    current_timestamp() as last_updated_ts
                FROM {oa_source_parent_table}
                WHERE operational_agreement_id = '{source_oa_id}'
            """
            client.execute_query(oa_parent_copy_query, raise_on_error=True)
            oa_record_count = 1
            print(f"  ✓ Created OA record: {new_oa_id}")
            
            # Step 4c.4: Clone OA Attributes with new operational_agreement_id
            oa_attr_copy_query = f"""
                INSERT INTO {oa_silver_attr_table} (
                    oa_attributes_id,
                    operational_agreement_id,
                    document_id,
                    parent_document_id,
                    dta_id,
                    trial_id,
                    data_stream,
                    data_provider_name,
                    data_recipient,
                    document_version,
                    issue_date,
                    version,
                    version_status,
                    is_current_draft,
                    definition_hash,
                    row_status,
                    vendor_comments,
                    created_by_principal,
                    created_ts,
                    databricks_job_id,
                    databricks_job_name,
                    databricks_run_id,
                    last_updated_by_principal,
                    last_updated_ts
                )
                SELECT 
                    uuid() as oa_attributes_id,
                    '{new_oa_id}' as operational_agreement_id,
                    uuid() as document_id,
                    document_id as parent_document_id,
                    '{dta_id}' as dta_id,
                    trial_id,
                    data_stream,
                    data_provider_name,
                    data_recipient,
                    '{draft_version}' as document_version,
                    issue_date,
                    '{draft_version}' as version,
                    'DRAFT' as version_status,
                    true as is_current_draft,
                    NULL as definition_hash,
                    'ACTIVE' as row_status,
                    CONCAT('Cloned from ', COALESCE(version, 'source')) as vendor_comments,
                    '{created_by}' as created_by_principal,
                    current_timestamp() as created_ts,
                    NULL as databricks_job_id,
                    'UI Clone' as databricks_job_name,
                    NULL as databricks_run_id,
                    '{created_by}' as last_updated_by_principal,
                    current_timestamp() as last_updated_ts
                FROM {oa_source_attr_table}
                WHERE operational_agreement_id = '{source_oa_id}'
            """
            client.execute_query(oa_attr_copy_query, raise_on_error=True)
            
            # Get attributes count
            oa_attr_cnt = client.execute_query(f"SELECT COUNT(*) as cnt FROM {oa_silver_attr_table} WHERE operational_agreement_id = '{new_oa_id}'")
            oa_attr_count = int(oa_attr_cnt[0].get("cnt", 0)) if oa_attr_cnt else 0
            print(f"  ✓ Copied {oa_attr_count} OA attributes")
            
            # Step 4c.5: Clone OA Options with new operational_agreement_id
            oa_options_copy_query = f"""
                INSERT INTO {oa_silver_options_table} (
                    oa_options_id,
                    operational_agreement_id,
                    section_name,
                    section_description,
                    option_key,
                    options,
                    selected_options,
                    vendor_comment,
                    notes,
                    status,
                    created_by_principal,
                    created_ts,
                    last_updated_by_principal,
                    last_updated_ts
                )
                SELECT 
                    uuid() as oa_options_id,
                    '{new_oa_id}' as operational_agreement_id,
                    section_name,
                    section_description,
                    option_key,
                    options,
                    selected_options,
                    vendor_comment,
                    CONCAT('Cloned from ', '{source_version}') as notes,
                    status,
                    '{created_by}' as created_by_principal,
                    current_timestamp() as created_ts,
                    '{created_by}' as last_updated_by_principal,
                    current_timestamp() as last_updated_ts
                FROM {oa_source_options_table}
                WHERE operational_agreement_id = '{source_oa_id}'
            """
            client.execute_query(oa_options_copy_query, raise_on_error=True)
            
            # Get options count
            oa_options_cnt = client.execute_query(f"SELECT COUNT(*) as cnt FROM {oa_silver_options_table} WHERE operational_agreement_id = '{new_oa_id}'")
            oa_options_count = int(oa_options_cnt[0].get("cnt", 0)) if oa_options_cnt else 0
            print(f"  ✓ Copied {oa_options_count} OA options")
            
            # Step 4c.6: Clone OA Other with new operational_agreement_id
            oa_other_copy_query = f"""
                INSERT INTO {oa_silver_other_table} (
                    oa_other_id,
                    operational_agreement_id,
                    item_key,
                    item_label,
                    item_value,
                    vendor_comment,
                    notes,
                    status,
                    created_by_principal,
                    created_ts,
                    last_updated_by_principal,
                    last_updated_ts
                )
                SELECT 
                    uuid() as oa_other_id,
                    '{new_oa_id}' as operational_agreement_id,
                    item_key,
                    item_label,
                    item_value,
                    vendor_comment,
                    CONCAT('Cloned from ', '{source_version}') as notes,
                    status,
                    '{created_by}' as created_by_principal,
                    current_timestamp() as created_ts,
                    '{created_by}' as last_updated_by_principal,
                    current_timestamp() as last_updated_ts
                FROM {oa_source_other_table}
                WHERE operational_agreement_id = '{source_oa_id}'
            """
            client.execute_query(oa_other_copy_query, raise_on_error=True)
            
            # Get other count
            oa_other_cnt = client.execute_query(f"SELECT COUNT(*) as cnt FROM {oa_silver_other_table} WHERE operational_agreement_id = '{new_oa_id}'")
            oa_other_count = int(oa_other_cnt[0].get("cnt", 0)) if oa_other_cnt else 0
            print(f"  ✓ Copied {oa_other_count} OA other items")
            
            print(f"  ✓ OA cloned from {'Silver (Draft)' if is_source_draft else 'Gold (Approved)'}: parent=1, attributes={oa_attr_count}, options={oa_options_count}, other={oa_other_count}")
            
        except Exception as e:
            error_str = str(e)
            print(f"  ⚠ OA clone failed: {error_str}")
            # Will fall through to Step 4d to create default OA data
        
        # Log total OA data (inside the if source_dta_id block)
        total_oa_count = oa_record_count + oa_attr_count + oa_options_count + oa_other_count
        if total_oa_count > 0:
            print(f"  ✓ Total OA data: {total_oa_count} items (parent: {oa_record_count}, attributes: {oa_attr_count}, options: {oa_options_count}, other: {oa_other_count})")
    
    # ========================================
    # Step 4d: If no OA data exists, create default OA
    # This is the FALLBACK that creates default OA data for new DTAs
    # Only runs if tables were created successfully
    # ========================================
    total_oa_count = oa_record_count + oa_attr_count + oa_options_count + oa_other_count
    print(f"Step 4d: Checking OA - tables_created={oa_tables_created}, total_count={total_oa_count}")
    
    # Note: If table creation failed, an exception was raised above, so oa_tables_created is always True here
    if total_oa_count == 0:
        print(f"Step 4d: No OA data found - CREATING DEFAULT OA (4 tables)...")
        print(f"  Using dta_id={dta_id}, trial_id={trial_id}, stream={data_stream_type}, provider={data_provider_name}")
        
        # Generate new operational_agreement_id
        new_oa_id = str(uuid.uuid4())
        print(f"  Generated new_oa_id={new_oa_id}")
        
        # Define default OA options
        default_oa_options = [
            ("File Format", "Specify the format for data transfer files", "format_type", "CSV,SAS,XPT,Excel", "CSV"),
            ("Transfer Frequency", "How often data should be transferred", "frequency", "Daily,Weekly,Monthly,Ad-hoc", "Weekly"),
            ("Data Encryption", "Encryption requirements for data transfer", "encryption", "None,AES-256,PGP", "AES-256"),
            ("Notification Method", "How to notify upon data transfer completion", "notification", "Email,API Callback,None", "Email")
        ]
        
        default_oa_other = [
            ("special_instructions", "Special Instructions", "Include reconciliation file with each transfer"),
            ("escalation_contact", "Escalation Contact", "data.ops@jnj.com"),
            ("sla_response_time", "SLA Response Time", "24 hours")
        ]
        
        # Step 4d.1: Create parent OA record in md_operational_agreement_normalised
        try:
            # Generate document_id in Python (uuid() not allowed in VALUES clause)
            document_id = str(uuid.uuid4())
            
            oa_parent_insert = f"""
                INSERT INTO {oa_silver_parent_table} (
                    operational_agreement_id,
                    document_id,
                    parent_document_id,
                    trial_id,
                    data_stream,
                    data_provider_name,
                    dta_id,
                    version,
                    version_status,
                    is_current_draft,
                    row_status,
                    vendor_comments,
                    definition_hash,
                    created_by_principal,
                    created_ts,
                    databricks_job_id,
                    databricks_job_name,
                    databricks_run_id,
                    last_updated_by_principal,
                    last_updated_ts
                ) VALUES (
                    '{new_oa_id}',
                    '{document_id}',
                    NULL,
                    '{trial_id}',
                    '{data_stream_type}',
                    '{data_provider_name}',
                    '{dta_id}',
                    '{draft_version}',
                    'DRAFT',
                    true,
                    'ACTIVE',
                    'Default OA created during DTA setup',
                    NULL,
                    '{created_by}',
                    current_timestamp(),
                    NULL,
                    'UI DTA Creation',
                    NULL,
                    '{created_by}',
                    current_timestamp()
                )
            """
            client.execute_query(oa_parent_insert, raise_on_error=True)
            
            # Verify the insert worked
            verify_query = f"SELECT COUNT(*) as cnt FROM {oa_silver_parent_table} WHERE operational_agreement_id = '{new_oa_id}'"
            verify_result = client.execute_query(verify_query, raise_on_error=True)
            verify_count = int(verify_result[0].get('cnt', 0)) if verify_result else 0
            print(f"  VERIFY: Parent table has {verify_count} rows for oa_id={new_oa_id}")
            
            oa_record_count = verify_count
            print(f"  ✓ Created default OA parent record: {new_oa_id}")
        except Exception as e:
            print(f"  ⚠ ERROR creating default OA parent: {e}")
            import traceback
            traceback.print_exc()
            raise Exception(f"Failed to create OA parent record: {e}")
        
        # Step 4d.2: Create default OA Attributes record
        try:
            # Generate IDs in Python (uuid() not allowed in VALUES clause)
            oa_attributes_id = str(uuid.uuid4())
            attr_document_id = str(uuid.uuid4())
            from datetime import date
            issue_date_str = date.today().strftime('%Y-%m-%d')
            
            oa_attr_insert = f"""
                INSERT INTO {oa_silver_attr_table} (
                    oa_attributes_id,
                    operational_agreement_id,
                    document_id,
                    parent_document_id,
                    dta_id,
                    trial_id,
                    data_stream,
                    data_provider_name,
                    data_recipient,
                    document_version,
                    issue_date,
                    version,
                    version_status,
                    is_current_draft,
                    definition_hash,
                    row_status,
                    vendor_comments,
                    created_by_principal,
                    created_ts,
                    databricks_job_id,
                    databricks_job_name,
                    databricks_run_id,
                    last_updated_by_principal,
                    last_updated_ts
                ) VALUES (
                    '{oa_attributes_id}',
                    '{new_oa_id}',
                    '{attr_document_id}',
                    NULL,
                    '{dta_id}',
                    '{trial_id}',
                    '{data_stream_type}',
                    '{data_provider_name}',
                    'Johnson & Johnson',
                    '{draft_version}',
                    '{issue_date_str}',
                    '{draft_version}',
                    'DRAFT',
                    true,
                    NULL,
                    'ACTIVE',
                    'Default OA attributes created during DTA setup',
                    '{created_by}',
                    current_timestamp(),
                    NULL,
                    'UI DTA Creation',
                    NULL,
                    '{created_by}',
                    current_timestamp()
                )
            """
            client.execute_query(oa_attr_insert, raise_on_error=True)
            
            # Verify the insert worked
            verify_attr = f"SELECT COUNT(*) as cnt FROM {oa_silver_attr_table} WHERE operational_agreement_id = '{new_oa_id}'"
            verify_attr_result = client.execute_query(verify_attr, raise_on_error=True)
            oa_attr_count = int(verify_attr_result[0].get('cnt', 0)) if verify_attr_result else 0
            print(f"  VERIFY: Attr table has {oa_attr_count} rows for oa_id={new_oa_id}")
            print(f"  ✓ Created default OA attributes record")
        except Exception as e:
            print(f"  ⚠ ERROR creating default OA attributes: {e}")
            import traceback
            traceback.print_exc()
            raise Exception(f"Failed to create OA attributes record: {e}")
        
        # Step 4d.3: Create default OA Options
        try:
            for section_name, section_desc, option_key, options, selected in default_oa_options:
                # Generate ID in Python (uuid() not allowed in VALUES clause)
                oa_options_id = str(uuid.uuid4())
                
                oa_opt_insert = f"""
                    INSERT INTO {oa_silver_options_table} (
                        oa_options_id,
                        operational_agreement_id,
                        section_name,
                        section_description,
                        option_key,
                        options,
                        selected_options,
                        vendor_comment,
                        notes,
                        status,
                        created_by_principal,
                        created_ts,
                        last_updated_by_principal,
                        last_updated_ts
                    ) VALUES (
                        '{oa_options_id}',
                        '{new_oa_id}',
                        '{section_name}',
                        '{section_desc}',
                        '{option_key}',
                        '{options}',
                        '{selected}',
                        NULL,
                        'Default OA option',
                        'PENDING',
                        '{created_by}',
                        current_timestamp(),
                        '{created_by}',
                        current_timestamp()
                    )
                """
                client.execute_query(oa_opt_insert, raise_on_error=True)
            
            # Verify the inserts worked
            verify_opt = f"SELECT COUNT(*) as cnt FROM {oa_silver_options_table} WHERE operational_agreement_id = '{new_oa_id}'"
            verify_opt_result = client.execute_query(verify_opt, raise_on_error=True)
            oa_options_count = int(verify_opt_result[0].get('cnt', 0)) if verify_opt_result else 0
            print(f"  VERIFY: Options table has {oa_options_count} rows for oa_id={new_oa_id}")
            print(f"  ✓ Inserted {oa_options_count} default OA options")
        except Exception as e:
            print(f"  ⚠ ERROR inserting default OA options: {e}")
            import traceback
            traceback.print_exc()
            raise Exception(f"Failed to insert OA options: {e}")
        
        # Step 4d.4: Create default OA Other items
        try:
            for item_key, item_label, item_value in default_oa_other:
                # Generate ID in Python (uuid() not allowed in VALUES clause)
                oa_other_id = str(uuid.uuid4())
                
                oa_other_insert = f"""
                    INSERT INTO {oa_silver_other_table} (
                        oa_other_id,
                        operational_agreement_id,
                        item_key,
                        item_label,
                        item_value,
                        vendor_comment,
                        notes,
                        status,
                        created_by_principal,
                        created_ts,
                        last_updated_by_principal,
                        last_updated_ts
                    ) VALUES (
                        '{oa_other_id}',
                        '{new_oa_id}',
                        '{item_key}',
                        '{item_label}',
                        '{item_value}',
                        NULL,
                        'Default OA item',
                        'PENDING',
                        '{created_by}',
                        current_timestamp(),
                        '{created_by}',
                        current_timestamp()
                    )
                """
                client.execute_query(oa_other_insert, raise_on_error=True)
            
            # Verify the inserts worked
            verify_other = f"SELECT COUNT(*) as cnt FROM {oa_silver_other_table} WHERE operational_agreement_id = '{new_oa_id}'"
            verify_other_result = client.execute_query(verify_other, raise_on_error=True)
            oa_other_count = int(verify_other_result[0].get('cnt', 0)) if verify_other_result else 0
            print(f"  VERIFY: Other table has {oa_other_count} rows for oa_id={new_oa_id}")
            print(f"  ✓ Inserted {oa_other_count} default OA other items")
        except Exception as e:
            print(f"  ⚠ ERROR inserting default OA other: {e}")
            import traceback
            traceback.print_exc()
            raise Exception(f"Failed to insert OA other items: {e}")
        
        print(f"  ✓ Total default OA data: parent={oa_record_count}, attributes={oa_attr_count}, options={oa_options_count}, other={oa_other_count}")
    else:
        print(f"Step 4d: OA data already exists ({total_oa_count} items) - skipping fallback")
    
    # ========================================
    # Step 5: Register version in registry
    # ========================================
    version_insert = f"""
        INSERT INTO {registry_table} (
            version, library_type, version_type, dta_id,
            parent_version, record_count, status,
            created_by_principal, created_ts, last_updated_by_principal, last_updated_ts,
            databricks_job_id, databricks_job_name, databricks_run_id
        ) VALUES (
            '{draft_version}',
            'transfer_variables',
            'DTA_DRAFT',
            '{dta_id}',
            '{base_template_version}',
            {record_count},
            'ACTIVE',
            '{created_by}',
            current_timestamp(),
            '{created_by}',
            current_timestamp(),
            NULL,
            'UI DTA Creation',
            NULL
        )
    """
    
    print(f"Step 5: Registering version...")
    client.execute_query(version_insert)
    print(f"  ✓ Transfer variables version registered: {draft_version}")
    
    # Register test_concepts version if any were copied
    if tc_record_count > 0:
        tc_version_insert = f"""
            INSERT INTO {registry_table} (
                version, library_type, version_type, dta_id,
                parent_version, record_count, status,
                created_by_principal, created_ts, last_updated_by_principal, last_updated_ts,
                databricks_job_id, databricks_job_name, databricks_run_id
            ) VALUES (
                '{draft_version}',
                'test_concepts',
                'DTA_DRAFT',
                '{dta_id}',
                '{base_template_version}',
                {tc_record_count},
                'ACTIVE',
                '{created_by}',
                current_timestamp(),
                '{created_by}',
                current_timestamp(),
                NULL,
                'UI DTA Creation',
                NULL
            )
        """
        client.execute_query(tc_version_insert)
        print(f"  ✓ Test concepts version registered: {draft_version}")
    
    # Log version creation activity
    activity_type = "CLONED_FROM" if source_dta_id else "DRAFT_CREATED"
    log_version_event(
        dta_id=dta_id,
        activity_type=activity_type,
        version=draft_version,
        performed_by=created_by,
        parent_version=base_template_version,
        source_dta_number=source_dta_number,
        source_dta_name=source_dta_name
    )
    print(f"  ✓ Activity logged: {activity_type}")
    
    print(f"=" * 60)
    print(f"DTA CREATION COMPLETE!")
    print(f"  DTA: {dta_number} ({dta_id})")
    print(f"  Version: {draft_version}")
    print(f"  Transfer Variables: {record_count}")
    print(f"  Test Concepts: {tc_record_count}")
    print(f"  OA Tables Created: {oa_tables_created}")
    print(f"  OA Data: parent={oa_record_count}, attr={oa_attr_count}, options={oa_options_count}, other={oa_other_count}")
    print(f"=" * 60)
    
    return {
        "dta_id": dta_id,
        "dta_number": dta_number,
        "dta_name": dta_name,
        "version": draft_version,
        "trial_id": trial_id,
        "data_stream_type": data_stream_type,
        "data_provider_name": data_provider_name,
        "status": "DRAFT",
        "workflow_state": "NOT_STARTED",
        "record_count": record_count,
        "tc_record_count": tc_record_count,
        "oa_tables_created": oa_tables_created,
        "oa_record_count": oa_record_count,
        "oa_attr_count": oa_attr_count,
        "oa_options_count": oa_options_count,
        "oa_other_count": oa_other_count,
        "base_template_version": base_template_version
    }


@dta_bp.route('/create', methods=['POST'])
def api_create_dta():
    """
    Create a new DTA draft with complete entity setup.
    
    Request body:
        - trial_id: Required trial ID
        - data_stream_type: Required data stream type  
        - data_provider_name: Required provider name
        - versions: Optional dict of library type -> version tag to use
        - source_dta_id: Optional DTA ID to clone from
        - notes: Optional notes
        
    Returns:
        JSON with created DTA details including redirect URL
    """
    try:
        data = request.get_json() or {}
        
        # Validate required fields
        trial_id = data.get('trial_id', '').strip()
        data_stream = data.get('data_stream_type', '').strip()
        provider = data.get('data_provider_name', '').strip()
        
        if not trial_id or not data_stream or not provider:
            return jsonify({
                "success": False,
                "error": "Trial ID, Data Stream, and Provider are required"
            }), 400
        
        # Get optional fields
        source_dta_id = data.get('source_dta_id', '').strip() or None
        versions = data.get('versions', {})
        notes = data.get('notes', '').strip() or None
        
        # Get current user (in production, from auth)
        # For now, use a placeholder
        created_by = data.get('created_by', 'ui_user@jnj.com')
        
        # Create the complete DTA
        result = create_dta_complete(
            trial_id=trial_id,
            data_stream_type=data_stream,
            data_provider_name=provider,
            created_by=created_by,
            source_dta_id=source_dta_id,
            versions=versions,
            notes=notes
        )
        
        return jsonify({
            "success": True,
            "data": result,
            "redirect_url": f"/clone-dta/{result['dta_id']}"
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@dta_bp.route('/<dta_id>/update-name', methods=['POST'])
def api_update_dta_name(dta_id):
    """
    Update the user-friendly DTA name.
    
    Request body:
        - dta_name: New DTA name
        
    Returns:
        JSON with success status
    """
    try:
        data = request.get_json() or {}
        new_name = data.get('dta_name', '').strip()
        
        if not new_name:
            return jsonify({"ok": False, "msg": "DTA name is required"}), 400
        
        config = _get_db_config()
        client = _get_sql_client()
        
        dta_table = f"{config['catalog']}.{config['gold_schema']}.dta"
        
        # Escape single quotes
        escaped_name = new_name.replace("'", "''")
        
        update_sql = f"""
            UPDATE {dta_table}
            SET dta_name = '{escaped_name}',
                last_updated_ts = current_timestamp()
            WHERE dta_id = '{dta_id}'
        """
        
        client.execute_query(update_sql)
        
        print(f"Updated DTA {dta_id} name to: {new_name}")
        
        return jsonify({
            "ok": True,
            "msg": "DTA name updated successfully",
            "dta_name": new_name
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "msg": str(e)}), 500


# ============================================================================
# DTA EXPORT
# ============================================================================

@dta_bp.route('/<dta_id>/export', methods=['GET'])
def api_export_dta(dta_id):
    """
    Trigger DTA export job and return job run ID.
    
    The export job generates an Excel file with:
        - DTA Summary
        - Version History
        - Transfer Variables (by domain)
        - Test Concepts (by domain)
    
    Query Parameters:
        - export_type: tsDTA (default), oa (future), dta_full (future)
        - source_root: Volume path root (default: clinical_data_standards/test)
        
    Returns:
        JSON with job_run_id and status URL
    """
    from flask import request
    import os
    
    try:
        # Get export parameters
        export_type = request.args.get('export_type', 'tsDTA')
        source_root = request.args.get('source_root', 'clinical_data_standards/test')
        
        config = _get_db_config()
        client = _get_sql_client()
        catalog = config['catalog']
        gold_schema = config['gold_schema']
        
        # Verify DTA exists
        dta_query = f"""
            SELECT dta_id, dta_number, dta_name FROM {catalog}.{gold_schema}.dta
            WHERE dta_id = '{dta_id}'
        """
        dta_result = client.execute_query(dta_query)
        if not dta_result:
            return jsonify({"error": "DTA not found"}), 404
        
        dta = dict(dta_result[0])
        dta_number = dta.get('dta_number', 'DTA')
        
        # Trigger the export job
        from databricks.sdk import WorkspaceClient
        
        w = WorkspaceClient()
        
        # Find the export job (same pattern as upload_api.py)
        job_name = os.environ.get("EXPORT_JOB_NAME", "job_cdm_export_file")
        job_id = None
        found_job_name = None
        
        # First try exact match
        for job in w.jobs.list(name=job_name):
            job_id = job.job_id
            found_job_name = job.settings.name
            print(f"EXPORT: Found exact match - Job ID: {job_id}, Name: {found_job_name}")
            break
        
        # If not found, search for jobs containing the name (dev mode has prefix)
        if not job_id:
            print(f"EXPORT: Exact match not found, searching for jobs containing '{job_name}'...")
            for job in w.jobs.list(expand_tasks=False):
                if job_name in job.settings.name:
                    job_id = job.job_id
                    found_job_name = job.settings.name
                    print(f"EXPORT: Found pattern match - Job ID: {job_id}, Name: {found_job_name}")
                    break
        
        if not job_id:
            # Fall back to JSON export (inline)
            print(f"EXPORT: Job '{job_name}' not found, falling back to JSON export")
            return _export_dta_json(dta_id, client, config)
        
        # Run the job with parameters
        run = w.jobs.run_now(
            job_id=job_id,
            job_parameters={
                "dta_id": dta_id,
                "export_type": export_type,
                "source_root": source_root,
                "catalog_override": catalog
            }
        )
        
        print(f"Started export job run: {run.run_id} for job: {found_job_name}")
        
        # Get run details with full URL from SDK (consistent with upload_api.py)
        run_details = w.jobs.get_run(run_id=run.run_id)
        status_url = run_details.run_page_url
        
        return jsonify({
            "success": True,
            "message": f"Export started for {dta_number}",
            "job_run_id": run.run_id,
            "job_id": job_id,
            "status_url": status_url,
            "dta_number": dta_number,
            "export_type": export_type
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        # Fall back to JSON export on error
        try:
            return _export_dta_json(dta_id, _get_sql_client(), _get_db_config())
        except:
            return jsonify({"error": str(e)}), 500


def _export_dta_json(dta_id, client, config):
    """Fallback: Export DTA data as JSON file download."""
    from flask import Response
    
    catalog = config['catalog']
    gold_schema = config['gold_schema']
    silver_schema = config['silver_schema']
    
    # Get DTA details
    dta_query = f"""
        SELECT * FROM {catalog}.{gold_schema}.dta
        WHERE dta_id = '{dta_id}'
    """
    dta_result = client.execute_query(dta_query)
    if not dta_result:
        return jsonify({"error": "DTA not found"}), 404
    
    dta = dict(dta_result[0])
    dta_number = dta.get('dta_number', 'DTA')
    
    # Convert timestamps to strings
    for key, val in dta.items():
        if hasattr(val, 'isoformat'):
            dta[key] = val.isoformat()
    
    # Get Transfer Variables
    tv_query = f"""
        SELECT * FROM {catalog}.{silver_schema}.md_dta_transfer_variables_draft
        WHERE dta_id = '{dta_id}'
        ORDER BY COALESCE(transfer_variable_order, 9999)
    """
    tv_result = client.execute_query(tv_query)
    transfer_variables = []
    if tv_result:
        for row in tv_result:
            tv = dict(row)
            for key, val in tv.items():
                if hasattr(val, 'isoformat'):
                    tv[key] = val.isoformat()
            transfer_variables.append(tv)
    
    # Get Test Concepts
    tc_query = f"""
        SELECT * FROM {catalog}.{silver_schema}.md_dta_vendor_test_concepts_draft
        WHERE dta_id = '{dta_id}'
        ORDER BY test_concept_reference
    """
    tc_result = client.execute_query(tc_query)
    test_concepts = []
    if tc_result:
        for row in tc_result:
            tc = dict(row)
            for key, val in tc.items():
                if hasattr(val, 'isoformat'):
                    tc[key] = val.isoformat()
            test_concepts.append(tc)
    
    # Build export object
    export_data = {
        "export_timestamp": datetime.now().isoformat(),
        "dta": dta,
        "transfer_variables": transfer_variables,
        "transfer_variables_count": len(transfer_variables),
        "test_concepts": test_concepts,
        "test_concepts_count": len(test_concepts)
    }
    
    # Create JSON response as file download
    json_data = json.dumps(export_data, indent=2, default=str)
    
    filename = f"{dta_number}_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    
    return Response(
        json_data,
        mimetype='application/json',
        headers={
            'Content-Disposition': f'attachment; filename={filename}'
        }
    )


@dta_bp.route('/<dta_id>/export/status/<run_id>', methods=['GET'])
def api_export_status(dta_id, run_id):
    """
    Check status of export job run.
    
    Returns:
        JSON with job run status and result
    """
    import os
    
    try:
        from databricks.sdk import WorkspaceClient
        
        w = WorkspaceClient()
        run = w.jobs.get_run(run_id=int(run_id))
        
        status = run.state.life_cycle_state.value if run.state else "UNKNOWN"
        result = run.state.result_state.value if run.state and run.state.result_state else None
        
        response = {
            "run_id": run_id,
            "status": status,
            "result": result,
            "is_complete": status in ["TERMINATED", "SKIPPED", "INTERNAL_ERROR"]
        }
        
        # If complete and successful, get the export path from task values
        if status == "TERMINATED" and result == "SUCCESS":
            try:
                # Try to get output from the task
                for task in run.tasks or []:
                    if task.task_key == "export_file" and task.state.result_state.value == "SUCCESS":
                        response["export_complete"] = True
                        break
            except:
                pass
        
        return jsonify(response)
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


# ============================================================================
# DTA DELETE / ARCHIVE
# ============================================================================

def _execute_safe(client, query, description=""):
    """Execute a query safely, logging errors but not failing."""
    try:
        client.execute_query(query)
        print(f"  ✓ {description or query[:60]}...")
        return True
    except Exception as e:
        print(f"  ⚠ Warning ({description}): {str(e)[:80]}")
        return False


def archive_dta_with_metadata(client, config: dict, dta_id: str, dta_number: str, user: str = "system"):
    """
    Archive a DTA and all associated metadata using SCD Type 2 pattern.
    
    Sets effective_end_ts and is_current=false on:
        - DTA entity
        - Transfer Variables (gold)
        - Test Concepts (gold)
        - Version Registry entries
        - Silver draft tables (is_current_draft=false)
    
    Logs all actions to activity log.
    
    Args:
        client: SQL client
        config: Database config
        dta_id: DTA ID to archive
        dta_number: DTA number for logging
        user: User performing the action
        
    Returns:
        dict with summary of archived records
    """
    catalog = config['catalog']
    gold = config['gold_schema']
    silver = config['silver_schema']
    
    archived_counts = {}
    
    print(f"Archiving DTA {dta_number} ({dta_id}) with all metadata...")
    
    # 1. Archive DTA entity (SCD Type 2) - use status instead of is_current
    dta_query = f"""
        UPDATE {catalog}.{gold}.dta
        SET status = 'ARCHIVED',
            effective_end_ts = current_timestamp(),
            last_updated_ts = current_timestamp(),
            last_updated_by_principal = '{user}'
        WHERE dta_id = '{dta_id}'
          AND status != 'ARCHIVED'
    """
    _execute_safe(client, dta_query, "Archive DTA entity")
    archived_counts['dta'] = 1
    
    # 2. Archive Gold Transfer Variables (SCD Type 2)
    tv_gold_query = f"""
        UPDATE {catalog}.{gold}.md_dta_transfer_variables
        SET effective_end_ts = current_timestamp(),
            is_current = false,
            last_updated_ts = current_timestamp()
        WHERE dta_id = '{dta_id}'
          AND (is_current = true OR is_current IS NULL)
    """
    _execute_safe(client, tv_gold_query, "Archive Gold Transfer Variables")
    
    # Get count
    try:
        count_result = client.execute_query(
            f"SELECT COUNT(*) as cnt FROM {catalog}.{gold}.md_dta_transfer_variables WHERE dta_id = '{dta_id}'"
        )
        archived_counts['transfer_variables_gold'] = count_result[0]['cnt'] if count_result else 0
    except:
        archived_counts['transfer_variables_gold'] = 0
    
    # 3. Archive Gold Test Concepts (SCD Type 2)
    tc_gold_query = f"""
        UPDATE {catalog}.{gold}.md_dta_vendor_test_concepts
        SET effective_end_ts = current_timestamp(),
            is_current = false,
            last_updated_ts = current_timestamp()
        WHERE dta_id = '{dta_id}'
          AND (is_current = true OR is_current IS NULL)
    """
    _execute_safe(client, tc_gold_query, "Archive Gold Test Concepts")
    
    # Get count
    try:
        count_result = client.execute_query(
            f"SELECT COUNT(*) as cnt FROM {catalog}.{gold}.md_dta_vendor_test_concepts WHERE dta_id = '{dta_id}'"
        )
        archived_counts['test_concepts_gold'] = count_result[0]['cnt'] if count_result else 0
    except:
        archived_counts['test_concepts_gold'] = 0
    
    # 4. Archive Silver Draft Transfer Variables
    tv_silver_query = f"""
        UPDATE {catalog}.{silver}.md_dta_transfer_variables_draft
        SET is_current_draft = false,
            last_updated_ts = current_timestamp()
        WHERE dta_id = '{dta_id}'
          AND (is_current_draft = true OR is_current_draft IS NULL)
    """
    _execute_safe(client, tv_silver_query, "Archive Silver Transfer Variables")
    
    # 5. Archive Silver Draft Test Concepts
    tc_silver_query = f"""
        UPDATE {catalog}.{silver}.md_dta_vendor_test_concepts_draft
        SET is_current_draft = false,
            last_updated_ts = current_timestamp()
        WHERE dta_id = '{dta_id}'
          AND (is_current_draft = true OR is_current_draft IS NULL)
    """
    _execute_safe(client, tc_silver_query, "Archive Silver Test Concepts")
    
    # 6. Archive Version Registry entries (set effective_end_ts when ARCHIVED)
    registry_query = f"""
        UPDATE {catalog}.{gold}.md_version_registry
        SET status = 'ARCHIVED',
            effective_end_ts = current_timestamp(),
            last_updated_ts = current_timestamp()
        WHERE dta_id = '{dta_id}'
          AND status != 'ARCHIVED'
    """
    _execute_safe(client, registry_query, "Archive Version Registry")
    
    # 7. Log activity
    try:
        from api.activity_log_api import log_activity
        log_activity(
            client=client,
            config=config,
            dta_id=dta_id,
            activity_type="DTA_ARCHIVED",
            description=f"DTA {dta_number} archived with all metadata",
            details={
                "archived_counts": archived_counts,
                "archived_by": user
            }
        )
    except Exception as e:
        print(f"  ⚠ Warning logging activity: {str(e)[:80]}")
    
    print(f"✓ DTA {dta_number} archived successfully: {archived_counts}")
    return archived_counts


@dta_bp.route('/<dta_id>', methods=['DELETE'])
def api_delete_dta(dta_id):
    """
    Delete or Archive a DTA based on its status.
    
    - DRAFT DTAs: Hard delete (remove all data)
    - APPROVED/TEMPLATE DTAs: Soft delete using SCD Type 2 (archive with effective_end_ts)
    
    All actions are logged to the activity log.
        
    Returns:
        JSON with success status
    """
    try:
        config = _get_db_config()
        client = _get_sql_client()
        catalog = config['catalog']
        gold_schema = config['gold_schema']
        silver_schema = config['silver_schema']
        
        # Get DTA details
        dta_query = f"""
            SELECT dta_id, dta_number, dta_name, status, workflow_state 
            FROM {catalog}.{gold_schema}.dta
            WHERE dta_id = '{dta_id}'
        """
        dta_result = client.execute_query(dta_query)
        if not dta_result:
            return jsonify({"error": "DTA not found"}), 404
        
        dta = dict(dta_result[0])
        dta_number = dta.get('dta_number')
        status = (dta.get('status') or '').upper()
        
        # Current user (would come from session in production)
        current_user = "system"
        
        # Determine action based on status
        is_draft = status == 'DRAFT'
        
        if is_draft:
            # ============================================
            # HARD DELETE for DRAFT DTAs
            # ============================================
            print(f"Hard deleting DRAFT DTA {dta_number} ({dta_id})...")
            
            # Log activity BEFORE deletion
            try:
                from api.activity_log_api import log_activity
                log_activity(
                    client=client,
                    config=config,
                    dta_id=dta_id,
                    activity_type="DTA_DELETED",
                    description=f"DRAFT DTA {dta_number} permanently deleted",
                    details={"status": status, "deleted_by": current_user}
                )
            except Exception as e:
                print(f"  ⚠ Warning logging activity: {str(e)[:80]}")
            
            # Delete in order (child tables first)
            delete_queries = [
                (f"DELETE FROM {catalog}.{silver_schema}.md_dta_transfer_variables_draft WHERE dta_id = '{dta_id}'", "Silver Transfer Variables"),
                (f"DELETE FROM {catalog}.{silver_schema}.md_dta_vendor_test_concepts_draft WHERE dta_id = '{dta_id}'", "Silver Test Concepts"),
                (f"DELETE FROM {catalog}.{gold_schema}.dta_approval_task WHERE dta_workflow_id IN (SELECT dta_workflow_id FROM {catalog}.{gold_schema}.dta_workflow WHERE dta_id = '{dta_id}')", "Approval Tasks"),
                (f"DELETE FROM {catalog}.{gold_schema}.dta_workflow WHERE dta_id = '{dta_id}'", "Workflows"),
                (f"DELETE FROM {catalog}.{gold_schema}.dta_activity_log WHERE dta_id = '{dta_id}'", "Activity Logs"),
                (f"DELETE FROM {catalog}.{gold_schema}.md_version_registry WHERE dta_id = '{dta_id}'", "Version Registry"),
                (f"DELETE FROM {catalog}.{gold_schema}.dta WHERE dta_id = '{dta_id}'", "DTA Entity")
            ]
            
            for query, desc in delete_queries:
                _execute_safe(client, query, desc)
            
            print(f"✓ DRAFT DTA {dta_number} deleted successfully")
            
            return jsonify({
                "ok": True,
                "action": "deleted",
                "message": f"Draft DTA {dta_number} deleted successfully",
                "dta_id": dta_id,
                "dta_number": dta_number
            })
        
        else:
            # ============================================
            # SOFT DELETE (ARCHIVE) for APPROVED/TEMPLATE DTAs
            # Using SCD Type 2 pattern
            # ============================================
            archived_counts = archive_dta_with_metadata(
                client=client,
                config=config,
                dta_id=dta_id,
                dta_number=dta_number,
                user=current_user
            )
            
            return jsonify({
                "ok": True,
                "action": "archived",
                "message": f"DTA {dta_number} archived successfully",
                "dta_id": dta_id,
                "dta_number": dta_number,
                "archived_counts": archived_counts
            })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


# ============================================================================
# STUDY MANAGEMENT FUNCTIONS
# ============================================================================

def get_studies(client, config: dict) -> list:
    """
    Fetch all studies from the md_study table in gold schema.
    
    Args:
        client: SQL client
        config: Database config with catalog and gold_schema
        
    Returns:
        List of study dictionaries with study_id, study_title, created_ts
    """
    catalog = config['catalog']
    gold_schema = config['gold_schema']
    study_table = f"{catalog}.{gold_schema}.md_study"
    
    # Check if table exists
    try:
        check_query = f"SHOW TABLES IN {catalog}.{gold_schema} LIKE 'md_study'"
        result = client.execute_query(check_query, raise_on_error=False)
        if not result:
            print(f"Study table {study_table} does not exist yet")
            return []
    except Exception as e:
        print(f"Error checking study table: {e}")
        return []
    
    # Fetch studies
    try:
        query = f"""
            SELECT 
                study_id,
                study_title,
                created_by_principal,
                CAST(created_ts AS STRING) as created_ts
            FROM {study_table}
            ORDER BY created_ts DESC
        """
        results = client.execute_query(query, raise_on_error=False)
        return results if results else []
    except Exception as e:
        print(f"Error fetching studies: {e}")
        return []


def create_mock_studies(client, config: dict) -> list:
    """
    Create the md_study table in gold schema and insert mock studies.
    
    Args:
        client: SQL client
        config: Database config with catalog and gold_schema
        
    Returns:
        List of created study dictionaries
    """
    catalog = config['catalog']
    gold_schema = config['gold_schema']
    study_table = f"{catalog}.{gold_schema}.md_study"
    
    # Create table if not exists
    create_ddl = f"""
        CREATE TABLE IF NOT EXISTS {study_table} (
            study_id STRING NOT NULL,
            study_title STRING,
            created_by_principal STRING,
            created_ts TIMESTAMP,
            last_updated_by_principal STRING,
            last_updated_ts TIMESTAMP
        ) USING DELTA
    """
    
    print(f"Creating study table: {study_table}")
    client.execute_query(create_ddl, raise_on_error=True)
    print(f"✓ Table created/exists: {study_table}")
    
    # Define mock studies
    mock_studies = [
        {
            "study_id": "VAC18193RSV300",
            "study_title": "A Phase 1b/2 Study of the Combination of Talquetamab and Teclistamab in Participants with Relapsed or Refractory Multiple Myeloma"
        },
        {
            "study_id": "78278343PCR1001",
            "study_title": "A Phase 3 Randomized, Double-Blind Study Evaluating the Efficacy and Safety of JNJ-78278343 in Adults with Moderate to Severe Ulcerative Colitis"
        }
    ]
    
    created_studies = []
    current_user = os.environ.get("DATABRICKS_USER", "system")
    
    for study in mock_studies:
        # Check if study already exists
        check_query = f"SELECT study_id FROM {study_table} WHERE study_id = '{study['study_id']}'"
        existing = client.execute_query(check_query, raise_on_error=False)
        
        if existing:
            print(f"  Study {study['study_id']} already exists, skipping")
            created_studies.append(study)
            continue
        
        # Insert study
        # Escape single quotes in title
        safe_title = study['study_title'].replace("'", "''")
        
        insert_query = f"""
            INSERT INTO {study_table} (
                study_id,
                study_title,
                created_by_principal,
                created_ts,
                last_updated_by_principal,
                last_updated_ts
            ) VALUES (
                '{study['study_id']}',
                '{safe_title}',
                '{current_user}',
                current_timestamp(),
                '{current_user}',
                current_timestamp()
            )
        """
        
        try:
            client.execute_query(insert_query, raise_on_error=True)
            print(f"  ✓ Created study: {study['study_id']}")
            created_studies.append(study)
        except Exception as e:
            print(f"  ⚠ Error creating study {study['study_id']}: {e}")
    
    print(f"✓ Created {len(created_studies)} mock studies")
    return created_studies

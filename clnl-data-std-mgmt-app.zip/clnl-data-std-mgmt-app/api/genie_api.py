# =============================================================================
# Genie API - Natural Language Search using Databricks Genie
# =============================================================================
# This module provides Flask API endpoints for AI-powered natural language
# search of DTAs and clinical metadata using Databricks Genie.
#
# Uses GenieWrapper from databricks_ai_bridge for clean API interaction.
#
# Prerequisites:
# 1. Create a Genie Space in Databricks with DTA tables
# 2. Set GENIE_SPACE_ID environment variable in app.yaml
# 3. Install databricks-ai-bridge package
# =============================================================================

import os
from datetime import datetime
from flask import Blueprint, request, jsonify

# Import GenieWrapper and GenieResponse from our wrapper module
from api.genie import GenieWrapper, GenieResponse

genie_bp = Blueprint('genie', __name__, url_prefix='/api/genie')


def _format_dta_for_ui(dta: dict) -> dict:
    """
    Format a DTA record for UI rendering.
    Applies the same formatting as Standard Search to ensure consistent display.
    
    - Formats timestamps to human-readable strings
    - Ensures count fields are integers
    - Adds metadata summary for backward compatibility
    """
    # Debug: Log input DTA fields
    print(f"[Genie Format] Input DTA keys: {list(dta.keys())}")
    print(f"[Genie Format] Input DTA values (first 10): {dict(list(dta.items())[:10])}")
    
    # Format timestamp
    last_updated_ts = dta.get("last_updated_ts", "")
    if last_updated_ts:
        try:
            if isinstance(last_updated_ts, str):
                # Try ISO format parsing
                dt = datetime.fromisoformat(last_updated_ts.replace("Z", "+00:00"))
            elif hasattr(last_updated_ts, 'strftime'):
                # Already a datetime object
                dt = last_updated_ts
            else:
                dt = None
            
            if dt:
                formatted_date = dt.strftime("%b %d, %Y")
            else:
                formatted_date = str(last_updated_ts)[:10] if last_updated_ts else "N/A"
        except:
            formatted_date = str(last_updated_ts)[:10] if last_updated_ts else "N/A"
    else:
        formatted_date = "N/A"
    
    # Ensure count fields are integers
    count_fields = [
        'transfer_variables_count', 'test_concepts_count', 'codelists_count',
        'operational_agreements_count', 'visits_timepoints_count', 
        'data_ingestion_params_count', 'data_ingestion_parameters_count'
    ]
    
    for field in count_fields:
        if field in dta:
            try:
                dta[field] = int(dta[field]) if dta[field] is not None else 0
            except (ValueError, TypeError):
                dta[field] = 0
    
    # Build metadata summary for backward compatibility
    metadata_summary = {}
    lib_types = ['transfer_variables', 'test_concepts', 'codelists', 
                 'operational_agreements', 'visits_timepoints', 'data_ingestion_params']
    
    for lib_type in lib_types:
        count = dta.get(f"{lib_type}_count", 0)
        if count and int(count) > 0:
            metadata_summary[lib_type] = {
                "version": dta.get(f"{lib_type}_version"),
                "record_count": int(count)
            }
    
    # Create formatted DTA record
    formatted_dta = {
        **dta,
        "last_updated": formatted_date,  # Add formatted date
        "metadata": metadata_summary if metadata_summary else None
    }
    
    # Debug: Log output
    print(f"[Genie Format] Output last_updated: {formatted_date}")
    print(f"[Genie Format] Output test_concepts_count: {formatted_dta.get('test_concepts_count')}")
    print(f"[Genie Format] Output metadata: {metadata_summary}")
    
    return formatted_dta


def _get_genie_config():
    """Get Genie configuration from environment."""
    return {
        'space_id': os.environ.get('GENIE_SPACE_ID', ''),
    }


def _detect_response_type(result: GenieResponse, dtas: list) -> str:
    """
    Detect if the response is a clarifying question, data response, or informational.
    
    Args:
        result: GenieResponse from poll_result()
        dtas: Parsed DTA records
    
    Returns:
        'data' - Response contains DTA results to display
        'clarification' - Genie is asking for more details
        'info' - Informational response without actionable data
        'empty' - No meaningful response
    """
    # Core DTA fields that identify a valid DTA record
    valid_dta_fields = {
        'dta_id', 'dta_number', 'trial_id', 'data_provider_name', 
        'data_stream_type', 'status', 'workflow_state', 'version'
    }
    
    # Clarification patterns - Genie is asking for more information
    clarification_patterns = [
        'please specify', 'please provide', 'could you',
        'can you clarify', 'more specific', 'which',
        'do you mean', 'are you looking for', 'would you like',
        'i need more information', 'please tell me',
        'can you be more', 'what exactly', 'to find relevant',
        'to find', 'specify', 'either'
    ]
    
    # First, validate that parsed "DTAs" are actually valid DTA records
    if dtas and len(dtas) > 0:
        valid_dtas = []
        for dta in dtas:
            # Check if record has at least one valid DTA field
            has_valid_field = any(key in dta for key in valid_dta_fields)
            
            if has_valid_field:
                valid_dtas.append(dta)
            else:
                # Check if any key in this record looks like a clarification message
                # This happens when Genie returns a clarification as a table
                for key in dta.keys():
                    key_lower = key.lower().replace('_', ' ')
                    if any(pattern in key_lower for pattern in clarification_patterns):
                        print(f"[Genie] Detected clarification in parsed record key: {key}")
                        return 'clarification'
                    
                    # Also check the value for clarification patterns
                    value = str(dta.get(key, '')).lower()
                    if any(pattern in value for pattern in clarification_patterns):
                        print(f"[Genie] Detected clarification in parsed record value: {value[:100]}")
                        return 'clarification'
        
        # If we have valid DTAs after filtering, it's a data response
        if valid_dtas:
            print(f"[Genie] Found {len(valid_dtas)} valid DTA records")
            return 'data'
    
    # Check the description for clarification patterns
    if result.description:
        desc_lower = result.description.lower()
        
        # Check for question marks combined with clarification patterns
        has_question = '?' in desc_lower
        has_clarification = any(p in desc_lower for p in clarification_patterns)
        
        if has_question and has_clarification:
            return 'clarification'
        
        # Even without question mark, strong clarification language
        if any(p in desc_lower for p in ['please specify', 'please provide', 'to find relevant']):
            return 'clarification'
    
    # Check the raw result for clarification patterns
    if result.result:
        result_lower = str(result.result).lower()
        if any(p in result_lower for p in ['please specify', 'to find relevant', 'either the data stream']):
            print(f"[Genie] Detected clarification in raw result")
            return 'clarification'
        # If there are non-empty results but no valid DTAs, might be info
        return 'info'
    
    # No description and no result
    return 'empty'


def _format_genie_response(result: GenieResponse, conversation_id: str) -> dict:
    """
    Format GenieResponse into API response format.
    
    Args:
        result: GenieResponse from poll_result()
        conversation_id: Conversation ID for follow-ups
    
    Returns:
        Dict with success, answer, sql, results, conversation_id, response_type
    """
    # Core DTA fields that identify a valid DTA record
    valid_dta_fields = {
        'dta_id', 'dta_number', 'trial_id', 'data_provider_name', 
        'data_stream_type', 'status', 'workflow_state', 'version'
    }
    
    # Parse results into DTA-compatible format if possible
    parsed_dtas = _parse_results_to_dtas(result.result) if result.result else []
    
    # Detect response type for UI handling
    response_type = _detect_response_type(result, parsed_dtas)
    
    # Filter to only include valid DTAs (with at least one core field) and format for UI
    valid_dtas = []
    if response_type == 'data':
        for dta in parsed_dtas:
            if any(key in dta for key in valid_dta_fields):
                # Format DTA for UI (date formatting, count normalization, metadata summary)
                formatted_dta = _format_dta_for_ui(dta)
                valid_dtas.append(formatted_dta)
        print(f"[Genie] Filtered and formatted {len(valid_dtas)} valid DTAs from {len(parsed_dtas)} parsed records")
    
    # Build the answer - prioritize description, then check result for text responses
    answer = result.description or ""
    
    # If no answer yet and it's a clarification, extract from result or parsed data
    if response_type == 'clarification' and not answer:
        if isinstance(result.result, str) and len(result.result) < 2000:
            # Plain text clarification response (not a markdown table)
            answer = result.result
            print(f"[Genie] Using raw result as clarification answer: {answer[:100]}...")
        elif parsed_dtas:
            # Extract clarification message from the parsed "record"
            for dta in parsed_dtas:
                for key, value in dta.items():
                    # The key or value likely contains the clarification
                    clarification_text = f"{key.replace('_', ' ')}: {value}" if value else key.replace('_', ' ')
                    answer = clarification_text
                    break
                break
    
    # Also handle info type where the result is plain text
    if response_type == 'info' and not answer and isinstance(result.result, str):
        answer = result.result
        print(f"[Genie] Using raw result as info answer: {answer[:100]}...")
    
    return {
        "success": True,
        "answer": answer,
        "sql": result.query or "",
        "results": result.result or "",
        "dtas": valid_dtas,
        "conversation_id": conversation_id,
        "result_count": len(valid_dtas),
        "response_type": response_type
    }


def _get_field_mappings():
    """Get the field mappings for normalizing column names."""
    return {
        # Core DTA fields
        'dta_id': ['dta_id'],
        'dta_number': ['dta_number'],
        'dta_name': ['dta_name'],
        'trial_id': ['trial_id'],
        'data_stream_type': ['data_stream_type', 'stream_type'],
        'data_provider_name': ['data_provider_name', 'provider_name', 'vendor'],
        'status': ['status'],
        'workflow_state': ['workflow_state'],
        'version': ['version', 'version'],
        'last_updated_ts': ['last_updated_ts', 'last_updated', 'updated_ts'],
        
        # Metadata entity counts (from Genie training queries)
        'transfer_variables_count': ['transfer_variables_count'],
        'test_concepts_count': ['test_concepts_count'],
        'codelists_count': ['codelists_count'],
        'visits_timepoints_count': ['visits_timepoints_count'],
        'operational_agreements_count': ['operational_agreements_count'],
        'data_ingestion_params_count': ['data_ingestion_params_count', 'data_ingestion_parameters_count'],
        
        # Legacy/other fields
        'transfer_variable_name': ['transfer_variable_name'],
        'record_count': ['record_count'],
        'version': ['version']
    }


def _map_record_to_dta(record: dict) -> dict:
    """Map a single record dict to DTA format using field mappings."""
    dta = {}
    field_mappings = _get_field_mappings()
    
    # Normalize keys to lowercase with underscores
    normalized_record = {k.lower().replace(' ', '_'): v for k, v in record.items()}
    
    for target, sources in field_mappings.items():
        for src in sources:
            # Allow 0 values (important for count fields) - only skip None and empty strings
            if src in normalized_record and normalized_record[src] is not None and normalized_record[src] != '':
                dta[target] = normalized_record[src]
                break
    
    # Include all other columns that weren't mapped
    for key, value in normalized_record.items():
        # Allow 0 values - only skip None and empty strings
        if key not in dta and value is not None and value != '':
            dta[key] = value
    
    return dta


def _map_records_to_dtas(records: list) -> list:
    """Map a list of record dicts to DTA format."""
    dtas = []
    for record in records:
        dta = _map_record_to_dta(record)
        if dta:
            dtas.append(dta)
    print(f"[Genie Parse] Mapped {len(dtas)} records to DTAs")
    if dtas:
        print(f"[Genie Parse] First DTA: {dtas[0]}")
    return dtas


def _parse_results_to_dtas(result_data) -> list:
    """
    Parse Genie result into DTA-compatible records.
    Handles multiple formats: markdown table, DataFrame, dict list, etc.
    
    Args:
        result_data: Result from GenieResponse.result (could be various formats)
    
    Returns:
        List of DTA records (or empty list if parsing fails)
    """
    if not result_data:
        print("[Genie Parse] No result data to parse")
        return []
    
    print(f"[Genie Parse] Input type: {type(result_data)}")
    print(f"[Genie Parse] Input value (first 500 chars): {str(result_data)[:500]}")
    
    try:
        # Handle DataFrame (pandas)
        if hasattr(result_data, 'to_dict'):
            print("[Genie Parse] Detected DataFrame, converting to records")
            records = result_data.to_dict('records')
            return _map_records_to_dtas(records)
        
        # Handle list of dicts
        if isinstance(result_data, list) and len(result_data) > 0 and isinstance(result_data[0], dict):
            print(f"[Genie Parse] Detected list of dicts with {len(result_data)} records")
            return _map_records_to_dtas(result_data)
        
        # Handle string (markdown table or other text format)
        if isinstance(result_data, str):
            result_markdown = result_data
            print(f"[Genie Parse] Detected string, attempting markdown parse")
            
            # Parse markdown table format
            lines = result_markdown.strip().split('\n')
            print(f"[Genie Parse] Number of lines: {len(lines)}")
            if len(lines) > 0:
                print(f"[Genie Parse] First line: {lines[0][:200]}")
            
            if len(lines) < 3:  # Need header, separator, and at least one data row
                print("[Genie Parse] Not enough lines for markdown table")
                return []
            
            # Extract headers (first line) - split by | keeping track of positions
            header_parts = lines[0].split('|')
            print(f"[Genie Parse] Raw header_parts: {header_parts[:10]}...")
            
            # Remove first and last empty parts (from leading/trailing |)
            if header_parts and not header_parts[0].strip():
                header_parts = header_parts[1:]
            if header_parts and not header_parts[-1].strip():
                header_parts = header_parts[:-1]
            
            # Check if first column is an index column (empty or row number column)
            has_index_column = len(header_parts) > 0 and not header_parts[0].strip()
            print(f"[Genie Parse] Has index column: {has_index_column}")
            
            # If there's an index column, skip it
            if has_index_column:
                header_parts = header_parts[1:]
            
            # Get ALL headers - strip whitespace but keep positions
            all_headers = [h.strip() for h in header_parts]
            print(f"[Genie Parse] All headers ({len(all_headers)}): {all_headers}")
            
            # Filter to only non-empty headers (with their original positions)
            header_positions = [(i, h) for i, h in enumerate(all_headers) if h]
            print(f"[Genie Parse] Header positions: {header_positions}")
            
            if not header_positions:
                print("[Genie Parse] No headers found")
                return []
            
            # Skip separator line (second line)
            # Parse data rows - use header positions to extract matching values
            records = []
            for line in lines[2:]:
                if not line.strip() or line.strip().startswith('|--'):
                    continue
                
                # Split by | - keep ALL parts to preserve column alignment
                value_parts = line.split('|')
                
                # Remove first and last empty parts (from leading/trailing |)
                if value_parts and not value_parts[0].strip():
                    value_parts = value_parts[1:]
                if value_parts and not value_parts[-1].strip():
                    value_parts = value_parts[:-1]
                
                # If there's an index column, skip the first part (row number)
                if has_index_column and len(value_parts) > 1:
                    value_parts = value_parts[1:]
                
                # Get all values, keeping positions
                all_values = [v.strip() if v.strip() else None for v in value_parts]
                
                print(f"[Genie Parse] All values ({len(all_values)}): {all_values[:5]}...")
                
                # Build record using header positions to get correct values
                record = {}
                for pos, header in header_positions:
                    if pos < len(all_values):
                        key = header.lower().replace(' ', '_')
                        record[key] = all_values[pos]
                
                if record:
                    records.append(record)
                    print(f"[Genie Parse] Created record with {len(record)} fields: {list(record.items())[:5]}...")
            
            print(f"[Genie Parse] Parsed {len(records)} records from markdown")
            return _map_records_to_dtas(records)
        
        print(f"[Genie Parse] Unknown result format: {type(result_data)}")
        return []
        
    except Exception as e:
        print(f"[Genie Parse] Error parsing results: {e}")
        import traceback
        traceback.print_exc()
        return []


# =============================================================================
# API Routes
# =============================================================================

@genie_bp.route('/search')
def genie_search():
    """
    Natural language search using Databricks Genie.
    
    Query params:
        - q: Natural language question about DTAs
    
    Returns:
        JSON with:
        - success: bool
        - answer: Genie's text response (.description)
        - sql: Generated SQL (.query)
        - results: Raw markdown results (.result)
        - dtas: Parsed DTA records for card display
        - conversation_id: For follow-up questions
    
    Example queries:
        - "Show me the latest DTA for Labs data from LabCorp"
        - "Which DTAs for trial VAC18193 are pending approval?"
        - "Find approved transfer variable definitions for ECG"
    """
    question = request.args.get('q', '').strip()
    
    if not question:
        return jsonify({
            "success": False,
            "error": "Please enter a question"
        })
    
    if len(question) < 5:
        return jsonify({
            "success": False,
            "error": "Please enter a more detailed question (at least 5 characters)"
        })
    
    config = _get_genie_config()
    
    if not config['space_id']:
        return jsonify({
            "success": False,
            "error": "Genie Space ID not configured. Please set GENIE_SPACE_ID in app.yaml.",
            "not_configured": True
        })
    
    try:
        print(f"[Genie] Asking: {question}")
        print(f"[Genie] Space ID: {config['space_id']}")
        
        # Initialize GenieWrapper
        genie = GenieWrapper(config['space_id'])
        
        # Ask the question and get response
        response = genie.ask_first_question(question)
        print(f"[Genie] Conversation ID: {genie.get_conversation_id(response)}")
        
        # Poll for result
        result = genie.poll_result(response)
        conversation_id = genie.get_conversation_id(response)
        
        # DEBUG: Log the GenieResponse details
        print(f"[Genie] ===== RESPONSE DEBUG =====")
        print(f"[Genie] Result type: {type(result)}")
        print(f"[Genie] Result attributes: {dir(result)}")
        print(f"[Genie] Description: {result.description[:200] if result.description else 'None'}...")
        print(f"[Genie] Query: {result.query[:200] if result.query else 'None'}...")
        print(f"[Genie] Result type: {type(result.result)}")
        print(f"[Genie] Result value: {str(result.result)[:500] if result.result else 'None'}...")
        print(f"[Genie] ===========================")
        
        # Format and return response
        formatted = _format_genie_response(result, conversation_id)
        print(f"[Genie] Parsed DTAs count: {len(formatted.get('dtas', []))}")
        if formatted.get('dtas'):
            print(f"[Genie] First DTA: {formatted['dtas'][0]}")
        return jsonify(formatted)
        
    except TimeoutError as e:
        print(f"[Genie] Timeout error: {e}")
        return jsonify({
            "success": False,
            "error": "Genie is taking too long to respond. Please try a simpler question."
        }), 504
        
    except ConnectionError as e:
        print(f"[Genie] Connection error: {e}")
        return jsonify({
            "success": False,
            "error": "Could not connect to Genie service. Please try again later."
        }), 503
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        error_msg = str(e)
        
        # Check for common error patterns and provide user-friendly messages
        if "timeout" in error_msg.lower() or "timed out" in error_msg.lower():
            return jsonify({
                "success": False,
                "error": "Genie is taking too long to respond. Please try a simpler question."
            }), 504
        elif "connection" in error_msg.lower() or "network" in error_msg.lower():
            return jsonify({
                "success": False,
                "error": "Could not connect to Genie service. Please try again later."
            }), 503
        elif "not found" in error_msg.lower() or "no data" in error_msg.lower():
            # This is actually a valid "0 results" case, not an error
            return jsonify({
                "success": True,
                "answer": "No matching DTAs found for your query.",
                "sql": "",
                "results": "",
                "dtas": [],
                "conversation_id": None,
                "result_count": 0
            })
        else:
            return jsonify({
                "success": False,
                "error": f"Genie service error: {error_msg}"
            }), 500


@genie_bp.route('/followup', methods=['POST'])
def genie_followup():
    """
    Send a follow-up question in an existing conversation.
    
    Request body:
        - conversation_id: Existing conversation ID
        - question: Follow-up question
    
    Returns:
        Same format as /search
    """
    data = request.get_json() or {}
    conversation_id = data.get('conversation_id', '').strip()
    question = data.get('question', '').strip()
    
    if not conversation_id:
        return jsonify({
            "success": False,
            "error": "conversation_id is required"
        })
    
    if not question:
        return jsonify({
            "success": False,
            "error": "question is required"
        })
    
    config = _get_genie_config()
    
    if not config['space_id']:
        return jsonify({
            "success": False,
            "error": "Genie Space ID not configured",
            "not_configured": True
        })
    
    try:
        print(f"[Genie] Follow-up: {question}")
        print(f"[Genie] Conversation: {conversation_id}")
        
        # Initialize GenieWrapper
        genie = GenieWrapper(config['space_id'])
        
        # Send follow-up question
        response = genie.ask_followup_question(question, conversation_id)
        
        # Poll for result
        result = genie.poll_result(response)
        
        # Format and return response
        return jsonify(_format_genie_response(result, conversation_id))
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@genie_bp.route('/status')
def genie_status():
    """
    Check Genie configuration and availability.
    
    Returns:
        JSON with configuration status
    """
    config = _get_genie_config()
    
    return jsonify({
        "configured": bool(config['space_id']),
        "space_id": config['space_id'][:8] + "..." if config['space_id'] else None,
        "message": "Genie is configured" if config['space_id'] else "GENIE_SPACE_ID not set"
    })

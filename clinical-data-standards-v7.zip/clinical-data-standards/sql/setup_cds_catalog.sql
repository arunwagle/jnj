
-- ============================================================================
-- Catalog and Schema Setup SQL
-- ============================================================================
-- Purpose: Create catalog, schemas, and volumes if they don't exist
-- Use Case: clinical_data_standards
--
-- Parameters (passed from job):
--   :catalog_name - The catalog to create/use
--
-- NOTE: Entity tables (dta, dta_workflow, md_file_history, etc.) are created
-- dynamically by notebooks on first write. This ensures schema consistency
-- between Python code and Delta tables.
-- ============================================================================

-- Create catalog if it doesn't exist
CREATE CATALOG IF NOT EXISTS IDENTIFIER(:catalog_name)
COMMENT 'Catalog for clinical_data_standards use case';

-- Set current catalog
USE CATALOG IDENTIFIER(:catalog_name);

-- Create Bronze schema (raw/landing zone)
CREATE SCHEMA IF NOT EXISTS bronze_md
COMMENT 'Bronze layer - raw ingestion of Trial-Specific Data Transfer Agreement (tsDTA) files including ZIP archives, Excel documents, Operational Agreements (Word), and Protocol documents. Contains document manifest, extraction status, and Excel sheet metadata.';

-- Create Silver schema (cleaned/processed)
CREATE SCHEMA IF NOT EXISTS silver_md
COMMENT 'Silver layer - normalized draft data extracted from tsDTA files. Contains work-in-progress transfer variable definitions, codelists, test concepts, and visits/timepoints that are being reviewed by J&J Data Acquisition Experts (DAEs) and vendors before approval.';

-- Create Gold schema (curated metadata library)
CREATE SCHEMA IF NOT EXISTS gold_md
COMMENT 'Gold layer - approved Data Transfer Agreement (DTA) entities and versioned metadata library. Contains the DTA master table, workflow tracking, version registry, and approved transfer variable definitions. This is the source of truth for production data transfer specifications.';

-- ============================================================================
-- Create Volumes for file storage
-- ============================================================================
-- Volume for clinical data standards files (ZIP archives, Excel files, etc.)
-- Path: /Volumes/<catalog>/bronze_md/clinical_data_standards/
CREATE VOLUME IF NOT EXISTS bronze_md.clinical_data_standards
COMMENT 'Volume for clinical data standards files - ZIP archives, Excel files, documents';

-- Display setup summary
SELECT 
  '✅ Setup Complete' as status,
  :catalog_name as catalog,
  'bronze_md, silver_md, gold_md' as schemas_created,
  'bronze_md.clinical_data_standards' as volume_created;

-- ============================================================================
-- ENTITY TABLES
-- ============================================================================
-- Entity tables are created dynamically by notebooks on first write:
--   - gold_md.dta (created by nb_create_dta_instance.ipynb)
--   - gold_md.dta_workflow (created by nb_create_dta_instance.ipynb)
--   - gold_md.dta_approval_task (created by nb_create_dta_instance.ipynb)
--   - gold_md.dta_activity_log (created by activity logging functions)
--   - gold_md.md_version_registry (created by versioning notebooks)
--   - gold_md.md_dta_transfer_variables (created by nb_version_approve_dta.ipynb)
--   - silver_md.md_dta_transfer_variables_draft (created by nb_tsdta_transfer_variables_processor.ipynb)
--   - bronze_md.md_file_history (created by nb_file_processor.ipynb)
--
-- This approach ensures:
--   1. Single source of truth for schema (Python code)
--   2. No sync issues between SQL and Python
--   3. Correct nullability and data types
--
-- After tables are created, run sql/add_table_comments.sql to add 
-- comprehensive descriptions for Genie AI integration.
-- ============================================================================

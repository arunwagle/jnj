"""
Pytest configuration and fixtures for {{.project_name}}
"""

import pytest
from pyspark.sql import SparkSession
from typing import Generator


@pytest.fixture(scope="session")
def spark() -> Generator[SparkSession, None, None]:
    """
    Create Spark session for testing
    
    Yields:
        SparkSession instance
    """
    spark = (
        SparkSession.builder
        .appName("{{.project_name}}-tests")
        .master("local[*]")
        .config("spark.sql.shuffle.partitions", "1")
        .config("spark.default.parallelism", "1")
        .config("spark.sql.warehouse.dir", "/tmp/spark-warehouse")
        .getOrCreate()
    )
    
    yield spark
    
    spark.stop()


@pytest.fixture
def sample_data(spark):
    """
    Create sample data for testing
    
    Args:
        spark: SparkSession fixture
        
    Returns:
        Sample DataFrame
    """
    data = [
        (1, "Alice", "2024-01-01", 100.0),
        (2, "Bob", "2024-01-02", 150.0),
        (3, "Charlie", "2024-01-03", 200.0),
    ]
    
    columns = ["id", "name", "date", "amount"]
    
    return spark.createDataFrame(data, columns)


@pytest.fixture
def test_config():
    """
    Test configuration
    
    Returns:
        Dictionary with test configuration
    """
    return {
        "catalog": "{{.catalog_name}}",
        "bronze_schema": "{{.bronze_schema}}",
        "silver_schema": "{{.silver_schema}}",
        "gold_schema": "{{.gold_schema}}",
        "usecase": "{{.usecase}}"
    }


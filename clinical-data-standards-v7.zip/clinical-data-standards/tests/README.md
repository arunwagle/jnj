# Tests for {{.project_name}}

Test suite for {{.project_name}} components.

## Structure

```
tests/
├── conftest.py              # Pytest configuration and fixtures
├── framework/               # Framework tests
│   ├── test_utils.py
├── ml/                      # ML tests
│   ├── test_feature_engineering.py
│   └── test_model_training.py
└── integration/             # Integration tests
    └── test_pipeline.py
```

## Running Tests

### All Tests

```bash
pytest tests/ -v
```

### Specific Test File

```bash
pytest tests/framework/test_utils.py -v
```

### With Coverage

```bash
pytest tests/ --cov=src --cov-report=html
```

### Integration Tests Only

```bash
pytest tests/integration/ -v -m databricks
```

## Test Markers

Tests are marked with the following markers:

- `@pytest.mark.unit`: Unit tests
- `@pytest.mark.integration`: Integration tests
- `@pytest.mark.slow`: Slow-running tests
- `@pytest.mark.databricks`: Tests requiring Databricks connection

Run specific markers:

```bash
# Only unit tests
pytest -m unit

# Exclude slow tests
pytest -m "not slow"
```

## Writing Tests

### Unit Tests

```python
def test_my_function(spark, sample_data):
    \"\"\"Test description\"\"\"
    result = my_function(sample_data)
    assert result.count() > 0
```

### Integration Tests

```python
@pytest.mark.integration
@pytest.mark.databricks
def test_pipeline_integration(spark):
    \"\"\"Test end-to-end pipeline\"\"\"
    # Test against actual Databricks workspace
    pass
```

## Fixtures

Common fixtures in `conftest.py`:

- `spark`: SparkSession for testing
- `sample_data`: Sample DataFrame
- `test_config`: Test configuration

## Best Practices

1. **Test Isolation**: Each test should be independent
2. **Clear Names**: Use descriptive test names
3. **One Assert**: Prefer one assertion per test
4. **Fast Tests**: Keep unit tests fast (<1s)
5. **Mock External**: Mock external dependencies
6. **Test Data**: Use minimal test data

## CI/CD Integration

Tests run automatically in CI/CD pipeline:
- On pull requests
- Before deployments
- On schedule (nightly)

See `cicd/` directory for pipeline configuration.


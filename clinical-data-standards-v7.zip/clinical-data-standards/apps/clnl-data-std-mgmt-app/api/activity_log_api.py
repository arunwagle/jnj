"""
DTA Activity Log API
====================
Provides functions for logging and retrieving DTA activity history.

Activity Categories:
- DATA_CHANGE: INSERT, UPDATE, DELETE, BULK_INSERT
- WORKFLOW: SUBMITTED_FOR_APPROVAL, APPROVED, REJECTED, REASSIGNED, RECALLED
- STATUS_CHANGE: STATUS_CHANGED
- VERSION: DRAFT_CREATED, DTA_APPROVED_CREATED, PROMOTED_TO_TEMPLATE, CLONED_FROM
"""

import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any


def _get_db_config():
    """Get database configuration from environment."""
    import os
    return {
        'catalog': os.environ.get('CATALOG_NAME', 'aira_test'),
        'gold_schema': os.environ.get('GOLD_SCHEMA', 'gold_md'),
        'silver_schema': os.environ.get('SILVER_SCHEMA', 'silver_md'),
        'bronze_schema': os.environ.get('BRONZE_SCHEMA', 'bronze_md')
    }


def _get_sql_client():
    """Get SQL client for database operations."""
    from api.dta_api import _get_sql_client as get_client
    return get_client()


def log_activity(
    dta_id: str,
    activity_category: str,
    activity_type: str,
    activity_summary: str,
    performed_by: str,
    library_type: str = None,
    entity_id: str = None,
    entity_name: str = None,
    field_name: str = None,
    old_value: str = None,
    new_value: str = None,
    workflow_iteration: int = None,
    approver_role: str = None,
    approver_name: str = None,
    comment: str = None,
    version: str = None,
    parent_version: str = None
) -> bool:
    """Log a single activity to the activity log table.
    
    Note: The dta_activity_log table must be created via setup_cds_catalog.sql
    before using this function.
    """
    try:
        config = _get_db_config()
        client = _get_sql_client()
        
        table_name = f"{config['catalog']}.{config['gold_schema']}.dta_activity_log"
        
        activity_id = str(uuid.uuid4())
        
        # Escape single quotes
        def escape(val):
            if val is None:
                return "NULL"
            return f"'{str(val).replace(chr(39), chr(39)+chr(39))}'"
        
        insert_sql = f"""
            INSERT INTO {table_name} (
                activity_id, dta_id, activity_category, activity_type,
                library_type, entity_id, entity_name, field_name,
                old_value, new_value,
                workflow_iteration, approver_role, approver_name, comment,
                version, parent_version,
                activity_summary, performed_by_principal, performed_ts
            ) VALUES (
                '{activity_id}',
                '{dta_id}',
                '{activity_category}',
                '{activity_type}',
                {escape(library_type)},
                {escape(entity_id)},
                {escape(entity_name)},
                {escape(field_name)},
                {escape(old_value)},
                {escape(new_value)},
                {workflow_iteration if workflow_iteration is not None else 'NULL'},
                {escape(approver_role)},
                {escape(approver_name)},
                {escape(comment)},
                {escape(version)},
                {escape(parent_version)},
                {escape(activity_summary)},
                '{performed_by}',
                current_timestamp()
            )
        """
        
        client.execute_query(insert_sql, raise_on_error=True)
        return True
        
    except Exception as e:
        print(f"Warning: Failed to log activity: {e}")
        return False


def log_bulk_insert(
    dta_id: str,
    library_type: str,
    record_count: int,
    performed_by: str,
    source_dta_id: str = None
) -> bool:
    """Log a bulk insert operation (e.g., initial import or clone)."""
    summary = f"{record_count} {library_type.replace('_', ' ')} imported"
    if source_dta_id:
        summary = f"{record_count} {library_type.replace('_', ' ')} cloned from DTA {source_dta_id[:8]}"
    
    return log_activity(
        dta_id=dta_id,
        activity_category="DATA_CHANGE",
        activity_type="BULK_INSERT",
        activity_summary=summary,
        performed_by=performed_by,
        library_type=library_type,
        entity_id=None,
        entity_name=None,
        comment=f"Source DTA: {source_dta_id}" if source_dta_id else None
    )


def log_field_update(
    dta_id: str,
    library_type: str,
    entity_id: str,
    entity_name: str,
    field_name: str,
    old_value: str,
    new_value: str,
    performed_by: str
) -> bool:
    """Log a single field update."""
    summary = f"Updated {field_name}: '{old_value}' → '{new_value}'"
    
    return log_activity(
        dta_id=dta_id,
        activity_category="DATA_CHANGE",
        activity_type="UPDATE",
        activity_summary=summary,
        performed_by=performed_by,
        library_type=library_type,
        entity_id=entity_id,
        entity_name=entity_name,
        field_name=field_name,
        old_value=old_value,
        new_value=new_value
    )


def log_workflow_event(
    dta_id: str,
    activity_type: str,  # SUBMITTED_FOR_APPROVAL, APPROVED, REJECTED, etc.
    performed_by: str,
    workflow_iteration: int = None,
    approver_role: str = None,
    approver_name: str = None,
    comment: str = None
) -> bool:
    """Log a workflow event."""
    summaries = {
        "SUBMITTED_FOR_APPROVAL": f"Submitted for approval",
        "APPROVED": f"Approved by {approver_name} ({approver_role})" if approver_name else "Approved",
        "REJECTED": f"Rejected by {approver_name} ({approver_role})" if approver_name else "Rejected",
        "REASSIGNED": f"Reassigned to {approver_name}" if approver_name else "Reassigned",
        "RECALLED": "Recalled from approval"
    }
    summary = summaries.get(activity_type, activity_type)
    if comment:
        summary = f"{summary}. Comment: {comment[:50]}..."
    
    return log_activity(
        dta_id=dta_id,
        activity_category="WORKFLOW",
        activity_type=activity_type,
        activity_summary=summary,
        performed_by=performed_by,
        workflow_iteration=workflow_iteration,
        approver_role=approver_role,
        approver_name=approver_name,
        comment=comment
    )


def log_version_event(
    dta_id: str,
    activity_type: str,  # DRAFT_CREATED, DTA_APPROVED_CREATED, PROMOTED_TO_TEMPLATE, CLONED_FROM
    version: str,
    performed_by: str,
    parent_version: str = None,
    source_dta_number: str = None,
    source_dta_name: str = None
) -> bool:
    """Log a version-related event."""
    # Build clone source description with both number and name
    clone_source = "unknown"
    if source_dta_number:
        clone_source = source_dta_number
        if source_dta_name:
            clone_source = f"{source_dta_number} - {source_dta_name}"
    
    summaries = {
        "DRAFT_CREATED": f"Draft version {version} created",
        "DTA_APPROVED_CREATED": f"DTA Major version {version} created",
        "PROMOTED_TO_TEMPLATE": f"Promoted to DTA Template version {version}",
        "CLONED_FROM": f"Created by cloning from {clone_source}"
    }
    summary = summaries.get(activity_type, f"Version {version} - {activity_type}")
    
    return log_activity(
        dta_id=dta_id,
        activity_category="VERSION",
        activity_type=activity_type,
        activity_summary=summary,
        performed_by=performed_by,
        version=version,
        parent_version=parent_version,
        comment=f"Source: {clone_source}" if source_dta_number else None
    )


def get_activity_history(dta_id: str) -> Dict[str, Any]:
    """Get complete activity history for a DTA."""
    try:
        config = _get_db_config()
        client = _get_sql_client()
        
        table_name = f"{config['catalog']}.{config['gold_schema']}.dta_activity_log"
        dta_table = f"{config['catalog']}.{config['gold_schema']}.dta"
        
        # Get DTA info
        dta_query = f"""
            SELECT dta_id, dta_number, dta_name, trial_id, data_stream_type, data_provider_name,
                   status, workflow_state, created_ts, created_by_principal
            FROM {dta_table}
            WHERE dta_id = '{dta_id}'
        """
        dta_results = client.execute_query(dta_query, raise_on_error=True)
        dta_info = dta_results[0] if dta_results else {}
        
        # Check if activity log table exists
        try:
            check_query = f"SELECT 1 FROM {table_name} LIMIT 1"
            client.execute_query(check_query, raise_on_error=True)
        except:
            # Table doesn't exist, return empty history
            return {
                'ok': True,
                'dta_info': {
                    'dta_id': dta_info.get('dta_id', dta_id),
                    'dta_number': dta_info.get('dta_number', ''),
                    'dta_name': dta_info.get('dta_name', ''),
                    'status': dta_info.get('status', ''),
                    'workflow_state': dta_info.get('workflow_state', ''),
                    'trial_id': dta_info.get('trial_id', ''),
                    'data_stream_type': dta_info.get('data_stream_type', ''),
                    'data_provider_name': dta_info.get('data_provider_name', ''),
                    'created_ts': str(dta_info.get('created_ts', '')),
                    'created_by': dta_info.get('created_by_principal', '')
                },
                'history': []
            }
        
        # Get activity history
        history_query = f"""
            SELECT 
                activity_id,
                activity_category,
                activity_type,
                library_type,
                entity_id,
                entity_name,
                field_name,
                old_value,
                new_value,
                workflow_iteration,
                approver_role,
                approver_name,
                comment,
                version,
                parent_version,
                activity_summary,
                performed_by_principal,
                performed_ts,
                DATE_TRUNC('minute', performed_ts) as activity_batch
            FROM {table_name}
            WHERE dta_id = '{dta_id}'
            ORDER BY performed_ts DESC
        """
        
        results = client.execute_query(history_query, raise_on_error=True)
        
        # Group by timestamp batch (within same minute)
        batches = {}
        for row in results or []:
            batch_key = str(row.get('activity_batch', ''))
            if batch_key not in batches:
                batches[batch_key] = {
                    'timestamp': str(row.get('performed_ts', '')),
                    'user': row.get('performed_by_principal', 'Unknown'),
                    'activities': []
                }
            
            batches[batch_key]['activities'].append({
                'activity_id': row.get('activity_id'),
                'category': row.get('activity_category'),
                'type': row.get('activity_type'),
                'library_type': row.get('library_type'),
                'entity_id': row.get('entity_id'),
                'entity_name': row.get('entity_name'),
                'field_name': row.get('field_name'),
                'old_value': row.get('old_value'),
                'new_value': row.get('new_value'),
                'approver_role': row.get('approver_role'),
                'approver_name': row.get('approver_name'),
                'version': row.get('version'),
                'summary': row.get('activity_summary')
            })
        
        # Convert to sorted list
        history_list = []
        for batch_key in sorted(batches.keys(), reverse=True):
            batch = batches[batch_key]
            
            # Categorize activities
            data_changes = [a for a in batch['activities'] if a['category'] == 'DATA_CHANGE']
            workflow_events = [a for a in batch['activities'] if a['category'] == 'WORKFLOW']
            version_events = [a for a in batch['activities'] if a['category'] == 'VERSION']
            
            history_list.append({
                'timestamp': batch['timestamp'],
                'user': batch['user'],
                'data_changes': data_changes,
                'workflow_events': workflow_events,
                'version_events': version_events,
                'total_activities': len(batch['activities'])
            })
        
        return {
            'ok': True,
            'dta_info': {
                'dta_id': dta_info.get('dta_id', dta_id),
                'dta_number': dta_info.get('dta_number', ''),
                'dta_name': dta_info.get('dta_name', ''),
                'status': dta_info.get('status', ''),
                'workflow_state': dta_info.get('workflow_state', ''),
                'trial_id': dta_info.get('trial_id', ''),
                'data_stream_type': dta_info.get('data_stream_type', ''),
                'data_provider_name': dta_info.get('data_provider_name', ''),
                'created_ts': str(dta_info.get('created_ts', '')),
                'created_by': dta_info.get('created_by_principal', '')
            },
            'history': history_list
        }
        
    except Exception as e:
        print(f"Error getting activity history: {e}")
        import traceback
        traceback.print_exc()
        return {'ok': False, 'msg': str(e), 'history': []}


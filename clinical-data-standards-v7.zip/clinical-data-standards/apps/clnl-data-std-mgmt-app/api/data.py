"""
Mock Data Storage for DTA Studio
This module contains all mock data and helper functions.
In production, this would be replaced with actual database/service calls.
"""

from datetime import datetime
import json

# ============================================================================
# Mock Data - Ingestion Jobs
# ============================================================================

MOCK_RUNS = [
    { 
        "databricks_job_id": "job_12345678",
        "databricks_run_id": "run_987654321",
        "document_type": "Protocol",
        "file_name": "Clinical_Protocol_TRIAL-ABC_v3.2.pdf",
        "file_type": "PDF",
        "size": "2.4 MB",
        "start_time": "2025-10-28 10:01:23",
        "end_time": "2025-10-28 10:13:45",
        "duration": "12m 22s",
        "status": "success",
        "entities": {
            "metadata": True,
            "visits_timepoints": 12,
            "transfer_variables": 45,
            "test_concepts": 28,
            "code_lists": 8,
            "data_ingestion_parameters": 16
        }
    },
    { 
        "databricks_job_id": "job_23456789",
        "databricks_run_id": "run_876543210",
        "document_type": "Operational Agreement",
        "file_name": "Operational_Agreement_VEND-2_2025.docx",
        "file_type": "Word",
        "size": "856 KB",
        "start_time": "2025-10-28 11:20:10",
        "end_time": "2025-10-28 11:39:33",
        "duration": "19m 23s",
        "status": "running",
        "entities": {
            "metadata": True,
            "visits_timepoints": 0,
            "transfer_variables": 0,
            "test_concepts": 0,
            "code_lists": 0,
            "data_ingestion_parameters": 0
        }
    },
    { 
        "databricks_job_id": "job_34567890",
        "databricks_run_id": "run_765432109",
        "document_type": "Historical DTA",
        "file_name": "Historical_DTA_TRIAL-ABC_LB_Q3_2024.xlsx",
        "file_type": "Excel",
        "size": "5.7 MB",
        "start_time": "2025-10-27 09:00:15",
        "end_time": "2025-10-27 09:14:42",
        "duration": "14m 27s",
        "status": "failed",
        "entities": {
            "metadata": False,
            "visits_timepoints": 0,
            "transfer_variables": 0,
            "test_concepts": 0,
            "code_lists": 0
        }
    },
    { 
        "databricks_job_id": "job_45678901",
        "databricks_run_id": "run_654321098",
        "document_type": "Protocol",
        "file_name": "Clinical_Protocol_TRIAL-XYZ_v2.1.pdf",
        "file_type": "PDF",
        "size": "3.1 MB",
        "start_time": "2025-10-26 14:30:00",
        "end_time": "2025-10-26 14:45:12",
        "duration": "15m 12s",
        "status": "success",
        "entities": {
            "metadata": True,
            "visits_timepoints": 8,
            "transfer_variables": 32,
            "test_concepts": 18,
            "code_lists": 5,
            "data_ingestion_parameters": 16
        }
    },
    { 
        "databricks_job_id": "job_56789012",
        "databricks_run_id": "run_543210987",
        "document_type": "Operational Agreement",
        "file_name": "Operational_Agreement_VEND-5_2025.docx",
        "file_type": "Word",
        "size": "1.2 MB",
        "start_time": "2025-10-26 08:15:30",
        "end_time": "2025-10-26 08:32:45",
        "duration": "17m 15s",
        "status": "success",
        "entities": {
            "metadata": True,
            "visits_timepoints": 15,
            "transfer_variables": 52,
            "test_concepts": 35,
            "code_lists": 12,
            "data_ingestion_parameters": 16
        }
    },
    { 
        "databricks_job_id": "job_67890123",
        "databricks_run_id": "run_432109876",
        "document_type": "Historical DTA",
        "file_name": "Historical_DTA_TRIAL-DEF_AE_Q2_2024.xlsx",
        "file_type": "Excel",
        "size": "4.3 MB",
        "start_time": "2025-10-25 16:00:00",
        "end_time": "2025-10-25 16:11:22",
        "duration": "11m 22s",
        "status": "success",
        "entities": {
            "metadata": True,
            "visits_timepoints": 6,
            "transfer_variables": 38,
            "test_concepts": 22,
            "code_lists": 6,
            "data_ingestion_parameters": 16
        }
    },
    { 
        "databricks_job_id": "job_78901234",
        "databricks_run_id": "run_321098765",
        "document_type": "Protocol",
        "file_name": "Clinical_Protocol_TRIAL-GHI_v1.5.pdf",
        "file_type": "PDF",
        "size": "1.8 MB",
        "start_time": "2025-10-25 11:45:00",
        "end_time": "2025-10-25 11:58:33",
        "duration": "13m 33s",
        "status": "failed",
        "entities": {
            "metadata": False,
            "visits_timepoints": 0,
            "transfer_variables": 0,
            "test_concepts": 0,
            "code_lists": 0,
            "data_ingestion_parameters": 0
        }
    },
    { 
        "databricks_job_id": "job_89012345",
        "databricks_run_id": "run_210987654",
        "document_type": "Operational Agreement",
        "file_name": "Operational_Agreement_VEND-8_2025.docx",
        "file_type": "Word",
        "size": "920 KB",
        "start_time": "2025-10-24 13:20:15",
        "end_time": "2025-10-24 13:38:45",
        "duration": "18m 30s",
        "status": "success",
        "entities": {
            "metadata": True,
            "visits_timepoints": 10,
            "transfer_variables": 41,
            "test_concepts": 26,
            "code_lists": 9,
            "data_ingestion_parameters": 16
        }
    },
]

# ============================================================================
# Mock Data - Search Results (DTA Composer)
# ============================================================================

MOCK_RESULTS = [
    { "key": "TRIAL-XYZ|VEND-3|PK-Pharmacokinetics", "trial":"TRIAL-XYZ", "vendor":"VEND-3", "stream":"PK-Pharmacokinetics", "major": 2, "updated": "2025-11-15", "owners": ["pk.lab@vendor.com"], "badges": ["Transfer Variables","Code Lists","Test Concepts","Data Ingestion Parameters"], "status": "Approved" },
    { "key": "TRIAL-ABC|VEND-1|LB-Immunophenotyping", "trial":"TRIAL-ABC", "vendor":"VEND-1", "stream":"LB-Immunophenotyping", "major": 3, "updated": "2025-10-26", "owners": ["jane@jnj.com"], "badges": ["Visit and Timepoints","Transfer Variables","Code Lists","Test Concepts"], "status": "Approved" },
    { "key": "TRIAL-ABC|VEND-2|AE-AdverseEvents", "trial":"TRIAL-ABC", "vendor":"VEND-2", "stream":"AE-AdverseEvents", "major": 2, "updated": "2025-10-25", "owners": ["max@jnj.com"], "badges": ["Visit and Timepoints","Transfer Variables","Test Concepts"], "status": "Approved" },
    { "key": "TRIAL-ABC|VEND-3|VS-VitalSigns", "trial":"TRIAL-ABC", "vendor":"VEND-3", "stream":"VS-VitalSigns", "major": 1, "updated": "2025-10-24", "owners": ["sarah@jnj.com"], "badges": ["Transfer Variables","Test Concepts"], "status": "Draft" },
    { "key": "TRIAL-ABC|VEND-1|EG-ECG", "trial":"TRIAL-ABC", "vendor":"VEND-1", "stream":"EG-ECG", "major": 2, "updated": "2025-10-23", "owners": ["jane@jnj.com"], "badges": ["Visit and Timepoints","Transfer Variables","Code Lists","Test Concepts"], "status": "Approved" },
    { "key": "TRIAL-ABC|VEND-4|DM-Demographics", "trial":"TRIAL-ABC", "vendor":"VEND-4", "stream":"DM-Demographics", "major": 1, "updated": "2025-10-22", "owners": ["john@jnj.com"], "badges": ["Transfer Variables"], "status": "Draft" },
    { "key": "TRIAL-ABC|VEND-5|CM-ConcomitantMeds", "trial":"TRIAL-ABC", "vendor":"VEND-5", "stream":"CM-ConcomitantMeds", "major": 3, "updated": "2025-10-21", "owners": ["emily@jnj.com"], "badges": ["Visit and Timepoints","Transfer Variables","Code Lists","Test Concepts"], "status": "Approved" },
    { "key": "TRIAL-XYZ|VEND-2|AE-AdverseEvents", "trial":"TRIAL-XYZ", "vendor":"VEND-2", "stream":"AE-AdverseEvents", "major": 1, "updated": "2025-10-20", "owners": ["max@jnj.com"], "badges": ["Visit and Timepoints","Transfer Variables"], "status": "Draft" },
    { "key": "TRIAL-XYZ|VEND-1|LB-Immunophenotyping", "trial":"TRIAL-XYZ", "vendor":"VEND-1", "stream":"LB-Immunophenotyping", "major": 1, "updated": "2025-10-19", "owners": ["jane@jnj.com"], "badges": ["Transfer Variables","Test Concepts"], "status": "Draft" },
]

# ============================================================================
# Mock Data - Empty Entity Templates
# ============================================================================

EMPTY_ENTITIES = {
  "VT": [
    {"visit": "V1", "visit_label": "Screening", "timepoint": "TP1", "day": -14, "window_low": -7, "window_high": 0, "notes": "Initial eligibility assessment"},
    {"visit": "V2", "visit_label": "Baseline", "timepoint": "TP2", "day": 1, "window_low": 0, "window_high": 0, "notes": "Day 1 dosing"},
    {"visit": "V3", "visit_label": "Week 2", "timepoint": "TP3", "day": 15, "window_low": -2, "window_high": 2, "notes": "Safety assessment"},
    {"visit": "V4", "visit_label": "Week 4", "timepoint": "TP4", "day": 29, "window_low": -3, "window_high": 3, "notes": "Interim efficacy"},
    {"visit": "V5", "visit_label": "Week 8", "timepoint": "TP5", "day": 57, "window_low": -5, "window_high": 5, "notes": "Primary endpoint"},
    {"visit": "V6", "visit_label": "End of Study", "timepoint": "TP6", "day": 85, "window_low": -7, "window_high": 7, "notes": "Final assessment"}
  ],
  "TV": [
    {"LABEL":"STUDYID","FILE_ORDER":1,"FORMAT":"STRING","LENGTH":20,"REQUIRED":True,"TEST_CONCEPTS":"","EXAMPLE_VALUES":"TRIAL-ABC"},
    {"LABEL":"DOMAIN","FILE_ORDER":2,"FORMAT":"STRING","LENGTH":2,"REQUIRED":True,"TEST_CONCEPTS":"","EXAMPLE_VALUES":"LB"},
    {"LABEL":"USUBJID","FILE_ORDER":3,"FORMAT":"STRING","LENGTH":40,"REQUIRED":True,"TEST_CONCEPTS":"","EXAMPLE_VALUES":"TRIAL-ABC-001"},
    {"LABEL":"LBGRPID","FILE_ORDER":4,"FORMAT":"STRING","LENGTH":20,"REQUIRED":False,"TEST_CONCEPTS":"","EXAMPLE_VALUES":"GRP-001"},
    {"LABEL":"LBREFID","FILE_ORDER":5,"FORMAT":"STRING","LENGTH":20,"REQUIRED":True,"TEST_CONCEPTS":"","EXAMPLE_VALUES":"REF-001"},
    {"LABEL":"CTESTCD","FILE_ORDER":6,"FORMAT":"STRING","LENGTH":8,"REQUIRED":True,"TEST_CONCEPTS":"","EXAMPLE_VALUES":"EM_CD4_Th/CD3+"},
    {"LABEL":"CTEST","FILE_ORDER":7,"FORMAT":"STRING","LENGTH":40,"REQUIRED":True,"TEST_CONCEPTS":"","EXAMPLE_VALUES":"CD4 Th"}
  ],
  "CL": [
    {"ref":"RESULT_FLAG", "code":"POS", "text":"Positive"},
    {"ref":"RESULT_FLAG", "code":"NEG", "text":"Negative"},
    {"ref":"RESULT_FLAG", "code":"IND", "text":"Indeterminate"},
    {"ref":"SPECIMEN_TYPE", "code":"BLOOD", "text":"Whole Blood"},
    {"ref":"SPECIMEN_TYPE", "code":"SERUM", "text":"Serum"},
    {"ref":"SPECIMEN_TYPE", "code":"PLASMA", "text":"Plasma"},
    {"ref":"UNIT", "code":"%", "text":"Percent"},
    {"ref":"UNIT", "code":"mg/dL", "text":"Milligrams per Deciliter"},
    {"ref":"UNIT", "code":"cells/uL", "text":"Cells per Microliter"}
  ],
  "TC": [
    {"CTESTCD":"EM_CD4_Th/CD3+", "CTEST":"CD4 Th", "CUNIT":"%", "CSPEC":"Cryo PBMC", "CMETHOD":"FLOW CYTOMETRY", "CPANEL":"Revised T Cell Panel", "LBGATE":"EM_CD4_Th|not(CD4+ Treg)|CD4+|CD3+|Viable Lymphocytes|Lymphocytes", "LBLOQ":"not applicable", "LBMTHDOS":"", "LBCNDAGT":"", "LBANSTAT":"", "LBCLMETH":"", "LBTMTHSN":"", "LBREAGNT":"", "LBBDAGNT":""},
    {"CTESTCD":"EM_CD4_Th/CD4+", "CTEST":"CD4 Th", "CUNIT":"%", "CSPEC":"Cryo PBMC", "CMETHOD":"FLOW CYTOMETRY", "CPANEL":"Revised T Cell Panel", "LBGATE":"EM_CD4_Th|not(CD4+ Treg)|CD4+|CD3+|Viable Lymphocytes|Lymphocytes", "LBLOQ":"not applicable", "LBMTHDOS":"", "LBCNDAGT":"", "LBANSTAT":"", "LBCLMETH":"", "LBTMTHSN":"", "LBREAGNT":"", "LBBDAGNT":""},
    {"CTESTCD":"Naive_CD4_Th/CD3+", "CTEST":"Naive CD4 Th", "CUNIT":"%", "CSPEC":"Cryo PBMC", "CMETHOD":"FLOW CYTOMETRY", "CPANEL":"Revised T Cell Panel", "LBGATE":"Naive_CD4_Th|not(CD4+ Treg)|CD4+|CD3+|Viable Lymphocytes|Lymphocytes", "LBLOQ":"not applicable", "LBMTHDOS":"", "LBCNDAGT":"", "LBANSTAT":"", "LBCLMETH":"", "LBTMTHSN":"", "LBREAGNT":"", "LBBDAGNT":""},
    {"CTESTCD":"Naive_CD4_Th/CD4+", "CTEST":"Naive CD4 Th", "CUNIT":"%", "CSPEC":"Cryo PBMC", "CMETHOD":"FLOW CYTOMETRY", "CPANEL":"Revised T Cell Panel", "LBGATE":"Naive_CD4_Th|not(CD4+ Treg)|CD4+|CD3+|Viable Lymphocytes|Lymphocytes", "LBLOQ":"not applicable", "LBMTHDOS":"", "LBCNDAGT":"", "LBANSTAT":"", "LBCLMETH":"", "LBTMTHSN":"", "LBREAGNT":"", "LBBDAGNT":""},
    {"CTESTCD":"EM_CD8/CD8+", "CTEST":"Effector Memory CD8", "CUNIT":"%", "CSPEC":"Cryo PBMC", "CMETHOD":"FLOW CYTOMETRY", "CPANEL":"Revised T Cell Panel", "LBGATE":"EM_CD8|CD8+|CD3+|Viable Lymphocytes|Lymphocytes", "LBLOQ":"not applicable", "LBMTHDOS":"", "LBCNDAGT":"", "LBANSTAT":"", "LBCLMETH":"", "LBTMTHSN":"", "LBREAGNT":"", "LBBDAGNT":""}
  ]
}

# ============================================================================
# Mock Data - Workspaces (In-Memory State)
# ============================================================================

WORKSPACES = {}

# Initialize one approved DTA for testing export functionality
WORKSPACES["TRIAL-XYZ|VEND-3|PK-Pharmacokinetics"] = {
    "key": "TRIAL-XYZ|VEND-3|PK-Pharmacokinetics",
    "draft_id": "DRAFT-150320",
    "base_major": 2,
    "editor_tab": "META",
    "status": "Approved",
    "submitted_at": "2025-11-10T14:30:00",
    "approved_at": "2025-11-15T16:45:00",
    "entities": {
        "TC": [
            {"test_name": "Serum Concentration", "test_short_name": "PKCONC", "specimen_type": "Serum", "method": "LC-MS/MS", "reference_range": "N/A", "units": "ng/mL", "notes": ""},
            {"test_name": "Plasma AUC", "test_short_name": "PKAUC", "specimen_type": "Plasma", "method": "Non-compartmental", "reference_range": "N/A", "units": "ng*h/mL", "notes": ""},
        ],
        "TV": [
            {"variable": "STUDYID", "label": "Study Identifier", "datatype": "Char", "length": "20", "format": "", "controlled_terms": "", "notes": ""},
            {"variable": "USUBJID", "label": "Unique Subject Identifier", "datatype": "Char", "length": "40", "format": "", "controlled_terms": "", "notes": ""},
            {"variable": "PKSEQ", "label": "Sequence Number", "datatype": "Num", "length": "8", "format": "", "controlled_terms": "", "notes": ""},
            {"variable": "PKTESTCD", "label": "PK Test Short Name", "datatype": "Char", "length": "8", "format": "", "controlled_terms": "PKCONC, PKAUC", "notes": ""},
            {"variable": "PKTEST", "label": "PK Test Name", "datatype": "Char", "length": "40", "format": "", "controlled_terms": "", "notes": ""},
        ],
        "CL": [
            {"ref": "PKTESTCD", "code": "PKCONC", "text": "Serum Concentration"},
            {"ref": "PKTESTCD", "code": "PKAUC", "text": "Plasma AUC"},
        ],
        "VT": []
    },
    "metadata": [
        {"field": "trial_id", "label": "Trial ID", "value": "TRIAL-XYZ", "readonly": True},
        {"field": "vendor_id", "label": "Vendor ID", "value": "VEND-3", "readonly": True},
        {"field": "data_stream", "label": "Data Stream", "value": "PK-Pharmacokinetics", "readonly": True},
        {"field": "title", "label": "DTA Title", "value": "Pharmacokinetics Data Transfer Agreement", "readonly": False},
        {"field": "description", "label": "Description", "value": "Transfer of PK concentration and analysis data", "readonly": False},
        {"field": "protocol_version", "label": "Protocol Version", "value": "v3.0", "readonly": False},
        {"field": "vendor_contact", "label": "Vendor Contact", "value": "pk.lab@vendor.com", "readonly": False},
        {"field": "jnj_contact", "label": "JNJ Contact", "value": "clinical.team@jnj.com", "readonly": False},
    ],
    "metadata_state": [{"editable": False, "approved": True, "comments": []} for _ in range(8)],
    "dip": [
        {"field": "transfer_type", "label": "Type of Transfer", "value": "Cumulative", "readonly": False},
        {"field": "blinding", "label": "Blinding of Data", "value": "No secure data involved", "readonly": False},
        {"field": "frequency", "label": "Frequency of Transfer", "value": "Monthly", "readonly": False},
        {"field": "transfer_day", "label": "Transfer Day (if Weekly/Monthly)", "value": "1st of month", "readonly": False},
        {"field": "prior_to_lock", "label": "Prior to Database Lock", "value": "Yes", "readonly": False},
        {"field": "automated_timing", "label": "Automated Transfer Timing (UTC)", "value": "00:00", "readonly": False},
        {"field": "reconciliation", "label": "Reconciliation File", "value": "reconciliation.csv", "readonly": False},
        {"field": "zip_file_test", "label": "Transfer File Name - Test (Zip)", "value": "PK_TRIAL-XYZ_test_<YYYYMMDD>.zip", "readonly": False},
        {"field": "zip_file_prod", "label": "Transfer File Name - Production (Zip)", "value": "PK_TRIAL-XYZ_<YYYYMMDD>.zip", "readonly": False},
        {"field": "result_file_1", "label": "Result File - 1", "value": "PK_concentration.csv", "readonly": False},
        {"field": "result_file_2", "label": "Result File - 2", "value": "PK_parameters.csv", "readonly": False},
        {"field": "file_format", "label": "Transfer File Format", "value": "CSV", "readonly": False},
        {"field": "delimiter", "label": "Delimiter", "value": ",", "readonly": False},
        {"field": "transfer_method", "label": "Method of Transfer", "value": "Automated", "readonly": False},
        {"field": "lsaf_path_nonsecure", "label": "LSAF Path - NON-SECURE", "value": "/SAS/PK/TRIAL-XYZ", "readonly": False},
        {"field": "lsaf_path_secure", "label": "LSAF Path - SECURE", "value": "", "readonly": False},
    ],
    "dip_state": [{"editable": False, "approved": True, "comments": []} for _ in range(16)],
    "tc_state": [{"editable": False, "approved": True, "comments": []} for _ in range(2)],
    "tv_state": [{"editable": False, "approved": True, "comments": []} for _ in range(5)],
    "cl_state": {
        "PKTESTCD": [
            {"editable": False, "approved": True, "comments": []},
            {"editable": False, "approved": True, "comments": []},
        ]
    },
    "transfer_file_keys": ["STUDYID", "USUBJID", "PKSEQ"],
    "comments": [],
    "approvals": [
        {
            "reviewer_name": "Sarah Johnson",
            "reviewer_title": "DAE Lead",
            "reviewer_email": "sarah.johnson@jnj.com",
            "role": "JNJ DAE",
            "status": "Approved",
            "approved_at": "2025-11-12T10:30:00",
            "approved_by": "Sarah Johnson",
            "order": 1
        },
        {
            "reviewer_name": "Alex Kumar",
            "reviewer_title": "Data Manager",
            "reviewer_email": "alex.kumar@vendor.com",
            "role": "Vendor",
            "status": "Approved",
            "approved_at": "2025-11-14T14:15:00",
            "approved_by": "Alex Kumar",
            "order": 2
        },
        {
            "reviewer_name": "Lisa Wong",
            "reviewer_title": "Study Librarian",
            "reviewer_email": "lisa.wong@jnj.com",
            "role": "Librarian",
            "status": "Approved",
            "approved_at": "2025-11-15T16:45:00",
            "approved_by": "Lisa Wong",
            "order": 3
        }
    ]
}

# ============================================================================
# Helper Functions
# ============================================================================

def _ensure_tv_init(ws):
    """
    Ensure TV state exists and is sized to entities['TV'].
    Safe to call multiple times.
    """
    try:
        ents = ws.get("entities", {})
        tv = ents.get("TV", [])
        if "tv_selected" not in ws:
            ws["tv_selected"] = 0
        if "tv_state" not in ws:
            ws["tv_state"] = [{"approved": False, "editable": False, "comments": []} for _ in tv]
        else:
            # Ensure all rows have the required fields
            for i in range(len(tv)):
                if i >= len(ws["tv_state"]):
                    ws["tv_state"].append({"approved": False, "editable": False, "comments": []})
                else:
                    # Add missing fields to existing state
                    if "editable" not in ws["tv_state"][i]:
                        ws["tv_state"][i]["editable"] = False
                    if "comments" not in ws["tv_state"][i]:
                        ws["tv_state"][i]["comments"] = []
    except Exception:
        # never break the page
        pass


def group_codelists_by_ref(cl_list):
    """Group codelist entries by reference variable."""
    from collections import defaultdict
    grouped = defaultdict(list)
    for item in cl_list:
        grouped[item['ref']].append(item)
    return dict(grouped)


def get_or_create_workspace(result):
    """
    Create workspace from search result or get existing one.
    Initializes all necessary state for TC, TV, CL, metadata, and DIP.
    """
    key = result["key"]
    ws = WORKSPACES.get(key)
    
    if not ws:
        # Initialize CL state grouped by reference
        cl_state = {}
        for item in EMPTY_ENTITIES["CL"]:
            ref = item["ref"]
            if ref not in cl_state:
                cl_state[ref] = []
            cl_state[ref].append({"editable": False, "approved": False, "comments": []})
        
        # Initialize metadata fields
        metadata_fields = [
            {"field": "trial_id", "label": "Trial ID", "value": key.split('|')[0], "readonly": True},
            {"field": "vendor_id", "label": "Vendor ID", "value": key.split('|')[1], "readonly": True},
            {"field": "data_stream", "label": "Data Stream", "value": key.split('|')[2], "readonly": True},
            {"field": "title", "label": "DTA Title", "value": "", "readonly": False},
            {"field": "description", "label": "Description", "value": "", "readonly": False},
            {"field": "protocol_version", "label": "Protocol Version", "value": "", "readonly": False},
            {"field": "vendor_contact", "label": "Vendor Contact", "value": "", "readonly": False},
            {"field": "jnj_contact", "label": "JNJ Contact", "value": "", "readonly": False},
        ]
        
        # Initialize data ingestion parameters
        dip_fields = [
            {"field": "transfer_type", "label": "Type of Transfer", "value": "Cumulative", "readonly": False},
            {"field": "blinding", "label": "Blinding of Data", "value": "No secure data involved", "readonly": False},
            {"field": "frequency", "label": "Frequency of Transfer", "value": "During Trial", "readonly": False},
            {"field": "transfer_day", "label": "Transfer Day (if Weekly/Monthly)", "value": "", "readonly": False},
            {"field": "prior_to_lock", "label": "Prior to Database Lock", "value": "", "readonly": False},
            {"field": "automated_timing", "label": "Automated Transfer Timing (UTC)", "value": "", "readonly": False},
            {"field": "reconciliation", "label": "Reconciliation File", "value": "If applicable, otherwise leave field blank", "readonly": False},
            {"field": "zip_file_test", "label": "Transfer File Name - Test (Zip)", "value": "CellC_78278343PCR1001_test_<YYYYMMDD>_HHMMSS.zip", "readonly": False},
            {"field": "zip_file_prod", "label": "Transfer File Name - Production (Zip)", "value": "CellC_78278343PCR1001_<YYYYMMDD>_HHMMSS.zip", "readonly": False},
            {"field": "result_file_1", "label": "Result File - 1", "value": "CellCarta_78278343PCR1001_LBFlow_test.txt", "readonly": False},
            {"field": "result_file_2", "label": "Result File - 2", "value": "CellCarta_78278343PCR1001_LBFlow_na_test.txt", "readonly": False},
            {"field": "file_format", "label": "Transfer File Format", "value": "Text, csv or xls format, specify delimiter", "readonly": False},
            {"field": "delimiter", "label": "Delimiter", "value": "@", "readonly": False},
            {"field": "transfer_method", "label": "Method of Transfer", "value": "Manual", "readonly": False},
            {"field": "lsaf_path_nonsecure", "label": "LSAF Path - NON-SECURE", "value": "/SAS/5588/78278343PCR1001/Files/10_UAT/10_Biomarker_CellCart/10_Dropbox", "readonly": False},
            {"field": "lsaf_path_secure", "label": "LSAF Path - SECURE", "value": "", "readonly": False},
        ]
        
        ws = {
            "key": key,
            "draft_id": f"DRAFT-{datetime.utcnow().strftime('%H%M%S')}",
            "base_major": result["major"],
            "editor_tab": "META",
            "status": "Draft",
            "submitted_at": None,
            "is_mock_data": True,  # Flag indicating this workspace uses mock data
            "entities": json.loads(json.dumps(EMPTY_ENTITIES)),
            "metadata": metadata_fields,
            "metadata_state": [{"editable": False, "approved": False, "comments": []} for _ in metadata_fields],
            "dip": dip_fields,
            "dip_state": [{"editable": False, "approved": False, "comments": []} for _ in dip_fields],
            "tc_state": [{"editable": False, "approved": False, "comments": []} for _ in EMPTY_ENTITIES["TC"]],
            "cl_state": cl_state,
            "transfer_file_keys": ["STUDYID", "DOMAIN", "USUBJID", "LBREFID"],
            "comments": [],
            "approvals": [
                {"reviewer_name": "Jane Smith", "reviewer_title": "DTA Manager, JNJ", "reviewer_email": "jane.smith@jnj.com", "status": "Pending"},
                {"reviewer_name": "Michael Chen", "reviewer_title": "Clinical Operations Lead, Vendor", "reviewer_email": "michael.chen@vendor.com", "status": "Pending"},
                {"reviewer_name": "Sarah Johnson", "reviewer_title": "Quality Assurance Director, JNJ", "reviewer_email": "sarah.johnson@jnj.com", "status": "Pending"},
            ]
        }
        WORKSPACES[key] = ws
    
    # Ensure backward compatibility for existing workspaces
    if "transfer_file_keys" not in ws:
        ws["transfer_file_keys"] = ["STUDYID", "DOMAIN", "USUBJID", "LBREFID"]
    
    if "status" not in ws:
        ws["status"] = "Draft"
        ws["submitted_at"] = None
    
    if "cl_state" not in ws:
        cl_state = {}
        for item in ws.get("entities", {}).get("CL", []):
            ref = item["ref"]
            if ref not in cl_state:
                cl_state[ref] = []
            cl_state[ref].append({"editable": False, "approved": False, "comments": []})
        ws["cl_state"] = cl_state
    
    if "metadata" not in ws:
        key = ws["key"]
        metadata_fields = [
            {"field": "trial_id", "label": "Trial ID", "value": key.split('|')[0], "readonly": True},
            {"field": "vendor_id", "label": "Vendor ID", "value": key.split('|')[1], "readonly": True},
            {"field": "data_stream", "label": "Data Stream", "value": key.split('|')[2], "readonly": True},
            {"field": "title", "label": "DTA Title", "value": "", "readonly": False},
            {"field": "description", "label": "Description", "value": "", "readonly": False},
            {"field": "protocol_version", "label": "Protocol Version", "value": "", "readonly": False},
            {"field": "vendor_contact", "label": "Vendor Contact", "value": "", "readonly": False},
            {"field": "jnj_contact", "label": "JNJ Contact", "value": "", "readonly": False},
        ]
        ws["metadata"] = metadata_fields
        ws["metadata_state"] = [{"editable": False, "approved": False, "comments": []} for _ in metadata_fields]
    
    if "dip" not in ws:
        dip_fields = [
            {"field": "transfer_type", "label": "Type of Transfer", "value": "Cumulative", "readonly": False},
            {"field": "blinding", "label": "Blinding of Data", "value": "No secure data involved", "readonly": False},
            {"field": "frequency", "label": "Frequency of Transfer", "value": "During Trial", "readonly": False},
            {"field": "transfer_day", "label": "Transfer Day (if Weekly/Monthly)", "value": "", "readonly": False},
            {"field": "prior_to_lock", "label": "Prior to Database Lock", "value": "", "readonly": False},
            {"field": "automated_timing", "label": "Automated Transfer Timing (UTC)", "value": "", "readonly": False},
            {"field": "reconciliation", "label": "Reconciliation File", "value": "If applicable, otherwise leave field blank", "readonly": False},
            {"field": "zip_file_test", "label": "Transfer File Name - Test (Zip)", "value": "CellC_78278343PCR1001_test_<YYYYMMDD>_HHMMSS.zip", "readonly": False},
            {"field": "zip_file_prod", "label": "Transfer File Name - Production (Zip)", "value": "CellC_78278343PCR1001_<YYYYMMDD>_HHMMSS.zip", "readonly": False},
            {"field": "result_file_1", "label": "Result File - 1", "value": "CellCarta_78278343PCR1001_LBFlow_test.txt", "readonly": False},
            {"field": "result_file_2", "label": "Result File - 2", "value": "CellCarta_78278343PCR1001_LBFlow_na_test.txt", "readonly": False},
            {"field": "file_format", "label": "Transfer File Format", "value": "Text, csv or xls format, specify delimiter", "readonly": False},
            {"field": "delimiter", "label": "Delimiter", "value": "@", "readonly": False},
            {"field": "transfer_method", "label": "Method of Transfer", "value": "Manual", "readonly": False},
            {"field": "lsaf_path_nonsecure", "label": "LSAF Path - NON-SECURE", "value": "/SAS/5588/78278343PCR1001/Files/10_UAT/10_Biomarker_CellCart/10_Dropbox", "readonly": False},
            {"field": "lsaf_path_secure", "label": "LSAF Path - SECURE", "value": "", "readonly": False},
        ]
        ws["dip"] = dip_fields
        ws["dip_state"] = [{"editable": False, "approved": False, "comments": []} for _ in dip_fields]
    
    return ws


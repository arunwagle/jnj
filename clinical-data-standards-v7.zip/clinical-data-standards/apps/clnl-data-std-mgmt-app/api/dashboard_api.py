"""
Dashboard API - Provides data for the main dashboard view.
Integrates with Databricks SQL to fetch real version data from md_version_registry.
"""

from flask import Blueprint, jsonify
from datetime import datetime, timedelta
import random
import os

# Import SQL client for database queries
from api.databricks_client import DatabricksSQLClient

dashboard_bp = Blueprint('dashboard_api', __name__, url_prefix='/api/dashboard')


# ============================================================================
# DATABASE CONFIGURATION
# ============================================================================

# Log environment at module load time
print("=" * 60)
print("DASHBOARD_API MODULE LOADED")
print(f"  CATALOG_NAME: {os.environ.get('CATALOG_NAME', 'NOT SET')}")
print(f"  GOLD_SCHEMA: {os.environ.get('GOLD_SCHEMA', 'NOT SET')}")
print(f"  DATABRICKS_WAREHOUSE_ID: {os.environ.get('DATABRICKS_WAREHOUSE_ID', 'NOT SET')}")
print("=" * 60)


def _get_db_config():
    """Get database configuration from environment variables"""
    config = {
        "catalog": os.environ.get("CATALOG_NAME", "aira_test"),
        "gold_schema": os.environ.get("GOLD_SCHEMA", "gold_md"),
        "warehouse_id": os.environ.get("DATABRICKS_WAREHOUSE_ID")
    }
    print(f"DEBUG _get_db_config: {config}")
    return config


def _get_sql_client():
    """Get SQL client instance - raises if not configured"""
    config = _get_db_config()
    if not config["warehouse_id"]:
        raise RuntimeError(
            "DATABRICKS_WAREHOUSE_ID environment variable not set. "
            "This app must run on Databricks with proper configuration in app.yaml."
        )
    print(f"DEBUG: Creating SQL client for warehouse: {config['warehouse_id']}")
    return DatabricksSQLClient(config["warehouse_id"])


# ============================================================================
# REAL DATA QUERIES
# ============================================================================

def _get_all_versions_from_db():
    """
    Query md_version_registry for ALL library types in a single query.
    Joins with DTA table to get vendor and data stream information.
    Uses IN clause for efficiency.
    
    Returns:
        Dict mapping library_type -> list of version records with vendor/stream info
    """
    config = _get_db_config()
    registry_table = f"{config['catalog']}.{config['gold_schema']}.md_version_registry"
    dta_table = f"{config['catalog']}.{config['gold_schema']}.dta"
    
    # All library types we support
    library_types = [
        'transfer_variables', 'codelists', 'test_concepts',
        'operational_agreements', 'visits_timepoints', 'data_ingestion_parameters'
    ]
    library_types_str = ", ".join([f"'{t}'" for t in library_types])
    
    # Join with DTA table to get vendor and data stream information
    query = f"""
        SELECT 
            r.version,
            r.library_type,
            r.version_type,
            r.dta_id,
            r.parent_version,
            r.record_count,
            r.status,
            r.created_by_principal,
            r.created_ts,
            d.data_provider_name,
            d.data_stream_type,
            d.trial_id,
            d.dta_number,
            d.dta_name
        FROM {registry_table} r
        LEFT JOIN {dta_table} d ON r.dta_id = d.dta_id
        WHERE r.library_type IN ({library_types_str})
          AND r.status = 'ACTIVE'
          AND r.version_type = 'DTA_TEMPLATE'
        ORDER BY r.library_type, r.created_ts DESC
    """
    
    # Log the full query for debugging
    print(f"=" * 60)
    print(f"DEBUG: Querying ALL library templates with vendor/stream info")
    print(f"DEBUG: Registry Table: {registry_table}")
    print(f"DEBUG: DTA Table: {dta_table}")
    print(f"DEBUG: Query:")
    print(query)
    print(f"=" * 60)
    
    client = _get_sql_client()
    results = client.execute_query(query)
    
    print(f"DEBUG: Query returned {len(results)} total rows")
    
    # Group results by library_type
    versions_by_type = {}
    for row in results:
        lib_type = row.get("library_type")
        if lib_type not in versions_by_type:
            versions_by_type[lib_type] = []
        versions_by_type[lib_type].append(row)
    
    # Log summary
    print(f"DEBUG: Grouped by library_type:")
    for lib_type, versions in versions_by_type.items():
        print(f"  - {lib_type}: {len(versions)} templates")
    
    return versions_by_type


def _get_dta_overview_from_db():
    """
    Query DTA table for overview statistics.
    Returns total count and counts by workflow_state.
    """
    config = _get_db_config()
    table = f"{config['catalog']}.{config['gold_schema']}.dta"
    
    query = f"""
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN workflow_state = 'APPROVED' THEN 1 ELSE 0 END) as approved,
            SUM(CASE WHEN workflow_state = 'IN_REVIEW' THEN 1 ELSE 0 END) as in_review,
            SUM(CASE WHEN workflow_state IN ('DRAFT', 'NOT_STARTED') THEN 1 ELSE 0 END) as draft,
            SUM(CASE WHEN workflow_state = 'REJECTED' THEN 1 ELSE 0 END) as rejected,
            SUM(CASE WHEN status = 'MANUAL_REVIEW' THEN 1 ELSE 0 END) as manual_review
        FROM {table}
    """
    
    print(f"=" * 60)
    print(f"DEBUG: Querying DTA overview")
    print(f"DEBUG: Table: {table}")
    print(f"DEBUG: Query:")
    print(query)
    print(f"=" * 60)
    
    client = _get_sql_client()
    results = client.execute_query(query)
    
    if results and len(results) > 0:
        row = results[0]
        overview = {
            "total": int(row.get("total", 0) or 0),
            "by_status": {
                "approved": int(row.get("approved", 0) or 0),
                "in_review": int(row.get("in_review", 0) or 0),
                "draft": int(row.get("draft", 0) or 0),
                "rejected": int(row.get("rejected", 0) or 0),
                "manual_review": int(row.get("manual_review", 0) or 0)
            }
        }
        print(f"DEBUG: DTA Overview: {overview}")
        return overview
    
    # Return empty overview if query fails
    return {
        "total": 0,
        "by_status": {
            "approved": 0,
            "in_review": 0,
            "draft": 0,
            "rejected": 0,
            "manual_review": 0
        }
    }


def _get_dtas_needing_manual_review():
    """
    Get DTAs that have status = 'MANUAL_REVIEW'.
    Returns a list of DTA details with reason (from notes field).
    """
    config = _get_db_config()
    table = f"{config['catalog']}.{config['gold_schema']}.dta"
    
    query = f"""
        SELECT 
            dta_id,
            dta_number,
            dta_name,
            trial_id,
            data_stream_type,
            data_provider_name,
            workflow_state,
            notes,
            created_ts,
            last_updated_ts
        FROM {table}
        WHERE status = 'MANUAL_REVIEW'
        ORDER BY last_updated_ts DESC
    """
    
    print(f"DEBUG: Querying DTAs needing manual review...")
    
    try:
        client = _get_sql_client()
        results = client.execute_query(query)
        
        if not results:
            return []
        
        dtas = []
        for row in results:
            dta = {
                "dta_id": row.get("dta_id"),
                "dta_number": row.get("dta_number"),
                "dta_name": row.get("dta_name"),
                "trial_id": row.get("trial_id"),
                "data_stream_type": row.get("data_stream_type"),
                "data_provider_name": row.get("data_provider_name"),
                "workflow_state": row.get("workflow_state"),
                "review_reason": row.get("notes", "Requires manual review"),
                "created_ts": str(row.get("created_ts")) if row.get("created_ts") else None,
                "last_updated_ts": str(row.get("last_updated_ts")) if row.get("last_updated_ts") else None
            }
            dtas.append(dta)
        
        print(f"DEBUG: Found {len(dtas)} DTAs needing manual review")
        return dtas
        
    except Exception as e:
        print(f"DEBUG: Error getting manual review DTAs: {e}")
        return []


def _get_ready_to_promote_count():
    """
    Count DTAs that have DTA Approved versions ready to be included in DTA Templates.
    
    Two-stage promotion:
    1. DTA Approval → Creates DTA Approved (latest_major_version is populated)
    2. Template Creation (Librarian job) → Merges DTA Approved into DTA Template (status = 'PROMOTED')
    
    "Ready to Promote" shows DTAs at stage 1 complete, waiting for stage 2:
    - latest_major_version IS NOT NULL (DTA Approved exists)
    - status != 'PROMOTED' (not yet included in DTA Template)
    """
    config = _get_db_config()
    dta_table = f"{config['catalog']}.{config['gold_schema']}.dta"
    
    # Count DTAs with DTA Major versions that are ready for Library promotion
    # These have latest_major_version set but have not been promoted to Library yet
    query = f"""
        SELECT COUNT(DISTINCT d.dta_id) as ready_count
        FROM {dta_table} d
        WHERE d.latest_major_version IS NOT NULL
          AND d.latest_major_version != ''
          AND d.status != 'PROMOTED'
    """
    
    print(f"DEBUG: Querying ready to promote count...")
    
    try:
        client = _get_sql_client()
        results = client.execute_query(query)
        
        if results and len(results) > 0:
            count = int(results[0].get("ready_count", 0) or 0)
            print(f"DEBUG: Ready to promote count: {count}")
            return count
    except Exception as e:
        print(f"DEBUG: Error getting ready to promote count: {e}")
    
    return 0


def _get_promotion_candidates_from_db():
    """
    Get DTAs ready for template promotion, grouped by (vendor, data_stream).
    
    Returns list of groups, each with:
    - data_provider_name: Vendor name
    - data_stream_type: Stream type
    - library_type: Type of library (e.g., transfer_variables)
    - dta_count: Number of DTAs in this group
    - dtas: List of DTA details (id, number, name, record_count)
    - current_template: Existing template version for this vendor+stream (if any)
    """
    config = _get_db_config()
    dta_table = f"{config['catalog']}.{config['gold_schema']}.dta"
    registry_table = f"{config['catalog']}.{config['gold_schema']}.md_version_registry"
    
    # Query approved DTAs not yet promoted, grouped by vendor+stream
    query = f"""
        SELECT 
            d.data_provider_name,
            d.data_stream_type,
            r.library_type,
            d.dta_id,
            d.dta_number,
            d.dta_name,
            r.record_count,
            r.version as dta_version,
            r.created_ts
        FROM {registry_table} r
        JOIN {dta_table} d ON r.dta_id = d.dta_id
        WHERE r.version_type = 'DTA_APPROVED'
          AND r.status = 'ACTIVE'
          AND d.status != 'PROMOTED'
        ORDER BY d.data_provider_name, d.data_stream_type, r.library_type, r.created_ts DESC
    """
    
    print(f"DEBUG: Querying promotion candidates...")
    
    try:
        client = _get_sql_client()
        results = client.execute_query(query)
        
        if not results:
            return []
        
        # Group by (vendor, stream) - all library types together under one DTA Template
        groups = {}
        for row in results:
            key = (row.get('data_provider_name'), row.get('data_stream_type'))
            if key not in groups:
                groups[key] = {
                    'data_provider_name': row.get('data_provider_name'),
                    'data_stream_type': row.get('data_stream_type'),
                    'library_types': {},  # {library_type: total_records}
                    'dtas': [],
                    'dta_ids_seen': set(),  # Track unique DTAs
                    'current_template': None
                }
            
            # Track library type record counts
            lib_type = row.get('library_type')
            record_count = int(row.get('record_count') or 0)
            if lib_type not in groups[key]['library_types']:
                groups[key]['library_types'][lib_type] = 0
            groups[key]['library_types'][lib_type] += record_count
            
            # Add DTA info (only once per unique DTA)
            dta_id = row.get('dta_id')
            if dta_id not in groups[key]['dta_ids_seen']:
                groups[key]['dta_ids_seen'].add(dta_id)
                groups[key]['dtas'].append({
                    'dta_id': dta_id,
                    'dta_number': row.get('dta_number'),
                    'dta_name': row.get('dta_name'),
                    'record_count': record_count,
                    'version': row.get('dta_version'),
                    'created_ts': str(row.get('created_ts')) if row.get('created_ts') else None
                })
        
        # Get current templates for each group (by vendor+stream)
        for key, group in groups.items():
            vendor, stream = key
            template_query = f"""
                SELECT version, record_count, included_dta_ids, library_type, created_ts
                FROM {registry_table}
                WHERE version_type = 'DTA_TEMPLATE'
                  AND status = 'ACTIVE'
                  AND data_provider_name = '{vendor}'
                  AND data_stream_type = '{stream}'
                ORDER BY created_ts DESC
            """
            try:
                template_results = client.execute_query(template_query)
                if template_results and len(template_results) > 0:
                    # Get the latest template info
                    template = template_results[0]
                    group['current_template'] = {
                        'version': template.get('version'),
                        'record_count': int(template.get('record_count') or 0),
                        'included_dta_ids': template.get('included_dta_ids')
                    }
            except Exception as te:
                print(f"DEBUG: Error getting template for {key}: {te}")
        
        # Convert to list and clean up
        result = []
        for group in groups.values():
            group['dta_count'] = len(group['dtas'])
            # Calculate total records across all library types
            group['total_records'] = sum(group['library_types'].values())
            # Remove internal tracking set (not JSON serializable)
            del group['dta_ids_seen']
            result.append(group)
        
        print(f"DEBUG: Found {len(result)} promotion candidate groups")
        return result
        
    except Exception as e:
        print(f"DEBUG: Error getting promotion candidates: {e}")
        return []


def _get_processing_stats_from_db():
    """
    Query processing statistics for "This Month" panel.
    - DTAs created this month from dta table
    - Files processed this month from md_file_history table
    - Success rate based on document status
    """
    config = _get_db_config()
    dta_table = f"{config['catalog']}.{config['gold_schema']}.dta"
    doc_table = f"{config['catalog']}.bronze_md.md_file_history"
    
    # Query for DTAs created this month
    dta_query = f"""
        SELECT COUNT(*) as dtas_created
        FROM {dta_table}
        WHERE created_ts >= date_trunc('month', current_date())
    """
    
    # Query for files processed this month and success rate
    doc_query = f"""
        SELECT 
            COUNT(DISTINCT document_id) as files_processed,
            ROUND(
                SUM(CASE WHEN status = 'COMPLETED' THEN 1 ELSE 0 END) * 100.0 / 
                NULLIF(COUNT(*), 0)
            , 0) as success_rate
        FROM {doc_table}
        WHERE created_ts >= date_trunc('month', current_date())
    """
    
    print(f"=" * 60)
    print(f"DEBUG: Querying processing stats")
    print(f"DEBUG: DTA Query: {dta_query}")
    print(f"DEBUG: Doc Query: {doc_query}")
    print(f"=" * 60)
    
    client = _get_sql_client()
    
    # Get DTA count
    dtas_created = 0
    try:
        dta_results = client.execute_query(dta_query)
        if dta_results and len(dta_results) > 0:
            dtas_created = int(dta_results[0].get("dtas_created", 0) or 0)
    except Exception as e:
        print(f"WARNING: Failed to query DTA count: {e}")
    
    # Get files processed and success rate
    files_processed = 0
    success_rate = 0
    try:
        doc_results = client.execute_query(doc_query)
        if doc_results and len(doc_results) > 0:
            files_processed = int(doc_results[0].get("files_processed", 0) or 0)
            success_rate = int(doc_results[0].get("success_rate", 0) or 0)
    except Exception as e:
        print(f"WARNING: Failed to query document stats: {e}")
    
    stats = {
        "this_month": {
            "dtas_created": dtas_created,
            "files_processed": files_processed
        },
        "success_rate": success_rate
    }
    
    print(f"DEBUG: Processing Stats: {stats}")
    return stats


def _get_recent_dtas_from_db(offset: int = 0, limit: int = 100):
    """
    Query DTA table for paginated list of recent DTAs.
    
    Args:
        offset: Starting position for pagination
        limit: Number of records to fetch (max 100)
    
    Returns:
        dict with 'dtas' list, 'total_count', 'has_more', 'next_offset'
    """
    config = _get_db_config()
    table = f"{config['catalog']}.{config['gold_schema']}.dta"
    
    # Query for total count
    count_query = f"SELECT COUNT(*) as total FROM {table}"
    
    # Query for paginated DTAs ordered by last_updated_ts desc
    dta_query = f"""
        SELECT 
            dta_id,
            dta_number,
            trial_id,
            data_stream_type as data_stream,
            data_provider_name as vendor,
            status,
            workflow_state,
            version as version,
            notes,
            created_by_principal,
            created_ts,
            last_updated_ts
        FROM {table}
        ORDER BY last_updated_ts DESC
        LIMIT {limit}
        OFFSET {offset}
    """
    
    print(f"=" * 60)
    print(f"DEBUG: Querying paginated DTAs (offset={offset}, limit={limit})")
    print(f"DEBUG: Query: {dta_query[:200]}...")
    print(f"=" * 60)
    
    client = _get_sql_client()
    
    # Get total count
    total_count = 0
    try:
        count_results = client.execute_query(count_query)
        if count_results and len(count_results) > 0:
            total_count = int(count_results[0].get("total", 0) or 0)
    except Exception as e:
        print(f"WARNING: Failed to get DTA count: {e}")
    
    # Get paginated DTAs
    dtas = []
    try:
        results = client.execute_query(dta_query)
        if results:
            for row in results:
                # Format timestamps for display
                created_ts = row.get("created_ts", "")
                last_updated_ts = row.get("last_updated_ts", "")
                
                # Parse and format dates
                try:
                    if created_ts:
                        created_date = datetime.fromisoformat(str(created_ts).replace('Z', '+00:00'))
                        created_display = created_date.strftime("%Y-%m-%d %H:%M")
                    else:
                        created_display = "N/A"
                except:
                    created_display = str(created_ts)[:16] if created_ts else "N/A"
                
                try:
                    if last_updated_ts:
                        updated_date = datetime.fromisoformat(str(last_updated_ts).replace('Z', '+00:00'))
                        updated_display = updated_date.strftime("%Y-%m-%d %H:%M")
                    else:
                        updated_display = "N/A"
                except:
                    updated_display = str(last_updated_ts)[:16] if last_updated_ts else "N/A"
                
                dtas.append({
                    "dta_id": str(row.get("dta_id", "")),
                    "dta_number": str(row.get("dta_number", "")),
                    "trial_id": str(row.get("trial_id", "")),
                    "vendor": str(row.get("vendor", "")),
                    "data_stream": str(row.get("data_stream", "")),
                    "status": str(row.get("status", "")),
                    "workflow_state": str(row.get("workflow_state", "")),
                    "version": str(row.get("version", "")),
                    "notes": str(row.get("notes", "") or ""),
                    "created_by": str(row.get("created_by_principal", "")),
                    "created_ts": created_display,
                    "last_updated_ts": updated_display,
                    "created_ts_raw": str(created_ts),
                    "last_updated_ts_raw": str(last_updated_ts)
                })
    except Exception as e:
        print(f"ERROR: Failed to query DTAs: {e}")
        import traceback
        traceback.print_exc()
    
    has_more = (offset + len(dtas)) < total_count
    next_offset = offset + limit if has_more else None
    
    print(f"DEBUG: Retrieved {len(dtas)} DTAs (total: {total_count}, has_more: {has_more})")
    
    return {
        "dtas": dtas,
        "total_count": total_count,
        "has_more": has_more,
        "next_offset": next_offset,
        "offset": offset,
        "limit": limit
    }


def _get_recent_activity_from_db():
    """
    Query recent activity from Gold tables:
    - md_version_registry: Version creation events
    - dta: DTA creation/update events
    - dta_workflow: Workflow status changes
    
    Returns list of activity records sorted by timestamp.
    """
    config = _get_db_config()
    catalog = config['catalog']
    gold_schema = config['gold_schema']
    
    # UNION query to get activity from multiple tables
    query = f"""
        (
            -- Version Registry: Version created/updated
            SELECT 
                'VERSION' as source,
                version as entity_id,
                CASE version_type
                    WHEN 'DTA_TEMPLATE' THEN CONCAT('Library v', version, ' released (', COALESCE(record_count, 0), ' records)')
                    WHEN 'DTA_APPROVED' THEN CONCAT('DTA version ', version, ' approved (', COALESCE(record_count, 0), ' records)')
                    WHEN 'DTA_DRAFT' THEN CONCAT('Draft ', version, ' created')
                    ELSE CONCAT('Version ', version, ' updated')
                END as message,
                version_type as activity_type,
                status,
                created_ts as activity_ts,
                created_by_principal as user_principal,
                CASE version_type
                    WHEN 'DTA_TEMPLATE' THEN '📚'
                    WHEN 'DTA_APPROVED' THEN '📦'
                    WHEN 'DTA_DRAFT' THEN '📝'
                    ELSE '🔄'
                END as icon
            FROM {catalog}.{gold_schema}.md_version_registry
            WHERE created_ts >= current_date() - INTERVAL 30 DAY
        )
        
        UNION ALL
        
        (
            -- DTA: DTA created or state changed
            SELECT 
                'DTA' as source,
                dta_id as entity_id,
                CASE 
                    WHEN workflow_state = 'APPROVED' THEN CONCAT('DTA ', dta_number, ' approved')
                    WHEN workflow_state = 'REJECTED' THEN CONCAT('DTA ', dta_number, ' rejected')
                    WHEN workflow_state = 'IN_REVIEW' THEN CONCAT('DTA ', dta_number, ' submitted for review')
                    WHEN created_ts = last_updated_ts THEN CONCAT('DTA ', dta_number, ' created')
                    ELSE CONCAT('DTA ', dta_number, ' updated')
                END as message,
                workflow_state as activity_type,
                status,
                COALESCE(last_updated_ts, created_ts) as activity_ts,
                COALESCE(last_updated_by_principal, created_by_principal) as user_principal,
                CASE workflow_state
                    WHEN 'APPROVED' THEN '✅'
                    WHEN 'REJECTED' THEN '❌'
                    WHEN 'IN_REVIEW' THEN '🔍'
                    ELSE '📋'
                END as icon
            FROM {catalog}.{gold_schema}.dta
            WHERE last_updated_ts >= current_date() - INTERVAL 30 DAY
        )
        
        ORDER BY activity_ts DESC
        LIMIT 15
    """
    
    print(f"=" * 60)
    print(f"DEBUG: Querying recent activity")
    print(f"DEBUG: Query:")
    print(query)
    print(f"=" * 60)
    
    client = _get_sql_client()
    results = client.execute_query(query)
    
    print(f"DEBUG: Found {len(results)} activity records")
    
    # Format results for display
    activities = []
    for row in results:
        # Format timestamp to relative time
        activity_ts = row.get("activity_ts", "")
        if activity_ts:
            try:
                if isinstance(activity_ts, str):
                    dt = datetime.fromisoformat(activity_ts.replace("Z", "+00:00"))
                else:
                    dt = activity_ts
                # Calculate relative time
                now = datetime.now(dt.tzinfo) if dt.tzinfo else datetime.now()
                delta = now - dt
                if delta.days > 0:
                    timestamp = f"{delta.days}d ago"
                elif delta.seconds >= 3600:
                    timestamp = f"{delta.seconds // 3600}h ago"
                elif delta.seconds >= 60:
                    timestamp = f"{delta.seconds // 60}m ago"
                else:
                    timestamp = "Just now"
            except:
                timestamp = str(activity_ts)[:10]
        else:
            timestamp = "Unknown"
        
        # Extract username from email
        user = row.get("user_principal", "")
        if "@" in user:
            user_short = user.split("@")[0]
        else:
            user_short = user or "System"
        
        activities.append({
            "icon": row.get("icon", "📋"),
            "message": row.get("message", "Activity"),
            "timestamp": timestamp,
            "user": user_short,
            "source": row.get("source", ""),
            "activity_type": row.get("activity_type", ""),
            "status": row.get("status", "")
        })
    
    return activities


def _format_versions_for_display(db_versions, entity_code: str, entity_name: str, entity_icon: str):
    """
    Format database version records for dashboard display.
    Includes vendor and data stream information for each template.
    
    Args:
        db_versions: List of version records from database (with DTA join)
        entity_code: Entity code (e.g., 'TV')
        entity_name: Display name
        entity_icon: Emoji icon
    
    Returns:
        Formatted entity dictionary for dashboard with vendor/stream details
    """
    if not db_versions:
        return None
    
    versions = []
    for i, v in enumerate(db_versions[:5]):  # Limit to 5 templates
        # First version is the "current" (latest) library version
        is_current = (i == 0)
        
        # Format created_ts
        created_ts = v.get("created_ts", "")
        if created_ts:
            try:
                if isinstance(created_ts, str):
                    # Parse ISO format
                    dt = datetime.fromisoformat(created_ts.replace("Z", "+00:00"))
                else:
                    dt = created_ts
                updated = dt.strftime("%b %d")
                updated_full = dt.strftime("%b %d, %Y")
            except:
                updated = str(created_ts)[:10]
                updated_full = updated
        else:
            updated = "N/A"
            updated_full = "N/A"
        
        # Extract username from email
        created_by = v.get("created_by_principal", "")
        if "@" in created_by:
            created_by_short = created_by.split("@")[0]
        else:
            created_by_short = created_by
        
        # Get vendor and data stream from DTA join
        vendor = v.get("data_provider_name", "")
        data_stream = v.get("data_stream_type", "")
        trial_id = v.get("trial_id", "")
        dta_number = v.get("dta_number", "")
        dta_name = v.get("dta_name", "")
        
        # Shorten vendor name for display (first 15 chars)
        vendor_short = (vendor[:15] + "..." if len(vendor) > 15 else vendor) if vendor else "—"
        
        # Shorten data stream for display
        stream_short = (data_stream[:12] + "..." if len(data_stream) > 12 else data_stream) if data_stream else "—"
        
        versions.append({
            "version": v.get("version", "N/A"),
            "version_type": v.get("version_type", ""),
            "is_current": is_current,
            "record_count": int(v.get("record_count", 0)),
            "updated": updated,
            "updated_full": updated_full,
            "parent_version": v.get("parent_version", ""),
            "created_by": created_by,
            "created_by_short": created_by_short,
            "dta_id": v.get("dta_id", ""),
            # New fields for vendor/stream
            "vendor": vendor,
            "vendor_short": vendor_short,
            "data_stream": data_stream,
            "stream_short": stream_short,
            "trial_id": trial_id,
            "dta_number": dta_number,
            "dta_name": dta_name
        })
    
    return {
        "code": entity_code,
        "name": entity_name,
        "icon": entity_icon,
        "versions": versions,
        "has_real_data": True
    }


# ============================================================================
# MOCK DATA (Fallback when DB not available)
# ============================================================================

def _get_mock_dtas():
    """Generate mock DTA data"""
    return [
        {
            "dta_id": "DTA012",
            "dta_number": "DTA012",
            "trial_id": "TRIAL-045",
            "vendor": "IQVIA",
            "data_stream": "Lab Results",
            "status": "IN_REVIEW",
            "version": "1.0-DTA012-draft3",
            "workflow_state": "IN_REVIEW",
            "created_ts": (datetime.now() - timedelta(days=2)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(hours=2)).isoformat(),
            "approvals": [
                {"reviewer_name": "Sarah Johnson", "role": "JNJ_DAE", "status": "Approved"},
                {"reviewer_name": "Alex Kumar", "role": "VENDOR", "status": "Pending"}
            ]
        },
        {
            "dta_id": "DTA011",
            "dta_number": "DTA011",
            "trial_id": "TRIAL-044",
            "vendor": "Parexel",
            "data_stream": "EDC Data",
            "status": "DRAFT",
            "version": "1.0-DTA011-draft1",
            "workflow_state": "NOT_STARTED",
            "created_ts": (datetime.now() - timedelta(days=3)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(hours=5)).isoformat(),
            "approvals": []
        },
        {
            "dta_id": "DTA010",
            "dta_number": "DTA010",
            "trial_id": "TRIAL-043",
            "vendor": "PPD",
            "data_stream": "Safety Data",
            "status": "APPROVED",
            "version": "1.0-DTA010-v1.0",
            "workflow_state": "APPROVED",
            "created_ts": (datetime.now() - timedelta(days=5)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(days=1)).isoformat(),
            "approvals": [
                {"reviewer_name": "Sarah Johnson", "role": "JNJ_DAE", "status": "Approved"},
                {"reviewer_name": "David Park", "role": "VENDOR", "status": "Approved"}
            ]
        },
        {
            "dta_id": "DTA009",
            "dta_number": "DTA009",
            "trial_id": "TRIAL-042",
            "vendor": "IQVIA",
            "data_stream": "PK Data",
            "status": "APPROVED",
            "version": "1.0-DTA009-v1.0",
            "workflow_state": "APPROVED",
            "created_ts": (datetime.now() - timedelta(days=7)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(days=2)).isoformat(),
            "approvals": [
                {"reviewer_name": "Emily Rodriguez", "role": "JNJ_DAE", "status": "Approved"},
                {"reviewer_name": "Jennifer Lee", "role": "VENDOR", "status": "Approved"}
            ]
        },
        {
            "dta_id": "DTA008",
            "dta_number": "DTA008",
            "trial_id": "TRIAL-041",
            "vendor": "Syneos",
            "data_stream": "EDC Data",
            "status": "REJECTED",
            "version": "1.0-DTA008-draft2",
            "workflow_state": "REJECTED",
            "created_ts": (datetime.now() - timedelta(days=10)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(days=3)).isoformat(),
            "approvals": [
                {"reviewer_name": "Michael Chen", "role": "JNJ_DAE", "status": "Rejected"}
            ]
        },
        {
            "dta_id": "DTA007",
            "dta_number": "DTA007",
            "trial_id": "TRIAL-040",
            "vendor": "Covance",
            "data_stream": "Lab Results",
            "status": "APPROVED",
            "version": "1.0-DTA007-v1.0",
            "workflow_state": "APPROVED",
            "created_ts": (datetime.now() - timedelta(days=12)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(days=5)).isoformat(),
            "approvals": [
                {"reviewer_name": "Sarah Johnson", "role": "JNJ_DAE", "status": "Approved"},
                {"reviewer_name": "Alex Kumar", "role": "VENDOR", "status": "Approved"}
            ]
        },
        {
            "dta_id": "DTA006",
            "dta_number": "DTA006",
            "trial_id": "TRIAL-039",
            "vendor": "ICON",
            "data_stream": "Safety Data",
            "status": "IN_REVIEW",
            "version": "1.0-DTA006-draft2",
            "workflow_state": "IN_REVIEW",
            "created_ts": (datetime.now() - timedelta(days=4)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(hours=8)).isoformat(),
            "approvals": [
                {"reviewer_name": "Emily Rodriguez", "role": "JNJ_DAE", "status": "Pending"}
            ]
        },
        {
            "dta_id": "DTA005",
            "dta_number": "DTA005",
            "trial_id": "TRIAL-038",
            "vendor": "PRA Health",
            "data_stream": "EDC Data",
            "status": "DRAFT",
            "version": "1.0-DTA005-draft1",
            "workflow_state": "NOT_STARTED",
            "created_ts": (datetime.now() - timedelta(days=1)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(hours=12)).isoformat(),
            "approvals": []
        }
    ]


def _get_dta_templates():
    """
    Get DTA Templates (TPL001, TPL002, etc.) with metadata counts per type.
    
    Returns a list of templates with:
    - Template ID (TPL001, TPL002, etc.)
    - Vendor, Data Stream
    - Count of each metadata type (transfer_variables, test_concepts, etc.)
    
    Also includes a placeholder for "Generic Template" (coming soon).
    """
    config = _get_db_config()
    dta_table = f"{config['catalog']}.{config['gold_schema']}.dta"
    registry_table = f"{config['catalog']}.{config['gold_schema']}.md_version_registry"
    
    # Query templates from DTA table with metadata counts from registry
    query = f"""
        WITH template_metadata AS (
            SELECT 
                r.dta_id,
                r.library_type,
                r.record_count,
                r.version
            FROM {registry_table} r
            WHERE r.version_type = 'DTA_TEMPLATE'
              AND r.status = 'ACTIVE'
        )
        SELECT 
            d.dta_id,
            d.dta_number,
            d.dta_name,
            d.data_provider_name,
            d.data_stream_type,
            d.trial_id,
            d.created_ts,
            d.last_updated_ts,
            COALESCE(SUM(CASE WHEN m.library_type = 'transfer_variables' THEN m.record_count ELSE 0 END), 0) as transfer_variables_count,
            COALESCE(SUM(CASE WHEN m.library_type = 'test_concepts' THEN m.record_count ELSE 0 END), 0) as test_concepts_count,
            COALESCE(SUM(CASE WHEN m.library_type = 'codelists' THEN m.record_count ELSE 0 END), 0) as codelists_count,
            COALESCE(SUM(CASE WHEN m.library_type = 'operational_agreements' THEN m.record_count ELSE 0 END), 0) as operational_agreements_count,
            MAX(m.version) as template_version
        FROM {dta_table} d
        LEFT JOIN template_metadata m ON d.dta_id = m.dta_id
        WHERE d.dta_number LIKE 'TPL%'
          AND d.status = 'ACTIVE'
        GROUP BY d.dta_id, d.dta_number, d.dta_name, d.data_provider_name, 
                 d.data_stream_type, d.trial_id, d.created_ts, d.last_updated_ts
        ORDER BY d.dta_number DESC
    """
    
    print(f"=" * 60)
    print("DEBUG: Fetching DTA Templates with metadata counts")
    print(f"Query: {query}")
    print(f"=" * 60)
    
    templates = []
    
    # Add Generic Template placeholder first
    templates.append({
        "id": "generic",
        "dta_number": "GENERIC",
        "dta_name": "Generic Template",
        "vendor": None,
        "data_stream": None,
        "is_generic": True,
        "coming_soon": True,
        "metadata_counts": {
            "transfer_variables": 0,
            "test_concepts": 0,
            "codelists": 0,
            "operational_agreements": 0
        },
        "total_records": 0,
        "version": None,
        "updated": None,
        "description": "Start with an empty template"
    })
    
    try:
        client = _get_sql_client()
        results = client.execute_query(query)
        
        print(f"DEBUG: Found {len(results)} DTA templates")
        
        for row in results:
            # Format date
            updated_ts = row.get("last_updated_ts") or row.get("created_ts")
            if updated_ts:
                try:
                    if isinstance(updated_ts, str):
                        dt = datetime.fromisoformat(updated_ts.replace("Z", "+00:00"))
                    else:
                        dt = updated_ts
                    updated = dt.strftime("%b %d, %Y")
                except:
                    updated = str(updated_ts)[:10]
            else:
                updated = "N/A"
            
            # Get metadata counts
            tv_count = int(row.get("transfer_variables_count", 0))
            tc_count = int(row.get("test_concepts_count", 0))
            cl_count = int(row.get("codelists_count", 0))
            oa_count = int(row.get("operational_agreements_count", 0))
            total_records = tv_count + tc_count + cl_count + oa_count
            
            vendor = row.get("data_provider_name", "")
            data_stream = row.get("data_stream_type", "")
            
            templates.append({
                "id": row.get("dta_id"),
                "dta_number": row.get("dta_number"),
                "dta_name": row.get("dta_name", ""),
                "vendor": vendor,
                "vendor_short": (vendor[:15] + "..." if len(vendor) > 15 else vendor) if vendor else "—",
                "data_stream": data_stream,
                "stream_short": (data_stream[:12] + "..." if len(data_stream) > 12 else data_stream) if data_stream else "—",
                "is_generic": False,
                "coming_soon": False,
                "metadata_counts": {
                    "transfer_variables": tv_count,
                    "test_concepts": tc_count,
                    "codelists": cl_count,
                    "operational_agreements": oa_count
                },
                "total_records": total_records,
                "version": row.get("template_version"),
                "updated": updated,
                "description": f"{vendor} • {data_stream}" if vendor and data_stream else ""
            })
            
            print(f"  - {row.get('dta_number')}: TV={tv_count}, TC={tc_count}, CL={cl_count}, OA={oa_count}")
    
    except Exception as e:
        print(f"ERROR: Failed to fetch DTA templates: {e}")
        import traceback
        traceback.print_exc()
    
    return templates


def _get_library_data():
    """
    Get library data for all 6 metadata entities from database.
    Uses a single query with IN clause for efficiency.
    Shows "No data found" for entities without versions.
    """
    entities = []
    
    # Define all library types with display info
    library_configs = [
        ("transfer_variables", "TV", "Transfer Variables", "📊"),
        ("codelists", "CL", "Codelists", "📋"),
        ("test_concepts", "TC", "Test Concepts", "🧪"),
        ("operational_agreements", "OA", "Operational Agreements", "📝"),
        ("visits_timepoints", "VT", "Visits & Timepoints", "📅"),
        ("data_ingestion_parameters", "DIP", "Data Ingestion Parameters", "⚙️"),
    ]
    
    # Single query for all library types
    print("\n=== Fetching All Library Versions ===")
    versions_by_type = _get_all_versions_from_db()
    
    # Build entities from grouped results
    for lib_type, code, name, icon in library_configs:
        db_versions = versions_by_type.get(lib_type, [])
        
        if db_versions:
            # Limit to 5 versions per type
            entity = _format_versions_for_display(db_versions[:5], code, name, icon)
            if entity:
                entities.append(entity)
                print(f"✓ {name}: {len(db_versions)} versions found")
            else:
                # Format returned None (shouldn't happen, but handle it)
                entities.append({
                    "code": code,
                    "name": name,
                    "icon": icon,
                    "versions": [],
                    "has_real_data": True,
                    "message": "No data found"
                })
                print(f"⚠ {name}: No versions formatted")
        else:
            # No versions found for this library type - show message in panel
            entities.append({
                "code": code,
                "name": name,
                "icon": icon,
                "versions": [],
                "has_real_data": True,
                "message": "No data found"
            })
            print(f"⚠ {name}: No data found")
    
    print(f"\n=== Library Data Summary ===")
    print(f"Total entities: {len(entities)}")
    for e in entities:
        version_count = len(e.get("versions", []))
        msg = e.get("message", "")
        if msg:
            print(f"  - {e['name']}: {msg}")
        else:
            print(f"  - {e['name']}: {version_count} versions")
    
    return {"entities": entities}


def _get_mock_activity():
    """Get mock recent activity"""
    return [
        {
            "type": "submission",
            "message": "DTA012 submitted for approval",
            "timestamp": (datetime.now() - timedelta(hours=2)).isoformat(),
            "user": "john.doe@jnj.com",
            "icon": "📤"
        },
        {
            "type": "approval",
            "message": "DTA010 approved by Sarah Johnson",
            "timestamp": (datetime.now() - timedelta(hours=5)).isoformat(),
            "user": "sarah.johnson@jnj.com",
            "icon": "✅"
        },
        {
            "type": "library",
            "message": "Library promoted to v2.0",
            "timestamp": (datetime.now() - timedelta(days=1)).isoformat(),
            "user": "lisa.wong@jnj.com",
            "icon": "📚"
        },
        {
            "type": "approval",
            "message": "DTA009 approved by Vendor",
            "timestamp": (datetime.now() - timedelta(days=2)).isoformat(),
            "user": "david.park@vendor.com",
            "icon": "✅"
        },
        {
            "type": "rejection",
            "message": "DTA008 rejected - missing required fields",
            "timestamp": (datetime.now() - timedelta(days=3)).isoformat(),
            "user": "michael.chen@jnj.com",
            "icon": "❌"
        },
        {
            "type": "draft",
            "message": "DTA011 draft created",
            "timestamp": (datetime.now() - timedelta(days=3)).isoformat(),
            "user": "emily.rodriguez@jnj.com",
            "icon": "📝"
        }
    ]


def _get_mock_processing_stats():
    """Get mock processing statistics"""
    return {
        "this_month": {
            "dtas_created": 12,
            "files_processed": 48,
            "documents_uploaded": 156
        },
        "monthly_trend": [
            {"month": "Oct", "count": 8},
            {"month": "Nov", "count": 10},
            {"month": "Dec", "count": 12}
        ],
        "success_rate": 94.5
    }


# ============================================================================
# API ENDPOINTS
# ============================================================================

@dashboard_bp.route('/action-required')
def get_action_required():
    """
    Get counts for action required cards.
    Returns: pending approvals, my drafts, processing documents, ready for promotion
    """
    dtas = _get_mock_dtas()
    
    # Count pending approvals (DTAs in IN_REVIEW with pending approval tasks for current user)
    pending_approvals = len([d for d in dtas if d['status'] == 'IN_REVIEW'])
    
    # Count my drafts (DTAs in DRAFT status)
    my_drafts = len([d for d in dtas if d['status'] == 'DRAFT'])
    
    # Processing documents (mock - documents currently being processed)
    processing_documents = 5
    
    # Ready for promotion (approved DTA majors not yet in library)
    ready_for_promotion = 1
    
    return jsonify({
        "success": True,
        "data": {
            "pending_approvals": pending_approvals,
            "my_drafts": my_drafts,
            "processing_documents": processing_documents,
            "ready_for_promotion": ready_for_promotion
        }
    })


@dashboard_bp.route('/dta-overview')
def get_dta_overview():
    """
    Get DTA overview with status breakdown.
    """
    overview = _get_dta_overview_from_db()
    
    return jsonify({
        "success": True,
        "data": overview
    })


@dashboard_bp.route('/library-overview')
def get_library_overview():
    """
    Get library version overview for all 6 metadata entities.
    """
    library = _get_library_data()
    
    return jsonify({
        "success": True,
        "data": {
            "entities": library["entities"]
        }
    })


@dashboard_bp.route('/recent-dtas')
def get_recent_dtas():
    """
    Get recent DTAs with pagination for infinite scroll.
    
    Query params:
        offset: Starting position (default 0)
        limit: Number of records to fetch (default 100, max 100)
    
    Returns:
        dtas: List of DTA records
        total_count: Total number of DTAs
        has_more: Whether more records exist
        next_offset: Offset for next page (null if no more)
    """
    from flask import request
    
    offset = request.args.get('offset', 0, type=int)
    limit = min(request.args.get('limit', 100, type=int), 100)  # Max 100
    
    # Get real data from database
    result = _get_recent_dtas_from_db(offset=offset, limit=limit)
    
    return jsonify({
        "success": True,
        "data": result
    })


@dashboard_bp.route('/recent-activity')
def get_recent_activity():
    """
    Get recent activity feed.
    """
    activity = _get_recent_activity_from_db()
    
    return jsonify({
        "success": True,
        "data": {
            "activities": activity
        }
    })


@dashboard_bp.route('/promotion-candidates')
def get_promotion_candidates():
    """
    Get DTAs ready for template promotion, grouped by (vendor, data_stream).
    
    Each group represents a potential DTA Template that can be created or updated.
    Groups include:
    - Vendor and data stream info
    - List of approved DTAs ready to promote
    - Current template version (if exists)
    
    Used by the Approvals UI to show promotion cards.
    """
    candidates = _get_promotion_candidates_from_db()
    
    return jsonify({
        "success": True,
        "data": {
            "groups": candidates,
            "total_groups": len(candidates),
            "total_dtas": sum(c.get('dta_count', 0) for c in candidates)
        }
    })


@dashboard_bp.route('/manual-review')
def get_manual_review_dtas():
    """
    Get DTAs that require manual review.
    These have status = 'MANUAL_REVIEW'.
    
    Returns list of DTAs with review reason (from notes field).
    """
    dtas = _get_dtas_needing_manual_review()
    
    return jsonify({
        "success": True,
        "data": {
            "dtas": dtas,
            "total_count": len(dtas)
        }
    })


@dashboard_bp.route('/processing-stats')
def get_processing_stats():
    """
    Get processing statistics for charts.
    """
    stats = _get_processing_stats_from_db()
    
    return jsonify({
        "success": True,
        "data": stats
    })


@dashboard_bp.route('/summary')
def get_dashboard_summary():
    """
    Get all dashboard data in a single call for initial page load.
    This combines all the above endpoints for efficiency.
    """
    # Get real data from database
    library = _get_library_data()
    dta_overview = _get_dta_overview_from_db()
    stats = _get_processing_stats_from_db()
    activity = _get_recent_activity_from_db()
    
    # Get real DTAs from database with pagination
    dtas_result = _get_recent_dtas_from_db(offset=0, limit=100)
    dtas = dtas_result.get("dtas", [])
    
    return jsonify({
        "success": True,
        "data": {
            "action_required": {
                "pending_approvals": dta_overview["by_status"]["in_review"],
                "my_drafts": dta_overview["by_status"]["draft"],
                "manual_review": dta_overview["by_status"]["manual_review"],
            },
            "dta_overview": dta_overview,
            "library_entities": library["entities"],
            "recent_dtas": dtas[:10],
            "recent_dtas_all": dtas,
            "dtas_pagination": {
                "total_count": dtas_result.get("total_count", 0),
                "has_more": dtas_result.get("has_more", False),
                "next_offset": dtas_result.get("next_offset")
            },
            "recent_activity": activity,  # All activity for infinite scroll
            "processing_stats": stats
        }
    })


# ============================================================================
# HELPER FUNCTIONS FOR TEMPLATE RENDERING
# ============================================================================

def get_dashboard_data():
    """
    Get all dashboard data for template rendering.
    Returns a dictionary with all dashboard components.
    """
    # Get real data from database
    library = _get_library_data()
    dta_overview = _get_dta_overview_from_db()
    stats = _get_processing_stats_from_db()
    activity = _get_recent_activity_from_db()
    ready_to_promote = _get_ready_to_promote_count()
    dta_templates = _get_dta_templates()  # New: simplified template list
    
    # Get real DTAs from database (first page for initial load)
    dtas_result = _get_recent_dtas_from_db(offset=0, limit=100)
    dtas = dtas_result.get("dtas", [])
    dtas_pagination = {
        "total_count": dtas_result.get("total_count", 0),
        "has_more": dtas_result.get("has_more", False),
        "next_offset": dtas_result.get("next_offset")
    }
    
    return {
        "action_required": {
            "pending_approvals": dta_overview["by_status"]["in_review"],
            "my_drafts": dta_overview["by_status"]["draft"],
            "ready_to_promote": ready_to_promote,
            "manual_review": dta_overview["by_status"]["manual_review"],
        },
        "dta_overview": dta_overview,
        "library_entities": library["entities"],
        "dta_templates": dta_templates,  # New: simplified template list
        "recent_dtas": dtas[:10],  # Initial display of 10 (real data)
        "recent_dtas_all": dtas,    # Full cached data (up to 100)
        "dtas_pagination": dtas_pagination,  # Pagination info for infinite scroll
        "recent_activity": activity,  # All activity for infinite scroll
        "processing_stats": stats
    }


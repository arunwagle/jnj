# API Architecture Guide

## Overview

This document explains the new API layer architecture for easier backend integration.

## Architecture

```
┌─────────────┐
│  templates/ │  ← UI Layer
└──────┬──────┘
       │
┌──────▼──────┐
│   app.py    │  ← Flask Routes (thin layer)
└──────┬──────┘
       │
┌──────▼──────┐
│   api.py    │  ← API Layer (business logic)
└──────┬──────┘
       │
┌──────▼──────┐
│   data.py   │  ← Mock Data (in production: real backend)
└─────────────┘
```

## Key Benefits

1. **Clean Separation**: Routes only handle HTTP concerns
2. **Easy Testing**: API functions can be tested independently
3. **Simple Backend Integration**: Just replace API functions with real backend calls
4. **Consistent Responses**: All API functions return standardized format

## API Response Format

All API functions return a consistent structure:

```python
{
    "success": True/False,
    "data": {...},           # For successful responses
    "error": "message",      # For errors
    "message": "info"        # Optional message
}
```

## Example: Dashboard Route

### Before (Direct Data Access)
```python
@app.route("/dashboard")
def dashboard():
    # Direct data manipulation in route
    all_dtas = []
    for ws in WORKSPACES.values():
        status = ws.get("status", "Draft")
        if status in ["Pending Approval", "Approved"]:
            all_dtas.append(ws)
    
    all_dtas.sort(key=lambda x: x.get("submitted_at", ""), reverse=True)
    pending_dtas = [ws for ws in all_dtas if ws.get("status") == "Pending Approval"]
    approved_dtas = [ws for ws in all_dtas if ws.get("status") == "Approved"]
    
    return render_template("dashboard.html", ...)
```

### After (API Layer)
```python
import api

@app.route("/dashboard")
def dashboard():
    # Call API function
    result = api.get_dashboard_dtas()
    
    if not result["success"]:
        flash(f"Error: {result.get('error')}", "error")
        return render_template("dashboard.html", pending_dtas=[], approved_dtas=[], total_count=0)
    
    data = result["data"]
    return render_template("dashboard.html", 
                         pending_dtas=data["pending_dtas"],
                         approved_dtas=data["approved_dtas"],
                         total_count=data["total_count"])
```

## Available API Functions

### Dashboard
- `get_dashboard_dtas(status_filter=None)` - Get DTAs for dashboard

### Workspace
- `get_workspace(key)` - Get workspace by key
- `search_workspaces(query)` - Search workspaces
- `create_or_get_workspace(result)` - Create/get workspace

### Approvals
- `get_pending_approvals()` - Get pending approvals
- `submit_for_approval(key, approvers)` - Submit for approval
- `approve_dta(key)` - Approve DTA
- `reject_dta(key, reason)` - Reject DTA
- `get_approvers()` - Get available approvers

### Jobs
- `get_jobs(status_filter=None)` - Get ingestion jobs
- `create_export_job(key)` - Create export job
- `publish_major_version(key)` - Publish major version

### Entity Operations
- `add_tc_row(key)` - Add test concept row
- `add_tv_row(key)` - Add transfer variable
- `update_entity_state(key, entity_type, index, action, data)` - Generic state update

### Transfer Keys
- `add_transfer_key(key, variable)` - Add transfer key
- `remove_transfer_key(key, variable)` - Remove transfer key

## Migration Strategy

### Option 1: Gradual Migration (Recommended)
1. Start with high-value routes (Dashboard, Approvals)
2. Test thoroughly
3. Migrate remaining routes incrementally

### Option 2: Full Migration
1. Create `data.py` with all mock data
2. Update all routes to use API functions
3. Test comprehensively
4. Deploy

### Option 3: Parallel Run
1. Keep existing routes
2. Create new API-based routes (e.g., `/api/v2/dashboard`)
3. Gradually switch frontend to use new routes
4. Remove old routes when stable

## Next Steps for Backend Integration

When integrating with real backend:

1. **Replace `api.py` functions** with real API calls:
   ```python
   # Current (Mock)
   def get_dashboard_dtas(status_filter=None):
       data = WORKSPACES.values()  # Mock data
       return {"success": True, "data": data}
   
   # Future (Real Backend)
   def get_dashboard_dtas(status_filter=None):
       response = requests.get(f"{BACKEND_URL}/api/dtas", params={"status": status_filter})
       return response.json()
   ```

2. **No changes needed** to:
   - Flask routes (app.py)
   - Templates
   - Frontend JavaScript

## Questions?

- Mock data is in `WORKSPACES`, `MOCK_RUNS`, `MOCK_RESULTS` (app.py)
- Should be moved to `data.py` for cleaner separation
- API functions are fully implemented in `api.py`
- Ready for gradual or full migration


# DTA Builder - Design Document

> **Version**: 1.0  
> **Date**: January 2026  
> **Status**: Implemented

---

## Table of Contents

- [Part 1: Design Overview](#part-1-design-overview)
  - [Project Overview](#project-overview)
  - [Architecture Summary](#architecture-summary)
- [Part 2: Job Architecture](#part-2-job-architecture)
  - [Overview](#overview)
  - [Main Jobs](#main-jobs)
  - [Test Jobs](#test-jobs)
- [Part 3: Schema Design](#part-3-schema-design)
  - [Tables Summary](#tables-summary)
  - [Gold Layer Tables](#gold-layer-tables)
  - [Silver Layer Tables](#silver-layer-tables)
  - [Bronze Layer Tables](#bronze-layer-tables)
- [Part 4: Status Lifecycle](#part-4-status-lifecycle)
  - [Document Statuses](#document-statuses)
  - [DTA and Metadata Statuses](#dta-and-metadata-statuses)
- [Part 5: Versioning](#part-5-versioning)
  - [Version Types](#version-types)
  - [Version Manager Operations](#version-manager-operations)
  - [DTA Template Creation](#dta-template-creation)
- [Part 6: Hash Generation](#part-6-hash-generation)
  - [Transfer Variables](#transfer-variables)
  - [Test Concepts](#test-concepts)
  - [Hash Algorithm](#hash-algorithm)
- [Part 7: DTA Workflow](#part-7-dta-workflow)
  - [Approver Roles](#approver-roles)
  - [DTA Lifecycle States](#dta-lifecycle-states)
  - [State Transitions](#state-transitions)
- [Part 8: AI Processing](#part-8-ai-processing)
  - [AI Capabilities](#ai-capabilities)
  - [Model Selection](#model-selection)
  - [Patterns](#patterns)
- [Part 9: Permissions](#part-9-permissions)
  - [Authentication Modes](#authentication-modes)
  - [Unity Catalog Permissions](#unity-catalog-permissions)
  - [Role-Based Access Control](#role-based-access-control)
- [Part 10: Genie Integration](#part-10-genie-integration)
  - [Asset Generation Job](#asset-generation-job)
  - [UI Design](#ui-design)
  - [Best Practices](#best-practices-for-designing-genie-spaces)

---

# Part 1: Design Overview

## Project Overview

The **DTA Builder** is a metadata-driven platform for managing Data Transfer Agreements (DTAs) across the clinical data lifecycle. DTAs define the specifications, formats, and validation rules for data exchanged between pharmaceutical sponsors and external vendors (labs, CROs, data providers).

### Purpose

- **Standardize** DTA creation and management across clinical trials
- **Automate** metadata extraction from legacy Excel-based specifications
- **Version Control** all changes with full audit trail
- **Accelerate** delivery timelines through reusable templates
- **Ensure Governance** with multi-party approval workflows

### Key Capabilities

| Capability | Description |
|------------|-------------|
| **Metadata-Driven** | Capture transfer variables, test concepts, codelists as structured metadata |
| **Template Library** | Create reusable templates scoped by vendor and data stream |
| **Version Management** | SCD Type 2 versioning with branch, draft, approve, promote lifecycle |
| **Approval Workflow** | Multi-party approval chain (JNJ DAE → Vendor → Legal → Librarian) |
| **AI-Powered** | Document parsing, entity extraction, natural language search |
| **Export Formats** | Generate tsDTA Excel, Operational Agreement PDFs, full packages |

---

## Architecture Summary

### Platform

The DTA Builder is built on **Databricks** with the following components:

| Component | Technology | Purpose |
|-----------|------------|---------|
| **Data Platform** | Databricks Unity Catalog | Data governance, lineage, permissions |
| **Processing** | Databricks Jobs + Notebooks | ETL pipelines, versioning operations |
| **Storage** | Delta Lake (Bronze/Silver/Gold) | Medallion architecture for data layers |
| **UI Application** | Databricks Apps (Flask) | Web interface for DTA management |
| **Genie Agent** | Databricks AI/BI Genie | Natural language search and discovery |

### High-Level Architecture

#### DTA Builder Architecture

![DTA Builder Architecture](./diagrams/00_dta_builder_architecture.drawio.png)

#### CDH (Clinical Data Hub) - Future State Conceptual Architecture

> **Note**: This is a conceptual architecture based on the CDR Hackathon requirements. It illustrates the envisioned downstream flow from DTA Builder.

The CDH diagram expands the downstream consumer of DTA Builder, showing how approved DTAs flow into the Clinical Data Hub for study setup, vendor data ingestion, and conformance validation.

![CDH Conceptual Architecture](./diagrams/00_cdh_architecture.drawio.png)

---

# Part 2: Job Architecture

## Overview

This section describes the Clinical Data Standards job architecture for processing DTA (Data Transfer Agreement) data, managing versions, and exporting metadata.

### Main Jobs

| Job Name | Purpose | Trigger |
|----------|---------|---------|
| `job_cdm_dta_import` | End-to-end orchestrator for historical DTA import | File Arrival / Manual |
| `job_cds_file_processor` | Extract ZIP archives and create document manifest | Called by orchestrator |
| `job_cds_tsdta_xls_processor` | Process tsDTA Excel files (sheets, codelists, transfer vars, test concepts) | Called by orchestrator |
| `job_cdm_dta_create` | Create DTA instances and manage versioning | Called by orchestrator / API |
| `job_cdm_version_manager` | Versioning operations (branch, save, approve, template) | API / UI |
| `job_cdm_export_file` | Export DTA metadata to Excel/PDF files | API / UI |
| `job_cdm_export_genie_assets` | Generate Genie space training assets | Manual |
| `job_populate_config_cache` | Load configuration into Spark cache | Called by other jobs |

### Test Jobs

| Job Name | Purpose | Triggers |
|----------|---------|----------|
| `job_test_cdm_dta_import` | End-to-end test for DTA import pipeline | `job_cdm_dta_import` |
| `job_test_cdm_cleanup` | Drop all tables and delete checkpoint folders | Direct notebook |
| `job_test_cdm_create_dta_template` | Test DTA Template creation from approved DTAs | `job_cdm_version_manager` |
| `job_test_cdm_export_genie_assets` | Test Genie asset generation | `job_cdm_export_genie_assets` |
| `job_test_cds_sql_setup` | Test SQL catalog/schema setup | `job_cds_sql_setup` |

---

### Diagrams

| Diagram | Description | View |
|---------|-------------|------|
| DTA Import | End-to-end orchestrator flow | ![](./diagrams/01_job_cdm_dta_import.drawio.png) |
| File Processor | ZIP extraction and manifest creation | ![](./diagrams/01_job_cds_file_processor.drawio.png) |
| tsDTA Processor | Excel sheet processing pipeline | ![](./diagrams/01_job_cds_tsdta_xls_processor.drawio.png) |
| DTA Create | DTA instance creation with branching | ![](./diagrams/01_job_cdm_dta_create.drawio.png) |
| Version Manager | Condition chain for versioning actions | ![](./diagrams/01_job_cdm_version_manager.drawio.png) |
| Export File | File export to Volumes | ![](./diagrams/01_job_cdm_export_file.drawio.png) |
| Export Genie Assets | Genie training asset generation | ![](./diagrams/01_job_cdm_export_genie_assets.drawio.png) |

---

## Main Jobs

### 1. job_cdm_dta_import

**Description**

The main orchestrator job for importing historical clinical trial data end-to-end. It coordinates file extraction, Excel processing, and DTA entity creation.

**Trigger**

| Type | Details |
|------|---------|
| File Arrival | Automatically triggers when new ZIP files land in `/Volumes/{catalog}/bronze_md/clinical_data_standards/historical_data/uploads/` |
| Manual | Can be run via Databricks CLI or UI |

**Pipeline Flow**

| Task | Description | Dependency |
|------|-------------|------------|
| `process_files` | Extract ZIP archives, create manifest | - |
| `process_tsdta` | Process tsDTA Excel files | `process_files` |
| `create_dta` | Create DTA entities and versions | `process_tsdta` |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_dta_import.job.yml` |
| Notebooks | Uses `run_job_task` to call child jobs |

---

### 2. job_cds_file_processor

**Description**

Processes ZIP files containing clinical trial documents. Extracts archives, creates document manifest in bronze layer, and tags files for downstream processing.

**Pipeline Flow**

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `process_files` | Extract ZIPs, create manifest, tag documents | `setup` |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_file_processor.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Processor Notebook | `notebooks/data_engineering/clinical_data_standards/jobs/nb_file_processor.ipynb` |

---

### 3. job_cds_tsdta_xls_processor

**Description**

Processes tsDTA (Trial Specific Data Transfer Agreement) Excel files. Extracts sheets, processes codelists, transfer variables, and test concepts into silver layer tables.

**Pipeline Flow**

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `extract_excel_sheets` | Read Excel files, extract sheet data to bronze | `setup` |
| `load_codelist` | Process codelists, create lookup table | `extract_excel_sheets` |
| `load_transfer_metadata` | Process transfer variables, compute hash | `load_codelist` |
| `load_test_concepts` | Extract test concepts with dynamic headers | `load_transfer_metadata` |
| `update_completion_status` | Mark documents as READY_FOR_VERSIONING | `load_test_concepts` |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_tsdta_processor.job.yml` |
| Extract Sheets | `notebooks/data_engineering/clinical_data_standards/jobs/nb_extract_excel_sheets.ipynb` |
| Codelists | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_code_lists_processor.ipynb` |
| Transfer Variables | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_transfer_variables_processor.ipynb` |
| Test Concepts | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_test_concepts_processor.ipynb` |

---

### 4. job_cdm_dta_create

**Description**

Creates DTA instances and manages the versioning workflow. Supports two modes:
- **HISTORICAL**: Simulates full draft → approve flow (for bulk import)
- **UI**: Creates DTA in draft status for manual editing

**Pipeline Flow**

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `create_dta_instance` | Create DTA entity record | `setup` |
| `check_source` | Condition: Is source HISTORICAL? | `create_dta_instance` |
| **HISTORICAL Branch:** | | |
| `save_draft` | Link silver records with draft version | `check_source` (true) |
| `approve_to_major` | Promote draft to DTA Major in gold | `save_draft` |
| **UI Branch:** | | |
| `create_branch` | Create branch from library template | `check_source` (false) |

---

### 5. job_cdm_version_manager

**Description**

Manages Clinical Data Metadata versioning operations using SCD Type 2. Supports five mutually exclusive actions via condition task chain.

**Actions**

| Action | Description | Use Case |
|--------|-------------|----------|
| `CREATE_BRANCH` | Create new DTA draft from library template | UI initiates new DTA |
| `SAVE_DRAFT` | Save changes to existing draft | UI saves edits |
| `APPROVE_DTA` | Promote draft to DTA Major | Workflow approval |
| `CREATE_DTA_APPROVED` | Create DTA Major directly | Single DTA via API |
| `CREATE_DTA_TEMPLATE` | Merge approved DTAs into template | Librarian promotion |

---

### 6. job_cdm_export_file

**Description**

Generic file export job for DTA metadata. Generates Excel/PDF files and uploads to Unity Catalog Volumes.

**Export Types**

| Type | Format | Status |
|------|--------|--------|
| `tsDTA` | Excel (.xlsx) | Implemented |
| `oa` | PDF | Future |
| `dta_full` | ZIP package | Future |

**Output Path**

```
/Volumes/{catalog}/bronze_md/{source_root}/exports/{date}/{dta_number}/
```

---

### 7. job_cdm_export_genie_assets

**Description**

Generates Databricks Genie space training assets. Dynamically discovers tables, generates SQL comments, instructions, example queries, and assembles the serialized space configuration.

**Output Files**

```
/Volumes/{catalog}/bronze_md/{source_volume}/{source_root}/exports/genie/
├── sql/
│   ├── add_table_comments.sql
│   └── example_queries.sql
├── components/
│   ├── data_sources.json
│   ├── sample_questions.json
│   ├── text_instructions.json
│   └── example_queries.json
├── genie_instructions.txt
├── serialized_space.json
└── export_manifest.json
```

---

## Test Jobs

### job_test_cdm_dta_import

**Purpose**: End-to-end test for the DTA import pipeline.

| Parameter | Default | Description |
|-----------|---------|-------------|
| `catalog_override` | `aira_test` | Test catalog |
| `source_root` | `test` | Uses test/uploads folder |

---

### job_test_cdm_cleanup

**Purpose**: Drop all bronze, silver, and gold tables. Delete checkpoint and ingested folders.

> **WARNING**: Only run in dev/test environments!

---

### job_test_cdm_create_dta_template

**Purpose**: Test DTA Template creation from approved DTAs. Templates are scoped by (vendor, data_stream) combination.

| Parameter | Default | Description |
|-----------|---------|-------------|
| `library_type` | (empty) | Process all library types |
| `merge_strategy` | `UNION_DEDUP` | How to merge records |

---

# Part 3: Schema Design

## Overview

This section describes the database schema for the Clinical Data Standards DTA Management System. The schema follows the Medallion Architecture with Bronze, Silver, and Gold layers.

### Schema Layers

| Layer | Schema | Purpose |
|-------|--------|---------|
| Gold | `gold_md` | Approved DTA entities, workflows, and versioned metadata library |
| Silver | `silver_md` | Normalized draft data being reviewed before approval |
| Bronze | `bronze_md` | Raw ingestion of tsDTA files, document manifest, Excel metadata |

### Diagrams

#### Schema Data Flow

![Schema Data Flow](./diagrams/02_schema_design_tables.drawio.png)

#### Entity Relationship Diagram (ERD)

![ERD Diagram](./diagrams/02_schema_erd.drawio.png)

---

## Tables Summary

### Gold Layer (`gold_md`)

| Table | Purpose |
|-------|---------|
| `dta` | Core DTA entity representing a Data Transfer Agreement |
| `dta_workflow` | Workflow cycle tracking for DTA approval |
| `dta_approval_task` | Individual approval tasks within a workflow |
| `dta_activity_log` | Activity audit log for all DTA operations |
| `md_version_registry` | Central registry for all version metadata |
| `md_dta_transfer_variables` | Approved transfer variable definitions (SCD Type 2) |
| `md_dta_vendor_test_concepts` | Approved vendor test concept definitions |

### Silver Layer (`silver_md`)

| Table | Purpose |
|-------|---------|
| `md_dta_transfer_variables_draft` | Draft transfer variable definitions being reviewed |
| `md_dta_vendor_test_concepts_draft` | Draft vendor test concepts being reviewed |
| `md_codelists_normalized` | Standardized codelist values extracted from tsDTA |

### Bronze Layer (`bronze_md`)

| Table | Purpose |
|-------|---------|
| `md_file_history` | Document manifest with extraction status and completion tracking |
| `md_document_types` | Reference table for document type enablement |
| `md_dta_excel_file_raw` | Excel sheet metadata for tsDTA files |

---

## Gold Layer Tables

### 1. dta

**Purpose**: Core DTA entity representing a Data Transfer Agreement between J&J and a data provider.

| Column | Type | Description |
|--------|------|-------------|
| `dta_id` | STRING | **PK** - UUID identifier |
| `dta_number` | STRING | Human-readable ID (DTA001, DTA002) |
| `dta_name` | STRING | Descriptive name for the DTA |
| `trial_id` | STRING | Associated trial identifier |
| `data_stream_type` | STRING | Data stream type (Labs, ECG, etc.) |
| `data_provider_name` | STRING | Vendor/provider name |
| `status` | STRING | DRAFT, ACTIVE, MANUAL_REVIEW, ARCHIVED |
| `workflow_state` | STRING | NOT_STARTED, IN_REVIEW, APPROVED, REJECTED |
| `workflow_iteration` | INT | Current approval cycle number |
| `current_version_tag` | STRING | Active version tag |
| `current_draft_version` | STRING | Current draft version being edited |
| `latest_major_version` | STRING | Latest approved major version |
| `base_library_version` | STRING | Library version this DTA was branched from |
| `parent_document_id` | STRING | **FK** - Reference to source document |

---

### 2. dta_workflow

**Purpose**: Tracks the approval lifecycle for DTAs across stakeholders.

| Column | Type | Description |
|--------|------|-------------|
| `dta_workflow_id` | STRING | **PK** - UUID identifier |
| `dta_id` | STRING | **FK** - References dta table |
| `workflow_iteration` | INT | Iteration number (1, 2, 3...) |
| `workflow_status` | STRING | NOT_STARTED, IN_REVIEW, APPROVED, REJECTED |
| `summary_comment` | STRING | Workflow summary notes |
| `initiated_ts` | TIMESTAMP | When workflow started |
| `closed_ts` | TIMESTAMP | When workflow completed |

---

### 3. dta_approval_task

**Purpose**: Individual approval tasks within a workflow cycle.

| Column | Type | Description |
|--------|------|-------------|
| `approval_task_id` | STRING | **PK** - UUID identifier |
| `dta_workflow_id` | STRING | **FK** - References dta_workflow |
| `dta_id` | STRING | **FK** - References dta table |
| `approver_role` | STRING | Role: jnj_dae, vendor, librarian |
| `assigned_to_principal` | STRING | Assigned approver email |
| `approval_order` | INT | Order in approval chain (1, 2, 3) |
| `approval_status` | STRING | PENDING, APPROVED, REJECTED, SKIPPED |
| `approval_comment` | STRING | Approver's comment |
| `approved_ts` | TIMESTAMP | When approved/rejected |

---

### 4. dta_activity_log

**Purpose**: Captures the full audit history of all activities performed on DTAs.

| Column | Type | Description |
|--------|------|-------------|
| `activity_id` | STRING | **PK** - UUID identifier |
| `dta_id` | STRING | **FK** - References dta table |
| `entity_id` | STRING | ID of affected entity |
| `entity_name` | STRING | Name of entity |
| `activity_type` | STRING | CREATE, UPDATE, DELETE, APPROVE, REJECT |
| `activity_summary` | STRING | Human-readable summary |
| `field_name` | STRING | Changed field name |
| `old_value` | STRING | Previous value |
| `new_value` | STRING | New value |
| `version_tag` | STRING | Version when change occurred |
| `performed_by_principal` | STRING | User who performed action |
| `performed_ts` | TIMESTAMP | When action was performed |

---

### 5. md_version_registry

**Purpose**: Central registry for all version metadata, supporting SCD Type 2 lifecycle management.

| Column | Type | Description |
|--------|------|-------------|
| `version_tag` | STRING | **PK** - Unique version identifier |
| `library_type` | STRING | transfer_variables, test_concepts, codelists |
| `version_type` | STRING | DTA_TEMPLATE, DTA_APPROVED, DTA_DRAFT |
| `dta_id` | STRING | **FK** - Associated DTA (NULL for library templates) |
| `parent_version` | STRING | Version branched from |
| `record_count` | INT | Number of records in version |
| `status` | STRING | ACTIVE, SUPERSEDED, ARCHIVED |

---

### 6. md_dta_transfer_variables

**Purpose**: SCD Type 2 versioned library of approved transfer variable definitions.

| Column | Type | Description |
|--------|------|-------------|
| `definition_hash` | STRING | **PK** - Unique definition hash |
| `version` | STRING | **PK** - Version tag |
| `dta_id` | STRING | **FK** - Associated DTA |
| `transfer_variable_name` | STRING | Variable name |
| `transfer_variable_label` | STRING | Variable label |
| `transfer_variable_order` | INT | Order in transfer file |
| `format` | STRING | Data type |
| `anticipated_max_length` | INT | Maximum length |
| `transfer_file_key` | BOOLEAN | Part of unique key |
| `populate_for_all_records` | BOOLEAN | Required for all records |
| `codelist_values` | STRING | Associated codelists (JSON) |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `is_major_version` | BOOLEAN | TRUE for DTA Template versions |
| `is_dta_major` | BOOLEAN | TRUE for DTA Approved versions |
| `is_current` | BOOLEAN | Active version flag |
| `effective_start_ts` | TIMESTAMP | When version became active |
| `effective_end_ts` | TIMESTAMP | When superseded (NULL if current) |

---

## Silver Layer Tables

### 1. md_dta_transfer_variables_draft

**Purpose**: Draft transfer variable definitions being reviewed before approval.

| Column | Type | Description |
|--------|------|-------------|
| `transfer_variable_field_id` | STRING | **PK** - Unique record ID |
| `parent_document_id` | STRING | **FK** - References source document |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `transfer_variable_name` | STRING | Variable name |
| `format` | STRING | Data type (text, numeric, date) |
| `definition_hash` | STRING | Hash for deduplication |
| `status` | STRING | COMPLETED or MANUAL_REVIEW_REQUIRED |

---

### 2. md_codelists_normalized

**Purpose**: Standardized codelist values extracted from tsDTA files.

| Column | Type | Description |
|--------|------|-------------|
| `codelist_id` | STRING | **PK** - Unique codelist record ID |
| `parent_document_id` | STRING | **FK** - References source document |
| `transfer_variable_name` | STRING | Associated variable |
| `codelist_reference` | STRING | Codelist identifier |
| `code_value` | STRING | Individual code value |
| `status` | STRING | Processing status |

---

## Bronze Layer Tables

### 1. md_file_history

**Purpose**: Document manifest with extraction status and completion tracking.

| Column | Type | Description |
|--------|------|-------------|
| `document_id` | STRING | **PK** - Unique document identifier |
| `parent_document_id` | STRING | **FK** - Self-reference for parent ZIP |
| `zip_source_path` | STRING | Original ZIP file path |
| `extracted_path` | STRING | Extraction location |
| `file_extension` | STRING | File type extension |
| `document_tags` | ARRAY | Classification tags (tsDTA, DTA, etc.) |
| `status` | STRING | Processing status |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |

---

## Key Design Patterns

### 1. Parent-Child Document Linking

`parent_document_id` links child documents to parent ZIPs, enabling tracking of document lineage.

```
ZIP File (parent_document_id = NULL)
├── Excel File 1 (parent_document_id = ZIP.document_id)
│   ├── Sheet 1 (parent_document_id = Excel.document_id)
│   └── Sheet 2 (parent_document_id = Excel.document_id)
└── Excel File 2 (parent_document_id = ZIP.document_id)
```

### 2. SCD Type 2 Versioning

Used in `md_dta_transfer_variables` and `md_dta_vendor_test_concepts`:

| Column | Purpose |
|--------|---------|
| `effective_start_ts` | When version became active |
| `effective_end_ts` | When superseded (NULL if current) |
| `is_current` | Active version flag |
| `version` + `definition_hash` | Composite primary key |

### 3. Audit Columns

All tables include standard audit columns:

| Column | Type | Description |
|--------|------|-------------|
| `created_by_principal` | STRING | User who created the record |
| `created_ts` | TIMESTAMP | Record creation timestamp |
| `last_updated_by_principal` | STRING | User who last updated |
| `last_updated_ts` | TIMESTAMP | Last update timestamp |
| `databricks_job_id` | STRING | Job ID for lineage |
| `databricks_run_id` | STRING | Run ID for lineage |

---

# Part 4: Status Lifecycle

## Overview

This section describes the status values used throughout the Clinical Data Standards pipeline to track document processing and DTA lifecycle management.

### Purpose

Status tracking serves two key purposes:

1. **Document Processing** - Track the lifecycle of files from extraction through processing to DTA creation
2. **DTA Management** - Track the lifecycle of Data Transfer Agreements from draft through approval

### Diagrams

#### Document Processing Lifecycle

![Document Processing Lifecycle](./diagrams/03_document_processing_lifecycle.drawio.png)

#### DTA Status Lifecycle

![DTA Status Lifecycle](./diagrams/03_dta_status_lifecycle.drawio.png)

---

## Document Statuses

The `md_file_history` table in the Bronze layer tracks document processing status.

### Status Values

| Status | Description | Next Status |
|--------|-------------|-------------|
| `READY_FOR_PROCESSING` | File extracted, awaiting processing | TSDTA_PROCESSING, DOC_PROCESSING |
| `TSDTA_PROCESSING` | Excel sheets being extracted | EXCEL_EXTRACTION_COMPLETED, TSDTA_FAILED |
| `EXCEL_EXTRACTION_COMPLETED` | Sheets extracted successfully | READY_FOR_VERSIONING |
| `TSDTA_FAILED` | Excel processing failed | Manual intervention required |
| `DOC_PROCESSING` | PDF/Word being processed | DOC_COMPLETED, DOC_FAILED |
| `DOC_COMPLETED` | Document processed successfully | READY_FOR_VERSIONING |
| `DOC_FAILED` | Document processing failed | Manual intervention required |
| `READY_FOR_VERSIONING` | All processing complete | VERSIONING_IN_PROCESS |
| `VERSIONING_IN_PROCESS` | DTA creation in progress | VERSIONED, VERSIONING_FAILED |
| `VERSIONED` | DTA created successfully | Terminal state |
| `VERSIONING_FAILED` | DTA creation failed | Manual intervention required |
| `EXTRACTION_ERROR` | File extraction failed | Manual intervention required |

---

## DTA and Metadata Statuses

### DTA Entity Status

The `dta` table in the Gold layer tracks DTA lifecycle status.

#### Status Values

| Status | Description | Editable? |
|--------|-------------|-----------|
| `DRAFT` | DTA being created or edited | Yes |
| `ACTIVE` | All records validated, ready for use | Yes |
| `MANUAL_REVIEW` | Contains records needing review | Yes |
| `PENDING_APPROVAL` | Submitted, awaiting approval chain | No |
| `APPROVED` | All approvers approved | No |
| `REJECTED` | Approver rejected (returns to DRAFT) | Yes |
| `ARCHIVED` | Superseded by newer version | No |

### Silver Layer Validation Status

Records in the Silver layer have a `status` column indicating validation results.

| Status | Description |
|--------|-------------|
| `COMPLETED` | All required fields present and valid |
| `MANUAL_REVIEW_REQUIRED` | Missing or invalid fields needing review |

### Status Propagation (Silver → Gold)

When a DTA is created from Silver layer records:

- If **all records** have `status = COMPLETED` → DTA status is `ACTIVE`
- If **any record** has `status = MANUAL_REVIEW_REQUIRED` → DTA status is `MANUAL_REVIEW`

---

# Part 5: Versioning

## Overview

The Clinical Data Standards platform uses **SCD Type 2 (Slowly Changing Dimension)** versioning to track all changes to transfer variable definitions. This enables:

- **Full audit trail** of every change
- **Parallel DTA development** without collisions
- **Point-in-time queries** for any historical version
- **Approval workflows** with version promotion
- **Vendor+Stream scoped templates** for reusable standards

---

## Version Types

The system supports three distinct version types:

### 1. DTA Template (Canonical Standard per Vendor+Stream)
- **Format**: `1.0`, `2.0`, `3.0`, etc.
- **Purpose**: The canonical, production-ready standard **scoped by vendor and data stream**
- **Characteristics**:
  - `version_type = 'DTA_TEMPLATE'`
  - Each (vendor, data_stream) combination has its own version sequence
  - New DTAs can branch from any DTA Template version
- **Creation**: Requires **Librarian role** approval; merges multiple approved DTAs

### 2. DTA Draft Version (Work in Progress)
- **Format**: `{template}-{dta_number}-draft{n}`
- **Example**: `1.0-DTA001-draft1`, `1.0-DTA001-draft2`
- **Purpose**: Editable working copies for a specific DTA
- **Lifecycle**: Created → Edited → Superseded → Closed

### 3. DTA Approved Version (Approved DTA)
- **Format**: `{template}-{dta_number}-v{n}.0`
- **Example**: `1.0-DTA001-v1.0`, `1.0-DTA001-v2.0`
- **Purpose**: Approved, finalized version for a specific DTA
- **Lifecycle**: Approved draft becomes DTA Approved

---

## Version Manager Operations

The `job_cdm_version_manager` supports five mutually exclusive operations:

### 1. CREATE_BRANCH - Start New DTA

**Trigger**: UI initiates new DTA creation

**Source Options** (user chooses one):
- **DTA Template** (e.g., `1.0`, `2.0`) - Start from canonical standard
- **DTA Approved Version** (e.g., `1.0-DTA001-v1.0`) - Reuse another DTA's definitions

**What it does**:
1. User selects source version
2. Copies all records from selected source
3. Creates new draft version (e.g., `1.0-DTA002-draft1`)
4. Registers version with `parent_version` reference

### 2. SAVE_DRAFT - Save Changes

**Trigger**: User saves edits in the UI

**What it does**:
1. Closes current draft (set `is_current = FALSE`)
2. Creates new draft with changes (e.g., `1.0-DTA001-draft2`)
3. Updates registry: old draft → `SUPERSEDED`, new draft → `ACTIVE`

### 3. APPROVE_DTA - Promote Draft to DTA Approved

**Trigger**: Workflow approval completes

**What it does**:
1. Closes current draft
2. Creates DTA Approved version (e.g., `1.0-DTA001-v1.0`)
3. Sets `version_type = 'DTA_APPROVED'`

### 4. CREATE_DTA_APPROVED - Direct DTA Approved Creation

**Trigger**: Historical data import or API call

**What it does**:
1. Creates DTA Approved directly from silver data (skips draft phase)
2. Used for historical DTAs that are already approved

### 5. CREATE_DTA_TEMPLATE - Create Vendor+Stream Scoped Templates

**Trigger**: Librarian role initiates template creation

**What it does**:
1. Groups all approved DTAs by `(data_provider_name, data_stream_type)`
2. Merges new DTAs with existing template records
3. Creates a new DTA_TEMPLATE version
4. Updates DTA `status` to `PROMOTED`

---

## DTA Template Creation

### Template Scoping

**Key Concept**: Each `(data_provider_name, data_stream_type)` combination has its own independent template version sequence.

![Template Scoping](./diagrams/04_template_scoping.drawio.png)

**Benefits of Vendor+Stream Scoping**:
- Templates are tailored to specific vendor conventions
- Different data streams have independent standards
- No collision between vendors
- Incremental improvement per vendor+stream

### Merge Strategies

| Strategy | Description | Use Case |
|----------|-------------|----------|
| `UNION_DEDUP` | Combine all records, deduplicate by `definition_hash` | **Default** |
| `LATEST_WINS` | On duplicate, keep newest record | Prefer newer standards |
| `FIRST_WINS` | On duplicate, keep oldest record | Preserve original definitions |

---

## State Transitions

### Basic Flow (Branch from Template)

![Basic Flow](./diagrams/04_basic_flow_branch.drawio.png)

### Parallel DTA Development

![Parallel DTA Development](./diagrams/04_parallel_dta_development.drawio.png)

**Key Points**:
- Each DTA has isolated version tags
- Changes in one DTA don't affect others
- Multiple DTAs can be merged into template
- Templates are scoped by vendor+stream

---

## Version Tag Format

| Version Type | Format | Example |
|--------------|--------|---------|
| DTA Template | `{major}.0` | `1.0`, `2.0` (per vendor+stream) |
| DTA Draft | `{template}-{dta_number}-draft{n}` | `1.0-DTA001-draft1` |
| DTA Approved | `{template}-{dta_number}-v{n}.0` | `1.0-DTA001-v1.0` |

---

# Part 6: Hash Generation

## Overview

The hash generation system creates deterministic, content-based identifiers (`definition_hash`) that uniquely identify metadata definitions regardless of their source. This enables:

- **Cross-trial deduplication**: Same variable definition used in multiple trials = single library entry
- **Change detection**: Modified definitions get new hashes, preserving history
- **Versioning support**: Hash + version forms composite key in gold layer

---

## Transfer Variables

Transfer variables use a **vendor-scoped semantic hash** that captures the definition fields along with vendor and data stream context.

### Hash Fields

| Field | Description |
|-------|-------------|
| `data_provider_name` | Vendor name |
| `data_stream_type` | Data stream type (EDC, Lab, etc.) |
| `transfer_variable_name` | Variable name (e.g., SUBJECT_ID) |
| `transfer_variable_order` | Order/sequence in the transfer file |
| `format` | Data type (text, numeric, date, etc.) |
| `anticipated_max_length` | Maximum length for the field |
| `transfer_file_key` | Whether this is a key field |
| `populate_for_all_records` | Whether value is required for all records |
| `codelist_values_str` | Stringified codelist values |

### Result

- Same definition from same vendor+stream → **Same hash**
- Same definition from different vendors → **Different hash** (vendor-scoped)
- Any change to hash fields → **New hash**

---

## Test Concepts

Test concepts use a **vendor-scoped hash** that includes the complete transfer variable mapping for each row.

### Hash Fields

| Field | Description |
|-------|-------------|
| `data_provider_name` | Vendor name |
| `data_stream_type` | Data stream type |
| `transfer_tuple_map` | Complete JSON-serialized map of all transfer variable values |

---

## Hash Algorithm

### Transfer Variables

Uses `compute_definition_hash()` from `src/clinical_data_standards_framework/utils.py`:

**Steps:**
1. **Sort fields alphabetically** for deterministic ordering
2. **Normalize values**:
   - `None` → empty string `""`
   - `Boolean true` → `"1"`
   - `Boolean false` → `"0"`
   - `Numbers` → string representation
   - `Strings` → lowercase, trimmed whitespace
3. **Concatenate** with pipe `|` delimiter
4. **Compute SHA256** hash (64 hex characters)

### Test Concepts

**Steps:**
1. **Create dictionary** with keys: `data_provider`, `data_stream`, `tuple_map`
2. **Sort dictionary items** alphabetically
3. **JSON serialize** with `json.dumps(sorted_items, sort_keys=True)`
4. **Compute SHA256** hash (64 hex characters)

---

# Part 7: DTA Workflow

## Overview

The DTA approval flow manages the governance process from DTA creation through final approval. It supports:

- **Multi-party approval**: JNJ DAE, Vendor, Legal (future), Librarian
- **Ordered approval chain**: Approvers review in sequence based on `approval_order`
- **Rejection handling**: Any rejection returns DTA to editing state
- **Version creation**: Approval triggers DTA version creation
- **Multiple cycles**: Rejection increments `workflow_iteration` for resubmission

---

## Diagram

![DTA Workflow Flow](./diagrams/06_dta_workflow_flow.drawio.png)

---

## Approver Roles

| Role | Description | Mandatory |
|------|-------------|-----------|
| `JNJ_DAE` | JNJ Data Analytics Engineer | Yes |
| `VENDOR` | External Data Provider | Yes |
| `LEGAL` | Legal Review | Optional (Future) |
| `LIBRARIAN` | Template creation (separate flow) | Yes |

Approvers are processed sequentially based on `approval_order` (1 → 2 → 3...).

---

## DTA Lifecycle States

### DTA Status

| Status | Description | Editable? |
|--------|-------------|-----------|
| `DRAFT` | DTA is being created/edited | Yes |
| `PENDING_APPROVAL` | Submitted, awaiting approval chain | No |
| `APPROVED` | All approvers approved | No |
| `REJECTED` | At least one approver rejected | Yes |
| `MANUAL_REVIEW` | Contains records needing manual review | Yes |

### Workflow Status

| Status | Description |
|--------|-------------|
| `NOT_STARTED` | Workflow created but not submitted |
| `IN_REVIEW` | Submitted and awaiting approvals |
| `APPROVED` | All approvers approved |
| `REJECTED` | At least one approver rejected |

### Approval Task Status

| Status | Description |
|--------|-------------|
| `PENDING` | Awaiting this approver's decision |
| `APPROVED` | Approver approved |
| `REJECTED` | Approver rejected |
| `SKIPPED` | Non-mandatory task skipped |

---

## State Transitions

| From | Trigger | To | Result |
|------|---------|-----|--------|
| DRAFT | Save changes | DRAFT | Draft version updated |
| DRAFT | Submit for review | PENDING_APPROVAL | First approver notified |
| PENDING_APPROVAL | Approver approves | PENDING_APPROVAL | Next approver notified |
| PENDING_APPROVAL | All approve | APPROVED | DTA version created |
| PENDING_APPROVAL | Any rejects | REJECTED → DRAFT | Returns for editing |
| APPROVED | Continue work | DRAFT | New workflow iteration |

---

## Librarian Flow (Template Creation)

Template creation is a **separate process** managed by the Librarian role, occurring **after** DTA approval.

### Key Concepts

- Templates are **scoped by (vendor, data_stream)** combination
- Each vendor+stream pair has its own independent template version sequence
- Multiple approved DTAs from the same vendor+stream are merged into a single template
- DTAs included in a template are marked as `PROMOTED`

---

# Part 8: AI Processing

## Overview

The Clinical Data Standards platform leverages Databricks AI capabilities to process clinical documents containing unstructured or semi-structured data.

### Document Types

- **Operational Agreements** (PDF/Word) - Contract terms, vendor information, transfer requirements
- **Protocol Documents** (PDF/Word) - Study design, endpoints, Schedule of Activities tables

### AI Functions

| Function | Purpose |
|----------|---------|
| `ai_parse_document` | Parse unstructured documents into structured content using OCR, layout detection, and table extraction |
| `ai_query` | Extract specific entities from parsed documents using natural language queries |

### Model Serving

Databricks Model Serving provides flexible infrastructure for deploying LLM endpoints:

- **Model Flexibility**: Switch between OpenAI GPT-4, Llama 3, Claude, or custom models
- **Cost Optimization**: Route simpler tasks to cost-effective models
- **Custom Endpoints**: Deploy document-type specific endpoints with tailored prompts
- **Scalability**: Auto-scaling based on document processing volume

---

## Diagrams

### AI Processing Overview

![AI Processing Overview](./diagrams/07_ai_processing_overview.drawio.png)

### Model Selection Strategy

![Model Selection Strategy](./diagrams/07_model_selection_strategy.drawio.png)

---

## AI Capabilities

### ai_parse_document - Document Parsing

Parses unstructured documents into structured, queryable content:

- **OCR Processing**: Converts scanned images and PDF text layers
- **Layout Detection**: Identifies document structure
- **Table Detection**: Extracts tabular data preserving relationships
- **Text Extraction**: Cleans and normalizes text content

### ai_query - Entity Extraction

Extracts specific entities from parsed documents:

- **Named Entity Recognition**: Identifies people, organizations, dates
- **Key-Value Extraction**: Extracts specific fields based on query
- **Relationship Extraction**: Identifies connections between entities
- **Conditional Extraction**: Filters results based on criteria

---

## Model Selection

### Model Comparison

| Model | Best For | Context Length | Cost | Latency |
|-------|----------|----------------|------|---------|
| **OpenAI GPT-4** | Complex reasoning, accuracy-critical | 128K | $$$ | Medium |
| **OpenAI GPT-4o** | Balanced performance, general extraction | 128K | $$ | Fast |
| **Llama 3 70B** | Cost-effective, privacy-sensitive | 8K | $ | Fast |
| **Claude 3 Opus** | Very long documents (>100K tokens) | 200K | $$$ | Medium |
| **Custom Fine-tuned** | Domain-specific tasks (forms, checkboxes) | Varies | $ | Fast |

### Selection Criteria

| Criterion | Routing Decision |
|-----------|------------------|
| **Document Length** | Documents >100K tokens → Claude 3 (200K context) |
| **Accuracy Requirements** | Operational agreements → GPT-4 (highest accuracy) |
| **Cost Constraints** | Protocol summaries → Llama 3 (cost-effective) |
| **Form Extraction** | Checkbox forms → Custom fine-tuned model |
| **Privacy Requirements** | Sensitive data → Self-hosted Llama models |

---

## Patterns

### Checkbox Extraction

Detects checked and unchecked boxes in scanned forms. Returns structured JSON with label, checked state, and confidence score.

### Entity Extraction with Schema

Extracts entities matching a predefined schema. The prompt specifies exact fields required with confidence scores for each extracted field.

### Protocol Document Parsing

Processes clinical protocol documents to extract study design information including objectives, endpoints, and inclusion/exclusion criteria.

### Schedule of Activities Table Extraction

Extracts Time and Visit data from Schedule of Activities (SoA) tables:

- **Visits**: Study visit identifiers (Screening, Day 1, Week 4, etc.)
- **Timepoints**: Timing relative to study milestones
- **Procedures**: Activities performed at each visit

---

# Part 9: Permissions

## Overview

This section describes the permissions and access control architecture including Unity Catalog access, Databricks Apps authentication, and role-based access control.

---

## Authentication Modes

### 1. Service Principal Authentication (Current)

The Databricks App runs with its own **Service Principal** identity.

```
User → App → App Service Principal → Unity Catalog
```

**Pros:**
- Simple setup
- Works for background/batch operations
- Consistent permissions regardless of user

**Cons:**
- Requires explicit GRANT statements
- No per-user row-level security

### 2. On-Behalf-Of (OBO) Authentication (Recommended for Production)

The app uses the **logged-in user's token** to execute operations.

```
User → App → User's Token → Unity Catalog
```

**Pros:**
- Uses existing user permissions
- Row-level security enforced
- Audit logs show actual user

---

## Unity Catalog Permissions

### Required Grants for Service Principal

```sql
-- 1. Grant USE CATALOG
GRANT USE CATALOG ON CATALOG aira_test TO `App - clnl-data-std-mgmt-app`;

-- 2. Grant USE SCHEMA for all required schemas
GRANT USE SCHEMA ON SCHEMA aira_test.bronze_md TO `App - clnl-data-std-mgmt-app`;
GRANT USE SCHEMA ON SCHEMA aira_test.silver_md TO `App - clnl-data-std-mgmt-app`;
GRANT USE SCHEMA ON SCHEMA aira_test.gold_md TO `App - clnl-data-std-mgmt-app`;

-- 3. Grant SELECT on schemas (for reading data)
GRANT SELECT ON SCHEMA aira_test.bronze_md TO `App - clnl-data-std-mgmt-app`;
GRANT SELECT ON SCHEMA aira_test.silver_md TO `App - clnl-data-std-mgmt-app`;
GRANT SELECT ON SCHEMA aira_test.gold_md TO `App - clnl-data-std-mgmt-app`;
```

---

## Role-Based Access Control

### Application Roles

| Role | Description | Permissions |
|------|-------------|-------------|
| **JNJ_DATA_ENGINEER** | Creates and manages DTAs | Create DTA, Edit Draft, Submit |
| **JNJ_APPROVER** | Approves/rejects DTAs | View DTA, Approve, Reject |
| **VENDOR** | External vendor users | View assigned DTAs, Edit sections |
| **LIBRARIAN** | Manages library versions | Promote to Template, Merge DTAs |
| **ADMIN** | Full system access | All operations, User management |

### Permission Matrix

| Action | DATA_ENGINEER | APPROVER | VENDOR | LIBRARIAN | ADMIN |
|--------|---------------|----------|--------|-----------|-------|
| View Dashboard | Yes | Yes | Yes | Yes | Yes |
| Create DTA | Yes | No | No | Yes | Yes |
| Edit Draft | Yes | No | Yes* | Yes | Yes |
| Submit for Approval | Yes | No | Yes | Yes | Yes |
| Approve DTA | No | Yes | No | Yes | Yes |
| Reject DTA | No | Yes | No | Yes | Yes |
| Promote to Library | No | No | No | Yes | Yes |
| Merge DTAs | No | No | No | Yes | Yes |
| Manage Users | No | No | No | No | Yes |

*Vendor can only edit DTAs assigned to them

---

## Security Best Practices

1. **Principle of Least Privilege**: Grant only necessary permissions
2. **Use OBO for Production**: Enables per-user audit trails
3. **Regular Permission Audits**: Review grants periodically
4. **Separate Environments**: Use different catalogs for dev/test/prod
5. **Rotate Credentials**: Regularly rotate service principal secrets
6. **Enable Audit Logging**: Track all data access operations

---

# Part 10: Genie Integration

## Overview

### What is Databricks AI/BI Genie?

Databricks AI/BI Genie is a natural language interface that allows users to query data using conversational questions instead of writing SQL.

| Capability | Description |
|------------|-------------|
| **Natural Language Queries** | Users ask questions in plain English; Genie translates to SQL |
| **Unity Catalog Integration** | Queries tables directly with permission enforcement |
| **Conversation Context** | Supports follow-up questions within a conversation |
| **SQL Generation** | Generates and displays the SQL query for transparency |

### Purpose in DTA Builder

- **DTA Discovery**: Search for existing DTAs using natural language
- **Version Lookup**: Query version history and approval status
- **Template Search**: Find approved DTAs to use as templates
- **Activity Tracking**: Query recent changes and user activity

---

## Asset Generation Job

The `job_cdm_export_genie_assets` job dynamically generates all assets needed to configure a Genie space.

### Job Workflow

| Task | Notebook | Purpose |
|------|----------|---------|
| `export_genie_assets` | `nb_export_genie_assets.ipynb` | Discover tables, generate component files |
| `generate_serialized_space` | `nb_generate_serialized_space.ipynb` | Assemble final `serialized_space.json` |

### Output Files

```
/Volumes/{catalog}/bronze_md/{volume}/{source_root}/exports/genie/
├── sql/
│   ├── add_table_comments.sql       # Table and column descriptions
│   └── example_queries.sql          # 15 parameterized training queries
├── components/
│   ├── sample_questions.json        # Quick-start questions for users
│   ├── data_sources.json            # Tables with column configurations
│   ├── text_instructions.json       # Space instructions
│   └── example_queries.json         # SQL examples with questions
├── genie_instructions.txt           # Human-readable instructions
├── serialized_space.json            # Complete space configuration for API
└── export_manifest.json             # Export metadata and timestamps
```

---

## UI Design

### Search Mode Toggle

The DTA Builder UI provides two search modes:

| Mode | Description |
|------|-------------|
| **Standard Search** | Traditional SQL-based search with field filters |
| **AI Search with Genie** | Natural language queries powered by Genie |

### Genie Response Panel

| Component | Description |
|-----------|-------------|
| **Text Response** | Genie's explanation of the results |
| **Generated SQL** | The SQL query generated (expandable) |
| **Results** | DTA cards rendered from query results |

### User Experience Flow

1. User selects **AI Search with Genie** toggle
2. User types natural language question
3. User clicks **Ask Genie**
4. UI sends request to Flask backend
5. Backend calls Genie API and polls for response
6. Response displayed with DTA cards rendered from results

---

## Best Practices for Designing Genie Spaces

### Table Selection

- **Focus on Gold layer**: Include core business tables (`dta`, `dta_workflow`, `md_dta_transfer_variables`)
- **Include Bronze for context**: Add `md_file_history` for document lineage
- **Limit scope**: Too many tables can confuse Genie
- **Add related tables**: Include lookup tables needed for JOINs

### Table and Column Comments

Rich descriptions help Genie understand data semantics:

- **Table comments**: Explain the purpose and business context
- **Column comments**: Describe what each column contains, valid values
- **Use `add_table_comments.sql`**: Generated automatically by the export job
- **Include examples**: "data_stream_type contains values like Labs, ECG, Biomarkers"

### Instructions

Write focused, domain-specific instructions:

- **Define terminology**: Explain what DTA, vendor, data stream mean
- **Specify required filters**: "Always ask for vendor and data stream or trial"
- **Clarify relationships**: Explain how tables relate
- **Set expectations**: Define what questions the space can and cannot answer

### Sample Questions

Provide representative questions users might ask:

- Start with common use cases
- Include variations (by vendor, by trial, by status)
- Cover different query types (search, count, latest, history)
- Keep questions natural and conversational

### SQL Examples

Train Genie with parameterized queries:

- **Cover key patterns**: Filtering, joining, aggregating
- **Use consistent style**: Same column selection, JOIN patterns
- **Include comments**: Explain what each query does
- **Match to sample questions**: Each example should answer a sample question

### Column Configurations

| Setting | Purpose |
|---------|---------|
| `get_example_values: true` | Genie fetches sample values to understand column content |
| `build_value_dictionary: true` | Creates lookup for categorical columns (STRING types) |

**Note**: Sort columns alphabetically (Genie API requirement).

### Iterative Refinement

1. **Start simple**: Begin with core tables and basic instructions
2. **Monitor usage**: Review questions in Genie's Monitoring tab
3. **Identify gaps**: Note queries that fail or return wrong results
4. **Refine instructions**: Add clarifications for misunderstood queries
5. **Add examples**: Create SQL examples for problematic patterns
6. **Test variations**: Try different phrasings of the same question
7. **Collect feedback**: Use upvote/downvote to identify improvements

### Required Search Criteria

Configure Genie to ask clarifying questions when context is missing:

| Required Combination | Example |
|---------------------|---------|
| Vendor + Data Stream | "Show me Labs DTAs from LabCorp" |
| Vendor + Trial | "Find DTAs for Covance in trial VAC18193" |

---

*Document Version: 1.0 | Last Updated: January 2026*


# AI Processing Design

> **Status**: Implemented  
> **Last Updated**: January 2026

---

## Overview

The Clinical Data Standards platform leverages Databricks AI capabilities to process clinical documents containing unstructured or semi-structured data. This architecture enables intelligent extraction of data from:

- **Operational Agreements** (PDF/Word) - Contract terms, vendor information, transfer requirements
- **Protocol Documents** (PDF/Word) - Study design, endpoints, Schedule of Activities tables

### AI Functions

The platform uses two primary AI functions provided by Databricks:

| Function | Purpose |
|----------|---------|
| `ai_parse_document` | Parse unstructured documents (PDF, Word, scanned images) into structured, queryable content using OCR, layout detection, and table extraction |
| `ai_query` | Extract specific entities, relationships, and structured data from parsed documents using natural language queries |

### Model Serving

Databricks Model Serving provides a flexible infrastructure for deploying and managing LLM endpoints. Key capabilities include:

- **Model Flexibility**: Switch between OpenAI GPT-4, Llama 3, Claude, or custom models without code changes
- **Cost Optimization**: Route simpler tasks to cost-effective models, reserve premium models for complex extraction
- **Custom Endpoints**: Deploy document-type specific endpoints with tailored prompts
- **Scalability**: Auto-scaling based on document processing volume
- **Version Control**: Deploy new model versions with rollback capability

### Prompt Engineering

Effective extraction relies on well-designed prompts that:

- Specify the exact output schema expected (JSON structure, field names, data types)
- Include confidence scoring requirements for extracted values
- Handle missing or ambiguous data gracefully (null values, low confidence flags)
- Provide context about document type and domain terminology
- Use few-shot examples when appropriate for complex extraction patterns

---

## Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| AI Processing Overview | End-to-end architecture showing input, processing, models, and output | [PNG](./diagrams/07_ai_processing_overview.drawio.png) | [Draw.io](./diagrams/07_ai_processing_overview.drawio) |
| Model Selection Strategy | Decision tree for routing documents to appropriate models | [PNG](./diagrams/07_model_selection_strategy.drawio.png) | [Draw.io](./diagrams/07_model_selection_strategy.drawio) |

### AI Processing Overview

![AI Processing Overview](./diagrams/07_ai_processing_overview.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/07_ai_processing_overview.drawio)

### Model Selection Strategy

![Model Selection Strategy](./diagrams/07_model_selection_strategy.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/07_model_selection_strategy.drawio)

---

## AI Capabilities

### `ai_parse_document` - Document Parsing

Parses unstructured documents into structured, queryable content. This function handles:

- **OCR Processing**: Converts scanned images and PDF text layers into machine-readable text
- **Layout Detection**: Identifies document structure including headers, paragraphs, lists, and sections
- **Table Detection**: Extracts tabular data preserving row/column relationships
- **Text Extraction**: Cleans and normalizes text content for downstream processing

### `ai_query` - Entity Extraction

Extracts specific entities and relationships from parsed documents using natural language queries. Supports:

- **Named Entity Recognition**: Identifies people, organizations, dates, locations
- **Key-Value Extraction**: Extracts specific fields based on query context
- **Relationship Extraction**: Identifies connections between entities (e.g., vendor-contact relationships)
- **Conditional Extraction**: Filters results based on specified criteria

### Model Serving - Custom Extraction

For complex extraction patterns, the platform uses Databricks Model Serving endpoints with custom prompts. This enables:

- **Schema-Guided Extraction**: Prompts that specify exact output structure
- **Multi-Model Routing**: Different models for different document types
- **Confidence Scoring**: Each extracted value includes a confidence score
- **Fallback Handling**: Automatic fallback to alternative models on failure

---

## Model Selection

### Model Comparison

| Model | Best For | Context Length | Cost | Latency |
|-------|----------|----------------|------|---------|
| **OpenAI GPT-4** | Complex reasoning, accuracy-critical extraction | 128K | $$$ | Medium |
| **OpenAI GPT-4o** | Balanced performance, general extraction | 128K | $$ | Fast |
| **Llama 3 70B** | Cost-effective processing, privacy-sensitive | 8K | $ | Fast |
| **Llama 3.1 405B** | Open-source, high capability | 128K | $$ | Medium |
| **Claude 3 Opus** | Very long documents (>100K tokens) | 200K | $$$ | Medium |
| **Claude 3 Sonnet** | Balanced, long context needs | 200K | $$ | Fast |
| **Custom Fine-tuned** | Domain-specific tasks (forms, checkboxes) | Varies | $ | Fast |

### Selection Criteria

| Criterion | Routing Decision |
|-----------|------------------|
| **Document Length** | Documents >100K tokens → Claude 3 (200K context) |
| **Accuracy Requirements** | Operational agreements → GPT-4 (highest accuracy) |
| **Cost Constraints** | Protocol summaries → Llama 3 (cost-effective) |
| **Form Extraction** | Checkbox forms → Custom fine-tuned model |
| **Privacy Requirements** | Sensitive data → Self-hosted Llama models |

---

## Patterns

### Checkbox Extraction

Detects checked and unchecked boxes in scanned forms or PDFs. The model identifies checkbox symbols (☑, ☐, ✓, X) and their associated labels, returning structured JSON with:

- Label/description of each checkbox
- Checked state (true/false)
- Confidence score (0.0-1.0)

Used for processing clinical forms where requirements or options are indicated via checkboxes.

### Entity Extraction with Schema

Extracts entities matching a predefined schema from unstructured text. The prompt specifies the exact fields required (vendor name, contract dates, transfer frequency, data formats) and their expected data types. The model returns:

- Field values matching the schema
- Null values for fields not found in the document
- Confidence scores for each extracted field

Enables consistent, structured output regardless of how information is presented in source documents.

### Protocol Document Parsing

Processes clinical protocol documents to extract study design information. The model identifies section headers (Objectives, Endpoints, Inclusion/Exclusion Criteria) and extracts:

- Study title and identifiers
- Primary and secondary objectives
- Primary, secondary, and exploratory endpoints
- Inclusion and exclusion criteria as structured lists

### Schedule of Activities Table Extraction

Extracts Time and Visit data from Schedule of Activities (SoA) tables found in Protocol documents. These tables define:

- **Visits**: Study visit identifiers (Screening, Day 1, Week 4, etc.)
- **Timepoints**: Timing relative to study milestones
- **Procedures**: Activities performed at each visit (marked with X or specific codes)

The model preserves the tabular structure while extracting:

- Visit names and timing windows
- Procedure-to-visit mappings
- Visit sequence and dependencies

This extraction is critical for generating study calendars and procedure schedules from protocol documents.

---

## Related Documentation

- [01_job_architecture_design.readme.md](./01_job_architecture_design.readme.md) - Overall pipeline architecture
- [02_schema_design.readme.md](./02_schema_design.readme.md) - Schema for extracted data
- [03_status_lifecycle_design.readme.md](./03_status_lifecycle_design.readme.md) - Document processing statuses

---

*Last Updated: January 2026*

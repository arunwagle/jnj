
-- ============================================================================
-- Catalog and Schema Setup SQL
-- ============================================================================
-- Purpose: Create catalog, schemas, and volumes if they don't exist
-- Use Case: clinical_data_standards
--
-- Parameters (passed from job):
--   :catalog_name - The catalog to create/use
--
-- NOTE: Entity tables (dta, dta_workflow, md_file_history, etc.) are created
-- dynamically by notebooks on first write. This ensures schema consistency
-- between Python code and Delta tables.
-- ============================================================================

-- Create catalog if it doesn't exist
CREATE CATALOG IF NOT EXISTS IDENTIFIER(:catalog_name)
COMMENT 'Catalog for clinical_data_standards use case';

-- Set current catalog
USE CATALOG IDENTIFIER(:catalog_name);

-- Create Bronze schema (raw/landing zone)
CREATE SCHEMA IF NOT EXISTS bronze_md
COMMENT 'Bronze layer - raw ingestion of Trial-Specific Data Transfer Agreement (tsDTA) files including ZIP archives, Excel documents, Operational Agreements (Word), and Protocol documents. Contains document manifest, extraction status, and Excel sheet metadata.';

-- Create Silver schema (cleaned/processed)
CREATE SCHEMA IF NOT EXISTS silver_md
COMMENT 'Silver layer - normalized draft data extracted from tsDTA files. Contains work-in-progress transfer variable definitions, codelists, test concepts, and visits/timepoints that are being reviewed by J&J Data Acquisition Experts (DAEs) and vendors before approval.';

-- Create Gold schema (curated metadata library)
CREATE SCHEMA IF NOT EXISTS gold_md
COMMENT 'Gold layer - approved Data Transfer Agreement (DTA) entities and versioned metadata library. Contains the DTA master table, workflow tracking, version registry, and approved transfer variable definitions. This is the source of truth for production data transfer specifications.';

-- ============================================================================
-- Create Volumes for file storage
-- ============================================================================
-- Volume for clinical data standards files (ZIP archives, Excel files, etc.)
-- Path: /Volumes/<catalog>/bronze_md/clinical_data_standards/
CREATE VOLUME IF NOT EXISTS bronze_md.clinical_data_standards
COMMENT 'Volume for clinical data standards files - ZIP archives, Excel files, documents';

-- Display setup summary
SELECT 
  '✅ Setup Complete' as status,
  :catalog_name as catalog,
  'bronze_md, silver_md, gold_md' as schemas_created,
  'bronze_md.clinical_data_standards' as volume_created;

-- ============================================================================
-- ENTITY TABLES
-- ============================================================================
-- Entity tables are created dynamically by notebooks on first write:
--   - gold_md.dta (created by nb_create_dta_instance.ipynb)
--   - gold_md.dta_workflow (created by nb_create_dta_instance.ipynb)
--   - gold_md.dta_approval_task (created by nb_create_dta_instance.ipynb)
--   - gold_md.dta_activity_log (created by activity logging functions)
--   - gold_md.md_version_registry (created by versioning notebooks)
--   - gold_md.md_dta_transfer_variables (created by nb_version_approve_dta.ipynb)
--   - silver_md.md_dta_transfer_variables_draft (created by nb_tsdta_transfer_variables_processor.ipynb)
--   - bronze_md.md_file_history (created by nb_file_processor.ipynb)
--
-- This approach ensures:
--   1. Single source of truth for schema (Python code)
--   2. No sync issues between SQL and Python
--   3. Correct nullability and data types
--
-- After tables are created, run job_cdm_export_genie_assets to dynamically
-- generate table comments and Genie training assets. The generated files are
-- exported to: /Volumes/{catalog}/bronze_md/{source_root}/export/genie/
-- ============================================================================

-- ============================================================================
-- COMMENTS TABLE - Threaded discussions on DTA library items
-- ============================================================================
-- Supports two-way JNJ/Vendor communication with thread resolution.
-- Created explicitly via SQL (not dynamically by notebooks).
-- ============================================================================

-- Silver table: Draft comments (created during DTA editing)
CREATE TABLE IF NOT EXISTS silver_md.md_comments_draft (
    comment_id STRING NOT NULL COMMENT 'UUID primary key for the comment',
    thread_id STRING NOT NULL COMMENT 'Groups related comments into a thread',
    parent_comment_id STRING COMMENT 'NULL for thread starters, links to parent for replies',
    dta_id STRING NOT NULL COMMENT 'FK to DTA being commented on',
    library_type STRING NOT NULL COMMENT 'Library type: transfer_variables, test_concepts, codelists, etc.',
    item_id STRING NOT NULL COMMENT 'Row identifier in the library (e.g., transfer_variable_id)',
    item_name STRING COMMENT 'Human-readable name for context',
    comment_text STRING NOT NULL COMMENT 'The comment content',
    commenter_role STRING NOT NULL COMMENT 'JNJ_DAE or VENDOR',
    commenter_principal STRING NOT NULL COMMENT 'Email of commenter',
    commenter_name STRING COMMENT 'Display name of commenter',
    thread_status STRING COMMENT 'OPEN or RESOLVED (only on thread root comment)',
    resolved_by_principal STRING COMMENT 'Who resolved the thread',
    resolved_ts TIMESTAMP COMMENT 'When the thread was resolved',
    version_tag STRING COMMENT 'DTA version when comment was made',
    -- Audit columns
    created_ts TIMESTAMP NOT NULL COMMENT 'When comment was created',
    created_by_principal STRING NOT NULL COMMENT 'Who created the comment',
    last_updated_ts TIMESTAMP COMMENT 'Last update timestamp',
    last_updated_by_principal STRING COMMENT 'Who last updated'
)
USING DELTA
COMMENT 'Draft comments for DTA library items - two-way JNJ/Vendor threaded discussions'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true'
);

-- Gold table: Approved comments (copied from silver on DTA approval)
CREATE TABLE IF NOT EXISTS gold_md.md_comments (
    comment_id STRING NOT NULL COMMENT 'UUID primary key for the comment',
    thread_id STRING NOT NULL COMMENT 'Groups related comments into a thread',
    parent_comment_id STRING COMMENT 'NULL for thread starters, links to parent for replies',
    dta_id STRING NOT NULL COMMENT 'FK to DTA being commented on',
    library_type STRING NOT NULL COMMENT 'Library type: transfer_variables, test_concepts, codelists, etc.',
    item_id STRING NOT NULL COMMENT 'Row identifier in the library (e.g., transfer_variable_id)',
    item_name STRING COMMENT 'Human-readable name for context',
    comment_text STRING NOT NULL COMMENT 'The comment content',
    commenter_role STRING NOT NULL COMMENT 'JNJ_DAE or VENDOR',
    commenter_principal STRING NOT NULL COMMENT 'Email of commenter',
    commenter_name STRING COMMENT 'Display name of commenter',
    thread_status STRING COMMENT 'OPEN or RESOLVED (only on thread root comment)',
    resolved_by_principal STRING COMMENT 'Who resolved the thread',
    resolved_ts TIMESTAMP COMMENT 'When the thread was resolved',
    version_tag STRING COMMENT 'DTA version when comment was approved',
    -- Audit columns
    created_ts TIMESTAMP NOT NULL COMMENT 'When comment was created',
    created_by_principal STRING NOT NULL COMMENT 'Who created the comment',
    last_updated_ts TIMESTAMP COMMENT 'Last update timestamp',
    last_updated_by_principal STRING COMMENT 'Who last updated'
)
USING DELTA
COMMENT 'Approved comments for DTA library items - two-way JNJ/Vendor threaded discussions'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true'
);

SELECT '✅ Comments tables created' as status;


from flask import Flask, render_template, request, redirect, url_for, jsonify, flash, session
from datetime import datetime
import json
import random
import re
import os

# Import API layer and data storage
from api import api
from api.data import WORKSPACES, MOCK_RUNS, MOCK_RESULTS, _ensure_tv_init, group_codelists_by_ref, get_or_create_workspace
from api.versioning_api import versioning_bp
from api.dashboard_api import dashboard_bp, get_dashboard_data
from api.dta_api import dta_bp, get_dta_create_context
from api.genie_api import genie_bp
from api.upload_api import upload_bp
from api.study_api import (
    study_bp, get_studies, get_study_details, get_vendors, get_data_streams,
    get_study_activities, create_study, update_study_status, 
    assign_activity_vendor_stream, _get_db_config as study_get_db_config,
    _get_sql_client as study_get_sql_client
)
from api.user_management_api import UserManagementService

app = Flask(__name__)
app.secret_key = "dev-secret"  # for flashes (demo only)
app.config['SESSION_TYPE'] = 'filesystem'

# Custom Jinja2 filter to ensure arrays are always iterable
@app.template_filter('ensure_list')
def ensure_list_filter(value):
    """
    Ensure value is a list. Handles:
    - Already a list: return as-is
    - String representation of list: parse and return
    - Comma-separated string: split and return
    - None/empty: return empty list
    
    Common problematic formats:
    - "['item1', 'item2']" - Python repr
    - '["item1", "item2"]' - JSON
    - "[item1, item2]" - Malformed
    - "item1,item2" - Comma-separated
    """
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return []
        
        # Handle string representation of list with brackets
        if value.startswith('[') and value.endswith(']'):
            import json
            import re
            
            # Try JSON parsing first
            try:
                parsed = json.loads(value)
                if isinstance(parsed, list):
                    return [str(item).strip() for item in parsed if item]
            except (json.JSONDecodeError, ValueError):
                pass
            
            # Try JSON with single quotes converted to double quotes
            try:
                parsed = json.loads(value.replace("'", '"'))
                if isinstance(parsed, list):
                    return [str(item).strip() for item in parsed if item]
            except (json.JSONDecodeError, ValueError):
                pass
            
            # Remove brackets and parse as comma-separated
            value = value[1:-1]  # Remove [ and ]
            # Handle quoted items: split by comma, then strip quotes
            items = []
            for item in value.split(','):
                item = item.strip()
                # Remove surrounding quotes if present
                if (item.startswith('"') and item.endswith('"')) or (item.startswith("'") and item.endswith("'")):
                    item = item[1:-1]
                if item:
                    items.append(item)
            return items
        
        # Fall back to comma-separated
        return [v.strip() for v in value.split(',') if v.strip()]
    return []

# Register API blueprints
app.register_blueprint(versioning_bp)
app.register_blueprint(dashboard_bp)
app.register_blueprint(dta_bp)
app.register_blueprint(genie_bp)
app.register_blueprint(upload_bp)
app.register_blueprint(study_bp)

# -------- User Management & Permissions --------

# Initialize user management service (lazily)
user_service = None

def get_user_service():
    """Get or initialize user management service"""
    global user_service
    if user_service is None:
        try:
            client = study_get_sql_client()
            config = study_get_db_config()
            catalog = config.get('catalog', 'dta_poc_test')
            user_service = UserManagementService(client, catalog, 'gold_md')
        except Exception as e:
            print(f"Warning: Could not initialize user service: {e}")
            user_service = None
    return user_service

def get_current_user_email():
    """Get current user email (simulated or from session)"""
    # For Phase 1: Use session-based simulation
    # Default to DAE user for development
    return session.get('simulated_user', 'VKapoor9@its.jnj.com')

def get_current_user():
    """Get current user details with permissions"""
    email = get_current_user_email()
    service = get_user_service()
    
    print(f"\n{'='*80}")
    print(f"GET_CURRENT_USER DEBUG:")
    print(f"  Email: {email}")
    print(f"  Service initialized: {service is not None}")
    
    if not service:
        # Fallback if user service is not available
        print(f"  WARNING: User service not available, using fallback with full permissions")
        print(f"{'='*80}\n")
        return {
            'email': email,
            'display_name': email.split('@')[0],
            'permissions': {'PAGE_ACCESS': ['page_all'], 'PANEL_VIEW': [], 'ACTION_EXECUTE': ['action_edit_dta', 'action_add_comment']},
            'groups': [{'group_name': 'JNJ_DAE'}],
            'vendor_id': None,
            'vendor_name': None
        }
    
    user = service.get_user_by_email(email)
    print(f"  User found in DB: {user is not None}")
    if not user:
        # User not found in database, return default permissions
        print(f"  WARNING: User not found in DB, using fallback with full permissions")
        print(f"{'='*80}\n")
        return {
            'email': email,
            'display_name': email.split('@')[0],
            'permissions': {'PAGE_ACCESS': ['page_all'], 'PANEL_VIEW': [], 'ACTION_EXECUTE': ['action_edit_dta', 'action_add_comment']},
            'groups': [{'group_name': 'JNJ_DAE'}],
            'vendor_id': None,
            'vendor_name': None
        }
    
    user['permissions'] = service.get_user_permissions(email)
    user['groups'] = service.get_user_groups(email)
    
    print(f"  User details fetched successfully:")
    print(f"    Display name: {user.get('display_name')}")
    print(f"    Groups: {[g.get('group_name') for g in user.get('groups', [])]}")
    print(f"    Permissions ACTION_EXECUTE: {user.get('permissions', {}).get('ACTION_EXECUTE', [])}")
    print(f"    Permissions PAGE_ACCESS: {user.get('permissions', {}).get('PAGE_ACCESS', [])}")
    print(f"  can('action_edit_dta'): {'action_edit_dta' in user.get('permissions', {}).get('ACTION_EXECUTE', [])}")
    print(f"  can('action_add_comment'): {'action_add_comment' in user.get('permissions', {}).get('ACTION_EXECUTE', [])}")
    print(f"{'='*80}\n")
    
    return user

@app.context_processor
def inject_user():
    """Make user context available to all templates"""
    current_user = get_current_user()
    
    def can(permission_key):
        """
        Template helper to check permissions (for HIDE mode).
        Returns True if user has permission.
        """
        perms = current_user.get('permissions', {})
        
        # Check if permission exists in ACTION_EXECUTE
        if permission_key in perms.get('ACTION_EXECUTE', []):
            return True
        
        # Check if permission exists in PANEL_VIEW
        if permission_key in perms.get('PANEL_VIEW', []):
            return True
        
        # Check for wildcard page_all permission (ONLY for page_* permissions)
        if permission_key.startswith('page_') and 'page_all' in perms.get('PAGE_ACCESS', []):
            return True
        
        # Check if permission exists in PAGE_ACCESS
        if permission_key in perms.get('PAGE_ACCESS', []):
            return True
        
        return False
    
    def is_disabled(permission_key):
        """
        Template helper to check if action should be shown but disabled.
        Returns True if user lacks permission AND enforcement mode is DISABLE.
        """
        # If user has permission, it's not disabled
        if can(permission_key):
            return False
        
        # User doesn't have permission - check enforcement mode
        try:
            perm_mode = user_service.get_permission_mode(current_user['email'], permission_key)
            return perm_mode.get('mode') == 'DISABLE'
        except Exception as e:
            print(f"Error checking disabled state for {permission_key}: {e}")
            return False
    
    def disabled_reason(permission_key):
        """
        Template helper to get the disabled message for tooltips.
        Returns the message string or empty string if none.
        """
        try:
            perm_mode = user_service.get_permission_mode(current_user['email'], permission_key)
            return perm_mode.get('message', '') or ''
        except Exception as e:
            print(f"Error getting disabled reason for {permission_key}: {e}")
            return ''
    
    return dict(
        current_user=current_user,
        can=can,
        is_disabled=is_disabled,
        disabled_reason=disabled_reason
    )

# -------- Helper Functions --------

def log_activity_for_save(client, dta_id, library_type, records_updated, field_changes, domain_info=None):
    """
    Common function to log activity for save operations.
    Handles user resolution and error handling internally.
    
    Args:
        client: SQL client instance
        dta_id: DTA identifier
        library_type: 'transfer_variables', 'test_concepts', 'operational_agreements', 'codelists'
        records_updated: Count of records updated
        field_changes: List of field change dicts
        domain_info: Optional domain filter
    
    Returns:
        bool: True if logged successfully, False otherwise
    """
    from api.activity_log_api import log_batch_update
    
    if not field_changes:
        return False
    
    # Get current user
    current_user = "app_user"
    try:
        user_result = client.execute_query("SELECT current_user() as user")
        if user_result:
            current_user = user_result[0].get('user', 'app_user')
    except:
        pass
    
    try:
        log_batch_update(
            dta_id=dta_id,
            library_type=library_type,
            records_updated=records_updated,
            field_changes=field_changes,
            performed_by=current_user,
            domain_info=domain_info
        )
        print(f"SAVE: {library_type} activity log updated ({len(field_changes)} changes)")
        return True
    except Exception as log_err:
        print(f"SAVE: Warning - Failed to log {library_type} changes: {log_err}")
        return False

# -------- Routes --------
@app.route("/")
def home():
    return redirect(url_for("dashboard"))

@app.route("/dashboard")
def dashboard():
    """Dashboard - main view with action cards, DTA overview, library status, and activity"""
    import os
    import traceback
    
    # Debug: Log environment variables
    print("=" * 60)
    print("DASHBOARD: Loading dashboard data...")
    print(f"DASHBOARD: CATALOG_NAME = {os.environ.get('CATALOG_NAME', 'NOT SET')}")
    print(f"DASHBOARD: GOLD_SCHEMA = {os.environ.get('GOLD_SCHEMA', 'NOT SET')}")
    print(f"DASHBOARD: DATABRICKS_WAREHOUSE_ID = {os.environ.get('DATABRICKS_WAREHOUSE_ID', 'NOT SET')}")
    print("=" * 60)
    
    try:
        # Get all dashboard data from the new dashboard API
        dashboard_data = get_dashboard_data()
        print("DASHBOARD: Successfully loaded dashboard data")
        return render_template("dashboard.html", dashboard=dashboard_data)
    except Exception as e:
        # Log the full error with traceback
        print("=" * 60)
        print(f"DASHBOARD ERROR: {str(e)}")
        print("DASHBOARD TRACEBACK:")
        traceback.print_exc()
        print("=" * 60)
        
        flash(f"Error loading dashboard: {str(e)}", "error")
        # Return empty dashboard data with error message
    return render_template("dashboard.html", 
            dashboard={
                "action_required": {"pending_approvals": 0, "my_drafts": 0, "processing_documents": 0, "ready_for_promotion": 0},
                "dta_overview": {"total": 0, "by_status": {"approved": 0, "in_review": 0, "draft": 0, "rejected": 0}},
                "library_entities": [],
                "recent_dtas": [],
                "recent_activity": [],
                "processing_stats": {"this_month": {"dtas_created": 0, "files_processed": 0}, "success_rate": 0}
            },
            error_message=str(e)
        )

@app.route("/upload")
def upload():
    """Upload Documents page"""
    return render_template("upload.html")

@app.route("/create-dta")
def create_dta():
    """Create DTA page - two-panel wizard for creating new DTAs"""
    import traceback
    
    try:
        # Get pre-selected library versions from URL params (from dashboard)
        selected_libraries = {}
        code_mapping = {
            'lib_tv': 'TV',
            'lib_cl': 'CL',
            'lib_tc': 'TC',
            'lib_oa': 'OA',
            'lib_vt': 'VT',
            'lib_dip': 'DIP'
        }
        
        for param, code in code_mapping.items():
            value = request.args.get(param)
            if value and value.lower() != 'none':
                selected_libraries[code] = value
        
        print(f"CREATE-DTA: Pre-selected libraries from URL: {selected_libraries}")
        
        # Get full context for the page
        context = get_dta_create_context(selected_libraries)
        
        return render_template("create_dta.html", context=context)
        
    except Exception as e:
        print("=" * 60)
        print(f"CREATE-DTA ERROR: {str(e)}")
        traceback.print_exc()
        print("=" * 60)
        
        flash(f"Error loading DTA creation page: {str(e)}", "error")
        return redirect(url_for("dashboard"))

@app.route("/document-editor/<doc_id>")
def document_editor(doc_id):
    """Document Editor for manual review"""
    doc_type = request.args.get("type", "Protocol")
    
    # Mock extracted data based on document type
    if doc_type == "Protocol":
        doc_data = {
            "id": doc_id,
            "type": "Protocol",
            "filename": "Clinical_Protocol_TRIAL-ABC_v3.2.pdf",
            "extracted": {
                "trial_id": "TRIAL-ABC",
                "protocol_number": "JNJ-ABC-2025-001",
                "study_title": "A Phase 3, Randomized, Double-Blind Study of Drug X in Patients with Condition Y",
                "study_phase": "Phase 3",
                "therapeutic_area": "Oncology",
                "transfer_variables": "STUDYID, USUBJID, DOMAIN, AGE, SEX, RACE, COUNTRY",
                "test_concepts": "LBTESTCD, LBTEST, LBCAT, LBORRES, LBORRESU"
            },
            "notes": ""
        }
    else:  # SOW
        doc_data = {
            "id": doc_id,
            "type": "SOW",
            "filename": "SOW_Vendor_XYZ_2025.docx",
            "extracted": {
                "vendor_name": "ABC Clinical Labs",
                "vendor_id": "VEND-2",
                "data_stream": "Laboratory Results",
                "agreement_date": "2025-01-15",
                "data_format": "CSV",
                "delivery_frequency": "Weekly"
            },
            "notes": ""
        }
    
    return render_template("document_editor.html", doc_data=doc_data)

@app.route('/api/run-documents/<run_id>')
def get_run_documents_api(run_id):
    """API endpoint to get documents for a specific run (legacy)"""
    warehouse_id = os.environ.get('DATABRICKS_WAREHOUSE_ID')
    result = api.get_run_documents(run_id, warehouse_id=warehouse_id)
    return jsonify(result)

@app.route('/api/run-details/<run_id>')
def get_run_details_api(run_id):
    """API endpoint to get run details with entity counts from Bronze/Silver/Gold layers"""
    warehouse_id = os.environ.get('DATABRICKS_WAREHOUSE_ID')
    result = api.get_run_details(run_id, warehouse_id=warehouse_id)
    return jsonify(result)

# -------- Study Management Routes --------
@app.route("/study/setup")
def setup_study():
    """Setup Study page - allows creating new studies"""
    try:
        config = study_get_db_config()
        client = study_get_sql_client()
        studies = get_studies(client, config)
        databricks_host = os.environ.get('DATABRICKS_HOST', '')
        return render_template("setup_study.html", studies=studies, nav_active='study', databricks_host=databricks_host)
    except Exception as e:
        print(f"Error loading studies: {e}")
        import traceback
        traceback.print_exc()
        databricks_host = os.environ.get('DATABRICKS_HOST', '')
        return render_template("setup_study.html", studies=[], error=str(e), nav_active='study', databricks_host=databricks_host)


@app.route("/study/<study_id>")
def study_details(study_id):
    """Study details page - shows study info, activities, and allows vendor/stream assignment"""
    try:
        config = study_get_db_config()
        client = study_get_sql_client()
        
        # Get study details
        study = get_study_details(client, config, study_id)
        if not study:
            flash(f"Study {study_id} not found", "error")
            return redirect(url_for("setup_study"))
        
        # Get activities extracted from protocol
        activities = get_study_activities(client, config, study_id)
        
        # Get vendors and data streams for dropdowns
        vendors = get_vendors(client, config)
        data_streams = get_data_streams(client, config)
        
        databricks_host = os.environ.get('DATABRICKS_HOST', '')
        return render_template(
            "study_details.html",
            study=study,
            activities=activities,
            vendors=vendors,
            data_streams=data_streams,
            nav_active='study',
            databricks_host=databricks_host
        )
    except Exception as e:
        print(f"Error loading study details: {e}")
        import traceback
        traceback.print_exc()
        flash(f"Error loading study: {str(e)}", "error")
        return redirect(url_for("setup_study"))


@app.route("/api/reference-data", methods=["GET"])
def get_reference_data():
    """API endpoint to fetch reference data for search dropdowns (studies, vendors, data streams)"""
    from api.databricks_client import DatabricksSQLClient
    try:
        warehouse_id = os.environ.get('DATABRICKS_WAREHOUSE_ID')
        client = DatabricksSQLClient(warehouse_id=warehouse_id)
        
        catalog = os.environ.get('CATALOG_NAME', 'aira_test')
        gold_schema = os.environ.get('GOLD_SCHEMA', 'gold_md')
        
        result = {
            "ok": True,
            "studies": [],
            "vendors": [],
            "data_streams": []
        }
        
        # Fetch studies from md_study
        try:
            study_query = f"""
                SELECT study_id, study_title 
                FROM {catalog}.{gold_schema}.md_study 
                ORDER BY study_title
            """
            study_results = client.execute_query(study_query, raise_on_error=True)
            result["studies"] = [
                {"id": row.get("study_id", ""), "name": row.get("study_title", "")}
                for row in (study_results or [])
            ]
        except Exception as e:
            print(f"Warning: Could not fetch studies: {e}")
        
        # Fetch vendors from md_vendor
        try:
            vendor_query = f"""
                SELECT vendor_id, vendor_name 
                FROM {catalog}.{gold_schema}.md_vendor 
                WHERE is_active = true
                ORDER BY vendor_name
            """
            vendor_results = client.execute_query(vendor_query, raise_on_error=True)
            result["vendors"] = [
                {"id": row.get("vendor_id", ""), "name": row.get("vendor_name", "")}
                for row in (vendor_results or [])
            ]
        except Exception as e:
            print(f"Warning: Could not fetch vendors: {e}")
        
        # Fetch data streams from md_data_stream
        try:
            stream_query = f"""
                SELECT data_stream_id, data_stream_name 
                FROM {catalog}.{gold_schema}.md_data_stream 
                WHERE is_active = true
                ORDER BY data_stream_name
            """
            stream_results = client.execute_query(stream_query, raise_on_error=True)
            result["data_streams"] = [
                {"id": row.get("data_stream_id", ""), "name": row.get("data_stream_name", "")}
                for row in (stream_results or [])
            ]
        except Exception as e:
            print(f"Warning: Could not fetch data streams: {e}")
        
        return jsonify(result)
        
    except Exception as e:
        print(f"ERROR: get_reference_data failed: {e}")
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/study/create", methods=["POST"])
def api_create_study():
    """API endpoint to create a new study - uploads file and triggers job"""
    try:
        # Get form data
        study_title = request.form.get("study_title")
        study_nickname = request.form.get("study_nickname", "")
        study_description = request.form.get("study_description", "")
        study_phase = request.form.get("study_phase", "")
        protocol_file = request.files.get("protocol_file")
        
        if not study_title:
            return jsonify({"ok": False, "error": "Study title is required"}), 400
        
        if not protocol_file:
            return jsonify({"ok": False, "error": "Protocol document is required"}), 400
        
        # Generate IDs
        import uuid
        study_id = str(uuid.uuid4())[:8].upper()  # Short ID like "A1B2C3D4"
        protocol_id = str(uuid.uuid4())
        
        # Step 1: Upload the protocol file to volume using common upload function
        from api.upload_api import save_file_to_volume, get_upload_config
        
        upload_config = get_upload_config()
        upload_result = save_file_to_volume(
            file_storage=protocol_file,
            document_type="Protocol",
            upload_source_root=upload_config.get('upload_source_root', 'test/uploads'),
            config=upload_config
        )
        
        if not upload_result.get("ok"):
            return jsonify({
                "ok": False, 
                "error": f"Failed to upload file: {upload_result.get('error')}"
            }), 500
        
        print(f"STUDY CREATE: File uploaded to {upload_result.get('file_path')}")
        print(f"STUDY CREATE: Source subdir: {upload_result.get('source_subdir')}")
        
        # Step 2: Trigger the study creation job with upload info
        from api.study_api import trigger_setup_study_job
        # Job expects source_root (base path), derive from upload_source_root
        upload_source_root = upload_config.get('upload_source_root', 'test/uploads')
        source_root = upload_source_root.replace('/uploads', '') if '/uploads' in upload_source_root else upload_source_root
        
        job_result = trigger_setup_study_job(
            study_id=study_id,
            study_title=study_title,
            study_nickname=study_nickname,
            study_description=study_description,
            study_phase=study_phase,
            protocol_id=protocol_id,
            source_root=source_root,
            source_subdir=upload_result.get('source_subdir'),
            catalog_override=upload_config.get('catalog')
        )
        
        if not job_result.get("ok"):
            return jsonify({"ok": False, "error": job_result.get("error", "Failed to trigger job")}), 500
        
        return jsonify({
            "ok": True,
            "study_id": study_id,
            "study_title": study_title,
            "study_nickname": study_nickname,
            "study_phase": study_phase,
            "protocol_id": protocol_id,
            "run_id": job_result.get("run_id"),
            "job_id": job_result.get("job_id"),
            "file_path": upload_result.get("file_path"),
            "status": "IN_PROGRESS"
        })
        
    except Exception as e:
        print(f"Error creating study: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/study/<study_id>/extract-data", methods=["POST"])
def api_extract_study_data(study_id):
    """API endpoint to extract data from protocol document"""
    try:
        # In a full implementation, this would trigger a job to extract Schedule of Activities
        # For now, we just update status
        config = study_get_db_config()
        client = study_get_sql_client()
        
        # Update status
        update_study_status(client, config, study_id, "PARSING_COMPLETED")
        
        return jsonify({"ok": True, "study_id": study_id, "message": "Data extraction started"})
    except Exception as e:
        print(f"Error extracting data: {e}")
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/study/<study_id>/assign-activity", methods=["POST"])
def api_assign_activity(study_id):
    """API endpoint to assign vendor/data stream to an activity"""
    try:
        config = study_get_db_config()
        client = study_get_sql_client()
        
        data = request.get_json()
        activity_id = data.get("activity_id")
        vendor_id = data.get("vendor_id")
        data_stream_id = data.get("data_stream_id")
        
        result = assign_activity_vendor_stream(
            client, config, study_id, activity_id,
            vendor_id=vendor_id, data_stream_id=data_stream_id
        )
        
        return jsonify(result)
    except Exception as e:
        print(f"Error assigning activity: {e}")
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/study/<study_id>/complete", methods=["POST"])
def api_complete_study(study_id):
    """API endpoint to mark a study as completed"""
    try:
        config = study_get_db_config()
        client = study_get_sql_client()
        
        result = update_study_status(client, config, study_id, "COMPLETED")
        return jsonify(result)
    except Exception as e:
        print(f"Error completing study: {e}")
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/study/<study_id>/update", methods=["POST"])
def api_update_study(study_id):
    """API endpoint to update study metadata"""
    from api.study_api import update_study
    
    try:
        config = study_get_db_config()
        client = study_get_sql_client()
        
        # Get JSON data from request
        study_data = request.get_json()
        if not study_data:
            return jsonify({"ok": False, "error": "No data provided"}), 400
        
        # Get current user for audit
        updated_by = request.headers.get('X-User-Email', 'unknown')
        
        result = update_study(client, config, study_id, study_data, updated_by=updated_by)
        return jsonify(result)
    except Exception as e:
        print(f"Error updating study: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/study/create-mock", methods=["POST"])
def api_create_mock_studies():
    """API endpoint to create mock studies in gold table (legacy - kept for compatibility)"""
    from api.dta_api import _get_db_config, _get_sql_client, create_mock_studies
    
    try:
        config = _get_db_config()
        client = _get_sql_client()
        result = create_mock_studies(client, config)
        return jsonify({"ok": True, "studies": result})
    except Exception as e:
        print(f"Error creating mock studies: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/ingestion")
def ingestion():
    """Ingestion jobs page - shows recent job runs from Databricks"""
    status = request.args.get("status")
    
    # Get warehouse_id from environment (set in app.yaml)
    warehouse_id = os.environ.get('DATABRICKS_WAREHOUSE_ID')
    
    if not warehouse_id:
        print("ERROR: DATABRICKS_WAREHOUSE_ID not set!")
        return render_template(
            'ingestion.html',
            error="Configuration error: DATABRICKS_WAREHOUSE_ID not set"
        )
    
    print(f"DEBUG: Using warehouse_id: {warehouse_id}")
    
    # Get jobs from API (uses real Databricks data - no mock fallback)
    result = api.get_jobs(status_filter=status, use_real_data=True, warehouse_id=warehouse_id)
    
    # If there's an error, display it
    if not result.get('success'):
        flash(f"Error loading jobs: {result.get('error')}", "error")
        return render_template(
            'ingestion.html',
            jobs=[],
            runs=[],
            status=status,
            kpis={
                "runs7d": 0,
                "successRate": "0%",
                "avgDuration": "N/A",
                "entitiesProduced": []
            },
            error=result.get('error', 'Unknown error'),
            error_details=result.get('details') or result.get('traceback'),
            is_mock_data=True,  # Flag for fallback/mock data
            unavailable_jobs_count=0
        )
    
    api_data = result["data"]
    jobs = api_data.get("jobs", [])  # Jobs with enriched run statistics
    runs = api_data.get("runs", [])  # All runs (for backward compatibility)
    kpis = api_data.get("kpis", {})
    
    # Count unavailable jobs (jobs that couldn't be loaded)
    unavailable_jobs_count = len(result.get("warnings", []))
    
    return render_template("ingestion.html", jobs=jobs, runs=runs, status=status, kpis=kpis, 
                           is_mock_data=False, unavailable_jobs_count=unavailable_jobs_count)

def parse_search_query(q):
    """
    Parse free-form search query and extract trial, vendor, stream filters.
    Supports formats like:
    - "TRIAL-ABC"
    - "trial id = ABC"
    - "ABC"
    - "trial id = ABC and vendor id = VEND-1"
    - "ABC VEND-1"
    """
    import re
    
    q_lower = q.lower()
    filters = {
        'trial': [],
        'vendor': [],
        'stream': []
    }
    
    # Pattern for "field = value" or "field: value"
    field_patterns = [
        (r'trial\s*(?:id)?\s*[=:]\s*([a-z0-9\-]+)', 'trial'),
        (r'vendor\s*(?:id)?\s*[=:]\s*([a-z0-9\-]+)', 'vendor'),
        (r'(?:data\s*)?stream\s*[=:]\s*([a-z0-9\-]+)', 'stream'),
    ]
    
    for pattern, field in field_patterns:
        matches = re.findall(pattern, q_lower, re.IGNORECASE)
        for match in matches:
            # Add with or without prefix
            filters[field].append(match.upper())
            if field == 'trial' and not match.upper().startswith('TRIAL-'):
                filters[field].append(f'TRIAL-{match.upper()}')
            elif field == 'vendor' and not match.upper().startswith('VEND-'):
                filters[field].append(f'VEND-{match.upper()}')
    
    # If no structured patterns found, try to extract tokens
    if not any(filters.values()):
        # Remove common words
        stop_words = ['and', 'or', 'the', 'id', '=', ':']
        tokens = re.findall(r'[a-z0-9\-]+', q_lower)
        tokens = [t for t in tokens if t not in stop_words and len(t) > 1]
        
        for token in tokens:
            token_upper = token.upper()
            # Try to guess the field type
            if token.startswith('trial-') or re.match(r'^trial', token):
                filters['trial'].append(token_upper)
                if not token_upper.startswith('TRIAL-'):
                    filters['trial'].append(f'TRIAL-{token_upper}')
            elif token.startswith('vend-') or re.match(r'^vend', token):
                filters['vendor'].append(token_upper)
                if not token_upper.startswith('VEND-'):
                    filters['vendor'].append(f'VEND-{token_upper}')
            else:
                # Could be trial, vendor, or stream - add to all
                filters['trial'].append(token_upper)
                filters['trial'].append(f'TRIAL-{token_upper}')
                filters['vendor'].append(token_upper)
                filters['vendor'].append(f'VEND-{token_upper}')
                filters['stream'].append(token_upper)
    
    return filters

# ============================================================================
# AUDIT & ACTIVITY
# ============================================================================

@app.route("/audit")
def audit():
    """Audit & Activity screen - shows all DTAs with activity logs."""
    return render_template("audit.html")

@app.route("/documents_review")
def documents_review():
    """Documents Review - view Protocol documents processed by AI document parsing."""
    # Pass the Databricks host for constructing job run URLs
    databricks_host = os.environ.get('DATABRICKS_HOST', '')
    return render_template("documents_review.html", databricks_host=databricks_host)

# ============================================================================
# DTA VIEWER ROUTES
# ============================================================================

@app.route("/dta-viewer")
def dta_viewer():
    """DTA Viewer - browse and filter all DTAs."""
    from api.databricks_client import DatabricksSQLClient
    
    status_filter = request.args.get('status', 'all')
    
    try:
        # Get warehouse_id from environment (required)
        warehouse_id = os.environ.get('DATABRICKS_WAREHOUSE_ID')
        if not warehouse_id:
            return render_template('dta_viewer.html', 
                                   dtas=[], 
                                   status_filter=status_filter,
                                   counts={'all': 0, 'draft': 0, 'active': 0, 'manual_review': 0, 'template': 0},
                                   error="DATABRICKS_WAREHOUSE_ID not configured")
        
        client = DatabricksSQLClient(warehouse_id)
        catalog = os.environ.get('CATALOG_NAME', 'aira_test')
        dta_table = f"{catalog}.gold_md.dta"
        
        # Build query with optional status filter
        if status_filter and status_filter != 'all':
            if status_filter == 'TEMPLATE':
                # Templates are identified by dta_number prefix, not status
                query = f"""
                    SELECT dta_id, dta_number, dta_name, trial_id, data_stream_type, 
                           data_provider_name, status, workflow_state, version, 
                           last_updated_ts
                    FROM {dta_table}
                    WHERE dta_number LIKE 'TPL%'
                    ORDER BY last_updated_ts DESC
                """
            else:
                # For other status filters, exclude templates
                query = f"""
                    SELECT dta_id, dta_number, dta_name, trial_id, data_stream_type, 
                           data_provider_name, status, workflow_state, version, 
                           last_updated_ts
                    FROM {dta_table}
                    WHERE status = '{status_filter}'
                      AND dta_number NOT LIKE 'TPL%'
                    ORDER BY last_updated_ts DESC
                """
        else:
            query = f"""
                SELECT dta_id, dta_number, dta_name, trial_id, data_stream_type, 
                       data_provider_name, status, workflow_state, version, 
                       last_updated_ts
                FROM {dta_table}
                ORDER BY last_updated_ts DESC
            """
        
        print(f"DEBUG dta_viewer: Executing query: {query[:200]}...")
        dtas = client.execute_query(query) or []
        
        # Get document counts for each DTA from md_file_history
        file_history_table = f"{catalog}.bronze_md.md_file_history"
        if dtas:
            dta_ids = [dta.get('dta_id') for dta in dtas if dta.get('dta_id')]
            if dta_ids:
                # Query to count documents per DTA (using parent_document_id as DTA reference)
                doc_count_query = f"""
                    SELECT 
                        parent_document_id as dta_id,
                        COUNT(*) as doc_count,
                        CONCAT_WS(', ', COLLECT_SET(
                            CASE 
                                WHEN array_contains(document_tags, 'tsDTA') THEN 'tsDTA'
                                WHEN array_contains(document_tags, 'Protocol') THEN 'Protocol'
                                WHEN array_contains(document_tags, 'OA') THEN 'OA'
                                ELSE 'Other'
                            END
                        )) as doc_types
                    FROM {file_history_table}
                    WHERE parent_document_id IS NOT NULL
                      AND is_current = true
                    GROUP BY parent_document_id
                """
                try:
                    doc_counts = client.execute_query(doc_count_query) or []
                    doc_count_map = {d.get('dta_id'): {'count': d.get('doc_count', 0), 'types': d.get('doc_types', '')} for d in doc_counts}
                    
                    # Merge doc counts into DTAs
                    for dta in dtas:
                        dta_id = dta.get('dta_id')
                        if dta_id and dta_id in doc_count_map:
                            dta['doc_count'] = doc_count_map[dta_id]['count']
                            dta['doc_types'] = doc_count_map[dta_id]['types']
                        else:
                            dta['doc_count'] = 0
                            dta['doc_types'] = ''
                except Exception as doc_err:
                    print(f"Warning: Could not fetch document counts: {doc_err}")
                    for dta in dtas:
                        dta['doc_count'] = 0
                        dta['doc_types'] = ''
        
        # Get counts for each status (exclude templates from status counts)
        count_query = f"""
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'DRAFT' AND dta_number NOT LIKE 'TPL%' THEN 1 ELSE 0 END) as draft,
                SUM(CASE WHEN status = 'ACTIVE' AND dta_number NOT LIKE 'TPL%' THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN status = 'MANUAL_REVIEW' AND dta_number NOT LIKE 'TPL%' THEN 1 ELSE 0 END) as manual_review,
                SUM(CASE WHEN dta_number LIKE 'TPL%' THEN 1 ELSE 0 END) as template
            FROM {dta_table}
        """
        count_result = client.execute_query(count_query)
        counts = {
            'all': count_result[0].get('total', 0) if count_result else 0,
            'draft': count_result[0].get('draft', 0) if count_result else 0,
            'active': count_result[0].get('active', 0) if count_result else 0,
            'manual_review': count_result[0].get('manual_review', 0) if count_result else 0,
            'template': count_result[0].get('template', 0) if count_result else 0
        }
        
        print(f"DEBUG dta_viewer: Found {len(dtas)} DTAs, counts: {counts}")
        
        return render_template("dta_viewer.html", 
                               dtas=dtas, 
                               status_filter=status_filter,
                               counts=counts,
                               nav_active='dta_viewer')
                               
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"ERROR in dta_viewer: {e}")
        return render_template("dta_viewer.html", 
                               dtas=[], 
                               status_filter=status_filter,
                               counts={'all': 0, 'draft': 0, 'active': 0, 'manual_review': 0, 'template': 0},
                               nav_active='dta_viewer')


# Keep legacy review route for backwards compatibility (redirects to filtered view)
@app.route("/review")
def review():
    """Legacy review route - redirects to DTA Viewer with manual review filter."""
    return redirect(url_for('dta_viewer', status='MANUAL_REVIEW'))


@app.route("/dta/<dta_id>/view")
def view_dta(dta_id):
    """Read-only view of DTA details."""
    from api.dta_api import _get_db_config, _get_sql_client, get_test_concepts_for_dta, get_oa_for_dta, get_codelists_for_dta, transform_codelists_to_display, get_di_params_for_dta
    
    print(f"=" * 60)
    print(f"VIEW DTA: Loading DTA ID = {dta_id}")
    print(f"=" * 60)
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    silver_schema = config["silver_schema"]
    
    # Get DTA details (latest_major_version removed - derived from md_version_registry)
    dta_query = f"""
        SELECT 
            dta_id, dta_number, dta_name,
            trial_id, data_stream_type, data_provider_name,
            status, workflow_state, notes, version,
            base_template_version, current_draft_version,
            created_ts, last_updated_ts
        FROM {catalog}.{gold_schema}.dta
        WHERE dta_id = '{dta_id}'
    """
    
    try:
        result = client.execute_query(dta_query)
        if not result:
            flash("DTA not found", "error")
            return redirect(url_for("review"))
        
        dta = dict(result[0])
        
        # Determine which table to query based on DTA status
        # Data is in GOLD only when status is ACTIVE (approved) or TEMPLATE
        # All other states (DRAFT, PENDING_APPROVAL, IN_REVIEW, etc.) have data in SILVER
        dta_status = dta.get('status', '')
        workflow_state = dta.get('workflow_state', '')
        is_draft = dta_status not in ('ACTIVE', 'TEMPLATE', 'ARCHIVED')
        print(f"DEBUG view_dta: DTA status = {dta_status}, workflow_state = {workflow_state}, is_draft = {is_draft}")
        
        if is_draft:
            # Get transfer variables from SILVER draft table for draft DTAs
            tv_query = f"""
                SELECT * FROM {catalog}.{silver_schema}.md_dta_transfer_variables_draft
                WHERE dta_id = '{dta_id}'
                ORDER BY COALESCE(domain_info, 'ZZZ'), COALESCE(transfer_variable_order, 9999), transfer_variable_name
            """
            count_table = f"{catalog}.{silver_schema}.md_dta_transfer_variables_draft"
        else:
            # Get transfer variables from GOLD library table for approved/template DTAs
            tv_query = f"""
                SELECT * FROM {catalog}.{gold_schema}.md_dta_transfer_variables
                WHERE dta_id = '{dta_id}' AND is_current = true
                ORDER BY COALESCE(domain_info, 'ZZZ'), COALESCE(transfer_variable_order, 9999), transfer_variable_name
            """
            count_table = f"{catalog}.{gold_schema}.md_dta_transfer_variables"
        
        print(f"DEBUG view_dta: TV Query: {tv_query}")
        tv_results = client.execute_query(tv_query)
        print(f"DEBUG view_dta: tv_results type: {type(tv_results)}, length: {len(tv_results) if tv_results else 0}")
        transfer_variables = [dict(r) for r in tv_results] if tv_results else []
        print(f"DEBUG view_dta: After conversion - transfer_variables length: {len(transfer_variables)}")
        
        # Debug: Also run a COUNT(*) query to verify
        if is_draft:
            count_query = f"""
                SELECT COUNT(*) as total FROM {count_table}
                WHERE dta_id = '{dta_id}'
            """
        else:
            count_query = f"""
                SELECT COUNT(*) as total FROM {count_table}
                WHERE dta_id = '{dta_id}' AND is_current = true
            """
        count_result = client.execute_query(count_query)
        if count_result:
            db_count = count_result[0].get('total', 'unknown')
            print(f"DEBUG view_dta: Database COUNT(*) = {db_count}, returned rows = {len(transfer_variables)}")
        
        if transfer_variables:
            # Log first record columns for debugging
            print(f"DEBUG view_dta: TV columns: {list(transfer_variables[0].keys())}")
        
        # Get test concepts - pass correct parameters including status
        test_concepts_raw = get_test_concepts_for_dta(client, config, dta_id, dta_status=dta_status)
        print(f"DEBUG view_dta: Found {len(test_concepts_raw)} test concepts")
        
        # Explode transfer_tuple_map for display
        # Collect all unique keys across all test concepts
        all_tuple_keys = set()
        test_concepts = []
        for tc in test_concepts_raw:
            tc_dict = dict(tc) if not isinstance(tc, dict) else tc
            tuple_map = tc_dict.get('transfer_tuple_map', {})
            
            # Handle if tuple_map is a string (JSON)
            if isinstance(tuple_map, str):
                try:
                    import json
                    tuple_map = json.loads(tuple_map)
                except:
                    tuple_map = {}
            elif tuple_map is None:
                tuple_map = {}
            
            # Collect keys
            all_tuple_keys.update(tuple_map.keys())
            
            # Flatten the tuple_map into the record
            tc_flat = {
                'test_concept_reference': tc_dict.get('test_concept_reference'),
                'status': tc_dict.get('status'),
                'notes': tc_dict.get('notes'),
                'domain_info': tc_dict.get('domain_info'),  # Include domain_info for filtering
                'transfer_tuple_map': tuple_map  # Keep original for reference
            }
            # Add each tuple key as a column
            for key, value in tuple_map.items():
                tc_flat[key] = value
            
            test_concepts.append(tc_flat)
        
        # Sort keys for consistent column order
        tuple_keys = sorted(list(all_tuple_keys))
        print(f"DEBUG view_dta: Transfer tuple keys: {tuple_keys}")
        
        # Get Data Ingestion Parameters (use silver for drafts, gold for approved)
        di_result = get_di_params_for_dta(client, config, dta_id, is_draft=is_draft)
        di_params = di_result.get('params', [])
        di_params_grouped = di_result.get('grouped', {})
        print(f"DEBUG view_dta: DI params exists = {di_result.get('exists', False)}, count = {len(di_params)}")
        
        # Get Operational Agreements data (use silver for drafts, gold for approved)
        oa_data = get_oa_for_dta(client, config, dta_id, is_draft=is_draft)
        print(f"DEBUG view_dta: OA exists = {oa_data.get('oa_exists', False)}, is_draft={is_draft}")
        
        # Get Codelists data
        codelists_raw = get_codelists_for_dta(client, config, dta_id, dta_status=dta_status)
        codelists = transform_codelists_to_display(codelists_raw)
        print(f"DEBUG view_dta: Found {len(codelists)} codelists")
        
        # Get source documents for this DTA from md_file_history
        # Step 1: Get parent_document_id from dta table
        # Step 2: Get that document AND any child documents from md_file_history
        source_documents = []
        try:
            file_history_table = f"{catalog}.bronze_md.md_file_history"
            dta_table = f"{catalog}.{gold_schema}.dta"
            
            # Query: Get the parent_document_id from DTA, then get that document + children
            source_docs_query = f"""
                WITH dta_doc AS (
                    SELECT parent_document_id as doc_id
                    FROM {dta_table}
                    WHERE dta_id = '{dta_id}' AND parent_document_id IS NOT NULL
                )
                SELECT 
                    fh.document_id,
                    regexp_extract(fh.extracted_path, '[^/]+$', 0) as file_name,
                    fh.extracted_path,
                    fh.document_tags,
                    fh.status,
                    fh.created_ts
                FROM {file_history_table} fh
                WHERE fh.is_current = true
                  AND (
                      fh.document_id IN (SELECT doc_id FROM dta_doc)
                      OR fh.parent_document_id IN (SELECT doc_id FROM dta_doc)
                  )
                ORDER BY fh.created_ts DESC
            """
            print(f"DEBUG view_dta: Source docs query executing...")
            source_docs_result = client.execute_query(source_docs_query) or []
            
            # Parse document_tags - may come as string representation of array
            import json
            source_documents = []
            for doc in source_docs_result:
                doc_dict = dict(doc)
                tags = doc_dict.get('document_tags')
                if isinstance(tags, str):
                    try:
                        doc_dict['document_tags'] = json.loads(tags)
                    except:
                        doc_dict['document_tags'] = [tags] if tags else []
                elif tags is None:
                    doc_dict['document_tags'] = []
                source_documents.append(doc_dict)
            
            print(f"DEBUG view_dta: Found {len(source_documents)} source documents")
        except Exception as doc_err:
            # Log the full error - don't swallow silently
            print(f"ERROR fetching source documents: {doc_err}")
            import traceback
            traceback.print_exc()
            source_documents = []
        
        return render_template("view.html", 
                             dta=dta, 
                             transfer_variables=transfer_variables,
                             test_concepts=test_concepts,
                             tuple_keys=tuple_keys,
                             codelists=codelists,
                             oa_data=oa_data,
                             di_params_grouped=di_params_grouped,
                             source_documents=source_documents,
                             nav_active='dta_viewer')
    except Exception as e:
        print(f"Error loading DTA view: {e}")
        import traceback
        traceback.print_exc()
        flash(f"Error loading DTA: {str(e)}", "error")
        return redirect(url_for("review"))

# =============================================================================
# DTA WORKFLOW ROUTES (formerly Approvals)
# =============================================================================

@app.route("/approvals")
def approvals():
    """DTA Workflow screen - shows DTAs pending approval and promotion."""
    from api.dta_api import _get_db_config, _get_sql_client
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    
    # Current user (hardcoded for now)
    current_user_email = "arun.wagle@jnj.com"
    
    # Get DTAs pending approval (workflow_state IN_REVIEW and not yet APPROVED)
    pending_approval_query = f"""
        SELECT 
            d.dta_id,
            d.dta_number,
            d.dta_name,
            d.trial_id,
            d.data_stream_type,
            d.data_provider_name,
            d.status,
            d.workflow_state,
            d.version,
            d.last_updated_ts,
            w.dta_workflow_id,
            w.workflow_status,
            w.initiated_ts
        FROM {catalog}.{gold_schema}.dta d
        LEFT JOIN {catalog}.{gold_schema}.dta_workflow w 
            ON d.dta_id = w.dta_id AND d.workflow_iteration = w.workflow_iteration
        WHERE d.workflow_state = 'IN_REVIEW'
          AND d.dta_number NOT LIKE 'TPL%'
        ORDER BY w.initiated_ts DESC NULLS LAST, d.last_updated_ts DESC
    """
    
    # Get DTAs ready for template promotion (APPROVED but not yet PROMOTED)
    pending_promotion_query = f"""
        SELECT 
            d.dta_id,
            d.dta_number,
            d.dta_name,
            d.trial_id,
            d.data_stream_type,
            d.data_provider_name,
            d.status,
            d.workflow_state,
            d.version,
            d.last_updated_ts
        FROM {catalog}.{gold_schema}.dta d
        WHERE d.workflow_state = 'APPROVED'
          AND d.status = 'ACTIVE'
          AND d.dta_number NOT LIKE 'TPL%'
        ORDER BY d.last_updated_ts DESC
    """
    
    # Get recently approved DTAs (last 24 hours)
    recent_approved_query = f"""
        SELECT 
            d.dta_id,
            d.dta_number,
            d.dta_name,
            d.data_provider_name,
            d.data_stream_type,
            d.version,
            d.last_updated_ts
        FROM {catalog}.{gold_schema}.dta d
        WHERE d.workflow_state = 'APPROVED'
          AND d.last_updated_ts >= current_timestamp() - INTERVAL 1 DAY
          AND d.dta_number NOT LIKE 'TPL%'
        ORDER BY d.last_updated_ts DESC
        LIMIT 5
    """
    
    # Get recently promoted DTA Templates (last 24 hours) - Show TEMPLATES that were created
    recent_promoted_query = f"""
        SELECT 
            d.dta_id,
            d.dta_number,
            d.dta_name,
            d.data_provider_name,
            d.data_stream_type,
            d.version,
            d.last_updated_ts
        FROM {catalog}.{gold_schema}.dta d
        WHERE d.dta_number LIKE 'TPL%'
          AND d.status = 'ACTIVE'
          AND d.last_updated_ts >= current_timestamp() - INTERVAL 1 DAY
        ORDER BY d.last_updated_ts DESC
        LIMIT 5
    """
    
    try:
        # Fetch pending approvals
        pending_approval_result = client.execute_query(pending_approval_query)
        pending_approval_raw = pending_approval_result if pending_approval_result else []
        
        # Get approval tasks for each pending DTA
        pending_approvals = []
        for dta in pending_approval_raw:
            tasks_query = f"""
                SELECT 
                    approval_task_id,
                    approver_role,
                    assigned_to_principal,
                    approval_status,
                    approval_order,
                    approval_comment,
                    approved_ts
                FROM {catalog}.{gold_schema}.dta_approval_task
                WHERE dta_id = '{dta['dta_id']}'
                ORDER BY approval_order
            """
            tasks_result = client.execute_query(tasks_query)
            tasks = tasks_result if tasks_result else []
            
            # Check if current user has a pending task
            user_can_approve = any(
                t['assigned_to_principal'] == current_user_email and t['approval_status'] == 'PENDING'
                for t in tasks
            )
            
            # Check if all approved
            all_approved = all(t['approval_status'] == 'APPROVED' for t in tasks) if tasks else False
            
            pending_approvals.append({
                **dta,
                'approvals': tasks,
                'user_can_approve': user_can_approve,
                'all_approved': all_approved
            })
        
        # Fetch pending promotions
        pending_promotion_result = client.execute_query(pending_promotion_query)
        pending_promotions = pending_promotion_result if pending_promotion_result else []
        
        # Fetch recently approved
        recent_approved_result = client.execute_query(recent_approved_query)
        recent_approvals = recent_approved_result if recent_approved_result else []
        
        # Fetch recently promoted
        recent_promoted_result = client.execute_query(recent_promoted_query)
        recent_promotions = recent_promoted_result if recent_promoted_result else []
        
        return render_template("approvals.html", 
                             pending_approvals=pending_approvals,
                             pending_promotions=pending_promotions,
                             recent_approvals=recent_approvals,
                             recent_promotions=recent_promotions,
                             current_user_email=current_user_email,
                             nav_active='workflow')
    except Exception as e:
        print(f"Error loading DTA workflow: {e}")
        import traceback
        traceback.print_exc()
        return render_template("approvals.html", 
                             pending_approvals=[], 
                             pending_promotions=[],
                             recent_approvals=[],
                             recent_promotions=[],
                             current_user_email=current_user_email, 
                             nav_active='workflow')

@app.route("/approvals/<dta_id>")
def approval_detail(dta_id):
    """Approval detail page for a specific DTA."""
    from api.dta_api import _get_db_config, _get_sql_client
    
    print(f"=" * 60)
    print(f"APPROVAL DETAIL: Loading DTA ID = {dta_id}")
    print(f"=" * 60)
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    
    # Current user (hardcoded for now)
    current_user_email = "arun.wagle@jnj.com"
    
    # Get DTA details
    dta_query = f"""
        SELECT 
            d.dta_id,
            d.dta_number,
            d.dta_name,
            d.trial_id,
            d.data_stream_type,
            d.data_provider_name,
            d.status,
            d.workflow_state,
            d.version,
            d.last_updated_ts,
            w.dta_workflow_id,
            w.workflow_status,
            w.initiated_ts,
            w.summary_comment
        FROM {catalog}.{gold_schema}.dta d
        LEFT JOIN {catalog}.{gold_schema}.dta_workflow w 
            ON d.dta_id = w.dta_id AND d.workflow_iteration = w.workflow_iteration
        WHERE d.dta_id = '{dta_id}'
    """
    
    print(f"APPROVAL DETAIL: Executing query...")
    
    try:
        result = client.execute_query(dta_query)
        dta_list = result if result else []
        
        print(f"APPROVAL DETAIL: Query returned {len(dta_list)} rows")
        if dta_list:
            print(f"APPROVAL DETAIL: First row = {dta_list[0]}")
        
        if not dta_list:
            print(f"APPROVAL DETAIL ERROR: DTA {dta_id} not found!")
            flash("DTA not found", "error")
            return redirect(url_for('approvals'))
        
        dta = dta_list[0]
        
        # Get approval tasks
        tasks_query = f"""
            SELECT 
                approval_task_id,
                approver_role,
                assigned_to_principal,
                approval_status,
                approval_order,
                approval_comment,
                approved_ts,
                created_ts
            FROM {catalog}.{gold_schema}.dta_approval_task
            WHERE dta_id = '{dta_id}'
            ORDER BY approval_order
        """
        tasks_result = client.execute_query(tasks_query)
        tasks = tasks_result if tasks_result else []
        
        # Check if current user has a pending task
        user_task = next(
            (t for t in tasks if t['assigned_to_principal'] == current_user_email and t['approval_status'] == 'PENDING'),
            None
        )
        
        # Check if all approved
        all_approved = all(t['approval_status'] == 'APPROVED' for t in tasks) if tasks else False
        
        return render_template("approval_detail.html",
                             dta=dta,
                             tasks=tasks,
                             user_task=user_task,
                             all_approved=all_approved,
                             current_user_email=current_user_email,
                             nav_active='workflow')
    except Exception as e:
        print(f"Error loading approval detail: {e}")
        import traceback
        traceback.print_exc()
        flash(f"Error loading DTA: {e}", "error")
        return redirect(url_for('approvals'))

@app.route("/workspace/<dta_id>/assign-approvers")
def assign_approvers(dta_id):
    """Assign approvers to a DTA before starting work."""
    from api.dta_api import _get_db_config, _get_sql_client
    
    print(f"=" * 60)
    print(f"ASSIGN-APPROVERS: Loading DTA {dta_id}")
    print(f"=" * 60)
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    
    # Current user (hardcoded for now)
    current_user_email = "arun.wagle@jnj.com"
    current_user_name = "Arun Wagle"
    
    # Get DTA details
    dta_query = f"""
        SELECT 
            dta_id,
            dta_number,
            dta_name,
            trial_id,
            data_stream_type,
            data_provider_name,
            status
        FROM {catalog}.{gold_schema}.dta
        WHERE dta_id = '{dta_id}'
    """
    
    print(f"ASSIGN-APPROVERS: Query: {dta_query}")
    
    try:
        result = client.execute_query(dta_query)
        dta_list = result if result else []
        
        print(f"ASSIGN-APPROVERS: Query returned {len(dta_list)} results")
        
        if not dta_list:
            print(f"ASSIGN-APPROVERS: DTA not found! Redirecting to composer.")
            flash("DTA not found", "error")
            return redirect(url_for('composer'))
        
        dta = dta_list[0]
        print(f"ASSIGN-APPROVERS: Found DTA: {dta}")
        
        return render_template("assign_approvers.html",
                             dta=dta,
                             current_user_email=current_user_email,
                             current_user_name=current_user_name)
    except Exception as e:
        print(f"ASSIGN-APPROVERS ERROR: {e}")
        import traceback
        traceback.print_exc()
        # Handle table not found gracefully
        error_str = str(e)
        if 'TABLE_OR_VIEW_NOT_FOUND' in error_str or 'cannot be found' in error_str:
            print("ASSIGN-APPROVERS: DTA table not found, redirecting to composer")
            flash("DTA table not found. Please run the data pipeline first.", "error")
        else:
            flash(f"Error loading DTA: {e}", "error")
        return redirect(url_for('composer'))

@app.route("/api/audit/dtas")
def api_audit_dtas():
    """Get all DTAs for audit screen."""
    try:
        from api.dta_api import _get_db_config, _get_sql_client
        
        config = _get_db_config()
        client = _get_sql_client()
        
        dta_table = f"{config['catalog']}.{config['gold_schema']}.dta"
        
        query = f"""
            SELECT dta_id, dta_number, dta_name, trial_id, data_stream_type,
                   data_provider_name, status, workflow_state, 
                   DATE_FORMAT(last_updated_ts, 'MMM dd, yyyy') as last_updated
            FROM {dta_table}
            ORDER BY last_updated_ts DESC
        """
        
        print(f"AUDIT: Fetching DTAs...")
        results = client.execute_query(query, raise_on_error=True)
        
        dtas = [dict(row) for row in (results or [])]
        print(f"AUDIT: Found {len(dtas)} DTAs")
        
        return jsonify({"ok": True, "dtas": dtas})
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        # Handle table not found gracefully - return empty list
        error_str = str(e)
        if 'TABLE_OR_VIEW_NOT_FOUND' in error_str or 'cannot be found' in error_str:
            print("AUDIT: DTA table not found, returning empty list")
            return jsonify({"ok": True, "dtas": []})
        return jsonify({"ok": False, "msg": str(e), "dtas": []})

# =============================================================================
# APPROVAL WORKFLOW APIS
# =============================================================================

@app.route("/api/dta/assign-approvers", methods=["POST"])
def api_assign_approvers():
    """Assign approvers to a DTA's approval tasks."""
    from api.dta_api import _get_db_config, _get_sql_client
    
    data = request.get_json()
    dta_id = data.get("dta_id")
    approvers = data.get("approvers", [])
    
    if not dta_id or not approvers:
        return jsonify({"ok": False, "error": "Missing dta_id or approvers"})
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    approval_table = f"{catalog}.{gold_schema}.dta_approval_task"
    
    try:
        # Update each approver's task
        for approver in approvers:
            role = approver.get("role")
            email = approver.get("email")
            
            if role and email:
                update_query = f"""
                    UPDATE {approval_table}
                    SET assigned_to_principal = '{email}',
                        last_updated_ts = current_timestamp()
                    WHERE dta_id = '{dta_id}'
                      AND approver_role = '{role}'
                """
                client.execute_query(update_query)
                print(f"Assigned {role} to {email} for DTA {dta_id}")
        
        return jsonify({"ok": True, "msg": "Approvers assigned successfully"})
        
    except Exception as e:
        print(f"Error assigning approvers: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)})

@app.route("/api/approval/submit/<dta_id>", methods=["POST"])
def api_submit_for_approval(dta_id):
    """Submit a DTA for approval - changes status and notifies approvers."""
    from api.dta_api import _get_db_config, _get_sql_client
    from api.activity_log_api import log_workflow_event
    
    print(f"=" * 60)
    print(f"SUBMIT FOR APPROVAL: DTA ID = {dta_id}")
    print(f"=" * 60)
    
    data = request.get_json() or {}
    comment = data.get("comment", "")
    current_user = "arun.wagle@jnj.com"  # Hardcoded for now
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    
    dta_table = f"{catalog}.{gold_schema}.dta"
    workflow_table = f"{catalog}.{gold_schema}.dta_workflow"
    
    try:
        # First verify DTA exists
        check_query = f"SELECT dta_id, dta_number, status, workflow_state FROM {dta_table} WHERE dta_id = '{dta_id}'"
        check_result = client.execute_query(check_query)
        print(f"SUBMIT: DTA check result: {check_result}")
        
        if not check_result:
            print(f"SUBMIT ERROR: DTA {dta_id} not found!")
            return jsonify({"ok": False, "error": f"DTA {dta_id} not found"})
        
        # Update DTA status
        dta_update = f"""
            UPDATE {dta_table}
            SET status = 'PENDING_APPROVAL',
                workflow_state = 'IN_REVIEW',
                last_updated_ts = current_timestamp(),
                last_updated_by_principal = '{current_user}'
            WHERE dta_id = '{dta_id}'
        """
        print(f"SUBMIT: Executing DTA update...")
        client.execute_query(dta_update)
        print(f"SUBMIT: DTA status updated to PENDING_APPROVAL")
        
        # Update workflow
        workflow_update = f"""
            UPDATE {workflow_table}
            SET workflow_status = 'IN_REVIEW',
                initiated_ts = current_timestamp(),
                summary_comment = '{comment.replace("'", "''")}',
                last_updated_ts = current_timestamp()
            WHERE dta_id = '{dta_id}'
        """
        client.execute_query(workflow_update)
        
        # Log activity
        log_workflow_event(
            dta_id=dta_id,
            activity_type="SUBMITTED_FOR_APPROVAL",
            performed_by=current_user,
            comment=comment
        )
        
        return jsonify({"ok": True, "msg": "DTA submitted for approval"})
        
    except Exception as e:
        print(f"Error submitting for approval: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)})

@app.route("/api/approval/approve/<dta_id>", methods=["POST"])
def api_approve(dta_id):
    """Approve a DTA - current user approves their task."""
    from api.dta_api import _get_db_config, _get_sql_client
    from api.activity_log_api import log_workflow_event
    
    data = request.get_json() or {}
    comment = data.get("comment", "")
    current_user = "arun.wagle@jnj.com"  # Hardcoded for now
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    
    approval_table = f"{catalog}.{gold_schema}.dta_approval_task"
    dta_table = f"{catalog}.{gold_schema}.dta"
    workflow_table = f"{catalog}.{gold_schema}.dta_workflow"
    
    try:
        # Update user's approval task
        task_update = f"""
            UPDATE {approval_table}
            SET approval_status = 'APPROVED',
                approval_comment = '{comment.replace("'", "''")}',
                approved_ts = current_timestamp(),
                last_updated_ts = current_timestamp()
            WHERE dta_id = '{dta_id}'
              AND assigned_to_principal = '{current_user}'
              AND approval_status = 'PENDING'
        """
        client.execute_query(task_update)
        
        # Check if all tasks are approved
        check_query = f"""
            SELECT COUNT(*) as pending_count
            FROM {approval_table}
            WHERE dta_id = '{dta_id}'
              AND approval_status = 'PENDING'
        """
        result = client.execute_query(check_query)
        pending = result[0]['pending_count'] if result else 0
        
        all_approved = (pending == 0)
        
        if all_approved:
            # Update DTA and workflow to APPROVED
            dta_update = f"""
                UPDATE {dta_table}
                SET workflow_state = 'APPROVED',
                    last_updated_ts = current_timestamp()
                WHERE dta_id = '{dta_id}'
            """
            client.execute_query(dta_update)
            
            workflow_update = f"""
                UPDATE {workflow_table}
                SET workflow_status = 'APPROVED',
                    closed_ts = current_timestamp(),
                    last_updated_ts = current_timestamp()
                WHERE dta_id = '{dta_id}'
            """
            client.execute_query(workflow_update)
        
        # Log activity
        log_workflow_event(
            dta_id=dta_id,
            activity_type="APPROVED",
            performed_by=current_user,
            comment=comment
        )
        
        return jsonify({
            "ok": True, 
            "msg": "Approval recorded",
            "all_approved": all_approved
        })
        
    except Exception as e:
        print(f"Error approving: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)})

@app.route("/api/approval/reject/<dta_id>", methods=["POST"])
def api_reject(dta_id):
    """Reject a DTA - current user rejects their task."""
    from api.dta_api import _get_db_config, _get_sql_client
    from api.activity_log_api import log_workflow_event
    
    data = request.get_json() or {}
    comment = data.get("comment", "")
    current_user = "arun.wagle@jnj.com"  # Hardcoded for now
    
    if not comment:
        return jsonify({"ok": False, "error": "Comment is required for rejection"})
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    
    approval_table = f"{catalog}.{gold_schema}.dta_approval_task"
    dta_table = f"{catalog}.{gold_schema}.dta"
    workflow_table = f"{catalog}.{gold_schema}.dta_workflow"
    
    try:
        # Update user's approval task
        task_update = f"""
            UPDATE {approval_table}
            SET approval_status = 'REJECTED',
                approval_comment = '{comment.replace("'", "''")}',
                approved_ts = current_timestamp(),
                last_updated_ts = current_timestamp()
            WHERE dta_id = '{dta_id}'
              AND assigned_to_principal = '{current_user}'
              AND approval_status = 'PENDING'
        """
        client.execute_query(task_update)
        
        # Update DTA back to DRAFT
        dta_update = f"""
            UPDATE {dta_table}
            SET status = 'DRAFT',
                workflow_state = 'REJECTED',
                last_updated_ts = current_timestamp()
            WHERE dta_id = '{dta_id}'
        """
        client.execute_query(dta_update)
        
        # Update workflow
        workflow_update = f"""
            UPDATE {workflow_table}
            SET workflow_status = 'REJECTED',
                closed_ts = current_timestamp(),
                last_updated_ts = current_timestamp()
            WHERE dta_id = '{dta_id}'
        """
        client.execute_query(workflow_update)
        
        # Log activity
        log_workflow_event(
            dta_id=dta_id,
            activity_type="REJECTED",
            performed_by=current_user,
            comment=comment
        )
        
        return jsonify({"ok": True, "msg": "DTA rejected and returned to draft"})
        
    except Exception as e:
        print(f"Error rejecting: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/dta/<dta_id>/update-name", methods=["POST"])
def api_update_dta_name(dta_id):
    """Update DTA name and log the change to activity log."""
    try:
        from api.dta_api import _get_db_config, _get_sql_client
        from api.activity_log_api import log_field_update
        
        data = request.json or {}
        new_name = data.get("dta_name", "").strip()
        
        if not new_name:
            return jsonify({"ok": False, "msg": "DTA name cannot be empty"}), 400
        
        config = _get_db_config()
        client = _get_sql_client()
        dta_table = f"{config['catalog']}.{config.get('gold_schema', 'gold_md')}.dta"
        
        # Get current name for activity log
        current_query = f"SELECT dta_name, dta_number FROM {dta_table} WHERE dta_id = '{dta_id}'"
        current_result = client.execute_query(current_query)
        
        if not current_result:
            return jsonify({"ok": False, "msg": "DTA not found"}), 404
        
        old_name = current_result[0].get("dta_name") or ""
        dta_number = current_result[0].get("dta_number") or dta_id
        
        # Skip if name hasn't changed
        if old_name == new_name:
            return jsonify({"ok": True, "msg": "Name unchanged"})
        
        # Update the DTA name
        escaped_name = new_name.replace("'", "''")
        update_query = f"""
            UPDATE {dta_table}
            SET dta_name = '{escaped_name}',
                last_updated_ts = current_timestamp()
            WHERE dta_id = '{dta_id}'
        """
        client.execute_query(update_query)
        
        # Get current user
        user = "system"
        try:
            from databricks.sdk import WorkspaceClient
            w = WorkspaceClient()
            user = w.current_user.me().user_name or "system"
        except:
            pass
        
        # Log the change to activity log
        log_field_update(
            dta_id=dta_id,
            library_type="DTA",
            entity_id=dta_id,
            entity_name=dta_number,
            field_name="dta_name",
            old_value=old_name,
            new_value=new_name,
            performed_by=user
        )
        
        print(f"DTA name updated: {dta_id} - '{old_name}' -> '{new_name}'")
        return jsonify({"ok": True, "msg": "Name updated successfully"})
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "msg": str(e)}), 500


@app.route("/composer")
def composer():
    """DTA Builder Home - shows user's draft DTAs and Create New DTA button"""
    from api.dta_api import get_user_drafts
    
    # Fetch user's draft DTAs
    user_drafts = []
    try:
        user_drafts = get_user_drafts(limit=50)
        print(f"DTA_BUILDER: Found {len(user_drafts)} user drafts")
    except Exception as e:
        print(f"DTA_BUILDER: Error fetching drafts: {e}")
        user_drafts = []
    
    return render_template("dta_builder.html", user_drafts=user_drafts)


@app.route("/dta/search")
def dta_search():
    """DTA Search - search existing DTAs and templates to clone"""
    import traceback
    from api.dta_api import search_existing_dtas, get_all_versions, format_library_entities_for_selection, get_user_drafts, get_dta_templates
    from api.study_api import get_studies, get_vendors, get_data_streams
    
    q = (request.args.get("q") or "").strip()
    action = request.args.get("action", "")
    
    # Get filter parameters for dropdown search
    filter_study_id = request.args.get("filter_study_id", "").strip()
    filter_vendor = request.args.get("filter_vendor", "").strip()
    filter_data_stream = request.args.get("filter_data_stream", "").strip()
    
    # Get pre-selected study_id (from Study Details page)
    preselected_study_id = request.args.get("study_id", "").strip()
    
    # Get pre-selected library versions from URL params (from dashboard)
    selected_libraries = {}
    code_mapping = {
        'lib_tv': 'TV',
        'lib_cl': 'CL',
        'lib_tc': 'TC',
        'lib_oa': 'OA',
        'lib_vt': 'VT',
        'lib_dip': 'DIP'
    }
    
    for param, code in code_mapping.items():
        value = request.args.get(param)
        if value and value.lower() != 'none':
            selected_libraries[code] = value
    
    # Format selected libraries for display
    library_display = []
    if selected_libraries:
        entity_names = {
            'TV': ('📊', 'Transfer Variables'),
            'CL': ('📋', 'Codelists'),
            'TC': ('🧪', 'Test Concepts'),
            'OA': ('📝', 'Operational Agreements'),
            'VT': ('📅', 'Visits & Timepoints'),
            'DIP': ('⚙️', 'Data Ingestion Params')
        }
        for code, version in selected_libraries.items():
            icon, name = entity_names.get(code, ('📁', code))
            library_display.append({
                'code': code,
                'name': name,
                'icon': icon,
                'version': version
            })
    
    # Search results
    results = []
    default_templates = []  # Generic templates to show by default
    use_real_search = True  # Flag to use real database search
    
    # Check if we have any search criteria (text query OR dropdown filters)
    has_filter_search = filter_study_id or filter_vendor or filter_data_stream
    has_text_search = bool(q)
    
    # Fetch default templates (DTA_GENERIC_TEMPLATE) to show when no search
    try:
        from api.dta_api import get_dta_templates
        default_templates = get_dta_templates(version_type='DTA_GENERIC_TEMPLATE', limit=10)
        print(f"COMPOSER: Found {len(default_templates)} generic templates for default view")
    except Exception as e:
        print(f"COMPOSER: Error fetching generic templates: {e}")
        default_templates = []
    
    if has_text_search or has_filter_search:
        if use_real_search:
            try:
                # Use real DTA search from database with optional filters
                results = search_existing_dtas(
                    query=q if has_text_search else None, 
                    limit=50,
                    trial_id=filter_study_id if filter_study_id else None,
                    provider=filter_vendor if filter_vendor else None,
                    data_stream=filter_data_stream if filter_data_stream else None
                )
                print(f"COMPOSER: Found {len(results)} DTAs for query='{q}', study={filter_study_id}, vendor={filter_vendor}, stream={filter_data_stream}")
            except Exception as e:
                print(f"COMPOSER: Search error: {e}")
                traceback.print_exc()
                flash(f"Search error: {str(e)}", "error")
        else:
            # Fallback to mock data
            filters = parse_search_query(q)
            api_result = api.search_workspaces("")
            
            if api_result["success"]:
                all_results = api_result["data"]
                
                def matches(r):
                    if filters['trial'] or filters['vendor'] or filters['stream']:
                        is_token_search = (filters['trial'] and filters['vendor'] and filters['stream'])
                        trial_match = not filters['trial'] or any(f in r["trial"].upper() or r["trial"].upper() in f for f in filters['trial'])
                        vendor_match = not filters['vendor'] or any(f in r["vendor"].upper() or r["vendor"].upper() in f for f in filters['vendor'])
                        stream_match = not filters['stream'] or any(f.upper() in r["stream"].upper() or r["stream"].upper() in f.upper() for f in filters['stream'])
                        
                        if is_token_search:
                            return trial_match or vendor_match or stream_match
                        else:
                            return trial_match and vendor_match and stream_match
                    else:
                        q_lower = q.lower()
                        return (q_lower in r["trial"].lower() or 
                               q_lower in r["vendor"].lower() or 
                               q_lower in r["stream"].lower())
                
                results = [r for r in all_results if matches(r)]
    
    # Fetch reference data for dropdown filters using existing API functions
    reference_data = {"studies": [], "vendors": [], "data_streams": []}
    try:
        # Use existing study_api functions
        studies = get_studies(limit=100)
        reference_data["studies"] = [
            {"id": s.get("study_id", ""), "name": s.get("study_title", "")}
            for s in studies
        ]
        print(f"COMPOSER: Found {len(reference_data['studies'])} studies")
        
        vendors = get_vendors()
        reference_data["vendors"] = [
            {"id": v.get("vendor_id", ""), "name": v.get("vendor_name", "")}
            for v in vendors
        ]
        print(f"COMPOSER: Found {len(reference_data['vendors'])} vendors")
        
        data_streams = get_data_streams()
        reference_data["data_streams"] = [
            {"id": ds.get("data_stream_id", ""), "name": ds.get("data_stream_name", "")}
            for ds in data_streams
        ]
        print(f"COMPOSER: Found {len(reference_data['data_streams'])} data streams")
    except Exception as e:
        print(f"COMPOSER: Error fetching reference data: {e}")
    
    # Fetch user's draft DTAs
    try:
        user_drafts = get_user_drafts(limit=50)
        print(f"COMPOSER: Found {len(user_drafts)} user drafts")
    except Exception as e:
        print(f"COMPOSER: Error fetching drafts: {e}")
        user_drafts = []
    
    return render_template("dta_search.html", 
                          results=results, 
                          default_templates=default_templates,
                          q=q,
                          action=action,
                          selected_libraries=selected_libraries,
                          library_display=library_display,
                          use_real_search=use_real_search,
                          user_drafts=user_drafts,
                          reference_data=reference_data,
                          filter_study_id=filter_study_id,
                          filter_vendor=filter_vendor,
                          filter_data_stream=filter_data_stream,
                          preselected_study_id=preselected_study_id)

@app.route("/edit-draft/<dta_id>")
def edit_draft(dta_id):
    """
    Edit an existing draft DTA - loads data from Silver table.
    
    This function:
    1. Fetches DTA metadata from database
    2. Fetches transfer variables from Silver table using dta_id
    3. Populates workspace with real data and redirects
    """
    from api.dta_api import (_get_db_config, _get_sql_client, get_test_concepts_for_dta, transform_test_concepts_to_workspace,
                              get_oa_for_dta, get_codelists_for_dta, transform_codelists_to_workspace,
                              get_di_params_for_dta, transform_di_params_to_workspace)
    from api.data import WORKSPACES, EMPTY_ENTITIES, MOCK_RESULTS
    
    try:
        config = _get_db_config()
        client = _get_sql_client()
        
        catalog = config['catalog']
        gold_schema = config['gold_schema']
        silver_schema = config['silver_schema']
        dta_table = f"{catalog}.{gold_schema}.dta"
        silver_table = f"{catalog}.{silver_schema}.md_dta_transfer_variables_draft"
        
        # ========================================
        # Step 1: Get DTA metadata
        # ========================================
        print(f"EDIT-DRAFT: Loading draft DTA {dta_id}...")
        
        dta_query = f"""
            SELECT dta_id, dta_number, dta_name, trial_id, data_stream_type, data_provider_name,
                   status, workflow_state, version, current_draft_version, notes,
                   last_updated_ts
            FROM {dta_table}
            WHERE dta_id = '{dta_id}'
        """
        
        dta_results = client.execute_query(dta_query, raise_on_error=True)
        
        if not dta_results:
            flash(f"Draft DTA {dta_id} not found", "error")
            return redirect(url_for("composer"))
        
        dta = dta_results[0]
        dta_number = dta.get("dta_number", "")
        dta_name = dta.get("dta_name", "")
        trial_id = dta.get("trial_id", "UNKNOWN")
        provider = dta.get("data_provider_name", "UNKNOWN")
        stream = dta.get("data_stream_type", "UNKNOWN")
        version = dta.get("current_draft_version") or dta.get("version", "")
        
        print(f"EDIT-DRAFT: Found DTA {dta_number}, version {version}")
        
        # ========================================
        # Step 2: Fetch transfer variables from Silver table
        # ========================================
        print(f"EDIT-DRAFT: Fetching transfer variables from Silver table...")
        
        tv_query = f"""
            SELECT 
                transfer_variable_id,
                transfer_variable_name,
                transfer_variable_label,
                format,
                anticipated_max_length,
                populate_for_all_records,
                codelist_values,
                example_values,
                variable_description,
                transfer_file_key,
                transfer_variable_order,
                status,
                vendor_comment,
                domain_info
            FROM {silver_table}
            WHERE dta_id = '{dta_id}'
            ORDER BY COALESCE(domain_info, 'ZZZ'), transfer_variable_order, transfer_variable_name
        """
        
        tv_results = client.execute_query(tv_query, raise_on_error=True)
        print(f"EDIT-DRAFT: Found {len(tv_results) if tv_results else 0} transfer variables")
        
        # Transform to workspace format
        real_tv = []
        if tv_results:
            for i, row in enumerate(tv_results, 1):
                try:
                    length_val = row.get("anticipated_max_length")
                    length = int(length_val) if length_val else 50
                except (ValueError, TypeError):
                    length = 50
                
                file_order = row.get("transfer_variable_order") or i
                try:
                    file_order = int(file_order)
                except:
                    file_order = i
                
                # Handle boolean fields - SQL API returns strings
                required_val = row.get("populate_for_all_records")
                is_required = str(required_val).lower() == "true" if required_val else False
                
                is_key_val = row.get("transfer_file_key")
                is_key = str(is_key_val).lower() == "true" if is_key_val else False
                
                # Handle codelist_values array
                codelist_val = row.get("codelist_values")
                if codelist_val:
                    if isinstance(codelist_val, list):
                        codelist_str = ", ".join(str(v) for v in codelist_val if v)
                    else:
                        codelist_str = str(codelist_val)
                else:
                    codelist_str = ""
                
                real_tv.append({
                    "_transfer_variable_id": str(row.get("transfer_variable_id") or ""),
                    "LABEL": str(row.get("transfer_variable_name") or row.get("transfer_variable_label") or ""),
                    "FILE_ORDER": file_order,
                    "FORMAT": str(row.get("format") or "STRING"),
                    "LENGTH": length,
                    "REQUIRED": is_required,
                    "TEST_CONCEPTS": codelist_str,
                    "EXAMPLE_VALUES": str(row.get("example_values") or ""),
                    "DESCRIPTION": str(row.get("variable_description") or ""),
                    "IS_KEY": is_key,
                    "ROW_STATUS": str(row.get("status") or "COMPLETED"),
                    "VENDOR_COMMENT": str(row.get("vendor_comment") or ""),
                    "DOMAIN_INFO": str(row.get("domain_info") or "")
                })
        
        if not real_tv:
            real_tv = list(EMPTY_ENTITIES["TV"])
            print(f"EDIT-DRAFT: No transfer variables found, using empty entities")
        
        # ========================================
        # Step 2.5: Get Test Concepts from Silver
        # ========================================
        print(f"EDIT-DRAFT: Loading test concepts...")
        tc_results = get_test_concepts_for_dta(client, config, dta_id)
        real_tc = transform_test_concepts_to_workspace(tc_results)
        print(f"EDIT-DRAFT: Found {len(real_tc)} test concepts")
        
        if not real_tc:
            real_tc = list(EMPTY_ENTITIES["TC"])
            print(f"EDIT-DRAFT: No test concepts found, using empty entities")
        
        # ========================================
        # Step 2.6: Get Operational Agreement data from Silver (unified API)
        # ========================================
        print(f"EDIT-DRAFT: Loading OA data...")
        oa_data = get_oa_for_dta(client, config, dta_id, is_draft=True)  # Always draft for edit
        
        oa_parent = oa_data.get("oa_parent", [])
        oa_attr = oa_data.get("oa_attr", [])
        oa_options = oa_data.get("oa_options", [])
        oa_other = oa_data.get("oa_other", [])
        
        # Note: No default OA data - if no OA exists, show empty section
        # User must upload OA document to get actual data
        
        print(f"EDIT-DRAFT: OA (4 tables): oa_id={oa_data.get('oa_id')}, parent={len(oa_parent)}, attrs={len(oa_attr)}, options={len(oa_options)}, other={len(oa_other)}")
        
        # ========================================
        # Step 2.7: Get Codelists from Silver
        # ========================================
        print(f"EDIT-DRAFT: Loading codelists...")
        cl_results = get_codelists_for_dta(client, config, dta_id, dta_status='DRAFT')
        real_cl = transform_codelists_to_workspace(cl_results)
        print(f"EDIT-DRAFT: Found {len(real_cl)} codelist entries")
        
        if not real_cl:
            real_cl = list(EMPTY_ENTITIES["CL"])
            print(f"EDIT-DRAFT: No codelists found, using empty entities")
        
        # ========================================
        # Step 3: Create workspace with data
        # ========================================
        workspace_key = f"{trial_id}|{provider}|{stream}|{dta_id}"
        
        # Initialize CL state
        cl_state = {}
        for item in real_cl:
            ref = item["ref"]
            if ref not in cl_state:
                cl_state[ref] = []
            cl_state[ref].append({"editable": False, "approved": False, "comments": []})
        
        # Extract transfer file keys
        transfer_file_keys = [tv["LABEL"] for tv in real_tv if tv.get("IS_KEY")]
        
        # Metadata fields
        metadata_fields = [
            {"field": "trial_id", "label": "Trial ID", "value": trial_id, "readonly": True},
            {"field": "vendor", "label": "Vendor", "value": provider, "readonly": True},
            {"field": "data_stream", "label": "Data Stream", "value": stream, "readonly": True},
            {"field": "dta_number", "label": "DTA Number", "value": dta_number, "readonly": True},
            {"field": "version", "label": "Version", "value": version, "readonly": True},
            {"field": "status", "label": "Status", "value": dta.get("status", "DRAFT"), "readonly": True},
            {"field": "notes", "label": "Notes", "value": dta.get("notes", "") or "", "readonly": False},
        ]
        
        # DIP fields - fetch from database
        print(f"EDIT-DRAFT: Fetching Data Ingestion Parameters...")
        dip_result = get_di_params_for_dta(client, config, dta_id, is_draft=True)
        dip_params = dip_result.get('params', [])
        dip_fields = transform_di_params_to_workspace(dip_params)
        print(f"EDIT-DRAFT: Found {len(dip_fields)} DI params")
        
        # Parse version info from database
        draft_display = version if version else f"DRAFT-{dta_id[:8]}"
        
        # Extract major version from version if present (e.g., "v1.0" -> 1)
        base_major_version = 0
        if version:
            import re
            major_match = re.search(r'v(\d+)', version)
            if major_match:
                base_major_version = int(major_match.group(1))
        
        # Format last_updated_ts for display
        last_updated_ts = dta.get("last_updated_ts")
        if last_updated_ts:
            try:
                from datetime import datetime
                if isinstance(last_updated_ts, str):
                    last_updated_ts = datetime.fromisoformat(last_updated_ts.replace('Z', '+00:00'))
                last_updated_display = last_updated_ts.strftime("%b %d, %Y at %I:%M %p")
            except:
                last_updated_display = str(last_updated_ts)
        else:
            last_updated_display = None
        
        # Create workspace
        WORKSPACES[workspace_key] = {
            "key": workspace_key,
            "dta_id": dta_id,
            "dta_number": dta_number,
            "dta_name": dta_name,  # User-friendly name for UI display
            "version": version,
            "draft_id": draft_display,
            "base_major": base_major_version,
            "editor_tab": "META",
            "status": dta.get("status", "Draft"),
            "is_mock_data": False,  # Real data from Silver
            "has_pending_changes": False,  # Track unsaved changes
            "last_updated_ts": last_updated_display,  # For display in header
            "entities": {
                "TC": real_tc,
                "TV": real_tv,
                "CL": real_cl,
                "VT": list(EMPTY_ENTITIES["VT"])
            },
            "metadata": metadata_fields,
            "metadata_state": [{"editable": False, "approved": False, "comments": []} for _ in metadata_fields],
            "dip": dip_fields,
            "dip_state": [{"editable": False, "approved": False, "comments": []} for _ in dip_fields],
            "tc_state": [
                {
                    "editable": False, 
                    "approved": False, 
                    "comments": [{"user": "vendor", "ts": "saved", "text": tc.get("_vendor_comment")}] if tc.get("_vendor_comment") else []
                } for tc in real_tc
            ],
            "tv_state": [
                {
                    "editable": False, 
                    "approved": False, 
                    "comments": [{"user": "vendor", "ts": "saved", "text": tv.get("VENDOR_COMMENT")}] if tv.get("VENDOR_COMMENT") else []
                } for tv in real_tv
            ],
            "cl_state": cl_state,
            "transfer_file_keys": transfer_file_keys,
            "comments": [],
            # Operational Agreement data (4 tables)
            "oa_parent": oa_parent,
            "oa_parent_state": [{"editable": False, "approved": False, "comments": []} for _ in oa_parent],
            "oa_attr": oa_attr,
            "oa_attr_state": [{"editable": False, "approved": False, "comments": []} for _ in oa_attr],
            "oa_options": oa_options,
            "oa_options_state": [{"editable": False, "approved": False, "comments": []} for _ in oa_options],
            "oa_other": oa_other,
            "oa_other_state": [{"editable": False, "approved": False, "comments": []} for _ in oa_other],
        }
        
        # Add to MOCK_RESULTS for workspace route compatibility
        mock_result = {
            "key": workspace_key,
            "dta_id": dta_id,
            "trial": trial_id,
            "vendor": provider,
            "stream": stream,
            "major": 0,
            "updated": datetime.now().strftime("%Y-%m-%d"),
            "owners": [],
            "badges": ["Transfer Variables"],
            "status": "Draft"
        }
        
        existing_idx = next((i for i, r in enumerate(MOCK_RESULTS) if r.get("key") == workspace_key), None)
        if existing_idx is not None:
            MOCK_RESULTS[existing_idx] = mock_result
        else:
            MOCK_RESULTS.insert(0, mock_result)
        
        # Preserve the tab query parameter if provided, default to META
        tab = request.args.get("tab", "META")
        print(f"EDIT-DRAFT: Successfully loaded draft, redirecting to workspace (tab={tab})")
        return redirect(url_for("workspace", key=workspace_key, tab=tab))
        
    except Exception as e:
        print(f"EDIT-DRAFT: Error loading draft: {e}")
        import traceback
        traceback.print_exc()
        flash(f"Error loading draft: {str(e)}", "error")
        return redirect(url_for("composer"))


@app.route("/dta/configure")
def configure_dta():
    """
    Configure DTA page - Step 2 of the unified DTA creation flow.
    
    This page allows users to:
    1. Select a study (from dropdown)
    2. Enter DTA name
    3. Select vendor and data stream
    4. Assign approvers
    
    Then proceed to create a DTA draft and open the workspace.
    """
    from api.study_api import get_studies, get_vendors, get_data_streams
    from api.dta_api import _get_db_config, _get_sql_client
    
    # Get parameters from URL
    source_id = request.args.get("source_id", "")
    source_type = request.args.get("source_type", "")
    source_key = request.args.get("source_key", "")
    preselected_study_id = request.args.get("study_id", "")
    
    # Get library versions if passed
    selected_libraries = {}
    code_mapping = {
        'lib_tv': 'TV',
        'lib_cl': 'CL',
        'lib_tc': 'TC',
        'lib_oa': 'OA',
        'lib_vt': 'VT',
        'lib_dip': 'DIP'
    }
    
    for param, code in code_mapping.items():
        value = request.args.get(param)
        if value and value.lower() != 'none':
            selected_libraries[code] = value
    
    library_display = []
    if selected_libraries:
        entity_names = {
            'TV': ('📊', 'Transfer Variables'),
            'CL': ('📋', 'Codelists'),
            'TC': ('🧪', 'Test Concepts'),
            'OA': ('📝', 'Operational Agreements'),
            'VT': ('📅', 'Visits & Timepoints'),
            'DIP': ('⚙️', 'Data Ingestion Params')
        }
        # Disabled library types (not yet integrated with real data)
        disabled_library_types = {'CL', 'VT', 'DIP'}
        
        for code, version in selected_libraries.items():
            # Skip disabled library types
            if code in disabled_library_types:
                continue
            icon, name = entity_names.get(code, ('📁', code))
            library_display.append({
                'code': code,
                'name': name,
                'icon': icon,
                'version': version
            })
    
    # Fetch source DTA details if source_id is provided
    source_dta = None
    default_dta_name = ""
    preselected_vendor_id = ""
    preselected_data_stream_id = ""
    
    if source_id:
        try:
            config = _get_db_config()
            client = _get_sql_client()
            
            # Try to get DTA from gold table first
            dta_query = f"""
                SELECT dta_id, dta_number, dta_name, trial_id, data_stream_type, 
                       data_provider_name, version, workflow_state
                FROM {config['catalog']}.{config['gold_schema']}.dta
                WHERE dta_id = '{source_id}'
            """
            result = client.execute_query(dta_query)
            if result:
                source_dta = result[0]
                default_dta_name = f"Copy of {source_dta.get('dta_name', source_dta.get('dta_number', ''))}"
                preselected_study_id = preselected_study_id or source_dta.get('trial_id', '')
                
                # Pre-select vendor from source DTA
                source_vendor = source_dta.get('data_provider_name', '')
                if source_vendor:
                    # Try to find matching vendor_id
                    vendor_query = f"""
                        SELECT vendor_id FROM {config['catalog']}.{config['gold_schema']}.md_vendor
                        WHERE LOWER(vendor_name) = LOWER('{source_vendor}')
                        OR LOWER(vendor_name) LIKE LOWER('%{source_vendor}%')
                        LIMIT 1
                    """
                    vendor_result = client.execute_query(vendor_query)
                    if vendor_result:
                        preselected_vendor_id = vendor_result[0].get('vendor_id', '')
                
                # Pre-select data stream from source DTA
                source_stream = source_dta.get('data_stream_type', '')
                if source_stream:
                    # Try to find matching data_stream_id
                    stream_query = f"""
                        SELECT data_stream_id FROM {config['catalog']}.{config['gold_schema']}.md_data_stream
                        WHERE LOWER(data_stream_name) = LOWER('{source_stream}')
                        OR LOWER(data_stream_name) LIKE LOWER('%{source_stream}%')
                        LIMIT 1
                    """
                    stream_result = client.execute_query(stream_query)
                    if stream_result:
                        preselected_data_stream_id = stream_result[0].get('data_stream_id', '')
            else:
                # Try version registry for templates
                registry_query = f"""
                    SELECT version_id, version, version_type, dta_id, description
                    FROM {config['catalog']}.{config['gold_schema']}.md_version_registry
                    WHERE version_id = '{source_id}' OR version = '{source_id}'
                    LIMIT 1
                """
                reg_result = client.execute_query(registry_query)
                if reg_result:
                    source_dta = reg_result[0]
                    source_type = source_dta.get('version_type', source_type)
        except Exception as e:
            print(f"CONFIGURE_DTA: Error fetching source: {e}")
    
    # Fetch reference data for dropdowns
    studies = []
    vendors = []
    data_streams = []
    
    try:
        studies = get_studies(limit=100)
        vendors = get_vendors()
        data_streams = get_data_streams()
    except Exception as e:
        print(f"CONFIGURE_DTA: Error fetching reference data: {e}")
    
    # Get current user info
    current_user_email = request.headers.get("X-Forwarded-Email", os.environ.get("USER", "unknown@jnj.com"))
    current_user_name = request.headers.get("X-Forwarded-User", current_user_email.split("@")[0])
    
    return render_template("configure_dta.html",
                          source_id=source_id,
                          source_type=source_type,
                          source_dta=source_dta,
                          default_dta_name=default_dta_name,
                          preselected_study_id=preselected_study_id,
                          preselected_vendor_id=preselected_vendor_id,
                          preselected_data_stream_id=preselected_data_stream_id,
                          studies=studies,
                          vendors=vendors,
                          data_streams=data_streams,
                          library_display=library_display,
                          current_user_email=current_user_email,
                          current_user_name=current_user_name)


@app.route("/dta/create-from-config", methods=["POST"])
def create_dta_from_config():
    """
    Create a DTA draft from the configuration form.
    
    This is the submission handler for the configure_dta page.
    It redirects to create_draft_dta with form values as query parameters.
    """
    from api.dta_api import _get_db_config, _get_sql_client
    
    try:
        # Get form data
        source_id = request.form.get("source_id", "")
        source_type = request.form.get("source_type", "")
        study_id = request.form.get("study_id", "")
        dta_name = request.form.get("dta_name", "")
        vendor_id = request.form.get("vendor_id", "")
        data_stream_id = request.form.get("data_stream_id", "")
        jnj_dae_email = request.form.get("jnj_dae_email", "")
        jnj_dae_name = request.form.get("jnj_dae_name", "")
        
        print(f"=" * 60)
        print(f"CREATE_DTA_FROM_CONFIG: Redirecting to create_draft_dta")
        print(f"  Study: {study_id}")
        print(f"  Name: {dta_name}")
        print(f"  Vendor ID: {vendor_id}")
        print(f"  Data Stream ID: {data_stream_id}")
        print(f"  Source ID: {source_id}")
        print(f"  Source Type: {source_type}")
        print(f"  JNJ DAE Email: {jnj_dae_email}")
        print(f"=" * 60)
        
        config = _get_db_config()
        client = _get_sql_client()
        
        # Get vendor and data stream names from IDs
        vendor_name = ""
        data_stream_name = ""
        
        if vendor_id:
            vendor_query = f"""
                SELECT vendor_name FROM {config['catalog']}.{config['gold_schema']}.md_vendor
                WHERE vendor_id = '{vendor_id}' LIMIT 1
            """
            result = client.execute_query(vendor_query)
            if result:
                vendor_name = result[0].get('vendor_name', vendor_id)
        
        if data_stream_id:
            stream_query = f"""
                SELECT data_stream_name FROM {config['catalog']}.{config['gold_schema']}.md_data_stream
                WHERE data_stream_id = '{data_stream_id}' LIMIT 1
            """
            result = client.execute_query(stream_query)
            if result:
                data_stream_name = result[0].get('data_stream_name', data_stream_id)
        
        # Validate source DTA exists
        if not source_id:
            flash("No source DTA or template selected. Please select a DTA to clone from.", "error")
            return redirect(url_for("dta_search"))
        
        # Redirect to create_draft_dta with override values as query params
        # The create_draft_dta function handles all the creation logic
        # Include approver info so it can be assigned after DTA creation
        return redirect(url_for(
            "create_draft_dta",
            source_dta_id=source_id,
            study_id=study_id,
            vendor_name=vendor_name or vendor_id,
            data_stream_type=data_stream_name or data_stream_id,
            dta_name=dta_name,
            jnj_dae_email=jnj_dae_email,
            jnj_dae_name=jnj_dae_name
        ))
        
    except Exception as e:
        print(f"CREATE_DTA_FROM_CONFIG: Error: {e}")
        import traceback
        traceback.print_exc()
        flash(f"Error creating DTA: {str(e)}", "error")
        return redirect(url_for("dta_search"))


@app.route("/dta/create-draft/<source_dta_id>")
def create_draft_dta(source_dta_id):
    """
    Create a new DTA draft from a source DTA/template.
    
    This function:
    1. Fetches source DTA metadata from database
    2. Creates a new DTA draft using create_dta_complete() (with record copying)
    3. Assigns approvers to the DTA workflow tasks
    4. Uses override values (study, vendor, stream) from query params if provided
    5. Fetches real transfer variables from the new draft's library version
    6. Populates workspace with real data and redirects
    
    Query Parameters (override source DTA values):
    - study_id: Trial/Study ID to use
    - vendor_name: Vendor/Provider name to use
    - data_stream_type: Data stream type to use
    - dta_name: Custom DTA name
    - jnj_dae_email: Email for JNJ DAE approver
    - jnj_dae_name: Name for JNJ DAE approver
    """
    from api.dta_api import (_get_db_config, _get_sql_client, create_dta_complete, 
                              get_test_concepts_for_dta, transform_test_concepts_to_workspace,
                              get_oa_for_dta, get_codelists_for_dta, transform_codelists_to_workspace,
                              get_di_params_for_dta, transform_di_params_to_workspace)
    from api.data import WORKSPACES, EMPTY_ENTITIES, MOCK_RESULTS
    
    # Get override values from query params (from Configure DTA form)
    override_study_id = request.args.get("study_id", "").strip()
    override_vendor = request.args.get("vendor_name", "").strip()
    override_stream = request.args.get("data_stream_type", "").strip()
    override_dta_name = request.args.get("dta_name", "").strip()
    
    # Get approver info from query params (from Configure DTA form)
    jnj_dae_email = request.args.get("jnj_dae_email", "").strip()
    jnj_dae_name = request.args.get("jnj_dae_name", "").strip()
    
    try:
        config = _get_db_config()
        client = _get_sql_client()
        
        catalog = config['catalog']
        gold_schema = config['gold_schema']
        dta_table = f"{catalog}.{gold_schema}.dta"
        # Note: Drafts are stored in Silver table, not Gold library table
        
        print(f"=" * 60)
        print(f"CREATE-DRAFT-DTA: Starting creation from source DTA {source_dta_id}")
        print(f"  Overrides: study={override_study_id}, vendor={override_vendor}, stream={override_stream}")
        print(f"=" * 60)
        
        # ========================================
        # Step 1: Fetch source DTA metadata
        # ========================================
        source_query = f"""
            SELECT 
                dta_id, dta_number, trial_id, data_stream_type, data_provider_name,
                version, workflow_state, status, notes
            FROM {dta_table}
            WHERE dta_id = '{source_dta_id}'
        """
        
        source_results = client.execute_query(source_query)
        
        if not source_results:
            flash(f"Source DTA {source_dta_id} not found", "error")
            return redirect(url_for("composer"))
        
        source_dta = source_results[0]
        print(f"CREATE-DRAFT-DTA: Found source DTA {source_dta.get('dta_number')}")
        
        # Use override values if provided, otherwise use source values
        trial_id = override_study_id or source_dta.get("trial_id", "UNKNOWN")
        provider = override_vendor or source_dta.get("data_provider_name", "UNKNOWN")
        stream = override_stream or source_dta.get("data_stream_type", "UNKNOWN")
        source_version = source_dta.get("version")
        
        print(f"CREATE-DRAFT-DTA: Final values: trial={trial_id}, vendor={provider}, stream={stream}")
        
        # ========================================
        # Step 2: Create NEW DTA draft in database
        # ========================================
        print(f"CREATE-DRAFT-DTA: Creating new DTA draft...")
        
        # Build notes based on whether we're using override values
        if override_study_id or override_vendor or override_stream:
            notes = f"Created from {source_dta.get('dta_number', source_dta_id)} with custom configuration"
        else:
            notes = f"Cloned from {source_dta.get('dta_number', source_dta_id)}"
        
        new_dta = create_dta_complete(
            trial_id=trial_id,
            data_stream_type=stream,
            data_provider_name=provider,
            created_by='ui_user@jnj.com',
            source_dta_id=source_dta_id,  # This triggers record copying!
            notes=notes
        )
        
        new_dta_id = new_dta['dta_id']
        new_dta_number = new_dta['dta_number']
        new_version = new_dta['version']
        
        print(f"CREATE-DRAFT-DTA: Created {new_dta_number} with version {new_version}")
        
        # ========================================
        # Step 2b: Assign approvers to workflow tasks
        # ========================================
        if jnj_dae_email:
            approval_table = f"{catalog}.{gold_schema}.dta_approval_task"
            print(f"CREATE-DRAFT-DTA: Assigning JNJ DAE approver: {jnj_dae_email}")
            
            # Update JNJ_DAE task
            jnj_update = f"""
                UPDATE {approval_table}
                SET assigned_to_principal = '{jnj_dae_email}',
                    last_updated_ts = current_timestamp()
                WHERE dta_id = '{new_dta_id}'
                  AND approver_role = 'JNJ_DAE'
            """
            client.execute_query(jnj_update)
            print(f"  ✓ JNJ DAE approver assigned: {jnj_dae_email}")
        else:
            print(f"CREATE-DRAFT-DTA: No JNJ DAE email provided, skipping approver assignment")
        
        # ========================================
        # Step 3: Fetch REAL transfer variables from SILVER
        # ========================================
        # Drafts are stored in Silver table (md_dta_transfer_variables_draft)
        silver_table = f"{catalog}.silver_md.md_dta_transfer_variables_draft"
        
        print(f"CREATE-DRAFT-DTA: Fetching real transfer variables from Silver table...")
        print(f"  Table: {silver_table}")
        print(f"  DTA ID: {new_dta_id}")
        print(f"  Version Tag: {new_version}")
        
        # Silver table column names (from nb_tsdta_transfer_variables_processor.ipynb):
        # transfer_variable_id, parent_document_id, dta_id, trial_id, 
        # data_stream_type, data_provider_name, transfer_variable_name,
        # codelist_values (ARRAY), transfer_variable_label, variable_description,
        # transfer_variable_order, format, anticipated_max_length,
        # populate_for_all_records, transfer_file_key, example_values,
        # definition_hash, notes, status,
        # version, version_status, is_current_draft
        tv_query = f"""
            SELECT 
                transfer_variable_id,
                transfer_variable_name,
                transfer_variable_label,
                format,
                anticipated_max_length,
                populate_for_all_records,
                codelist_values,
                example_values,
                variable_description,
                transfer_file_key,
                status,
                transfer_variable_order,
                domain_info
            FROM {silver_table}
            WHERE dta_id = '{new_dta_id}' AND version = '{new_version}'
            ORDER BY COALESCE(domain_info, 'ZZZ'), transfer_variable_order, transfer_variable_name
        """
        
        print(f"CREATE-DRAFT-DTA: Executing query...")
        print(f"CREATE-DRAFT-DTA: Query: {tv_query[:200]}...")
        tv_results = client.execute_query(tv_query)
        print(f"CREATE-DRAFT-DTA: Found {len(tv_results) if tv_results else 0} transfer variables")
        
        # Transform to workspace format
        if tv_results and len(tv_results) > 0:
            real_tv = []
            for i, row in enumerate(tv_results, 1):
                # Safely convert anticipated_max_length to int (SQL may return strings)
                try:
                    length_val = row.get("anticipated_max_length")
                    length = int(length_val) if length_val else 50
                except (ValueError, TypeError):
                    length = 50
                
                # Safely get transfer_variable_order (may be int or string from SQL)
                try:
                    order_val = row.get("transfer_variable_order")
                    file_order = int(order_val) if order_val else i
                except (ValueError, TypeError):
                    file_order = i
                
                # Handle codelist_values which is an ARRAY in Silver table
                codelist_val = row.get("codelist_values")
                if codelist_val:
                    if isinstance(codelist_val, list):
                        codelist_str = ", ".join(str(v) for v in codelist_val if v)
                    else:
                        codelist_str = str(codelist_val)
                else:
                    codelist_str = ""
                
                # Handle boolean fields - SQL API returns strings "true"/"false"
                required_val = row.get("populate_for_all_records")
                is_required = str(required_val).lower() == "true" if required_val else False
                
                is_key_val = row.get("transfer_file_key")
                is_key = str(is_key_val).lower() == "true" if is_key_val else False
                
                real_tv.append({
                    "_transfer_variable_id": str(row.get("transfer_variable_id") or ""),
                    "LABEL": str(row.get("transfer_variable_name") or row.get("transfer_variable_label") or ""),
                    "FILE_ORDER": file_order,
                    "FORMAT": str(row.get("format") or "STRING"),
                    "LENGTH": length,
                    "REQUIRED": is_required,
                    "TEST_CONCEPTS": codelist_str,
                    "EXAMPLE_VALUES": str(row.get("example_values") or ""),
                    "DESCRIPTION": str(row.get("variable_description") or ""),
                    "IS_KEY": is_key,
                    "ROW_STATUS": str(row.get("status") or "COMPLETED"),
                    "DOMAIN_INFO": str(row.get("domain_info") or "")
                })
        else:
            # Fallback to empty if no records (shouldn't happen if source has data)
            real_tv = list(EMPTY_ENTITIES["TV"])
            print(f"CREATE-DRAFT-DTA: Using fallback empty TV entities")
        
        # ========================================
        # Step 4: Create workspace with REAL data
        # ========================================
        # Use new DTA ID in workspace key to ensure uniqueness
        workspace_key = f"{trial_id}|{provider}|{stream}|{new_dta_id}"
        
        # Initialize metadata fields with real DTA data
        metadata_fields = [
            {"field": "trial_id", "label": "Trial ID", "value": trial_id, "readonly": True},
            {"field": "vendor_id", "label": "Vendor ID / Provider", "value": provider, "readonly": True},
            {"field": "data_stream", "label": "Data Stream", "value": stream, "readonly": True},
            {"field": "dta_number", "label": "DTA Number", "value": new_dta_number, "readonly": True},
            {"field": "version", "label": "Version", "value": new_version, "readonly": True},
            {"field": "source_dta", "label": "Based On", "value": source_dta.get("dta_number", source_dta_id), "readonly": True},
            {"field": "title", "label": "DTA Title", "value": override_dta_name or f"New DTA from {source_dta.get('dta_number', source_dta_id)}", "readonly": False},
            {"field": "description", "label": "Description", "value": source_dta.get("notes") or "", "readonly": False},
            {"field": "protocol_version", "label": "Protocol Version", "value": "", "readonly": False},
            {"field": "vendor_contact", "label": "Vendor Contact", "value": "", "readonly": False},
            {"field": "jnj_contact", "label": "JNJ Contact", "value": "", "readonly": False},
        ]
        
        # DIP fields will be fetched from database after DTA is created
        # Initialize empty placeholder - will be populated in Step 4.8
        dip_fields = []
        
        # Extract transfer file keys from real TV data
        transfer_file_keys = [tv["LABEL"] for tv in real_tv if tv.get("IS_KEY")]
        
        # ========================================
        # Step 4.5: Fetch Test Concepts for new DTA
        # ========================================
        print(f"CREATE-DRAFT-DTA: Loading test concepts for new DTA {new_dta_id}...")
        tc_results = get_test_concepts_for_dta(client, config, new_dta_id)
        real_tc = transform_test_concepts_to_workspace(tc_results)
        print(f"CREATE-DRAFT-DTA: Found {len(real_tc)} test concepts")
        
        if not real_tc:
            real_tc = list(EMPTY_ENTITIES["TC"])
            print(f"CREATE-DRAFT-DTA: No test concepts found, using empty entities")
        
        # ========================================
        # Step 4.6: Fetch Operational Agreement data for new DTA (4 tables)
        # ========================================
        print(f"CREATE-DRAFT-DTA: Loading OA data for new DTA {new_dta_id}...")
        oa_data = get_oa_for_dta(client, config, new_dta_id, is_draft=True)  # New DTA is always draft
        
        oa_parent = oa_data.get("oa_parent", [])
        oa_attr = oa_data.get("oa_attr", [])
        oa_options = oa_data.get("oa_options", [])
        oa_other = oa_data.get("oa_other", [])
        
        # Note: No default OA data - if no OA exists, show empty section
        # User must upload OA document to get actual data
        
        print(f"CREATE-DRAFT-DTA: OA (4 tables): parent={len(oa_parent)}, attrs={len(oa_attr)}, options={len(oa_options)}, other={len(oa_other)}")
        
        # ========================================
        # Step 4.7: Fetch Codelists for new DTA
        # ========================================
        print(f"CREATE-DRAFT-DTA: Loading codelists for new DTA {new_dta_id}...")
        cl_results = get_codelists_for_dta(client, config, new_dta_id, dta_status='DRAFT')
        real_cl = transform_codelists_to_workspace(cl_results)
        print(f"CREATE-DRAFT-DTA: Found {len(real_cl)} codelist entries")
        
        if not real_cl:
            real_cl = list(EMPTY_ENTITIES["CL"])
            print(f"CREATE-DRAFT-DTA: No codelists found, using empty entities")
        
        # Initialize CL state
        cl_state = {}
        for item in real_cl:
            ref = item["ref"]
            if ref not in cl_state:
                cl_state[ref] = []
            cl_state[ref].append({"editable": False, "approved": False, "comments": []})
        
        # ========================================
        # Step 4.8: Fetch Data Ingestion Parameters for new DTA
        # ========================================
        print(f"CREATE-DRAFT-DTA: Loading Data Ingestion Parameters for new DTA {new_dta_id}...")
        dip_result = get_di_params_for_dta(client, config, new_dta_id, is_draft=True)
        dip_params = dip_result.get('params', [])
        real_dip = transform_di_params_to_workspace(dip_params)
        print(f"CREATE-DRAFT-DTA: Found {len(real_dip)} DI params")
        
        # If no DI params, show empty section (don't fail)
        if not real_dip:
            real_dip = []
            print(f"CREATE-DRAFT-DTA: No DI params found - section will be empty")
        
        # Update dip_fields with real data
        dip_fields = real_dip
        
        # Create the workspace with REAL data
        WORKSPACES[workspace_key] = {
            "key": workspace_key,
            "dta_id": new_dta_id,
            "dta_number": new_dta_number,
            "version": new_version,
            "draft_id": f"DRAFT-{new_dta_id[:8]}",
            "base_major": 0,
            "editor_tab": "META",
            "status": "Draft",
            "is_mock_data": False,  # Real data - cloned from database
            "has_pending_changes": False,  # Track unsaved changes
            "last_updated_ts": None,  # New clone - not yet saved
            "source_dta_id": source_dta_id,
            "source_dta_number": source_dta.get("dta_number"),
            "entities": {
                "TC": real_tc,  # REAL test concepts!
                "TV": real_tv,  # REAL transfer variables!
                "CL": real_cl,  # REAL codelists!
                "VT": list(EMPTY_ENTITIES["VT"])   # TODO: Fetch real VT
            },
            "metadata": metadata_fields,
            "metadata_state": [{"editable": False, "approved": False, "comments": []} for _ in metadata_fields],
            "dip": dip_fields,
            "dip_state": [{"editable": False, "approved": False, "comments": []} for _ in dip_fields],
            "tc_state": [
                {
                    "editable": False, 
                    "approved": False, 
                    "comments": [{"user": "vendor", "ts": "saved", "text": tc.get("_vendor_comment")}] if tc.get("_vendor_comment") else []
                } for tc in real_tc
            ],
            "tv_state": [{"editable": False, "approved": False, "comments": []} for _ in real_tv],
            "cl_state": cl_state,
            "transfer_file_keys": transfer_file_keys,
            "comments": [],
            # Operational Agreement data (4 tables)
            "oa_parent": oa_parent,
            "oa_parent_state": [{"editable": False, "approved": False, "comments": []} for _ in oa_parent],
            "oa_attr": oa_attr,
            "oa_attr_state": [{"editable": False, "approved": False, "comments": []} for _ in oa_attr],
            "oa_options": oa_options,
            "oa_options_state": [{"editable": False, "approved": False, "comments": []} for _ in oa_options],
            "oa_other": oa_other,
            "oa_other_state": [{"editable": False, "approved": False, "comments": []} for _ in oa_other],
        }
        
        # Add to MOCK_RESULTS so workspace route can find it
        mock_result = {
            "key": workspace_key,
            "dta_id": new_dta_id,
            "trial": trial_id,
            "vendor": provider,
            "stream": stream,
            "major": 0,
            "updated": datetime.now().strftime("%Y-%m-%d"),
            "owners": [],
            "badges": ["Transfer Variables"],
            "status": "Draft"
        }
        MOCK_RESULTS.append(mock_result)
        
        print(f"=" * 60)
        print(f"CREATE-DRAFT-DTA: SUCCESS!")
        print(f"  New DTA: {new_dta_number} ({new_dta_id})")
        print(f"  Version: {new_version}")
        print(f"  Transfer Variables: {len(real_tv)}")
        print(f"  Test Concepts: {len(real_tc)}")
        print(f"  OA Data: parent={len(oa_parent)}, attrs={len(oa_attr)}, options={len(oa_options)}, other={len(oa_other)}")
        print(f"  Workspace Key: {workspace_key}")
        print(f"=" * 60)
        
        # Build success message with counts
        tv_count = len(real_tv)
        tc_count = len(real_tc) if real_tc and not (len(real_tc) == 1 and real_tc[0].get('LABEL', '') == 'Sample Test 1') else 0
        oa_count = len(oa_parent) + len(oa_attr) + len(oa_options) + len(oa_other)
        msg_parts = [f"Created draft {new_dta_number}"]
        if tv_count > 0:
            msg_parts.append(f"{tv_count} transfer variables")
        if tc_count > 0:
            msg_parts.append(f"{tc_count} test concepts")
        if oa_count > 0:
            msg_parts.append(f"{oa_count} OA items")
        flash(" with ".join(msg_parts[:2]) + (f" and {', '.join(msg_parts[2:])}" if len(msg_parts) > 2 else ""), "success")
        # Redirect directly to workspace for editing
        return redirect(url_for("workspace", key=workspace_key))
        
    except Exception as e:
        import traceback
        print(f"CREATE-DRAFT-DTA ERROR: {e}")
        traceback.print_exc()
        flash(f"Error creating DTA draft: {str(e)}", "error")
        return redirect(url_for("dta_search"))


@app.route("/workspace/<path:key>")
def workspace(key):
    from api.dta_api import (_get_db_config, _get_sql_client, get_oa_for_dta)
    
    res = next((r for r in MOCK_RESULTS if r["key"] == key), None)
    if not res:
        flash("DTA not found", "error")
        return redirect(url_for("composer"))
    ws = get_or_create_workspace(res)
    
    # Check if DTA is in Pending Approval or Approved state
    if ws.get("status") in ["Pending Approval", "Approved"]:
        # Both pending and approved DTAs use the approval_detail view
        # The view will show different buttons based on status
        return redirect(url_for("approval_detail", key=key))

    # ========================================
    # Load real OA data from database if dta_id exists (unified API)
    # ========================================
    dta_id = ws.get("dta_id")
    if dta_id and not ws.get("is_mock_data"):
        try:
            config = _get_db_config()
            client = _get_sql_client()
            
            # Determine if draft based on workspace status
            ws_status = ws.get("status", "Draft")
            is_draft_ws = ws_status == "Draft"
            
            # Fetch real OA data using 4-table API
            oa_data = get_oa_for_dta(client, config, dta_id, is_draft=is_draft_ws)
            
            oa_parent = oa_data.get("oa_parent", [])
            oa_attr = oa_data.get("oa_attr", [])
            oa_options = oa_data.get("oa_options", [])
            oa_other = oa_data.get("oa_other", [])
            
            # Update workspace with real OA data (if found)
            if oa_parent:
                ws["oa_parent"] = oa_parent
                ws["oa_parent_state"] = [{"editable": False, "approved": False, "comments": []} for _ in oa_parent]
            if oa_attr:
                ws["oa_attr"] = oa_attr
                ws["oa_attr_state"] = [{"editable": False, "approved": False, "comments": []} for _ in oa_attr]
            if oa_options:
                ws["oa_options"] = oa_options
                ws["oa_options_state"] = [{"editable": False, "approved": False, "comments": []} for _ in oa_options]
                # Debug: Log the data types and exact format
                for idx, opt in enumerate(oa_options):
                    opts = opt.get('options')
                    selected = opt.get('selected_options')
                    print(f"WORKSPACE DEBUG OA Opt {idx}: options type={type(opts).__name__}, repr={repr(opts)}")
                    print(f"WORKSPACE DEBUG OA Opt {idx}: selected type={type(selected).__name__}, repr={repr(selected)}")
            if oa_other:
                ws["oa_other"] = oa_other
                ws["oa_other_state"] = [{"editable": False, "approved": False, "comments": []} for _ in oa_other]
                # Debug: Log the data types and exact format
                for idx, item in enumerate(oa_other):
                    opts = item.get('options')
                    selected = item.get('selected_options')
                    print(f"WORKSPACE DEBUG OA Other {idx}: options type={type(opts).__name__}, repr={repr(opts)}")
                    print(f"WORKSPACE DEBUG OA Other {idx}: selected type={type(selected).__name__}, repr={repr(selected)}")
                
            print(f"WORKSPACE: Loaded OA (4 tables) for DTA {dta_id}: oa_id={oa_data.get('oa_id')}, parent={len(oa_parent)}, attrs={len(oa_attr)}, options={len(oa_options)}, other={len(oa_other)}")
        except Exception as e:
            print(f"WORKSPACE: Could not load OA data for DTA {dta_id}: {e}")
            # Continue with existing/mock OA data

    # Active tabs (enabled for interaction)
    allowed_tabs = ["META", "TV", "TC", "OA", "CL", "DIP"]
    # Coming Soon tabs (shown grayed out)
    disabled_tabs = ["VT"]
    
    tab = request.args.get("tab") or ws.get("editor_tab") or "META"
    if tab not in allowed_tabs:
        tab = "META"
    ws["editor_tab"] = tab

    _ensure_tv_init(ws)
    print(f"DBG tv_selected: {ws.get('tv_selected')}")
    print(f"DBG tv_state: {ws.get('tv_state')}")
    print(f"DBG TV entities count: {len(ws.get('entities', {}).get('TV', []))}")
    
    # Group codelists by reference for CL tab
    cl_grouped = group_codelists_by_ref(ws.get('entities', {}).get('CL', []))
    
    # Sort TC columns - columns with more non-empty values come first
    tc_entities = ws.get("entities", {}).get("TC", [])
    if tc_entities:
        # Count non-empty values per column
        column_data_count = {}
        for row in tc_entities:
            for key, val in row.items():
                if not key.startswith('_'):
                    if key not in column_data_count:
                        column_data_count[key] = 0
                    if val and str(val).strip():
                        column_data_count[key] += 1
        
        # Sort columns: those with more data first, then alphabetically for ties
        sorted_tc_keys = sorted(
            column_data_count.keys(),
            key=lambda k: (-column_data_count[k], k)
        )
    else:
        sorted_tc_keys = []
    
    return render_template("workspace.html",
                           ws=ws,
                           current_tab=tab,
                           allowed_tabs=allowed_tabs,
                           disabled_tabs=disabled_tabs,
                           label_for_tab=label_for_tab,
                           cl_grouped=cl_grouped,
                           sorted_tc_keys=sorted_tc_keys)

@app.route("/api/workspace/<path:key>/save", methods=["POST"])
def api_save(key):
    """Save the current workspace draft to the database."""
    from api.dta_api import _get_db_config, _get_sql_client
    from datetime import datetime
    
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    dta_id = ws.get("dta_id")
    
    # Get domain_info filter from query params
    domain_info_filter = request.args.get('domain_info', None)
    
    # If no dta_id, this is mock data - just save in memory
    if not dta_id or ws.get("is_mock_data", True):
        return jsonify({"ok": True, "msg": f"Draft {ws.get('draft_id', 'DRAFT')} saved (in-memory only - mock data)."})
    
    try:
        config = _get_db_config()
        client = _get_sql_client()
        
        catalog = config['catalog']
        gold_schema = config['gold_schema']
        silver_schema = config['silver_schema']
        silver_table = f"{catalog}.{silver_schema}.md_dta_transfer_variables_draft"
        dta_table = f"{catalog}.{gold_schema}.dta"
        
        # Get transfer variables from workspace
        all_tv_entities = ws.get("entities", {}).get("TV", [])
        
        # Filter by domain_info if specified
        if domain_info_filter:
            tv_entities = [tv for tv in all_tv_entities if tv.get("DOMAIN_INFO", "") == domain_info_filter]
            print(f"SAVE: Filtering by domain_info='{domain_info_filter}' - {len(tv_entities)} of {len(all_tv_entities)} records")
        else:
            tv_entities = all_tv_entities
        
        print(f"SAVE: Starting save for DTA {dta_id} with {len(tv_entities)} transfer variables")
        
        # Debug: Check for new rows in the entities
        new_row_count = sum(1 for tv in tv_entities if tv.get("_is_new") or str(tv.get("_transfer_variable_id", "")).startswith("new_"))
        print(f"SAVE DEBUG: Found {new_row_count} rows with _is_new flag or new_ prefix in TV entities")
        if new_row_count > 0:
            for i, tv in enumerate(tv_entities):
                if tv.get("_is_new") or str(tv.get("_transfer_variable_id", "")).startswith("new_"):
                    print(f"  - Row {i}: _is_new={tv.get('_is_new')}, _transfer_variable_id={tv.get('_transfer_variable_id')}, LABEL={tv.get('LABEL')}")
        
        # ========================================
        # Step 1: Fetch current DB values for change detection (keyed by transfer_variable_id)
        # ========================================
        current_db_values = {}
        try:
            # Build WHERE clause with optional domain_info filter
            where_clause = f"dta_id = '{dta_id}'"
            if domain_info_filter:
                domain_escaped = domain_info_filter.replace("'", "''")
                where_clause += f" AND domain_info = '{domain_escaped}'"
            
            fetch_query = f"""
                SELECT transfer_variable_id, transfer_variable_order, transfer_variable_name, format, 
                       anticipated_max_length, populate_for_all_records, variable_description,
                       transfer_file_key, vendor_comment, domain_info
                FROM {silver_table}
                WHERE {where_clause}
            """
            db_results = client.execute_query(fetch_query, raise_on_error=True)
            for row in db_results or []:
                tv_id = row.get('transfer_variable_id')
                if tv_id:
                    # Properly handle boolean fields from DB (native bool, string, or None)
                    db_required = row.get('populate_for_all_records')
                    if db_required is None:
                        required_val = False
                    elif isinstance(db_required, bool):
                        required_val = db_required
                    else:
                        required_val = str(db_required).lower() in ('true', '1', 'yes')
                    
                    db_is_key = row.get('transfer_file_key')
                    if db_is_key is None:
                        is_key_val = False
                    elif isinstance(db_is_key, bool):
                        is_key_val = db_is_key
                    else:
                        is_key_val = str(db_is_key).lower() in ('true', '1', 'yes')
                    
                    # Properly handle length (int or None)
                    db_length = row.get('anticipated_max_length')
                    length_val = int(db_length) if db_length is not None else 50
                    
                    current_db_values[str(tv_id)] = {
                        'order': row.get('transfer_variable_order'),
                        'name': str(row.get('transfer_variable_name') or ''),
                        'format': str(row.get('format') or 'STRING'),
                        'length': length_val,
                        'required': required_val,
                        'description': str(row.get('variable_description') or ''),
                        'is_key': is_key_val,
                        'vendor_comment': str(row.get('vendor_comment') or '')
                    }
            print(f"SAVE: Fetched {len(current_db_values)} existing records from DB (keyed by transfer_variable_id)")
        except Exception as fetch_error:
            print(f"SAVE: Could not fetch current values, will update all: {fetch_error}")
        
        # ========================================
        # Step 2: Detect changed rows
        # ========================================
        updated_count = 0
        field_changes = []  # Track all field-level changes for activity log
        
        if tv_entities:
            # Build VALUES clause for only changed TV records
            values_rows = []
            new_rows = []  # Track new rows that need INSERT
            
            for tv in tv_entities:
                # Use transfer_variable_id as the unique key for matching
                tv_id = tv.get("_transfer_variable_id", "")
                file_order = tv.get("FILE_ORDER", 0)
                is_new_row = tv.get("_is_new", False) or (tv_id and tv_id.startswith("new_"))
                
                if not tv_id:
                    print(f"SAVE: Skipping TV row without transfer_variable_id (order={file_order})")
                    continue
                
                # Handle new rows separately - they need INSERT
                if is_new_row:
                    print(f"SAVE: Found new row to INSERT (temp_id={tv_id}, label={tv.get('LABEL', '')})")
                    new_rows.append(tv)
                    continue
                    
                # Get values (unescaped for comparison)
                # IMPORTANT: Ensure correct types for comparison - UI/JS may send strings
                label = (tv.get("LABEL", "") or "")
                format_val = (tv.get("FORMAT", "STRING") or "STRING")
                
                # Force int for length (UI might send string "50" instead of int 50)
                length_raw = tv.get("LENGTH", 50)
                length = int(length_raw) if length_raw else 50
                
                # Force bool for required (UI might send string "true"/"false")
                required_raw = tv.get("REQUIRED", False)
                required_bool = required_raw if isinstance(required_raw, bool) else str(required_raw).lower() == 'true'
                required = str(required_bool).lower()
                
                description = (tv.get("DESCRIPTION", "") or "")
                
                # Force bool for is_key (UI might send string "true"/"false")
                is_key_raw = tv.get("IS_KEY", False)
                is_key_bool = is_key_raw if isinstance(is_key_raw, bool) else str(is_key_raw).lower() == 'true'
                is_key = str(is_key_bool).lower()
                
                vendor_comment = (tv.get("VENDOR_COMMENT", "") or "")
                
                # Check if this row has changed compared to DB (keyed by transfer_variable_id)
                db_row = current_db_values.get(str(tv_id))
                row_has_changes = False
                
                if db_row:
                    # Debug: Log first row comparison to help diagnose type issues
                    if len(values_rows) == 0:
                        print(f"SAVE DEBUG: First row comparison (tv_id={tv_id}):")
                        print(f"  label: '{label}' vs DB: '{db_row['name']}' | match={label == db_row['name']}")
                        print(f"  format: '{format_val}' vs DB: '{db_row['format']}' | match={format_val == db_row['format']}")
                        print(f"  length: {length} ({type(length).__name__}) vs DB: {db_row['length']} ({type(db_row['length']).__name__}) | match={length == db_row['length']}")
                        print(f"  required: {required_bool} ({type(required_bool).__name__}) vs DB: {db_row['required']} ({type(db_row['required']).__name__}) | match={required_bool == db_row['required']}")
                        print(f"  is_key: {is_key_bool} ({type(is_key_bool).__name__}) vs DB: {db_row['is_key']} ({type(db_row['is_key']).__name__}) | match={is_key_bool == db_row['is_key']}")
                        print(f"  description: '{description[:30]}...' vs DB: '{db_row['description'][:30] if db_row['description'] else ''}...' | match={description == db_row['description']}")
                    
                    # Compare each field and track changes
                    print(f"SAVE DEBUG COMPARE: tv_id={tv_id[:8]}... label='{label}' vs db='{db_row['name']}' match={label == db_row['name']}")
                    if label != db_row['name']:
                        field_changes.append({
                            'entity_id': str(tv_id),
                            'entity_name': label or db_row['name'],
                            'field': 'name',
                            'old': db_row['name'],
                            'new': label
                        })
                        row_has_changes = True
                    
                    if format_val != db_row['format']:
                        field_changes.append({
                            'entity_id': str(tv_id),
                            'entity_name': label or db_row['name'],
                            'field': 'format',
                            'old': db_row['format'],
                            'new': format_val
                        })
                        row_has_changes = True
                    
                    if length != db_row['length']:
                        field_changes.append({
                            'entity_id': str(tv_id),
                            'entity_name': label or db_row['name'],
                            'field': 'length',
                            'old': str(db_row['length']),
                            'new': str(length)
                        })
                        row_has_changes = True
                    
                    if required_bool != db_row['required']:
                        field_changes.append({
                            'entity_id': str(tv_id),
                            'entity_name': label or db_row['name'],
                            'field': 'required',
                            'old': str(db_row['required']),
                            'new': str(required_bool)
                        })
                        row_has_changes = True
                    
                    if description != db_row['description']:
                        field_changes.append({
                            'entity_id': str(tv_id),
                            'entity_name': label or db_row['name'],
                            'field': 'description',
                            'old': db_row['description'][:50] if db_row['description'] else '',
                            'new': description[:50] if description else ''
                        })
                        row_has_changes = True
                    
                    if is_key_bool != db_row.get('is_key', False):
                        field_changes.append({
                            'entity_id': str(tv_id),
                            'entity_name': label or db_row['name'],
                            'field': 'is_key',
                            'old': str(db_row.get('is_key', False)),
                            'new': str(is_key_bool)
                        })
                        row_has_changes = True
                    
                    if vendor_comment != db_row.get('vendor_comment', ''):
                        field_changes.append({
                            'entity_id': str(tv_id),
                            'entity_name': label or db_row['name'],
                            'field': 'vendor_comment',
                            'old': db_row.get('vendor_comment', ''),
                            'new': vendor_comment
                        })
                        row_has_changes = True
                    
                    if not row_has_changes:
                        continue  # Skip unchanged rows
                else:
                    # New row - this is an INSERT
                    row_has_changes = True
                
                # Escape for SQL
                tv_id_escaped = str(tv_id).replace("'", "''")
                label_escaped = label.replace("'", "''")
                format_escaped = format_val.replace("'", "''")
                desc_escaped = description.replace("'", "''")
                comment_escaped = vendor_comment.replace("'", "''")
                
                # Include transfer_variable_id in VALUES for unique MERGE matching
                values_rows.append(f"('{tv_id_escaped}', '{dta_id}', {file_order}, '{label_escaped}', '{format_escaped}', {length}, {required}, '{desc_escaped}', {is_key}, '{comment_escaped}')")
            
            print(f"SAVE: Detected {len(values_rows)} changed records out of {len(tv_entities)} total")
            print(f"SAVE DEBUG: field_changes has {len(field_changes)} entries for existing row updates")
            
            if values_rows:
                values_clause = ",\n                ".join(values_rows)
                
                # MERGE using transfer_variable_id as the unique key to prevent duplicate row matching
                merge_query = f"""
                    MERGE INTO {silver_table} AS target
                    USING (
                        SELECT * FROM (
                            VALUES
                                {values_clause}
                        ) AS source(transfer_variable_id, dta_id, transfer_variable_order, transfer_variable_name, format, anticipated_max_length, populate_for_all_records, variable_description, transfer_file_key, vendor_comment)
                    ) AS source
                    ON target.transfer_variable_id = source.transfer_variable_id
                    WHEN MATCHED THEN
                        UPDATE SET
                            target.transfer_variable_name = source.transfer_variable_name,
                            target.format = source.format,
                            target.anticipated_max_length = source.anticipated_max_length,
                            target.populate_for_all_records = source.populate_for_all_records,
                            target.variable_description = source.variable_description,
                            target.transfer_file_key = source.transfer_file_key,
                            target.vendor_comment = source.vendor_comment,
                            target.last_updated_ts = current_timestamp(),
                            target.last_updated_by_principal = current_user()
                """
                
                try:
                    print(f"SAVE: Executing batch MERGE for {len(values_rows)} transfer variables...")
                    client.execute_query(merge_query, raise_on_error=True)
                    updated_count = len(values_rows)
                    print(f"SAVE: Batch MERGE completed - {updated_count} records")
                    
                    # ========================================
                    # Step 2b: Log batch update to activity log (consolidated)
                    # ========================================
                    if field_changes:
                        # Debug: Show exactly which fields changed
                        print(f"SAVE DEBUG: {len(field_changes)} field changes detected:")
                        field_summary = {}
                        for change in field_changes:
                            field_name = change['field']
                            field_summary[field_name] = field_summary.get(field_name, 0) + 1
                        for field_name, count in sorted(field_summary.items()):
                            print(f"  - {field_name}: {count} changes")
                        
                        # Log using common helper function
                        log_activity_for_save(client, dta_id, "transfer_variables", updated_count, field_changes, domain_info_filter)
                        
                except Exception as merge_error:
                    print(f"SAVE ERROR: Batch MERGE failed: {merge_error}")
                    import traceback
                    traceback.print_exc()
                    return jsonify({"ok": False, "msg": f"Failed to save transfer variables: {str(merge_error)}"}), 500
            
            # ========================================
            # Step 1.5: INSERT new rows
            # ========================================
            print(f"SAVE DEBUG: new_rows count = {len(new_rows)}")
            if new_rows:
                import uuid
                print(f"SAVE: Inserting {len(new_rows)} new transfer variables...")
                
                for new_tv in new_rows:
                    # Generate a real UUID for the new row
                    real_tv_id = str(uuid.uuid4())
                    
                    # Get values with proper type handling
                    label = (new_tv.get("LABEL", "") or "").replace("'", "''")
                    format_val = (new_tv.get("FORMAT", "STRING") or "STRING").replace("'", "''")
                    length_raw = new_tv.get("LENGTH", 50)
                    length = int(length_raw) if length_raw else 50
                    required_raw = new_tv.get("REQUIRED", False)
                    required_bool = required_raw if isinstance(required_raw, bool) else str(required_raw).lower() == 'true'
                    description = (new_tv.get("DESCRIPTION", "") or "").replace("'", "''")
                    is_key_raw = new_tv.get("IS_KEY", False)
                    is_key_bool = is_key_raw if isinstance(is_key_raw, bool) else str(is_key_raw).lower() == 'true'
                    vendor_comment = (new_tv.get("VENDOR_COMMENT", "") or "").replace("'", "''")
                    domain_info = (new_tv.get("DOMAIN_INFO", "") or "").replace("'", "''")
                    file_order = int(new_tv.get("FILE_ORDER", 0))
                    
                    print(f"SAVE DEBUG: Inserting TV - label='{label}', domain='{domain_info}', order={file_order}")
                    
                    insert_query = f"""
                        INSERT INTO {silver_table} (
                            transfer_variable_id, dta_id, transfer_variable_order, transfer_variable_name,
                            format, anticipated_max_length, populate_for_all_records, variable_description,
                            transfer_file_key, vendor_comment, domain_info, status, version, version_status,
                            is_current_draft, definition_hash,
                            created_by_principal, created_ts, last_updated_by_principal, last_updated_ts
                        ) VALUES (
                            '{real_tv_id}', '{dta_id}', {file_order}, '{label}',
                            '{format_val}', {length}, {str(required_bool).lower()}, '{description}',
                            {str(is_key_bool).lower()}, '{vendor_comment}', '{domain_info}', 'DRAFT', 1, 'draft',
                            true, '',
                            current_user(), current_timestamp(), current_user(), current_timestamp()
                        )
                    """
                    try:
                        client.execute_query(insert_query, raise_on_error=True)
                        updated_count += 1
                        print(f"SAVE: Inserted new TV '{label}' with ID {real_tv_id}")
                        
                        # Update the in-memory row with the real ID and remove _is_new flag
                        new_tv["_transfer_variable_id"] = real_tv_id
                        new_tv.pop("_is_new", None)
                        
                        # Also update tv_state to remove is_new flag
                        for i, tv in enumerate(ws["entities"]["TV"]):
                            if tv.get("_transfer_variable_id") == real_tv_id:
                                if "tv_state" in ws and i < len(ws["tv_state"]):
                                    ws["tv_state"][i].pop("is_new", None)
                                break
                        
                    except Exception as insert_err:
                        print(f"SAVE ERROR: Failed to insert new TV: {insert_err}")
                        import traceback
                        traceback.print_exc()
                        return jsonify({"ok": False, "msg": f"Failed to insert new transfer variable: {str(insert_err)}"}), 500
                
                # Log new row inserts to activity log
                if len(new_rows) > 0:
                    from api.activity_log_api import log_batch_update
                    
                    # Build field_changes for new rows - use clear descriptive format
                    new_row_changes = []
                    for new_tv in new_rows:
                        label = new_tv.get("LABEL", "") or "(unnamed)"
                        domain = new_tv.get("DOMAIN_INFO", "") or ""
                        new_row_changes.append({
                            'entity_id': new_tv.get("_transfer_variable_id", ""),
                            'entity_name': f"New variable: {label}",
                            'field': 'CREATED',
                            'old': '(new)',
                            'new': f"{label} in {domain}" if domain else label
                        })
                    
                    # Get current user
                    log_user = "ui_user"
                    try:
                        user_result = client.execute_query("SELECT current_user() as user")
                        if user_result:
                            log_user = user_result[0].get('user', 'ui_user')
                    except:
                        pass
                    
                    try:
                        log_batch_update(
                            dta_id=dta_id,
                            library_type="transfer_variables",
                            records_updated=len(new_rows),
                            field_changes=new_row_changes,
                            performed_by=log_user,
                            domain_info=domain_info_filter
                        )
                        print(f"SAVE: Activity log updated for {len(new_rows)} new transfer variables")
                    except Exception as log_err:
                        print(f"Warning: Failed to log new TV inserts: {log_err}")
            else:
                print(f"SAVE DEBUG: No new rows to insert")
        
        # ========================================
        # Step 2: Save Test Concepts
        # ========================================
        tc_silver_table = f"{catalog}.{silver_schema}.md_dta_vendor_test_concepts_draft"
        tc_entities = ws.get("entities", {}).get("TC", [])
        tc_updated_count = 0
        
        if tc_entities:
            print(f"SAVE: Processing {len(tc_entities)} test concepts...")
            
            # Fetch current TC values for change detection (including transfer_tuple_map)
            tc_current_db = {}
            try:
                tc_fetch_query = f"""
                    SELECT test_concept_id, test_concept_reference, transfer_tuple_map, 
                           vendor_comment, notes, status
                    FROM {tc_silver_table}
                    WHERE dta_id = '{dta_id}'
                """
                tc_db_results = client.execute_query(tc_fetch_query, raise_on_error=True)
                for row in tc_db_results or []:
                    tc_id = row.get('test_concept_id')
                    if tc_id:
                        # Parse the tuple map from DB
                        db_tuple_map = row.get('transfer_tuple_map')
                        if isinstance(db_tuple_map, str):
                            try:
                                import json
                                db_tuple_map = json.loads(db_tuple_map)
                            except:
                                db_tuple_map = {}
                        elif not isinstance(db_tuple_map, dict):
                            db_tuple_map = {}
                        
                        tc_current_db[tc_id] = {
                            'test_concept_id': tc_id,
                            'test_concept_reference': row.get('test_concept_reference', ''),
                            'tuple_map': db_tuple_map,
                            'vendor_comment': str(row.get('vendor_comment') or ''),
                            'notes': str(row.get('notes') or ''),
                            'status': str(row.get('status') or '')
                        }
                print(f"SAVE: Fetched {len(tc_current_db)} existing test concepts from DB")
            except Exception as tc_fetch_error:
                print(f"SAVE: Could not fetch current TC values: {tc_fetch_error}")
            
            # Separate new rows from existing rows
            new_tc_rows = [tc for tc in tc_entities if tc.get("_is_new")]
            existing_tc_rows = [tc for tc in tc_entities if not tc.get("_is_new")]
            
            print(f"SAVE: Found {len(new_tc_rows)} new TCs and {len(existing_tc_rows)} existing TCs")
            
            # Build batch MERGE for changed TCs (much faster than individual UPDATEs)
            tc_select_rows = []  # For UNION ALL approach with MAP
            tc_field_changes = []
            
            for row_idx, tc in enumerate(existing_tc_rows, start=1):
                # Get the test concept ID (hidden field)
                tc_id = tc.get("_test_concept_id", "")
                if not tc_id:
                    continue  # Skip silently - reduced logging for performance
                
                # Check if this TC exists in DB first (early exit optimization)
                db_tc = tc_current_db.get(tc_id)
                if not db_tc:
                    continue
                
                # Get metadata values from UI
                vendor_comment = str(tc.get("_vendor_comment", "") or "")
                notes = str(tc.get("_notes", "") or "")
                status = str(tc.get("_status", "") or "")
                
                # Extract tuple map columns (all non-underscore keys)
                ui_tuple_map = {}
                for key, val in tc.items():
                    if not key.startswith('_'):
                        ui_tuple_map[key] = str(val) if val is not None else ""
                
                has_changes = False
                row_label = f"Row {row_idx}"
                
                # Compare tuple map columns
                db_tuple_map = db_tc.get('tuple_map', {})
                for key, ui_val in ui_tuple_map.items():
                    db_val = str(db_tuple_map.get(key, ''))
                    if ui_val != db_val:
                        tc_field_changes.append({
                            'entity_id': tc_id,
                            'entity_name': row_label,
                            'field': key,
                            'old': db_val,
                            'new': ui_val
                        })
                        has_changes = True
                
                # Compare metadata fields
                if vendor_comment != db_tc['vendor_comment']:
                    tc_field_changes.append({
                        'entity_id': tc_id,
                        'entity_name': row_label,
                        'field': 'vendor_comment',
                        'old': db_tc['vendor_comment'],
                        'new': vendor_comment
                    })
                    has_changes = True
                
                if notes != db_tc['notes']:
                    tc_field_changes.append({
                        'entity_id': tc_id,
                        'entity_name': row_label,
                        'field': 'notes',
                        'old': db_tc['notes'],
                        'new': notes
                    })
                    has_changes = True
                
                if status and status != db_tc['status']:
                    tc_field_changes.append({
                        'entity_id': tc_id,
                        'entity_name': row_label,
                        'field': 'status',
                        'old': db_tc['status'],
                        'new': status
                    })
                    has_changes = True
                
                # Build MERGE row if any changes detected (moved OUTSIDE status check)
                if has_changes:
                    # Build MAP literal for transfer_tuple_map
                    map_entries = []
                    for k, v in ui_tuple_map.items():
                        k_escaped = k.replace("'", "''")
                        v_escaped = str(v).replace("'", "''")
                        map_entries.append(f"'{k_escaped}', '{v_escaped}'")
                    map_literal = f"MAP({', '.join(map_entries)})" if map_entries else "MAP()"
                    
                    tc_id_escaped = tc_id.replace("'", "''")
                    vendor_comment_escaped = vendor_comment.replace("'", "''")
                    notes_escaped = notes.replace("'", "''")
                    
                    # Build SELECT row for UNION ALL (supports MAP type)
                    tc_select_rows.append(
                        f"SELECT '{tc_id_escaped}' as test_concept_id, "
                        f"{map_literal} as transfer_tuple_map, "
                        f"'{vendor_comment_escaped}' as vendor_comment, "
                        f"'{notes_escaped}' as notes"
                    )
                    tc_updated_count += 1
            
            print(f"SAVE: Detected {len(tc_select_rows)} changed test concepts")
            
            # Execute single MERGE for all TC changes
            if tc_select_rows:
                union_clause = "\n                        UNION ALL\n                        ".join(tc_select_rows)
                
                tc_merge_query = f"""
                    MERGE INTO {tc_silver_table} AS target
                    USING (
                        {union_clause}
                    ) AS source
                    ON target.test_concept_id = source.test_concept_id
                    WHEN MATCHED THEN
                        UPDATE SET
                            target.transfer_tuple_map = source.transfer_tuple_map,
                            target.vendor_comment = source.vendor_comment,
                            target.notes = source.notes,
                            target.last_updated_ts = current_timestamp(),
                            target.last_updated_by = current_user()
                """
                
                try:
                    print(f"SAVE: Executing batch MERGE for {len(tc_select_rows)} test concepts...")
                    client.execute_query(tc_merge_query, raise_on_error=True)
                    tc_updated_count = len(tc_select_rows)
                    print(f"SAVE: Batch MERGE completed - {tc_updated_count} test concepts")
                except Exception as tc_merge_err:
                    print(f"SAVE ERROR: TC batch MERGE failed: {tc_merge_err}")
                    import traceback
                    traceback.print_exc()
                    return jsonify({"ok": False, "msg": f"Failed to save test concepts: {str(tc_merge_err)}"}), 500
            
            # Step 2.5: INSERT new test concepts
            if new_tc_rows:
                import uuid
                print(f"SAVE: Inserting {len(new_tc_rows)} new test concepts...")
                
                tc_insert_values = []
                for tc in new_tc_rows:
                    new_tc_id = str(uuid.uuid4())  # Generate real UUID for new TC
                    
                    # Get metadata values
                    vendor_comment = str(tc.get("_vendor_comment", "") or "").replace("'", "''")
                    notes = str(tc.get("_notes", "") or "").replace("'", "''")
                    
                    # Extract tuple map columns (all non-underscore keys)
                    ui_tuple_map = {}
                    for key, val in tc.items():
                        if not key.startswith('_'):
                            ui_tuple_map[key] = str(val) if val is not None else ""
                    
                    # Get test_concept_reference - try from field first, then from tuple map
                    tc_ref = tc.get("_test_concept_reference", "")
                    if not tc_ref:
                        # Use first non-empty tuple map value as reference
                        for key, val in ui_tuple_map.items():
                            if val:
                                tc_ref = str(val)[:50]
                                break
                    tc_ref = tc_ref.replace("'", "''") if tc_ref else ""
                    
                    # Build MAP literal for transfer_tuple_map
                    map_entries = []
                    for k, v in ui_tuple_map.items():
                        k_escaped = k.replace("'", "''")
                        v_escaped = str(v).replace("'", "''")
                        map_entries.append(f"'{k_escaped}', '{v_escaped}'")
                    map_literal = f"MAP({', '.join(map_entries)})" if map_entries else "MAP()"
                    
                    # Build SELECT for UNION ALL (supports MAP type)
                    tc_insert_values.append(
                        f"SELECT '{new_tc_id}' as test_concept_id, "
                        f"'{dta_id}' as dta_id, "
                        f"'{tc_ref}' as test_concept_reference, "
                        f"{map_literal} as transfer_tuple_map, "
                        f"'{vendor_comment}' as vendor_comment, "
                        f"'{notes}' as notes, "
                        f"'DRAFT' as status, "
                        f"1 as version, "
                        f"'DRAFT' as version_status, "
                        f"true as is_current_draft, "
                        f"current_user() as created_by_principal, "
                        f"current_timestamp() as created_ts"
                    )
                    
                    # Update in-memory workspace with real ID and remove _is_new flag
                    for i, existing_tc in enumerate(ws["entities"]["TC"]):
                        if existing_tc.get("_test_concept_id") == tc.get("_test_concept_id"):
                            ws["entities"]["TC"][i]["_test_concept_id"] = new_tc_id
                            ws["entities"]["TC"][i].pop("_is_new", None)
                            if "tc_state" in ws and i < len(ws["tc_state"]):
                                ws["tc_state"][i].pop("is_new", None)
                            break
                    
                    tc_updated_count += 1
                
                if tc_insert_values:
                    union_clause = "\n                    UNION ALL\n                    ".join(tc_insert_values)
                    
                    tc_insert_query = f"""
                        INSERT INTO {tc_silver_table} (test_concept_id, dta_id, test_concept_reference, transfer_tuple_map, vendor_comment, notes, status, version, version_status, is_current_draft, created_by_principal, created_ts)
                        {union_clause}
                    """
                    
                    try:
                        client.execute_query(tc_insert_query, raise_on_error=True)
                        print(f"SAVE: Inserted {len(new_tc_rows)} new test concepts")
                    except Exception as tc_insert_err:
                        print(f"SAVE ERROR: New TC INSERT failed: {tc_insert_err}")
                        import traceback
                        traceback.print_exc()
                        return jsonify({"ok": False, "msg": f"Failed to insert new test concepts: {str(tc_insert_err)}"}), 500
                
                # Build field_changes for new TC rows - use row numbers
                new_tc_changes = []
                # New rows start after existing rows
                new_row_start = len(existing_tc_rows) + 1
                for idx, tc in enumerate(new_tc_rows, start=new_row_start):
                    row_label = f"Row {idx}"
                    new_tc_changes.append({
                        'entity_id': tc.get("_test_concept_id", ""),
                        'entity_name': row_label,
                        'field': 'CREATED',
                        'old': '(new)',
                        'new': row_label
                    })
            
            # Combine all TC changes and log once (performance optimization - single DB call)
            if 'new_tc_changes' not in locals():
                new_tc_changes = []
            all_tc_changes = tc_field_changes + new_tc_changes
            # Log using common helper function
            log_activity_for_save(client, dta_id, "test_concepts", len(all_tc_changes), all_tc_changes)
        
        # ========================================
        # Step 3: Save Operational Agreement (OA) data to Silver (4 tables)
        # Schema: 
        #   1. md_dta_operational_agreement_draft (parent)
        #   2. md_dta_oa_attributes_draft (attributes)
        #   3. md_dta_oa_options_draft (options)
        #   4. md_dta_oa_other_draft (other)
        # Uses same change detection pattern as TV and TC
        # ========================================
        oa_updated_count = 0
        oa_field_changes = []  # Track all field-level changes for activity log
        oa_parent_data = ws.get("oa_parent", [])
        oa_attr = ws.get("oa_attr", [])
        oa_options = ws.get("oa_options", [])
        oa_other = ws.get("oa_other", [])
        
        if oa_parent_data or oa_attr or oa_options or oa_other:
            # 4-table schema names (silver uses _draft suffix)
            oa_parent_table = f"{catalog}.{silver_schema}.md_dta_operational_agreement_draft"
            oa_attr_table = f"{catalog}.{silver_schema}.md_dta_oa_attributes_draft"
            oa_options_table = f"{catalog}.{silver_schema}.md_dta_oa_options_draft"
            oa_other_table = f"{catalog}.{silver_schema}.md_dta_oa_other_draft"
            
            print(f"SAVE: Processing OA data (4 tables) - parent: {len(oa_parent_data)}, attrs: {len(oa_attr)}, options: {len(oa_options)}, other: {len(oa_other)}")
            
            # Step 3.1: Get operational_agreement_id for this DTA
            oa_id = None
            try:
                oa_id_query = f"""
                    SELECT operational_agreement_id 
                    FROM {oa_parent_table} 
                    WHERE dta_id = '{dta_id}' AND (is_current_draft = true OR is_current_draft IS NULL)
                    ORDER BY created_ts DESC LIMIT 1
                """
                oa_id_result = client.execute_query(oa_id_query, raise_on_error=False)
                if oa_id_result:
                    oa_id = oa_id_result[0].get('operational_agreement_id')
                    print(f"SAVE: Found OA ID: {oa_id}")
            except Exception as oa_lookup_err:
                print(f"SAVE: Warning - Could not lookup OA ID: {oa_lookup_err}")
            
            if not oa_id:
                print(f"SAVE: No OA found for DTA {dta_id} - skipping OA save")
            else:
                # ========================================
                # Step 3.2: Fetch current OA values from DB for change detection
                # ========================================
                oa_db_parent = {}
                oa_db_attr = {}
                oa_db_options = {}  # keyed by oa_options_id
                oa_db_other = {}    # keyed by oa_other_id
                
                try:
                    # Fetch parent values (use 'version' - no 'file_version' column exists)
                    parent_fetch = f"""
                        SELECT version FROM {oa_parent_table}
                        WHERE operational_agreement_id = '{oa_id}'
                    """
                    parent_result = client.execute_query(parent_fetch, raise_on_error=False)
                    if parent_result:
                        oa_db_parent = {
                            'version': str(parent_result[0].get('version') or '')
                        }
                    
                    # Fetch attributes values (all editable fields)
                    attr_fetch = f"""
                        SELECT data_recipient, type_of_data, document_version, issue_date, vendor_comments
                        FROM {oa_attr_table}
                        WHERE operational_agreement_id = '{oa_id}'
                    """
                    attr_result = client.execute_query(attr_fetch, raise_on_error=False)
                    if attr_result:
                        oa_db_attr = {
                            'data_recipient': str(attr_result[0].get('data_recipient') or ''),
                            'type_of_data': str(attr_result[0].get('type_of_data') or ''),
                            'document_version': str(attr_result[0].get('document_version') or ''),
                            'issue_date': str(attr_result[0].get('issue_date') or ''),
                            'vendor_comments': str(attr_result[0].get('vendor_comments') or '')
                        }
                    
                    # Fetch options values (all editable fields for change detection)
                    options_fetch = f"""
                        SELECT oa_options_id, section_name, section_description, option_key,
                               options, selected_options, vendor_comments
                        FROM {oa_options_table}
                        WHERE operational_agreement_id = '{oa_id}'
                    """
                    options_result = client.execute_query(options_fetch, raise_on_error=False)
                    for opt_row in (options_result or []):
                        opt_id = opt_row.get('oa_options_id')
                        if opt_id:
                            # Parse array fields - DB might return list, JSON string, or comma-separated string
                            from api.dta_api import _parse_oa_array_field
                            db_options_raw = opt_row.get('options', [])
                            db_selected_raw = opt_row.get('selected_options', [])
                            
                            # Parse and normalize to sorted comma-separated string for comparison
                            db_options_list = _parse_oa_array_field(db_options_raw)
                            db_selected_list = _parse_oa_array_field(db_selected_raw)
                            
                            oa_db_options[opt_id] = {
                                'section_name': str(opt_row.get('section_name') or ''),
                                'section_description': str(opt_row.get('section_description') or ''),
                                'option_key': str(opt_row.get('option_key') or ''),
                                'options': ",".join(sorted([o.strip() for o in db_options_list if o.strip()])),
                                'selected_options': ",".join(sorted([s.strip() for s in db_selected_list if s.strip()]))
                            }
                    
                    # Fetch other values (section_name, selected_options - vendor_comments removed)
                    # IMPORTANT: Parse and normalize arrays the same way as OA Options for proper comparison
                    other_fetch = f"""
                        SELECT oa_other_id, section_name, selected_options
                        FROM {oa_other_table}
                        WHERE operational_agreement_id = '{oa_id}'
                    """
                    other_result = client.execute_query(other_fetch, raise_on_error=False)
                    for other_row in (other_result or []):
                        other_id = other_row.get('oa_other_id')
                        if other_id:
                            # Parse selected_options using the same parser as OA Options
                            db_selected_raw = other_row.get('selected_options', [])
                            db_selected_list = _parse_oa_array_field(db_selected_raw)
                            
                            oa_db_other[other_id] = {
                                'section_name': str(other_row.get('section_name') or ''),
                                'selected_options': ",".join(sorted([s.strip() for s in db_selected_list if s.strip()]))
                            }
                            print(f"SAVE DEBUG: OA Other {other_id[:8]} DB selected_options normalized: '{oa_db_other[other_id]['selected_options']}'")
                    
                    print(f"SAVE: Fetched OA DB values - parent: {bool(oa_db_parent)}, attr: {bool(oa_db_attr)}, options: {len(oa_db_options)}, other: {len(oa_db_other)}")
                except Exception as oa_fetch_err:
                    print(f"SAVE: Warning - Could not fetch OA DB values for change detection: {oa_fetch_err}")
                
                # ========================================
                # Step 3.3: Compare and save OA Parent (only if changed)
                # Note: Use 'version' column, not 'file_version' (doesn't exist)
                # ========================================
                if oa_parent_data and oa_db_parent:
                    ui_version = str(next((f.get("value", "") for f in oa_parent_data if f.get("field") == "version"), "") or "")
                    db_version = oa_db_parent.get('version', '')
                    
                    if ui_version != db_version:
                        try:
                            version_escaped = ui_version.replace("'", "''")
                            oa_parent_update = f"""
                                UPDATE {oa_parent_table}
                                SET version = '{version_escaped}',
                                    last_updated_by_principal = current_user(),
                                    last_updated_ts = current_timestamp()
                                WHERE operational_agreement_id = '{oa_id}'
                            """
                            client.execute_query(oa_parent_update, raise_on_error=False)
                            oa_updated_count += 1
                            oa_field_changes.append({
                                'entity_id': oa_id,
                                'entity_name': 'OA Parent',
                                'field': 'version',
                                'old': db_version,
                                'new': ui_version
                            })
                            print(f"SAVE: OA parent updated (version changed)")
                        except Exception as oa_parent_err:
                            print(f"SAVE: Warning - Could not save OA parent: {oa_parent_err}")
                
                # ========================================
                # Step 3.4: Compare and save OA Attributes (only if changed)
                # Includes: data_recipient, type_of_data, document_version, issue_date, vendor_comments
                # ========================================
                if oa_attr and oa_db_attr:
                    # Get UI values (all editable fields)
                    ui_data_recipient = str(next((a.get("value", "") for a in oa_attr if a.get("field") == "data_recipient"), "") or "")
                    ui_type_of_data = str(next((a.get("value", "") for a in oa_attr if a.get("field") == "type_of_data"), "") or "")
                    ui_document_version = str(next((a.get("value", "") for a in oa_attr if a.get("field") == "document_version"), "") or "")
                    ui_issue_date = str(next((a.get("value", "") for a in oa_attr if a.get("field") == "issue_date"), "") or "")
                    ui_vendor_comments = str(next((a.get("value", "") for a in oa_attr if a.get("field") == "vendor_comments"), "") or "")
                    
                    # Compare with DB values
                    attr_has_changes = False
                    if ui_data_recipient != oa_db_attr.get('data_recipient', ''):
                        oa_field_changes.append({
                            'entity_id': oa_id, 'entity_name': 'OA Attributes',
                            'field': 'data_recipient',
                            'old': oa_db_attr.get('data_recipient', ''), 'new': ui_data_recipient
                        })
                        attr_has_changes = True
                    if ui_type_of_data != oa_db_attr.get('type_of_data', ''):
                        oa_field_changes.append({
                            'entity_id': oa_id, 'entity_name': 'OA Attributes',
                            'field': 'type_of_data',
                            'old': oa_db_attr.get('type_of_data', ''), 'new': ui_type_of_data
                        })
                        attr_has_changes = True
                    if ui_document_version != oa_db_attr.get('document_version', ''):
                        oa_field_changes.append({
                            'entity_id': oa_id, 'entity_name': 'OA Attributes',
                            'field': 'document_version',
                            'old': oa_db_attr.get('document_version', ''), 'new': ui_document_version
                        })
                        attr_has_changes = True
                    if ui_issue_date != oa_db_attr.get('issue_date', ''):
                        oa_field_changes.append({
                            'entity_id': oa_id, 'entity_name': 'OA Attributes',
                            'field': 'issue_date',
                            'old': oa_db_attr.get('issue_date', ''), 'new': ui_issue_date
                        })
                        attr_has_changes = True
                    if ui_vendor_comments != oa_db_attr.get('vendor_comments', ''):
                        oa_field_changes.append({
                            'entity_id': oa_id, 'entity_name': 'OA Attributes',
                            'field': 'vendor_comments',
                            'old': oa_db_attr.get('vendor_comments', ''), 'new': ui_vendor_comments
                        })
                        attr_has_changes = True
                    
                    if attr_has_changes:
                        try:
                            oa_attr_update = f"""
                                UPDATE {oa_attr_table}
                                SET data_recipient = '{ui_data_recipient.replace("'", "''")}',
                                    type_of_data = '{ui_type_of_data.replace("'", "''")}',
                                    document_version = '{ui_document_version.replace("'", "''")}',
                                    issue_date = '{ui_issue_date.replace("'", "''")}',
                                    vendor_comments = '{ui_vendor_comments.replace("'", "''")}',
                                    last_updated_by_principal = current_user(),
                                    last_updated_ts = current_timestamp()
                                WHERE operational_agreement_id = '{oa_id}'
                            """
                            client.execute_query(oa_attr_update, raise_on_error=False)
                            oa_updated_count += 1
                            print(f"SAVE: OA attributes updated")
                        except Exception as oa_attr_err:
                            print(f"SAVE: Warning - Could not save OA attributes: {oa_attr_err}")
                
                # ========================================
                # Step 3.5: Compare and save OA Options (NEW + UPDATE with all fields)
                # Handles: section_name, section_description, option_key, options, selected_options
                # ========================================
                import uuid as uuid_lib
                print(f"SAVE DEBUG: About to process {len(oa_options)} OA options from workspace")
                for idx, oa_opt in enumerate(oa_options):
                    print(f"SAVE DEBUG OA Opt {idx}: options type={type(oa_opt.get('options'))}, value={oa_opt.get('options')}")
                    print(f"SAVE DEBUG OA Opt {idx}: selected_options type={type(oa_opt.get('selected_options'))}, value={oa_opt.get('selected_options')}")
                    opt_id = oa_opt.get("oa_options_id", "")
                    if not opt_id:
                        continue
                    
                    # Check if this is a new option (not yet in DB)
                    is_new_option = opt_id.startswith("new_") or oa_opt.get("_is_new", False)
                    
                    # Get UI values (all editable fields)
                    ui_section_name = str(oa_opt.get("section_name", "") or "").strip()
                    ui_section_desc = str(oa_opt.get("section_description", "") or "").strip()
                    ui_option_key = str(oa_opt.get("option_key", "") or "").strip()
                    
                    # Handle options array - normalize for comparison (sorted, stripped)
                    ui_options = oa_opt.get("options", [])
                    if isinstance(ui_options, list):
                        ui_options_list = sorted([str(o).strip() for o in ui_options if str(o).strip()])
                        ui_options_str = ",".join(ui_options_list)
                    else:
                        ui_options_raw = str(ui_options) if ui_options else ""
                        ui_options_list = sorted([o.strip() for o in ui_options_raw.split(',') if o.strip()])
                        ui_options_str = ",".join(ui_options_list)
                    
                    # Handle selected_options array - normalize for comparison (sorted, stripped)
                    ui_selected = oa_opt.get("selected_options", [])
                    if isinstance(ui_selected, list):
                        ui_selected_list = sorted([str(s).strip() for s in ui_selected if str(s).strip()])
                        ui_selected_str = ",".join(ui_selected_list)
                    else:
                        ui_selected_raw = str(ui_selected) if ui_selected else ""
                        ui_selected_list = sorted([s.strip() for s in ui_selected_raw.split(',') if s.strip()])
                        ui_selected_str = ",".join(ui_selected_list)
                    
                    # Handle NEW options - INSERT
                    if is_new_option:
                        try:
                            # Generate a real UUID for the new option
                            new_opt_id = str(uuid_lib.uuid4())
                            
                            # Convert lists to SQL array literals
                            options_array_items = [f"'{item.replace(chr(39), chr(39)*2)}'" for item in ui_options_list]
                            options_sql = f"ARRAY({', '.join(options_array_items)})" if options_array_items else "ARRAY()"
                            
                            selected_array_items = [f"'{item.replace(chr(39), chr(39)*2)}'" for item in ui_selected_list]
                            selected_sql = f"ARRAY({', '.join(selected_array_items)})" if selected_array_items else "ARRAY()"
                            
                            oa_opt_insert = f"""
                                INSERT INTO {oa_options_table} (
                                    oa_options_id, operational_agreement_id, dta_id,
                                    section_name, section_description, option_key,
                                    options, selected_options,
                                    status, version_status, is_current_draft,
                                    created_by_principal, created_ts, last_updated_by_principal, last_updated_ts
                                ) VALUES (
                                    '{new_opt_id}', '{oa_id}', '{dta_id}',
                                    '{ui_section_name.replace("'", "''")}',
                                    '{ui_section_desc.replace("'", "''")}',
                                    '{ui_option_key.replace("'", "''")}',
                                    {options_sql},
                                    {selected_sql},
                                    'PENDING', 'DRAFT', true,
                                    current_user(), current_timestamp(), current_user(), current_timestamp()
                                )
                            """
                            print(f"SAVE DEBUG: Inserting new OA option with arrays - options_sql={options_sql}, selected_sql={selected_sql}")
                            client.execute_query(oa_opt_insert, raise_on_error=True)
                            oa_updated_count += 1
                            oa_field_changes.append({
                                'entity_id': new_opt_id, 
                                'entity_name': f'New OA Option: {ui_section_name or "Unnamed"}',
                                'field': 'created',
                                'old': '', 'new': 'New option created'
                            })
                            print(f"SAVE: Inserted new OA option: {ui_section_name or new_opt_id[:8]}")
                        except Exception as oa_opt_insert_err:
                            print(f"SAVE ERROR: Could not insert OA option: {oa_opt_insert_err}")
                            import traceback
                            traceback.print_exc()
                        continue
                    
                    # Handle EXISTING options - UPDATE with change detection
                    db_opt = oa_db_options.get(opt_id, {})
                    if not db_opt:
                        print(f"SAVE: OA option {opt_id[:8]} not found in DB, skipping update")
                        continue
                    
                    # Get DB values (already normalized when fetched from DB)
                    db_section_name = str(db_opt.get('section_name', '') or '').strip()
                    db_section_desc = str(db_opt.get('section_description', '') or '').strip()
                    db_option_key = str(db_opt.get('option_key', '') or '').strip()
                    
                    # DB arrays are already normalized (sorted, comma-separated) from fetch step
                    db_options_str = str(db_opt.get('options', '') or '')
                    db_selected_str = str(db_opt.get('selected_options', '') or '')
                    
                    # Compare all fields
                    opt_has_changes = False
                    entity_name = f'OA Option: {ui_section_name or db_section_name or opt_id[:8]}'
                    
                    # Debug: Log comparison for ALL options (not just first)
                    print(f"SAVE DEBUG OA Options comparison for {opt_id[:8]} ({entity_name}):")
                    print(f"  section_name: UI='{ui_section_name}' vs DB='{db_section_name}' | match={ui_section_name == db_section_name}")
                    print(f"  section_desc: UI='{ui_section_desc[:50]}' vs DB='{db_section_desc[:50]}' | match={ui_section_desc == db_section_desc}")
                    print(f"  option_key: UI='{ui_option_key}' vs DB='{db_option_key}' | match={ui_option_key == db_option_key}")
                    print(f"  options: UI='{ui_options_str}' vs DB='{db_options_str}' | match={ui_options_str == db_options_str}")
                    print(f"  selected: UI='{ui_selected_str}' vs DB='{db_selected_str}' | match={ui_selected_str == db_selected_str}")
                    
                    if ui_section_name != db_section_name:
                        oa_field_changes.append({
                            'entity_id': opt_id, 'entity_name': entity_name,
                            'field': 'section_name',
                            'old': db_section_name, 'new': ui_section_name
                        })
                        opt_has_changes = True
                    
                    if ui_section_desc != db_section_desc:
                        oa_field_changes.append({
                            'entity_id': opt_id, 'entity_name': entity_name,
                            'field': 'section_description',
                            'old': db_section_desc[:50] + '...' if len(db_section_desc) > 50 else db_section_desc,
                            'new': ui_section_desc[:50] + '...' if len(ui_section_desc) > 50 else ui_section_desc
                        })
                        opt_has_changes = True
                    
                    if ui_option_key != db_option_key:
                        oa_field_changes.append({
                            'entity_id': opt_id, 'entity_name': entity_name,
                            'field': 'option_key',
                            'old': db_option_key, 'new': ui_option_key
                        })
                        opt_has_changes = True
                    
                    if ui_options_str != db_options_str:
                        oa_field_changes.append({
                            'entity_id': opt_id, 'entity_name': entity_name,
                            'field': 'options',
                            'old': db_options_str, 'new': ui_options_str
                        })
                        opt_has_changes = True
                    
                    if ui_selected_str != db_selected_str:
                        oa_field_changes.append({
                            'entity_id': opt_id, 'entity_name': entity_name,
                            'field': 'selected_options',
                            'old': db_selected_str, 'new': ui_selected_str
                        })
                        opt_has_changes = True
                    
                    if opt_has_changes:
                        try:
                            # Convert lists to SQL array literals
                            # Build SQL array syntax: ARRAY('item1', 'item2', 'item3')
                            options_array_items = [f"'{item.replace(chr(39), chr(39)*2)}'" for item in ui_options_list]
                            options_sql = f"ARRAY({', '.join(options_array_items)})" if options_array_items else "ARRAY()"
                            
                            selected_array_items = [f"'{item.replace(chr(39), chr(39)*2)}'" for item in ui_selected_list]
                            selected_sql = f"ARRAY({', '.join(selected_array_items)})" if selected_array_items else "ARRAY()"
                            
                            oa_opt_update = f"""
                                UPDATE {oa_options_table}
                                SET section_name = '{ui_section_name.replace("'", "''")}',
                                    section_description = '{ui_section_desc.replace("'", "''")}',
                                    option_key = '{ui_option_key.replace("'", "''")}',
                                    options = {options_sql},
                                    selected_options = {selected_sql},
                                    last_updated_by_principal = current_user(),
                                    last_updated_ts = current_timestamp()
                                WHERE operational_agreement_id = '{oa_id}' AND oa_options_id = '{opt_id}'
                            """
                            print(f"SAVE DEBUG: Executing OA option UPDATE for {opt_id[:8]}")
                            print(f"  options_sql: {options_sql}")
                            print(f"  selected_sql: {selected_sql}")
                            result = client.execute_query(oa_opt_update, raise_on_error=True)
                            oa_updated_count += 1
                            print(f"SAVE: Updated OA option {ui_section_name or opt_id[:8]} - result: {result}")
                        except Exception as oa_opt_err:
                            print(f"SAVE ERROR: Could not save OA option: {oa_opt_err}")
                            import traceback
                            traceback.print_exc()
                    else:
                        print(f"SAVE: No changes detected for OA option {opt_id[:8]}, skipping update")
                
                # ========================================
                # Step 3.6: Compare and save OA Other (only if changed)
                # Schema: section_name, options, selected_options (same as OA Options)
                # ========================================
                print(f"SAVE DEBUG: About to process {len(oa_other)} OA other items from workspace")
                for oa_item in oa_other:
                    item_id = oa_item.get("oa_other_id", "")
                    if not item_id:
                        continue
                    
                    db_item = oa_db_other.get(item_id, {})
                    if not db_item:
                        print(f"SAVE DEBUG: OA Other {item_id[:8]} not found in DB, skipping")
                        continue  # Skip if not found in DB
                    
                    # Get UI selected_options (array) and normalize (same as OA Options)
                    ui_selected = oa_item.get("selected_options", [])
                    print(f"SAVE DEBUG: OA Other {item_id[:8]} UI selected_options type={type(ui_selected)}, raw value={ui_selected}")
                    
                    if isinstance(ui_selected, list):
                        ui_selected_list = sorted([str(s).strip() for s in ui_selected if str(s).strip()])
                        ui_selected_str = ",".join(ui_selected_list)
                    else:
                        ui_selected_raw = str(ui_selected) if ui_selected else ""
                        ui_selected_list = sorted([s.strip() for s in ui_selected_raw.split(',') if s.strip()])
                        ui_selected_str = ",".join(ui_selected_list)
                    
                    # Get DB values (already normalized from fetch)
                    db_selected_str = str(db_item.get('selected_options', '') or '')
                    section_name = db_item.get('section_name', item_id[:8])
                    
                    # Compare
                    item_has_changes = (ui_selected_str != db_selected_str)
                    
                    # Debug: Log comparison
                    print(f"SAVE DEBUG OA Other comparison for {item_id[:8]} ({section_name}):")
                    print(f"  selected: UI='{ui_selected_str}' vs DB='{db_selected_str}' | match={ui_selected_str == db_selected_str}")
                    
                    if item_has_changes:
                        try:
                            # Convert list to SQL array literal (same as OA Options)
                            selected_array_items = [f"'{item.replace(chr(39), chr(39)*2)}'" for item in ui_selected_list]
                            selected_sql = f"ARRAY({', '.join(selected_array_items)})" if selected_array_items else "ARRAY()"
                            
                            oa_other_update = f"""
                                UPDATE {oa_other_table}
                                SET selected_options = {selected_sql},
                                    last_updated_by_principal = current_user(),
                                    last_updated_ts = current_timestamp()
                                WHERE operational_agreement_id = '{oa_id}' AND oa_other_id = '{item_id}'
                            """
                            print(f"SAVE DEBUG: Executing OA other UPDATE for {item_id[:8]}")
                            print(f"  selected_sql: {selected_sql}")
                            client.execute_query(oa_other_update, raise_on_error=True)
                            oa_updated_count += 1
                            oa_field_changes.append({
                                'entity_id': item_id,
                                'entity_name': f'OA Other: {section_name}',
                                'field': 'selected_options',
                                'old': db_selected_str,
                                'new': ui_selected_str
                            })
                            print(f"SAVE: Updated OA Other item {section_name}")
                        except Exception as oa_other_err:
                            print(f"SAVE ERROR: Could not save OA other item: {oa_other_err}")
                            import traceback
                            traceback.print_exc()
                    else:
                        print(f"SAVE: No changes detected for OA Other {item_id[:8]}, skipping update")
                
                print(f"SAVE: OA data saved - {oa_updated_count} records updated, {len(oa_field_changes)} field changes")
                
                # ========================================
                # Step 3.7: Log OA changes to activity log
                # ========================================
                # Log using common helper function
                log_activity_for_save(client, dta_id, "operational_agreements", oa_updated_count, oa_field_changes)
        
        # ========================================
        # Step 3.8: Save Codelists (CL) data to Silver
        # ========================================
        cl_updated_count = 0
        cl_field_changes = []
        
        cl_entities = ws.get("entities", {}).get("CL", [])
        if cl_entities:
            print(f"SAVE: Processing {len(cl_entities)} codelist entries...")
            
            cl_silver_table = f"{catalog}.{silver_schema}.md_codelists_normalized"
            
            # Group workspace codelists by transfer_variable_name (ref)
            # Workspace format: {ref, code, text} - one row per code value
            # DB format: {transfer_variable_name, values: [...]} - one row per variable
            cl_by_ref = {}
            for cl in cl_entities:
                ref = cl.get("ref", "")
                if ref:
                    if ref not in cl_by_ref:
                        cl_by_ref[ref] = []
                    code = cl.get("code", "")
                    if code:  # Only include non-empty codes
                        cl_by_ref[ref].append(code)
            
            print(f"SAVE: CL grouped by ref - {len(cl_by_ref)} unique transfer variables")
            
            # Fetch current DB values
            cl_db_values = {}
            try:
                cl_fetch_query = f"""
                    SELECT codelist_id, transfer_variable_name, values
                    FROM {cl_silver_table}
                    WHERE dta_id = '{dta_id}'
                """
                cl_db_results = client.execute_query(cl_fetch_query, raise_on_error=False)
                for row in cl_db_results or []:
                    ref = row.get('transfer_variable_name', '')
                    if ref:
                        db_values = row.get('values', []) or []
                        if isinstance(db_values, str):
                            try:
                                import json
                                db_values = json.loads(db_values)
                            except:
                                db_values = [v.strip() for v in db_values.split(',') if v.strip()]
                        cl_db_values[ref] = {
                            'codelist_id': row.get('codelist_id', ''),
                            'values': sorted(db_values) if isinstance(db_values, list) else []
                        }
                print(f"SAVE: Fetched {len(cl_db_values)} existing codelist records from DB")
            except Exception as cl_fetch_err:
                print(f"SAVE: Could not fetch codelist values: {cl_fetch_err}")
            
            # Compare and update changed codelists
            for ref, ui_codes in cl_by_ref.items():
                ui_codes_sorted = sorted(ui_codes)
                
                if ref in cl_db_values:
                    # Existing codelist - check for changes
                    db_record = cl_db_values[ref]
                    db_codes_sorted = db_record.get('values', [])
                    
                    if ui_codes_sorted != db_codes_sorted:
                        # Values changed - update
                        codelist_id = db_record.get('codelist_id', '')
                        if codelist_id:
                            try:
                                # Build array literal
                                values_escaped = [v.replace("'", "''") for v in ui_codes_sorted]
                                values_literal = "ARRAY(" + ", ".join(f"'{v}'" for v in values_escaped) + ")"
                                
                                cl_update_query = f"""
                                    UPDATE {cl_silver_table}
                                    SET values = {values_literal},
                                        last_updated_by_principal = current_user(),
                                        last_updated_ts = current_timestamp()
                                    WHERE codelist_id = '{codelist_id}'
                                """
                                client.execute_query(cl_update_query, raise_on_error=False)
                                cl_updated_count += 1
                                
                                # Track changes for activity log
                                cl_field_changes.append({
                                    'entity_id': codelist_id,
                                    'entity_name': ref,
                                    'field': 'values',
                                    'old': ', '.join(db_codes_sorted[:5]) + ('...' if len(db_codes_sorted) > 5 else ''),
                                    'new': ', '.join(ui_codes_sorted[:5]) + ('...' if len(ui_codes_sorted) > 5 else '')
                                })
                                print(f"SAVE: Updated codelist {ref}")
                            except Exception as cl_update_err:
                                print(f"SAVE: Warning - Could not update codelist {ref}: {cl_update_err}")
                else:
                    # New codelist - insert
                    try:
                        import uuid
                        new_cl_id = str(uuid.uuid4())
                        values_escaped = [v.replace("'", "''") for v in ui_codes_sorted]
                        values_literal = "ARRAY(" + ", ".join(f"'{v}'" for v in values_escaped) + ")"
                        
                        # Get trial_id, data_stream_type, data_provider_name from DTA
                        dta_info_query = f"""
                            SELECT trial_id, data_stream_type, data_provider_name
                            FROM {dta_table}
                            WHERE dta_id = '{dta_id}'
                        """
                        dta_info = client.execute_query(dta_info_query, raise_on_error=False)
                        if dta_info:
                            trial_id = dta_info[0].get('trial_id', '')
                            data_stream_type = dta_info[0].get('data_stream_type', '')
                            data_provider_name = dta_info[0].get('data_provider_name', '')
                        else:
                            trial_id = ''
                            data_stream_type = ''
                            data_provider_name = ''
                        
                        ref_escaped = ref.replace("'", "''")
                        
                        cl_insert_query = f"""
                            INSERT INTO {cl_silver_table} (
                                codelist_id, parent_document_id, dta_id, trial_id, 
                                data_stream_type, data_provider_name, transfer_variable_name,
                                values, status, version, version_status, is_current_draft
                            ) VALUES (
                                '{new_cl_id}', '{dta_id}', '{dta_id}', '{trial_id}',
                                '{data_stream_type}', '{data_provider_name}', '{ref_escaped}',
                                {values_literal}, 'DRAFT', '1', 'DRAFT', true
                            )
                        """
                        client.execute_query(cl_insert_query, raise_on_error=False)
                        cl_updated_count += 1
                        
                        cl_field_changes.append({
                            'entity_id': new_cl_id,
                            'entity_name': ref,
                            'field': 'CREATED',
                            'old': '(new)',
                            'new': f"{len(ui_codes_sorted)} codes"
                        })
                        print(f"SAVE: Inserted new codelist {ref}")
                    except Exception as cl_insert_err:
                        print(f"SAVE: Warning - Could not insert codelist {ref}: {cl_insert_err}")
            
            print(f"SAVE: CL data saved - {cl_updated_count} records updated/inserted")
            
            # Log CL changes using common helper function
            log_activity_for_save(client, dta_id, "codelists", cl_updated_count, cl_field_changes)
        else:
            cl_updated_count = 0
        
        # ========================================
        # Step 3.9: Save Data Ingestion Parameters (DIP) to Silver
        # ========================================
        dip_updated_count = 0
        dip_field_changes = []
        
        dip_entities = ws.get("dip", [])
        if dip_entities:
            print(f"SAVE: Processing {len(dip_entities)} DIP entries...")
            
            dip_silver_table = f"{catalog}.{silver_schema}.md_dta_data_ingestion_parameters_draft"
            
            # Get current version
            version = ws.get("version", "0.0.1")
            
            # ========================================
            # Fetch current DIP values from DB for change detection
            # ========================================
            dip_db = {}
            try:
                dip_db_query = f"""
                    SELECT data_ingestion_id, parameter_name, attribute_key, attribute_value, 
                           description, notes
                    FROM {dip_silver_table}
                    WHERE dta_id = '{dta_id}'
                """
                dip_db_rows = client.execute_query(dip_db_query)
                for row in dip_db_rows:
                    dip_id_key = row.get('data_ingestion_id')
                    if dip_id_key:
                        dip_db[dip_id_key] = {
                            'parameter_name': str(row.get('parameter_name', '') or ''),
                            'attribute_key': str(row.get('attribute_key', '') or ''),
                            'attribute_value': str(row.get('attribute_value', '') or ''),
                            'description': str(row.get('description', '') or ''),
                            'notes': str(row.get('notes', '') or '')
                        }
                print(f"SAVE: Fetched {len(dip_db)} existing DIP records from DB for dirty checking")
            except Exception as dip_fetch_err:
                print(f"SAVE: Warning - Could not fetch DIP from DB: {dip_fetch_err}")
            
            # ========================================
            # Process each DIP entity with change detection
            # ========================================
            for dip in dip_entities:
                dip_id = dip.get("_data_ingestion_id", "")
                param_name = (dip.get("parameter_name") or "").replace("'", "''")
                attr_key = (dip.get("attribute_key") or "").replace("'", "''")
                attr_value = (dip.get("attribute_value") or "").replace("'", "''")
                description = (dip.get("description") or "").replace("'", "''")
                notes = (dip.get("notes") or "").replace("'", "''")
                is_new = dip.get("_is_new", False)
                
                if not dip_id:
                    continue
                
                if is_new or dip_id.startswith("new_"):
                    # INSERT new record
                    import uuid
                    new_dip_id = str(uuid.uuid4())
                    
                    dip_insert_query = f"""
                        INSERT INTO {dip_silver_table} (
                            data_ingestion_id,
                            parent_document_id,
                            dta_id,
                            parameter_name,
                            attribute_key,
                            attribute_value,
                            description,
                            notes,
                            version,
                            version_status,
                            is_current_draft,
                            created_by_principal,
                            created_ts,
                            last_updated_by_principal,
                            last_updated_ts
                        ) VALUES (
                            '{new_dip_id}',
                            '{dta_id}',
                            '{dta_id}',
                            '{param_name}',
                            '{attr_key}',
                            '{attr_value}',
                            '{description}',
                            '{notes}',
                            '{version}',
                            'DRAFT',
                            true,
                            current_user(),
                            current_timestamp(),
                            current_user(),
                            current_timestamp()
                        )
                    """
                    try:
                        client.execute_query(dip_insert_query, raise_on_error=False)
                        dip_updated_count += 1
                        
                        dip_field_changes.append({
                            'entity_id': new_dip_id,
                            'entity_name': param_name,
                            'field': 'CREATED',
                            'old_value': None,
                            'new_value': f"{attr_key}={attr_value}"
                        })
                        print(f"SAVE: Inserted new DIP {param_name}: {attr_key}={attr_value}")
                    except Exception as dip_insert_err:
                        print(f"SAVE: Warning - Could not insert DIP: {dip_insert_err}")
                else:
                    # ========================================
                    # UPDATE with change detection (dirty checking)
                    # ========================================
                    db_dip = dip_db.get(dip_id, {})
                    if not db_dip:
                        print(f"SAVE: DIP {dip_id[:8]} not found in DB, skipping update")
                        continue
                    
                    # Normalize values for comparison (handle None, whitespace, and quotes)
                    def normalize_dip_value(val):
                        if val is None or val == 'None':
                            return ''
                        return str(val).replace("''", "'").strip()
                    
                    db_param_name = normalize_dip_value(db_dip.get('parameter_name', ''))
                    db_attr_key = normalize_dip_value(db_dip.get('attribute_key', ''))
                    db_attr_value = normalize_dip_value(db_dip.get('attribute_value', ''))
                    db_description = normalize_dip_value(db_dip.get('description', ''))
                    db_notes = normalize_dip_value(db_dip.get('notes', ''))
                    
                    ui_param_name = normalize_dip_value(param_name)
                    ui_attr_key = normalize_dip_value(attr_key)
                    ui_attr_value = normalize_dip_value(attr_value)
                    ui_description = normalize_dip_value(description)
                    ui_notes = normalize_dip_value(notes)
                    
                    # Debug logging for comparison
                    print(f"\nDIP DIRTY CHECK {dip_id[:8]}:")
                    print(f"  param_name: UI='{ui_param_name}' vs DB='{db_param_name}' | match={ui_param_name == db_param_name}")
                    print(f"  attr_key: UI='{ui_attr_key}' vs DB='{db_attr_key}' | match={ui_attr_key == db_attr_key}")
                    print(f"  attr_value: UI='{ui_attr_value}' vs DB='{db_attr_value}' | match={ui_attr_value == db_attr_value}")
                    print(f"  description: UI='{ui_description[:30]}...' vs DB='{db_description[:30]}...' | match={ui_description == db_description}")
                    
                    # Detect changes
                    dip_has_changes = False
                    entity_name = f'DIP: {ui_param_name or db_param_name or dip_id[:8]}'
                    
                    if ui_param_name != db_param_name:
                        dip_field_changes.append({
                            'entity_id': dip_id, 'entity_name': entity_name,
                            'field': 'parameter_name',
                            'old_value': db_param_name, 'new_value': ui_param_name
                        })
                        dip_has_changes = True
                    
                    if ui_attr_key != db_attr_key:
                        dip_field_changes.append({
                            'entity_id': dip_id, 'entity_name': entity_name,
                            'field': 'attribute_key',
                            'old_value': db_attr_key, 'new_value': ui_attr_key
                        })
                        dip_has_changes = True
                    
                    if ui_attr_value != db_attr_value:
                        dip_field_changes.append({
                            'entity_id': dip_id, 'entity_name': entity_name,
                            'field': 'attribute_value',
                            'old_value': db_attr_value, 'new_value': ui_attr_value
                        })
                        dip_has_changes = True
                    
                    if ui_description != db_description:
                        dip_field_changes.append({
                            'entity_id': dip_id, 'entity_name': entity_name,
                            'field': 'description',
                            'old_value': db_description[:50] + '...' if len(db_description) > 50 else db_description,
                            'new_value': ui_description[:50] + '...' if len(ui_description) > 50 else ui_description
                        })
                        dip_has_changes = True
                    
                    if ui_notes != db_notes:
                        dip_field_changes.append({
                            'entity_id': dip_id, 'entity_name': entity_name,
                            'field': 'notes',
                            'old_value': db_notes[:50] + '...' if len(db_notes) > 50 else db_notes,
                            'new_value': ui_notes[:50] + '...' if len(ui_notes) > 50 else ui_notes
                        })
                        dip_has_changes = True
                    
                    # Only update if there are actual changes
                    if dip_has_changes:
                        dip_update_query = f"""
                            UPDATE {dip_silver_table}
                            SET parameter_name = '{param_name}',
                                attribute_key = '{attr_key}',
                                attribute_value = '{attr_value}',
                                description = '{description}',
                                notes = '{notes}',
                                last_updated_by_principal = current_user(),
                                last_updated_ts = current_timestamp()
                            WHERE data_ingestion_id = '{dip_id}'
                        """
                        try:
                            client.execute_query(dip_update_query, raise_on_error=False)
                            dip_updated_count += 1
                            print(f"SAVE: Updated DIP {ui_param_name}: {ui_attr_key}={ui_attr_value}")
                        except Exception as dip_update_err:
                            print(f"SAVE: Warning - Could not update DIP {dip_id}: {dip_update_err}")
                    else:
                        print(f"SAVE: No changes detected for DIP {dip_id[:8]}, skipping update")
            
            print(f"SAVE: DIP data saved - {dip_updated_count} records updated/inserted")
            
            # Log DIP changes (only if there were actual changes)
            if dip_field_changes:
                log_activity_for_save(client, dta_id, "data_ingestion_parameters", dip_updated_count, dip_field_changes)
        else:
            dip_updated_count = 0
        
        # ========================================
        # Step 4: Update DTA's last_updated_ts
        # ========================================
        dta_update_query = f"""
            UPDATE {dta_table}
            SET last_updated_ts = current_timestamp(),
                last_updated_by_principal = current_user()
            WHERE dta_id = '{dta_id}'
        """
        try:
            client.execute_query(dta_update_query, raise_on_error=True)
            print(f"SAVE: Updated DTA timestamp")
        except Exception as dta_error:
            print(f"Warning: Could not update DTA timestamp: {dta_error}")
        
        # Clear pending changes flag and remove workspace (will be reloaded fresh)
        ws["has_pending_changes"] = False
        
        # Remove from workspaces so edit_draft will reload fresh from DB
        if key in WORKSPACES:
            del WORKSPACES[key]
        
        total_updated = updated_count + tc_updated_count + oa_updated_count + cl_updated_count + dip_updated_count
        print(f"SAVE: Draft saved successfully for DTA {dta_id} (TV: {updated_count}, TC: {tc_updated_count}, OA: {oa_updated_count}, CL: {cl_updated_count}, DIP: {dip_updated_count})")
        
        # Build success message
        msg_parts = ["Draft saved successfully."]
        if updated_count > 0:
            msg_parts.append(f"{updated_count} transfer variable(s)")
        if tc_updated_count > 0:
            msg_parts.append(f"{tc_updated_count} test concept(s)")
        if oa_updated_count > 0:
            msg_parts.append(f"{oa_updated_count} OA item(s)")
        if cl_updated_count > 0:
            msg_parts.append(f"{cl_updated_count} codelist(s)")
        if dip_updated_count > 0:
            msg_parts.append(f"{dip_updated_count} data ingestion parameter(s)")
        if total_updated > 0:
            msg = f"{msg_parts[0]} Updated {', '.join(msg_parts[1:])}."
        else:
            msg = "Draft saved. No changes detected."
        
        return jsonify({"ok": True, "msg": msg, "dta_id": dta_id})
        
    except Exception as e:
        print(f"SAVE ERROR: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "msg": f"Error saving draft: {str(e)}"}), 500

@app.route("/api/history/<dta_id>", methods=["GET"])
def get_history(dta_id):
    """Get complete activity history for a DTA from the activity log."""
    from api.activity_log_api import get_activity_history
    
    try:
        result = get_activity_history(dta_id)
        return jsonify(result)
        
    except Exception as e:
        print(f"HISTORY ERROR: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'ok': False, 'msg': str(e)}), 500

# =============================================================================
# COMMENTS API - Threaded discussions on library items
# =============================================================================

@app.route("/api/comments/<dta_id>/<library_type>/<item_id>", methods=["GET"])
def api_get_comments(dta_id, library_type, item_id):
    """Get all comment threads for a specific library item."""
    from api.comments_api import get_comments_for_item
    
    try:
        result = get_comments_for_item(dta_id, library_type, item_id)
        return jsonify(result)
    except Exception as e:
        print(f"GET COMMENTS ERROR: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 500


@app.route("/api/comments", methods=["POST"])
def api_create_comment():
    """Create a new comment or reply to an existing thread."""
    from api.comments_api import create_comment
    
    try:
        data = request.get_json() or {}
        
        # Required fields
        dta_id = data.get('dta_id')
        library_type = data.get('library_type')
        item_id = data.get('item_id')
        comment_text = data.get('text', '').strip()
        
        if not all([dta_id, library_type, item_id, comment_text]):
            return jsonify({'ok': False, 'error': 'Missing required fields'}), 400
        
        # Get current user (hardcoded for now)
        current_user_email = "awagle4@its.jnj.com"
        current_user_name = "Arun Wagle"
        
        # Determine role (in production, from auth)
        # For now, assume JNJ_DAE - could be passed from frontend
        commenter_role = data.get('role', 'JNJ_DAE')
        
        result = create_comment(
            dta_id=dta_id,
            library_type=library_type,
            item_id=item_id,
            item_name=data.get('item_name', ''),
            comment_text=comment_text,
            commenter_role=commenter_role,
            commenter_principal=current_user_email,
            commenter_name=current_user_name,
            parent_comment_id=data.get('parent_comment_id'),
            version_tag=data.get('version_tag')
        )
        
        return jsonify(result)
        
    except Exception as e:
        print(f"CREATE COMMENT ERROR: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 500


@app.route("/api/comments/<thread_id>/resolve", methods=["POST"])
def api_resolve_thread(thread_id):
    """Resolve (close) a comment thread."""
    from api.comments_api import resolve_thread
    
    try:
        # Get current user (hardcoded for now)
        current_user_email = "awagle4@its.jnj.com"
        
        result = resolve_thread(thread_id, current_user_email)
        return jsonify(result)
        
    except Exception as e:
        print(f"RESOLVE THREAD ERROR: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 500


@app.route("/api/comments/<thread_id>/reopen", methods=["POST"])
def api_reopen_thread(thread_id):
    """Reopen a resolved comment thread."""
    from api.comments_api import reopen_thread
    
    try:
        # Get current user (hardcoded for now)
        current_user_email = "awagle4@its.jnj.com"
        
        result = reopen_thread(thread_id, current_user_email)
        return jsonify(result)
        
    except Exception as e:
        print(f"REOPEN THREAD ERROR: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 500


@app.route("/api/comments/counts/<dta_id>/<library_type>", methods=["POST"])
def api_get_comment_counts(dta_id, library_type):
    """Get comment counts for multiple items (for badge display)."""
    from api.comments_api import get_comment_counts_for_items
    
    try:
        data = request.get_json() or {}
        item_ids = data.get('item_ids', [])
        
        counts = get_comment_counts_for_items(dta_id, library_type, item_ids)
        return jsonify({'ok': True, 'counts': counts})
        
    except Exception as e:
        print(f"GET COMMENT COUNTS ERROR: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 500

# =============================================================================
# END COMMENTS API
# =============================================================================

@app.route("/api/approvers", methods=["GET"])
def get_approvers():
    """Return list of available approvers for each role"""
    approvers = {
        "jnj_dae": [
            {"id": "jnj_1", "name": "Sarah Johnson", "title": "DAE Lead", "email": "sarah.johnson@jnj.com"},
            {"id": "jnj_2", "name": "Michael Chen", "title": "Senior DAE", "email": "michael.chen@jnj.com"},
            {"id": "jnj_3", "name": "Emily Rodriguez", "title": "DAE Manager", "email": "emily.rodriguez@jnj.com"}
        ],
        "vendor": [
            {"id": "vnd_1", "name": "Alex Kumar", "title": "Data Manager", "email": "alex.kumar@vendor.com"},
            {"id": "vnd_2", "name": "David Park", "title": "Senior Data Scientist", "email": "david.park@vendor.com"},
            {"id": "vnd_3", "name": "Jennifer Lee", "title": "QC Lead", "email": "jennifer.lee@vendor.com"}
        ],
        "librarian": [
            {"id": "lib_1", "name": "Lisa Wong", "title": "Study Librarian", "email": "lisa.wong@jnj.com"},
            {"id": "lib_2", "name": "Robert Martinez", "title": "Senior Librarian", "email": "robert.martinez@jnj.com"},
            {"id": "lib_3", "name": "Patricia Taylor", "title": "Data Librarian", "email": "patricia.taylor@jnj.com"}
        ]
    }
    return jsonify({"success": True, "approvers": approvers})

@app.route("/api/workspace/<path:key>/submit", methods=["POST"])
def api_submit(key):
    # Get request data
    request_data = request.get_json() or {}
    approvers_list = request_data.get("approvers", [])
    
    # Call API to submit for approval
    result = api.submit_for_approval(key, approvers_list)
    
    if result["success"]:
        return jsonify({"success": True, "msg": result.get("message", "Submitted for approval.")})
    else:
        return jsonify({"ok": False, "msg": result.get("error", "Submission failed")}), 404

@app.route("/api/workspace/<path:key>/publish", methods=["POST"])
def api_publish(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    next_major = ws["base_major"] + 1
    return jsonify({
        "ok": True,
        "msg": f"Publishing Major v{next_major} (simulated). Prior is_current=false, SCD2 rows written."
    })

@app.route("/api/workspace/<path:key>/comment", methods=["POST"])
def api_comment(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    text = (request.json or {}).get("text", "").strip()
    if not text:
        return jsonify({"ok": False, "msg": "empty comment"}), 400
    ws["comments"].append({
        "text": text,
        "user": "you@jnj.com",
        "ts": datetime.utcnow().isoformat()
    })
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/entity/<tab>/<int:idx>/<col>", methods=["POST"])
def api_update_cell(key, tab, idx, col):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    value = (request.json or {}).get("value")
    try:
        ws["entities"][tab][idx][col] = value
        # Mark workspace as having pending changes
        ws["has_pending_changes"] = True
    except Exception:
        return jsonify({"ok": False, "msg": "bad index/column"}), 400
    return jsonify({"ok": True})

def label_for_tab(t):
    return {
        "VT": "Visit and Timepoints",
        "DIP": "Data Ingestion Parameters",
        "TV": "Transfer Variables",
        "CL": "Code Lists",
        "TC": "Test Concepts",
        "META": "Metadata",
        "OA": "Operational Agreements",
    }.get(t, t)

# === TC (Test Concepts) endpoints ===

@app.route("/api/workspace/<path:key>/tc/<int:idx>/edit", methods=["POST"])
def api_tc_edit(key, idx):
    import copy
    ws = WORKSPACES.get(key)
    if not ws: 
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    try:
        # Store original values for cancel/restore
        ws["tc_state"][idx]["original_values"] = copy.deepcopy(ws["entities"]["TC"][idx])
        ws["tc_state"][idx]["editable"] = True
        ws["tc_state"][idx]["approved"] = False  # editing resets approval
        # Mark as having pending changes when entering edit mode
        ws["has_pending_changes"] = True
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tc/<int:idx>/save", methods=["POST"])
def api_tc_save(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    try:
        # Clear the original values backup (changes are now permanent)
        ws["tc_state"][idx].pop("original_values", None)
        ws["tc_state"][idx]["editable"] = False
        # Mark workspace as having pending changes (needs Save Draft to persist to DB)
        ws["has_pending_changes"] = True
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tc/<int:idx>/cancel", methods=["POST"])
def api_tc_cancel(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    # Validate index
    if idx < 0 or idx >= len(ws.get("entities", {}).get("TC", [])):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    
    # Check if this is a new row (not yet saved to DB)
    is_new_row = ws.get("tc_state", [{}])[idx].get("is_new", False) or ws["entities"]["TC"][idx].get("_is_new", False)
    
    if is_new_row:
        # For new rows, cancel means delete the row entirely
        print(f"TC-CANCEL: Removing new row at index {idx}")
        ws["entities"]["TC"].pop(idx)
        if "tc_state" in ws and idx < len(ws["tc_state"]):
            ws["tc_state"].pop(idx)
        return jsonify({"ok": True, "deleted": True, "count": len(ws["entities"]["TC"])})
    
    # For existing rows, restore original values if they exist
    try:
        original = ws["tc_state"][idx].get("original_values")
        if original:
            ws["entities"]["TC"][idx] = original
            ws["tc_state"][idx].pop("original_values", None)
        ws["tc_state"][idx]["editable"] = False
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    
    return jsonify({"ok": True, "deleted": False})

@app.route("/api/workspace/<path:key>/tc/<int:idx>/approve", methods=["POST"])
def api_tc_approve(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    try:
        ws["tc_state"][idx]["approved"] = True
        ws["tc_state"][idx]["editable"] = False
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tc/<int:idx>/comment", methods=["POST"])
def api_tc_comment(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    payload = request.json or {}
    text = (payload.get("text") or "").strip()
    if not text:
        return jsonify({"ok": False, "msg": "empty comment"}), 400
    try:
        ws["tc_state"][idx]["comments"].insert(0, {
            "user": payload.get("user") or "vendor@example.com",
            "ts": datetime.utcnow().isoformat(),
            "text": text
        })
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

# === Transfer Variables (TV) endpoints ===

@app.route("/api/workspace/<path:key>/tv/select/<int:idx>", methods=["POST"])
def api_tv_select(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    _ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    ws["tv_selected"] = idx
    return jsonify({"ok": True, "selected": idx})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/update", methods=["POST"])
def api_tv_update(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    _ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    payload = request.json or {}
    for k in ["FILE_ORDER","FORMAT","LENGTH","REQUIRED","IS_KEY","TEST_CONCEPTS","EXAMPLE_VALUES"]:
        if k in payload:
            ws["entities"]["TV"][idx][k] = payload[k]
    return jsonify({"ok": True, "row": ws["entities"]["TV"][idx]})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/edit", methods=["POST"])
def api_tv_edit(key, idx):
    import copy
    print(f"API tv_edit called: key={key}, idx={idx}")
    ws = WORKSPACES.get(key)
    if not ws:
        print(f"Workspace not found: {key}")
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    _ensure_tv_init(ws)
    print(f"TV state before edit: {ws.get('tv_state')}")
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        print(f"Bad index: {idx}, TV length: {len(ws['entities']['TV'])}")
        return jsonify({"ok": False, "msg": "bad index"}), 400
    
    # Store original values for cancel/restore
    ws["tv_state"][idx]["original_values"] = copy.deepcopy(ws["entities"]["TV"][idx])
    ws["tv_state"][idx]["editable"] = True
    ws["tv_state"][idx]["approved"] = False  # editing resets approval
    # Mark as having pending changes when entering edit mode
    ws["has_pending_changes"] = True
    print(f"TV state after edit: {ws['tv_state'][idx]}")
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/save", methods=["POST"])
def api_tv_save(key, idx):
    """Save a TV row's edit state. Field values are already synced via updateCell()."""
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    _ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    
    # Clear the original values backup (changes are now permanent)
    ws["tv_state"][idx].pop("original_values", None)
    ws["tv_state"][idx]["editable"] = False
    # Mark workspace as having pending changes (needs Save Draft to persist to DB)
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/cancel", methods=["POST"])
def api_tv_cancel(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    _ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    
    # Check if this is a new row (not yet saved to DB)
    is_new_row = ws["tv_state"][idx].get("is_new", False) or ws["entities"]["TV"][idx].get("_is_new", False)
    
    if is_new_row:
        # For new rows, cancel means delete the row entirely
        print(f"TV-CANCEL: Removing new row at index {idx}")
        ws["entities"]["TV"].pop(idx)
        ws["tv_state"].pop(idx)
        return jsonify({"ok": True, "deleted": True, "count": len(ws["entities"]["TV"])})
    
    # For existing rows, restore original values if they exist
    original = ws["tv_state"][idx].get("original_values")
    if original:
        ws["entities"]["TV"][idx] = original
        ws["tv_state"][idx].pop("original_values", None)
    
    ws["tv_state"][idx]["editable"] = False
    return jsonify({"ok": True, "deleted": False})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/delete", methods=["POST"])
def api_tv_delete(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    _ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    # Delete the row from entities and state
    ws["entities"]["TV"].pop(idx)
    ws["tv_state"].pop(idx)
    return jsonify({"ok": True, "count": len(ws["entities"]["TV"])})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/approve", methods=["POST"])
def api_tv_approve(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    _ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    ws["tv_state"][idx]["approved"] = True
    ws["tv_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/comment", methods=["POST"])
def api_tv_comment(key, idx):
    """Update vendor comment in-memory. Save Draft will persist to DB."""
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    _ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    
    payload = request.json or {}
    text = (payload.get("text") or "").strip()
    # Allow empty text (to clear comment)
    
    # Update in-memory entity
    tv_row = ws["entities"]["TV"][idx]
    tv_row["VENDOR_COMMENT"] = text
    
    # Mark as having pending changes
    ws["has_pending_changes"] = True
    
    print(f"  ✓ Vendor comment updated in-memory for row {idx}: {text[:50] if text else '(cleared)'}...")
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/add", methods=["POST"])
def api_tv_add(key):
    import uuid
    
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    _ensure_tv_init(ws)
    
    # Get domain_info from request body (pre-populate from selected filter)
    req_data = request.get_json() or {}
    domain_info = req_data.get("domain_info", "")
    
    new_idx = len(ws["entities"]["TV"]) + 1
    
    # Generate a temporary UUID for the new row
    # This will be replaced with a real ID when saved to DB
    temp_id = f"new_{str(uuid.uuid4())}"
    
    row = {
        "_transfer_variable_id": temp_id,  # Temporary ID for new row
        "_is_new": True,  # Flag to indicate this is a new row (needs INSERT not UPDATE)
        "LABEL": "",  # Empty - user to fill
        "FILE_ORDER": new_idx,
        "FORMAT": "",  # Empty - user to fill
        "LENGTH": "",  # Empty - user to fill
        "REQUIRED": False,  # Boolean default
        "TEST_CONCEPTS": "",
        "EXAMPLE_VALUES": "",
        "DOMAIN_INFO": domain_info,  # Pre-populated from dropdown selection
        "VENDOR_COMMENT": "",  # Empty - user to fill
        "ROW_STATUS": "DRAFT",  # New rows start as draft
        "IS_KEY": False,  # Boolean default
        "DESCRIPTION": ""  # Empty - user to fill
    }
    ws["entities"]["TV"].append(row)
    ws["tv_state"].append({"approved": False, "editable": True, "comments": [], "is_new": True})  # New row is editable
    ws["tv_selected"] = new_idx - 1
    ws["has_pending_changes"] = True  # Mark as having changes
    
    print(f"TV-ADD: Added new variable at index {new_idx - 1} with temp_id {temp_id}")
    return jsonify({"ok": True, "index": ws["tv_selected"], "row": row})

@app.route("/api/workspace/<path:key>/tc/add", methods=["POST"])
def api_tc_add(key):
    import uuid
    
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    # Get the first row to determine column structure
    if not ws.get("entities", {}).get("TC"):
        return jsonify({"ok": False, "msg": "No TC data exists"}), 400
    
    # Create a blank row with all columns set to empty strings (for display)
    first_row = ws["entities"]["TC"][0]
    row = {k: "" for k in first_row.keys()}  # Initialize all to empty string
    
    # Generate a temporary UUID for the new row
    # This will be replaced with a real ID when saved to DB
    temp_id = f"new_{str(uuid.uuid4())}"
    
    # Set required metadata fields for new rows
    row["_test_concept_id"] = temp_id  # Temporary ID for new row
    row["_is_new"] = True  # Flag to indicate this is a new row (needs INSERT not UPDATE)
    row["_vendor_comment"] = ""  # Empty - user to fill
    row["_notes"] = ""  # Empty - user to fill
    row["_status"] = "DRAFT"  # New rows start as draft
    
    ws["entities"]["TC"].append(row)
    
    # Initialize tc_state if it doesn't exist
    if "tc_state" not in ws:
        ws["tc_state"] = []
    
    # Add state for the new row - set as editable by default, mark as new
    ws["tc_state"].append({"approved": False, "editable": True, "comments": [], "is_new": True})
    ws["has_pending_changes"] = True  # Mark as having changes
    
    new_idx = len(ws["entities"]["TC"]) - 1
    print(f"TC-ADD: Added new test concept at index {new_idx} with temp_id {temp_id}")
    return jsonify({"ok": True, "index": new_idx, "row": row})

# === Code Lists (CL) endpoints ===

def _get_cl_item_by_ref_idx(cl_list, ref, idx):
    """Get the idx-th item with given ref from CL list."""
    matching = [item for item in cl_list if item["ref"] == ref]
    if idx < 0 or idx >= len(matching):
        return None
    # Find the global index in cl_list
    count = 0
    for i, item in enumerate(cl_list):
        if item["ref"] == ref:
            if count == idx:
                return i, item
            count += 1
    return None

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/edit", methods=["POST"])
def api_cl_edit(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if ref not in ws.get("cl_state", {}):
        return jsonify({"ok": False, "msg": "reference not found"}), 404
    
    if idx < 0 or idx >= len(ws["cl_state"][ref]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["cl_state"][ref][idx]["editable"] = True
    # Mark as having pending changes when entering edit mode
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/save", methods=["POST"])
def api_cl_save(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    code = payload.get("code", "")
    text = payload.get("text", "")
    
    result = _get_cl_item_by_ref_idx(ws.get("entities", {}).get("CL", []), ref, idx)
    if result is None:
        return jsonify({"ok": False, "msg": "code not found"}), 404
    
    global_idx, item = result
    item["code"] = code
    item["text"] = text
    
    ws["cl_state"][ref][idx]["editable"] = False
    # Mark workspace as having pending changes (needs Save Draft to persist to DB)
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/cancel", methods=["POST"])
def api_cl_cancel(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if ref not in ws.get("cl_state", {}):
        return jsonify({"ok": False, "msg": "reference not found"}), 404
    
    if idx < 0 or idx >= len(ws["cl_state"][ref]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Simply set editable to false without saving changes
    ws["cl_state"][ref][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/approve", methods=["POST"])
def api_cl_approve(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if ref not in ws.get("cl_state", {}):
        return jsonify({"ok": False, "msg": "reference not found"}), 404
    
    if idx < 0 or idx >= len(ws["cl_state"][ref]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["cl_state"][ref][idx]["approved"] = True
    ws["cl_state"][ref][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/comment", methods=["POST"])
def api_cl_comment(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    text = payload.get("text", "")
    
    if not text:
        return jsonify({"ok": False, "msg": "comment text required"}), 400
    
    if ref not in ws.get("cl_state", {}):
        return jsonify({"ok": False, "msg": "reference not found"}), 404
    
    if idx < 0 or idx >= len(ws["cl_state"][ref]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    comment = {
        "user": "You",
        "ts": datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
        "text": text
    }
    ws["cl_state"][ref][idx]["comments"].append(comment)
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/add", methods=["POST"])
def api_cl_add(key, ref):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    cl_list = ws.get("entities", {}).get("CL", [])
    
    # Add new blank code entry
    new_item = {"ref": ref, "code": "", "text": ""}
    cl_list.append(new_item)
    
    # Initialize state for the new code
    if ref not in ws.get("cl_state", {}):
        ws["cl_state"][ref] = []
    
    ws["cl_state"][ref].append({"editable": True, "approved": False, "comments": []})
    
    return jsonify({"ok": True})


@app.route("/api/workspace/<path:key>/cl/add-new", methods=["POST"])
def api_cl_add_new(key):
    """Add a new codelist with a new transfer variable reference."""
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    ref = payload.get("ref", "").strip().upper()
    
    cl_list = ws.get("entities", {}).get("CL", [])
    existing_refs = set(item.get("ref", "") for item in cl_list)
    
    # If no ref provided, generate a placeholder name
    if not ref:
        # Generate unique placeholder: NEW_VARIABLE_1, NEW_VARIABLE_2, etc.
        counter = 1
        while f"NEW_VARIABLE_{counter}" in existing_refs:
            counter += 1
        ref = f"NEW_VARIABLE_{counter}"
    else:
        # Check if this reference already exists
        if ref in existing_refs:
            return jsonify({"ok": False, "msg": f"Transfer variable '{ref}' already has a codelist. Use 'Add Code' to add values."}), 400
    
    # Add new blank code entry for this new reference
    new_item = {"ref": ref, "code": "", "text": "", "_is_new": True}
    cl_list.append(new_item)
    
    # Initialize state for the new reference - mark as new section
    if "cl_state" not in ws:
        ws["cl_state"] = {}
    
    ws["cl_state"][ref] = [{"editable": True, "approved": False, "comments": [], "is_new_section": True}]
    
    # Track which sections are new (for editable variable name)
    if "cl_new_sections" not in ws:
        ws["cl_new_sections"] = []
    ws["cl_new_sections"].append(ref)
    
    ws["has_pending_changes"] = True
    
    return jsonify({"ok": True, "ref": ref})


@app.route("/api/workspace/<path:key>/cl/rename", methods=["POST"])
def api_cl_rename(key):
    """Rename a codelist reference (transfer variable name)."""
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    old_ref = payload.get("old_ref", "").strip()
    new_ref = payload.get("new_ref", "").strip().upper()
    
    if not old_ref or not new_ref:
        return jsonify({"ok": False, "msg": "old_ref and new_ref are required"}), 400
    
    if old_ref == new_ref:
        return jsonify({"ok": True, "msg": "No change needed"})
    
    cl_list = ws.get("entities", {}).get("CL", [])
    existing_refs = set(item.get("ref", "") for item in cl_list)
    
    # Check if new_ref already exists (and is different from old_ref)
    if new_ref in existing_refs and new_ref != old_ref:
        return jsonify({"ok": False, "msg": f"Transfer variable '{new_ref}' already exists."}), 400
    
    # Update all items with old_ref to new_ref
    for item in cl_list:
        if item.get("ref") == old_ref:
            item["ref"] = new_ref
    
    # Update cl_state
    if "cl_state" in ws and old_ref in ws["cl_state"]:
        ws["cl_state"][new_ref] = ws["cl_state"].pop(old_ref)
    
    # Update cl_new_sections if this was a new section
    if "cl_new_sections" in ws and old_ref in ws["cl_new_sections"]:
        ws["cl_new_sections"].remove(old_ref)
        ws["cl_new_sections"].append(new_ref)
    
    ws["has_pending_changes"] = True
    
    return jsonify({"ok": True, "old_ref": old_ref, "new_ref": new_ref})


# === Transfer File Keys endpoints ===

@app.route("/api/workspace/<path:key>/transfer-keys/add", methods=["POST"])
def api_add_transfer_key(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    variable = payload.get("variable", "").strip()
    
    if not variable:
        return jsonify({"ok": False, "msg": "variable name is required"}), 400
    
    # Initialize transfer_file_keys if it doesn't exist
    if "transfer_file_keys" not in ws:
        ws["transfer_file_keys"] = []
    
    # Check if variable already exists in keys
    if variable in ws["transfer_file_keys"]:
        return jsonify({"ok": False, "msg": "variable already in keys"}), 400
    
    # Verify the variable exists in TV entities
    tv_labels = [row.get("LABEL", "") for row in ws.get("entities", {}).get("TV", [])]
    if variable not in tv_labels:
        return jsonify({"ok": False, "msg": "variable not found in Transfer Variables"}), 400
    
    ws["transfer_file_keys"].append(variable)
    return jsonify({"ok": True, "keys": ws["transfer_file_keys"]})

@app.route("/api/workspace/<path:key>/transfer-keys/remove", methods=["POST"])
def api_remove_transfer_key(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    variable = payload.get("variable", "").strip()
    
    if not variable:
        return jsonify({"ok": False, "msg": "variable name is required"}), 400
    
    # Initialize transfer_file_keys if it doesn't exist
    if "transfer_file_keys" not in ws:
        ws["transfer_file_keys"] = []
    
    # Remove the variable if it exists
    if variable in ws["transfer_file_keys"]:
        ws["transfer_file_keys"].remove(variable)
        return jsonify({"ok": True, "keys": ws["transfer_file_keys"]})
    else:
        return jsonify({"ok": False, "msg": "variable not found in keys"}), 404

# === Metadata endpoints ===
@app.route("/api/workspace/<path:key>/meta/<int:idx>/edit", methods=["POST"])
def api_meta_edit(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata_state" not in ws or idx < 0 or idx >= len(ws["metadata_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Store original value for cancel/restore
    ws["metadata_state"][idx]["original_value"] = ws["metadata"][idx].get("value", "")
    ws["metadata_state"][idx]["editable"] = True
    # Mark as having pending changes when entering edit mode
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/meta/<int:idx>/save", methods=["POST"])
def api_meta_save(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata" not in ws or idx < 0 or idx >= len(ws["metadata"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    data = request.json or {}
    value = data.get("value", "")
    
    # Update the metadata value and clear backup
    ws["metadata"][idx]["value"] = value
    ws["metadata_state"][idx].pop("original_value", None)
    ws["metadata_state"][idx]["editable"] = False
    # Mark workspace as having pending changes (needs Save Draft to persist to DB)
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/meta/<int:idx>/cancel", methods=["POST"])
def api_meta_cancel(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata_state" not in ws or idx < 0 or idx >= len(ws["metadata_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Restore original value if it exists
    original = ws["metadata_state"][idx].get("original_value")
    if original is not None:
        ws["metadata"][idx]["value"] = original
        ws["metadata_state"][idx].pop("original_value", None)
    
    ws["metadata_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/meta/<int:idx>/approve", methods=["POST"])
def api_meta_approve(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata_state" not in ws or idx < 0 or idx >= len(ws["metadata_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["metadata_state"][idx]["approved"] = True
    ws["metadata_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/meta/<int:idx>/comment", methods=["POST"])
def api_meta_comment(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata_state" not in ws or idx < 0 or idx >= len(ws["metadata_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    data = request.json or {}
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"ok": False, "msg": "empty comment"}), 400
    
    comment = {
        "user": "Current User",
        "ts": datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
        "text": text
    }
    ws["metadata_state"][idx]["comments"].append(comment)
    return jsonify({"ok": True})

# === DIP (Data Ingestion Parameters) endpoints ===
@app.route("/api/workspace/<path:key>/dip/add-new", methods=["POST"])
def api_dip_add_new(key):
    """Add a new Data Ingestion Parameter row."""
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    import uuid
    
    # Initialize dip and dip_state if they don't exist
    if "dip" not in ws:
        ws["dip"] = []
    if "dip_state" not in ws:
        ws["dip_state"] = []
    
    # Create new DIP row with default values
    new_dip = {
        "_data_ingestion_id": str(uuid.uuid4()),
        "parameter_name": "",
        "attribute_key": "",
        "attribute_value": "",
        "description": "",
        "status": "PENDING",
        "notes": "",
        "vendor_comment": "",
        "_is_new": True
    }
    
    # Create state for new row - start in edit mode
    new_state = {
        "editable": True,
        "approved": False,
        "comments": [],
        "original": None  # No original to restore to
    }
    
    # Add to workspace
    ws["dip"].append(new_dip)
    ws["dip_state"].append(new_state)
    ws["has_pending_changes"] = True
    
    new_idx = len(ws["dip"]) - 1
    return jsonify({"ok": True, "idx": new_idx})


@app.route("/api/workspace/<path:key>/dip/<int:idx>/edit", methods=["POST"])
def api_dip_edit(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip" not in ws or idx < 0 or idx >= len(ws["dip"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Initialize dip_state if needed
    if "dip_state" not in ws:
        ws["dip_state"] = [{"editable": False, "approved": False, "comments": []} for _ in ws["dip"]]
    
    # Ensure dip_state has enough entries
    while len(ws["dip_state"]) <= idx:
        ws["dip_state"].append({"editable": False, "approved": False, "comments": []})
    
    # Store original values for cancel/restore
    ws["dip_state"][idx]["original"] = {
        "parameter_name": ws["dip"][idx].get("parameter_name", ""),
        "attribute_key": ws["dip"][idx].get("attribute_key", ""),
        "attribute_value": ws["dip"][idx].get("attribute_value", ""),
        "description": ws["dip"][idx].get("description", "")
    }
    ws["dip_state"][idx]["editable"] = True
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})


@app.route("/api/workspace/<path:key>/dip/<int:idx>/save", methods=["POST"])
def api_dip_save(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip" not in ws or idx < 0 or idx >= len(ws["dip"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    data = request.json or {}
    
    # Update all editable fields
    ws["dip"][idx]["parameter_name"] = data.get("parameter_name", ws["dip"][idx].get("parameter_name", ""))
    ws["dip"][idx]["attribute_key"] = data.get("attribute_key", ws["dip"][idx].get("attribute_key", ""))
    ws["dip"][idx]["attribute_value"] = data.get("attribute_value", ws["dip"][idx].get("attribute_value", ""))
    ws["dip"][idx]["description"] = data.get("description", ws["dip"][idx].get("description", ""))
    
    # Clear the _is_new flag after first save
    ws["dip"][idx]["_is_new"] = False
    
    # Clear original backup and exit edit mode
    if "dip_state" in ws and idx < len(ws["dip_state"]):
        ws["dip_state"][idx].pop("original", None)
        ws["dip_state"][idx]["editable"] = False
    
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})


@app.route("/api/workspace/<path:key>/dip/<int:idx>/cancel", methods=["POST"])
def api_dip_cancel(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip_state" not in ws or idx < 0 or idx >= len(ws["dip_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Restore original values if they exist
    original = ws["dip_state"][idx].get("original")
    if original:
        ws["dip"][idx]["parameter_name"] = original.get("parameter_name", "")
        ws["dip"][idx]["attribute_key"] = original.get("attribute_key", "")
        ws["dip"][idx]["attribute_value"] = original.get("attribute_value", "")
        ws["dip"][idx]["description"] = original.get("description", "")
        ws["dip_state"][idx].pop("original", None)
    
    # If this was a new row being cancelled (has _is_new and original is None), remove it
    if ws["dip"][idx].get("_is_new") and not original:
        ws["dip"].pop(idx)
        ws["dip_state"].pop(idx)
        return jsonify({"ok": True, "removed": True})
    
    ws["dip_state"][idx]["editable"] = False
    return jsonify({"ok": True})


@app.route("/api/workspace/<path:key>/dip/<int:idx>/delete", methods=["POST"])
def api_dip_delete(key, idx):
    """Delete a Data Ingestion Parameter row."""
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip" not in ws or idx < 0 or idx >= len(ws["dip"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Remove the row
    ws["dip"].pop(idx)
    if "dip_state" in ws and idx < len(ws["dip_state"]):
        ws["dip_state"].pop(idx)
    
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})


@app.route("/api/workspace/<path:key>/dip/<int:idx>/approve", methods=["POST"])
def api_dip_approve(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip_state" not in ws or idx < 0 or idx >= len(ws["dip_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["dip_state"][idx]["approved"] = True
    ws["dip_state"][idx]["editable"] = False
    return jsonify({"ok": True})


@app.route("/api/workspace/<path:key>/dip/<int:idx>/comment", methods=["POST"])
def api_dip_comment(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip_state" not in ws or idx < 0 or idx >= len(ws["dip_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    data = request.json or {}
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"ok": False, "msg": "empty comment"}), 400
    
    comment = {
        "user": "Current User",
        "ts": datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
        "text": text
    }
    ws["dip_state"][idx]["comments"].append(comment)
    return jsonify({"ok": True})

# === OA (Operational Agreements) endpoints ===

# OA Parent (Operational Agreement table)
@app.route("/api/workspace/<path:key>/oa/parent/edit", methods=["POST"])
def api_oa_parent_edit(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    idx = data.get("idx", -1)
    
    if "oa_parent_state" not in ws or idx < 0 or idx >= len(ws.get("oa_parent_state", [])):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["oa_parent_state"][idx]["original_value"] = ws["oa_parent"][idx].get("value", "")
    ws["oa_parent_state"][idx]["editable"] = True
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/oa/parent/save", methods=["POST"])
def api_oa_parent_save(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    idx = data.get("idx", -1)
    value = data.get("value", "")
    
    if "oa_parent" not in ws or idx < 0 or idx >= len(ws.get("oa_parent", [])):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["oa_parent"][idx]["value"] = value
    ws["oa_parent_state"][idx].pop("original_value", None)
    ws["oa_parent_state"][idx]["editable"] = False
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/oa/parent/cancel", methods=["POST"])
def api_oa_parent_cancel(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    idx = data.get("idx", -1)
    
    if "oa_parent_state" not in ws or idx < 0 or idx >= len(ws.get("oa_parent_state", [])):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    original = ws["oa_parent_state"][idx].get("original_value")
    if original is not None:
        ws["oa_parent"][idx]["value"] = original
        ws["oa_parent_state"][idx].pop("original_value", None)
    
    ws["oa_parent_state"][idx]["editable"] = False
    return jsonify({"ok": True})

# OA Attributes
@app.route("/api/workspace/<path:key>/oa/attr/edit", methods=["POST"])
def api_oa_attr_edit(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    idx = data.get("idx", -1)
    
    if "oa_attr_state" not in ws or idx < 0 or idx >= len(ws["oa_attr_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["oa_attr_state"][idx]["original_value"] = ws["oa_attr"][idx].get("value", "")
    ws["oa_attr_state"][idx]["editable"] = True
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/oa/attr/save", methods=["POST"])
def api_oa_attr_save(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    idx = data.get("idx", -1)
    value = data.get("value", "")
    
    if "oa_attr" not in ws or idx < 0 or idx >= len(ws["oa_attr"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["oa_attr"][idx]["value"] = value
    ws["oa_attr_state"][idx].pop("original_value", None)
    ws["oa_attr_state"][idx]["editable"] = False
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/oa/attr/cancel", methods=["POST"])
def api_oa_attr_cancel(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    idx = data.get("idx", -1)
    
    if "oa_attr_state" not in ws or idx < 0 or idx >= len(ws["oa_attr_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    original = ws["oa_attr_state"][idx].get("original_value")
    if original is not None:
        ws["oa_attr"][idx]["value"] = original
        ws["oa_attr_state"][idx].pop("original_value", None)
    
    ws["oa_attr_state"][idx]["editable"] = False
    return jsonify({"ok": True})

# OA Options
@app.route("/api/workspace/<path:key>/oa/options/edit", methods=["POST"])
def api_oa_options_edit(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    idx = data.get("idx", -1)
    
    if "oa_options_state" not in ws or idx < 0 or idx >= len(ws["oa_options_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Store all original field values for cancel/restore
    opt_options = ws["oa_options"][idx].get("options", [])
    opt_selected = ws["oa_options"][idx].get("selected_options", [])
    
    # Ensure we're working with lists and make deep copies
    original_data = {
        "section_name": ws["oa_options"][idx].get("section_name", ""),
        "section_description": ws["oa_options"][idx].get("section_description", ""),
        "option_key": ws["oa_options"][idx].get("option_key", ""),
        "options": list(opt_options) if opt_options else [],
        "selected_options": list(opt_selected) if opt_selected else []
    }
    ws["oa_options_state"][idx]["original_data"] = original_data
    ws["oa_options_state"][idx]["editable"] = True
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/oa/options/save", methods=["POST"])
def api_oa_options_save(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    idx = data.get("idx", -1)
    
    if "oa_options" not in ws or idx < 0 or idx >= len(ws["oa_options"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Get original data for dirty checking
    original_data = ws["oa_options_state"][idx].get("original_data", {})
    current = ws["oa_options"][idx]
    
    # Build new_data from request, only including fields that are present
    new_data = {}
    if "section_name" in data:
        new_data["section_name"] = data.get("section_name", "")
    if "section_description" in data:
        new_data["section_description"] = data.get("section_description", "")
    if "option_key" in data:
        new_data["option_key"] = data.get("option_key", "")
    if "options" in data:
        new_data["options"] = data.get("options", [])
    if "selected_options" in data:
        new_data["selected_options"] = data.get("selected_options", [])
    
    # Dirty check - only compare fields that are being updated
    no_changes = False
    if original_data and new_data:
        has_changes = False
        if "section_name" in new_data and new_data["section_name"] != original_data.get("section_name", ""):
            has_changes = True
        if "section_description" in new_data and new_data["section_description"] != original_data.get("section_description", ""):
            has_changes = True
        if "option_key" in new_data and new_data["option_key"] != original_data.get("option_key", ""):
            has_changes = True
        if "options" in new_data and sorted(new_data["options"]) != sorted(original_data.get("options", [])):
            has_changes = True
        if "selected_options" in new_data and sorted(new_data["selected_options"]) != sorted(original_data.get("selected_options", [])):
            has_changes = True
        
        if not has_changes:
            print(f"OA Options save: No changes detected for idx={idx}, skipping save")
            no_changes = True
    
    # Only update fields that were sent and if there are changes
    if not no_changes and new_data:
        for field, value in new_data.items():
            ws["oa_options"][idx][field] = value
        ws["has_pending_changes"] = True
    
    # Clear original values and mark as not editing
    ws["oa_options_state"][idx].pop("original_data", None)
    ws["oa_options_state"][idx].pop("original_selected", None)
    ws["oa_options_state"][idx].pop("original_comments", None)
    ws["oa_options_state"][idx]["editable"] = False
    ws["oa_options_state"][idx].pop("_is_new", None)
    
    return jsonify({"ok": True, "no_changes": no_changes})


@app.route("/api/workspace/<path:key>/oa/options/<int:idx>/update-selection", methods=["POST"])
def api_oa_options_update_selection(key, idx):
    """Update OA option checkbox selection in-memory (without full save/edit flow)."""
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    options = data.get("options", [])
    selected_options = data.get("selected_options", [])
    
    print(f"OA OPTIONS UPDATE SELECTION: idx={idx}, options={options}, selected={selected_options}")
    
    if "oa_options" not in ws or idx >= len(ws["oa_options"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 400
    
    # Update in-memory workspace (will be persisted on "Save as Draft")
    ws["oa_options"][idx]["options"] = options
    ws["oa_options"][idx]["selected_options"] = selected_options
    ws["has_pending_changes"] = True
    
    print(f"OA OPTIONS UPDATE SELECTION: Updated workspace - ws[oa_options][{idx}] now has {len(selected_options)} selected")
    
    return jsonify({"ok": True})


@app.route("/api/workspace/<path:key>/oa/other/<int:idx>/update-selection", methods=["POST"])
def api_oa_other_update_selection(key, idx):
    """Update OA other checkbox selection in-memory (without full save/edit flow)."""
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    options = data.get("options", [])
    selected_options = data.get("selected_options", [])
    
    print(f"OA OTHER UPDATE SELECTION: idx={idx}, options={options}, selected={selected_options}")
    
    if "oa_other" not in ws or idx >= len(ws["oa_other"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 400
    
    # Update in-memory workspace (will be persisted on "Save as Draft")
    ws["oa_other"][idx]["options"] = options
    ws["oa_other"][idx]["selected_options"] = selected_options
    ws["has_pending_changes"] = True
    
    print(f"OA OTHER UPDATE SELECTION: Updated workspace - ws[oa_other][{idx}] now has {len(selected_options)} selected")
    
    return jsonify({"ok": True})


@app.route("/api/workspace/<path:key>/oa/options/add", methods=["POST"])
def api_oa_options_add(key):
    """Add a new OA option."""
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"success": False, "error": "workspace not found"}), 404
    
    # Initialize oa_options if not exists
    if "oa_options" not in ws:
        ws["oa_options"] = []
    if "oa_options_state" not in ws:
        ws["oa_options_state"] = []
    
    # Create new option
    import uuid
    new_option = {
        "oa_options_id": f"new_{uuid.uuid4().hex[:8]}",
        "section_name": "",
        "section_description": "",
        "option_key": "",
        "options": [],
        "selected_options": [],
        "status": "PENDING",
        "vendor_comments": ""
    }
    
    # Create state for new option (start in edit mode)
    new_state = {
        "editable": True,
        "approved": False,
        "_is_new": True
    }
    
    ws["oa_options"].append(new_option)
    ws["oa_options_state"].append(new_state)
    ws["has_pending_changes"] = True
    
    return jsonify({"success": True, "idx": len(ws["oa_options"]) - 1})

@app.route("/api/workspace/<path:key>/oa/options/<int:idx>/add-option-value", methods=["POST"])
def api_oa_options_add_value(key, idx):
    """Add a new value to the options array for an OA option."""
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    value = data.get("value", "").strip()
    
    if not value:
        return jsonify({"ok": False, "msg": "value is required"}), 400
    
    if "oa_options" not in ws or idx < 0 or idx >= len(ws["oa_options"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Initialize options array if it doesn't exist
    if "options" not in ws["oa_options"][idx]:
        ws["oa_options"][idx]["options"] = []
    
    # Add the new value to options array
    ws["oa_options"][idx]["options"].append(value)
    ws["has_pending_changes"] = True
    
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/oa/options/cancel", methods=["POST"])
def api_oa_options_cancel(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    idx = data.get("idx", -1)
    
    if "oa_options_state" not in ws or idx < 0 or idx >= len(ws["oa_options_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # If this is a new option (not yet saved), remove it entirely
    if ws["oa_options_state"][idx].get("_is_new"):
        del ws["oa_options"][idx]
        del ws["oa_options_state"][idx]
        return jsonify({"ok": True, "was_new": True})
    
    # Restore all original values from stored original_data
    original_data = ws["oa_options_state"][idx].get("original_data")
    if original_data:
        ws["oa_options"][idx]["section_name"] = original_data.get("section_name", "")
        ws["oa_options"][idx]["section_description"] = original_data.get("section_description", "")
        ws["oa_options"][idx]["option_key"] = original_data.get("option_key", "")
        ws["oa_options"][idx]["options"] = original_data.get("options", [])
        ws["oa_options"][idx]["selected_options"] = original_data.get("selected_options", [])
        ws["oa_options_state"][idx].pop("original_data", None)
    else:
        # Legacy fallback
        original_selected = ws["oa_options_state"][idx].get("original_selected")
        if original_selected is not None:
            ws["oa_options"][idx]["selected_options"] = original_selected
            ws["oa_options_state"][idx].pop("original_selected", None)
    
    ws["oa_options_state"][idx]["editable"] = False
    return jsonify({"ok": True, "was_new": False})

# OA Other
@app.route("/api/workspace/<path:key>/oa/other/edit", methods=["POST"])
def api_oa_other_edit(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    idx = data.get("idx", -1)
    
    if "oa_other_state" not in ws or idx < 0 or idx >= len(ws["oa_other_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Store original checkbox state (same as OA Options)
    orig_opts = ws["oa_other"][idx].get("options", [])
    orig_sel = ws["oa_other"][idx].get("selected_options", [])
    ws["oa_other_state"][idx]["original_options"] = list(orig_opts) if orig_opts else []
    ws["oa_other_state"][idx]["original_selected"] = list(orig_sel) if orig_sel else []
    ws["oa_other_state"][idx]["editable"] = True
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/oa/other/save", methods=["POST"])
def api_oa_other_save(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    idx = data.get("idx", -1)
    options = data.get("options", [])
    selected_options = data.get("selected_options", [])
    
    if "oa_other" not in ws or idx < 0 or idx >= len(ws["oa_other"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Update checkbox-based structure (same as OA Options)
    ws["oa_other"][idx]["options"] = options
    ws["oa_other"][idx]["selected_options"] = selected_options
    ws["oa_other_state"][idx].pop("original_options", None)
    ws["oa_other_state"][idx].pop("original_selected", None)
    ws["oa_other_state"][idx]["editable"] = False
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/oa/other/cancel", methods=["POST"])
def api_oa_other_cancel(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    data = request.json or {}
    idx = data.get("idx", -1)
    
    if "oa_other_state" not in ws or idx < 0 or idx >= len(ws["oa_other_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Restore original checkbox state (same as OA Options)
    original_options = ws["oa_other_state"][idx].get("original_options")
    if original_options is not None:
        ws["oa_other"][idx]["options"] = original_options
        ws["oa_other_state"][idx].pop("original_options", None)
    
    original_selected = ws["oa_other_state"][idx].get("original_selected")
    if original_selected is not None:
        ws["oa_other"][idx]["selected_options"] = original_selected
        ws["oa_other_state"][idx].pop("original_selected", None)
    
    ws["oa_other_state"][idx]["editable"] = False
    return jsonify({"ok": True})

# === Export and Publish Endpoints ===

@app.route("/api/workspace/<path:key>/export", methods=["POST"])
def api_export_dta(key):
    """Trigger Databricks job to export DTA configuration"""
    # Call API to create export job
    result = api.create_export_job(key)
    
    if result["success"]:
        job_data = result["data"]
        return jsonify({
            "success": True, 
            "job_id": job_data["job_id"],
            "run_id": job_data["run_id"],
            "msg": result.get("message", "Export job triggered successfully")
        })
    else:
        return jsonify({"success": False, "msg": result.get("error", "Export failed")}), 400

@app.route("/api/workspace/<path:key>/publish-major", methods=["POST"])
def api_publish_major(key):
    """Publish approved DTA as a new major version"""
    # Call API to publish major version
    result = api.publish_major_version(key)
    
    if result["success"]:
        version_data = result["data"]
        return jsonify({
            "success": True,
            "msg": result.get("message", "DTA published"),
            "new_major_version": version_data["new_major_version"],
            "published_at": version_data["published_at"]
        })
    else:
        return jsonify({"success": False, "msg": result.get("error", "Publish failed")}), 400

# ============================================================================
# User Simulation & Management APIs
# ============================================================================

@app.route('/api/simulate-user', methods=['POST'])
def simulate_user():
    """Switch simulated user for testing (Phase 1 demo feature)"""
    data = request.get_json() or {}
    email = data.get('email', 'VKapoor9@its.jnj.com')
    session['simulated_user'] = email
    print(f"\n{'='*80}")
    print(f"SIMULATE USER: Session updated to {email}")
    print(f"{'='*80}\n")
    return jsonify({'ok': True, 'user': email})

@app.route('/api/users/list', methods=['GET'])
def list_users():
    """List all users for simulation dropdown"""
    service = get_user_service()
    if not service:
        # Return default users if service is not available
        return jsonify({'users': [
            {'email': 'VKapoor9@its.jnj.com', 'display_name': 'Vikas Kapoor (DAE)', 'group_name': 'JNJ_DAE', 'organization': 'JNJ Internal'},
            {'email': 'gricca4@its.jnj.com', 'display_name': 'Giuseppe Ricca (DAE)', 'group_name': 'JNJ_DAE', 'organization': 'JNJ Internal'},
            {'email': 'awagle4@its.jnj.com', 'display_name': 'Arun Wagle (LabCorp)', 'group_name': 'VENDOR', 'organization': 'LabCorp'},
            {'email': 'RRaoGude@its.jnj.com', 'display_name': 'Rohit Rao Gude (Clario)', 'group_name': 'VENDOR', 'organization': 'Clario'},
            {'email': 'JHEERES1@its.jnj.com', 'display_name': 'Jennifer Heeres (Librarian)', 'group_name': 'JNJ_LIBRARIAN', 'organization': 'JNJ Internal'}
        ]})
    
    users = service.list_all_users()
    return jsonify({'users': users})

@app.route('/api/users/current', methods=['GET'])
def get_current_user_info():
    """Get current user information"""
    user = get_current_user()
    return jsonify({'user': user})

# === Start the Flask app ===

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)

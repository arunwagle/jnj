# Permissions Feature Deployment Guide

**Package Date:** 2026-01-25  
**Feature:** Role-Based Access Control (RBAC) - Phase 1

## Overview

This package contains all files needed to deploy the permissions/user management feature for the Clinical Data Standards Management Application.

## What's Included

### 1. Database & Permissions Setup
- `sql/setup_cdm_app_permissions.sql` - Creates permission tables, groups, and users
- `resources/sql/common/jobs/job_cdm_app_permissions.job.yml` - Job definition for permissions setup
- `resources/sql/test/jobs/job_test_cdm_app_permissions.job.yml` - Test job for permissions

### 2. Backend API
- `apps/clnl-data-std-mgmt-app/api/user_management_api.py` - User management service (NEW FILE)
- `apps/clnl-data-std-mgmt-app/app.py` - Updated with permission integration

### 3. Frontend Templates
- `apps/clnl-data-std-mgmt-app/templates/base.html` - User simulation dropdown, nav permissions
- `apps/clnl-data-std-mgmt-app/templates/workspace.html` - Edit permission controls
- `apps/clnl-data-std-mgmt-app/templates/approvals.html` - Approval section permissions
- `apps/clnl-data-std-mgmt-app/templates/dashboard.html` - Role-based panel visibility
- `apps/clnl-data-std-mgmt-app/templates/view.html` - Delete button permissions

### 4. Static Assets
- `apps/clnl-data-std-mgmt-app/static/styles.css` - Disabled button styles, user dropdown, dashboard alignment
- `apps/clnl-data-std-mgmt-app/static/script.js` - User switching functionality

### 5. Documentation
- `docs/08_permissions_design.readme.md` - Complete permissions design documentation

## Deployment Steps

### Step 1: Backup Current System
```bash
# Backup current app files
cp -r apps/clnl-data-std-mgmt-app apps/clnl-data-std-mgmt-app.backup_$(date +%Y%m%d)

# Backup current SQL files
cp -r sql sql.backup_$(date +%Y%m%d)

# Backup current resource definitions
cp -r resources resources.backup_$(date +%Y%m%d)
```

### Step 2: Deploy Files
Extract this zip file and copy all files to your project root, preserving the directory structure:

```bash
# Extract zip
unzip permissions_deployment_YYYYMMDD.zip -d /tmp/permissions_extracted

# Copy files (adjust paths as needed)
cd /tmp/permissions_extracted
cp -r * /path/to/your/clinical-data-standards/
```

### Step 3: Deploy to Databricks
```bash
# Deploy using Databricks Asset Bundles
databricks bundle deploy --target <your_target>
```

### Step 4: Run Permissions Setup Job
**IMPORTANT:** Run this job to create permission tables and seed initial data.

Option A - Via Databricks UI:
1. Go to Workflows → Jobs
2. Find `job_cdm_app_permissions`
3. Click "Run now"
4. Monitor execution

Option B - Via CLI:
```bash
databricks jobs run-now --job-name job_cdm_app_permissions
```

Option C - Run SQL directly:
```sql
-- In Databricks SQL Editor
-- Set catalog parameter, then run:
-- sql/setup_cdm_app_permissions.sql
```

### Step 5: Verify Deployment

1. **Check Permission Tables:**
```sql
USE CATALOG <your_catalog>;
USE SCHEMA gold_md;

-- Verify tables exist
SHOW TABLES LIKE 'md_%';

-- Check users
SELECT * FROM md_users;

-- Check permissions
SELECT * FROM md_permissions;

-- Check group assignments
SELECT u.email, u.display_name, g.group_name
FROM md_users u
JOIN md_user_group_memberships ugm ON u.user_id = ugm.user_id
JOIN md_user_groups g ON ugm.group_id = g.group_id;
```

2. **Test the App:**
   - Access the application
   - Use the user simulation dropdown in the header
   - Switch between different users:
     - JNJ DAE (full access)
     - Vendor (limited editing)
     - Librarian (template promotion only)
   - Verify menu items and buttons are properly hidden/disabled based on role

## User Roles & Permissions

### JNJ DAE (Data Acquisition Engineer)
- ✅ All pages visible
- ✅ Can create, edit, clone, approve DTAs
- ✅ Can submit for approval
- ✅ Can add comments
- ✅ Can promote to template
- Dashboard: Pending Approvals, My Drafts, Manual Review

### Vendor User
- ✅ Dashboard, DTA Workflow, DTA Viewer
- ❌ Study Management, Document Management, Administration (hidden)
- ✅ Can view and comment on DTAs
- ✅ Can approve DTAs (vendor approval step)
- ❌ Cannot edit, clone, or delete DTAs (buttons disabled/hidden)
- ❌ Cannot promote to template
- Dashboard: Pending Approvals, My Drafts (vendor-filtered)

### JNJ Librarian
- ✅ Dashboard, DTA Workflow, DTA Viewer, Administration
- ❌ Study Management, Document Management (hidden)
- ✅ Can view DTAs
- ✅ Can add comments
- ✅ Can promote to template
- ❌ Cannot edit, clone, approve, or delete DTAs
- Dashboard: Ready to Promote only

## Test Users

The following test users are pre-configured:

| Email | Display Name | Role | Vendor |
|-------|--------------|------|--------|
| awagle4@its.jnj.com | Arun Wagle | Vendor | LabCorp |
| RRaoGude@its.jnj.com | Rajat Rao | Vendor | Clario |
| VKapoor9@its.jnj.com | Vishal Kapoor | JNJ DAE | - |
| gricca4@its.jnj.com | Giuseppe Ricca | JNJ DAE | - |
| JHEERES1@its.jnj.com | Jessica Heeres | Librarian | - |

## Customization

### Adding New Users

Edit `sql/setup_cdm_app_permissions.sql` and add to the users INSERT section:
```sql
INSERT INTO md_users (user_id, email, display_name, vendor_id)
SELECT uuid(), 'newuser@example.com', 'New User', 'vendor_id'
UNION ALL
-- ... existing users
```

Then assign to a group:
```sql
INSERT INTO md_user_group_memberships (membership_id, user_id, group_id)
SELECT uuid(), 
  (SELECT user_id FROM md_users WHERE email = 'newuser@example.com'),
  'group_jnj_dae'  -- or 'group_vendor' or 'group_jnj_librarian'
```

Re-run the permissions job to apply changes.

### Modifying Permissions

Edit the permissions INSERT section in `sql/setup_cdm_app_permissions.sql` to add/remove permissions from groups.

## Troubleshooting

### Issue: User sees wrong permissions
**Solution:** Clear browser cache and reload, or use incognito mode

### Issue: Permission tables not found
**Solution:** Ensure `job_cdm_app_permissions` ran successfully

### Issue: All buttons still active for Vendor
**Solution:** 
1. Verify permissions job ran successfully
2. Check `md_group_permissions` table has correct entries
3. Clear browser cache
4. Check browser console for JavaScript errors

### Issue: User simulation dropdown not showing
**Solution:**
1. Ensure `app.py` has the `/api/users/list` endpoint
2. Check `user_management_api.py` is in the correct location
3. Verify imports in `app.py`

## Rollback Instructions

If you need to rollback:

1. **Restore backup files:**
```bash
rm -rf apps/clnl-data-std-mgmt-app
cp -r apps/clnl-data-std-mgmt-app.backup_YYYYMMDD apps/clnl-data-std-mgmt-app

rm -rf sql
cp -r sql.backup_YYYYMMDD sql

rm -rf resources
cp -r resources.backup_YYYYMMDD resources
```

2. **Redeploy to Databricks:**
```bash
databricks bundle deploy --target <your_target>
```

3. **Optionally drop permission tables:**
```sql
USE CATALOG <your_catalog>;
USE SCHEMA gold_md;

DROP TABLE IF EXISTS md_user_group_memberships;
DROP TABLE IF EXISTS md_group_permissions;
DROP TABLE IF EXISTS md_permissions;
DROP TABLE IF EXISTS md_user_groups;
DROP TABLE IF EXISTS md_users;
```

## Support

For issues or questions, contact the development team or refer to:
- `docs/08_permissions_design.readme.md` for detailed design documentation

## Change Log

### 2026-01-25 - Phase 1 Release
- Initial permissions framework
- 3 user roles: JNJ DAE, Vendor, Librarian
- User simulation dropdown for testing
- Page-level and action-level permissions
- Dashboard role-based panel visibility
- Administration menu access for Librarian
- Action cards left-alignment fix


# Permissions & Access Control Design

## Overview

This document describes the **hierarchical permissions system** for the Clinical Data Standards Management application. The design follows a top-down approach:

1. **Page Access** - Which pages/menus can the user see?
2. **Panel View** - Which panels/sections are visible on those pages?
3. **Action Execute** - Which buttons/actions can the user perform?

### Design Principles

- **Hierarchical**: Page access controls panel visibility, which controls action availability
- **Extensible**: Easy to add new roles, permissions, and UI elements
- **Databricks-Ready**: Mock API pattern mirrors Databricks Account Manager APIs for future integration
- **Testable**: User simulation dropdown for testing different roles

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           PERMISSION ARCHITECTURE                                │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│  ┌──────────────────────────────────────────────────────────────────────────┐   │
│  │                           USER GROUPS                                     │   │
│  │                                                                           │   │
│  │   ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐    │   │
│  │   │ APP_MANAGER │  │   JNJ_DAE   │  │ LIBRARIAN   │  │   VENDOR    │    │   │
│  │   │             │  │             │  │             │  │             │    │   │
│  │   │ Full Admin  │  │ Manage DTA  │  │ Promote DTA │  │ Comment +   │    │   │
│  │   │ All Access  │  │ Submit Appr │  │ View All    │  │ Approve     │    │   │
│  │   └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘    │   │
│  │          │                │                │                │           │   │
│  └──────────┼────────────────┼────────────────┼────────────────┼───────────┘   │
│             │                │                │                │                │
│             ▼                ▼                ▼                ▼                │
│  ┌──────────────────────────────────────────────────────────────────────────┐   │
│  │                        PERMISSION LEVELS                                  │   │
│  │                                                                           │   │
│  │   Level 1: PAGE ACCESS                                                    │   │
│  │   ┌──────────────────────────────────────────────────────────────────┐   │   │
│  │   │  Dashboard │ DTA Builder │ DTA Viewer │ Workflow │ Study Mgmt   │   │   │
│  │   └──────────────────────────────────────────────────────────────────┘   │   │
│  │                                    │                                      │   │
│  │                                    ▼                                      │   │
│  │   Level 2: PANEL VIEW                                                     │   │
│  │   ┌──────────────────────────────────────────────────────────────────┐   │   │
│  │   │  Create DTA Btn │ Promote Queue │ Vendor DTA List │ My Drafts   │   │   │
│  │   └──────────────────────────────────────────────────────────────────┘   │   │switched

│  │                                    │                                      │   │
│  │                                    ▼                                      │   │
│  │   Level 3: ACTION EXECUTE                                                 │   │
│  │   ┌──────────────────────────────────────────────────────────────────┐   │   │
│  │   │  Edit │ Clone │ Comment │ Submit │ Approve │ Reject │ Promote   │   │   │
│  │   └──────────────────────────────────────────────────────────────────┘   │   │
│  │                                                                           │   │
│  └──────────────────────────────────────────────────────────────────────────┘   │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## User Groups

| Group | Description | Primary Use Case |
|-------|-------------|------------------|
| **JNJ_APP_MANAGER** | Full admin access | System administration, user management |
| **JNJ_DAE** | Data Acquisition Engineer | Create, edit, clone, manage DTAs; submit for approval |
| **JNJ_LIBRARIAN** | Library maintainer | View DTAs, comment, and promote approved DTAs to templates |
| **VENDOR** | External vendor user | View assigned DTAs; add comments; approve DTAs |

### Vendor User Scoping

Vendor users are linked to a specific vendor via `vendor_id`:
- They only see DTAs associated with their vendor
- `vendor_id` references `md_vendor.vendor_id`
- Data queries are automatically filtered by vendor

---

## Permission Hierarchy

### Level 1: Page Access

Controls which pages/menu items the user can see.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                             PAGE ACCESS MATRIX                                   │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│   Page                    │ APP_MANAGER │  DAE  │ LIBRARIAN │ VENDOR           │
│   ────────────────────────┼─────────────┼───────┼───────────┼─────────────────  │
│   Dashboard               │     ✓       │   ✓   │     ✓     │    ✓              │
│   DTA Builder             │     ✓       │   ✓   │     ✗     │    ✗              │
│   DTA Viewer              │     ✓       │   ✓   │     ✓     │    ✓              │
│   DTA Workflow            │     ✓       │   ✓   │     ✓     │    ✓              │
│   Study Management        │     ✓       │   ✓   │     ✗     │    ✗              │
│   Document Management     │     ✓       │   ✓   │     ✗     │    ✗              │
│   Jobs Panel              │     ✓       │   ✓   │     ✗     │    ✗              │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### Level 2: Panel View

Controls which panels/sections are visible within accessible pages.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                             PANEL VIEW MATRIX                                    │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│   Panel                   │ APP_MANAGER │  DAE  │ LIBRARIAN │ VENDOR           │
│   ────────────────────────┼─────────────┼───────┼───────────┼─────────────────  │
│                                                                                  │
│   DASHBOARD                                                                      │
│   ─────────                                                                      │
│   Create DTA Button       │     ✓       │   ✓   │     ✗     │    ✗              │
│   All DTAs List           │     ✓       │   ✓   │     ✓     │    ✗              │
│   Vendor DTAs List        │     ✗       │   ✗   │     ✗     │    ✓              │
│   Pending Approvals       │     ✓       │   ✓   │     ✗     │    ✓*             │
│   Promote Queue           │     ✓       │   ✗   │     ✓     │    ✗              │
│   My Drafts               │     ✓       │   ✓   │     ✗     │    ✗              │
│                                                                                  │
│   DTA VIEWER                                                                     │
│   ──────────                                                                     │
│   DTA Details             │     ✓       │   ✓   │     ✓     │    ✓              │
│   Edit/Clone Buttons      │     ✓       │   ✓   │     ✗     │    ✗              │
│   Comment Section         │     ✓       │   ✓   │     ✓     │    ✓              │
│   Approval Buttons        │     ✓       │   ✗   │     ✗     │    ✓              │
│   Promote Button          │     ✓       │   ✗   │     ✓     │    ✗              │
│                                                                                  │
│   * Vendor sees only their vendor's pending approvals                           │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### Level 3: Action Execute

Controls which actions the user can perform.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            ACTION EXECUTE MATRIX                                 │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│   Action                  │ APP_MANAGER │  DAE  │ LIBRARIAN │ VENDOR           │
│   ────────────────────────┼─────────────┼───────┼───────────┼─────────────────  │
│   Create DTA              │     ✓       │   ✓   │     ✗     │    ✗              │
│   Edit DTA                │     ✓       │   ✓   │     ✗     │    ✗              │
│   Clone DTA               │     ✓       │   ✓   │     ✗     │    ✗              │
│   Add Comment             │     ✓       │   ✓   │     ✓     │    ✓              │
│   Submit for Approval     │     ✓       │   ✓   │     ✗     │    ✗              │
│   Approve DTA             │     ✓       │   ✗   │     ✗     │    ✓              │
│   Reject DTA              │     ✓       │   ✗   │     ✗     │    ✓              │
│   Promote to Template     │     ✓       │   ✗   │     ✓     │    ✗              │
│   Export DTA              │     ✓       │   ✓   │     ✓     │    ✓              │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## Data Model

### Entity Relationship Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           PERMISSION DATA MODEL                                  │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│                                                                                  │
│   ┌─────────────────────┐         ┌─────────────────────────────────┐           │
│   │     md_users        │         │        md_vendor                │           │
│   ├─────────────────────┤         ├─────────────────────────────────┤           │
│   │ user_id        PK   │         │ vendor_id              PK       │           │
│   │ email               │         │ vendor_name                     │           │
│   │ display_name        │    ┌───▶│ vendor_description              │           │
│   │ vendor_id       FK  │────┘    │ is_active                       │           │
│   │ is_active           │         └─────────────────────────────────┘           │
│   │ created_ts          │                                                        │
│   │ last_updated_ts     │                                                        │
│   └──────────┬──────────┘                                                        │
│              │                                                                   │
│              │ 1:N                                                               │
│              ▼                                                                   │
│   ┌─────────────────────────────────┐                                           │
│   │  md_user_group_memberships      │                                           │
│   ├─────────────────────────────────┤                                           │
│   │ membership_id              PK   │                                           │
│   │ user_id                    FK   │                                           │
│   │ group_id                   FK   │                                           │
│   │ joined_ts                       │                                           │
│   └──────────┬──────────────────────┘                                           │
│              │                                                                   │
│              │ N:1                                                               │
│              ▼                                                                   │
│   ┌─────────────────────┐         ┌─────────────────────────────────┐           │
│   │   md_user_groups    │         │       md_permissions            │           │
│   ├─────────────────────┤         ├─────────────────────────────────┤           │
│   │ group_id       PK   │         │ permission_id            PK     │           │
│   │ group_name          │         │ permission_type                 │           │
│   │ description         │         │ permission_key                  │           │
│   │ is_active           │         │ enforcement_mode                │           │
│   └──────────┬──────────┘         │ description                     │           │
│              │                    │ disabled_message                │           │
│              │ 1:N          N:1   └──────────┬──────────────────────┘           │
│              │                               │                                   │
│              │ 1:N                     N:1   │                                   │
│              ▼                               │                                   │
│   ┌─────────────────────────────────────────┴───────┐                           │
│   │           md_group_permissions                   │                           │
│   ├──────────────────────────────────────────────────┤                           │
│   │ group_permission_id                         PK   │                           │
│   │ group_id                                    FK   │                           │
│   │ permission_id                               FK   │                           │
│   └──────────────────────────────────────────────────┘                           │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### Table Definitions

#### md_users
```sql
CREATE TABLE IF NOT EXISTS gold_md.md_users (
    user_id             STRING      COMMENT 'Unique user identifier (UUID)',
    email               STRING      COMMENT 'User email for SSO and notifications',
    display_name        STRING      COMMENT 'User display name',
    vendor_id           STRING      COMMENT 'FK to md_vendor for vendor users, NULL for internal',
    is_active           BOOLEAN     COMMENT 'Active status',
    created_ts          TIMESTAMP   COMMENT 'Record creation timestamp',
    last_updated_ts     TIMESTAMP   COMMENT 'Last update timestamp'
) USING DELTA
COMMENT 'Application users with group memberships';
```

#### md_user_groups
```sql
CREATE TABLE IF NOT EXISTS gold_md.md_user_groups (
    group_id            STRING      COMMENT 'Unique group identifier (UUID)',
    group_name          STRING      COMMENT 'Group name: JNJ_APP_MANAGER, JNJ_DAE, JNJ_LIBRARIAN, VENDOR',
    description         STRING      COMMENT 'Group description',
    is_active           BOOLEAN     COMMENT 'Active status'
) USING DELTA
COMMENT 'User groups with permission sets';
```

#### md_permissions
```sql
CREATE TABLE IF NOT EXISTS gold_md.md_permissions (
    permission_id       STRING      COMMENT 'Unique permission identifier',
    permission_type     STRING      COMMENT 'Type: PAGE_ACCESS, PANEL_VIEW, ACTION_EXECUTE',
    permission_key      STRING      COMMENT 'Unique key: page_dashboard, action_edit_dta, etc.',
    enforcement_mode    STRING      COMMENT 'Enforcement mode: HIDE, DISABLE, REQUIRE',
    description         STRING      COMMENT 'Human-readable description',
    disabled_message    STRING      COMMENT 'Tooltip/message shown when element is disabled'
) USING DELTA
COMMENT 'Permission definitions with enforcement strategy';
```

### Enforcement Modes

The permission system supports three enforcement modes that control how UI elements behave when users lack permission:

| Mode | Description | UI Behavior | Use Case | Example |
|------|-------------|-------------|----------|---------|
| **HIDE** | Element completely removed from DOM | Element not rendered | Navigation items, features user shouldn't know exist | Study Management nav for vendors |
| **DISABLE** | Element visible but non-interactive | Button shown but grayed out with explanatory tooltip | Actions where user should see feature exists but can't use it | Edit DTA buttons for vendors |
| **REQUIRE** | Element hidden until permission granted | Same as HIDE but for contextual enablement | Premium features, progressive disclosure | Future feature flags |

#### Mode Selection Guidelines

**Use HIDE when:**
- Feature is completely irrelevant to user's role
- Showing the feature would create confusion
- Navigation/menu items for different departments
- Security-sensitive actions
- Example: Vendors never need "Study Management" or "Create Template"

**Use DISABLE when:**
- User should know the feature exists
- Training/onboarding benefits from visibility
- Feature might become available to user later
- Context helps user understand system capabilities
- Example: Vendors see "Edit DTA" buttons disabled with message "You do not have permission to edit DTAs. Contact your administrator to request access."

**Use REQUIRE when:**
- Feature availability depends on context (not just role)
- Progressive disclosure patterns
- Premium/licensed features
- Example: Advanced analytics features that require additional licenses

#### Implementation

**Backend (SQL):**
```sql
-- Page Access - typically HIDE (navigation items)
INSERT INTO md_permissions VALUES
('perm_page_study_mgmt', 'PAGE_ACCESS', 'page_study_mgmt', 'HIDE', 
 'Access Study Management pages', NULL);

-- Actions - DISABLE to show but restrict
INSERT INTO md_permissions VALUES
('perm_action_edit_dta', 'ACTION_EXECUTE', 'action_edit_dta', 'DISABLE',
 'Edit DTA fields', 
 'You do not have permission to edit DTAs. Contact your administrator to request access.');

-- Actions - HIDE to completely remove
INSERT INTO md_permissions VALUES
('perm_action_clone_dta', 'ACTION_EXECUTE', 'action_clone_dta', 'HIDE',
 'Clone DTAs', NULL);
```

**Python API:**
```python
# Check if user has permission (for HIDE mode)
can('action_edit_dta')  # Returns True/False

# Check if should be shown but disabled
is_disabled('action_edit_dta')  # Returns True if no permission AND mode is DISABLE

# Get disabled message for tooltips
disabled_reason('action_edit_dta')  # Returns the disabled_message
```

**Template Usage:**
```html
<!-- HIDE Mode: Completely remove from DOM -->
{% if can('page_study_mgmt') %}
  <a href="/study">Study Management</a>
{% endif %}

<!-- DISABLE Mode: Show but disable with tooltip -->
<button 
  onclick="editDta()"
  {% if is_disabled('action_edit_dta') %}
    disabled
    title="{{ disabled_reason('action_edit_dta') }}"
  {% endif %}>
  Edit DTA
</button>

<!-- Mixed: Hide some, disable others -->
<div class="actions">
  <button onclick="view()">View</button>  <!-- Always available -->
  
  <button 
    onclick="edit()"
    {% if is_disabled('action_edit_dta') %}
      disabled title="{{ disabled_reason('action_edit_dta') }}"
    {% endif %}>
    Edit
  </button>
  
  {% if can('action_clone_dta') %}
    <button onclick="clone()">Clone</button>  <!-- HIDE mode -->
  {% endif %}
</div>
```

#### Enforcement Mode Examples by Role

**Vendor User on DTA Edit Page:**

| Element | Mode | Behavior |
|---------|------|----------|
| "Study Management" nav | HIDE | Removed from sidebar |
| "Document Management" nav | HIDE | Removed from sidebar |
| "Administration" nav | HIDE | Removed from sidebar |
| "Save as Draft" button | DISABLE | Visible but grayed out with tooltip |
| "Submit for Approval" button | DISABLE | Visible but grayed out with tooltip |
| "Add Variable" button | DISABLE | Visible but grayed out with tooltip |
| "Add Comment" button | (has permission) | Fully functional |
| "Clone DTA" button | HIDE | Completely removed |

**Benefits:**
1. **Better UX**: Users understand what features exist even if they can't use them
2. **Training**: New users see full feature set, learn system capabilities
3. **Context**: Disabled buttons with messages explain why action isn't available
4. **Flexibility**: Same permission can use different modes in different UI contexts

#### md_user_group_memberships
```sql
CREATE TABLE IF NOT EXISTS gold_md.md_user_group_memberships (
    membership_id       STRING      COMMENT 'Unique membership identifier',
    user_id             STRING      COMMENT 'FK to md_users',
    group_id            STRING      COMMENT 'FK to md_user_groups',
    joined_ts           TIMESTAMP   COMMENT 'When user joined the group'
) USING DELTA
COMMENT 'User to group membership mapping';
```

#### md_group_permissions
```sql
CREATE TABLE IF NOT EXISTS gold_md.md_group_permissions (
    group_permission_id STRING      COMMENT 'Unique identifier',
    group_id            STRING      COMMENT 'FK to md_user_groups',
    permission_id       STRING      COMMENT 'FK to md_permissions'
) USING DELTA
COMMENT 'Group to permission mapping';
```

---

## Permission Keys

### Page Access Keys (Level 1)
| Key | Description |
|-----|-------------|
| `page_dashboard` | Access to Dashboard |
| `page_dta_builder` | Access to DTA Builder (create/edit) |
| `page_dta_viewer` | Access to DTA Viewer |
| `page_dta_workflow` | Access to DTA Workflow |
| `page_study_management` | Access to Study Management |
| `page_document_management` | Access to Document Management |
| `page_jobs_panel` | Access to Jobs Panel |

### Panel View Keys (Level 2)
| Key | Description |
|-----|-------------|
| `panel_create_dta_btn` | Show Create DTA button on dashboard |
| `panel_all_dtas_list` | Show all DTAs list |
| `panel_vendor_dtas_list` | Show vendor-specific DTAs list |
| `panel_pending_approvals` | Show pending approvals panel |
| `panel_promote_queue` | Show promote to template queue |
| `panel_my_drafts` | Show my drafts panel |
| `panel_edit_clone_buttons` | Show edit/clone buttons in viewer |
| `panel_comment_section` | Show comment section |
| `panel_approval_buttons` | Show approve/reject buttons |
| `panel_promote_button` | Show promote to template button |

### Action Execute Keys (Level 3)
| Key | Description |
|-----|-------------|
| `action_create_dta` | Create new DTA |
| `action_edit_dta` | Edit existing DTA |
| `action_clone_dta` | Clone DTA |
| `action_add_comment` | Add comments to DTA |
| `action_submit_approval` | Submit DTA for approval |
| `action_approve_dta` | Approve DTA |
| `action_reject_dta` | Reject DTA |
| `action_promote_template` | Promote DTA to template |
| `action_export_dta` | Export DTA |

---

## Group Permission Assignments

### JNJ_APP_MANAGER (Full Admin)
```
Page Access:      ALL
Panel View:       ALL
Action Execute:   ALL
```

### JNJ_DAE (Data Acquisition Engineer)
```
Page Access:      page_dashboard, page_dta_builder, page_dta_viewer, 
                  page_dta_workflow, page_study_management, 
                  page_document_management, page_jobs_panel

Panel View:       panel_create_dta_btn, panel_all_dtas_list, 
                  panel_pending_approvals, panel_my_drafts,
                  panel_edit_clone_buttons, panel_comment_section

Action Execute:   action_create_dta, action_edit_dta, action_clone_dta,
                  action_add_comment, action_submit_approval, action_export_dta
```

### JNJ_LIBRARIAN
```
Page Access:      page_dashboard, page_dta_viewer, page_dta_workflow,
                  page_study_management, page_document_management, 
                  page_jobs_panel

Panel View:       panel_all_dtas_list, panel_pending_approvals, 
                  panel_promote_queue, panel_my_drafts,
                  panel_comment_section, panel_promote_button

Action Execute:   action_add_comment, action_promote_template, action_export_dta
```

### VENDOR
```
Page Access:      page_dashboard, page_dta_viewer

Panel View:       panel_vendor_dtas_list, panel_pending_approvals,
                  panel_comment_section, panel_approval_buttons

Action Execute:   action_add_comment, action_approve_dta, 
                  action_reject_dta, action_export_dta

Data Scope:       WHERE data_provider_name = {user.vendor_id}
```

---

## Implementation

### Python API Pattern

The implementation uses a mock API pattern that mirrors Databricks Account Manager APIs for easy future integration.

#### user_management_api.py
```python
class UserManagementService:
    """
    Mock service that mirrors Databricks Account Manager API.
    Can be replaced with real API calls later.
    """
    
    def __init__(self, sql_client):
        self.client = sql_client
        self.catalog = "aira_test"
        self.schema = "gold_md"
    
    # ─────────────────────────────────────────────────────────────
    # User Operations
    # ─────────────────────────────────────────────────────────────
    
    def list_users(self) -> list[dict]:
        """List all active users"""
        query = f"""
            SELECT * FROM {self.catalog}.{self.schema}.md_users
            WHERE is_active = true
        """
        return self.client.execute_query(query)
    
    def get_user(self, email: str) -> dict:
        """Get user by email"""
        query = f"""
            SELECT * FROM {self.catalog}.{self.schema}.md_users
            WHERE email = '{email}' AND is_active = true
        """
        result = self.client.execute_query(query)
        return result[0] if result else None
    
    def get_user_with_permissions(self, email: str) -> dict:
        """Get user with all permissions resolved"""
        user = self.get_user(email)
        if not user:
            return None
        
        permissions = self.get_user_permissions(email)
        user['permissions'] = permissions
        return user
    
    # ─────────────────────────────────────────────────────────────
    # Group Operations
    # ─────────────────────────────────────────────────────────────
    
    def list_groups(self) -> list[dict]:
        """List all active groups"""
        query = f"""
            SELECT * FROM {self.catalog}.{self.schema}.md_user_groups
            WHERE is_active = true
        """
        return self.client.execute_query(query)
    
    def get_user_groups(self, email: str) -> list[dict]:
        """Get groups for a user"""
        query = f"""
            SELECT g.* 
            FROM {self.catalog}.{self.schema}.md_user_groups g
            JOIN {self.catalog}.{self.schema}.md_user_group_memberships m 
                ON g.group_id = m.group_id
            JOIN {self.catalog}.{self.schema}.md_users u 
                ON m.user_id = u.user_id
            WHERE u.email = '{email}' AND g.is_active = true
        """
        return self.client.execute_query(query)
    
    # ─────────────────────────────────────────────────────────────
    # Permission Operations
    # ─────────────────────────────────────────────────────────────
    
    def get_user_permissions(self, email: str) -> list[str]:
        """Get all permission keys for a user"""
        query = f"""
            SELECT DISTINCT p.permission_key
            FROM {self.catalog}.{self.schema}.md_permissions p
            JOIN {self.catalog}.{self.schema}.md_group_permissions gp 
                ON p.permission_id = gp.permission_id
            JOIN {self.catalog}.{self.schema}.md_user_group_memberships m 
                ON gp.group_id = m.group_id
            JOIN {self.catalog}.{self.schema}.md_users u 
                ON m.user_id = u.user_id
            WHERE u.email = '{email}'
        """
        result = self.client.execute_query(query)
        return [r['permission_key'] for r in result]
    
    def has_permission(self, email: str, permission_key: str) -> bool:
        """Check if user has a specific permission"""
        permissions = self.get_user_permissions(email)
        return permission_key in permissions
```

#### auth_api.py (Flask Integration)
```python
from flask import session, g
from functools import wraps

def get_current_user():
    """Get current user from session (simulated or real)"""
    if 'current_user' not in g:
        email = session.get('simulated_user', 'dae.user@jnj.com')
        user_service = UserManagementService(get_sql_client())
        g.current_user = user_service.get_user_with_permissions(email)
    return g.current_user

def can(permission_key: str) -> bool:
    """Check if current user has permission"""
    user = get_current_user()
    if not user:
        return False
    return permission_key in user.get('permissions', [])

def require_permission(permission_key: str):
    """Decorator to require a permission for a route"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not can(permission_key):
                return render_template('403.html'), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def get_vendor_filter():
    """Get vendor filter for data scoping"""
    user = get_current_user()
    if user and user.get('vendor_id'):
        return user['vendor_id']
    return None
```

### Template Integration

#### Context Processor (app.py)
```python
@app.context_processor
def inject_user_context():
    """Inject user and permission helpers into all templates"""
    return {
        'current_user': get_current_user(),
        'can': can
    }
```

#### Template Usage Examples

**Menu Visibility (base.html)**
```html
<nav>
    {% if can('page_dashboard') %}
        <a href="/dashboard">Dashboard</a>
    {% endif %}
    
    {% if can('page_dta_builder') %}
        <a href="/dta-builder">DTA Builder</a>
    {% endif %}
    
    {% if can('page_dta_workflow') %}
        <a href="/workflow">Workflow</a>
    {% endif %}
</nav>
```

**Panel Visibility (dashboard.html)**
```html
{% if can('panel_create_dta_btn') %}
    <button onclick="createDTA()">Create New DTA</button>
{% endif %}

{% if can('panel_promote_queue') %}
    <div class="promote-queue-panel">
        <!-- Promote queue content -->
    </div>
{% endif %}
```

**Action Visibility (view.html)**
```html
{% if can('action_edit_dta') %}
    <button onclick="editDTA()">Edit</button>
{% endif %}

{% if can('action_approve_dta') %}
    <button onclick="approveDTA()">Approve</button>
    <button onclick="rejectDTA()">Reject</button>
{% endif %}

{% if can('action_promote_template') %}
    <button onclick="promoteDTA()">Promote to Template</button>
{% endif %}
```

---

## User Simulation (Testing)

### Simulation Dropdown

Add to header for testing different roles:

```html
<div class="user-simulation">
    <label>Simulate User:</label>
    <select id="simulate-user" onchange="switchUser(this.value)">
        <option value="admin@jnj.com">Admin (APP_MANAGER)</option>
        <option value="dae.user@jnj.com" selected>DAE User</option>
        <option value="librarian@jnj.com">Librarian</option>
        <option value="vendor.labcorp@vendor.com">Labcorp (VENDOR)</option>
        <option value="vendor.clario@vendor.com">Clario (VENDOR)</option>
    </select>
</div>

<script>
function switchUser(email) {
    fetch('/api/simulate-user', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({email: email})
    }).then(() => location.reload());
}
</script>
```

### Simulation Endpoint (app.py)
```python
@app.route('/api/simulate-user', methods=['POST'])
def simulate_user():
    """Switch simulated user for testing"""
    data = request.get_json()
    session['simulated_user'] = data.get('email', 'dae.user@jnj.com')
    return jsonify({'ok': True})
```

### Mock Users

| Email | Display Name | Group | Vendor |
|-------|--------------|-------|--------|
| admin@jnj.com | App Admin | JNJ_APP_MANAGER | - |
| dae.user@jnj.com | DAE User | JNJ_DAE | - |
| librarian@jnj.com | Librarian | JNJ_LIBRARIAN | - |
| vendor.labcorp@vendor.com | Labcorp User | VENDOR | Labcorp |
| vendor.clario@vendor.com | Clario User | VENDOR | Clario |

---

## Future: Databricks Integration

### Migration Path

1. **Replace mock data loading** with Databricks Account Manager API calls
2. **Replace md_users** with Databricks users (keep vendor_id mapping)
3. **Replace md_user_groups** with Databricks groups
4. **Keep md_permissions and md_group_permissions** (app-specific)

### Databricks Account Manager API

```python
from databricks.sdk import AccountClient

class DatabricksUserManagementService(UserManagementService):
    """Real implementation using Databricks APIs"""
    
    def __init__(self, account_client: AccountClient):
        self.account = account_client
    
    def list_users(self):
        return self.account.users.list()
    
    def get_user(self, email: str):
        users = self.account.users.list(filter=f'emails.value eq "{email}"')
        return next(iter(users), None)
    
    def list_groups(self):
        return self.account.groups.list()
```

### SSO Integration

When SSO is enabled:
1. Remove user simulation dropdown
2. Get user email from request headers: `X-Forwarded-User`
3. Map Databricks groups to application permissions

---

## Troubleshooting

### User Not Found
```
Error: User 'user@example.com' not found
```
**Solution:** Add user to md_users table or check email spelling

### Permission Denied
```
Error: 403 Forbidden - Missing permission 'action_edit_dta'
```
**Solution:** Check user's group memberships and group permissions

### Vendor Data Not Filtered
```
Issue: Vendor user sees all DTAs instead of their vendor's
```
**Solution:** Ensure `vendor_id` is set on user and queries use `get_vendor_filter()`

---

## Job Architecture & Execution Order

### Overview

This section describes the correct order for running CDM setup and data loading jobs, including permissions setup.

### Job Dependency Chain

```
job_cdm_sql_setup
    ↓
job_cdm_sql_load_reference_data
    ↓
job_cdm_dta_import
    ↓
job_cdm_app_permissions
    ↓
Deploy Flask App
```

### Detailed Execution Steps

#### 1. Setup Catalog, Schemas, and Volumes
**Job**: `job_cdm_sql_setup`  
**Purpose**: Creates catalog, schemas (bronze_md, silver_md, gold_md), and volumes  
**SQL**: `sql/setup_cds_catalog.sql`

```bash
databricks jobs run-now --job-name job_cdm_sql_setup
```

**Creates**:
- Catalog: `dta_poc_test` (or configured catalog)
- Schemas: `bronze_md`, `silver_md`, `gold_md`
- Volumes: `bronze_uploads`, `silver_uploads`

#### 2. Load Reference Data (Document Types)
**Job**: `job_cdm_sql_load_reference_data`  
**Purpose**: Loads document type configuration  
**SQL**: `sql/load_reference_data.sql`  
**Depends on**: job_cdm_sql_setup

```bash
databricks jobs run-now --job-name job_cdm_sql_load_reference_data
```

**Creates/Populates**:
- `bronze_md.md_document_types` - Controls which document types are processed

#### 3. Run CDM Import (Operational Data)
**Job**: `job_cdm_dta_import`  
**Purpose**: Imports real operational data from source documents  
**Depends on**: job_cdm_sql_setup, job_cdm_sql_load_reference_data

```bash
databricks jobs run-now --job-name job_cdm_dta_import
```

**Populates**:
- `gold_md.md_vendor` - Vendor/data provider information (from ingested DTAs)
- `gold_md.md_study` - Study/trial information (from ingested DTAs)
- `gold_md.md_data_stream` - Data stream types (from ingested DTAs)
- `silver_md.*_draft` tables - DTA library data
- `gold_md.md_dta` - DTA metadata

#### 4. Setup App Permissions (Users & Groups)
**Job**: `job_cdm_app_permissions`  
**Purpose**: Creates permission tables and seeds test users  
**SQL**: `sql/setup_cdm_app_permissions.sql`  
**Depends on**: job_cdm_sql_setup, CDM import (for vendors)

```bash
databricks jobs run-now --job-name job_cdm_app_permissions
```

**Creates/Populates**:
- `gold_md.md_users` - Application users
- `gold_md.md_user_groups` - User groups (JNJ_DAE, VENDOR, JNJ_LIBRARIAN)
- `gold_md.md_permissions` - Permission definitions
- `gold_md.md_user_group_memberships` - User to group mappings
- `gold_md.md_group_permissions` - Group to permission mappings
- `gold_md.md_vendor` - Adds Clario (V006) if not exists

**Test Users Created**:
- **JNJ DAE**: VKapoor9@its.jnj.com, gricca4@its.jnj.com
- **Vendor**: awagle4@its.jnj.com (LabCorp), RRaoGude@its.jnj.com (Clario)
- **Librarian**: JHEERES1@its.jnj.com

#### 5. Deploy Flask App
**Purpose**: Deploys the web application with permission support  
**Depends on**: All previous jobs

```bash
cd /path/to/clinical-data-standards
./_deploy_app.sh clnl-data-std-mgmt-app
```

### Quick Start (Full Setup)

```bash
# Run all jobs in sequence
databricks jobs run-now --job-name job_cdm_sql_setup && \
databricks jobs run-now --job-name job_cdm_sql_load_reference_data && \
databricks jobs run-now --job-name job_cdm_dta_import && \
databricks jobs run-now --job-name job_cdm_app_permissions

# Deploy app
./_deploy_app.sh clnl-data-std-mgmt-app
```

### Data Flow Summary

| Job | Schema | Tables Created | Data Source |
|-----|--------|----------------|-------------|
| sql_setup | All | Schema structure | Config |
| load_reference_data | bronze_md | md_document_types | Static config |
| cdm_dta_import | silver_md, gold_md | DTA libraries, md_vendor, md_study | Ingested documents |
| app_permissions | gold_md | User/permission tables | Static seed data |

### Why This Order?

1. **Catalog/Schemas first** - Infrastructure must exist
2. **Reference data next** - Configures document processing rules
3. **CDM import** - Populates operational data (vendors, studies, DTAs)
4. **Permissions last** - Requires vendors to exist for vendor users
5. **App deployment** - Requires all data to be in place

### Re-running Individual Jobs

#### Update Permissions Only
If you need to add new users or change permissions:
```bash
databricks jobs run-now --job-name job_cdm_app_permissions
```

#### Reload Reference Data
If document type configuration changes:
```bash
databricks jobs run-now --job-name job_cdm_sql_load_reference_data
```

#### Re-import DTAs
If source documents are updated:
```bash
databricks jobs run-now --job-name job_cdm_dta_import
```

### Test Jobs (Isolated Testing)

#### Test with Separate Catalog
Use test jobs to set up and validate in an isolated test catalog (e.g., `aira_test`):

```bash
# 1. Setup test catalog
databricks jobs run-now --job-name job_test_cdm_sql_setup

# 2. Run CDM import (populate vendors)
databricks jobs run-now --job-name job_test_cdm_dta_import

# 3. Setup permissions in test catalog
databricks jobs run-now --job-name job_test_cdm_app_permissions
```

**Test Jobs Available:**
- `job_test_cdm_sql_setup` - Creates test catalog and schemas
- `job_test_cdm_app_permissions` - Sets up permissions in test catalog

**Default Test Catalog**: `${var.test_catalog}` (usually `aira_test`)

### Job Troubleshooting

#### Error: "Table md_vendor not found" during permissions setup
**Cause**: CDM import job hasn't run yet  
**Solution**: Run `job_cdm_dta_import` before `job_cdm_app_permissions`

#### Error: "Schema gold_md does not exist"
**Cause**: Setup job hasn't run  
**Solution**: Run `job_cdm_sql_setup` first

#### Error: User not found in app
**Cause**: Permissions job hasn't run or failed  
**Solution**: Run `job_cdm_app_permissions` and check logs

#### Error: "Catalog does not exist" in test job
**Cause**: Test catalog hasn't been created  
**Solution**: Run `job_test_cdm_sql_setup` first

---

## Phase 1 Implementation Summary

### Implementation Date
**Date**: January 25, 2026  
**Version**: Phase 1 - Role-Based Access Control

### Files Created

#### 1. SQL Scripts
- `sql/setup_cdm_app_permissions.sql`
  - Creates permission tables (md_users, md_user_groups, md_permissions, etc.)
  - Seeds 5 test users (2 DAE, 2 Vendor, 1 Librarian)
  - Configures permissions for 3 user groups

#### 2. Python API
- `apps/clnl-data-std-mgmt-app/api/user_management_api.py`
  - UserManagementService class
  - User lookup, group membership, permission checking APIs

#### 3. Databricks Jobs
- `resources/sql/common/jobs/job_cdm_app_permissions.job.yml`
  - Standalone Databricks job for permissions setup
  - Runs independently after CDM import
- `resources/sql/test/jobs/job_test_cdm_app_permissions.job.yml`
  - Test job with catalog override support

### Files Modified

#### 1. Flask Application
- `apps/clnl-data-std-mgmt-app/app.py`
  - Added user management integration
  - Session-based user simulation
  - Context processor for permission checking
  - 3 new API endpoints

#### 2. UI Templates
- `apps/clnl-data-std-mgmt-app/templates/base.html`
  - Added user simulation dropdown in header
  - JavaScript for user switching

#### 3. Styling
- `apps/clnl-data-std-mgmt-app/static/styles.css`
  - Styling for user simulation dropdown

#### 4. Job Configuration
- `resources/sql/common/jobs/job_cdm_sql_setup.job.yml`
  - Removed permissions task (now separate job)

#### 5. Reference Data
- `sql/load_reference_data.sql`
  - Removed redundant vendor seeding

### User Groups & Permissions

#### JNJ_DAE (Data Acquisition Engineer)
- Can create, edit, submit DTAs
- Can add comments
- Cannot promote to template
- **Users**: VKapoor9@its.jnj.com, gricca4@its.jnj.com

#### VENDOR (External Data Provider)
- Can view DTAs
- Can add comments and approve/reject
- Cannot edit DTA fields (only comment)
- Cannot promote to template
- **Users**: awagle4@its.jnj.com (LabCorp), RRaoGude@its.jnj.com (Clario)

#### JNJ_LIBRARIAN (Library Manager)
- Can view DTAs
- Can add comments
- Can promote DTAs to templates
- Cannot edit DTA fields
- **Users**: JHEERES1@its.jnj.com

### Installation Steps

1. Extract deployment package to your clinical-data-standards directory

2. Run jobs in this order:
   ```bash
   databricks jobs run-now --job-name job_cdm_sql_setup
   databricks jobs run-now --job-name job_cdm_sql_load_reference_data
   databricks jobs run-now --job-name job_cdm_dta_import
   databricks jobs run-now --job-name job_cdm_app_permissions
   ```

3. Deploy the Flask app:
   ```bash
   ./_deploy_app.sh clnl-data-std-mgmt-app
   ```

4. Access the app and test user simulation dropdown in header

### Key Features Implemented

✓ Database tables for users, groups, and permissions  
✓ 5 test users across 3 groups  
✓ User simulation dropdown in UI header  
✓ Permission checking framework (can() helper)  
✓ Separate permissions job for independent execution  
✓ Clean data flow: CDM import → vendors → permissions  
✓ Test job support with catalog override  

### Testing the Implementation

1. Access the Flask app
2. Use the user dropdown in top-right header
3. Switch between personas:
   - **Vikas Kapoor (DAE)** - Can edit DTAs
   - **Arun Wagle (LabCorp)** - Vendor, can only comment
   - **Jennifer Heeres (Librarian)** - Can promote to template

4. Verify permissions:
   - **DAE**: Can create, edit, save DTAs
   - **Vendor**: Can only add comments (edit disabled)
   - **Librarian**: Can promote to template

### Next Steps (Future Phases)

#### Phase 2
- Hide edit buttons for vendor users in workspace.html
- Add promote button visibility check
- Implement vendor data scoping (filter by vendor_id)

#### Phase 3
- Panel-level permissions
- SSO integration
- Databricks Account Manager API integration

### Support

For questions or issues:
- Check app logs: `databricks apps logs clnl-data-std-mgmt-app`
- Review job execution order above
- Consult architecture sections in this document

---

## Related Documentation

- [04_versioning_design.readme.md](./04_versioning_design.readme.md) - Version management
- [02_dta_approval_design.readme.md](./02_dta_approval_design.readme.md) - Approval workflow
- [Databricks Account Manager API](https://docs.databricks.com/api/account/users)
- [Unity Catalog Documentation](https://docs.databricks.com/data-governance/unity-catalog/index.html)

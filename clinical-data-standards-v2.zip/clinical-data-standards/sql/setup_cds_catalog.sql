
-- ============================================================================
-- Catalog and Schema Setup SQL
-- ============================================================================
-- Purpose: Create catalog, schemas, and volumes if they don't exist
-- Use Case: clinical_data_standards
--
-- Parameters (passed from job):
--   :catalog_name - The catalog to create/use
-- ============================================================================

-- Create catalog if it doesn't exist
CREATE CATALOG IF NOT EXISTS IDENTIFIER(:catalog_name)
COMMENT 'Catalog for clinical_data_standards use case';

-- Set current catalog
USE CATALOG IDENTIFIER(:catalog_name);

-- Create Bronze schema (raw/landing zone)
CREATE SCHEMA IF NOT EXISTS bronze_md
COMMENT 'Bronze layer - raw data ingestion';

-- Create Silver schema (cleaned/processed)
CREATE SCHEMA IF NOT EXISTS silver_md
COMMENT 'Silver layer - cleaned and validated data';

-- Create Gold schema (curated metadata library)
CREATE SCHEMA IF NOT EXISTS gold_md
COMMENT 'Gold layer - curated, deduplicated metadata library';

-- ============================================================================
-- Create Volumes for file storage
-- ============================================================================
-- Volume for clinical data standards files (ZIP archives, Excel files, etc.)
-- Path: /Volumes/<catalog>/bronze_md/clinical_data_standards/
CREATE VOLUME IF NOT EXISTS bronze_md.clinical_data_standards
COMMENT 'Volume for clinical data standards files - ZIP archives, Excel files, documents';

-- Display setup summary
SELECT 
  '✅ Setup Complete' as status,
  :catalog_name as catalog,
  'bronze_md, silver_md, gold_md' as schemas_created,
  'bronze_md.clinical_data_standards' as volume_created;


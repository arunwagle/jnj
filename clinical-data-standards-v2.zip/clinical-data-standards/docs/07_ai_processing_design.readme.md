# AI Design Architecture

> **Purpose**: Document the AI/ML capabilities used in the Clinical Data Standards platform for intelligent document processing, entity extraction, and structured data extraction from unstructured documents.

## Overview

The DTA project leverages multiple AI capabilities to process clinical documents that contain unstructured or semi-structured data. This architecture enables intelligent extraction of data from:

- **Operational Agreements** (PDF/Word)
- **Protocol Documents** (PDF/Word)
- **Any Unstructured Data** (Text, scanned documents)

```mermaid
flowchart TB
    subgraph Input["📄 Input Documents"]
        D1["Operational<br/>Agreements"]
        D2["Protocol<br/>Documents"]
        D3["Unstructured<br/>Data"]
    end
    
    subgraph AI["🤖 AI Processing Layer"]
        A1["ai_parse_document<br/><i>Document Parsing</i>"]
        A2["ai_query<br/><i>Entity Extraction</i>"]
        A3["Model Serving<br/><i>Prompt Engineering</i>"]
    end
    
    subgraph Models["🧠 Model Selection"]
        M1["OpenAI GPT-4"]
        M2["Llama 3"]
        M3["Claude"]
        M4["Custom Models"]
    end
    
    subgraph Output["📊 Extracted Data"]
        O1["Structured JSON"]
        O2["Entities & Relations"]
        O3["Checkboxes & Forms"]
    end
    
    Input --> AI
    AI <--> Models
    AI --> Output
    
    style AI fill:#E8F5E9,stroke:#388E3C
    style Models fill:#E3F2FD,stroke:#1565C0
```

---

## 🔧 AI Capabilities

### 1. `ai_parse_document` - Document Parsing

**Purpose**: Parse unstructured documents (PDF, Word, scanned images) into structured, queryable content.

```mermaid
flowchart LR
    subgraph Input["📥 Input"]
        I1["PDF"]
        I2["Word (.docx)"]
        I3["Scanned Image"]
    end
    
    subgraph Parse["🔍 ai_parse_document"]
        P1["OCR Processing"]
        P2["Layout Detection"]
        P3["Text Extraction"]
        P4["Table Detection"]
    end
    
    subgraph Output["📤 Output"]
        O1["Parsed Text"]
        O2["Document Structure"]
        O3["Extracted Tables"]
    end
    
    Input --> Parse --> Output
    
    style Parse fill:#FFF3E0,stroke:#EF6C00
```

#### Use Cases

| Document Type | What's Extracted | Example |
|---------------|------------------|---------|
| Operational Agreements | Terms, conditions, parties | "Vendor: ABC Corp, Start Date: 2025-01-01" |
| Protocol Documents | Study design, endpoints, criteria | "Primary Endpoint: Overall Survival" |
| Scanned Forms | Text from images, handwriting | OCR'd text from legacy documents |

#### Example Usage

```python
from databricks.sdk.runtime import spark

# Parse a PDF document
result = spark.sql("""
    SELECT ai_parse_document(
        content,
        'pdf'
    ) as parsed_content
    FROM bronze_md.md_dta_history
    WHERE ARRAY_CONTAINS(document_tags, 'OPERATIONAL_AGREEMENT')
""")
```

---

### 2. `ai_query` - Entity Extraction

**Purpose**: Extract specific entities, relationships, and structured data from parsed documents using natural language queries.

```mermaid
flowchart TD
    subgraph Input["📥 Parsed Document"]
        I1["Document Text"]
    end
    
    subgraph Query["❓ ai_query"]
        Q1["Natural Language Query"]
        Q2["Entity Recognition"]
        Q3["Relationship Extraction"]
    end
    
    subgraph Output["📤 Extracted Entities"]
        O1["Named Entities"]
        O2["Key-Value Pairs"]
        O3["Relationships"]
    end
    
    Input --> Query --> Output
    
    style Query fill:#E8EAF6,stroke:#3F51B5
```

#### Use Cases

| Query Type | Example Query | Expected Output |
|------------|---------------|-----------------|
| Entity Extraction | "Extract all vendor names" | ["ABC Corp", "XYZ Labs"] |
| Date Extraction | "What is the contract start date?" | "2025-01-15" |
| Relationship | "Who is the primary contact?" | "John Smith, john@vendor.com" |
| Conditional | "List all mandatory requirements" | ["Requirement A", "Requirement B"] |

#### Example Usage

```python
# Extract specific entities using natural language
result = spark.sql("""
    SELECT ai_query(
        parsed_content,
        'Extract the vendor name, contract start date, and data transfer frequency'
    ) as extracted_entities
    FROM silver_md.md_parsed_documents
    WHERE document_type = 'OPERATIONAL_AGREEMENT'
""")
```

---

### 3. Databricks Model Serving - Prompt Engineering

**Purpose**: Use custom prompts with configurable models (OpenAI, Llama, Claude) to extract complex structures like checkboxes, forms, and multi-part data.

```mermaid
flowchart TB
    subgraph Endpoint["🎯 Model Serving Endpoint"]
        E1["dta-document-extraction"]
    end
    
    subgraph Router["🔀 Model Router"]
        R1{"Document<br/>Type?"}
    end
    
    subgraph Models["🧠 Available Models"]
        M1["OpenAI GPT-4<br/><i>Complex reasoning</i>"]
        M2["Llama 3 70B<br/><i>Cost-effective</i>"]
        M3["Claude 3<br/><i>Long context</i>"]
        M4["Custom Fine-tuned<br/><i>Domain-specific</i>"]
    end
    
    subgraph UseCase["📋 Use Case Routing"]
        U1["Operational Agreement<br/>→ GPT-4"]
        U2["Protocol Summary<br/>→ Llama 3"]
        U3["Long Documents<br/>→ Claude 3"]
        U4["Checkbox Extraction<br/>→ Custom Model"]
    end
    
    Endpoint --> Router
    Router --> Models
    Models --> UseCase
    
    style Endpoint fill:#C8E6C9,stroke:#388E3C
    style Router fill:#FFF59D,stroke:#F9A825
```

#### Model Selection Strategy

```mermaid
flowchart TD
    Start["📄 Document Received"] --> Check1{"Document<br/>Type?"}
    
    Check1 -->|"Operational Agreement"| OA["Complex Terms<br/>Extraction"]
    Check1 -->|"Protocol"| PD["Study Design<br/>Extraction"]
    Check1 -->|"Checkbox Form"| CB["Form Field<br/>Extraction"]
    
    OA --> Model1["🟢 GPT-4<br/><i>High accuracy needed</i>"]
    PD --> Model2["🔵 Llama 3<br/><i>Cost-effective</i>"]
    CB --> Model3["🟣 Custom Model<br/><i>Trained on forms</i>"]
    
    Model1 --> Output["📊 Structured Output"]
    Model2 --> Output
    Model3 --> Output
    
    style Model1 fill:#C8E6C9,stroke:#388E3C
    style Model2 fill:#BBDEFB,stroke:#1565C0
    style Model3 fill:#E1BEE7,stroke:#7B1FA2
```

#### Why Model Serving?

| Benefit | Description |
|---------|-------------|
| **Model Flexibility** | Switch between OpenAI, Llama, Claude without code changes |
| **Cost Optimization** | Use cheaper models for simpler tasks, premium for complex |
| **A/B Testing** | Compare model performance on same documents |
| **Scalability** | Auto-scaling based on document volume |
| **Version Control** | Deploy new model versions with rollback capability |
| **Custom Prompts** | Document-type specific prompt engineering |

---

## 🔀 Model Routing Architecture

### Configuration-Driven Model Selection

```mermaid
flowchart LR
    subgraph Config["⚙️ Configuration"]
        C1["model_routing.yaml"]
    end
    
    subgraph Routing["🔀 Routing Logic"]
        R1["Document Type"]
        R2["Complexity Score"]
        R3["Cost Budget"]
        R4["Latency SLA"]
    end
    
    subgraph Selection["✅ Model Selected"]
        S1["Endpoint + Model"]
    end
    
    Config --> Routing --> Selection
    
    style Config fill:#FFF3E0,stroke:#EF6C00
```

#### Example Configuration

```yaml
# config/model_routing.yaml
model_serving:
  endpoint_name: "dta-document-extraction"
  
  # Model routing rules
  routing:
    operational_agreement:
      default_model: "openai-gpt-4"
      fallback_model: "llama-3-70b"
      max_tokens: 4096
      temperature: 0.1  # Low for consistency
      
    protocol_document:
      default_model: "llama-3-70b"
      fallback_model: "openai-gpt-4"
      max_tokens: 8192
      temperature: 0.2
      
    checkbox_extraction:
      default_model: "custom-form-extractor"
      fallback_model: "openai-gpt-4"
      max_tokens: 2048
      temperature: 0.0  # Deterministic
      
    long_document:
      default_model: "claude-3-opus"  # 200K context
      fallback_model: "openai-gpt-4-turbo"
      max_tokens: 16384
      
  # Cost controls
  cost_limits:
    daily_budget_usd: 100
    per_document_max_usd: 0.50
    prefer_cost_effective: true
```

---

## 📝 Prompt Engineering Patterns

### Pattern 1: Checkbox Extraction

```mermaid
flowchart LR
    subgraph Input["📄 Scanned Form"]
        I1["☑ Option A<br/>☐ Option B<br/>☑ Option C"]
    end
    
    subgraph Prompt["💬 Engineered Prompt"]
        P1["Extract all checkboxes.<br/>Return checked=true/false<br/>for each option."]
    end
    
    subgraph Output["📊 Structured JSON"]
        O1["{'Option A': true,<br/>'Option B': false,<br/>'Option C': true}"]
    end
    
    Input --> Prompt --> Output
    
    style Prompt fill:#E8F5E9,stroke:#388E3C
```

#### Example Prompt Template

```python
CHECKBOX_EXTRACTION_PROMPT = """
You are analyzing a clinical document form. Extract all checkbox fields.

For each checkbox, determine:
1. The label/description of the checkbox
2. Whether it is checked (☑/✓/X) or unchecked (☐/empty)

Return a JSON object with this structure:
{
  "checkboxes": [
    {"label": "...", "checked": true/false, "confidence": 0.0-1.0}
  ]
}

Document content:
{document_text}
"""
```

### Pattern 2: Entity Extraction with Schema

```mermaid
flowchart TD
    subgraph Schema["📋 Target Schema"]
        S1["vendor_name: STRING"]
        S2["contract_date: DATE"]
        S3["transfer_frequency: STRING"]
        S4["data_formats: ARRAY"]
    end
    
    subgraph Prompt["💬 Schema-Guided Prompt"]
        P1["Extract entities matching<br/>the provided schema"]
    end
    
    subgraph Output["📊 Validated JSON"]
        O1["Matches schema exactly"]
    end
    
    Schema --> Prompt --> Output
    
    style Schema fill:#E3F2FD,stroke:#1565C0
```

#### Example Prompt Template

```python
ENTITY_EXTRACTION_PROMPT = """
You are extracting structured data from a clinical operational agreement.

Extract the following fields and return as JSON:
- vendor_name (string): The name of the external data provider
- contract_start_date (date): Format YYYY-MM-DD
- contract_end_date (date): Format YYYY-MM-DD  
- transfer_frequency (string): How often data is transferred (daily, weekly, monthly)
- data_formats (array): List of data formats (CSV, SAS, Excel, etc.)
- primary_contact_name (string): Main point of contact
- primary_contact_email (string): Contact email

If a field is not found, set it to null.
Include a confidence score (0.0-1.0) for each extracted field.

Document:
{document_text}
"""
```

### Pattern 3: Protocol Document Parsing

```mermaid
flowchart TD
    subgraph Protocol["📄 Protocol Document"]
        P1["Study Title"]
        P2["Objectives"]
        P3["Endpoints"]
        P4["Inclusion/Exclusion"]
    end
    
    subgraph Sections["📑 Section Detection"]
        S1["Identify section headers"]
        S2["Extract section content"]
        S3["Parse structured lists"]
    end
    
    subgraph Output["📊 Structured Protocol"]
        O1["study_info: {...}"]
        O2["objectives: [...]"]
        O3["endpoints: {...}"]
        O4["criteria: {...}"]
    end
    
    Protocol --> Sections --> Output
    
    style Sections fill:#FFF3E0,stroke:#EF6C00
```

---

## 🏗️ Integration Architecture

### End-to-End Document Processing Flow

```mermaid
flowchart TB
    subgraph Bronze["🟤 Bronze Layer"]
        B1["md_dta_history<br/>Raw documents"]
    end
    
    subgraph Processing["⚙️ AI Processing"]
        P1["ai_parse_document<br/>PDF/Word → Text"]
        P2["ai_query<br/>Entity Extraction"]
        P3["Model Serving<br/>Complex Extraction"]
    end
    
    subgraph Silver["⚪ Silver Layer"]
        S1["md_parsed_documents<br/>Parsed content"]
        S2["md_extracted_entities<br/>Structured entities"]
    end
    
    subgraph Gold["🟡 Gold Layer"]
        G1["DTA<br/>Complete records"]
    end
    
    Bronze --> P1
    P1 --> S1
    S1 --> P2
    S1 --> P3
    P2 --> S2
    P3 --> S2
    S2 --> Gold
    
    style Processing fill:#E8F5E9,stroke:#388E3C
```

### Notebook Integration Example

```python
# notebooks/data_engineering/clinical_data_standards/jobs/nb_ai_document_processor.ipynb

from databricks.sdk.runtime import spark
import requests

# 1. Parse document using ai_parse_document
df_parsed = spark.sql("""
    SELECT 
        document_id,
        ai_parse_document(content_base64, 'pdf') as parsed_text
    FROM bronze_md.md_dta_history
    WHERE ARRAY_CONTAINS(document_tags, 'OPERATIONAL_AGREEMENT')
      AND current_status = 'READY_FOR_PROCESSING'
""")

# 2. Extract entities using ai_query
df_entities = spark.sql("""
    SELECT 
        document_id,
        ai_query(
            parsed_text, 
            'Extract vendor name, contract dates, and data transfer requirements'
        ) as entities
    FROM parsed_documents
""")

# 3. Complex extraction via Model Serving endpoint
def extract_checkboxes(document_text):
    endpoint_url = f"https://{workspace}/serving-endpoints/dta-document-extraction/invocations"
    
    response = requests.post(
        endpoint_url,
        headers={"Authorization": f"Bearer {token}"},
        json={
            "model": "checkbox-extractor",
            "messages": [
                {"role": "system", "content": CHECKBOX_EXTRACTION_PROMPT},
                {"role": "user", "content": document_text}
            ]
        }
    )
    return response.json()
```

---

## 📊 Model Comparison

| Model | Best For | Context Length | Cost | Latency |
|-------|----------|----------------|------|---------|
| **OpenAI GPT-4** | Complex reasoning, accuracy-critical | 128K | $$$ | Medium |
| **OpenAI GPT-4o** | Balanced performance | 128K | $$ | Fast |
| **Llama 3 70B** | Cost-effective, privacy | 8K | $ | Fast |
| **Llama 3.1 405B** | Open-source, high capability | 128K | $$ | Medium |
| **Claude 3 Opus** | Very long documents | 200K | $$$ | Medium |
| **Claude 3 Sonnet** | Balanced, long context | 200K | $$ | Fast |
| **Custom Fine-tuned** | Domain-specific tasks | Varies | $ | Fast |

### Model Selection Decision Tree

```mermaid
flowchart TD
    Start["🚀 Start"] --> Q1{"Document<br/>Length?"}
    
    Q1 -->|"> 100K tokens"| Long["Long Document"]
    Q1 -->|"< 100K tokens"| Normal["Normal Length"]
    
    Long --> Claude["Claude 3 Opus<br/><i>200K context</i>"]
    
    Normal --> Q2{"Accuracy<br/>Critical?"}
    Q2 -->|"Yes"| GPT4["GPT-4<br/><i>Highest accuracy</i>"]
    Q2 -->|"No"| Q3{"Budget<br/>Constrained?"}
    
    Q3 -->|"Yes"| Llama["Llama 3<br/><i>Cost-effective</i>"]
    Q3 -->|"No"| GPT4o["GPT-4o<br/><i>Balanced</i>"]
    
    style Claude fill:#E1BEE7,stroke:#7B1FA2
    style GPT4 fill:#C8E6C9,stroke:#388E3C
    style Llama fill:#BBDEFB,stroke:#1565C0
    style GPT4o fill:#FFF59D,stroke:#F9A825
```

---

## 🔗 Related Documentation

- [01_job_architecture_design.readme.md](./01_job_architecture_design.readme.md) - Overall pipeline architecture
- [03_status_lifecycle_design.readme.md](./03_status_lifecycle_design.readme.md) - Document processing statuses
- [02_schema_design.readme.md](./02_schema_design.readme.md) - Schema for extracted data

---

*Last Updated: December 2025*


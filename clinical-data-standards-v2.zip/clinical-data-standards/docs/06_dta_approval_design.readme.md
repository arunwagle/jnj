# DTA Approval Flow - Governance & Lifecycle Management

This document describes the approval flow for Data Transfer Agreements (DTAs), including user assignment, state transitions, and the approval chain mechanism.

> **Related Diagrams**:
> - [`06_dta_approval_design.drawio`](./diagrams/06_dta_approval_design.drawio) - Visual representation of the approval flow
> - [`04_versioning_design.drawio`](./diagrams/04_versioning_design.drawio) - How approval triggers version creation
> - [`04_versioning_design.readme.md`](./04_versioning_design.readme.md) - Version management operations

---

## Table of Contents

1. [Overview](#overview)
2. [Key Tables](#key-tables)
3. [DTA Lifecycle States](#dta-lifecycle-states)
4. [Approval Chain & User Assignment](#approval-chain--user-assignment)
5. [State Transitions](#state-transitions)
6. [Approval Ordering Mechanism](#approval-ordering-mechanism)
7. [Schema Examples](#schema-examples)
8. [Library Promotion (Librarian Flow)](#library-promotion-librarian-flow)

---

## Overview

The DTA approval flow manages the governance process from DTA creation through final approval. It supports:

- **Multi-party approval**: JNJ DAE, Vendor, Legal (future), Librarian
- **Ordered approval chain**: Approvers review in sequence
- **Rejection handling**: Any rejection returns DTA to editing state
- **Version creation**: Approval triggers DTA Major version creation
- **Library promotion**: Separate librarian-driven process

```mermaid
flowchart LR
    A["🆕 DTA<br/>Created"] --> B["📤 Submit for<br/>Approval"]
    B --> C{{"🔍 Approval<br/>Chain"}}
    C -->|"✅ All Approve"| D["✅ APPROVED"]
    C -->|"❌ Rejected"| A
    D --> E["📦 DTA Major<br/>Version"]
    
    style A fill:#dae8fc,stroke:#6c8ebf
    style D fill:#d5e8d4,stroke:#82b366
    style E fill:#d5e8d4,stroke:#82b366
```

---

## Key Tables

### 1. `DTA` - Core DTA Entity

The central entity representing a Data Transfer Agreement.

| Column | Type | Description |
|--------|------|-------------|
| `dta_id` | STRING | PK - UUID identifier |
| `dta_number` | STRING | Human-readable ID (e.g., DTA001) |
| `trial_id` | STRING | Associated trial |
| `data_stream_type` | STRING | Data stream type (e.g., PF, EDC) |
| `data_provider_name` | STRING | Vendor/provider name |
| `status` | STRING | DRAFT, PENDING_APPROVAL, APPROVED, REJECTED |
| `current_version_tag` | STRING | Current working version |
| `workflow_state` | STRING | NOT_STARTED, IN_REVIEW, APPROVED |
| `workflow_iteration` | INT | Current approval cycle number |
| `notes` | STRING | General notes |
| *Audit columns* | | Standard audit fields |

### 2. `DTA_WORKFLOW` - Approval Cycle Tracking

Tracks each approval cycle for a DTA. A DTA can have multiple workflow iterations if rejected and resubmitted.

| Column | Type | Description |
|--------|------|-------------|
| `dta_workflow_id` | STRING | PK - UUID identifier |
| `dta_id` | STRING | FK - Reference to DTA |
| `workflow_iteration` | INT | Iteration number (1, 2, 3...) |
| `workflow_status` | STRING | NOT_STARTED, IN_REVIEW, APPROVED, REJECTED |
| `summary_comment` | STRING | Overall workflow notes/comments |
| `initiated_ts` | TIMESTAMP | When workflow was started |
| `submitted_by` | STRING | Principal who submitted |
| `submitted_ts` | TIMESTAMP | Submission timestamp |
| `completed_ts` | TIMESTAMP | When workflow completed |
| *Audit columns* | | Standard audit fields |

### 3. `DTA_APPROVAL_TASK` - Individual Approver Tasks

Each approver in the chain gets a task record. **Order is critical** - controlled by `approval_order`.

| Column | Type | Description |
|--------|------|-------------|
| `dta_approval_task_id` | STRING | PK - UUID identifier |
| `dta_workflow_id` | STRING | FK - Reference to workflow |
| `dta_id` | STRING | FK - Reference to DTA |
| `approver_role` | STRING | Role: JNJ_DAE, VENDOR, LEGAL, LIBRARIAN |
| `approver_principal` | STRING | Assigned user email/principal |
| `approval_order` | INT | **Sequence order (1, 2, 3...)** |
| `is_mandatory` | BOOLEAN | Whether approval is required |
| `approval_status` | STRING | PENDING, APPROVED, REJECTED, SKIPPED |
| `approval_ts` | TIMESTAMP | When approved/rejected |
| `response_comment` | STRING | Approver's comment |
| `last_reminder_ts` | TIMESTAMP | Last reminder sent |
| `reminder_count` | INT | Number of reminders sent |
| *Audit columns* | | Standard audit fields |

---

## DTA Lifecycle States

### DTA Status Values

| Status | Description | Can Edit? |
|--------|-------------|-----------|
| `DRAFT` | DTA is being created/edited | ✅ Yes |
| `PENDING_APPROVAL` | Submitted, awaiting approval | ❌ No (read-only) |
| `APPROVED` | All approvers approved | ❌ No |
| `REJECTED` | At least one approver rejected | ✅ Yes (returns to DRAFT) |
| `MANUAL_REVIEW` | Contains records needing manual review | ✅ Yes |

### Workflow Status Values

| Status | Description |
|--------|-------------|
| `NOT_STARTED` | Workflow created but not submitted |
| `IN_REVIEW` | Submitted and awaiting approvals |
| `APPROVED` | All approvers approved |
| `REJECTED` | At least one approver rejected |

### Approval Task Status Values

| Status | Description |
|--------|-------------|
| `PENDING` | Awaiting this approver's decision |
| `APPROVED` | Approver approved |
| `REJECTED` | Approver rejected |
| `SKIPPED` | Non-mandatory task skipped |

---

## Approval Chain & User Assignment

### Approver Roles

| Role | Description | Mandatory | Future |
|------|-------------|-----------|--------|
| `JNJ_DAE` | JNJ Data Analytics Engineer | ✅ Yes | Current |
| `VENDOR` | External Data Provider | ✅ Yes | Current |
| `LEGAL` | Legal Review | ⚪ Optional | 🔜 Future |
| `LIBRARIAN` | Library promotion (separate flow) | ✅ Yes | Current |

### Adding Approvers to a DTA

When a DTA is created or before submission, approvers are assigned:

```python
# Example: Assigning approvers for a new DTA
approval_tasks = [
    {
        "dta_approval_task_id": str(uuid.uuid4()),
        "dta_workflow_id": workflow_id,
        "dta_id": dta_id,
        "approver_role": "JNJ_DAE",
        "approver_principal": "john.doe@jnj.com",
        "approval_order": 1,  # First in sequence
        "is_mandatory": True,
        "approval_status": "PENDING"
    },
    {
        "dta_approval_task_id": str(uuid.uuid4()),
        "dta_workflow_id": workflow_id,
        "dta_id": dta_id,
        "approver_role": "VENDOR",
        "approver_principal": "vendor.contact@partner.com",
        "approval_order": 2,  # Second in sequence
        "is_mandatory": True,
        "approval_status": "PENDING"
    },
    {
        "dta_approval_task_id": str(uuid.uuid4()),
        "dta_workflow_id": workflow_id,
        "dta_id": dta_id,
        "approver_role": "LEGAL",
        "approver_principal": "legal.team@jnj.com",
        "approval_order": 3,  # Third in sequence (future)
        "is_mandatory": False,  # Optional for now
        "approval_status": "PENDING"
    }
]
```

---

## State Transitions

### Transition Diagram

```mermaid
flowchart TD
    %% Main Flow
    A[/"🆕 DTA Created<br/>(status=DRAFT)"/] --> B["📝 Save Draft"]
    B <-.-> C["✏️ Edit Variables"]
    B --> D["📤 Submit for Review<br/>(workflow_status=IN_REVIEW)"]
    
    %% Approval Chain
    D --> E{{"🔍 Approval Chain"}}
    
    subgraph chain["Approval Chain (by approval_order)"]
        direction TB
        F["1️⃣ JNJ_DAE<br/>order=1"] -->|"✅ Approved"| G["2️⃣ VENDOR<br/>order=2"]
        G -->|"✅ Approved"| H["3️⃣ LEGAL 🔜<br/>order=3<br/>(Future - Optional)"]
    end
    
    E --> F
    
    %% Outcomes
    H -->|"✅ All Approved"| I["✅ APPROVED"]
    chain -->|"❌ Any Rejected"| J["❌ REJECTED<br/>(back to DRAFT)"]
    J -->|"workflow_iteration++"| A
    
    %% Version Creation
    I --> K["📦 DTA Major Version<br/>1.0-DTA001-v1.0"]
    
    %% Continue Decision
    K --> L{"Continue<br/>Working?"}
    L -->|"Yes"| A
    L -->|"No"| M(("🏁 End"))

    %% Styling
    style A fill:#dae8fc,stroke:#6c8ebf,stroke-width:2px
    style D fill:#fff2cc,stroke:#d6b656,stroke-width:2px
    style I fill:#d5e8d4,stroke:#82b366,stroke-width:2px
    style J fill:#f8cecc,stroke:#b85450,stroke-width:2px
    style K fill:#d5e8d4,stroke:#82b366,stroke-width:2px
    style F fill:#e1d5e7,stroke:#9673a6,stroke-width:2px
    style G fill:#e1d5e7,stroke:#9673a6,stroke-width:2px
    style H fill:#f5f5f5,stroke:#999999,stroke-width:2px,stroke-dasharray: 5 5
```

### Transition Details

| # | From State | Trigger | To State | Actions |
|---|------------|---------|----------|---------|
| 1 | DRAFT | User saves changes | DRAFT | `save_dta_draft()` - creates draft version |
| 2 | DRAFT | User submits for review | PENDING_APPROVAL / IN_REVIEW | Workflow status = IN_REVIEW, first approver notified |
| 3 | IN_REVIEW | Approver approves | IN_REVIEW | Move to next approver (by `approval_order`) |
| 4 | IN_REVIEW | All approvers approve | APPROVED | `approve_dta_version()` - creates DTA Major |
| 5 | IN_REVIEW | Any approver rejects | REJECTED / DRAFT | Workflow ends, DTA returns to DRAFT |
| 6 | APPROVED | User continues work | DRAFT | New workflow iteration (increment `workflow_iteration`) |

---

## Approval Ordering Mechanism

### How `approval_order` Works

The `approval_order` column in `DTA_APPROVAL_TASK` controls the sequence:

```sql
-- Get next pending approver for a workflow
SELECT * FROM dta_approval_task
WHERE dta_workflow_id = :workflow_id
  AND approval_status = 'PENDING'
  AND is_mandatory = TRUE
ORDER BY approval_order ASC
LIMIT 1;
```

### Ordering Rules

1. **Sequential Processing**: Approvers are processed in `approval_order` sequence (1 → 2 → 3...)
2. **Mandatory First**: Mandatory approvers must complete before optional ones
3. **Blocking**: An approver cannot act until all previous mandatory approvers have approved
4. **Skip Logic**: Non-mandatory approvers can be skipped if not assigned

### Example Approval Flow

| Time | Action | approval_order | Status |
|------|--------|----------------|--------|
| T1 | Submit for approval | - | Workflow: `IN_REVIEW` |
| T2 | Notify JNJ_DAE (first) | 1 | `PENDING` → notified |
| T3 | JNJ_DAE approves | 1 | ✅ `APPROVED` |
| T4 | Notify VENDOR (second) | 2 | `PENDING` → notified |
| T5 | VENDOR approves | 2 | ✅ `APPROVED` |
| T6 | LEGAL skipped (optional) | 3 | ⏭️ `SKIPPED` (is_mandatory=false) |
| T7 | All complete | - | Workflow: ✅ `APPROVED` |
| T8 | DTA Major version created | - | Version: `1.0-DTA001-v1.0` |

---

## Schema Examples

### Example 1: New DTA Creation

```json
// DTA Record
{
  "dta_id": "883bcb88-1234-5678-abcd-ef0123456789",
  "dta_number": "DTA001",
  "trial_id": "VAC18193RSV3001",
  "data_stream_type": "PF",
  "data_provider_name": "Adaptive",
  "status": "DRAFT",
  "current_version_tag": "1.0-DTA001-draft1",
  "workflow_state": "NOT_STARTED",
  "workflow_iteration": 1
}

// DTA_WORKFLOW Record
{
  "dta_workflow_id": "wf-001-uuid",
  "dta_id": "883bcb88-1234-5678-abcd-ef0123456789",
  "workflow_iteration": 1,
  "workflow_status": "NOT_STARTED",
  "initiated_ts": "2025-12-09T10:00:00Z"
}

// DTA_APPROVAL_TASK Records (initial setup)
[
  {
    "dta_approval_task_id": "task-001-uuid",
    "dta_workflow_id": "wf-001-uuid",
    "dta_id": "883bcb88-1234-5678-abcd-ef0123456789",
    "approver_role": "JNJ_DAE",
    "approver_principal": "john.doe@jnj.com",
    "approval_order": 1,
    "is_mandatory": true,
    "approval_status": "PENDING"
  },
  {
    "dta_approval_task_id": "task-002-uuid",
    "dta_workflow_id": "wf-001-uuid",
    "dta_id": "883bcb88-1234-5678-abcd-ef0123456789",
    "approver_role": "VENDOR",
    "approver_principal": "partner@vendor.com",
    "approval_order": 2,
    "is_mandatory": true,
    "approval_status": "PENDING"
  }
]
```

### Example 2: After Approval Complete

```json
// DTA Record (updated)
{
  "dta_id": "883bcb88-1234-5678-abcd-ef0123456789",
  "dta_number": "DTA001",
  "status": "APPROVED",
  "current_version_tag": "1.0-DTA001-v1.0",  // Now DTA Major
  "workflow_state": "APPROVED",
  "workflow_iteration": 1
}

// DTA_WORKFLOW Record (completed)
{
  "dta_workflow_id": "wf-001-uuid",
  "workflow_status": "APPROVED",
  "completed_ts": "2025-12-09T14:30:00Z"
}

// DTA_APPROVAL_TASK Records (all approved)
[
  {
    "dta_approval_task_id": "task-001-uuid",
    "approval_status": "APPROVED",
    "approval_ts": "2025-12-09T11:00:00Z",
    "response_comment": "Looks good, approved."
  },
  {
    "dta_approval_task_id": "task-002-uuid",
    "approval_status": "APPROVED",
    "approval_ts": "2025-12-09T14:30:00Z",
    "response_comment": "Vendor review complete."
  }
]
```

### Example 3: Rejection Scenario

```json
// DTA_APPROVAL_TASK - VENDOR rejects
{
  "dta_approval_task_id": "task-002-uuid",
  "approval_status": "REJECTED",
  "approval_ts": "2025-12-09T12:00:00Z",
  "response_comment": "Variable XYZ needs correction. Please review format."
}

// DTA Record (updated after rejection)
{
  "status": "DRAFT",  // Back to draft for editing
  "workflow_state": "NOT_STARTED",
  "workflow_iteration": 2  // New cycle will start
}

// New DTA_WORKFLOW Record (new iteration)
{
  "dta_workflow_id": "wf-002-uuid",
  "dta_id": "883bcb88-1234-5678-abcd-ef0123456789",
  "workflow_iteration": 2,  // Incremented
  "workflow_status": "NOT_STARTED"
}
```

---

## Library Promotion (Librarian Flow)

### Separate from DTA Approval

Library promotion is a **separate process** managed by a Librarian role. It occurs **after** DTA approval and is **outside** the standard DTA approval chain.

```mermaid
flowchart LR
    subgraph approved["Approved DTAs"]
        A["✅ DTA_A Approved<br/>1.0-DTA001-v1.0"]
        B["✅ DTA_B Approved<br/>1.0-DTA002-v1.0"]
    end
    
    A --> C{{"🔀 Merge"}}
    B --> C
    
    C --> D["📚 Librarian<br/>Reviews &<br/>Approves"]
    
    D -->|"✅ Promote"| E["📦 Library Major<br/>v2.0"]
    
    style A fill:#d5e8d4,stroke:#82b366
    style B fill:#d5e8d4,stroke:#82b366
    style D fill:#fff2cc,stroke:#d6b656
    style E fill:#dae8fc,stroke:#6c8ebf,stroke-width:3px
```

### Librarian Approval Task

When promoting to Library Major, a separate approval task is created:

```json
{
  "dta_approval_task_id": "lib-task-001-uuid",
  "dta_workflow_id": null,  // Not part of DTA workflow
  "dta_id": null,           // Library-level, not DTA-specific
  "approver_role": "LIBRARIAN",
  "approver_principal": "librarian@jnj.com",
  "approval_order": 1,
  "is_mandatory": true,
  "approval_status": "PENDING",
  "response_comment": null,
  "context": {
    "action": "PROMOTE_TO_LIBRARY",
    "source_versions": ["1.0-DTA001-v1.0", "1.0-DTA002-v1.0"],
    "target_version": "2.0"
  }
}
```

### Key Differences from DTA Approval

| Aspect | DTA Approval | Library Promotion |
|--------|--------------|-------------------|
| Trigger | User submits DTA | Librarian initiates |
| Approvers | JNJ_DAE, Vendor, Legal | Librarian only |
| Scope | Single DTA | Multiple DTAs (merge) |
| Result | DTA Major version | Library Major version |
| Tables | DTA_WORKFLOW, DTA_APPROVAL_TASK | Separate tracking (or extended task) |

---

## SQL Queries

### Get Current Approver for a DTA

```sql
SELECT 
  t.approver_role,
  t.approver_principal,
  t.approval_order
FROM dta_approval_task t
JOIN dta_workflow w ON t.dta_workflow_id = w.dta_workflow_id
WHERE w.dta_id = :dta_id
  AND w.workflow_iteration = (
    SELECT MAX(workflow_iteration) 
    FROM dta_workflow 
    WHERE dta_id = :dta_id
  )
  AND t.approval_status = 'PENDING'
  AND t.is_mandatory = TRUE
ORDER BY t.approval_order ASC
LIMIT 1;
```

### Get Approval History for a DTA

```sql
SELECT 
  w.workflow_iteration,
  t.approver_role,
  t.approver_principal,
  t.approval_status,
  t.approval_ts,
  t.response_comment
FROM dta_approval_task t
JOIN dta_workflow w ON t.dta_workflow_id = w.dta_workflow_id
WHERE w.dta_id = :dta_id
ORDER BY w.workflow_iteration, t.approval_order;
```

### Check if All Approvals Complete

```sql
SELECT 
  CASE 
    WHEN COUNT(*) = 0 THEN TRUE  -- No pending mandatory tasks
    ELSE FALSE
  END as all_approved
FROM dta_approval_task
WHERE dta_workflow_id = :workflow_id
  AND is_mandatory = TRUE
  AND approval_status = 'PENDING';
```

---

## Summary

| Component | Purpose |
|-----------|---------|
| `DTA` | Core entity - tracks overall DTA state |
| `DTA_WORKFLOW` | Tracks each approval cycle (iteration) |
| `DTA_APPROVAL_TASK` | Individual approver tasks with ordering |
| `approval_order` | Controls sequence of approvers |
| `workflow_iteration` | Allows multiple approval cycles after rejection |
| Librarian Flow | Separate process for Library Major promotion |

---

*Last Updated: December 2025*


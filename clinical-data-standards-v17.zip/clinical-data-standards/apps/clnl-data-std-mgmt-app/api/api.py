"""
API Layer for DTA Studio
This module provides a clean API interface for all data operations.
In production, these functions would call actual backend services.
"""

import os
from datetime import datetime
import json
import random

# Import mock data and helper functions
from . import data
from .data import WORKSPACES, MOCK_RUNS, MOCK_RESULTS, EMPTY_ENTITIES

# Import Databricks client for real API integration
from .databricks_client import DatabricksJobsClient


# ============================================================================
# Dashboard APIs
# ============================================================================

def get_dashboard_dtas(status_filter=None):
    """
    Get DTAs for dashboard
    Args:
        status_filter: Optional filter ('pending', 'approved', or None for all)
    Returns:
        dict with success, data (list of DTAs), and counts
    """
    try:
        all_dtas = []
        for ws in WORKSPACES.values():
            ws_status = ws.get("status", "Draft")
            if ws_status in ["Pending Approval", "Approved"]:
                all_dtas.append(ws)
        
        # Sort by submitted_at (most recent first)
        all_dtas.sort(key=lambda x: x.get("submitted_at", ""), reverse=True)
        
        # Filter if requested
        if status_filter == "pending":
            filtered_dtas = [ws for ws in all_dtas if ws.get("status") == "Pending Approval"]
        elif status_filter == "approved":
            filtered_dtas = [ws for ws in all_dtas if ws.get("status") == "Approved"]
        else:
            filtered_dtas = all_dtas
        
        pending_count = len([ws for ws in all_dtas if ws.get("status") == "Pending Approval"])
        approved_count = len([ws for ws in all_dtas if ws.get("status") == "Approved"])
        
        return {
            "success": True,
            "data": {
                "dtas": filtered_dtas,
                "total_count": len(all_dtas),
                "pending_count": pending_count,
                "approved_count": approved_count
            }
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


# ============================================================================
# Workspace APIs
# ============================================================================

def get_workspace(key):
    """Get workspace by key"""
    ws = WORKSPACES.get(key)
    if not ws:
        return {"success": False, "error": "Workspace not found"}
    return {"success": True, "data": ws}


def search_workspaces(query):
    """
    Search for workspaces in composer
    Returns matching results from MOCK_RESULTS
    If query is empty, returns all results (for advanced filtering in route)
    """
    try:
        if not query:
            # Return all results - let the route handle filtering
            return {"success": True, "data": MOCK_RESULTS}
        
        # Simple substring search
        q_lower = query.lower()
        results = [
            r for r in MOCK_RESULTS 
            if q_lower in r["trial"].lower() 
            or q_lower in r["vendor"].lower() 
            or q_lower in r["stream"].lower()
        ]
        
        return {"success": True, "data": results}
    except Exception as e:
        return {"success": False, "error": str(e)}


def create_or_get_workspace(result):
    """Create workspace from search result or get existing"""
    try:
        ws = data.get_or_create_workspace(result)
        return {"success": True, "data": ws}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ============================================================================
# Approval APIs
# ============================================================================

def get_pending_approvals():
    """Get all DTAs pending approval"""
    try:
        pending_dtas = [
            ws for ws in WORKSPACES.values() 
            if ws.get("status") == "Pending Approval"
        ]
        pending_dtas.sort(key=lambda x: x.get("submitted_at", ""), reverse=True)
        return {"success": True, "data": pending_dtas}
    except Exception as e:
        return {"success": False, "error": str(e)}


def submit_for_approval(key, approvers):
    """
    Submit DTA for approval
    Args:
        key: Workspace key
        approvers: List of approver objects with role, name, title, email, order
    """
    try:
        ws = WORKSPACES.get(key)
        if not ws:
            return {"success": False, "error": "Workspace not found"}
        
        ws["status"] = "Pending Approval"
        ws["submitted_at"] = datetime.utcnow().isoformat()
        
        ws["approvals"] = []
        for approver in approvers:
            ws["approvals"].append({
                "reviewer_name": approver["name"],
                "reviewer_title": approver["title"],
                "reviewer_email": approver["email"],
                "role": approver["role"],
                "status": "Pending",
                "approved_at": None,
                "approved_by": None,
                "order": approver.get("order", 1)
            })
        
        return {"success": True, "message": "Submitted for approval"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def approve_dta(key):
    """Approve current stage of DTA"""
    try:
        ws = WORKSPACES.get(key)
        if not ws:
            return {"success": False, "error": "Workspace not found"}
        
        # Find first pending approval and mark as approved
        approved_reviewer = None
        all_approved = True
        
        for approval in ws.get("approvals", []):
            if approval["status"] == "Pending" and not approved_reviewer:
                approval["status"] = "Approved"
                approval["approved_at"] = datetime.utcnow().isoformat()
                approval["approved_by"] = approval.get("reviewer_name", "Reviewer")
                approved_reviewer = approval.get("reviewer_name", "Reviewer")
            if approval["status"] == "Pending":
                all_approved = False
        
        # If all approved, mark DTA as approved
        if all_approved:
            ws["status"] = "Approved"
            ws["approved_at"] = datetime.utcnow().isoformat()
        
        return {"success": True, "message": f"Approved by {approved_reviewer}"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def reject_dta(key, reason):
    """Reject DTA and send back to draft"""
    try:
        ws = WORKSPACES.get(key)
        if not ws:
            return {"success": False, "error": "Workspace not found"}
        
        ws["status"] = "Draft"
        ws["rejected_at"] = datetime.utcnow().isoformat()
        ws["rejection_reason"] = reason
        
        return {"success": True, "message": "DTA rejected and sent back to draft"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def get_approvers():
    """Get list of available approvers"""
    return {
        "success": True,
        "data": {
            "jnj_dae": [
                {"id": "jnj_1", "name": "Sarah Johnson", "title": "DAE Lead", "email": "sarah.johnson@jnj.com"},
                {"id": "jnj_2", "name": "Michael Chen", "title": "Senior DAE", "email": "michael.chen@jnj.com"},
                {"id": "jnj_3", "name": "Emily Rodriguez", "title": "DAE Manager", "email": "emily.rodriguez@jnj.com"}
            ],
            "vendor": [
                {"id": "vnd_1", "name": "Alex Kumar", "title": "Data Manager", "email": "alex.kumar@vendor.com"},
                {"id": "vnd_2", "name": "David Park", "title": "Senior Data Scientist", "email": "david.park@vendor.com"},
                {"id": "vnd_3", "name": "Jennifer Lee", "title": "QC Lead", "email": "jennifer.lee@vendor.com"}
            ],
            "librarian": [
                {"id": "lib_1", "name": "Lisa Wong", "title": "Study Librarian", "email": "lisa.wong@jnj.com"},
                {"id": "lib_2", "name": "Robert Martinez", "title": "Senior Librarian", "email": "robert.martinez@jnj.com"},
                {"id": "lib_3", "name": "Patricia Taylor", "title": "Data Librarian", "email": "patricia.taylor@jnj.com"}
            ]
        }
    }


# ============================================================================
# Jobs APIs
# ============================================================================

def get_jobs(status_filter=None, use_real_data=True, warehouse_id=None):
    """
    Get ingestion jobs and their runs.
    Smart approach: Query md_file_history table for active job IDs, then fetch details.
    
    Args:
        status_filter: Optional filter by run status ('success', 'running', 'failed')
        use_real_data: If True, fetch from Databricks API. (Mock data removed)
        warehouse_id: SQL Warehouse ID for querying tables
    
    Returns:
        dict with success, data (jobs, runs, kpis) OR error
    """
    try:
        print("DEBUG: Initializing Databricks client...")
        client = DatabricksJobsClient(warehouse_id=warehouse_id)
        
        # Step 1: Get active job IDs from md_file_history table
        # This gives us only jobs that have actually processed data
        # Catalog is read from CATALOG_NAME environment variable
        print(f"DEBUG: Step 1 - Getting active job IDs from md_file_history table...")
        active_jobs_from_table = client.get_active_job_ids_from_table(
            schema="bronze_md", 
            table="md_file_history"
        )
        
        if not active_jobs_from_table:
            print(f"WARNING: No job IDs found in md_file_history table")
            return {
                "success": True,
                "data": {
                    "jobs": [],
                    "runs": [],
                    "kpis": {
                        "runs7d": 0,
                        "successRate": "0%",
                        "avgDuration": "N/A",
                        "entitiesProduced": []
                    }
                },
                "message": "No jobs found in md_file_history table"
            }
        
        print(f"DEBUG: Found {len(active_jobs_from_table)} unique job IDs from table")
        
        # Step 2: Get job details for these specific IDs
        # Uses: https://docs.databricks.com/api/workspace/jobs/get
        print(f"DEBUG: Step 2 - Getting job details for {len(active_jobs_from_table)} jobs...")
        jobs = []
        job_ids_to_fetch_runs = []
        errors = []
        
        for active_job_info in active_jobs_from_table:
            job_id = active_job_info['job_id']
            job_name_from_table = active_job_info['job_name']
            try:
                job_detail = client.get_job_details(job_id)
                if job_detail:
                    # Use job_name from API if available, otherwise from table
                    job_detail['job_name'] = job_detail.get('job_name', job_name_from_table)
                    jobs.append(job_detail)
                    job_ids_to_fetch_runs.append(job_id)
                else:
                    error_msg = f"Could not get details for job ID {job_id}"
                    print(f"WARNING: {error_msg}")
                    errors.append(error_msg)
            except Exception as e:
                error_msg = f"Failed to get details for job ID {job_id}: {str(e)}"
                print(f"ERROR: {error_msg}")
                errors.append(error_msg)
        
        # If we couldn't get ANY job details, return empty data (graceful handling)
        if not jobs:
            print(f"WARNING: Could not retrieve any job details. Errors: {'; '.join(errors)}")
            return {
                "success": True,
                "data": {
                    "jobs": [],
                    "runs": [],
                    "kpis": {
                        "runs7d": 0,
                        "successRate": "0%",
                        "avgDuration": "N/A",
                        "entitiesProduced": []
                    }
                },
                "message": "No job details available. Jobs may have been deleted or are not accessible.",
                "warnings": errors
            }
        
        print(f"DEBUG: Retrieved details for {len(jobs)} jobs")
        
        # Step 3: Get runs for these jobs from last 7 days
        # Uses: https://docs.databricks.com/api/workspace/jobs/listruns
        print(f"DEBUG: Step 3 - Getting runs for {len(job_ids_to_fetch_runs)} jobs...")
        runs = client.get_runs_for_jobs(
            job_ids=job_ids_to_fetch_runs,
            days=7,
            limit=100
        )
        
        print(f"DEBUG: Got {len(runs)} total runs")
        
        # Step 4: Enrich jobs with run statistics
        # Group runs by job_id
        runs_by_job = {}
        for run in runs:
            job_id = str(run.get('job_id'))  # Ensure string comparison
            if job_id not in runs_by_job:
                runs_by_job[job_id] = []
            runs_by_job[job_id].append(run)
        
        print(f"DEBUG: Grouped runs into {len(runs_by_job)} job buckets")
        for job_id, job_runs in runs_by_job.items():
            print(f"DEBUG: Job {job_id} has {len(job_runs)} runs")
        
        # Enrich each job with its run statistics
        for job in jobs:
            job_id = str(job['job_id'])  # Ensure string comparison
            job_runs = runs_by_job.get(job_id, [])
            
            print(f"DEBUG: Enriching job {job_id} ({job['job_name']}) with {len(job_runs)} runs")
            
            # Calculate statistics
            total_runs = len(job_runs)
            success_count = len([r for r in job_runs if r['status'].lower() == 'success'])
            success_rate = f"{int(success_count/total_runs*100)}%" if total_runs > 0 else "0%"
            
            # Get latest run (runs should already be sorted by time, most recent first)
            latest_run = job_runs[0] if job_runs else None
            
            # Update job with statistics
            job['total_runs'] = total_runs
            job['success_rate'] = success_rate
            job['latest_run'] = latest_run
            job['all_runs'] = job_runs  # Store all runs for this job
            
            print(f"DEBUG: Job {job['job_name']}: {total_runs} runs, success_rate={success_rate}, all_runs count={len(job['all_runs'])}")
        
        # Step 5: Apply status filter to jobs if specified
        # Filter jobs based on their latest run status
        print(f"DEBUG: Before status filter: {len(jobs)} jobs")
        for job in jobs:
            print(f"DEBUG: Job {job['job_name']}: latest_run status = {job.get('latest_run', {}).get('status', 'None')}")
        
        if status_filter:
            print(f"DEBUG: Applying status filter: '{status_filter}'")
            jobs = [j for j in jobs if j.get('latest_run') and j['latest_run']['status'].lower() == status_filter.lower()]
            print(f"DEBUG: After status filter '{status_filter}': {len(jobs)} jobs")
        
        # Step 6: Calculate overall KPIs
        kpis = client.calculate_kpis(runs)
        
        result = {
            "success": True,
            "data": {
                "jobs": jobs,  # Jobs enriched with run statistics
                "runs": runs,  # All runs (for backward compatibility)
                "kpis": kpis
            }
        }
        
        # Add warnings if some jobs failed
        if errors:
            result["warnings"] = errors
        
        return result
        
    except Exception as e:
        print(f"ERROR: Error fetching job data: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            "success": False, 
            "error": f"Failed to fetch job data: {str(e)}",
            "traceback": traceback.format_exc()
        }


def get_run_documents(databricks_run_id, warehouse_id=None):
    """
    Get documents from md_dta_trial_dta_history for a specific databricks_run_id.
    
    Args:
        databricks_run_id: Run ID to filter documents
        warehouse_id: SQL Warehouse ID for querying
    
    Returns:
        dict with success, data (list of documents)
    """
    try:
        from .databricks_client import DatabricksSQLClient
        
        if not warehouse_id:
            warehouse_id = os.environ.get('DATABRICKS_WAREHOUSE_ID')
        
        if not warehouse_id:
            return {"success": False, "error": "No warehouse_id provided"}
        
        print(f"DEBUG: Fetching documents for run_id: {databricks_run_id}")
        
        # Get catalog from environment - never hardcode
        catalog = os.environ.get('CATALOG_NAME')
        if not catalog:
            return {"success": False, "error": "CATALOG_NAME environment variable is required"}
        
        bronze_schema = os.environ.get('BRONZE_SCHEMA', 'bronze_md')
        
        # Initialize SQL client
        sql_client = DatabricksSQLClient(warehouse_id=warehouse_id)
        
        # Query md_dta_trial_dta_history - CORRECTED COLUMNS
        query = f"""
            SELECT 
                document_id,
                extracted_path,
                file_extension,
                document_tags,
                active,
                status,
                size_bytes
            FROM {catalog}.{bronze_schema}.md_dta_trial_dta_history
            WHERE databricks_run_id = '{databricks_run_id}'
            ORDER BY last_updated_ts
        """
        
        print(f"DEBUG: Executing query:\n{query}")
        
        result = sql_client.execute_query(query)
        
        print(f"DEBUG: Query returned {len(result)} rows")
        
        # Format documents
        documents = []
        for row in result:
            # Extract just the filename from extracted_path
            extracted_path = row.get('extracted_path', '')
            filename = extracted_path.split('/')[-1] if extracted_path else 'N/A'
            
            documents.append({
                'document_id': row.get('document_id'),
                'filename': filename,
                'path': row.get('extracted_path', 'N/A'),
                'file_extension': row.get('file_extension', 'N/A'),
                'document_tags': row.get('document_tags', []),
                'active': row.get('active', False),
                'status': row.get('status', 'N/A'),
                'size_bytes': row.get('size_bytes', 0)
            })
        
        print(f"DEBUG: Found {len(documents)} documents for run {databricks_run_id}")
        
        return {
            "success": True,
            "data": documents
        }
        
    except Exception as e:
        print(f"ERROR: Failed to fetch documents: {str(e)}")
        import traceback
        traceback.print_exc()
        return {"success": False, "error": str(e)}


def get_run_details(databricks_run_id, warehouse_id=None):
    """
    Get run details with entity counts from Bronze, Silver, and Gold layers.
    
    Uses DOCUMENT LINEAGE to trace records across layers:
    1. Bronze: Get all document_ids for this run
    2. Silver: Count records where parent_document_id matches Bronze documents
    3. Gold: Count records where parent_document_id matches Bronze documents
    
    Args:
        databricks_run_id: Run ID to filter entities
        warehouse_id: SQL Warehouse ID for querying
    
    Returns:
        dict with success, data containing counts by layer:
        - bronze: Document counts by type
        - silver: Draft entity counts (linked via parent_document_id)
        - gold: Approved entity counts (linked via parent_document_id)
    """
    try:
        from .databricks_client import DatabricksSQLClient
        
        if not warehouse_id:
            warehouse_id = os.environ.get('DATABRICKS_WAREHOUSE_ID')
        
        if not warehouse_id:
            return {"success": False, "error": "No warehouse_id provided"}
        
        print(f"DEBUG: Fetching run details for run_id: {databricks_run_id}")
        
        # Get catalog from environment
        catalog = os.environ.get('CATALOG_NAME')
        if not catalog:
            return {"success": False, "error": "CATALOG_NAME environment variable is required"}
        
        bronze_schema = os.environ.get('BRONZE_SCHEMA', 'bronze_md')
        silver_schema = os.environ.get('SILVER_SCHEMA', 'silver_md')
        gold_schema = os.environ.get('GOLD_SCHEMA', 'gold_md')
        
        # Initialize SQL client
        sql_client = DatabricksSQLClient(warehouse_id=warehouse_id)
        
        # ========================================
        # Step 1: Get ROOT document_ids from Bronze for this run
        # ========================================
        bronze_docs_query = f"""
            SELECT document_id
            FROM {catalog}.{bronze_schema}.md_file_history
            WHERE databricks_run_id = '{databricks_run_id}'
        """
        bronze_docs_result = sql_client.execute_query(bronze_docs_query)
        root_doc_ids = [row.get('document_id') for row in bronze_docs_result or [] if row.get('document_id')]
        
        print(f"DEBUG: Found {len(root_doc_ids)} root documents in Bronze for run {databricks_run_id}")
        
        # ========================================
        # Step 2: Get CHILD document_ids whose parent is one of the root docs
        # ========================================
        all_doc_ids = list(root_doc_ids)
        if root_doc_ids:
            root_ids_str = "', '".join(root_doc_ids)
            children_query = f"""
                SELECT document_id
                FROM {catalog}.{bronze_schema}.md_file_history
                WHERE parent_document_id IN ('{root_ids_str}')
            """
            children_result = sql_client.execute_query(children_query)
            child_doc_ids = [row.get('document_id') for row in children_result or [] if row.get('document_id')]
            all_doc_ids.extend(child_doc_ids)
            print(f"DEBUG: Found {len(child_doc_ids)} child documents, total: {len(all_doc_ids)}")
        
        # ========================================
        # Bronze Layer: Documents by type (direct run_id match)
        # ========================================
        bronze_query = f"""
            SELECT 
                COALESCE(document_tags[0], file_extension, 'Unknown') as doc_type,
                COUNT(*) as count
            FROM {catalog}.{bronze_schema}.md_file_history
            WHERE databricks_run_id = '{databricks_run_id}'
            GROUP BY COALESCE(document_tags[0], file_extension, 'Unknown')
            ORDER BY count DESC
        """
        
        print(f"DEBUG: Bronze query:\n{bronze_query}")
        bronze_result = sql_client.execute_query(bronze_query)
        
        bronze_counts = {}
        bronze_total = 0
        for row in bronze_result or []:
            doc_type = row.get('doc_type', 'Unknown')
            count = int(row.get('count', 0))
            bronze_counts[doc_type] = count
            bronze_total += count
        
        # Initialize silver/gold counts
        silver_tv_count = 0
        silver_tc_count = 0
        silver_cl_count = 0
        gold_dta_count = 0
        gold_tv_count = 0
        gold_tc_count = 0
        
        # Only query Silver/Gold if we have Bronze documents to link
        if all_doc_ids:
            # Create IN clause for parent_document_id matching (includes root + child docs)
            doc_ids_str = "', '".join(all_doc_ids)
            parent_doc_filter = f"parent_document_id IN ('{doc_ids_str}')"
            
            # ========================================
            # Silver Layer: Draft entities (linked via parent_document_id)
            # ========================================
            # Transfer Variables Draft
            silver_tv_query = f"""
                SELECT COUNT(*) as count
                FROM {catalog}.{silver_schema}.md_dta_transfer_variables_draft
                WHERE {parent_doc_filter}
            """
            try:
                silver_tv_result = sql_client.execute_query(silver_tv_query)
                silver_tv_count = int(silver_tv_result[0].get('count', 0)) if silver_tv_result else 0
            except Exception as e:
                print(f"DEBUG: Silver TV query failed: {e}")
                silver_tv_count = 0
            
            # Test Concepts Draft
            silver_tc_query = f"""
                SELECT COUNT(*) as count
                FROM {catalog}.{silver_schema}.md_dta_vendor_test_concepts_draft
                WHERE {parent_doc_filter}
            """
            try:
                silver_tc_result = sql_client.execute_query(silver_tc_query)
                silver_tc_count = int(silver_tc_result[0].get('count', 0)) if silver_tc_result else 0
            except Exception as e:
                print(f"DEBUG: Silver TC query failed: {e}")
                silver_tc_count = 0
            
            # Codelists (normalized)
            silver_cl_query = f"""
                SELECT COUNT(*) as count
                FROM {catalog}.{silver_schema}.md_codelists_normalized
                WHERE {parent_doc_filter}
            """
            try:
                silver_cl_result = sql_client.execute_query(silver_cl_query)
                silver_cl_count = int(silver_cl_result[0].get('count', 0)) if silver_cl_result else 0
            except Exception as e:
                print(f"DEBUG: Silver CL query failed: {e}")
                silver_cl_count = 0
            
            # ========================================
            # Gold Layer: Approved entities (linked via parent_document_id)
            # ========================================
            # DTA
            gold_dta_query = f"""
                SELECT COUNT(*) as count
                FROM {catalog}.{gold_schema}.dta
                WHERE {parent_doc_filter}
            """
            try:
                gold_dta_result = sql_client.execute_query(gold_dta_query)
                gold_dta_count = int(gold_dta_result[0].get('count', 0)) if gold_dta_result else 0
            except Exception as e:
                print(f"DEBUG: Gold DTA query failed: {e}")
                gold_dta_count = 0
            
            # Transfer Variables (approved)
            gold_tv_query = f"""
                SELECT COUNT(*) as count
                FROM {catalog}.{gold_schema}.md_dta_transfer_variables
                WHERE {parent_doc_filter}
            """
            try:
                gold_tv_result = sql_client.execute_query(gold_tv_query)
                gold_tv_count = int(gold_tv_result[0].get('count', 0)) if gold_tv_result else 0
            except Exception as e:
                print(f"DEBUG: Gold TV query failed: {e}")
                gold_tv_count = 0
            
            # Test Concepts (approved)
            gold_tc_query = f"""
                SELECT COUNT(*) as count
                FROM {catalog}.{gold_schema}.md_dta_vendor_test_concepts
                WHERE {parent_doc_filter}
            """
            try:
                gold_tc_result = sql_client.execute_query(gold_tc_query)
                gold_tc_count = int(gold_tc_result[0].get('count', 0)) if gold_tc_result else 0
            except Exception as e:
                print(f"DEBUG: Gold TC query failed: {e}")
                gold_tc_count = 0
        
        print(f"DEBUG: Linked counts - Silver TV: {silver_tv_count}, Silver TC: {silver_tc_count}, Gold DTA: {gold_dta_count}, Gold TV: {gold_tv_count}, Gold TC: {gold_tc_count}")
        
        # Build response
        run_details = {
            "run_id": databricks_run_id,
            "bronze": {
                "title": "Documents Processed",
                "total": bronze_total,
                "by_type": bronze_counts
            },
            "silver": {
                "title": "Draft Entities",
                "total": silver_tv_count + silver_tc_count + silver_cl_count,
                "transfer_variables": silver_tv_count,
                "test_concepts": silver_tc_count,
                "codelists": silver_cl_count
            },
            "gold": {
                "title": "Approved Entities",
                "total": gold_dta_count + gold_tv_count + gold_tc_count,
                "dta": gold_dta_count,
                "transfer_variables": gold_tv_count,
                "test_concepts": gold_tc_count
            }
        }
        
        print(f"DEBUG: Run details for {databricks_run_id}: Bronze={bronze_total}, Silver={silver_tv_count + silver_tc_count}, Gold={gold_dta_count + gold_tv_count + gold_tc_count}")
        
        return {
            "success": True,
            "data": run_details
        }
        
    except Exception as e:
        print(f"ERROR: Failed to fetch run details: {str(e)}")
        import traceback
        traceback.print_exc()
        return {"success": False, "error": str(e)}


def create_export_job(key):
    """Create export job for approved DTA"""
    try:
        ws = WORKSPACES.get(key)
        if not ws:
            return {"success": False, "error": "Workspace not found"}
        
        if ws.get("status") != "Approved":
            return {"success": False, "error": "Only approved DTAs can be exported"}
        
        # Generate job IDs
        databricks_job_id = f"job_{random.randint(100000, 999999)}"
        databricks_run_id = f"run_{random.randint(100000000, 999999999)}"
        
        # Create job entry
        now = datetime.utcnow()
        new_job = {
            "databricks_job_id": databricks_job_id,
            "databricks_run_id": databricks_run_id,
            "document_type": "DTA Export",
            "file_name": f"{key.replace('|', '_')}_DTA_Export.xlsx",
            "file_type": "Excel",
            "size": "2.3 MB",
            "start_time": now.strftime("%Y-%m-%d %H:%M:%S"),
            "end_time": None,
            "duration": "Running...",
            "status": "Running",
            "entities": {
                "metadata": len(ws.get("metadata", [])),
                "visits_timepoints": len(ws.get("entities", {}).get("VT", [])),
                "transfer_variables": len(ws.get("entities", {}).get("TV", [])),
                "test_concepts": len(ws.get("entities", {}).get("TC", [])),
                "code_lists": len(ws.get("entities", {}).get("CL", [])),
                "data_ingestion_parameters": len(ws.get("dip", []))
            },
            "dta_key": key,
            "output_path": f"/Volumes/catalog/schema/exports/{key.replace('|', '_')}_DTA_Export.xlsx"
        }
        
        MOCK_RUNS.insert(0, new_job)
        
        return {
            "success": True,
            "data": {
                "job_id": databricks_job_id,
                "run_id": databricks_run_id
            },
            "message": "Export job triggered successfully"
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def publish_major_version(key):
    """Publish approved DTA as new major version"""
    try:
        ws = WORKSPACES.get(key)
        if not ws:
            return {"success": False, "error": "Workspace not found"}
        
        if ws.get("status") != "Approved":
            return {"success": False, "error": "Only approved DTAs can be published"}
        
        # Increment major version
        current_major = ws.get("base_major", 1)
        new_major = current_major + 1
        
        ws["base_major"] = new_major
        ws["status"] = "Published"
        ws["published_at"] = datetime.utcnow().isoformat()
        ws["published_by"] = "Current User"
        ws["is_published"] = True
        
        return {
            "success": True,
            "data": {
                "new_major_version": new_major,
                "published_at": ws["published_at"]
            },
            "message": f"DTA published as Major v{new_major}"
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


# ============================================================================
# Entity CRUD APIs (TC, TV, CL, Metadata, DIP)
# ============================================================================

def add_tc_row(key):
    """Add new test concept row"""
    try:
        ws = WORKSPACES.get(key)
        if not ws:
            return {"success": False, "error": "Workspace not found"}
        
        new_row = {
            "test_name": "",
            "test_short_name": "",
            "specimen_type": "",
            "method": "",
            "reference_range": "",
            "units": "",
            "notes": ""
        }
        ws["entities"]["TC"].append(new_row)
        ws["tc_state"].append({"editable": True, "approved": False, "comments": []})
        
        return {"success": True, "message": "Row added"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def add_tv_row(key, domain_info=""):
    """Add new transfer variable"""
    import uuid
    
    try:
        ws = WORKSPACES.get(key)
        if not ws:
            return {"success": False, "error": "Workspace not found"}
        
        data._ensure_tv_init(ws)
        
        # Generate a temporary UUID for the new row
        temp_id = f"new_{str(uuid.uuid4())}"
        
        new_var = {
            "_transfer_variable_id": temp_id,  # Temporary ID for new row
            "_is_new": True,  # Flag to indicate this is a new row
            "variable": "",
            "label": "",
            "datatype": "",
            "length": "50",
            "format": "STRING",
            "controlled_terms": "",
            "notes": "",
            "DOMAIN_INFO": domain_info,  # Pre-populated from dropdown selection
            "VENDOR_COMMENT": "",
            "ROW_STATUS": "DRAFT",
            "IS_KEY": False,
            "DESCRIPTION": ""
        }
        ws["entities"]["TV"].append(new_var)
        ws["tv_state"].append({"editable": True, "approved": False, "comments": [], "is_new": True})
        ws["has_pending_changes"] = True
        
        return {"success": True, "message": "Variable added"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def update_entity_state(key, entity_type, index, action, payload=None):
    """
    Generic function to update entity state
    Args:
        key: Workspace key
        entity_type: 'tc', 'tv', 'meta', 'dip'
        index: Row index
        action: 'edit', 'save', 'cancel', 'approve', 'comment'
        payload: Optional data for save/comment actions
    """
    try:
        ws = WORKSPACES.get(key)
        if not ws:
            return {"success": False, "error": "Workspace not found"}
        
        state_key = f"{entity_type}_state"
        if state_key not in ws:
            return {"success": False, "error": f"Invalid entity type: {entity_type}"}
        
        if index < 0 or index >= len(ws[state_key]):
            return {"success": False, "error": "Invalid index"}
        
        if action == "edit":
            ws[state_key][index]["editable"] = True
        elif action == "save":
            ws[state_key][index]["editable"] = False
            # Update data if provided
            if payload and entity_type in ['meta', 'dip']:
                ws[entity_type][index]["value"] = payload.get("value", "")
        elif action == "cancel":
            ws[state_key][index]["editable"] = False
        elif action == "approve":
            ws[state_key][index]["approved"] = True
            ws[state_key][index]["editable"] = False
        elif action == "comment":
            if payload and "text" in payload:
                comment = {
                    "user": "Current User",
                    "ts": datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
                    "text": payload["text"]
                }
                ws[state_key][index]["comments"].append(comment)
        
        return {"success": True, "message": f"{action.capitalize()} completed"}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ============================================================================
# Transfer File Keys APIs
# ============================================================================

def add_transfer_key(key, variable):
    """Add variable to transfer file keys"""
    try:
        ws = WORKSPACES.get(key)
        if not ws:
            return {"success": False, "error": "Workspace not found"}
        
        if "transfer_file_keys" not in ws:
            ws["transfer_file_keys"] = []
        
        if variable not in ws["transfer_file_keys"]:
            ws["transfer_file_keys"].append(variable)
            return {"success": True, "message": "Key added"}
        else:
            return {"success": False, "error": "Key already exists"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def remove_transfer_key(key, variable):
    """Remove variable from transfer file keys"""
    try:
        ws = WORKSPACES.get(key)
        if not ws:
            return {"success": False, "error": "Workspace not found"}
        
        if "transfer_file_keys" in ws and variable in ws["transfer_file_keys"]:
            ws["transfer_file_keys"].remove(variable)
            return {"success": True, "message": "Key removed"}
        else:
            return {"success": False, "error": "Key not found"}
    except Exception as e:
        return {"success": False, "error": str(e)}


{{- if or (eq .project_type "full") (eq .project_type "data_only") (eq .include_dlt_pipelines "Y")}}
"""
Tests for framework utilities
"""

import pytest
from {{.usecase}}_framework.utils import (
    get_catalog_config,
    add_audit_columns,
    validate_schema
)


def test_get_catalog_config(spark):
    """Test catalog configuration retrieval"""
    config = get_catalog_config(spark)
    
    assert "catalog" in config
    assert "bronze_schema" in config
    assert "silver_schema" in config
    assert "gold_schema" in config


def test_add_audit_columns(spark, sample_data):
    """Test adding audit columns"""
    result = add_audit_columns(sample_data)
    
    assert "_processing_timestamp" in result.columns
    assert "_processing_date" in result.columns
    assert result.count() == sample_data.count()


def test_validate_schema_success(sample_data):
    """Test schema validation with valid columns"""
    required_columns = ["id", "name", "date"]
    
    assert validate_schema(sample_data, required_columns) is True


def test_validate_schema_failure(sample_data):
    """Test schema validation with missing columns"""
    required_columns = ["id", "name", "missing_column"]
    
    with pytest.raises(ValueError, match="Missing required columns"):
        validate_schema(sample_data, required_columns)
{{- end}}


"""
TOC (Table of Contents) Extraction Utilities

This module provides a clean abstraction for extracting Table of Contents
and sections from documents. Currently supports PDF, designed for extension
to Word documents.

Usage:
    from clinical_data_standards_framework.toc_utils import PDFTOCExtractor, Section
    
    extractor = PDFTOCExtractor()
    sections = extractor.extract_sections("/path/to/document.pdf")
    
    for section in sections:
        print(f"{section.title} (Level {section.level}): pages {section.page_start}-{section.page_end}")
"""

import re
import unicodedata
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

# PDF processing libraries
import fitz  # PyMuPDF
from pdfminer.high_level import extract_pages
from pdfminer.layout import LTTextContainer
from PyPDF2 import PdfReader, PdfWriter


@dataclass
class Section:
    """
    Represents a document section extracted from TOC.
    
    Attributes:
        title: Section title/heading text
        level: Hierarchy level (1 = top-level, 2 = subsection, etc.)
        page_start: Starting page number (0-based)
        page_end: Ending page number (0-based, inclusive)
    """
    title: str
    level: int
    page_start: int
    page_end: int
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization."""
        return {
            "title": self.title,
            "level": self.level,
            "page_start": self.page_start,
            "page_end": self.page_end
        }


class BaseTOCExtractor(ABC):
    """
    Abstract base class for TOC extraction.
    
    Provides a common interface for extracting sections from different
    document types (PDF, Word, etc.).
    """
    
    @abstractmethod
    def extract_sections(self, file_path: str) -> List[Section]:
        """
        Extract all sections from the document's Table of Contents.
        
        Args:
            file_path: Path to the document file
            
        Returns:
            List of Section objects representing document structure
        """
        pass
    
    @abstractmethod
    def get_section_content(self, file_path: str, section: Section) -> bytes:
        """
        Extract the content of a specific section as bytes.
        
        Args:
            file_path: Path to the source document
            section: Section object defining the content range
            
        Returns:
            Bytes containing the section content (format depends on document type)
        """
        pass
    
    @abstractmethod
    def supports_file(self, file_path: str) -> bool:
        """
        Check if this extractor supports the given file type.
        
        Args:
            file_path: Path to the document file
            
        Returns:
            True if this extractor can handle the file
        """
        pass


class PDFTOCExtractor(BaseTOCExtractor):
    """
    PDF-specific TOC extractor using PyMuPDF.
    
    Extracts sections from PDF documents using two methods:
    1. PDF bookmarks/outlines (primary, most reliable)
    2. Textual TOC parsing (fallback for PDFs without bookmarks)
    
    Example:
        extractor = PDFTOCExtractor()
        sections = extractor.extract_sections("/path/to/protocol.pdf")
        
        # Get content for a specific section as PDF bytes
        pdf_bytes = extractor.get_section_content("/path/to/protocol.pdf", sections[0])
    """
    
    SUPPORTED_EXTENSIONS = {'.pdf'}
    
    def supports_file(self, file_path: str) -> bool:
        """Check if file is a PDF."""
        return file_path.lower().endswith('.pdf')
    
    def extract_sections(self, file_path: str) -> List[Section]:
        """
        Extract all sections from PDF TOC with their page ranges.
        
        Uses PDF bookmarks if available, falls back to textual TOC parsing.
        
        Args:
            file_path: Path to the PDF file
            
        Returns:
            List of Section objects with title, level, and page ranges
        """
        sections = []
        
        with fitz.open(file_path) as doc:
            toc = doc.get_toc(simple=True)
            total_pages = doc.page_count
            
            if not toc:
                # No TOC bookmarks - try fallback textual TOC parsing
                print("  ⚠️ No PDF bookmarks found, trying textual TOC parsing...")
                mapping = self._parse_textual_toc(file_path)
                if mapping:
                    items_by_page = sorted([(v, k) for k, v in mapping.items()])
                    for i, (page0, title) in enumerate(items_by_page):
                        if i + 1 < len(items_by_page):
                            end = items_by_page[i + 1][0] - 1
                        else:
                            end = total_pages - 1
                        sections.append(Section(
                            title=title,
                            level=1,
                            page_start=page0,
                            page_end=end
                        ))
                return sections
            
            # Build outline tree from bookmarks
            flat = self._build_outline_tree(toc)
            
            for i, node in enumerate(flat):
                start, end = self._range_from_outline(flat, i)
                if end is None:
                    end = total_pages - 1
                
                sections.append(Section(
                    title=node["title"],
                    level=node["level"],
                    page_start=start,
                    page_end=end
                ))
        
        return sections
    
    def get_section_content(self, file_path: str, section: Section) -> bytes:
        """
        Extract section pages as a PDF byte stream.
        
        Args:
            file_path: Path to the source PDF
            section: Section object with page range
            
        Returns:
            Bytes containing a new PDF with only the section pages
        """
        import io
        
        with open(file_path, 'rb') as infile:
            reader = PdfReader(infile)
            writer = PdfWriter()
            
            total_pages = len(reader.pages)
            actual_end = min(section.page_end, total_pages - 1)
            
            for page_num in range(section.page_start, actual_end + 1):
                writer.add_page(reader.pages[page_num])
            
            output = io.BytesIO()
            writer.write(output)
            return output.getvalue()
    
    def extract_section_to_file(
        self, 
        source_path: str, 
        dest_path: str, 
        section: Section
    ) -> Optional[str]:
        """
        Extract section pages and save to a new PDF file.
        
        Args:
            source_path: Path to the source PDF
            dest_path: Path for the output PDF
            section: Section object with page range
            
        Returns:
            Path to the created file, or None if failed
        """
        import os
        
        try:
            with open(source_path, 'rb') as infile:
                reader = PdfReader(infile)
                writer = PdfWriter()
                
                total_pages = len(reader.pages)
                actual_end = min(section.page_end, total_pages - 1)
                
                for page_num in range(section.page_start, actual_end + 1):
                    writer.add_page(reader.pages[page_num])
                
                # Ensure directory exists
                os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                
                with open(dest_path, 'wb') as outfile:
                    writer.write(outfile)
                
                return dest_path
                
        except Exception as e:
            print(f"  ⚠️ Error extracting section to file: {e}")
            return None
    
    # =========================================================================
    # Private helper methods
    # =========================================================================
    
    @staticmethod
    def _normalize_text(s: str) -> str:
        """Normalize text for robust matching."""
        s = unicodedata.normalize("NFKC", s)
        s = re.sub(r"\s+", " ", s.strip())
        return s.lower()
    
    @staticmethod
    def _build_outline_tree(toc: List) -> List[Dict]:
        """
        Convert PyMuPDF TOC (list of [level, title, page]) to flat list with indices.
        
        Args:
            toc: PyMuPDF TOC list from doc.get_toc()
            
        Returns:
            List of dicts with {i, level, title, page0}
        """
        out = []
        for idx, (level, title, page1) in enumerate(toc):
            out.append({
                "i": idx,
                "level": level,
                "title": title,
                "page0": max(0, page1 - 1)  # PyMuPDF TOC pages are 1-based
            })
        return out
    
    @staticmethod
    def _range_from_outline(flat: List[Dict], i: int) -> Tuple[int, Optional[int]]:
        """
        Given index i in the flat outline, compute [start, end] page range.
        
        The end page is determined by finding the next section at the same
        or higher level (lower level number).
        
        Args:
            flat: Flattened outline list
            i: Index of current section
            
        Returns:
            Tuple of (start_page, end_page) where end_page may be None
        """
        cur = flat[i]
        start = cur["page0"]
        cur_level = cur["level"]
        end = start
        
        for j in range(i + 1, len(flat)):
            if flat[j]["level"] <= cur_level:
                end = max(start, flat[j]["page0"] - 1)
                break
        else:
            end = None  # extends to end of document
            
        return start, end
    
    def _parse_textual_toc(self, pdf_path: str) -> Dict[str, int]:
        """
        Fallback parser for printed 'Table of Contents' page.
        
        Looks for heading lines ending in page numbers, e.g.:
        "1.3 Schedule of Activities ........ 16"
        
        Args:
            pdf_path: Path to the PDF file
            
        Returns:
            Dict mapping section titles to page numbers (0-based)
        """
        line_re = re.compile(r"""
            ^\s*
            (?P<title>.+?)
            \s*(?:\.{2,}|[-–—]{2,}|\s{4,})\s*
            (?P<page>\d{1,6})\s*$
        """, re.VERBOSE)

        pages_text = []
        try:
            for i, page_layout in enumerate(extract_pages(pdf_path, maxpages=30)):
                text_lines = []
                for el in page_layout:
                    if isinstance(el, LTTextContainer):
                        text_lines.append(el.get_text())
                page_text = "\n".join(text_lines)
                pages_text.append((i, page_text))
        except Exception as e:
            print(f"  ⚠️ Error extracting pages for textual TOC: {e}")
            return {}

        # Find pages that look like TOC
        header_re = re.compile(r"\b(table of contents|contents|toc)\b", re.I)
        toc_page_indices = [i for i, txt in pages_text if header_re.search(txt)]
        candidates = toc_page_indices or [i for i, _ in pages_text[:10]]

        mapping: Dict[str, int] = {}
        for i in candidates:
            txt = pages_text[i][1]
            for raw_line in txt.splitlines():
                line = raw_line.strip()
                m = line_re.match(line)
                if not m:
                    continue
                title = self._normalize_text(m.group("title"))
                if not title or title in ("contents", "table of contents"):
                    continue
                page_num = int(m.group("page"))
                mapping[m.group("title")] = max(0, page_num - 1)

            if len(mapping) >= 5:
                break

        return mapping


# =============================================================================
# Factory function for getting appropriate extractor
# =============================================================================

def get_toc_extractor(file_path: str) -> Optional[BaseTOCExtractor]:
    """
    Get the appropriate TOC extractor for a file type.
    
    Args:
        file_path: Path to the document file
        
    Returns:
        Appropriate TOCExtractor instance, or None if unsupported
    """
    extractors = [
        PDFTOCExtractor(),
        # Future: WordTOCExtractor(),
    ]
    
    for extractor in extractors:
        if extractor.supports_file(file_path):
            return extractor
    
    return None


# =============================================================================
# Convenience functions
# =============================================================================

def extract_pdf_sections(pdf_path: str) -> List[Section]:
    """
    Convenience function to extract sections from a PDF.
    
    Args:
        pdf_path: Path to the PDF file
        
    Returns:
        List of Section objects
    """
    extractor = PDFTOCExtractor()
    return extractor.extract_sections(pdf_path)


def extract_pdf_section_to_file(
    source_path: str,
    dest_path: str,
    page_start: int,
    page_end: int
) -> Optional[str]:
    """
    Convenience function to extract pages from a PDF to a new file.
    
    Args:
        source_path: Path to the source PDF
        dest_path: Path for the output PDF
        page_start: Starting page (0-based)
        page_end: Ending page (0-based, inclusive)
        
    Returns:
        Path to the created file, or None if failed
    """
    section = Section(title="", level=1, page_start=page_start, page_end=page_end)
    extractor = PDFTOCExtractor()
    return extractor.extract_section_to_file(source_path, dest_path, section)


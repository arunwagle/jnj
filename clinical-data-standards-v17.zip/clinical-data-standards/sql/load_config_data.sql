-- ============================================================================
-- Config Data Load SQL - Populate md_config_cache
-- ============================================================================
-- Purpose: Load configuration snapshot into Delta table for fast job setup
-- Use Case: clinical_data_standards
-- 
-- Parameters:
--   :catalog_name - The catalog to use
--
-- Note: For automatic sync from YAML, use nb_populate_config_cache.ipynb instead
-- ============================================================================

USE CATALOG IDENTIFIER(:catalog_name);
USE SCHEMA bronze_md;

-- Create or replace table to ensure schema is current
CREATE OR REPLACE TABLE md_config_cache (
  config_key STRING NOT NULL,
  config_section STRING NOT NULL,
  config_json STRING,
  config_version STRING,
  updated_ts TIMESTAMP,
  updated_by STRING
)
USING DELTA
COMMENT 'Cached configuration for fast job setup.'
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'false',
  'delta.autoOptimize.optimizeWrite' = 'true'
);

-- GLOBALS Section
MERGE INTO md_config_cache AS target
USING (
  SELECT 
    'clinical_data_standards' AS config_key,
    'globals' AS config_section,
    CONCAT('{"spark_app_name": "clinical_data_standards", "catalog": "', :catalog_name, '", "bronze_schema": "bronze_md", "silver_schema": "silver_md", "gold_schema": "gold_md"}') AS config_json,
    '1.0.0' AS config_version,
    CURRENT_TIMESTAMP() AS updated_ts,
    'sql_load' AS updated_by
) AS source
ON target.config_key = source.config_key AND target.config_section = source.config_section
WHEN MATCHED THEN
  UPDATE SET config_json = source.config_json, config_version = source.config_version, updated_ts = source.updated_ts, updated_by = source.updated_by
WHEN NOT MATCHED THEN
  INSERT (config_key, config_section, config_json, config_version, updated_ts, updated_by)
  VALUES (source.config_key, source.config_section, source.config_json, source.config_version, source.updated_ts, source.updated_by);

-- SERVICES Section
MERGE INTO md_config_cache AS target
USING (
  SELECT 
    'clinical_data_standards' AS config_key,
    'services' AS config_section,
    '{"document_parser_default": {"type": "document_parsing", "engine": "ai_document_intelligence", "extract_text": true, "extract_tables": true, "extract_images": false, "output_format": "json", "timeout_seconds": 120, "description": "Databricks AI Document Intelligence"}, "entity_extractor_default": {"type": "model_serving", "max_tokens": 1000, "temperature": 0.1, "timeout_seconds": 90, "retry_attempts": 3, "description": "Foundation model for entity extraction"}}' AS config_json,
    '1.0.0' AS config_version,
    CURRENT_TIMESTAMP() AS updated_ts,
    'sql_load' AS updated_by
) AS source
ON target.config_key = source.config_key AND target.config_section = source.config_section
WHEN MATCHED THEN
  UPDATE SET config_json = source.config_json, config_version = source.config_version, updated_ts = source.updated_ts, updated_by = source.updated_by
WHEN NOT MATCHED THEN
  INSERT (config_key, config_section, config_json, config_version, updated_ts, updated_by)
  VALUES (source.config_key, source.config_section, source.config_json, source.config_version, source.updated_ts, source.updated_by);

-- PIPELINES Section
MERGE INTO md_config_cache AS target
USING (
  SELECT 
    'clinical_data_standards' AS config_key,
    'pipelines' AS config_section,
    '{"file_processor": {"description": "Generic file processor for archives and regular uploads", "owner": "data-team", "mode": "streaming", "source_volume": "clinical_data_standards", "target_volume": "clinical_data_standards", "sources": {"historical_data": {"description": "Historical clinical trial data", "root": "historical_data"}, "regular": {"description": "Ad-hoc document uploads", "root": "regular"}}, "default_source": "historical_data", "manifest_table": "md_file_history", "checkpoint_subdir": "jobs/_checkpoints/file_processor", "supported_extensions": [".pdf", ".doc", ".docx", ".xls", ".xlsx", ".txt", ".csv"]}, "tsdta_processor": {"description": "Process tsDTA Excel files from trial metadata", "owner": "data-team", "mode": "streaming"}, "dta_processor": {"description": "Create DTA instances and manage DTA versioning", "owner": "data-team", "mode": "batch"}}' AS config_json,
    '1.0.0' AS config_version,
    CURRENT_TIMESTAMP() AS updated_ts,
    'sql_load' AS updated_by
) AS source
ON target.config_key = source.config_key AND target.config_section = source.config_section
WHEN MATCHED THEN
  UPDATE SET config_json = source.config_json, config_version = source.config_version, updated_ts = source.updated_ts, updated_by = source.updated_by
WHEN NOT MATCHED THEN
  INSERT (config_key, config_section, config_json, config_version, updated_ts, updated_by)
  VALUES (source.config_key, source.config_section, source.config_json, source.config_version, source.updated_ts, source.updated_by);

-- STREAMING Section
MERGE INTO md_config_cache AS target
USING (
  SELECT 
    'clinical_data_standards' AS config_key,
    'streaming' AS config_section,
    '{"enabled": true, "change_data_feed": {"enabled": true, "cdf_tables": ["md_file_history"]}, "status_values": {"ready_for_processing": "READY_FOR_PROCESSING", "tsdta_in_process": "TSDTA_PROCESSING", "tsdta_completed": "TSDTA_COMPLETED", "tsdta_failed": "TSDTA_FAILED", "doc_in_process": "DOC_PROCESSING", "doc_completed": "DOC_COMPLETED", "doc_failed": "DOC_FAILED", "ready_for_versioning": "READY_FOR_VERSIONING", "versioning_in_process": "VERSIONING_IN_PROCESS", "versioned": "VERSIONED", "versioning_failed": "VERSIONING_FAILED"}, "completion_tracking": {"enabled": true, "required_tags_for_versioning": ["tsDTA"], "tracking_columns": ["total_documents_count", "required_documents_count", "processed_documents_count"]}, "trigger": {"mode": "availableNow", "max_files_per_trigger": 100}}' AS config_json,
    '1.0.0' AS config_version,
    CURRENT_TIMESTAMP() AS updated_ts,
    'sql_load' AS updated_by
) AS source
ON target.config_key = source.config_key AND target.config_section = source.config_section
WHEN MATCHED THEN
  UPDATE SET config_json = source.config_json, config_version = source.config_version, updated_ts = source.updated_ts, updated_by = source.updated_by
WHEN NOT MATCHED THEN
  INSERT (config_key, config_section, config_json, config_version, updated_ts, updated_by)
  VALUES (source.config_key, source.config_section, source.config_json, source.config_version, source.updated_ts, source.updated_by);

-- VERSIONING Section
MERGE INTO md_config_cache AS target
USING (
  SELECT 
    'clinical_data_standards' AS config_key,
    'versioning' AS config_section,
    '{"enabled": true, "registry_table": "md_version_registry", "registry_schema": "gold_md", "library_tables": [{"name": "md_dta_transfer_variables", "library_type": "transfer_variables", "schema": "gold_md", "silver_table": "md_dta_transfer_variables_draft", "silver_schema": "silver_md", "business_keys": ["definition_hash"], "description": "Master library of transfer variable definitions"}, {"name": "md_dta_vendor_test_concepts", "library_type": "test_concepts", "schema": "gold_md", "silver_table": "md_dta_vendor_test_concepts_draft", "silver_schema": "silver_md", "business_keys": ["definition_hash"], "description": "Master library of test concept definitions with transfer variable mappings"}]}' AS config_json,
    '1.0.0' AS config_version,
    CURRENT_TIMESTAMP() AS updated_ts,
    'sql_load' AS updated_by
) AS source
ON target.config_key = source.config_key AND target.config_section = source.config_section
WHEN MATCHED THEN
  UPDATE SET config_json = source.config_json, config_version = source.config_version, updated_ts = source.updated_ts, updated_by = source.updated_by
WHEN NOT MATCHED THEN
  INSERT (config_key, config_section, config_json, config_version, updated_ts, updated_by)
  VALUES (source.config_key, source.config_section, source.config_json, source.config_version, source.updated_ts, source.updated_by);

-- VALIDATION Section
MERGE INTO md_config_cache AS target
USING (
  SELECT 
    'clinical_data_standards' AS config_key,
    'validation' AS config_section,
    '{"codelists": {"header_patterns": ["codelist.*ref|reference", "values?"], "required_columns": ["codelist_reference", "code_value"], "optional_columns": ["sdtm_value"]}, "transfer_metadata": {"required_columns": ["transfer_variable_name", "transfer_variable_order", "format", "anticipated_max_length", "transfer_file_key", "populate_for_all_records"], "compute_definition_hash": true, "definition_hash_fields": ["transfer_variable_name", "transfer_variable_order", "format", "anticipated_max_length", "transfer_file_key", "populate_for_all_records", "codelist_values", "data_provider_name", "data_stream_type"]}}' AS config_json,
    '1.0.0' AS config_version,
    CURRENT_TIMESTAMP() AS updated_ts,
    'sql_load' AS updated_by
) AS source
ON target.config_key = source.config_key AND target.config_section = source.config_section
WHEN MATCHED THEN
  UPDATE SET config_json = source.config_json, config_version = source.config_version, updated_ts = source.updated_ts, updated_by = source.updated_by
WHEN NOT MATCHED THEN
  INSERT (config_key, config_section, config_json, config_version, updated_ts, updated_by)
  VALUES (source.config_key, source.config_section, source.config_json, source.config_version, source.updated_ts, source.updated_by);

-- EXPORT Section
MERGE INTO md_config_cache AS target
USING (
  SELECT 
    'clinical_data_standards' AS config_key,
    'export' AS config_section,
    '{
      "enabled": true,
      "export_folder": "exports",
      "date_format": "%Y-%m-%d",
      "timestamp_format": "%Y%m%d_%H%M%S",
      "document_types": [
        {
          "type": "tsDTA",
          "label": "Trial Specific DTA (Excel)",
          "description": "Complete tsDTA metadata export with summary, version history, and all metadata by domain",
          "format": "excel",
          "file_extension": ".xlsx",
          "is_enabled": true,
          "includes": ["dta_summary", "version_history", "transfer_variables", "test_concepts"],
          "sheets_by_domain": true,
          "max_sheet_name_length": 31
        },
        {
          "type": "oa",
          "label": "Operational Agreement (PDF)",
          "description": "Operational Agreement document export",
          "format": "pdf",
          "file_extension": ".pdf",
          "is_enabled": false,
          "includes": ["operational_agreement"]
        }
      ],
      "manifest": {
        "enabled": true,
        "filename": "export_manifest.json"
      }
    }' AS config_json,
    '1.0.0' AS config_version,
    CURRENT_TIMESTAMP() AS updated_ts,
    'sql_load' AS updated_by
) AS source
ON target.config_key = source.config_key AND target.config_section = source.config_section
WHEN MATCHED THEN
  UPDATE SET config_json = source.config_json, config_version = source.config_version, updated_ts = source.updated_ts, updated_by = source.updated_by
WHEN NOT MATCHED THEN
  INSERT (config_key, config_section, config_json, config_version, updated_ts, updated_by)
  VALUES (source.config_key, source.config_section, source.config_json, source.config_version, source.updated_ts, source.updated_by);

-- Verify Load
SELECT 
  '✅ Config Data Loaded' AS status,
  config_section,
  LENGTH(config_json) AS json_bytes,
  config_version,
  updated_ts
FROM md_config_cache
WHERE config_key = 'clinical_data_standards'
ORDER BY config_section;

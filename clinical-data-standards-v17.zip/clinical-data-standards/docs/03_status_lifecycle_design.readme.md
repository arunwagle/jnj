# Status Lifecycle Design

> **Status**: Implemented  
> **Last Updated**: January 2026

---

## Overview

This document describes the status values used throughout the Clinical Data Standards pipeline to track document processing and DTA lifecycle management.

### Purpose

Status tracking serves two key purposes:

1. **Document Processing** - Track the lifecycle of files from extraction through processing to DTA creation
2. **DTA Management** - Track the lifecycle of Data Transfer Agreements from draft through approval

### Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| Document Processing Lifecycle | Status flow for file processing | [PNG](./diagrams/03_document_processing_lifecycle.drawio.png) | [Draw.io](./diagrams/03_document_processing_lifecycle.drawio) |
| DTA Status Lifecycle | Status flow for DTA entities | [PNG](./diagrams/03_dta_status_lifecycle.drawio.png) | [Draw.io](./diagrams/03_dta_status_lifecycle.drawio) |

---

## Document Statuses

The `md_file_history` table in the Bronze layer tracks document processing status.

### Status Values

| Status | Description | Next Status |
|--------|-------------|-------------|
| `READY_FOR_PROCESSING` | File extracted, awaiting processing | TSDTA_PROCESSING, DOC_PROCESSING |
| `TSDTA_PROCESSING` | Excel sheets being extracted | EXCEL_EXTRACTION_COMPLETED, TSDTA_FAILED |
| `EXCEL_EXTRACTION_COMPLETED` | Sheets extracted successfully | READY_FOR_VERSIONING |
| `TSDTA_FAILED` | Excel processing failed | Manual intervention required |
| `DOC_PROCESSING` | PDF/Word being processed | DOC_COMPLETED, DOC_FAILED |
| `DOC_COMPLETED` | Document processed successfully | READY_FOR_VERSIONING |
| `DOC_FAILED` | Document processing failed | Manual intervention required |
| `READY_FOR_VERSIONING` | All processing complete | VERSIONING_IN_PROCESS |
| `VERSIONING_IN_PROCESS` | DTA creation in progress | VERSIONED, VERSIONING_FAILED |
| `VERSIONED` | DTA created successfully | Terminal state |
| `VERSIONING_FAILED` | DTA creation failed | Manual intervention required |
| `EXTRACTION_ERROR` | File extraction failed | Manual intervention required |

### Document Processing Lifecycle

![Document Processing Lifecycle](./diagrams/03_document_processing_lifecycle.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/03_document_processing_lifecycle.drawio)

### Status Tracking Columns

The `md_file_history` table includes additional columns for status tracking:

| Column | Purpose |
|--------|---------|
| `status` | Current processing status |
| `status_timestamp` | When status was last updated |
| `error_message` | Error details if status is a failure state |
| `processing_duration_seconds` | Time taken for processing |
| `retry_count` | Number of retry attempts |

---

## DTA and Metadata Statuses

### Status Alignment

The `dta.status` and `md_version_registry.status` columns are aligned 1:1, enabling simplified joins and consistent state management:

| Status | Description | effective_end_ts | Editable? |
|--------|-------------|------------------|-----------|
| `DRAFT` | DTA being created or edited | NULL | Yes |
| `ACTIVE` | Approved and in use | NULL | No |
| `PROMOTED` | Elevated to template | NULL | No |
| `ARCHIVED` | No longer active | Timestamp when archived | No |

### DTA Entity Status

The `dta` table in the Gold layer tracks DTA lifecycle status. The simplified join pattern uses `d.status = vr.status` instead of filtering by specific version types.

#### Status Values

| Status | Description | Transition From | Transition To |
|--------|-------------|-----------------|---------------|
| `DRAFT` | DTA being created or edited | (initial), REJECTED | ACTIVE |
| `ACTIVE` | Approved and in use | DRAFT (via approval) | PROMOTED, ARCHIVED |
| `PROMOTED` | Elevated to template | ACTIVE | ARCHIVED |
| `ARCHIVED` | No longer active | DRAFT, ACTIVE, PROMOTED | (terminal) |

**Note**: Workflow states (NOT_STARTED, IN_REVIEW, APPROVED, REJECTED) are tracked separately in `workflow_state` column.

#### DTA Status Lifecycle

![DTA Status Lifecycle](./diagrams/03_dta_status_lifecycle.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/03_dta_status_lifecycle.drawio)

### Silver Layer Validation Status

Records in the Silver layer (`md_dta_transfer_variables_draft`, `md_codelists_normalized`) have a `status` column indicating validation results.

| Status | Description |
|--------|-------------|
| `COMPLETED` | All required fields present and valid |
| `MANUAL_REVIEW_REQUIRED` | Missing or invalid fields needing review |

### Status Propagation (Silver → Gold)

When a DTA is created from Silver layer records:

- If **all records** have `status = COMPLETED` → DTA status is `ACTIVE`
- If **any record** has `status = MANUAL_REVIEW_REQUIRED` → DTA status starts as `DRAFT` for review

The corresponding `md_version_registry` entries are created with matching status (1:1 alignment).

### Version Registry Status

The `md_version_registry` table tracks version status aligned with `dta.status`:

| Status | effective_end_ts | Description |
|--------|------------------|-------------|
| `DRAFT` | NULL | Version being edited |
| `ACTIVE` | NULL | Approved version in use |
| `PROMOTED` | NULL | Elevated to template version |
| `ARCHIVED` | Timestamp | Previous version, no longer active |

**Note**: `effective_end_ts` is only set when status = `ARCHIVED`. This enables efficient queries without needing an `is_current` flag.

---

## Related Documentation

- [01_job_architecture_design.readme.md](./01_job_architecture_design.readme.md) - Processing pipeline and job definitions
- [02_schema_design.readme.md](./02_schema_design.readme.md) - Full table schema documentation
- [04_versioning_design.readme.md](./04_versioning_design.readme.md) - Version registry and SCD Type 2
- [06_dta_workflow_design.readme.md](./06_dta_workflow_design.readme.md) - Workflow, approval chain, and governance

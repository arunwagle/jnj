# Job Architecture Design

> **Status**: Implemented  
> **Last Updated**: January 2026

---

## Overview

This document describes the Clinical Data Standards job architecture for processing DTA (Data Transfer Agreement) data, managing versions, and exporting metadata.

### Main Jobs

| Job Name | Purpose | Trigger |
|----------|---------|---------|
| `job_cdm_dta_import` | End-to-end orchestrator for historical DTA import | File Arrival / Manual |
| `job_cds_file_processor` | Extract ZIP archives and create document manifest | Called by orchestrator |
| `job_cds_tsdta_xls_processor` | Process tsDTA Excel files (sheets, codelists, transfer vars, test concepts) | Called by orchestrator |
| `job_cdm_dta_create` | Create DTA instances and manage versioning | Called by orchestrator / API |
| `job_cdm_version_manager` | Versioning operations (branch, save, approve, template) | API / UI |
| `job_cdm_export_file` | Export DTA metadata to Excel/PDF files | API / UI |
| `job_cdm_export_genie_assets` | Generate Genie space training assets | Manual |
| `job_populate_config_cache` | Load configuration into Spark cache | Called by other jobs |

### Test Jobs

| Job Name | Purpose | Triggers |
|----------|---------|----------|
| `job_test_cdm_dta_import` | End-to-end test for DTA import pipeline | `job_cdm_dta_import` |
| `job_test_cdm_cleanup` | Drop all tables and delete checkpoint folders | Direct notebook |
| `job_test_cdm_create_dta_template` | Test DTA Template creation from approved DTAs | `job_cdm_version_manager` |
| `job_test_cdm_export_genie_assets` | Test Genie asset generation | `job_cdm_export_genie_assets` |
| `job_test_cds_sql_setup` | Test SQL catalog/schema setup | `job_cds_sql_setup` |

---

## Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| DTA Import | End-to-end orchestrator flow | [PNG](./diagrams/01_job_cdm_dta_import.drawio.png) | [Draw.io](./diagrams/01_job_cdm_dta_import.drawio) |
| File Processor | ZIP extraction and manifest creation | [PNG](./diagrams/01_job_cds_file_processor.drawio.png) | [Draw.io](./diagrams/01_job_cds_file_processor.drawio) |
| tsDTA Processor | Excel sheet processing pipeline | [PNG](./diagrams/01_job_cds_tsdta_xls_processor.drawio.png) | [Draw.io](./diagrams/01_job_cds_tsdta_xls_processor.drawio) |
| DTA Create | DTA instance creation with branching | [PNG](./diagrams/01_job_cdm_dta_create.drawio.png) | [Draw.io](./diagrams/01_job_cdm_dta_create.drawio) |
| Version Manager | Condition chain for versioning actions | [PNG](./diagrams/01_job_cdm_version_manager.drawio.png) | [Draw.io](./diagrams/01_job_cdm_version_manager.drawio) |
| Export File | File export to Volumes | [PNG](./diagrams/01_job_cdm_export_file.drawio.png) | [Draw.io](./diagrams/01_job_cdm_export_file.drawio) |
| Export Genie Assets | Genie training asset generation | [PNG](./diagrams/01_job_cdm_export_genie_assets.drawio.png) | [Draw.io](./diagrams/01_job_cdm_export_genie_assets.drawio) |

---

## Main Jobs

### 1. job_cdm_dta_import

**Description**

The main orchestrator job for importing historical clinical trial data end-to-end. It coordinates file extraction, Excel processing, and DTA entity creation.

**Trigger**

| Type | Details |
|------|---------|
| File Arrival | Automatically triggers when new ZIP files land in `/Volumes/{catalog}/bronze_md/clinical_data_standards/historical_data/uploads/` |
| Manual | Can be run via Databricks CLI or UI |

**Pipeline Flow**

![DTA Import Pipeline](./diagrams/01_job_cdm_dta_import.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_dta_import.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `process_files` | Extract ZIP archives, create manifest | - |
| `process_tsdta` | Process tsDTA Excel files | `process_files` |
| `create_dta` | Create DTA entities and versions | `process_tsdta` |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_dta_import.job.yml` |
| Notebooks | Uses `run_job_task` to call child jobs |

---

### 2. job_cds_file_processor

**Description**

Processes ZIP files containing clinical trial documents. Extracts archives, creates document manifest in bronze layer, and tags files for downstream processing.

**Trigger**

| Type | Details |
|------|---------|
| Called by | `job_cdm_dta_import` via `run_job_task` |
| Manual | Can be run independently for testing |

**Pipeline Flow**

![File Processor Pipeline](./diagrams/01_job_cds_file_processor.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cds_file_processor.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `process_files` | Extract ZIPs, create manifest, tag documents | `setup` |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_file_processor.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Processor Notebook | `notebooks/data_engineering/clinical_data_standards/jobs/nb_file_processor.ipynb` |

---

### 3. job_cds_tsdta_xls_processor

**Description**

Processes tsDTA (Trial Specific Data Transfer Agreement) Excel files. Extracts sheets, processes codelists, transfer variables, and test concepts into silver layer tables.

**Trigger**

| Type | Details |
|------|---------|
| Called by | `job_cdm_dta_import` via `run_job_task` |
| Manual | Can be run independently for testing |

**Pipeline Flow**

![tsDTA Processor Pipeline](./diagrams/01_job_cds_tsdta_xls_processor.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cds_tsdta_xls_processor.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `extract_excel_sheets` | Read Excel files, extract sheet data to bronze | `setup` |
| `load_codelist` | Process codelists, create lookup table | `extract_excel_sheets` |
| `load_transfer_metadata` | Process transfer variables, compute hash | `load_codelist` |
| `load_test_concepts` | Extract test concepts with dynamic headers | `load_transfer_metadata` |
| `update_completion_status` | Mark documents as READY_FOR_VERSIONING | `load_test_concepts` |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_tsdta_processor.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Extract Sheets | `notebooks/data_engineering/clinical_data_standards/jobs/nb_extract_excel_sheets.ipynb` |
| Codelists | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_code_lists_processor.ipynb` |
| Transfer Variables | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_transfer_variables_processor.ipynb` |
| Test Concepts | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_test_concepts_processor.ipynb` |
| Completion Status | `notebooks/data_engineering/clinical_data_standards/jobs/nb_update_completion_status.ipynb` |

---

### 4. job_cdm_dta_create

**Description**

Creates DTA instances and manages the versioning workflow. Supports two modes:
- **HISTORICAL**: Simulates full draft → approve flow (for bulk import)
- **UI**: Creates DTA in draft status for manual editing

**Trigger**

| Type | Details |
|------|---------|
| Called by | `job_cdm_dta_import` via `run_job_task` (HISTORICAL mode) |
| API/UI | Direct invocation for new DTA creation (UI mode) |

**Pipeline Flow**

![DTA Create Pipeline](./diagrams/01_job_cdm_dta_create.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_dta_create.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `create_dta_instance` | Create DTA entity record | `setup` |
| `check_source` | Condition: Is source HISTORICAL? | `create_dta_instance` |
| **HISTORICAL Branch (true):** | | |
| `save_draft` | Link silver records with draft version | `check_source` (true) |
| `approve_to_major` | Promote draft to DTA Major in gold | `save_draft` |
| **UI Branch (false):** | | |
| `create_branch` | Create branch from library template | `check_source` (false) |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_dta_create.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Create Instance | `notebooks/data_engineering/common/nb_create_dta_instance.ipynb` |
| Save Draft | `notebooks/data_engineering/common/nb_version_save_draft.ipynb` |
| Approve DTA | `notebooks/data_engineering/common/nb_version_approve_dta.ipynb` |

---

### 5. job_cdm_version_manager

**Description**

Manages Clinical Data Metadata versioning operations using SCD Type 2. Supports five mutually exclusive actions via condition task chain (only one action runs per execution).

**Actions**

| Action | Description | Use Case |
|--------|-------------|----------|
| `CREATE_BRANCH` | Create new DTA draft from library template | UI initiates new DTA |
| `SAVE_DRAFT` | Save changes to existing draft | UI saves edits |
| `APPROVE_DTA` | Promote draft to DTA Major | Workflow approval |
| `CREATE_DTA_APPROVED` | Create DTA Major directly | Single DTA via API |
| `CREATE_DTA_TEMPLATE` | Merge approved DTAs into template | Librarian promotion |

**Trigger**

| Type | Details |
|------|---------|
| API/UI | Called with `action` parameter to specify operation |
| Other Jobs | Called by `job_cdm_dta_create` for branching |

**Pipeline Flow**

![Version Manager Pipeline](./diagrams/01_job_cdm_version_manager.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_version_manager.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and initialize context | - |
| `check_create_branch` | Condition: Is action CREATE_BRANCH? | `setup` |
| `create_branch` | Execute CREATE_BRANCH action | `check_create_branch` (true) |
| `check_save_draft` | Condition: Is action SAVE_DRAFT? | `check_create_branch` (false) |
| `save_draft` | Execute SAVE_DRAFT action | `check_save_draft` (true) |
| `check_approve_dta` | Condition: Is action APPROVE_DTA? | `check_save_draft` (false) |
| `approve_dta` | Execute APPROVE_DTA action | `check_approve_dta` (true) |
| `check_create_major` | Condition: Is action CREATE_DTA_APPROVED? | `check_approve_dta` (false) |
| `create_dta_major` | Execute CREATE_DTA_APPROVED action | `check_create_major` (true) |
| `create_dta_template` | Execute CREATE_DTA_TEMPLATE (default) | `check_create_major` (false) |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_version_manager.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Create Branch | `notebooks/data_engineering/common/nb_version_create_branch.ipynb` |
| Save Draft | `notebooks/data_engineering/common/nb_version_save_draft.ipynb` |
| Approve DTA | `notebooks/data_engineering/common/nb_version_approve_dta.ipynb` |
| Create Template | `notebooks/data_engineering/common/nb_promote_to_template.ipynb` |

---

### 6. job_cdm_export_file

**Description**

Generic file export job for DTA metadata. Generates Excel/PDF files and uploads to Unity Catalog Volumes.

**Export Types**

| Type | Format | Status |
|------|--------|--------|
| `tsDTA` | Excel (.xlsx) | ✅ Implemented |
| `oa` | PDF | 🔜 Future |
| `dta_full` | ZIP package | 🔜 Future |

**Trigger**

| Type | Details |
|------|---------|
| API/UI | Called with `dta_id` and `export_type` parameters |

**Pipeline Flow**

![Export File Pipeline](./diagrams/01_job_cdm_export_file.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_export_file.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and validate parameters | - |
| `export_file` | Generate export file and upload to Volumes | `setup` |

**Output Path**

```
/Volumes/{catalog}/bronze_md/{source_root}/exports/{date}/{dta_number}/
```

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_export_file.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Export Notebook | `notebooks/data_engineering/clinical_data_standards/jobs/nb_export_dta_file.ipynb` |

---

### 7. job_cdm_export_genie_assets

**Description**

Generates Databricks Genie space training assets. Dynamically discovers tables, generates SQL comments, instructions, example queries, and assembles the serialized space configuration.

**Trigger**

| Type | Details |
|------|---------|
| Manual | Run via Databricks CLI or UI |

**Pipeline Flow**

![Export Genie Assets Pipeline](./diagrams/01_job_cdm_export_genie_assets.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/01_job_cdm_export_genie_assets.drawio)

| Task | Description | Dependency |
|------|-------------|------------|
| `setup` | Load configuration and validate parameters | - |
| `export_genie_assets` | Generate SQL comments, instructions, example queries, component JSONs | `setup` |
| `generate_serialized_space` | Assemble components into `serialized_space.json` | `export_genie_assets` |

**Output Files**

```
/Volumes/{catalog}/bronze_md/{source_volume}/{source_root}/exports/genie/
├── sql/
│   ├── add_table_comments.sql
│   └── example_queries.sql
├── components/
│   ├── data_sources.json
│   ├── sample_questions.json
│   ├── text_instructions.json
│   └── example_queries.json
├── genie_instructions.txt
├── serialized_space.json
└── export_manifest.json
```

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/clinical_data_standards/jobs/job_cdm_export_genie_assets.job.yml` |
| Setup Notebook | `notebooks/data_engineering/common/nb_setup.ipynb` |
| Export Assets | `notebooks/data_engineering/clinical_data_standards/jobs/nb_export_genie_assets.ipynb` |
| Generate Space | `notebooks/data_engineering/clinical_data_standards/jobs/nb_generate_serialized_space.ipynb` |

---

## Test Jobs

Test jobs are used for development and validation. They typically trigger main jobs with test-specific parameters.

### job_test_cdm_dta_import

**Purpose**: End-to-end test for the DTA import pipeline.

| Parameter | Default | Description |
|-----------|---------|-------------|
| `catalog_override` | `aira_test` | Test catalog |
| `source_root` | `test` | Uses test/uploads folder |

**Triggers**: `job_cdm_dta_import`

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/test/jobs/job_test_cdm_dta_import.job.yml` |

---

### job_test_cdm_cleanup

**Purpose**: Drop all bronze, silver, and gold tables. Delete checkpoint and ingested folders.

> ⚠️ **WARNING**: Only run in dev/test environments!

| Parameter | Default | Description |
|-----------|---------|-------------|
| `catalog_override` | `aira_test` | Catalog to clean up |

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/test/jobs/job_test_cdm_cleanup.job.yml` |
| Cleanup Notebook | `notebooks/data_engineering/test/jobs/nb_cleanup_test_data.ipynb` |

---

### job_test_cdm_create_dta_template

**Purpose**: Test DTA Template creation from approved DTAs. Templates are scoped by (vendor, data_stream) combination.

| Parameter | Default | Description |
|-----------|---------|-------------|
| `library_type` | (empty) | Process all library types |
| `merge_strategy` | `UNION_DEDUP` | How to merge records |
| `data_provider_name` | (empty) | Filter by vendor |
| `data_stream_type` | (empty) | Filter by stream |

**Triggers**: `job_cdm_version_manager` with `action=CREATE_DTA_TEMPLATE`

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/test/jobs/job_test_cdm_create_dta_template.job.yml` |

---

### job_test_cdm_export_genie_assets

**Purpose**: Test Genie asset generation.

**Triggers**: `job_cdm_export_genie_assets`

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/data_engineering/test/jobs/job_test_cdm_export_genie_assets.job.yml` |

---

### job_test_cds_sql_setup

**Purpose**: Test SQL catalog and schema setup.

**Triggers**: `job_cds_sql_setup`

**Low Level Design**

| Component | Path |
|-----------|------|
| Job Definition | `resources/sql/test/jobs/job_test_cds_sql_setup.job.yml` |

---

## Related Documentation

- [02_schema_design.readme.md](./02_schema_design.readme.md) - Table schemas and data model
- [04_versioning_design.readme.md](./04_versioning_design.readme.md) - Version management operations
- [06_dta_workflow_design.readme.md](./06_dta_workflow_design.readme.md) - Workflow, approval chain, and governance
- [09_genie_integration_design.readme.md](./09_genie_integration_design.readme.md) - Genie AI integration

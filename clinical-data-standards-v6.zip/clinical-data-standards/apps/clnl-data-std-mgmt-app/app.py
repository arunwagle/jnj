
from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
from datetime import datetime
import json
import random
import re
import os

# Import API layer and data storage
from api import api
from api import data
from api.data import WORKSPACES, MOCK_RUNS, MOCK_RESULTS
from api.versioning_api import versioning_bp
from api.dashboard_api import dashboard_bp, get_dashboard_data
from api.dta_api import dta_bp, get_dta_create_context
from api.genie_api import genie_bp

app = Flask(__name__)
app.secret_key = "dev-secret"  # for flashes (demo only)

# Register API blueprints
app.register_blueprint(versioning_bp)
app.register_blueprint(dashboard_bp)
app.register_blueprint(dta_bp)
app.register_blueprint(genie_bp)

# -------- Routes --------
@app.route("/")
def home():
    return redirect(url_for("dashboard"))

@app.route("/dashboard")
def dashboard():
    """Dashboard - main view with action cards, DTA overview, library status, and activity"""
    import os
    import traceback
    
    # Debug: Log environment variables
    print("=" * 60)
    print("DASHBOARD: Loading dashboard data...")
    print(f"DASHBOARD: CATALOG_NAME = {os.environ.get('CATALOG_NAME', 'NOT SET')}")
    print(f"DASHBOARD: GOLD_SCHEMA = {os.environ.get('GOLD_SCHEMA', 'NOT SET')}")
    print(f"DASHBOARD: DATABRICKS_WAREHOUSE_ID = {os.environ.get('DATABRICKS_WAREHOUSE_ID', 'NOT SET')}")
    print("=" * 60)
    
    try:
        # Get all dashboard data from the new dashboard API
        dashboard_data = get_dashboard_data()
        print("DASHBOARD: Successfully loaded dashboard data")
        return render_template("dashboard.html", dashboard=dashboard_data)
    except Exception as e:
        # Log the full error with traceback
        print("=" * 60)
        print(f"DASHBOARD ERROR: {str(e)}")
        print("DASHBOARD TRACEBACK:")
        traceback.print_exc()
        print("=" * 60)
        
        flash(f"Error loading dashboard: {str(e)}", "error")
        # Return empty dashboard data with error message
    return render_template("dashboard.html", 
            dashboard={
                "action_required": {"pending_approvals": 0, "my_drafts": 0, "processing_documents": 0, "ready_for_promotion": 0},
                "dta_overview": {"total": 0, "by_status": {"approved": 0, "in_review": 0, "draft": 0, "rejected": 0}},
                "library_entities": [],
                "recent_dtas": [],
                "recent_activity": [],
                "processing_stats": {"this_month": {"dtas_created": 0, "files_processed": 0}, "success_rate": 0}
            },
            error_message=str(e)
        )

@app.route("/upload")
def upload():
    """Upload Documents page"""
    return render_template("upload.html")

@app.route("/create-dta")
def create_dta():
    """Create DTA page - two-panel wizard for creating new DTAs"""
    import traceback
    
    try:
        # Get pre-selected library versions from URL params (from dashboard)
        selected_libraries = {}
        code_mapping = {
            'lib_tv': 'TV',
            'lib_cl': 'CL',
            'lib_tc': 'TC',
            'lib_oa': 'OA',
            'lib_vt': 'VT',
            'lib_dip': 'DIP'
        }
        
        for param, code in code_mapping.items():
            value = request.args.get(param)
            if value and value.lower() != 'none':
                selected_libraries[code] = value
        
        print(f"CREATE-DTA: Pre-selected libraries from URL: {selected_libraries}")
        
        # Get full context for the page
        context = get_dta_create_context(selected_libraries)
        
        return render_template("create_dta.html", context=context)
        
    except Exception as e:
        print("=" * 60)
        print(f"CREATE-DTA ERROR: {str(e)}")
        traceback.print_exc()
        print("=" * 60)
        
        flash(f"Error loading DTA creation page: {str(e)}", "error")
        return redirect(url_for("dashboard"))

@app.route("/document-editor/<doc_id>")
def document_editor(doc_id):
    """Document Editor for manual review"""
    doc_type = request.args.get("type", "Protocol")
    
    # Mock extracted data based on document type
    if doc_type == "Protocol":
        doc_data = {
            "id": doc_id,
            "type": "Protocol",
            "filename": "Clinical_Protocol_TRIAL-ABC_v3.2.pdf",
            "extracted": {
                "trial_id": "TRIAL-ABC",
                "protocol_number": "JNJ-ABC-2025-001",
                "study_title": "A Phase 3, Randomized, Double-Blind Study of Drug X in Patients with Condition Y",
                "study_phase": "Phase 3",
                "therapeutic_area": "Oncology",
                "transfer_variables": "STUDYID, USUBJID, DOMAIN, AGE, SEX, RACE, COUNTRY",
                "test_concepts": "LBTESTCD, LBTEST, LBCAT, LBORRES, LBORRESU"
            },
            "notes": ""
        }
    else:  # SOW
        doc_data = {
            "id": doc_id,
            "type": "SOW",
            "filename": "SOW_Vendor_XYZ_2025.docx",
            "extracted": {
                "vendor_name": "ABC Clinical Labs",
                "vendor_id": "VEND-2",
                "data_stream": "Laboratory Results",
                "agreement_date": "2025-01-15",
                "data_format": "CSV",
                "delivery_frequency": "Weekly"
            },
            "notes": ""
        }
    
    return render_template("document_editor.html", doc_data=doc_data)

@app.route('/api/run-documents/<run_id>')
def get_run_documents_api(run_id):
    """API endpoint to get documents for a specific run"""
    warehouse_id = os.environ.get('DATABRICKS_WAREHOUSE_ID')
    result = api.get_run_documents(run_id, warehouse_id=warehouse_id)
    return jsonify(result)

@app.route("/ingestion")
def ingestion():
    """Ingestion jobs page - shows recent job runs from Databricks"""
    status = request.args.get("status")
    
    # Get warehouse_id from environment (set in app.yaml)
    warehouse_id = os.environ.get('DATABRICKS_WAREHOUSE_ID')
    
    if not warehouse_id:
        print("ERROR: DATABRICKS_WAREHOUSE_ID not set!")
        return render_template(
            'ingestion.html',
            error="Configuration error: DATABRICKS_WAREHOUSE_ID not set"
        )
    
    print(f"DEBUG: Using warehouse_id: {warehouse_id}")
    
    # Get jobs from API (uses real Databricks data - no mock fallback)
    result = api.get_jobs(status_filter=status, use_real_data=True, warehouse_id=warehouse_id)
    
    # If there's an error, display it
    if not result.get('success'):
        flash(f"Error loading jobs: {result.get('error')}", "error")
        return render_template(
            'ingestion.html',
            jobs=[],
            runs=[],
            status=status,
            kpis={
                "runs7d": 0,
                "successRate": "0%",
                "avgDuration": "N/A",
                "entitiesProduced": []
            },
            error=result.get('error', 'Unknown error'),
            error_details=result.get('details') or result.get('traceback'),
            is_mock_data=True,  # Flag for fallback/mock data
            unavailable_jobs_count=0
        )
    
    api_data = result["data"]
    jobs = api_data.get("jobs", [])  # Jobs with enriched run statistics
    runs = api_data.get("runs", [])  # All runs (for backward compatibility)
    kpis = api_data.get("kpis", {})
    
    # Count unavailable jobs (jobs that couldn't be loaded)
    unavailable_jobs_count = len(result.get("warnings", []))
    
    return render_template("ingestion.html", jobs=jobs, runs=runs, status=status, kpis=kpis, 
                           is_mock_data=False, unavailable_jobs_count=unavailable_jobs_count)

def parse_search_query(q):
    """
    Parse free-form search query and extract trial, vendor, stream filters.
    Supports formats like:
    - "TRIAL-ABC"
    - "trial id = ABC"
    - "ABC"
    - "trial id = ABC and vendor id = VEND-1"
    - "ABC VEND-1"
    """
    import re
    
    q_lower = q.lower()
    filters = {
        'trial': [],
        'vendor': [],
        'stream': []
    }
    
    # Pattern for "field = value" or "field: value"
    field_patterns = [
        (r'trial\s*(?:id)?\s*[=:]\s*([a-z0-9\-]+)', 'trial'),
        (r'vendor\s*(?:id)?\s*[=:]\s*([a-z0-9\-]+)', 'vendor'),
        (r'(?:data\s*)?stream\s*[=:]\s*([a-z0-9\-]+)', 'stream'),
    ]
    
    for pattern, field in field_patterns:
        matches = re.findall(pattern, q_lower, re.IGNORECASE)
        for match in matches:
            # Add with or without prefix
            filters[field].append(match.upper())
            if field == 'trial' and not match.upper().startswith('TRIAL-'):
                filters[field].append(f'TRIAL-{match.upper()}')
            elif field == 'vendor' and not match.upper().startswith('VEND-'):
                filters[field].append(f'VEND-{match.upper()}')
    
    # If no structured patterns found, try to extract tokens
    if not any(filters.values()):
        # Remove common words
        stop_words = ['and', 'or', 'the', 'id', '=', ':']
        tokens = re.findall(r'[a-z0-9\-]+', q_lower)
        tokens = [t for t in tokens if t not in stop_words and len(t) > 1]
        
        for token in tokens:
            token_upper = token.upper()
            # Try to guess the field type
            if token.startswith('trial-') or re.match(r'^trial', token):
                filters['trial'].append(token_upper)
                if not token_upper.startswith('TRIAL-'):
                    filters['trial'].append(f'TRIAL-{token_upper}')
            elif token.startswith('vend-') or re.match(r'^vend', token):
                filters['vendor'].append(token_upper)
                if not token_upper.startswith('VEND-'):
                    filters['vendor'].append(f'VEND-{token_upper}')
            else:
                # Could be trial, vendor, or stream - add to all
                filters['trial'].append(token_upper)
                filters['trial'].append(f'TRIAL-{token_upper}')
                filters['vendor'].append(token_upper)
                filters['vendor'].append(f'VEND-{token_upper}')
                filters['stream'].append(token_upper)
    
    return filters

# ============================================================================
# AUDIT & ACTIVITY
# ============================================================================

@app.route("/audit")
def audit():
    """Audit & Activity screen - shows all DTAs with activity logs."""
    return render_template("audit.html")

# =============================================================================
# APPROVALS ROUTES
# =============================================================================

@app.route("/approvals")
def approvals():
    """Approvals list screen - shows DTAs pending approval for current user."""
    from api.dta_api import _get_db_config, _get_sql_client
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    
    # Current user (hardcoded for now)
    current_user_email = "arun.wagle@jnj.com"
    
    # Get DTAs pending approval
    query = f"""
        SELECT 
            d.dta_id,
            d.dta_number,
            d.dta_name,
            d.trial_id,
            d.data_stream_type,
            d.data_provider_name,
            d.status,
            d.workflow_state,
            d.current_version_tag,
            d.last_updated_ts,
            w.dta_workflow_id,
            w.workflow_status,
            w.initiated_ts
        FROM {catalog}.{gold_schema}.dta d
        LEFT JOIN {catalog}.{gold_schema}.dta_workflow w 
            ON d.dta_id = w.dta_id AND d.workflow_iteration = w.workflow_iteration
        WHERE d.workflow_state IN ('IN_REVIEW', 'APPROVED')
           OR d.status = 'PENDING_APPROVAL'
        ORDER BY w.initiated_ts DESC NULLS LAST, d.last_updated_ts DESC
    """
    
    try:
        result = client.execute_query(query)
        dtas_raw = result if result else []
        
        # Get approval tasks for each DTA
        dtas = []
        for dta in dtas_raw:
            tasks_query = f"""
                SELECT 
                    approval_task_id,
                    approver_role,
                    assigned_to_principal,
                    approval_status,
                    approval_order,
                    approval_comment,
                    approved_ts
                FROM {catalog}.{gold_schema}.dta_approval_task
                WHERE dta_id = '{dta['dta_id']}'
                ORDER BY approval_order
            """
            tasks_result = client.execute_query(tasks_query)
            tasks = tasks_result if tasks_result else []
            
            # Check if current user has a pending task
            user_can_approve = any(
                t['assigned_to_principal'] == current_user_email and t['approval_status'] == 'PENDING'
                for t in tasks
            )
            
            # Check if all approved
            all_approved = all(t['approval_status'] == 'APPROVED' for t in tasks) if tasks else False
            
            dtas.append({
                **dta,
                'approvals': tasks,
                'user_can_approve': user_can_approve,
                'all_approved': all_approved
            })
        
        return render_template("approvals.html", 
                             dtas=dtas, 
                             current_user_email=current_user_email,
                             nav_active='approvals')
    except Exception as e:
        print(f"Error loading approvals: {e}")
        import traceback
        traceback.print_exc()
        return render_template("approvals.html", dtas=[], current_user_email=current_user_email, nav_active='approvals')

@app.route("/approvals/<dta_id>")
def approval_detail(dta_id):
    """Approval detail page for a specific DTA."""
    from api.dta_api import _get_db_config, _get_sql_client
    
    print(f"=" * 60)
    print(f"APPROVAL DETAIL: Loading DTA ID = {dta_id}")
    print(f"=" * 60)
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    
    # Current user (hardcoded for now)
    current_user_email = "arun.wagle@jnj.com"
    
    # Get DTA details
    dta_query = f"""
        SELECT 
            d.dta_id,
            d.dta_number,
            d.dta_name,
            d.trial_id,
            d.data_stream_type,
            d.data_provider_name,
            d.status,
            d.workflow_state,
            d.current_version_tag,
            d.last_updated_ts,
            w.dta_workflow_id,
            w.workflow_status,
            w.initiated_ts,
            w.summary_comment
        FROM {catalog}.{gold_schema}.dta d
        LEFT JOIN {catalog}.{gold_schema}.dta_workflow w 
            ON d.dta_id = w.dta_id AND d.workflow_iteration = w.workflow_iteration
        WHERE d.dta_id = '{dta_id}'
    """
    
    print(f"APPROVAL DETAIL: Executing query...")
    
    try:
        result = client.execute_query(dta_query)
        dta_list = result if result else []
        
        print(f"APPROVAL DETAIL: Query returned {len(dta_list)} rows")
        if dta_list:
            print(f"APPROVAL DETAIL: First row = {dta_list[0]}")
        
        if not dta_list:
            print(f"APPROVAL DETAIL ERROR: DTA {dta_id} not found!")
            flash("DTA not found", "error")
            return redirect(url_for('approvals'))
        
        dta = dta_list[0]
        
        # Get approval tasks
        tasks_query = f"""
            SELECT 
                approval_task_id,
                approver_role,
                assigned_to_principal,
                approval_status,
                approval_order,
                approval_comment,
                approved_ts,
                created_ts
            FROM {catalog}.{gold_schema}.dta_approval_task
            WHERE dta_id = '{dta_id}'
            ORDER BY approval_order
        """
        tasks_result = client.execute_query(tasks_query)
        tasks = tasks_result if tasks_result else []
        
        # Check if current user has a pending task
        user_task = next(
            (t for t in tasks if t['assigned_to_principal'] == current_user_email and t['approval_status'] == 'PENDING'),
            None
        )
        
        # Check if all approved
        all_approved = all(t['approval_status'] == 'APPROVED' for t in tasks) if tasks else False
        
        return render_template("approval_detail.html",
                             dta=dta,
                             tasks=tasks,
                             user_task=user_task,
                             all_approved=all_approved,
                             current_user_email=current_user_email,
                             nav_active='approvals')
    except Exception as e:
        print(f"Error loading approval detail: {e}")
        import traceback
        traceback.print_exc()
        flash(f"Error loading DTA: {e}", "error")
        return redirect(url_for('approvals'))

@app.route("/workspace/<dta_id>/assign-approvers")
def assign_approvers(dta_id):
    """Assign approvers to a DTA before starting work."""
    from api.dta_api import _get_db_config, _get_sql_client
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    
    # Current user (hardcoded for now)
    current_user_email = "arun.wagle@jnj.com"
    current_user_name = "Arun Wagle"
    
    # Get DTA details
    dta_query = f"""
        SELECT 
            dta_id,
            dta_number,
            dta_name,
            trial_id,
            data_stream_type,
            data_provider_name,
            status
        FROM {catalog}.{gold_schema}.dta
        WHERE dta_id = '{dta_id}'
    """
    
    try:
        result = client.execute_query(dta_query)
        dta_list = result if result else []
        
        if not dta_list:
            flash("DTA not found", "error")
            return redirect(url_for('composer'))
        
        dta = dta_list[0]
        
        return render_template("assign_approvers.html",
                             dta=dta,
                             current_user_email=current_user_email,
                             current_user_name=current_user_name)
    except Exception as e:
        print(f"Error loading DTA for approver assignment: {e}")
        import traceback
        traceback.print_exc()
        flash(f"Error loading DTA: {e}", "error")
        return redirect(url_for('composer'))

@app.route("/api/audit/dtas")
def api_audit_dtas():
    """Get all DTAs for audit screen."""
    try:
        from api.dta_api import _get_db_config, _get_sql_client
        
        config = _get_db_config()
        client = _get_sql_client()
        
        dta_table = f"{config['catalog']}.{config['gold_schema']}.dta"
        
        query = f"""
            SELECT dta_id, dta_number, dta_name, trial_id, data_stream_type,
                   data_provider_name, status, workflow_state, 
                   DATE_FORMAT(last_updated_ts, 'MMM dd, yyyy') as last_updated
            FROM {dta_table}
            ORDER BY last_updated_ts DESC
        """
        
        print(f"AUDIT: Fetching DTAs...")
        results = client.execute_query(query, raise_on_error=True)
        
        dtas = [dict(row) for row in (results or [])]
        print(f"AUDIT: Found {len(dtas)} DTAs")
        
        return jsonify({"ok": True, "dtas": dtas})
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "msg": str(e), "dtas": []})

# =============================================================================
# APPROVAL WORKFLOW APIS
# =============================================================================

@app.route("/api/dta/assign-approvers", methods=["POST"])
def api_assign_approvers():
    """Assign approvers to a DTA's approval tasks."""
    from api.dta_api import _get_db_config, _get_sql_client
    
    data = request.get_json()
    dta_id = data.get("dta_id")
    approvers = data.get("approvers", [])
    
    if not dta_id or not approvers:
        return jsonify({"ok": False, "error": "Missing dta_id or approvers"})
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    approval_table = f"{catalog}.{gold_schema}.dta_approval_task"
    
    try:
        # Update each approver's task
        for approver in approvers:
            role = approver.get("role")
            email = approver.get("email")
            
            if role and email:
                update_query = f"""
                    UPDATE {approval_table}
                    SET assigned_to_principal = '{email}',
                        last_updated_ts = current_timestamp()
                    WHERE dta_id = '{dta_id}'
                      AND approver_role = '{role}'
                """
                client.execute_query(update_query)
                print(f"Assigned {role} to {email} for DTA {dta_id}")
        
        return jsonify({"ok": True, "msg": "Approvers assigned successfully"})
        
    except Exception as e:
        print(f"Error assigning approvers: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)})

@app.route("/api/approval/submit/<dta_id>", methods=["POST"])
def api_submit_for_approval(dta_id):
    """Submit a DTA for approval - changes status and notifies approvers."""
    from api.dta_api import _get_db_config, _get_sql_client
    from api.activity_log_api import log_workflow_event
    
    print(f"=" * 60)
    print(f"SUBMIT FOR APPROVAL: DTA ID = {dta_id}")
    print(f"=" * 60)
    
    data = request.get_json() or {}
    comment = data.get("comment", "")
    current_user = "arun.wagle@jnj.com"  # Hardcoded for now
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    
    dta_table = f"{catalog}.{gold_schema}.dta"
    workflow_table = f"{catalog}.{gold_schema}.dta_workflow"
    
    try:
        # First verify DTA exists
        check_query = f"SELECT dta_id, dta_number, status, workflow_state FROM {dta_table} WHERE dta_id = '{dta_id}'"
        check_result = client.execute_query(check_query)
        print(f"SUBMIT: DTA check result: {check_result}")
        
        if not check_result:
            print(f"SUBMIT ERROR: DTA {dta_id} not found!")
            return jsonify({"ok": False, "error": f"DTA {dta_id} not found"})
        
        # Update DTA status
        dta_update = f"""
            UPDATE {dta_table}
            SET status = 'PENDING_APPROVAL',
                workflow_state = 'IN_REVIEW',
                last_updated_ts = current_timestamp(),
                last_updated_by_principal = '{current_user}'
            WHERE dta_id = '{dta_id}'
        """
        print(f"SUBMIT: Executing DTA update...")
        client.execute_query(dta_update)
        print(f"SUBMIT: DTA status updated to PENDING_APPROVAL")
        
        # Update workflow
        workflow_update = f"""
            UPDATE {workflow_table}
            SET workflow_status = 'IN_REVIEW',
                initiated_ts = current_timestamp(),
                summary_comment = '{comment.replace("'", "''")}',
                last_updated_ts = current_timestamp()
            WHERE dta_id = '{dta_id}'
        """
        client.execute_query(workflow_update)
        
        # Log activity
        log_workflow_event(
            dta_id=dta_id,
            activity_type="SUBMITTED_FOR_APPROVAL",
            performed_by=current_user,
            comment=comment
        )
        
        return jsonify({"ok": True, "msg": "DTA submitted for approval"})
        
    except Exception as e:
        print(f"Error submitting for approval: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)})

@app.route("/api/approval/approve/<dta_id>", methods=["POST"])
def api_approve(dta_id):
    """Approve a DTA - current user approves their task."""
    from api.dta_api import _get_db_config, _get_sql_client
    from api.activity_log_api import log_workflow_event
    
    data = request.get_json() or {}
    comment = data.get("comment", "")
    current_user = "arun.wagle@jnj.com"  # Hardcoded for now
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    
    approval_table = f"{catalog}.{gold_schema}.dta_approval_task"
    dta_table = f"{catalog}.{gold_schema}.dta"
    workflow_table = f"{catalog}.{gold_schema}.dta_workflow"
    
    try:
        # Update user's approval task
        task_update = f"""
            UPDATE {approval_table}
            SET approval_status = 'APPROVED',
                approval_comment = '{comment.replace("'", "''")}',
                approved_ts = current_timestamp(),
                last_updated_ts = current_timestamp()
            WHERE dta_id = '{dta_id}'
              AND assigned_to_principal = '{current_user}'
              AND approval_status = 'PENDING'
        """
        client.execute_query(task_update)
        
        # Check if all tasks are approved
        check_query = f"""
            SELECT COUNT(*) as pending_count
            FROM {approval_table}
            WHERE dta_id = '{dta_id}'
              AND approval_status = 'PENDING'
        """
        result = client.execute_query(check_query)
        pending = result[0]['pending_count'] if result else 0
        
        all_approved = (pending == 0)
        
        if all_approved:
            # Update DTA and workflow to APPROVED
            dta_update = f"""
                UPDATE {dta_table}
                SET workflow_state = 'APPROVED',
                    last_updated_ts = current_timestamp()
                WHERE dta_id = '{dta_id}'
            """
            client.execute_query(dta_update)
            
            workflow_update = f"""
                UPDATE {workflow_table}
                SET workflow_status = 'APPROVED',
                    closed_ts = current_timestamp(),
                    last_updated_ts = current_timestamp()
                WHERE dta_id = '{dta_id}'
            """
            client.execute_query(workflow_update)
        
        # Log activity
        log_workflow_event(
            dta_id=dta_id,
            activity_type="APPROVED",
            performed_by=current_user,
            comment=comment
        )
        
        return jsonify({
            "ok": True, 
            "msg": "Approval recorded",
            "all_approved": all_approved
        })
        
    except Exception as e:
        print(f"Error approving: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)})

@app.route("/api/approval/reject/<dta_id>", methods=["POST"])
def api_reject(dta_id):
    """Reject a DTA - current user rejects their task."""
    from api.dta_api import _get_db_config, _get_sql_client
    from api.activity_log_api import log_workflow_event
    
    data = request.get_json() or {}
    comment = data.get("comment", "")
    current_user = "arun.wagle@jnj.com"  # Hardcoded for now
    
    if not comment:
        return jsonify({"ok": False, "error": "Comment is required for rejection"})
    
    config = _get_db_config()
    client = _get_sql_client()
    catalog = config["catalog"]
    gold_schema = config["gold_schema"]
    
    approval_table = f"{catalog}.{gold_schema}.dta_approval_task"
    dta_table = f"{catalog}.{gold_schema}.dta"
    workflow_table = f"{catalog}.{gold_schema}.dta_workflow"
    
    try:
        # Update user's approval task
        task_update = f"""
            UPDATE {approval_table}
            SET approval_status = 'REJECTED',
                approval_comment = '{comment.replace("'", "''")}',
                approved_ts = current_timestamp(),
                last_updated_ts = current_timestamp()
            WHERE dta_id = '{dta_id}'
              AND assigned_to_principal = '{current_user}'
              AND approval_status = 'PENDING'
        """
        client.execute_query(task_update)
        
        # Update DTA back to DRAFT
        dta_update = f"""
            UPDATE {dta_table}
            SET status = 'DRAFT',
                workflow_state = 'REJECTED',
                last_updated_ts = current_timestamp()
            WHERE dta_id = '{dta_id}'
        """
        client.execute_query(dta_update)
        
        # Update workflow
        workflow_update = f"""
            UPDATE {workflow_table}
            SET workflow_status = 'REJECTED',
                closed_ts = current_timestamp(),
                last_updated_ts = current_timestamp()
            WHERE dta_id = '{dta_id}'
        """
        client.execute_query(workflow_update)
        
        # Log activity
        log_workflow_event(
            dta_id=dta_id,
            activity_type="REJECTED",
            performed_by=current_user,
            comment=comment
        )
        
        return jsonify({"ok": True, "msg": "DTA rejected and returned to draft"})
        
    except Exception as e:
        print(f"Error rejecting: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/dta/<dta_id>/update-name", methods=["POST"])
def api_update_dta_name(dta_id):
    """Update DTA name and log the change to activity log."""
    try:
        from api.dta_api import _get_db_config, _get_sql_client
        from api.activity_log_api import log_field_update
        
        data = request.json or {}
        new_name = data.get("dta_name", "").strip()
        
        if not new_name:
            return jsonify({"ok": False, "msg": "DTA name cannot be empty"}), 400
        
        config = _get_db_config()
        client = _get_sql_client()
        dta_table = f"{config['catalog']}.{config.get('gold_schema', 'gold_md')}.dta"
        
        # Get current name for activity log
        current_query = f"SELECT dta_name, dta_number FROM {dta_table} WHERE dta_id = '{dta_id}'"
        current_result = client.execute_query(current_query)
        
        if not current_result:
            return jsonify({"ok": False, "msg": "DTA not found"}), 404
        
        old_name = current_result[0].get("dta_name") or ""
        dta_number = current_result[0].get("dta_number") or dta_id
        
        # Skip if name hasn't changed
        if old_name == new_name:
            return jsonify({"ok": True, "msg": "Name unchanged"})
        
        # Update the DTA name
        escaped_name = new_name.replace("'", "''")
        update_query = f"""
            UPDATE {dta_table}
            SET dta_name = '{escaped_name}',
                last_updated_ts = current_timestamp()
            WHERE dta_id = '{dta_id}'
        """
        client.execute_query(update_query)
        
        # Get current user
        user = "system"
        try:
            from databricks.sdk import WorkspaceClient
            w = WorkspaceClient()
            user = w.current_user.me().user_name or "system"
        except:
            pass
        
        # Log the change to activity log
        log_field_update(
            dta_id=dta_id,
            library_type="DTA",
            entity_id=dta_id,
            entity_name=dta_number,
            field_name="dta_name",
            old_value=old_name,
            new_value=new_name,
            performed_by=user
        )
        
        print(f"DTA name updated: {dta_id} - '{old_name}' -> '{new_name}'")
        return jsonify({"ok": True, "msg": "Name updated successfully"})
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "msg": str(e)}), 500


@app.route("/composer")
def composer():
    """DTA Builder - search existing DTAs and create new ones with optional library versions"""
    import traceback
    from api.dta_api import search_existing_dtas, get_all_library_versions, format_library_entities_for_selection, get_user_drafts
    
    q = (request.args.get("q") or "").strip()
    action = request.args.get("action", "")
    
    # Get pre-selected library versions from URL params (from dashboard)
    selected_libraries = {}
    code_mapping = {
        'lib_tv': 'TV',
        'lib_cl': 'CL',
        'lib_tc': 'TC',
        'lib_oa': 'OA',
        'lib_vt': 'VT',
        'lib_dip': 'DIP'
    }
    
    for param, code in code_mapping.items():
        value = request.args.get(param)
        if value and value.lower() != 'none':
            selected_libraries[code] = value
    
    # Format selected libraries for display
    library_display = []
    if selected_libraries:
        entity_names = {
            'TV': ('📊', 'Transfer Variables'),
            'CL': ('📋', 'Codelists'),
            'TC': ('🧪', 'Test Concepts'),
            'OA': ('📝', 'Operational Agreements'),
            'VT': ('📅', 'Visits & Timepoints'),
            'DIP': ('⚙️', 'Data Ingestion Params')
        }
        for code, version in selected_libraries.items():
            icon, name = entity_names.get(code, ('📁', code))
            library_display.append({
                'code': code,
                'name': name,
                'icon': icon,
                'version': version
            })
    
    # Search results
    results = []
    use_real_search = True  # Flag to use real database search
    
    if q:
        if use_real_search:
            try:
                # Use real DTA search from database
                results = search_existing_dtas(query=q, limit=10)
                print(f"COMPOSER: Found {len(results)} real DTAs for query '{q}'")
            except Exception as e:
                print(f"COMPOSER: Search error: {e}")
                traceback.print_exc()
                flash(f"Search error: {str(e)}", "error")
        else:
            # Fallback to mock data
            filters = parse_search_query(q)
            api_result = api.search_workspaces("")
            
            if api_result["success"]:
                all_results = api_result["data"]
                
                def matches(r):
                    if filters['trial'] or filters['vendor'] or filters['stream']:
                        is_token_search = (filters['trial'] and filters['vendor'] and filters['stream'])
                        trial_match = not filters['trial'] or any(f in r["trial"].upper() or r["trial"].upper() in f for f in filters['trial'])
                        vendor_match = not filters['vendor'] or any(f in r["vendor"].upper() or r["vendor"].upper() in f for f in filters['vendor'])
                        stream_match = not filters['stream'] or any(f.upper() in r["stream"].upper() or r["stream"].upper() in f.upper() for f in filters['stream'])
                        
                        if is_token_search:
                            return trial_match or vendor_match or stream_match
                        else:
                            return trial_match and vendor_match and stream_match
                    else:
                        q_lower = q.lower()
                        return (q_lower in r["trial"].lower() or 
                               q_lower in r["vendor"].lower() or 
                               q_lower in r["stream"].lower())
                
                results = [r for r in all_results if matches(r)]
    
    # Fetch user's draft DTAs
    try:
        user_drafts = get_user_drafts(limit=50)
        print(f"COMPOSER: Found {len(user_drafts)} user drafts")
    except Exception as e:
        print(f"COMPOSER: Error fetching drafts: {e}")
        user_drafts = []
    
    return render_template("composer.html", 
                          results=results, 
                          q=q,
                          action=action,
                          selected_libraries=selected_libraries,
                          library_display=library_display,
                          use_real_search=use_real_search,
                          user_drafts=user_drafts)

@app.route("/edit-draft/<dta_id>")
def edit_draft(dta_id):
    """
    Edit an existing draft DTA - loads data from Silver table.
    
    This function:
    1. Fetches DTA metadata from database
    2. Fetches transfer variables from Silver table using dta_id
    3. Populates workspace with real data and redirects
    """
    from api.dta_api import _get_db_config, _get_sql_client
    from api.data import WORKSPACES, EMPTY_ENTITIES, MOCK_RESULTS
    
    try:
        config = _get_db_config()
        client = _get_sql_client()
        
        catalog = config['catalog']
        gold_schema = config['gold_schema']
        silver_schema = config['silver_schema']
        dta_table = f"{catalog}.{gold_schema}.dta"
        silver_table = f"{catalog}.{silver_schema}.md_transfer_variable_field_normalized"
        
        # ========================================
        # Step 1: Get DTA metadata
        # ========================================
        print(f"EDIT-DRAFT: Loading draft DTA {dta_id}...")
        
        dta_query = f"""
            SELECT dta_id, dta_number, dta_name, trial_id, data_stream_type, data_provider_name,
                   status, workflow_state, current_version_tag, current_draft_version, notes,
                   last_updated_ts
            FROM {dta_table}
            WHERE dta_id = '{dta_id}'
        """
        
        dta_results = client.execute_query(dta_query, raise_on_error=True)
        
        if not dta_results:
            flash(f"Draft DTA {dta_id} not found", "error")
            return redirect(url_for("composer"))
        
        dta = dta_results[0]
        dta_number = dta.get("dta_number", "")
        dta_name = dta.get("dta_name", "")
        trial_id = dta.get("trial_id", "UNKNOWN")
        provider = dta.get("data_provider_name", "UNKNOWN")
        stream = dta.get("data_stream_type", "UNKNOWN")
        version_tag = dta.get("current_draft_version") or dta.get("current_version_tag", "")
        
        print(f"EDIT-DRAFT: Found DTA {dta_number}, version {version_tag}")
        
        # ========================================
        # Step 2: Fetch transfer variables from Silver table
        # ========================================
        print(f"EDIT-DRAFT: Fetching transfer variables from Silver table...")
        
        tv_query = f"""
            SELECT 
                transfer_variable_id,
                transfer_variable_name,
                transfer_variable_label,
                format,
                anticipated_max_length,
                populate_for_all_records,
                codelist_values,
                example_values,
                variable_description,
                transfer_file_key,
                transfer_variable_order,
                row_status,
                vendor_comment
            FROM {silver_table}
            WHERE dta_id = '{dta_id}'
            ORDER BY transfer_variable_order
        """
        
        tv_results = client.execute_query(tv_query, raise_on_error=True)
        print(f"EDIT-DRAFT: Found {len(tv_results) if tv_results else 0} transfer variables")
        
        # Transform to workspace format
        real_tv = []
        if tv_results:
            for i, row in enumerate(tv_results, 1):
                try:
                    length_val = row.get("anticipated_max_length")
                    length = int(length_val) if length_val else 50
                except (ValueError, TypeError):
                    length = 50
                
                file_order = row.get("transfer_variable_order") or i
                try:
                    file_order = int(file_order)
                except:
                    file_order = i
                
                # Handle boolean fields - SQL API returns strings
                required_val = row.get("populate_for_all_records")
                is_required = str(required_val).lower() == "true" if required_val else False
                
                is_key_val = row.get("transfer_file_key")
                is_key = str(is_key_val).lower() == "true" if is_key_val else False
                
                # Handle codelist_values array
                codelist_val = row.get("codelist_values")
                if codelist_val:
                    if isinstance(codelist_val, list):
                        codelist_str = ", ".join(str(v) for v in codelist_val if v)
                    else:
                        codelist_str = str(codelist_val)
                else:
                    codelist_str = ""
                
                real_tv.append({
                    "LABEL": str(row.get("transfer_variable_name") or row.get("transfer_variable_label") or ""),
                    "FILE_ORDER": file_order,
                    "FORMAT": str(row.get("format") or "STRING"),
                    "LENGTH": length,
                    "REQUIRED": is_required,
                    "TEST_CONCEPTS": codelist_str,
                    "EXAMPLE_VALUES": str(row.get("example_values") or ""),
                    "DESCRIPTION": str(row.get("variable_description") or ""),
                    "IS_KEY": is_key,
                    "ROW_STATUS": str(row.get("row_status") or "COMPLETED"),
                    "VENDOR_COMMENT": str(row.get("vendor_comment") or "")
                })
        
        if not real_tv:
            real_tv = list(EMPTY_ENTITIES["TV"])
            print(f"EDIT-DRAFT: No transfer variables found, using empty entities")
        
        # ========================================
        # Step 3: Create workspace with data
        # ========================================
        workspace_key = f"{trial_id}|{provider}|{stream}|{dta_id}"
        
        # Initialize CL state
        cl_state = {}
        for item in EMPTY_ENTITIES["CL"]:
            ref = item["ref"]
            if ref not in cl_state:
                cl_state[ref] = []
            cl_state[ref].append({"editable": False, "approved": False, "comments": []})
        
        # Extract transfer file keys
        transfer_file_keys = [tv["LABEL"] for tv in real_tv if tv.get("IS_KEY")]
        
        # Metadata fields
        metadata_fields = [
            {"field": "trial_id", "label": "Trial ID", "value": trial_id, "readonly": True},
            {"field": "vendor", "label": "Vendor", "value": provider, "readonly": True},
            {"field": "data_stream", "label": "Data Stream", "value": stream, "readonly": True},
            {"field": "dta_number", "label": "DTA Number", "value": dta_number, "readonly": True},
            {"field": "version_tag", "label": "Version", "value": version_tag, "readonly": True},
            {"field": "status", "label": "Status", "value": dta.get("status", "DRAFT"), "readonly": True},
            {"field": "notes", "label": "Notes", "value": dta.get("notes", "") or "", "readonly": False},
        ]
        
        # DIP fields
        dip_fields = [
            {"field": "protocol_version", "label": "Protocol Version", "value": "", "readonly": False},
            {"field": "vendor_contact", "label": "Vendor Contact", "value": "", "readonly": False},
            {"field": "jnj_contact", "label": "JNJ Contact", "value": "", "readonly": False},
        ]
        
        # Parse version info from database
        draft_display = version_tag if version_tag else f"DRAFT-{dta_id[:8]}"
        
        # Extract major version from version_tag if present (e.g., "v1.0" -> 1)
        base_major_version = 0
        if version_tag:
            import re
            major_match = re.search(r'v(\d+)', version_tag)
            if major_match:
                base_major_version = int(major_match.group(1))
        
        # Format last_updated_ts for display
        last_updated_ts = dta.get("last_updated_ts")
        if last_updated_ts:
            try:
                from datetime import datetime
                if isinstance(last_updated_ts, str):
                    last_updated_ts = datetime.fromisoformat(last_updated_ts.replace('Z', '+00:00'))
                last_updated_display = last_updated_ts.strftime("%b %d, %Y at %I:%M %p")
            except:
                last_updated_display = str(last_updated_ts)
        else:
            last_updated_display = None
        
        # Create workspace
        WORKSPACES[workspace_key] = {
            "key": workspace_key,
            "dta_id": dta_id,
            "dta_number": dta_number,
            "dta_name": dta_name,  # User-friendly name for UI display
            "version_tag": version_tag,
            "draft_id": draft_display,
            "base_major": base_major_version,
            "editor_tab": "META",
            "status": dta.get("status", "Draft"),
            "is_mock_data": False,  # Real data from Silver
            "has_pending_changes": False,  # Track unsaved changes
            "last_updated_ts": last_updated_display,  # For display in header
            "entities": {
                "TC": list(EMPTY_ENTITIES["TC"]),
                "TV": real_tv,
                "CL": list(EMPTY_ENTITIES["CL"]),
                "VT": list(EMPTY_ENTITIES["VT"])
            },
            "metadata": metadata_fields,
            "metadata_state": [{"editable": False, "approved": False, "comments": []} for _ in metadata_fields],
            "dip": dip_fields,
            "dip_state": [{"editable": False, "approved": False, "comments": []} for _ in dip_fields],
            "tc_state": [{"editable": False, "approved": False, "comments": []} for _ in EMPTY_ENTITIES["TC"]],
            "tv_state": [
                {
                    "editable": False, 
                    "approved": False, 
                    "comments": [{"user": "vendor", "ts": "saved", "text": tv.get("VENDOR_COMMENT")}] if tv.get("VENDOR_COMMENT") else []
                } for tv in real_tv
            ],
            "cl_state": cl_state,
            "transfer_file_keys": transfer_file_keys,
            "comments": [],
        }
        
        # Add to MOCK_RESULTS for workspace route compatibility
        mock_result = {
            "key": workspace_key,
            "dta_id": dta_id,
            "trial": trial_id,
            "vendor": provider,
            "stream": stream,
            "major": 0,
            "updated": datetime.now().strftime("%Y-%m-%d"),
            "owners": [],
            "badges": ["Transfer Variables"],
            "status": "Draft"
        }
        
        existing_idx = next((i for i, r in enumerate(MOCK_RESULTS) if r.get("key") == workspace_key), None)
        if existing_idx is not None:
            MOCK_RESULTS[existing_idx] = mock_result
        else:
            MOCK_RESULTS.insert(0, mock_result)
        
        # Preserve the tab query parameter if provided
        tab = request.args.get("tab", "TV")
        print(f"EDIT-DRAFT: Successfully loaded draft, redirecting to workspace (tab={tab})")
        return redirect(url_for("workspace", key=workspace_key, tab=tab))
        
    except Exception as e:
        print(f"EDIT-DRAFT: Error loading draft: {e}")
        import traceback
        traceback.print_exc()
        flash(f"Error loading draft: {str(e)}", "error")
        return redirect(url_for("composer"))


@app.route("/clone-dta/<dta_id>")
def clone_dta(dta_id):
    """
    Clone an existing DTA - creates a REAL draft in the database.
    
    This function:
    1. Fetches source DTA metadata from database
    2. Creates a new DTA draft using create_dta_complete() (with record copying)
    3. Fetches real transfer variables from the new draft's library version
    4. Populates workspace with real data and redirects
    """
    from api.dta_api import _get_db_config, _get_sql_client, create_dta_complete
    from api.data import WORKSPACES, EMPTY_ENTITIES, MOCK_RESULTS
    
    try:
        config = _get_db_config()
        client = _get_sql_client()
        
        catalog = config['catalog']
        gold_schema = config['gold_schema']
        dta_table = f"{catalog}.{gold_schema}.dta"
        # Note: Drafts are stored in Silver table, not Gold library table
        
        print(f"=" * 60)
        print(f"CLONE-DTA: Starting clone of DTA {dta_id}")
        print(f"=" * 60)
        
        # ========================================
        # Step 1: Fetch source DTA metadata
        # ========================================
        source_query = f"""
            SELECT 
                dta_id, dta_number, trial_id, data_stream_type, data_provider_name,
                current_version_tag, workflow_state, status, notes
            FROM {dta_table}
            WHERE dta_id = '{dta_id}'
        """
        
        source_results = client.execute_query(source_query)
        
        if not source_results:
            flash(f"Source DTA {dta_id} not found", "error")
            return redirect(url_for("composer"))
        
        source_dta = source_results[0]
        print(f"CLONE-DTA: Found source DTA {source_dta.get('dta_number')}")
        
        trial_id = source_dta.get("trial_id", "UNKNOWN")
        provider = source_dta.get("data_provider_name", "UNKNOWN")
        stream = source_dta.get("data_stream_type", "UNKNOWN")
        source_version = source_dta.get("current_version_tag")
        
        # ========================================
        # Step 2: Create NEW DTA draft in database
        # ========================================
        print(f"CLONE-DTA: Creating new DTA draft...")
        
        new_dta = create_dta_complete(
            trial_id=trial_id,
            data_stream_type=stream,
            data_provider_name=provider,
            created_by='ui_user@jnj.com',
            source_dta_id=dta_id,  # This triggers record copying!
            notes=f"Cloned from {source_dta.get('dta_number', dta_id)}"
        )
        
        new_dta_id = new_dta['dta_id']
        new_dta_number = new_dta['dta_number']
        new_version_tag = new_dta['version_tag']
        
        print(f"CLONE-DTA: Created {new_dta_number} with version {new_version_tag}")
        
        # ========================================
        # Step 3: Fetch REAL transfer variables from SILVER
        # ========================================
        # Drafts are stored in Silver table (md_transfer_variable_field_normalized)
        silver_table = f"{catalog}.silver_md.md_transfer_variable_field_normalized"
        
        print(f"CLONE-DTA: Fetching real transfer variables from Silver table...")
        print(f"  Table: {silver_table}")
        print(f"  DTA ID: {new_dta_id}")
        print(f"  Version Tag: {new_version_tag}")
        
        # Silver table column names (from nb_tsdta_transfer_variables_processor.ipynb):
        # transfer_variable_id, parent_document_id, dta_id, trial_id, 
        # data_stream_type, data_provider_name, transfer_variable_name,
        # codelist_values (ARRAY), transfer_variable_label, variable_description,
        # transfer_variable_order, format, anticipated_max_length,
        # populate_for_all_records, transfer_file_key, example_values,
        # definition_hash, categorization_notes, row_status,
        # version_tag, version_status, is_current_draft
        tv_query = f"""
            SELECT 
                transfer_variable_name,
                transfer_variable_label,
                format,
                anticipated_max_length,
                populate_for_all_records,
                codelist_values,
                example_values,
                variable_description,
                transfer_file_key,
                row_status,
                transfer_variable_order
            FROM {silver_table}
            WHERE dta_id = '{new_dta_id}' AND version_tag = '{new_version_tag}'
            ORDER BY transfer_variable_order, transfer_variable_name
        """
        
        print(f"CLONE-DTA: Executing query...")
        print(f"CLONE-DTA: Query: {tv_query[:200]}...")
        tv_results = client.execute_query(tv_query)
        print(f"CLONE-DTA: Found {len(tv_results) if tv_results else 0} transfer variables")
        
        # Transform to workspace format
        if tv_results and len(tv_results) > 0:
            real_tv = []
            for i, row in enumerate(tv_results, 1):
                # Safely convert anticipated_max_length to int (SQL may return strings)
                try:
                    length_val = row.get("anticipated_max_length")
                    length = int(length_val) if length_val else 50
                except (ValueError, TypeError):
                    length = 50
                
                # Safely get transfer_variable_order (may be int or string from SQL)
                try:
                    order_val = row.get("transfer_variable_order")
                    file_order = int(order_val) if order_val else i
                except (ValueError, TypeError):
                    file_order = i
                
                # Handle codelist_values which is an ARRAY in Silver table
                codelist_val = row.get("codelist_values")
                if codelist_val:
                    if isinstance(codelist_val, list):
                        codelist_str = ", ".join(str(v) for v in codelist_val if v)
                    else:
                        codelist_str = str(codelist_val)
                else:
                    codelist_str = ""
                
                # Handle boolean fields - SQL API returns strings "true"/"false"
                required_val = row.get("populate_for_all_records")
                is_required = str(required_val).lower() == "true" if required_val else False
                
                is_key_val = row.get("transfer_file_key")
                is_key = str(is_key_val).lower() == "true" if is_key_val else False
                
                real_tv.append({
                    "LABEL": str(row.get("transfer_variable_name") or row.get("transfer_variable_label") or ""),
                    "FILE_ORDER": file_order,
                    "FORMAT": str(row.get("format") or "STRING"),
                    "LENGTH": length,
                    "REQUIRED": is_required,
                    "TEST_CONCEPTS": codelist_str,
                    "EXAMPLE_VALUES": str(row.get("example_values") or ""),
                    "DESCRIPTION": str(row.get("variable_description") or ""),
                    "IS_KEY": is_key,
                    "ROW_STATUS": str(row.get("row_status") or "COMPLETED")
                })
        else:
            # Fallback to empty if no records (shouldn't happen if source has data)
            real_tv = list(EMPTY_ENTITIES["TV"])
            print(f"CLONE-DTA: Using fallback empty TV entities")
        
        # ========================================
        # Step 4: Create workspace with REAL data
        # ========================================
        # Use new DTA ID in workspace key to ensure uniqueness
        workspace_key = f"{trial_id}|{provider}|{stream}|{new_dta_id}"
        
        # Initialize CL state (empty for now - can be enhanced to fetch real codelists)
        cl_state = {}
        for item in EMPTY_ENTITIES["CL"]:
            ref = item["ref"]
            if ref not in cl_state:
                cl_state[ref] = []
            cl_state[ref].append({"editable": False, "approved": False, "comments": []})
        
        # Initialize metadata fields with real DTA data
        metadata_fields = [
            {"field": "trial_id", "label": "Trial ID", "value": trial_id, "readonly": True},
            {"field": "vendor_id", "label": "Vendor ID / Provider", "value": provider, "readonly": True},
            {"field": "data_stream", "label": "Data Stream", "value": stream, "readonly": True},
            {"field": "dta_number", "label": "DTA Number", "value": new_dta_number, "readonly": True},
            {"field": "version_tag", "label": "Version", "value": new_version_tag, "readonly": True},
            {"field": "source_dta", "label": "Cloned From", "value": source_dta.get("dta_number", dta_id), "readonly": True},
            {"field": "title", "label": "DTA Title", "value": f"Cloned from {source_dta.get('dta_number', dta_id)}", "readonly": False},
            {"field": "description", "label": "Description", "value": source_dta.get("notes") or "", "readonly": False},
            {"field": "protocol_version", "label": "Protocol Version", "value": "", "readonly": False},
            {"field": "vendor_contact", "label": "Vendor Contact", "value": "", "readonly": False},
            {"field": "jnj_contact", "label": "JNJ Contact", "value": "", "readonly": False},
        ]
        
        # Initialize DIP fields
        dip_fields = [
            {"field": "transfer_type", "label": "Type of Transfer", "value": "Cumulative", "readonly": False},
            {"field": "blinding", "label": "Blinding of Data", "value": "", "readonly": False},
            {"field": "frequency", "label": "Frequency of Transfer", "value": "", "readonly": False},
            {"field": "transfer_day", "label": "Transfer Day", "value": "", "readonly": False},
            {"field": "file_format", "label": "Transfer File Format", "value": "CSV", "readonly": False},
        ]
        
        # Extract transfer file keys from real TV data
        transfer_file_keys = [tv["LABEL"] for tv in real_tv if tv.get("IS_KEY")]
        
        # Create the workspace with REAL data
        WORKSPACES[workspace_key] = {
            "key": workspace_key,
            "dta_id": new_dta_id,
            "dta_number": new_dta_number,
            "version_tag": new_version_tag,
            "draft_id": f"DRAFT-{new_dta_id[:8]}",
            "base_major": 0,
            "editor_tab": "META",
            "status": "Draft",
            "is_mock_data": False,  # Real data - cloned from database
            "has_pending_changes": False,  # Track unsaved changes
            "last_updated_ts": None,  # New clone - not yet saved
            "source_dta_id": dta_id,
            "source_dta_number": source_dta.get("dta_number"),
            "entities": {
                "TC": list(EMPTY_ENTITIES["TC"]),  # TODO: Fetch real TC
                "TV": real_tv,  # REAL transfer variables!
                "CL": list(EMPTY_ENTITIES["CL"]),  # TODO: Fetch real CL
                "VT": list(EMPTY_ENTITIES["VT"])   # TODO: Fetch real VT
            },
            "metadata": metadata_fields,
            "metadata_state": [{"editable": False, "approved": False, "comments": []} for _ in metadata_fields],
            "dip": dip_fields,
            "dip_state": [{"editable": False, "approved": False, "comments": []} for _ in dip_fields],
            "tc_state": [{"editable": False, "approved": False, "comments": []} for _ in EMPTY_ENTITIES["TC"]],
            "tv_state": [{"editable": False, "approved": False, "comments": []} for _ in real_tv],
            "cl_state": cl_state,
            "transfer_file_keys": transfer_file_keys,
            "comments": [],
        }
        
        # Add to MOCK_RESULTS so workspace route can find it
        mock_result = {
            "key": workspace_key,
            "dta_id": new_dta_id,
            "trial": trial_id,
            "vendor": provider,
            "stream": stream,
            "major": 0,
            "updated": datetime.now().strftime("%Y-%m-%d"),
            "owners": [],
            "badges": ["Transfer Variables"],
            "status": "Draft"
        }
        MOCK_RESULTS.append(mock_result)
        
        print(f"=" * 60)
        print(f"CLONE-DTA: SUCCESS!")
        print(f"  New DTA: {new_dta_number} ({new_dta_id})")
        print(f"  Version: {new_version_tag}")
        print(f"  Transfer Variables: {len(real_tv)}")
        print(f"  Workspace Key: {workspace_key}")
        print(f"=" * 60)
        
        flash(f"Created draft {new_dta_number} with {len(real_tv)} transfer variables", "success")
        # Redirect to assign approvers page before workspace
        return redirect(url_for("assign_approvers", dta_id=new_dta_id))
        
    except Exception as e:
        import traceback
        print(f"CLONE-DTA ERROR: {e}")
        traceback.print_exc()
        flash(f"Error cloning DTA: {str(e)}", "error")
        return redirect(url_for("composer"))


@app.route("/workspace/<path:key>")
def workspace(key):
    res = next((r for r in MOCK_RESULTS if r["key"] == key), None)
    if not res:
        flash("DTA not found", "error")
        return redirect(url_for("composer"))
    ws = data.get_or_create_workspace(res)
    
    # Check if DTA is in Pending Approval or Approved state
    if ws.get("status") in ["Pending Approval", "Approved"]:
        # Both pending and approved DTAs use the approval_detail view
        # The view will show different buttons based on status
        return redirect(url_for("approval_detail", key=key))

    allowed_tabs = ["META","TV","TC","CL","VT","DIP"]  # VT and DIP are last two tabs
    tab = request.args.get("tab") or ws.get("editor_tab") or "META"
    if tab not in allowed_tabs:
        tab = "VT"
    ws["editor_tab"] = tab

    data._ensure_tv_init(ws)
    print(f"DBG tv_selected: {ws.get('tv_selected')}")
    print(f"DBG tv_state: {ws.get('tv_state')}")
    print(f"DBG TV entities count: {len(ws.get('entities', {}).get('TV', []))}")
    
    # Group codelists by reference for CL tab
    cl_grouped = data.group_codelists_by_ref(ws.get('entities', {}).get('CL', []))
    
    return render_template("workspace.html",
                           ws=ws,
                           current_tab=tab,
                           allowed_tabs=allowed_tabs,
                           label_for_tab=label_for_tab,
                           cl_grouped=cl_grouped)

@app.route("/api/workspace/<path:key>/save", methods=["POST"])
def api_save(key):
    """Save the current workspace draft to the database."""
    from api.dta_api import _get_db_config, _get_sql_client
    from datetime import datetime
    
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    dta_id = ws.get("dta_id")
    
    # If no dta_id, this is mock data - just save in memory
    if not dta_id or ws.get("is_mock_data", True):
        return jsonify({"ok": True, "msg": f"Draft {ws.get('draft_id', 'DRAFT')} saved (in-memory only - mock data)."})
    
    try:
        config = _get_db_config()
        client = _get_sql_client()
        
        catalog = config['catalog']
        gold_schema = config['gold_schema']
        silver_schema = config['silver_schema']
        silver_table = f"{catalog}.{silver_schema}.md_transfer_variable_field_normalized"
        dta_table = f"{catalog}.{gold_schema}.dta"
        
        # Get transfer variables from workspace
        tv_entities = ws.get("entities", {}).get("TV", [])
        
        print(f"SAVE: Starting save for DTA {dta_id} with {len(tv_entities)} transfer variables")
        
        # ========================================
        # Step 1: Fetch current DB values for change detection
        # ========================================
        current_db_values = {}
        try:
            fetch_query = f"""
                SELECT transfer_variable_order, transfer_variable_name, format, 
                       anticipated_max_length, populate_for_all_records, variable_description,
                       transfer_file_key, vendor_comment
                FROM {silver_table}
                WHERE dta_id = '{dta_id}'
            """
            db_results = client.execute_query(fetch_query, raise_on_error=True)
            for row in db_results or []:
                order = row.get('transfer_variable_order')
                if order:
                    current_db_values[int(order)] = {
                        'name': str(row.get('transfer_variable_name') or ''),
                        'format': str(row.get('format') or 'STRING'),
                        'length': int(row.get('anticipated_max_length') or 50),
                        'required': str(row.get('populate_for_all_records')).lower() == 'true',
                        'description': str(row.get('variable_description') or ''),
                        'is_key': str(row.get('transfer_file_key')).lower() == 'true',
                        'vendor_comment': str(row.get('vendor_comment') or '')
                    }
            print(f"SAVE: Fetched {len(current_db_values)} existing records from DB")
        except Exception as fetch_error:
            print(f"SAVE: Could not fetch current values, will update all: {fetch_error}")
        
        # ========================================
        # Step 2: Detect changed rows and log field-level changes
        # ========================================
        from api.activity_log_api import log_field_update
        
        updated_count = 0
        field_changes = []  # Track all field-level changes for activity log
        
        if tv_entities:
            # Build VALUES clause for only changed TV records
            values_rows = []
            for tv in tv_entities:
                file_order = tv.get("FILE_ORDER", 0)
                if not file_order:
                    continue
                    
                # Get values (unescaped for comparison)
                label = (tv.get("LABEL", "") or "")
                format_val = (tv.get("FORMAT", "STRING") or "STRING")
                length = tv.get("LENGTH", 50) or 50
                required_bool = tv.get("REQUIRED", False)
                required = str(required_bool).lower()
                description = (tv.get("DESCRIPTION", "") or "")
                is_key_bool = tv.get("IS_KEY", False)
                is_key = str(is_key_bool).lower()
                vendor_comment = (tv.get("VENDOR_COMMENT", "") or "")
                
                # Check if this row has changed compared to DB
                db_row = current_db_values.get(int(file_order))
                row_has_changes = False
                
                if db_row:
                    # Compare each field and track changes
                    if label != db_row['name']:
                        field_changes.append({
                            'entity_id': str(file_order),
                            'entity_name': label or db_row['name'],
                            'field': 'name',
                            'old': db_row['name'],
                            'new': label
                        })
                        row_has_changes = True
                    
                    if format_val != db_row['format']:
                        field_changes.append({
                            'entity_id': str(file_order),
                            'entity_name': label or db_row['name'],
                            'field': 'format',
                            'old': db_row['format'],
                            'new': format_val
                        })
                        row_has_changes = True
                    
                    if length != db_row['length']:
                        field_changes.append({
                            'entity_id': str(file_order),
                            'entity_name': label or db_row['name'],
                            'field': 'length',
                            'old': str(db_row['length']),
                            'new': str(length)
                        })
                        row_has_changes = True
                    
                    if required_bool != db_row['required']:
                        field_changes.append({
                            'entity_id': str(file_order),
                            'entity_name': label or db_row['name'],
                            'field': 'required',
                            'old': str(db_row['required']),
                            'new': str(required_bool)
                        })
                        row_has_changes = True
                    
                    if description != db_row['description']:
                        field_changes.append({
                            'entity_id': str(file_order),
                            'entity_name': label or db_row['name'],
                            'field': 'description',
                            'old': db_row['description'][:50] if db_row['description'] else '',
                            'new': description[:50] if description else ''
                        })
                        row_has_changes = True
                    
                    if is_key_bool != db_row.get('is_key', False):
                        field_changes.append({
                            'entity_id': str(file_order),
                            'entity_name': label or db_row['name'],
                            'field': 'is_key',
                            'old': str(db_row.get('is_key', False)),
                            'new': str(is_key_bool)
                        })
                        row_has_changes = True
                    
                    if vendor_comment != db_row.get('vendor_comment', ''):
                        field_changes.append({
                            'entity_id': str(file_order),
                            'entity_name': label or db_row['name'],
                            'field': 'vendor_comment',
                            'old': db_row.get('vendor_comment', ''),
                            'new': vendor_comment
                        })
                        row_has_changes = True
                    
                    if not row_has_changes:
                        continue  # Skip unchanged rows
                else:
                    # New row - this is an INSERT
                    row_has_changes = True
                
                # Escape for SQL
                label_escaped = label.replace("'", "''")
                format_escaped = format_val.replace("'", "''")
                desc_escaped = description.replace("'", "''")
                comment_escaped = vendor_comment.replace("'", "''")
                
                values_rows.append(f"('{dta_id}', {file_order}, '{label_escaped}', '{format_escaped}', {length}, {required}, '{desc_escaped}', {is_key}, '{comment_escaped}')")
            
            print(f"SAVE: Detected {len(values_rows)} changed records out of {len(tv_entities)} total")
            
            if values_rows:
                values_clause = ",\n                ".join(values_rows)
                
                merge_query = f"""
                    MERGE INTO {silver_table} AS target
                    USING (
                        SELECT * FROM (
                            VALUES
                                {values_clause}
                        ) AS source(dta_id, transfer_variable_order, transfer_variable_name, format, anticipated_max_length, populate_for_all_records, variable_description, transfer_file_key, vendor_comment)
                    ) AS source
                    ON target.dta_id = source.dta_id AND target.transfer_variable_order = source.transfer_variable_order
                    WHEN MATCHED THEN
                        UPDATE SET
                            target.transfer_variable_name = source.transfer_variable_name,
                            target.format = source.format,
                            target.anticipated_max_length = source.anticipated_max_length,
                            target.populate_for_all_records = source.populate_for_all_records,
                            target.variable_description = source.variable_description,
                            target.transfer_file_key = source.transfer_file_key,
                            target.vendor_comment = source.vendor_comment,
                            target.last_updated_ts = current_timestamp(),
                            target.last_updated_by_principal = current_user()
                """
                
                try:
                    print(f"SAVE: Executing batch MERGE for {len(values_rows)} transfer variables...")
                    client.execute_query(merge_query, raise_on_error=True)
                    updated_count = len(values_rows)
                    print(f"SAVE: Batch MERGE completed - {updated_count} records")
                    
                    # ========================================
                    # Step 2b: Log field-level changes to activity log
                    # ========================================
                    if field_changes:
                        print(f"SAVE: Logging {len(field_changes)} field changes to activity log...")
                        current_user = "app_user"  # Default
                        try:
                            user_result = client.execute_query("SELECT current_user() as user")
                            if user_result:
                                current_user = user_result[0].get('user', 'app_user')
                        except:
                            pass
                        
                        for change in field_changes:
                            try:
                                log_field_update(
                                    dta_id=dta_id,
                                    library_type="transfer_variables",
                                    entity_id=change['entity_id'],
                                    entity_name=change['entity_name'],
                                    field_name=change['field'],
                                    old_value=change['old'],
                                    new_value=change['new'],
                                    performed_by=current_user
                                )
                            except Exception as log_err:
                                print(f"Warning: Failed to log change: {log_err}")
                        
                        print(f"SAVE: Activity log updated")
                        
                except Exception as merge_error:
                    print(f"SAVE ERROR: Batch MERGE failed: {merge_error}")
                    import traceback
                    traceback.print_exc()
                    return jsonify({"ok": False, "msg": f"Failed to save transfer variables: {str(merge_error)}"}), 500
        
        # ========================================
        # Step 2: Update DTA's last_updated_ts
        # ========================================
        dta_update_query = f"""
            UPDATE {dta_table}
            SET last_updated_ts = current_timestamp(),
                last_updated_by_principal = current_user()
            WHERE dta_id = '{dta_id}'
        """
        try:
            client.execute_query(dta_update_query, raise_on_error=True)
            print(f"SAVE: Updated DTA timestamp")
        except Exception as dta_error:
            print(f"Warning: Could not update DTA timestamp: {dta_error}")
        
        # Clear pending changes flag and remove workspace (will be reloaded fresh)
        ws["has_pending_changes"] = False
        
        # Remove from workspaces so edit_draft will reload fresh from DB
        if key in WORKSPACES:
            del WORKSPACES[key]
        
        print(f"SAVE: Draft saved successfully for DTA {dta_id}")
        return jsonify({"ok": True, "msg": f"Draft saved successfully. Updated {updated_count} records.", "dta_id": dta_id})
        
    except Exception as e:
        print(f"SAVE ERROR: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"ok": False, "msg": f"Error saving draft: {str(e)}"}), 500

@app.route("/api/history/<dta_id>", methods=["GET"])
def get_history(dta_id):
    """Get complete activity history for a DTA from the activity log."""
    from api.activity_log_api import get_activity_history
    
    try:
        result = get_activity_history(dta_id)
        return jsonify(result)
        
    except Exception as e:
        print(f"HISTORY ERROR: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'ok': False, 'msg': str(e)}), 500

@app.route("/api/approvers", methods=["GET"])
def get_approvers():
    """Return list of available approvers for each role"""
    approvers = {
        "jnj_dae": [
            {"id": "jnj_1", "name": "Sarah Johnson", "title": "DAE Lead", "email": "sarah.johnson@jnj.com"},
            {"id": "jnj_2", "name": "Michael Chen", "title": "Senior DAE", "email": "michael.chen@jnj.com"},
            {"id": "jnj_3", "name": "Emily Rodriguez", "title": "DAE Manager", "email": "emily.rodriguez@jnj.com"}
        ],
        "vendor": [
            {"id": "vnd_1", "name": "Alex Kumar", "title": "Data Manager", "email": "alex.kumar@vendor.com"},
            {"id": "vnd_2", "name": "David Park", "title": "Senior Data Scientist", "email": "david.park@vendor.com"},
            {"id": "vnd_3", "name": "Jennifer Lee", "title": "QC Lead", "email": "jennifer.lee@vendor.com"}
        ],
        "librarian": [
            {"id": "lib_1", "name": "Lisa Wong", "title": "Study Librarian", "email": "lisa.wong@jnj.com"},
            {"id": "lib_2", "name": "Robert Martinez", "title": "Senior Librarian", "email": "robert.martinez@jnj.com"},
            {"id": "lib_3", "name": "Patricia Taylor", "title": "Data Librarian", "email": "patricia.taylor@jnj.com"}
        ]
    }
    return jsonify({"success": True, "approvers": approvers})

@app.route("/api/workspace/<path:key>/submit", methods=["POST"])
def api_submit(key):
    # Get request data
    request_data = request.get_json() or {}
    approvers_list = request_data.get("approvers", [])
    
    # Call API to submit for approval
    result = api.submit_for_approval(key, approvers_list)
    
    if result["success"]:
        return jsonify({"success": True, "msg": result.get("message", "Submitted for approval.")})
    else:
        return jsonify({"ok": False, "msg": result.get("error", "Submission failed")}), 404

@app.route("/api/workspace/<path:key>/publish", methods=["POST"])
def api_publish(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    next_major = ws["base_major"] + 1
    return jsonify({
        "ok": True,
        "msg": f"Publishing Major v{next_major} (simulated). Prior is_current=false, SCD2 rows written."
    })

@app.route("/api/workspace/<path:key>/comment", methods=["POST"])
def api_comment(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    text = (request.json or {}).get("text", "").strip()
    if not text:
        return jsonify({"ok": False, "msg": "empty comment"}), 400
    ws["comments"].append({
        "text": text,
        "user": "you@jnj.com",
        "ts": datetime.utcnow().isoformat()
    })
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/entity/<tab>/<int:idx>/<col>", methods=["POST"])
def api_update_cell(key, tab, idx, col):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    value = (request.json or {}).get("value")
    try:
        ws["entities"][tab][idx][col] = value
        # Mark workspace as having pending changes
        ws["has_pending_changes"] = True
    except Exception:
        return jsonify({"ok": False, "msg": "bad index/column"}), 400
    return jsonify({"ok": True})

def label_for_tab(t):
    return {
        "VT": "Visit and Timepoints",
        "DIP": "Data Ingestion Parameters",
        "TV": "Transfer Variables",
        "CL": "Code Lists",
        "TC": "Test Concepts",
        "META": "Metadata",
    }.get(t, t)

# === TC (Test Concepts) endpoints ===

@app.route("/api/workspace/<path:key>/tc/<int:idx>/edit", methods=["POST"])
def api_tc_edit(key, idx):
    import copy
    ws = WORKSPACES.get(key)
    if not ws: 
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    try:
        # Store original values for cancel/restore
        ws["tc_state"][idx]["original_values"] = copy.deepcopy(ws["entities"]["TC"][idx])
        ws["tc_state"][idx]["editable"] = True
        ws["tc_state"][idx]["approved"] = False  # editing resets approval
        # Mark as having pending changes when entering edit mode
        ws["has_pending_changes"] = True
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tc/<int:idx>/save", methods=["POST"])
def api_tc_save(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    try:
        # Clear the original values backup (changes are now permanent)
        ws["tc_state"][idx].pop("original_values", None)
        ws["tc_state"][idx]["editable"] = False
        # Mark workspace as having pending changes (needs Save Draft to persist to DB)
        ws["has_pending_changes"] = True
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tc/<int:idx>/cancel", methods=["POST"])
def api_tc_cancel(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    try:
        # Restore original values if they exist
        original = ws["tc_state"][idx].get("original_values")
        if original:
            ws["entities"]["TC"][idx] = original
            ws["tc_state"][idx].pop("original_values", None)
        ws["tc_state"][idx]["editable"] = False
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tc/<int:idx>/approve", methods=["POST"])
def api_tc_approve(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    try:
        ws["tc_state"][idx]["approved"] = True
        ws["tc_state"][idx]["editable"] = False
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tc/<int:idx>/comment", methods=["POST"])
def api_tc_comment(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    payload = request.json or {}
    text = (payload.get("text") or "").strip()
    if not text:
        return jsonify({"ok": False, "msg": "empty comment"}), 400
    try:
        ws["tc_state"][idx]["comments"].insert(0, {
            "user": payload.get("user") or "vendor@example.com",
            "ts": datetime.utcnow().isoformat(),
            "text": text
        })
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

# === Transfer Variables (TV) endpoints ===

@app.route("/api/workspace/<path:key>/tv/select/<int:idx>", methods=["POST"])
def api_tv_select(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    ws["tv_selected"] = idx
    return jsonify({"ok": True, "selected": idx})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/update", methods=["POST"])
def api_tv_update(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    payload = request.json or {}
    for k in ["FILE_ORDER","FORMAT","LENGTH","REQUIRED","IS_KEY","TEST_CONCEPTS","EXAMPLE_VALUES"]:
        if k in payload:
            ws["entities"]["TV"][idx][k] = payload[k]
    return jsonify({"ok": True, "row": ws["entities"]["TV"][idx]})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/edit", methods=["POST"])
def api_tv_edit(key, idx):
    import copy
    print(f"API tv_edit called: key={key}, idx={idx}")
    ws = WORKSPACES.get(key)
    if not ws:
        print(f"Workspace not found: {key}")
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    print(f"TV state before edit: {ws.get('tv_state')}")
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        print(f"Bad index: {idx}, TV length: {len(ws['entities']['TV'])}")
        return jsonify({"ok": False, "msg": "bad index"}), 400
    
    # Store original values for cancel/restore
    ws["tv_state"][idx]["original_values"] = copy.deepcopy(ws["entities"]["TV"][idx])
    ws["tv_state"][idx]["editable"] = True
    ws["tv_state"][idx]["approved"] = False  # editing resets approval
    # Mark as having pending changes when entering edit mode
    ws["has_pending_changes"] = True
    print(f"TV state after edit: {ws['tv_state'][idx]}")
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/save", methods=["POST"])
def api_tv_save(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    # Clear the original values backup (changes are now permanent)
    ws["tv_state"][idx].pop("original_values", None)
    ws["tv_state"][idx]["editable"] = False
    # Mark workspace as having pending changes (needs Save Draft to persist to DB)
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/cancel", methods=["POST"])
def api_tv_cancel(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    
    # Restore original values if they exist
    original = ws["tv_state"][idx].get("original_values")
    if original:
        ws["entities"]["TV"][idx] = original
        ws["tv_state"][idx].pop("original_values", None)
    
    ws["tv_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/delete", methods=["POST"])
def api_tv_delete(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    # Delete the row from entities and state
    ws["entities"]["TV"].pop(idx)
    ws["tv_state"].pop(idx)
    return jsonify({"ok": True, "count": len(ws["entities"]["TV"])})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/approve", methods=["POST"])
def api_tv_approve(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    ws["tv_state"][idx]["approved"] = True
    ws["tv_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/comment", methods=["POST"])
def api_tv_comment(key, idx):
    """Update vendor comment in-memory. Save Draft will persist to DB."""
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    
    payload = request.json or {}
    text = (payload.get("text") or "").strip()
    # Allow empty text (to clear comment)
    
    # Update in-memory entity
    tv_row = ws["entities"]["TV"][idx]
    tv_row["VENDOR_COMMENT"] = text
    
    # Mark as having pending changes
    ws["has_pending_changes"] = True
    
    print(f"  ✓ Vendor comment updated in-memory for row {idx}: {text[:50] if text else '(cleared)'}...")
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/add", methods=["POST"])
def api_tv_add(key):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    new_idx = len(ws["entities"]["TV"]) + 1
    row = {
        "LABEL": "",  # Empty for user to fill
        "FILE_ORDER": new_idx,
        "FORMAT": "",
        "LENGTH": 0,
        "REQUIRED": False,
        "TEST_CONCEPTS": "",
        "EXAMPLE_VALUES": ""
    }
    ws["entities"]["TV"].append(row)
    ws["tv_state"].append({"approved": False, "editable": True, "comments": []})  # New row is editable
    ws["tv_selected"] = new_idx - 1
    return jsonify({"ok": True, "index": ws["tv_selected"], "row": row})

@app.route("/api/workspace/<path:key>/tc/add", methods=["POST"])
def api_tc_add(key):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    # Get the first row to determine column structure
    if not ws.get("entities", {}).get("TC"):
        return jsonify({"ok": False, "msg": "No TC data exists"}), 400
    
    # Create a blank row with all columns set to empty strings
    first_row = ws["entities"]["TC"][0]
    row = {key: "" for key in first_row.keys()}
    
    ws["entities"]["TC"].append(row)
    
    # Initialize tc_state if it doesn't exist
    if "tc_state" not in ws:
        ws["tc_state"] = []
    
    # Add state for the new row - set as editable by default
    ws["tc_state"].append({"approved": False, "editable": True, "comments": []})
    
    return jsonify({"ok": True, "index": len(ws["entities"]["TC"]) - 1, "row": row})

# === Code Lists (CL) endpoints ===

def _get_cl_item_by_ref_idx(cl_list, ref, idx):
    """Get the idx-th item with given ref from CL list."""
    matching = [item for item in cl_list if item["ref"] == ref]
    if idx < 0 or idx >= len(matching):
        return None
    # Find the global index in cl_list
    count = 0
    for i, item in enumerate(cl_list):
        if item["ref"] == ref:
            if count == idx:
                return i, item
            count += 1
    return None

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/edit", methods=["POST"])
def api_cl_edit(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if ref not in ws.get("cl_state", {}):
        return jsonify({"ok": False, "msg": "reference not found"}), 404
    
    if idx < 0 or idx >= len(ws["cl_state"][ref]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["cl_state"][ref][idx]["editable"] = True
    # Mark as having pending changes when entering edit mode
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/save", methods=["POST"])
def api_cl_save(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    code = payload.get("code", "")
    text = payload.get("text", "")
    
    result = _get_cl_item_by_ref_idx(ws.get("entities", {}).get("CL", []), ref, idx)
    if result is None:
        return jsonify({"ok": False, "msg": "code not found"}), 404
    
    global_idx, item = result
    item["code"] = code
    item["text"] = text
    
    ws["cl_state"][ref][idx]["editable"] = False
    # Mark workspace as having pending changes (needs Save Draft to persist to DB)
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/cancel", methods=["POST"])
def api_cl_cancel(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if ref not in ws.get("cl_state", {}):
        return jsonify({"ok": False, "msg": "reference not found"}), 404
    
    if idx < 0 or idx >= len(ws["cl_state"][ref]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Simply set editable to false without saving changes
    ws["cl_state"][ref][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/approve", methods=["POST"])
def api_cl_approve(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if ref not in ws.get("cl_state", {}):
        return jsonify({"ok": False, "msg": "reference not found"}), 404
    
    if idx < 0 or idx >= len(ws["cl_state"][ref]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["cl_state"][ref][idx]["approved"] = True
    ws["cl_state"][ref][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/comment", methods=["POST"])
def api_cl_comment(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    text = payload.get("text", "")
    
    if not text:
        return jsonify({"ok": False, "msg": "comment text required"}), 400
    
    if ref not in ws.get("cl_state", {}):
        return jsonify({"ok": False, "msg": "reference not found"}), 404
    
    if idx < 0 or idx >= len(ws["cl_state"][ref]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    comment = {
        "user": "You",
        "ts": datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
        "text": text
    }
    ws["cl_state"][ref][idx]["comments"].append(comment)
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/add", methods=["POST"])
def api_cl_add(key, ref):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    cl_list = ws.get("entities", {}).get("CL", [])
    
    # Add new blank code entry
    new_item = {"ref": ref, "code": "", "text": ""}
    cl_list.append(new_item)
    
    # Initialize state for the new code
    if ref not in ws.get("cl_state", {}):
        ws["cl_state"][ref] = []
    
    ws["cl_state"][ref].append({"editable": True, "approved": False, "comments": []})
    
    return jsonify({"ok": True})


# === Transfer File Keys endpoints ===

@app.route("/api/workspace/<path:key>/transfer-keys/add", methods=["POST"])
def api_add_transfer_key(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    variable = payload.get("variable", "").strip()
    
    if not variable:
        return jsonify({"ok": False, "msg": "variable name is required"}), 400
    
    # Initialize transfer_file_keys if it doesn't exist
    if "transfer_file_keys" not in ws:
        ws["transfer_file_keys"] = []
    
    # Check if variable already exists in keys
    if variable in ws["transfer_file_keys"]:
        return jsonify({"ok": False, "msg": "variable already in keys"}), 400
    
    # Verify the variable exists in TV entities
    tv_labels = [row.get("LABEL", "") for row in ws.get("entities", {}).get("TV", [])]
    if variable not in tv_labels:
        return jsonify({"ok": False, "msg": "variable not found in Transfer Variables"}), 400
    
    ws["transfer_file_keys"].append(variable)
    return jsonify({"ok": True, "keys": ws["transfer_file_keys"]})

@app.route("/api/workspace/<path:key>/transfer-keys/remove", methods=["POST"])
def api_remove_transfer_key(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    variable = payload.get("variable", "").strip()
    
    if not variable:
        return jsonify({"ok": False, "msg": "variable name is required"}), 400
    
    # Initialize transfer_file_keys if it doesn't exist
    if "transfer_file_keys" not in ws:
        ws["transfer_file_keys"] = []
    
    # Remove the variable if it exists
    if variable in ws["transfer_file_keys"]:
        ws["transfer_file_keys"].remove(variable)
        return jsonify({"ok": True, "keys": ws["transfer_file_keys"]})
    else:
        return jsonify({"ok": False, "msg": "variable not found in keys"}), 404

# === Metadata endpoints ===
@app.route("/api/workspace/<path:key>/meta/<int:idx>/edit", methods=["POST"])
def api_meta_edit(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata_state" not in ws or idx < 0 or idx >= len(ws["metadata_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Store original value for cancel/restore
    ws["metadata_state"][idx]["original_value"] = ws["metadata"][idx].get("value", "")
    ws["metadata_state"][idx]["editable"] = True
    # Mark as having pending changes when entering edit mode
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/meta/<int:idx>/save", methods=["POST"])
def api_meta_save(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata" not in ws or idx < 0 or idx >= len(ws["metadata"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    data = request.json or {}
    value = data.get("value", "")
    
    # Update the metadata value and clear backup
    ws["metadata"][idx]["value"] = value
    ws["metadata_state"][idx].pop("original_value", None)
    ws["metadata_state"][idx]["editable"] = False
    # Mark workspace as having pending changes (needs Save Draft to persist to DB)
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/meta/<int:idx>/cancel", methods=["POST"])
def api_meta_cancel(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata_state" not in ws or idx < 0 or idx >= len(ws["metadata_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Restore original value if it exists
    original = ws["metadata_state"][idx].get("original_value")
    if original is not None:
        ws["metadata"][idx]["value"] = original
        ws["metadata_state"][idx].pop("original_value", None)
    
    ws["metadata_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/meta/<int:idx>/approve", methods=["POST"])
def api_meta_approve(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata_state" not in ws or idx < 0 or idx >= len(ws["metadata_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["metadata_state"][idx]["approved"] = True
    ws["metadata_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/meta/<int:idx>/comment", methods=["POST"])
def api_meta_comment(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata_state" not in ws or idx < 0 or idx >= len(ws["metadata_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    data = request.json or {}
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"ok": False, "msg": "empty comment"}), 400
    
    comment = {
        "user": "Current User",
        "ts": datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
        "text": text
    }
    ws["metadata_state"][idx]["comments"].append(comment)
    return jsonify({"ok": True})

# === DIP (Data Ingestion Parameters) endpoints ===
@app.route("/api/workspace/<path:key>/dip/<int:idx>/edit", methods=["POST"])
def api_dip_edit(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip_state" not in ws or idx < 0 or idx >= len(ws["dip_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Store original value for cancel/restore
    ws["dip_state"][idx]["original_value"] = ws["dip"][idx].get("value", "")
    ws["dip_state"][idx]["editable"] = True
    # Mark as having pending changes when entering edit mode
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/dip/<int:idx>/save", methods=["POST"])
def api_dip_save(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip" not in ws or idx < 0 or idx >= len(ws["dip"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    data = request.json or {}
    value = data.get("value", "")
    
    # Update the dip value and clear backup
    ws["dip"][idx]["value"] = value
    ws["dip_state"][idx].pop("original_value", None)
    ws["dip_state"][idx]["editable"] = False
    # Mark workspace as having pending changes (needs Save Draft to persist to DB)
    ws["has_pending_changes"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/dip/<int:idx>/cancel", methods=["POST"])
def api_dip_cancel(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip_state" not in ws or idx < 0 or idx >= len(ws["dip_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Restore original value if it exists
    original = ws["dip_state"][idx].get("original_value")
    if original is not None:
        ws["dip"][idx]["value"] = original
        ws["dip_state"][idx].pop("original_value", None)
    
    ws["dip_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/dip/<int:idx>/approve", methods=["POST"])
def api_dip_approve(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip_state" not in ws or idx < 0 or idx >= len(ws["dip_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["dip_state"][idx]["approved"] = True
    ws["dip_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/dip/<int:idx>/comment", methods=["POST"])
def api_dip_comment(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip_state" not in ws or idx < 0 or idx >= len(ws["dip_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    data = request.json or {}
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"ok": False, "msg": "empty comment"}), 400
    
    comment = {
        "user": "Current User",
        "ts": datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
        "text": text
    }
    ws["dip_state"][idx]["comments"].append(comment)
    return jsonify({"ok": True})

# === Export and Publish Endpoints ===

@app.route("/api/workspace/<path:key>/export", methods=["POST"])
def api_export_dta(key):
    """Trigger Databricks job to export DTA configuration"""
    # Call API to create export job
    result = api.create_export_job(key)
    
    if result["success"]:
        job_data = result["data"]
        return jsonify({
            "success": True, 
            "job_id": job_data["job_id"],
            "run_id": job_data["run_id"],
            "msg": result.get("message", "Export job triggered successfully")
        })
    else:
        return jsonify({"success": False, "msg": result.get("error", "Export failed")}), 400

@app.route("/api/workspace/<path:key>/publish-major", methods=["POST"])
def api_publish_major(key):
    """Publish approved DTA as a new major version"""
    # Call API to publish major version
    result = api.publish_major_version(key)
    
    if result["success"]:
        version_data = result["data"]
        return jsonify({
            "success": True,
            "msg": result.get("message", "DTA published"),
            "new_major_version": version_data["new_major_version"],
            "published_at": version_data["published_at"]
        })
    else:
        return jsonify({"success": False, "msg": result.get("error", "Publish failed")}), 400

# === Start the Flask app ===

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)

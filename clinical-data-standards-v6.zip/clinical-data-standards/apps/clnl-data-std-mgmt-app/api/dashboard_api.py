"""
Dashboard API - Provides data for the main dashboard view.
Integrates with Databricks SQL to fetch real version data from md_version_registry.
"""

from flask import Blueprint, jsonify
from datetime import datetime, timedelta
import random
import os

# Import SQL client for database queries
from api.databricks_client import DatabricksSQLClient

dashboard_bp = Blueprint('dashboard_api', __name__, url_prefix='/api/dashboard')


# ============================================================================
# DATABASE CONFIGURATION
# ============================================================================

# Log environment at module load time
print("=" * 60)
print("DASHBOARD_API MODULE LOADED")
print(f"  CATALOG_NAME: {os.environ.get('CATALOG_NAME', 'NOT SET')}")
print(f"  GOLD_SCHEMA: {os.environ.get('GOLD_SCHEMA', 'NOT SET')}")
print(f"  DATABRICKS_WAREHOUSE_ID: {os.environ.get('DATABRICKS_WAREHOUSE_ID', 'NOT SET')}")
print("=" * 60)


def _get_db_config():
    """Get database configuration from environment variables"""
    config = {
        "catalog": os.environ.get("CATALOG_NAME", "aira_test"),
        "gold_schema": os.environ.get("GOLD_SCHEMA", "gold_md"),
        "warehouse_id": os.environ.get("DATABRICKS_WAREHOUSE_ID")
    }
    print(f"DEBUG _get_db_config: {config}")
    return config


def _get_sql_client():
    """Get SQL client instance - raises if not configured"""
    config = _get_db_config()
    if not config["warehouse_id"]:
        raise RuntimeError(
            "DATABRICKS_WAREHOUSE_ID environment variable not set. "
            "This app must run on Databricks with proper configuration in app.yaml."
        )
    print(f"DEBUG: Creating SQL client for warehouse: {config['warehouse_id']}")
    return DatabricksSQLClient(config["warehouse_id"])


# ============================================================================
# REAL DATA QUERIES
# ============================================================================

def _get_all_library_versions_from_db():
    """
    Query md_version_registry for ALL library types in a single query.
    Uses IN clause for efficiency.
    
    Returns:
        Dict mapping library_type -> list of version records
    """
    config = _get_db_config()
    table = f"{config['catalog']}.{config['gold_schema']}.md_version_registry"
    
    # All library types we support
    library_types = [
        'transfer_variables', 'codelists', 'test_concepts',
        'operational_agreements', 'visits_timepoints', 'data_ingestion_parameters'
    ]
    library_types_str = ", ".join([f"'{t}'" for t in library_types])
    
    # Single query with IN clause for all library types
    query = f"""
        SELECT 
            version_tag,
            library_type,
            version_type,
            dta_id,
            parent_version,
            record_count,
            status,
            created_by_principal,
            created_ts
        FROM {table}
        WHERE library_type IN ({library_types_str})
          AND status = 'ACTIVE'
          AND version_type = 'LIBRARY_MAJOR'
        ORDER BY library_type, created_ts DESC
    """
    
    # Log the full query for debugging
    print(f"=" * 60)
    print(f"DEBUG: Querying ALL library versions")
    print(f"DEBUG: Table: {table}")
    print(f"DEBUG: Query:")
    print(query)
    print(f"=" * 60)
    
    client = _get_sql_client()
    results = client.execute_query(query)
    
    print(f"DEBUG: Query returned {len(results)} total rows")
    
    # Group results by library_type
    versions_by_type = {}
    for row in results:
        lib_type = row.get("library_type")
        if lib_type not in versions_by_type:
            versions_by_type[lib_type] = []
        versions_by_type[lib_type].append(row)
    
    # Log summary
    print(f"DEBUG: Grouped by library_type:")
    for lib_type, versions in versions_by_type.items():
        print(f"  - {lib_type}: {len(versions)} versions")
    
    return versions_by_type


def _get_dta_overview_from_db():
    """
    Query DTA table for overview statistics.
    Returns total count and counts by workflow_state.
    """
    config = _get_db_config()
    table = f"{config['catalog']}.{config['gold_schema']}.dta"
    
    query = f"""
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN workflow_state = 'APPROVED' THEN 1 ELSE 0 END) as approved,
            SUM(CASE WHEN workflow_state = 'IN_REVIEW' THEN 1 ELSE 0 END) as in_review,
            SUM(CASE WHEN workflow_state IN ('DRAFT', 'NOT_STARTED') THEN 1 ELSE 0 END) as draft,
            SUM(CASE WHEN workflow_state = 'REJECTED' THEN 1 ELSE 0 END) as rejected
        FROM {table}
    """
    
    print(f"=" * 60)
    print(f"DEBUG: Querying DTA overview")
    print(f"DEBUG: Table: {table}")
    print(f"DEBUG: Query:")
    print(query)
    print(f"=" * 60)
    
    client = _get_sql_client()
    results = client.execute_query(query)
    
    if results and len(results) > 0:
        row = results[0]
        overview = {
            "total": int(row.get("total", 0) or 0),
            "by_status": {
                "approved": int(row.get("approved", 0) or 0),
                "in_review": int(row.get("in_review", 0) or 0),
                "draft": int(row.get("draft", 0) or 0),
                "rejected": int(row.get("rejected", 0) or 0)
            }
        }
        print(f"DEBUG: DTA Overview: {overview}")
        return overview
    
    # Return empty overview if query fails
    return {
        "total": 0,
        "by_status": {
            "approved": 0,
            "in_review": 0,
            "draft": 0,
            "rejected": 0
        }
    }


def _get_ready_to_promote_count():
    """
    Count DTAs that have all approvals complete and are ready to be promoted to DTA Major.
    These are DTAs where:
    - workflow_state = 'APPROVED' (all approvers have approved)
    - status is still 'PENDING_APPROVAL' or 'APPROVED' (not yet promoted to MAJOR)
    """
    config = _get_db_config()
    dta_table = f"{config['catalog']}.{config['gold_schema']}.dta"
    approval_table = f"{config['catalog']}.{config['gold_schema']}.dta_approval_task"
    
    # Count DTAs where workflow_state is APPROVED
    # These are DTAs ready for promotion to Major version
    query = f"""
        SELECT COUNT(DISTINCT d.dta_id) as ready_count
        FROM {dta_table} d
        WHERE d.workflow_state = 'APPROVED'
          AND d.status != 'PROMOTED'
    """
    
    print(f"DEBUG: Querying ready to promote count...")
    
    try:
        client = _get_sql_client()
        results = client.execute_query(query)
        
        if results and len(results) > 0:
            count = int(results[0].get("ready_count", 0) or 0)
            print(f"DEBUG: Ready to promote count: {count}")
            return count
    except Exception as e:
        print(f"DEBUG: Error getting ready to promote count: {e}")
    
    return 0


def _get_processing_stats_from_db():
    """
    Query processing statistics for "This Month" panel.
    - DTAs created this month from dta table
    - Files processed this month from md_document_status table
    - Success rate based on document status
    """
    config = _get_db_config()
    dta_table = f"{config['catalog']}.{config['gold_schema']}.dta"
    doc_table = f"{config['catalog']}.bronze_md.md_document_status"
    
    # Query for DTAs created this month
    dta_query = f"""
        SELECT COUNT(*) as dtas_created
        FROM {dta_table}
        WHERE created_ts >= date_trunc('month', current_date())
    """
    
    # Query for files processed this month and success rate
    doc_query = f"""
        SELECT 
            COUNT(DISTINCT document_id) as files_processed,
            ROUND(
                SUM(CASE WHEN status = 'COMPLETED' THEN 1 ELSE 0 END) * 100.0 / 
                NULLIF(COUNT(*), 0)
            , 0) as success_rate
        FROM {doc_table}
        WHERE created_ts >= date_trunc('month', current_date())
    """
    
    print(f"=" * 60)
    print(f"DEBUG: Querying processing stats")
    print(f"DEBUG: DTA Query: {dta_query}")
    print(f"DEBUG: Doc Query: {doc_query}")
    print(f"=" * 60)
    
    client = _get_sql_client()
    
    # Get DTA count
    dtas_created = 0
    try:
        dta_results = client.execute_query(dta_query)
        if dta_results and len(dta_results) > 0:
            dtas_created = int(dta_results[0].get("dtas_created", 0) or 0)
    except Exception as e:
        print(f"WARNING: Failed to query DTA count: {e}")
    
    # Get files processed and success rate
    files_processed = 0
    success_rate = 0
    try:
        doc_results = client.execute_query(doc_query)
        if doc_results and len(doc_results) > 0:
            files_processed = int(doc_results[0].get("files_processed", 0) or 0)
            success_rate = int(doc_results[0].get("success_rate", 0) or 0)
    except Exception as e:
        print(f"WARNING: Failed to query document stats: {e}")
    
    stats = {
        "this_month": {
            "dtas_created": dtas_created,
            "files_processed": files_processed
        },
        "success_rate": success_rate
    }
    
    print(f"DEBUG: Processing Stats: {stats}")
    return stats


def _get_recent_dtas_from_db(offset: int = 0, limit: int = 100):
    """
    Query DTA table for paginated list of recent DTAs.
    
    Args:
        offset: Starting position for pagination
        limit: Number of records to fetch (max 100)
    
    Returns:
        dict with 'dtas' list, 'total_count', 'has_more', 'next_offset'
    """
    config = _get_db_config()
    table = f"{config['catalog']}.{config['gold_schema']}.dta"
    
    # Query for total count
    count_query = f"SELECT COUNT(*) as total FROM {table}"
    
    # Query for paginated DTAs ordered by last_updated_ts desc
    dta_query = f"""
        SELECT 
            dta_id,
            dta_number,
            trial_id,
            data_stream_type as data_stream,
            data_provider_name as vendor,
            status,
            workflow_state,
            current_version_tag as version_tag,
            notes,
            created_by_principal,
            created_ts,
            last_updated_ts
        FROM {table}
        ORDER BY last_updated_ts DESC
        LIMIT {limit}
        OFFSET {offset}
    """
    
    print(f"=" * 60)
    print(f"DEBUG: Querying paginated DTAs (offset={offset}, limit={limit})")
    print(f"DEBUG: Query: {dta_query[:200]}...")
    print(f"=" * 60)
    
    client = _get_sql_client()
    
    # Get total count
    total_count = 0
    try:
        count_results = client.execute_query(count_query)
        if count_results and len(count_results) > 0:
            total_count = int(count_results[0].get("total", 0) or 0)
    except Exception as e:
        print(f"WARNING: Failed to get DTA count: {e}")
    
    # Get paginated DTAs
    dtas = []
    try:
        results = client.execute_query(dta_query)
        if results:
            for row in results:
                # Format timestamps for display
                created_ts = row.get("created_ts", "")
                last_updated_ts = row.get("last_updated_ts", "")
                
                # Parse and format dates
                try:
                    if created_ts:
                        created_date = datetime.fromisoformat(str(created_ts).replace('Z', '+00:00'))
                        created_display = created_date.strftime("%Y-%m-%d %H:%M")
                    else:
                        created_display = "N/A"
                except:
                    created_display = str(created_ts)[:16] if created_ts else "N/A"
                
                try:
                    if last_updated_ts:
                        updated_date = datetime.fromisoformat(str(last_updated_ts).replace('Z', '+00:00'))
                        updated_display = updated_date.strftime("%Y-%m-%d %H:%M")
                    else:
                        updated_display = "N/A"
                except:
                    updated_display = str(last_updated_ts)[:16] if last_updated_ts else "N/A"
                
                dtas.append({
                    "dta_id": str(row.get("dta_id", "")),
                    "dta_number": str(row.get("dta_number", "")),
                    "trial_id": str(row.get("trial_id", "")),
                    "vendor": str(row.get("vendor", "")),
                    "data_stream": str(row.get("data_stream", "")),
                    "status": str(row.get("status", "")),
                    "workflow_state": str(row.get("workflow_state", "")),
                    "version_tag": str(row.get("version_tag", "")),
                    "notes": str(row.get("notes", "") or ""),
                    "created_by": str(row.get("created_by_principal", "")),
                    "created_ts": created_display,
                    "last_updated_ts": updated_display,
                    "created_ts_raw": str(created_ts),
                    "last_updated_ts_raw": str(last_updated_ts)
                })
    except Exception as e:
        print(f"ERROR: Failed to query DTAs: {e}")
        import traceback
        traceback.print_exc()
    
    has_more = (offset + len(dtas)) < total_count
    next_offset = offset + limit if has_more else None
    
    print(f"DEBUG: Retrieved {len(dtas)} DTAs (total: {total_count}, has_more: {has_more})")
    
    return {
        "dtas": dtas,
        "total_count": total_count,
        "has_more": has_more,
        "next_offset": next_offset,
        "offset": offset,
        "limit": limit
    }


def _get_recent_activity_from_db():
    """
    Query recent activity from Gold tables:
    - md_version_registry: Version creation events
    - dta: DTA creation/update events
    - dta_workflow: Workflow status changes
    
    Returns list of activity records sorted by timestamp.
    """
    config = _get_db_config()
    catalog = config['catalog']
    gold_schema = config['gold_schema']
    
    # UNION query to get activity from multiple tables
    query = f"""
        (
            -- Version Registry: Version created/updated
            SELECT 
                'VERSION' as source,
                version_tag as entity_id,
                CASE version_type
                    WHEN 'LIBRARY_MAJOR' THEN CONCAT('Library v', version_tag, ' released (', COALESCE(record_count, 0), ' records)')
                    WHEN 'DTA_MAJOR' THEN CONCAT('DTA version ', version_tag, ' approved (', COALESCE(record_count, 0), ' records)')
                    WHEN 'DTA_DRAFT' THEN CONCAT('Draft ', version_tag, ' created')
                    ELSE CONCAT('Version ', version_tag, ' updated')
                END as message,
                version_type as activity_type,
                status,
                created_ts as activity_ts,
                created_by_principal as user_principal,
                CASE version_type
                    WHEN 'LIBRARY_MAJOR' THEN '📚'
                    WHEN 'DTA_MAJOR' THEN '📦'
                    WHEN 'DTA_DRAFT' THEN '📝'
                    ELSE '🔄'
                END as icon
            FROM {catalog}.{gold_schema}.md_version_registry
            WHERE created_ts >= current_date() - INTERVAL 30 DAY
        )
        
        UNION ALL
        
        (
            -- DTA: DTA created or state changed
            SELECT 
                'DTA' as source,
                dta_id as entity_id,
                CASE 
                    WHEN workflow_state = 'APPROVED' THEN CONCAT('DTA ', dta_number, ' approved')
                    WHEN workflow_state = 'REJECTED' THEN CONCAT('DTA ', dta_number, ' rejected')
                    WHEN workflow_state = 'IN_REVIEW' THEN CONCAT('DTA ', dta_number, ' submitted for review')
                    WHEN created_ts = last_updated_ts THEN CONCAT('DTA ', dta_number, ' created')
                    ELSE CONCAT('DTA ', dta_number, ' updated')
                END as message,
                workflow_state as activity_type,
                status,
                COALESCE(last_updated_ts, created_ts) as activity_ts,
                COALESCE(last_updated_by_principal, created_by_principal) as user_principal,
                CASE workflow_state
                    WHEN 'APPROVED' THEN '✅'
                    WHEN 'REJECTED' THEN '❌'
                    WHEN 'IN_REVIEW' THEN '🔍'
                    ELSE '📋'
                END as icon
            FROM {catalog}.{gold_schema}.dta
            WHERE last_updated_ts >= current_date() - INTERVAL 30 DAY
        )
        
        ORDER BY activity_ts DESC
        LIMIT 15
    """
    
    print(f"=" * 60)
    print(f"DEBUG: Querying recent activity")
    print(f"DEBUG: Query:")
    print(query)
    print(f"=" * 60)
    
    client = _get_sql_client()
    results = client.execute_query(query)
    
    print(f"DEBUG: Found {len(results)} activity records")
    
    # Format results for display
    activities = []
    for row in results:
        # Format timestamp to relative time
        activity_ts = row.get("activity_ts", "")
        if activity_ts:
            try:
                if isinstance(activity_ts, str):
                    dt = datetime.fromisoformat(activity_ts.replace("Z", "+00:00"))
                else:
                    dt = activity_ts
                # Calculate relative time
                now = datetime.now(dt.tzinfo) if dt.tzinfo else datetime.now()
                delta = now - dt
                if delta.days > 0:
                    timestamp = f"{delta.days}d ago"
                elif delta.seconds >= 3600:
                    timestamp = f"{delta.seconds // 3600}h ago"
                elif delta.seconds >= 60:
                    timestamp = f"{delta.seconds // 60}m ago"
                else:
                    timestamp = "Just now"
            except:
                timestamp = str(activity_ts)[:10]
        else:
            timestamp = "Unknown"
        
        # Extract username from email
        user = row.get("user_principal", "")
        if "@" in user:
            user_short = user.split("@")[0]
        else:
            user_short = user or "System"
        
        activities.append({
            "icon": row.get("icon", "📋"),
            "message": row.get("message", "Activity"),
            "timestamp": timestamp,
            "user": user_short,
            "source": row.get("source", ""),
            "activity_type": row.get("activity_type", ""),
            "status": row.get("status", "")
        })
    
    return activities


def _format_versions_for_display(db_versions, entity_code: str, entity_name: str, entity_icon: str):
    """
    Format database version records for dashboard display.
    
    Args:
        db_versions: List of version records from database
        entity_code: Entity code (e.g., 'TV')
        entity_name: Display name
        entity_icon: Emoji icon
    
    Returns:
        Formatted entity dictionary for dashboard
    """
    if not db_versions:
        return None
    
    versions = []
    for i, v in enumerate(db_versions[:5]):  # Limit to 5 versions
        # First version is the "current" (latest) library version
        is_current = (i == 0)
        
        # Format created_ts
        created_ts = v.get("created_ts", "")
        if created_ts:
            try:
                if isinstance(created_ts, str):
                    # Parse ISO format
                    dt = datetime.fromisoformat(created_ts.replace("Z", "+00:00"))
                else:
                    dt = created_ts
                updated = dt.strftime("%b %d, %Y")
            except:
                updated = str(created_ts)[:10]
        else:
            updated = "N/A"
        
        # Extract username from email
        created_by = v.get("created_by_principal", "")
        if "@" in created_by:
            created_by_short = created_by.split("@")[0]
        else:
            created_by_short = created_by
        
        versions.append({
            "version": v.get("version_tag", "N/A"),
            "version_type": v.get("version_type", ""),
            "is_current": is_current,
            "record_count": int(v.get("record_count", 0)),
            "updated": updated,
            "parent_version": v.get("parent_version", ""),
            "created_by": created_by,
            "created_by_short": created_by_short,
            "dta_id": v.get("dta_id", "")
        })
    
    return {
        "code": entity_code,
        "name": entity_name,
        "icon": entity_icon,
        "versions": versions,
        "has_real_data": True
    }


# ============================================================================
# MOCK DATA (Fallback when DB not available)
# ============================================================================

def _get_mock_dtas():
    """Generate mock DTA data"""
    return [
        {
            "dta_id": "DTA012",
            "dta_number": "DTA012",
            "trial_id": "TRIAL-045",
            "vendor": "IQVIA",
            "data_stream": "Lab Results",
            "status": "IN_REVIEW",
            "version_tag": "1.0-DTA012-draft3",
            "workflow_state": "IN_REVIEW",
            "created_ts": (datetime.now() - timedelta(days=2)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(hours=2)).isoformat(),
            "approvals": [
                {"reviewer_name": "Sarah Johnson", "role": "JNJ_DAE", "status": "Approved"},
                {"reviewer_name": "Alex Kumar", "role": "VENDOR", "status": "Pending"}
            ]
        },
        {
            "dta_id": "DTA011",
            "dta_number": "DTA011",
            "trial_id": "TRIAL-044",
            "vendor": "Parexel",
            "data_stream": "EDC Data",
            "status": "DRAFT",
            "version_tag": "1.0-DTA011-draft1",
            "workflow_state": "NOT_STARTED",
            "created_ts": (datetime.now() - timedelta(days=3)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(hours=5)).isoformat(),
            "approvals": []
        },
        {
            "dta_id": "DTA010",
            "dta_number": "DTA010",
            "trial_id": "TRIAL-043",
            "vendor": "PPD",
            "data_stream": "Safety Data",
            "status": "APPROVED",
            "version_tag": "1.0-DTA010-v1.0",
            "workflow_state": "APPROVED",
            "created_ts": (datetime.now() - timedelta(days=5)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(days=1)).isoformat(),
            "approvals": [
                {"reviewer_name": "Sarah Johnson", "role": "JNJ_DAE", "status": "Approved"},
                {"reviewer_name": "David Park", "role": "VENDOR", "status": "Approved"}
            ]
        },
        {
            "dta_id": "DTA009",
            "dta_number": "DTA009",
            "trial_id": "TRIAL-042",
            "vendor": "IQVIA",
            "data_stream": "PK Data",
            "status": "APPROVED",
            "version_tag": "1.0-DTA009-v1.0",
            "workflow_state": "APPROVED",
            "created_ts": (datetime.now() - timedelta(days=7)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(days=2)).isoformat(),
            "approvals": [
                {"reviewer_name": "Emily Rodriguez", "role": "JNJ_DAE", "status": "Approved"},
                {"reviewer_name": "Jennifer Lee", "role": "VENDOR", "status": "Approved"}
            ]
        },
        {
            "dta_id": "DTA008",
            "dta_number": "DTA008",
            "trial_id": "TRIAL-041",
            "vendor": "Syneos",
            "data_stream": "EDC Data",
            "status": "REJECTED",
            "version_tag": "1.0-DTA008-draft2",
            "workflow_state": "REJECTED",
            "created_ts": (datetime.now() - timedelta(days=10)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(days=3)).isoformat(),
            "approvals": [
                {"reviewer_name": "Michael Chen", "role": "JNJ_DAE", "status": "Rejected"}
            ]
        },
        {
            "dta_id": "DTA007",
            "dta_number": "DTA007",
            "trial_id": "TRIAL-040",
            "vendor": "Covance",
            "data_stream": "Lab Results",
            "status": "APPROVED",
            "version_tag": "1.0-DTA007-v1.0",
            "workflow_state": "APPROVED",
            "created_ts": (datetime.now() - timedelta(days=12)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(days=5)).isoformat(),
            "approvals": [
                {"reviewer_name": "Sarah Johnson", "role": "JNJ_DAE", "status": "Approved"},
                {"reviewer_name": "Alex Kumar", "role": "VENDOR", "status": "Approved"}
            ]
        },
        {
            "dta_id": "DTA006",
            "dta_number": "DTA006",
            "trial_id": "TRIAL-039",
            "vendor": "ICON",
            "data_stream": "Safety Data",
            "status": "IN_REVIEW",
            "version_tag": "1.0-DTA006-draft2",
            "workflow_state": "IN_REVIEW",
            "created_ts": (datetime.now() - timedelta(days=4)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(hours=8)).isoformat(),
            "approvals": [
                {"reviewer_name": "Emily Rodriguez", "role": "JNJ_DAE", "status": "Pending"}
            ]
        },
        {
            "dta_id": "DTA005",
            "dta_number": "DTA005",
            "trial_id": "TRIAL-038",
            "vendor": "PRA Health",
            "data_stream": "EDC Data",
            "status": "DRAFT",
            "version_tag": "1.0-DTA005-draft1",
            "workflow_state": "NOT_STARTED",
            "created_ts": (datetime.now() - timedelta(days=1)).isoformat(),
            "last_updated_ts": (datetime.now() - timedelta(hours=12)).isoformat(),
            "approvals": []
        }
    ]


def _get_library_data():
    """
    Get library data for all 6 metadata entities from database.
    Uses a single query with IN clause for efficiency.
    Shows "No data found" for entities without versions.
    """
    entities = []
    
    # Define all library types with display info
    library_configs = [
        ("transfer_variables", "TV", "Transfer Variables", "📊"),
        ("codelists", "CL", "Codelists", "📋"),
        ("test_concepts", "TC", "Test Concepts", "🧪"),
        ("operational_agreements", "OA", "Operational Agreements", "📝"),
        ("visits_timepoints", "VT", "Visits & Timepoints", "📅"),
        ("data_ingestion_parameters", "DIP", "Data Ingestion Parameters", "⚙️"),
    ]
    
    # Single query for all library types
    print("\n=== Fetching All Library Versions ===")
    versions_by_type = _get_all_library_versions_from_db()
    
    # Build entities from grouped results
    for lib_type, code, name, icon in library_configs:
        db_versions = versions_by_type.get(lib_type, [])
        
        if db_versions:
            # Limit to 5 versions per type
            entity = _format_versions_for_display(db_versions[:5], code, name, icon)
            if entity:
                entities.append(entity)
                print(f"✓ {name}: {len(db_versions)} versions found")
            else:
                # Format returned None (shouldn't happen, but handle it)
                entities.append({
                    "code": code,
                    "name": name,
                    "icon": icon,
                    "versions": [],
                    "has_real_data": True,
                    "message": "No data found"
                })
                print(f"⚠ {name}: No versions formatted")
        else:
            # No versions found for this library type - show message in panel
            entities.append({
                "code": code,
                "name": name,
                "icon": icon,
                "versions": [],
                "has_real_data": True,
                "message": "No data found"
            })
            print(f"⚠ {name}: No data found")
    
    print(f"\n=== Library Data Summary ===")
    print(f"Total entities: {len(entities)}")
    for e in entities:
        version_count = len(e.get("versions", []))
        msg = e.get("message", "")
        if msg:
            print(f"  - {e['name']}: {msg}")
        else:
            print(f"  - {e['name']}: {version_count} versions")
    
    return {"entities": entities}


def _get_mock_activity():
    """Get mock recent activity"""
    return [
        {
            "type": "submission",
            "message": "DTA012 submitted for approval",
            "timestamp": (datetime.now() - timedelta(hours=2)).isoformat(),
            "user": "john.doe@jnj.com",
            "icon": "📤"
        },
        {
            "type": "approval",
            "message": "DTA010 approved by Sarah Johnson",
            "timestamp": (datetime.now() - timedelta(hours=5)).isoformat(),
            "user": "sarah.johnson@jnj.com",
            "icon": "✅"
        },
        {
            "type": "library",
            "message": "Library promoted to v2.0",
            "timestamp": (datetime.now() - timedelta(days=1)).isoformat(),
            "user": "lisa.wong@jnj.com",
            "icon": "📚"
        },
        {
            "type": "approval",
            "message": "DTA009 approved by Vendor",
            "timestamp": (datetime.now() - timedelta(days=2)).isoformat(),
            "user": "david.park@vendor.com",
            "icon": "✅"
        },
        {
            "type": "rejection",
            "message": "DTA008 rejected - missing required fields",
            "timestamp": (datetime.now() - timedelta(days=3)).isoformat(),
            "user": "michael.chen@jnj.com",
            "icon": "❌"
        },
        {
            "type": "draft",
            "message": "DTA011 draft created",
            "timestamp": (datetime.now() - timedelta(days=3)).isoformat(),
            "user": "emily.rodriguez@jnj.com",
            "icon": "📝"
        }
    ]


def _get_mock_processing_stats():
    """Get mock processing statistics"""
    return {
        "this_month": {
            "dtas_created": 12,
            "files_processed": 48,
            "documents_uploaded": 156
        },
        "monthly_trend": [
            {"month": "Oct", "count": 8},
            {"month": "Nov", "count": 10},
            {"month": "Dec", "count": 12}
        ],
        "success_rate": 94.5
    }


# ============================================================================
# API ENDPOINTS
# ============================================================================

@dashboard_bp.route('/action-required')
def get_action_required():
    """
    Get counts for action required cards.
    Returns: pending approvals, my drafts, processing documents, ready for promotion
    """
    dtas = _get_mock_dtas()
    
    # Count pending approvals (DTAs in IN_REVIEW with pending approval tasks for current user)
    pending_approvals = len([d for d in dtas if d['status'] == 'IN_REVIEW'])
    
    # Count my drafts (DTAs in DRAFT status)
    my_drafts = len([d for d in dtas if d['status'] == 'DRAFT'])
    
    # Processing documents (mock - documents currently being processed)
    processing_documents = 5
    
    # Ready for promotion (approved DTA majors not yet in library)
    ready_for_promotion = 1
    
    return jsonify({
        "success": True,
        "data": {
            "pending_approvals": pending_approvals,
            "my_drafts": my_drafts,
            "processing_documents": processing_documents,
            "ready_for_promotion": ready_for_promotion
        }
    })


@dashboard_bp.route('/dta-overview')
def get_dta_overview():
    """
    Get DTA overview with status breakdown.
    """
    overview = _get_dta_overview_from_db()
    
    return jsonify({
        "success": True,
        "data": overview
    })


@dashboard_bp.route('/library-overview')
def get_library_overview():
    """
    Get library version overview for all 6 metadata entities.
    """
    library = _get_library_data()
    
    return jsonify({
        "success": True,
        "data": {
            "entities": library["entities"]
        }
    })


@dashboard_bp.route('/recent-dtas')
def get_recent_dtas():
    """
    Get recent DTAs with pagination for infinite scroll.
    
    Query params:
        offset: Starting position (default 0)
        limit: Number of records to fetch (default 100, max 100)
    
    Returns:
        dtas: List of DTA records
        total_count: Total number of DTAs
        has_more: Whether more records exist
        next_offset: Offset for next page (null if no more)
    """
    from flask import request
    
    offset = request.args.get('offset', 0, type=int)
    limit = min(request.args.get('limit', 100, type=int), 100)  # Max 100
    
    # Get real data from database
    result = _get_recent_dtas_from_db(offset=offset, limit=limit)
    
    return jsonify({
        "success": True,
        "data": result
    })


@dashboard_bp.route('/recent-activity')
def get_recent_activity():
    """
    Get recent activity feed.
    """
    activity = _get_recent_activity_from_db()
    
    return jsonify({
        "success": True,
        "data": {
            "activities": activity
        }
    })


@dashboard_bp.route('/processing-stats')
def get_processing_stats():
    """
    Get processing statistics for charts.
    """
    stats = _get_processing_stats_from_db()
    
    return jsonify({
        "success": True,
        "data": stats
    })


@dashboard_bp.route('/summary')
def get_dashboard_summary():
    """
    Get all dashboard data in a single call for initial page load.
    This combines all the above endpoints for efficiency.
    """
    # Get real data from database
    library = _get_library_data()
    dta_overview = _get_dta_overview_from_db()
    stats = _get_processing_stats_from_db()
    activity = _get_recent_activity_from_db()
    
    # Get real DTAs from database with pagination
    dtas_result = _get_recent_dtas_from_db(offset=0, limit=100)
    dtas = dtas_result.get("dtas", [])
    
    return jsonify({
        "success": True,
        "data": {
            "action_required": {
                "pending_approvals": dta_overview["by_status"]["in_review"],
                "my_drafts": dta_overview["by_status"]["draft"],
            },
            "dta_overview": dta_overview,
            "library_entities": library["entities"],
            "recent_dtas": dtas[:10],
            "recent_dtas_all": dtas,
            "dtas_pagination": {
                "total_count": dtas_result.get("total_count", 0),
                "has_more": dtas_result.get("has_more", False),
                "next_offset": dtas_result.get("next_offset")
            },
            "recent_activity": activity,  # All activity for infinite scroll
            "processing_stats": stats
        }
    })


# ============================================================================
# HELPER FUNCTIONS FOR TEMPLATE RENDERING
# ============================================================================

def get_dashboard_data():
    """
    Get all dashboard data for template rendering.
    Returns a dictionary with all dashboard components.
    """
    # Get real data from database
    library = _get_library_data()
    dta_overview = _get_dta_overview_from_db()
    stats = _get_processing_stats_from_db()
    activity = _get_recent_activity_from_db()
    ready_to_promote = _get_ready_to_promote_count()
    
    # Get real DTAs from database (first page for initial load)
    dtas_result = _get_recent_dtas_from_db(offset=0, limit=100)
    dtas = dtas_result.get("dtas", [])
    dtas_pagination = {
        "total_count": dtas_result.get("total_count", 0),
        "has_more": dtas_result.get("has_more", False),
        "next_offset": dtas_result.get("next_offset")
    }
    
    return {
        "action_required": {
            "pending_approvals": dta_overview["by_status"]["in_review"],
            "my_drafts": dta_overview["by_status"]["draft"],
            "ready_to_promote": ready_to_promote,
        },
        "dta_overview": dta_overview,
        "library_entities": library["entities"],
        "recent_dtas": dtas[:10],  # Initial display of 10 (real data)
        "recent_dtas_all": dtas,    # Full cached data (up to 100)
        "dtas_pagination": dtas_pagination,  # Pagination info for infinite scroll
        "recent_activity": activity,  # All activity for infinite scroll
        "processing_stats": stats
    }


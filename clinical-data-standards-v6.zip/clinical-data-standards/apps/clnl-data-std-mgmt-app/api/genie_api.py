# =============================================================================
# Genie API - Natural Language Search using Databricks Genie
# =============================================================================
# This module provides Flask API endpoints for AI-powered natural language
# search of DTAs and clinical metadata using Databricks Genie.
#
# Uses GenieWrapper from databricks_ai_bridge for clean API interaction.
#
# Prerequisites:
# 1. Create a Genie Space in Databricks with DTA tables
# 2. Set GENIE_SPACE_ID environment variable in app.yaml
# 3. Install databricks-ai-bridge package
# =============================================================================

import os
from flask import Blueprint, request, jsonify

# Import GenieWrapper and GenieResponse from our wrapper module
from api.genie import GenieWrapper, GenieResponse

genie_bp = Blueprint('genie', __name__, url_prefix='/api/genie')


def _get_genie_config():
    """Get Genie configuration from environment."""
    return {
        'space_id': os.environ.get('GENIE_SPACE_ID', ''),
    }


def _format_genie_response(result: GenieResponse, conversation_id: str) -> dict:
    """
    Format GenieResponse into API response format.
    
    Args:
        result: GenieResponse from poll_result()
        conversation_id: Conversation ID for follow-ups
    
    Returns:
        Dict with success, answer, sql, results, conversation_id
    """
    # Parse results into DTA-compatible format if possible
    dtas = _parse_results_to_dtas(result.result) if result.result else []
    
    return {
        "success": True,
        "answer": result.description or "",
        "sql": result.query or "",
        "results": result.result or "",
        "dtas": dtas,
        "conversation_id": conversation_id,
        "result_count": len(dtas)
    }


def _get_field_mappings():
    """Get the field mappings for normalizing column names."""
    return {
        # Core DTA fields
        'dta_id': ['dta_id'],
        'dta_number': ['dta_number'],
        'dta_name': ['dta_name'],
        'trial_id': ['trial_id'],
        'data_stream_type': ['data_stream_type', 'stream_type'],
        'data_provider_name': ['data_provider_name', 'provider_name', 'vendor'],
        'status': ['status'],
        'workflow_state': ['workflow_state'],
        'current_version_tag': ['current_version_tag', 'version_tag'],
        'last_updated_ts': ['last_updated_ts', 'last_updated', 'updated_ts'],
        
        # Metadata entity counts (from Genie training queries)
        'transfer_variables_count': ['transfer_variables_count'],
        'test_concepts_count': ['test_concepts_count'],
        'codelists_count': ['codelists_count'],
        'visits_timepoints_count': ['visits_timepoints_count'],
        'operational_agreements_count': ['operational_agreements_count'],
        'data_ingestion_params_count': ['data_ingestion_params_count', 'data_ingestion_parameters_count'],
        
        # Legacy/other fields
        'transfer_variable_name': ['transfer_variable_name'],
        'record_count': ['record_count'],
        'library_version': ['library_version']
    }


def _map_record_to_dta(record: dict) -> dict:
    """Map a single record dict to DTA format using field mappings."""
    dta = {}
    field_mappings = _get_field_mappings()
    
    # Normalize keys to lowercase with underscores
    normalized_record = {k.lower().replace(' ', '_'): v for k, v in record.items()}
    
    for target, sources in field_mappings.items():
        for src in sources:
            if src in normalized_record and normalized_record[src]:
                dta[target] = normalized_record[src]
                break
    
    # Include all other columns that weren't mapped
    for key, value in normalized_record.items():
        if key not in dta and value:
            dta[key] = value
    
    return dta


def _map_records_to_dtas(records: list) -> list:
    """Map a list of record dicts to DTA format."""
    dtas = []
    for record in records:
        dta = _map_record_to_dta(record)
        if dta:
            dtas.append(dta)
    print(f"[Genie Parse] Mapped {len(dtas)} records to DTAs")
    if dtas:
        print(f"[Genie Parse] First DTA: {dtas[0]}")
    return dtas


def _parse_results_to_dtas(result_data) -> list:
    """
    Parse Genie result into DTA-compatible records.
    Handles multiple formats: markdown table, DataFrame, dict list, etc.
    
    Args:
        result_data: Result from GenieResponse.result (could be various formats)
    
    Returns:
        List of DTA records (or empty list if parsing fails)
    """
    if not result_data:
        print("[Genie Parse] No result data to parse")
        return []
    
    print(f"[Genie Parse] Input type: {type(result_data)}")
    print(f"[Genie Parse] Input value (first 500 chars): {str(result_data)[:500]}")
    
    try:
        # Handle DataFrame (pandas)
        if hasattr(result_data, 'to_dict'):
            print("[Genie Parse] Detected DataFrame, converting to records")
            records = result_data.to_dict('records')
            return _map_records_to_dtas(records)
        
        # Handle list of dicts
        if isinstance(result_data, list) and len(result_data) > 0 and isinstance(result_data[0], dict):
            print(f"[Genie Parse] Detected list of dicts with {len(result_data)} records")
            return _map_records_to_dtas(result_data)
        
        # Handle string (markdown table or other text format)
        if isinstance(result_data, str):
            result_markdown = result_data
            print(f"[Genie Parse] Detected string, attempting markdown parse")
            
            # Parse markdown table format
            lines = result_markdown.strip().split('\n')
            print(f"[Genie Parse] Number of lines: {len(lines)}")
            if len(lines) > 0:
                print(f"[Genie Parse] First line: {lines[0][:200]}")
            
            if len(lines) < 3:  # Need header, separator, and at least one data row
                print("[Genie Parse] Not enough lines for markdown table")
                return []
            
            # Extract headers (first line) - split by | keeping track of positions
            header_parts = lines[0].split('|')
            
            # Check if first column is an index column (empty header or just whitespace)
            has_index_column = len(header_parts) > 0 and not header_parts[0].strip() and len(header_parts) > 1 and not header_parts[1].strip()
            print(f"[Genie Parse] Has index column: {has_index_column}")
            
            # Get actual headers (skip empty ones at the start)
            headers = [h.strip() for h in header_parts if h.strip()]
            print(f"[Genie Parse] Headers: {headers}")
            
            if not headers:
                print("[Genie Parse] No headers found")
                return []
            
            # Skip separator line (second line)
            # Parse data rows
            records = []
            for line in lines[2:]:
                if not line.strip() or line.strip().startswith('|--'):
                    continue
                
                # Split by | and get all values
                value_parts = line.split('|')
                
                # If there's an index column, skip the first two parts (empty + index number)
                if has_index_column and len(value_parts) > 2:
                    # Skip first empty and the row index
                    values = [v.strip() for v in value_parts[2:] if v.strip() or v == '']
                else:
                    values = [v.strip() for v in value_parts if v.strip() or v == '']
                
                # Handle empty cells
                values = [v if v else None for v in values]
                
                print(f"[Genie Parse] Row values (first 5): {values[:5]}")
                
                if len(values) >= len(headers):
                    record = dict(zip([h.lower().replace(' ', '_') for h in headers], values[:len(headers)]))
                    records.append(record)
                    print(f"[Genie Parse] Created record: {list(record.items())[:3]}...")
            
            print(f"[Genie Parse] Parsed {len(records)} records from markdown")
            return _map_records_to_dtas(records)
        
        print(f"[Genie Parse] Unknown result format: {type(result_data)}")
        return []
        
    except Exception as e:
        print(f"[Genie Parse] Error parsing results: {e}")
        import traceback
        traceback.print_exc()
        return []


# =============================================================================
# API Routes
# =============================================================================

@genie_bp.route('/search')
def genie_search():
    """
    Natural language search using Databricks Genie.
    
    Query params:
        - q: Natural language question about DTAs
    
    Returns:
        JSON with:
        - success: bool
        - answer: Genie's text response (.description)
        - sql: Generated SQL (.query)
        - results: Raw markdown results (.result)
        - dtas: Parsed DTA records for card display
        - conversation_id: For follow-up questions
    
    Example queries:
        - "Show me the latest DTA for Labs data from LabCorp"
        - "Which DTAs for trial VAC18193 are pending approval?"
        - "Find approved transfer variable definitions for ECG"
    """
    question = request.args.get('q', '').strip()
    
    if not question:
        return jsonify({
            "success": False,
            "error": "Please enter a question"
        })
    
    if len(question) < 5:
        return jsonify({
            "success": False,
            "error": "Please enter a more detailed question (at least 5 characters)"
        })
    
    config = _get_genie_config()
    
    if not config['space_id']:
        return jsonify({
            "success": False,
            "error": "Genie Space ID not configured. Please set GENIE_SPACE_ID in app.yaml.",
            "not_configured": True
        })
    
    try:
        print(f"[Genie] Asking: {question}")
        print(f"[Genie] Space ID: {config['space_id']}")
        
        # Initialize GenieWrapper
        genie = GenieWrapper(config['space_id'])
        
        # Ask the question and get response
        response = genie.ask_first_question(question)
        print(f"[Genie] Conversation ID: {genie.get_conversation_id(response)}")
        
        # Poll for result
        result = genie.poll_result(response)
        conversation_id = genie.get_conversation_id(response)
        
        # DEBUG: Log the GenieResponse details
        print(f"[Genie] ===== RESPONSE DEBUG =====")
        print(f"[Genie] Result type: {type(result)}")
        print(f"[Genie] Result attributes: {dir(result)}")
        print(f"[Genie] Description: {result.description[:200] if result.description else 'None'}...")
        print(f"[Genie] Query: {result.query[:200] if result.query else 'None'}...")
        print(f"[Genie] Result type: {type(result.result)}")
        print(f"[Genie] Result value: {str(result.result)[:500] if result.result else 'None'}...")
        print(f"[Genie] ===========================")
        
        # Format and return response
        formatted = _format_genie_response(result, conversation_id)
        print(f"[Genie] Parsed DTAs count: {len(formatted.get('dtas', []))}")
        if formatted.get('dtas'):
            print(f"[Genie] First DTA: {formatted['dtas'][0]}")
        return jsonify(formatted)
        
    except TimeoutError as e:
        print(f"[Genie] Timeout error: {e}")
        return jsonify({
            "success": False,
            "error": "Genie is taking too long to respond. Please try a simpler question."
        }), 504
        
    except ConnectionError as e:
        print(f"[Genie] Connection error: {e}")
        return jsonify({
            "success": False,
            "error": "Could not connect to Genie service. Please try again later."
        }), 503
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        error_msg = str(e)
        
        # Check for common error patterns and provide user-friendly messages
        if "timeout" in error_msg.lower() or "timed out" in error_msg.lower():
            return jsonify({
                "success": False,
                "error": "Genie is taking too long to respond. Please try a simpler question."
            }), 504
        elif "connection" in error_msg.lower() or "network" in error_msg.lower():
            return jsonify({
                "success": False,
                "error": "Could not connect to Genie service. Please try again later."
            }), 503
        elif "not found" in error_msg.lower() or "no data" in error_msg.lower():
            # This is actually a valid "0 results" case, not an error
            return jsonify({
                "success": True,
                "answer": "No matching DTAs found for your query.",
                "sql": "",
                "results": "",
                "dtas": [],
                "conversation_id": None,
                "result_count": 0
            })
        else:
            return jsonify({
                "success": False,
                "error": f"Genie service error: {error_msg}"
            }), 500


@genie_bp.route('/followup', methods=['POST'])
def genie_followup():
    """
    Send a follow-up question in an existing conversation.
    
    Request body:
        - conversation_id: Existing conversation ID
        - question: Follow-up question
    
    Returns:
        Same format as /search
    """
    data = request.get_json() or {}
    conversation_id = data.get('conversation_id', '').strip()
    question = data.get('question', '').strip()
    
    if not conversation_id:
        return jsonify({
            "success": False,
            "error": "conversation_id is required"
        })
    
    if not question:
        return jsonify({
            "success": False,
            "error": "question is required"
        })
    
    config = _get_genie_config()
    
    if not config['space_id']:
        return jsonify({
            "success": False,
            "error": "Genie Space ID not configured",
            "not_configured": True
        })
    
    try:
        print(f"[Genie] Follow-up: {question}")
        print(f"[Genie] Conversation: {conversation_id}")
        
        # Initialize GenieWrapper
        genie = GenieWrapper(config['space_id'])
        
        # Send follow-up question
        response = genie.ask_followup_question(question, conversation_id)
        
        # Poll for result
        result = genie.poll_result(response)
        
        # Format and return response
        return jsonify(_format_genie_response(result, conversation_id))
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@genie_bp.route('/status')
def genie_status():
    """
    Check Genie configuration and availability.
    
    Returns:
        JSON with configuration status
    """
    config = _get_genie_config()
    
    return jsonify({
        "configured": bool(config['space_id']),
        "space_id": config['space_id'][:8] + "..." if config['space_id'] else None,
        "message": "Genie is configured" if config['space_id'] else "GENIE_SPACE_ID not set"
    })

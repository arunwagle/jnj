# Version Manager - SCD Type 2 Versioning System

> **Related Documentation:**
> - [04_versioning_design.drawio](./diagrams/04_versioning_design.drawio) - High-level versioning flow
> - [04b_versioning_technical_design.drawio](./diagrams/04b_versioning_technical_design.drawio) - Detailed data flow with examples
> - [06_dta_approval_design.readme.md](./06_dta_approval_design.readme.md) - Approval chain, user assignment, and governance
> - [06_dta_approval_design.drawio](./diagrams/06_dta_approval_design.drawio) - Visual approval flow diagram

## Overview

The Clinical Data Standards platform uses **SCD Type 2 (Slowly Changing Dimension)** versioning to track all changes to transfer variable definitions. This enables:

- **Full audit trail** of every change
- **Parallel DTA development** without collisions
- **Point-in-time queries** for any historical version
- **Approval workflows** with version promotion

---

## 📊 Version Types

The system supports three distinct version types:

### 1. **Library Major Version** (Canonical Production)
- **Format**: `1.0`, `2.0`, `3.0`, etc.
- **Purpose**: The canonical, production-ready standard
- **Characteristics**:
  - `is_major_version = TRUE`
  - `is_dta_major = FALSE`
  - New DTAs can branch from any Library Major version
- **Example**: `library_version = "1.0"`
- **Creation**: Requires **Librarian role** approval; can merge multiple approved DTAs

### 2. **DTA Draft Version** (Work in Progress)
- **Format**: `{library}-{dta_number}-draft{n}`
- **Example**: `1.0-DTA001-draft1`, `1.0-DTA001-draft2`
- **Purpose**: Editable working copies for a specific DTA
- **Characteristics**:
  - `is_major_version = FALSE`
  - `is_dta_major = FALSE`
  - Can have multiple sequential drafts (draft1, draft2, draft3...)
- **Lifecycle**: Created → Edited → Superseded → Closed

### 3. **DTA Major Version** (Approved DTA)
- **Format**: `{library}-{dta_number}-v{n}.0`
- **Example**: `1.0-DTA001-v1.0`, `1.0-DTA001-v2.0`
- **Purpose**: Approved, finalized version for a specific DTA
- **Characteristics**:
  - `is_major_version = FALSE`
  - `is_dta_major = TRUE`
  - Created when workflow approval completes
  - **Can be used as a source for new DTA branches** (reuse approved definitions)
- **Lifecycle**: Approved draft becomes DTA Major

---

## 🔄 Version Manager Operations

The `job_cdm_version_manager` supports five mutually exclusive operations using `condition_task` chain for true if-else branching:

### 1. `CREATE_BRANCH` - Start New DTA

**Trigger**: UI initiates new DTA creation

**Source Options** (user chooses one):
- **Library Major Version** (e.g., `1.0`, `2.0`) - Start from canonical standard
- **DTA Major Version** (e.g., `1.0-DTA001-v1.0`) - Reuse another DTA's approved definitions

**What it does**:
1. User selects source version (Library Major or DTA Major)
2. Copies all records from selected source
3. Creates new draft version (e.g., `1.0-DTA002-draft1`)
4. Registers version in `md_version_registry` with `parent_version` reference

**SCD Type 2**:
- Source records: Unchanged
- New draft records: `is_current = TRUE`, `effective_end_ts = NULL`

**Example 1: Branch from Library Major**

`Library v1.0` → **COPY** → `1.0-DTA001-draft1` *(parent_version = "1.0")*

**Example 2: Branch from DTA Major** (reuse approved DTA)

`1.0-DTA001-v1.0` → **COPY** → `1.0-DTA002-draft1` *(parent_version = "1.0-DTA001-v1.0")*

**Use Cases for DTA Major branching**:
- Similar trial needs same variable definitions
- Reuse vendor-specific customizations
- Start from a known-good configuration

---

### 2. `SAVE_DRAFT` - Save Changes

**Trigger**: User saves edits in the UI

**What it does**:
1. Closes current draft (set `is_current = FALSE`, `effective_end_ts = NOW()`)
2. Creates new draft with changes (e.g., `1.0-DTA001-draft2`)
3. Updates registry: old draft → `SUPERSEDED`, new draft → `ACTIVE`

**SCD Type 2**:
- Old draft: `is_current = FALSE`, `effective_end_ts = NOW()`
- New draft: `is_current = TRUE`, `effective_start_ts = NOW()`

`1.0-DTA001-draft1` → **SCD2 CLOSE** → `1.0-DTA001-draft2`
- Old: `is_current=FALSE`, `effective_end_ts` set
- New: `is_current=TRUE`, new records

**Note**: If a field value changes (e.g., `max_length: 20 → 50`), a new `definition_hash` is generated.

---

### 3. `APPROVE_DTA` - Promote Draft to DTA Major

**Trigger**: Workflow approval completes (all approvers in `DTA_APPROVAL_TASK` approve)

**What it does**:
1. Closes current draft
2. Creates DTA Major version (e.g., `1.0-DTA001-v1.0`)
3. Sets `is_dta_major = TRUE`
4. Updates DTA entity with `current_version_tag`

**SCD Type 2**:
- Draft: `is_current = FALSE`, `effective_end_ts = NOW()`
- DTA Major: `is_current = TRUE`, `is_dta_major = TRUE`

`1.0-DTA001-draft2` → **APPROVE** → `1.0-DTA001-v1.0` *(DTA Major, is_dta_major=TRUE)*

---

### 4. `CREATE_DTA_MAJOR` - Direct DTA Major Creation

**Trigger**: Historical data import or API call

**What it does**:
1. Creates DTA Major directly from silver data (skips draft phase)
2. Used for historical DTAs that are already approved
3. Registers version with `version_type = DTA_MAJOR`

**Use Case**: Processing historical tsDTA files that represent already-executed DTAs.

`Silver Data` → **DIRECT CREATE** → `1.0-DTA001-v1.0` *(DTA Major, is_dta_major=TRUE)*

---

### 5. `PROMOTE_TO_LIBRARY` - Merge All DTAs to Library Major

**Trigger**: Librarian role initiates promotion after review

**Authorization**: Requires **Librarian role** approval

**Key Behavior**: Automatically merges **ALL active DTA_MAJOR versions** into a new Library Major.

**What it does**:
1. Queries `md_version_registry` for all `version_type = 'DTA_MAJOR'` with `status = 'ACTIVE'`
2. Reads all records from `md_transfer_variables_library` for those versions
3. Merges records using the specified strategy (default: `UNION_DEDUP`)
4. Closes current Library Major (e.g., `1.0`) using SCD Type 2
5. Creates new Library Major (e.g., `2.0`) with merged content
6. Sets `is_major_version = TRUE` on new records
7. Updates `md_version_registry` with merge metadata

**SCD Type 2**:
- Old Library: `is_current = FALSE`, `effective_end_ts = NOW()`
- New Library: `is_current = TRUE`, `is_major_version = TRUE`

**Example: Automatic DTA Merge**

`1.0-DTA001-v1.0` + `1.0-DTA002-v1.0` + `1.0-DTA003-v1.0` → **PROMOTE** → `Library v2.0`

```mermaid
flowchart LR
    A["1.0-DTA001-v1.0<br/>(SubjectID=50)"] --> D
    B["1.0-DTA002-v1.0<br/>(Gender vals)"] --> D
    C["1.0-DTA003-v1.0<br/>(VisitType)"] --> D
    D{{"AUTO MERGE<br/>(UNION_DEDUP)"}} --> E["📚 Library v2.0"]
    
    style E fill:#dae8fc,stroke:#6c8ebf,stroke-width:2px
```

**No manual DTA selection required** - the system finds all active DTAs automatically.

---

## 📚 Library Major Promotion - The Merge Process

This section provides detailed information about how the Library Major version is created by merging all approved DTAs.

### When to Promote

Promote to Library Major when:
- Multiple DTAs have been approved and tested in production
- Standards need to be consolidated into a single canonical version
- A new baseline is needed for future DTA development

### The Promotion Flow

```mermaid
flowchart TD
    subgraph active["Active DTA Major Versions"]
        A["✅ 1.0-DTA001-v1.0<br/>85 records"]
        B["✅ 1.0-DTA002-v1.0<br/>90 records"]
        C["✅ 1.0-DTA003-v1.0<br/>85 records"]
    end
    
    D["📋 Query md_version_registry<br/>WHERE version_type='DTA_MAJOR'<br/>AND status='ACTIVE'"]
    
    A --> D
    B --> D
    C --> D
    
    D --> E["🔀 Merge Strategy<br/>(UNION_DEDUP)"]
    
    E --> F["📊 Deduplicate by<br/>definition_hash"]
    
    F --> G["📝 Close Old Library<br/>is_current=FALSE<br/>effective_end_ts=NOW()"]
    
    G --> H["📚 Create Library v2.0<br/>is_major_version=TRUE<br/>is_current=TRUE"]
    
    H --> I["📋 Update Registry<br/>Old Library: SUPERSEDED<br/>New Library: ACTIVE"]
    
    style A fill:#d5e8d4,stroke:#82b366
    style B fill:#d5e8d4,stroke:#82b366
    style C fill:#d5e8d4,stroke:#82b366
    style H fill:#dae8fc,stroke:#6c8ebf,stroke-width:3px
```

### Merge Strategies

| Strategy | Description | Use Case |
|----------|-------------|----------|
| `UNION_DEDUP` | Combine all records, deduplicate by `definition_hash` | **Default** - preserves unique definitions |
| `LATEST_WINS` | On duplicate `definition_hash`, use most recent DTA | Prefer newer standards |
| `FIRST_WINS` | On duplicate `definition_hash`, use earliest DTA | Preserve original definitions |

### How Deduplication Works

Records are deduplicated by `definition_hash`, which is computed from field content:

```
definition_hash = SHA256(
    transfer_variable_name + 
    data_type + 
    max_length + 
    required_flag + 
    codelist_reference + ...
)
```

**Example**: If DTA001 and DTA002 both have identical `SUBJECT_ID` definitions:
- Same `definition_hash` = merged into ONE record
- Different `definition_hash` = BOTH records included

### Registry Metadata After Merge

The `md_version_registry` stores merge information:

| Column | Value |
|--------|-------|
| `version_tag` | `2.0` |
| `version_type` | `LIBRARY_MAJOR` |
| `dta_id` | `NULL` (library versions have no DTA) |
| `parent_version` | `1.0-DTA001-v1.0,1.0-DTA002-v1.0,1.0-DTA003-v1.0` |
| `record_count` | 125 (deduplicated) |
| `status` | `ACTIVE` |

### Running the Promotion

**Via Test Job:**
```bash
databricks jobs run-now --job-name job_cdm_library_major_promote_test
```

**Via Version Manager:**
```bash
databricks jobs run-now --job-name job_cdm_version_manager \
  --job-parameters '{"action": "PROMOTE_TO_LIBRARY", "merge_strategy": "UNION_DEDUP"}'
```

### Post-Promotion Validation

Run these queries to verify the merge:

```sql
-- Check new library version
SELECT version_tag, status, record_count, created_ts
FROM gold_md.md_version_registry
WHERE version_type = 'LIBRARY_MAJOR'
ORDER BY created_ts DESC LIMIT 1;

-- Verify old library closed
SELECT library_version, is_current, effective_end_ts
FROM gold_md.md_transfer_variables_library
WHERE is_major_version = TRUE
GROUP BY library_version, is_current, effective_end_ts;
```

---

## 📋 Version Tag Format

| Version Type | Format | Example |
|--------------|--------|---------|
| Library Major | `{major}.0` | `1.0`, `2.0` |
| DTA Draft | `{library}-{dta_number}-draft{n}` | `1.0-DTA001-draft1` |
| DTA Major | `{library}-{dta_number}-v{n}.0` | `1.0-DTA001-v1.0` |

**Components**:
- `{library}`: Parent library version (e.g., `1.0`)
- `{dta_number}`: Sequential DTA identifier (e.g., `DTA001`, `DTA002`)
- `draft{n}`: Draft sequence number (1, 2, 3...)
- `v{n}.0`: Major version within the DTA

---

## 🗄️ Key Tables

### `md_transfer_variables_library`
The main versioned table using SCD Type 2:

| Column | Description |
|--------|-------------|
| `definition_hash` | Unique hash of field definition |
| `library_version` | Version tag (e.g., `1.0`, `1.0-DTA001-draft1`) |
| `is_major_version` | `TRUE` only for Library Major versions |
| `is_dta_major` | `TRUE` for approved DTA versions |
| `parent_version` | Version this was branched from |
| `effective_start_ts` | When this version became active |
| `effective_end_ts` | When this version was closed (`NULL` = active) |
| `is_current` | `TRUE` for the active version of each record |

### `md_version_registry`
Lightweight metadata for all versions:

| Column | Description |
|--------|-------------|
| `version_tag` | Unique version identifier |
| `version_type` | `LIBRARY_MAJOR`, `DTA_DRAFT`, or `DTA_MAJOR` |
| `dta_id` | Associated DTA (NULL for library versions) |
| `parent_version_tag` | Version this was derived from |
| `record_count` | Number of records in this version |
| `status` | `ACTIVE` or `SUPERSEDED` |

---

## 🔀 State Transitions

### Basic Flow (Branch from Library)

```mermaid
flowchart TD
    A["📚 Library v1.0<br/>(Canonical)"] 
    
    A -->|"CREATE_BRANCH"| B["1.0-DTA001-draft1"]
    A -->|"CREATE_BRANCH"| C["1.0-DTA002-draft1"]
    A -->|"CREATE_BRANCH"| D["1.0-DTA003-draft1"]
    
    B -->|"SAVE_DRAFT<br/>APPROVE_DTA"| E["✅ 1.0-DTA001-v1.0<br/>(Approved)"]
    C -->|"SAVE_DRAFT<br/>APPROVE_DTA"| F["✅ 1.0-DTA002-v1.0<br/>(Approved)"]
    D -->|"SAVE_DRAFT<br/>APPROVE_DTA"| G["✅ 1.0-DTA003-v1.0<br/>(Approved)"]
    
    E --> H{{"📚 PROMOTE_TO_LIBRARY<br/>(Librarian merges)"}}
    F --> H
    G --> H
    
    H --> I["📚 Library v2.0<br/>(Merged from DTAs)"]
    
    style A fill:#dae8fc,stroke:#6c8ebf,stroke-width:2px
    style E fill:#d5e8d4,stroke:#82b366
    style F fill:#d5e8d4,stroke:#82b366
    style G fill:#d5e8d4,stroke:#82b366
    style I fill:#dae8fc,stroke:#6c8ebf,stroke-width:3px
```

### Branch from DTA Major (Reuse Approved Definitions)

```mermaid
flowchart TD
    A["📚 Library v1.0"] -->|"CREATE_BRANCH"| B["✅ 1.0-DTA001-v1.0<br/>(DTA Major)<br/>Approved with custom definitions"]
    
    B -->|"CREATE_BRANCH<br/>(from DTA Major)"| C["📝 1.0-DTA004-draft1<br/>parent=DTA001<br/>Reusing DTA001's definitions"]
    
    style A fill:#dae8fc,stroke:#6c8ebf
    style B fill:#d5e8d4,stroke:#82b366,stroke-width:2px
    style C fill:#fff2cc,stroke:#d6b656
```

### Automatic DTA Merge to Library (Librarian Role)

The `PROMOTE_TO_LIBRARY` action automatically finds and merges all active DTAs:

```mermaid
flowchart TD
    subgraph approved["All Active DTA Majors (Auto-Discovered)"]
        A["✅ 1.0-DTA001-v1.0<br/>SubjectID=50"]
        B["✅ 1.0-DTA002-v1.0<br/>Gender=[M,F,O]"]
        C["✅ 1.0-DTA003-v1.0<br/>new VisitType"]
    end
    
    A --> D
    B --> D
    C --> D
    
    D["🔀 AUTO MERGE<br/>UNION_DEDUP<br/>Dedup by definition_hash"]
    
    D -->|"PROMOTE_TO_LIBRARY"| E["📚 Library v2.0<br/>• SubjectID=50<br/>• Gender=[M,F,O]<br/>• new VisitType"]
    
    style A fill:#d5e8d4,stroke:#82b366
    style B fill:#d5e8d4,stroke:#82b366
    style C fill:#d5e8d4,stroke:#82b366
    style D fill:#fff2cc,stroke:#d6b656,stroke-width:2px
    style E fill:#dae8fc,stroke:#6c8ebf,stroke-width:3px
```

**No manual DTA selection needed** - the system queries all active DTA_MAJORs automatically.

---

## 🔄 Parallel DTA Development

Multiple DTAs can work simultaneously without conflicts:

```mermaid
flowchart LR
    A["📚 Library v1.0"]
    
    A --> B["DTA_A: draft1"] --> C["draft2"] --> D["✅ v1.0<br/>(approved)"]
    A --> E["DTA_B: draft1"] --> F["draft2<br/>(still drafting)"]
    A --> G["DTA_C: draft1<br/>(just started)"]
    
    style A fill:#dae8fc,stroke:#6c8ebf
    style D fill:#d5e8d4,stroke:#82b366
    style F fill:#fff2cc,stroke:#d6b656
    style G fill:#fff2cc,stroke:#d6b656
```

**Key Points**:
- Each DTA has isolated version tags
- Changes in one DTA don't affect others
- Multiple DTAs can be promoted to library (incrementing version numbers)

---

## 🔍 Querying Versions

### Get Current Library Version
```sql
SELECT * FROM md_transfer_variables_library
WHERE is_major_version = TRUE AND is_current = TRUE
```

### Get Specific DTA's Current Draft
```sql
SELECT * FROM md_transfer_variables_library
WHERE library_version LIKE '%-DTA001-%' AND is_current = TRUE
```

### Get Point-in-Time Version
```sql
SELECT * FROM md_transfer_variables_library
WHERE library_version = '1.0'
  AND effective_start_ts <= '2025-01-15'
  AND (effective_end_ts IS NULL OR effective_end_ts > '2025-01-15')
```

### Get Version History
```sql
SELECT version_tag, version_type, status, created_ts
FROM md_version_registry
WHERE dta_id = 'DTA001'
ORDER BY created_ts
```

---

## 📁 Related Files

### Job Definitions
```
resources/data_engineering/clinical_data_standards/jobs/
└── job_cdm_version_manager.job.yml

resources/data_engineering/test/jobs/
└── job_cdm_library_major_promote_test.job.yml  # Test job for promotion
```

### Notebooks (by action)
```
notebooks/data_engineering/common/
├── nb_version_create_branch.ipynb    # CREATE_BRANCH
├── nb_version_save_draft.ipynb       # SAVE_DRAFT
├── nb_version_approve_dta.ipynb      # APPROVE_DTA / CREATE_DTA_MAJOR
└── nb_promote_to_library.ipynb       # PROMOTE_TO_LIBRARY (auto-merge all DTAs)
```

### Core Library
```
src/clinical_data_standards_framework/
└── versioning.py    # Core versioning functions including merge_dtas_to_library_major()
```

---

## 🔑 Design Principles

1. **Immutability**: Records are never updated in place; new versions are created
2. **Full History**: All changes are preserved with timestamps
3. **Isolation**: DTAs work in isolated version spaces
4. **Traceability**: Every version links to its parent via `parent_version`
5. **Atomic Operations**: Each operation is a complete, consistent state change


# Genie AI Integration Design

> **Status**: Implemented  
> **Last Updated**: December 2025

## Overview

This document describes the integration of Databricks Genie AI into the DTA Builder UI, enabling users to search for DTAs and clinical metadata using natural language queries.

---

## Architecture

```mermaid
flowchart LR
    subgraph "DTA Builder UI"
        UI[User Interface]
        Toggle[Search Mode Toggle]
        Results[Results Panel]
    end
    
    subgraph "Flask Backend"
        API["/api/genie/search"]
        Client[GenieClient]
    end
    
    subgraph "Databricks"
        SDK[Databricks SDK]
        Genie[Genie Space]
        Tables[(Unity Catalog Tables)]
    end
    
    UI --> Toggle
    Toggle -->|Standard| API
    Toggle -->|AI Search| API
    API --> Client
    Client --> SDK
    SDK --> Genie
    Genie --> Tables
    Tables --> Genie
    Genie --> SDK
    SDK --> Client
    Client --> API
    API --> Results
```

---

## Components

### 1. UI Components (`composer.html`)

#### Search Mode Toggle
```
[○ Standard Search]  [● AI Search with Genie] ✨
```

- **Standard Search**: Traditional SQL-based search with field matching
- **AI Search with Genie**: Natural language queries powered by Databricks Genie

#### Genie Response Panel
Displays:
- Genie's text response explaining the results
- Generated SQL query (expandable)
- Search results in DTA card format

### 2. Backend API (`api/genie_api.py`)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/genie/search` | GET | Send natural language query to Genie |
| `/api/genie/followup` | POST | Continue conversation with follow-up questions |
| `/api/genie/status` | GET | Check Genie configuration status |

### 3. Genie Wrapper (`api/genie.py`)

Uses `databricks_ai_bridge.genie` for clean API interaction:

```python
from api.genie import GenieWrapper, GenieResponse

genie = GenieWrapper(space_id)

# Ask initial question
response = genie.ask_first_question("Show me Labs DTAs")
result = genie.poll_result(response)  # Returns GenieResponse

# GenieResponse attributes:
# - result.description: Text explanation
# - result.query: Generated SQL
# - result.result: Markdown table results

# Follow-up questions
followup = genie.ask_followup_question("Filter by LabCorp", conversation_id)
followup_result = genie.poll_result(followup)
```

### 4. Configuration (`app.yaml`)

```yaml
env:
  - name: GENIE_SPACE_ID
    value: "your-genie-space-id"
  # Polling is handled internally by databricks-ai-bridge
```

---

## Genie Space Setup

### Prerequisites

1. Create a Genie Space in Databricks with the following tables:

| Table | Purpose |
|-------|---------|
| `gold_md.dta` | DTA entity records |
| `gold_md.dta_workflow` | Workflow tracking |
| `gold_md.md_version_registry` | Version registry |
| `gold_md.md_transfer_variables_library` | Approved variable definitions |
| `gold_md.dta_activity_log` | Audit history |
| `silver_md.md_transfer_variable_field_normalized` | Draft variables |

2. Configure the Genie Space with the table descriptions (from `sql/add_table_comments.sql`)

3. Set the `GENIE_SPACE_ID` environment variable

4. Install required dependencies (in `requirements.txt`):
   ```
   databricks-ai-bridge>=0.1.0
   ```

### Creating a Genie Space

1. Navigate to **Workspace** → **Genie** in Databricks
2. Click **Create Space**
3. Add the DTA tables from the catalog
4. Configure sample questions (optional)
5. Copy the Space ID and add to `app.yaml`

---

## Example Queries

| User Query | Genie Interprets As |
|------------|---------------------|
| "Show me the latest Labs DTA from LabCorp" | Find DTAs where `data_stream_type = 'Labs'` and `data_provider_name LIKE '%LabCorp%'` |
| "Which DTAs for trial VAC18193 are pending approval?" | Filter by `trial_id LIKE '%VAC18193%'` and `workflow_state = 'IN_REVIEW'` |
| "Find approved transfer variable definitions for ECG" | Query `md_transfer_variables_library` where `data_stream_type = 'ECG'` |
| "What changes were made to DTA001 this week?" | Query `dta_activity_log` for recent activity |
| "How many DTAs need manual review?" | Count DTAs where `status = 'MANUAL_REVIEW'` |

---

## Genie Training Sample Queries

Use these complete SQL queries to train your Genie space. They return DTAs with all metadata entity counts, enabling the UI to render complete DTA cards.

### Base Query Template

This is the complete query pattern that returns all data needed for UI card rendering:

```sql
-- Find approved DTAs with all metadata entity counts
SELECT 
    d.dta_id,
    d.dta_number,
    d.dta_name,
    d.trial_id,
    d.data_stream_type,
    d.data_provider_name,
    d.current_version_tag,
    d.workflow_state,
    d.status,
    d.last_updated_ts,
    -- Metadata entity counts from version registry
    COALESCE(tv.record_count, 0) AS transfer_variables_count,
    COALESCE(tc.record_count, 0) AS test_concepts_count,
    COALESCE(cl.record_count, 0) AS codelists_count,
    COALESCE(vt.record_count, 0) AS visits_timepoints_count,
    COALESCE(oa.record_count, 0) AS operational_agreements_count,
    COALESCE(dip.record_count, 0) AS data_ingestion_params_count
FROM aira_test.gold_md.dta d
LEFT JOIN aira_test.gold_md.md_version_registry tv 
    ON d.dta_id = tv.dta_id 
    AND tv.library_type = 'TRANSFER_VARIABLES' 
    AND tv.version_type = 'DTA_MAJOR' 
    AND tv.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry tc 
    ON d.dta_id = tc.dta_id 
    AND tc.library_type = 'TEST_CONCEPTS' 
    AND tc.version_type = 'DTA_MAJOR' 
    AND tc.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry cl 
    ON d.dta_id = cl.dta_id 
    AND cl.library_type = 'CODELISTS' 
    AND cl.version_type = 'DTA_MAJOR' 
    AND cl.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry vt 
    ON d.dta_id = vt.dta_id 
    AND vt.library_type = 'VISITS_TIMEPOINTS' 
    AND vt.version_type = 'DTA_MAJOR' 
    AND vt.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry oa 
    ON d.dta_id = oa.dta_id 
    AND oa.library_type = 'OPERATIONAL_AGREEMENTS' 
    AND oa.version_type = 'DTA_MAJOR' 
    AND oa.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry dip 
    ON d.dta_id = dip.dta_id 
    AND dip.library_type = 'DATA_INGESTION_PARAMS' 
    AND dip.version_type = 'DTA_MAJOR' 
    AND dip.status = 'ACTIVE'
WHERE d.workflow_state = 'APPROVED'
ORDER BY d.last_updated_ts DESC
LIMIT 10
```

### Sample Training Queries

#### 1. "Show all DTAs for trial VAC18193"

```sql
SELECT 
    d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type,
    d.data_provider_name, d.current_version_tag, d.workflow_state, d.status, d.last_updated_ts,
    COALESCE(tv.record_count, 0) AS transfer_variables_count,
    COALESCE(tc.record_count, 0) AS test_concepts_count,
    COALESCE(cl.record_count, 0) AS codelists_count,
    COALESCE(vt.record_count, 0) AS visits_timepoints_count,
    COALESCE(oa.record_count, 0) AS operational_agreements_count,
    COALESCE(dip.record_count, 0) AS data_ingestion_params_count
FROM aira_test.gold_md.dta d
LEFT JOIN aira_test.gold_md.md_version_registry tv 
    ON d.dta_id = tv.dta_id AND tv.library_type = 'TRANSFER_VARIABLES' AND tv.version_type = 'DTA_MAJOR' AND tv.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry tc 
    ON d.dta_id = tc.dta_id AND tc.library_type = 'TEST_CONCEPTS' AND tc.version_type = 'DTA_MAJOR' AND tc.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry cl 
    ON d.dta_id = cl.dta_id AND cl.library_type = 'CODELISTS' AND cl.version_type = 'DTA_MAJOR' AND cl.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry vt 
    ON d.dta_id = vt.dta_id AND vt.library_type = 'VISITS_TIMEPOINTS' AND vt.version_type = 'DTA_MAJOR' AND vt.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry oa 
    ON d.dta_id = oa.dta_id AND oa.library_type = 'OPERATIONAL_AGREEMENTS' AND oa.version_type = 'DTA_MAJOR' AND oa.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry dip 
    ON d.dta_id = dip.dta_id AND dip.library_type = 'DATA_INGESTION_PARAMS' AND dip.version_type = 'DTA_MAJOR' AND dip.status = 'ACTIVE'
WHERE d.workflow_state = 'APPROVED'
  AND UPPER(d.trial_id) LIKE '%VAC18193%'
ORDER BY d.last_updated_ts DESC
LIMIT 10
```

#### 2. "List all DTAs from Adaptive"

```sql
SELECT 
    d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type,
    d.data_provider_name, d.current_version_tag, d.workflow_state, d.status, d.last_updated_ts,
    COALESCE(tv.record_count, 0) AS transfer_variables_count,
    COALESCE(tc.record_count, 0) AS test_concepts_count,
    COALESCE(cl.record_count, 0) AS codelists_count,
    COALESCE(vt.record_count, 0) AS visits_timepoints_count,
    COALESCE(oa.record_count, 0) AS operational_agreements_count,
    COALESCE(dip.record_count, 0) AS data_ingestion_params_count
FROM aira_test.gold_md.dta d
LEFT JOIN aira_test.gold_md.md_version_registry tv 
    ON d.dta_id = tv.dta_id AND tv.library_type = 'TRANSFER_VARIABLES' AND tv.version_type = 'DTA_MAJOR' AND tv.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry tc 
    ON d.dta_id = tc.dta_id AND tc.library_type = 'TEST_CONCEPTS' AND tc.version_type = 'DTA_MAJOR' AND tc.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry cl 
    ON d.dta_id = cl.dta_id AND cl.library_type = 'CODELISTS' AND cl.version_type = 'DTA_MAJOR' AND cl.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry vt 
    ON d.dta_id = vt.dta_id AND vt.library_type = 'VISITS_TIMEPOINTS' AND vt.version_type = 'DTA_MAJOR' AND vt.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry oa 
    ON d.dta_id = oa.dta_id AND oa.library_type = 'OPERATIONAL_AGREEMENTS' AND oa.version_type = 'DTA_MAJOR' AND oa.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry dip 
    ON d.dta_id = dip.dta_id AND dip.library_type = 'DATA_INGESTION_PARAMS' AND dip.version_type = 'DTA_MAJOR' AND dip.status = 'ACTIVE'
WHERE d.workflow_state = 'APPROVED'
  AND UPPER(d.data_provider_name) LIKE '%ADAPTIVE%'
ORDER BY d.last_updated_ts DESC
LIMIT 10
```

#### 3. "Find DTAs for PF data stream"

```sql
SELECT 
    d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type,
    d.data_provider_name, d.current_version_tag, d.workflow_state, d.status, d.last_updated_ts,
    COALESCE(tv.record_count, 0) AS transfer_variables_count,
    COALESCE(tc.record_count, 0) AS test_concepts_count,
    COALESCE(cl.record_count, 0) AS codelists_count,
    COALESCE(vt.record_count, 0) AS visits_timepoints_count,
    COALESCE(oa.record_count, 0) AS operational_agreements_count,
    COALESCE(dip.record_count, 0) AS data_ingestion_params_count
FROM aira_test.gold_md.dta d
LEFT JOIN aira_test.gold_md.md_version_registry tv 
    ON d.dta_id = tv.dta_id AND tv.library_type = 'TRANSFER_VARIABLES' AND tv.version_type = 'DTA_MAJOR' AND tv.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry tc 
    ON d.dta_id = tc.dta_id AND tc.library_type = 'TEST_CONCEPTS' AND tc.version_type = 'DTA_MAJOR' AND tc.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry cl 
    ON d.dta_id = cl.dta_id AND cl.library_type = 'CODELISTS' AND cl.version_type = 'DTA_MAJOR' AND cl.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry vt 
    ON d.dta_id = vt.dta_id AND vt.library_type = 'VISITS_TIMEPOINTS' AND vt.version_type = 'DTA_MAJOR' AND vt.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry oa 
    ON d.dta_id = oa.dta_id AND oa.library_type = 'OPERATIONAL_AGREEMENTS' AND oa.version_type = 'DTA_MAJOR' AND oa.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry dip 
    ON d.dta_id = dip.dta_id AND dip.library_type = 'DATA_INGESTION_PARAMS' AND dip.version_type = 'DTA_MAJOR' AND dip.status = 'ACTIVE'
WHERE d.workflow_state = 'APPROVED'
  AND UPPER(d.data_stream_type) LIKE '%PF%'
ORDER BY d.last_updated_ts DESC
LIMIT 10
```

#### 4. "Show DTAs from Adaptive for PF data stream"

```sql
SELECT 
    d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type,
    d.data_provider_name, d.current_version_tag, d.workflow_state, d.status, d.last_updated_ts,
    COALESCE(tv.record_count, 0) AS transfer_variables_count,
    COALESCE(tc.record_count, 0) AS test_concepts_count,
    COALESCE(cl.record_count, 0) AS codelists_count,
    COALESCE(vt.record_count, 0) AS visits_timepoints_count,
    COALESCE(oa.record_count, 0) AS operational_agreements_count,
    COALESCE(dip.record_count, 0) AS data_ingestion_params_count
FROM aira_test.gold_md.dta d
LEFT JOIN aira_test.gold_md.md_version_registry tv 
    ON d.dta_id = tv.dta_id AND tv.library_type = 'TRANSFER_VARIABLES' AND tv.version_type = 'DTA_MAJOR' AND tv.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry tc 
    ON d.dta_id = tc.dta_id AND tc.library_type = 'TEST_CONCEPTS' AND tc.version_type = 'DTA_MAJOR' AND tc.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry cl 
    ON d.dta_id = cl.dta_id AND cl.library_type = 'CODELISTS' AND cl.version_type = 'DTA_MAJOR' AND cl.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry vt 
    ON d.dta_id = vt.dta_id AND vt.library_type = 'VISITS_TIMEPOINTS' AND vt.version_type = 'DTA_MAJOR' AND vt.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry oa 
    ON d.dta_id = oa.dta_id AND oa.library_type = 'OPERATIONAL_AGREEMENTS' AND oa.version_type = 'DTA_MAJOR' AND oa.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry dip 
    ON d.dta_id = dip.dta_id AND dip.library_type = 'DATA_INGESTION_PARAMS' AND dip.version_type = 'DTA_MAJOR' AND dip.status = 'ACTIVE'
WHERE d.workflow_state = 'APPROVED'
  AND UPPER(d.data_provider_name) LIKE '%ADAPTIVE%'
  AND UPPER(d.data_stream_type) LIKE '%PF%'
ORDER BY d.last_updated_ts DESC
LIMIT 10
```

#### 5. "What DTAs were created recently?"

```sql
SELECT 
    d.dta_id, d.dta_number, d.dta_name, d.trial_id, d.data_stream_type,
    d.data_provider_name, d.current_version_tag, d.workflow_state, d.status, d.last_updated_ts,
    COALESCE(tv.record_count, 0) AS transfer_variables_count,
    COALESCE(tc.record_count, 0) AS test_concepts_count,
    COALESCE(cl.record_count, 0) AS codelists_count,
    COALESCE(vt.record_count, 0) AS visits_timepoints_count,
    COALESCE(oa.record_count, 0) AS operational_agreements_count,
    COALESCE(dip.record_count, 0) AS data_ingestion_params_count
FROM aira_test.gold_md.dta d
LEFT JOIN aira_test.gold_md.md_version_registry tv 
    ON d.dta_id = tv.dta_id AND tv.library_type = 'TRANSFER_VARIABLES' AND tv.version_type = 'DTA_MAJOR' AND tv.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry tc 
    ON d.dta_id = tc.dta_id AND tc.library_type = 'TEST_CONCEPTS' AND tc.version_type = 'DTA_MAJOR' AND tc.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry cl 
    ON d.dta_id = cl.dta_id AND cl.library_type = 'CODELISTS' AND cl.version_type = 'DTA_MAJOR' AND cl.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry vt 
    ON d.dta_id = vt.dta_id AND vt.library_type = 'VISITS_TIMEPOINTS' AND vt.version_type = 'DTA_MAJOR' AND vt.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry oa 
    ON d.dta_id = oa.dta_id AND oa.library_type = 'OPERATIONAL_AGREEMENTS' AND oa.version_type = 'DTA_MAJOR' AND oa.status = 'ACTIVE'
LEFT JOIN aira_test.gold_md.md_version_registry dip 
    ON d.dta_id = dip.dta_id AND dip.library_type = 'DATA_INGESTION_PARAMS' AND dip.version_type = 'DTA_MAJOR' AND dip.status = 'ACTIVE'
WHERE d.workflow_state = 'APPROVED'
  AND d.last_updated_ts >= DATE_ADD(CURRENT_DATE(), -30)
ORDER BY d.last_updated_ts DESC
LIMIT 10
```

### Expected Output Columns for UI Cards

| Column | Used For |
|--------|----------|
| `dta_number` | Card header (DTA001, DTA002) |
| `dta_name` | DTA friendly name |
| `current_version_tag` | Version badge (1.0-DTA001-v1.0) |
| `trial_id` | Trial field |
| `data_stream_type` | Stream field |
| `data_provider_name` | Provider field |
| `workflow_state` | Status badge (APPROVED) |
| `last_updated_ts` | Date shown on card |
| `transfer_variables_count` | Icon with count (📊 85) |
| `test_concepts_count` | Icon with count |
| `codelists_count` | Icon with count |
| `visits_timepoints_count` | Icon with count |
| `operational_agreements_count` | Icon with count |
| `data_ingestion_params_count` | Icon with count |

---

## User Experience Flow

```mermaid
sequenceDiagram
    participant User
    participant UI as DTA Builder UI
    participant API as Flask API
    participant Genie as Databricks Genie
    
    User->>UI: Selects "AI Search with Genie"
    User->>UI: Types natural language question
    User->>UI: Clicks "Ask Genie"
    
    UI->>API: GET /api/genie/search?q=...
    API->>Genie: Start conversation
    Genie-->>API: Conversation ID
    
    API->>Genie: Send question
    Genie-->>API: Message ID
    
    loop Poll for response
        API->>Genie: Get message status
        Genie-->>API: Status (PENDING/COMPLETED)
    end
    
    Genie-->>API: Response (text + SQL + results)
    API-->>UI: Formatted response
    
    UI->>UI: Display Genie answer
    UI->>UI: Render DTA cards from results
```

---

## Error Handling

| Scenario | User Experience |
|----------|-----------------|
| Genie not configured | Toggle disabled with tooltip |
| Query too short | Alert message prompting more detail |
| Timeout | Error message with retry option |
| No results | Message suggesting query refinement |
| API error | Generic error with retry option |

---

## CSS Styling

The Genie integration uses a distinct visual style:

- **Purple gradient**: Indicates AI-powered functionality
- **Sparkle animation**: On the toggle label
- **Response panel**: Light purple gradient background
- **Loading spinner**: Animated during query processing

---

## Security Considerations

1. **Authentication**: Uses Databricks SDK with workspace credentials
2. **Authorization**: Respects Unity Catalog permissions on underlying tables
3. **Data Isolation**: Users only see data they have access to
4. **Audit Trail**: Genie conversations are logged in Databricks

---

## Future Enhancements

1. **Conversation History**: Save and resume Genie conversations
2. **Suggested Questions**: Pre-defined common queries
3. **Voice Input**: Microphone input for questions
4. **Multi-turn Conversations**: Follow-up questions in context
5. **Export Results**: Download Genie results as CSV/Excel

---

## Files Modified

| File | Changes |
|------|---------|
| `api/genie_api.py` | New file - Genie API endpoints |
| `templates/composer.html` | Search mode toggle + Genie response panel |
| `static/styles.css` | Genie-specific styles |
| `app.py` | Register genie_bp blueprint |
| `app.yaml` | Genie environment variables |

---

## Troubleshooting

### Genie toggle is disabled
- Check `GENIE_SPACE_ID` is set in `app.yaml`
- Verify the Space ID is correct and the space exists
- Check user has access to the Genie Space

### Query returns no results
- Verify the tables have data
- Check table permissions in Unity Catalog
- Try rephrasing the question

### Timeout errors
- Increase `GENIE_TIMEOUT` value
- Check Databricks cluster availability
- Simplify the query

---

*See also: [Schema Design](./02_schema_design.readme.md) for table descriptions used by Genie*


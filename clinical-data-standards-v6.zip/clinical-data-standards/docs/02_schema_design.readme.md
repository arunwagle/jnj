# DTA Schema - Detailed Diagram

> **Diagram**: [02_schema_design.drawio](./diagrams/02_schema_design.drawio)

## Overview

This document describes the complete database schema for the Clinical Data Standards DTA (Data Transfer Agreement) Management System, organized by the Medallion Architecture layers.

---

## 🏗️ Architecture Layers

```mermaid
flowchart LR
    subgraph Bronze["🟤 Bronze Layer"]
        A[Raw Data]
    end
    
    subgraph Silver["⚪ Silver Layer"]
        B[Normalized Data]
    end
    
    subgraph Gold["🟡 Gold Layer"]
        C[Business Entities]
    end
    
    A --> B --> C
    
    style Bronze fill:#FFE0B2,stroke:#E65100
    style Silver fill:#BBDEFB,stroke:#1565C0
    style Gold fill:#FFF59D,stroke:#F9A825
```

---

## 🟤 Bronze Layer (`bronze_md`)

Raw data ingestion and document tracking.

### `md_dta_history`
**Purpose**: Document manifest with extraction status and completion tracking.

| Column | Type | Description |
|--------|------|-------------|
| `document_id` | STRING | **PK** - Unique document identifier |
| `parent_document_id` | STRING | **FK** - Self-reference for parent ZIP |
| `zip_source_path` | STRING | Original ZIP file path |
| `extracted_path` | STRING | Extraction location |
| `content_base64` | STRING | Base64 encoded file content |
| `size_bytes` | LONG | File size |
| `file_extension` | STRING | File type extension |
| `document_tags` | ARRAY<STRING> | Classification tags (tsDTA, DTA, etc.) |
| `active` | BOOLEAN | Whether document is active |
| `current_status` | STRING | Processing status |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `total_documents_count` | INT | Total files in ZIP |
| `required_documents_count` | INT | Files requiring processing |
| `processed_documents_count` | INT | Processed file count |

### `md_document_status`
**Purpose**: Processing status tracking for each document.

| Column | Type | Description |
|--------|------|-------------|
| `document_id` | STRING | **PK** - References md_dta_history |
| `status` | STRING | Current processing status |
| `status_timestamp` | TIMESTAMP | When status changed |
| `error_message` | STRING | Error details if failed |
| `processing_duration_seconds` | DOUBLE | Processing time |
| `retry_count` | INT | Number of retry attempts |

### `md_dta_excel_file_raw`
**Purpose**: Excel sheet metadata for tsDTA files.

| Column | Type | Description |
|--------|------|-------------|
| `document_id` | STRING | **PK** - Unique sheet identifier |
| `parent_document_id` | STRING | **FK** - References parent Excel file |
| `sheet_name` | STRING | Excel sheet name |
| `sheet_index` | INT | Sheet position (0-based) |
| `sheet_category` | STRING | Categorized type (transfer_metadata, codelists, etc.) |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |

---

## ⚪ Silver Layer (`silver_md`)

Standardized and normalized data.

### `md_transfer_variable_field_normalized`
**Purpose**: Standardized transfer variable definitions from tsDTA.

| Column | Type | Description |
|--------|------|-------------|
| `transfer_variable_field_id` | STRING | **PK** - Unique record ID |
| `parent_document_id` | STRING | **FK** - References source document |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `transfer_variable_name` | STRING | Variable name |
| `transfer_variable_label` | STRING | Variable label |
| `variable_description` | STRING | Detailed description |
| `format` | STRING | Data type (text, numeric, date) |
| `anticipated_max_length` | INT | Maximum field length |
| `transfer_file_key` | BOOLEAN | Part of unique key |
| `populate_for_all_records` | BOOLEAN | Required for all records |
| `example_values` | STRING | Sample values |
| `codelist_values` | STRING | Associated codelist values |
| `definition_hash` | STRING | Hash for deduplication |
| `row_status` | STRING | COMPLETED or MANUAL_REVIEW_REQUIRED |
| `categorization_notes` | STRING | Processing notes |
| `transfer_file_order` | INT | Order in transfer file |

### `md_codelists_normalized`
**Purpose**: Standardized codelist values.

| Column | Type | Description |
|--------|------|-------------|
| `codelist_id` | STRING | **PK** - Unique codelist record ID |
| `parent_document_id` | STRING | **FK** - References source document |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `transfer_variable_name` | STRING | Associated variable |
| `codelist_reference` | STRING | Codelist identifier |
| `code_value` | STRING | Individual code value |
| `row_status` | STRING | Processing status |

---

## 🟡 Gold Layer (`gold_md`)

Business entities and versioned library.

### `dta`
**Purpose**: Core DTA entity representing a Data Transfer Agreement.

| Column | Type | Description |
|--------|------|-------------|
| `dta_id` | STRING | **PK** - UUID identifier |
| `dta_number` | STRING | Human-readable ID (DTA001, DTA002) |
| `trial_id` | STRING | Associated trial |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider |
| `status` | STRING | DRAFT, ACTIVE, MANUAL_REVIEW, ARCHIVED |
| `workflow_state` | STRING | NOT_STARTED, IN_REVIEW, APPROVED, REJECTED |
| `workflow_iteration` | INT | Current approval cycle |
| `current_version_tag` | STRING | **FK** - Active version in library |
| `notes` | STRING | General notes |

### `dta_workflow`
**Purpose**: Workflow cycle tracking for DTA approval.

| Column | Type | Description |
|--------|------|-------------|
| `dta_workflow_id` | STRING | **PK** - UUID identifier |
| `dta_id` | STRING | **FK** - References dta |
| `workflow_iteration` | INT | Iteration number (1, 2, 3...) |
| `workflow_status` | STRING | NOT_STARTED, IN_REVIEW, APPROVED, REJECTED |
| `summary_comment` | STRING | Workflow notes |
| `initiated_ts` | TIMESTAMP | When workflow started |
| `closed_ts` | TIMESTAMP | When workflow completed |

### `md_transfer_variables_library`
**Purpose**: SCD Type 2 versioned library of transfer variable definitions.

| Column | Type | Description |
|--------|------|-------------|
| `definition_hash` | STRING | **PK** - Unique definition hash |
| `library_version` | STRING | **PK** - Version tag (1.0, 1.0-DTA001-draft1) |
| `transfer_variable_name` | STRING | Variable name |
| `transfer_variable_label` | STRING | Variable label |
| `variable_description` | STRING | Detailed description |
| `format` | STRING | Data type |
| `anticipated_max_length` | INT | Maximum length |
| `codelist_values` | STRING | Associated codelists |
| `used_in_trials` | ARRAY<STRUCT> | Trial usage tracking |
| `usage_count` | INT | Usage frequency |
| **SCD Type 2 Columns** | | |
| `is_major_version` | BOOLEAN | TRUE for Library Major (1.0, 2.0) |
| `is_dta_major` | BOOLEAN | TRUE for DTA Major (1.0-DTA001-v1.0) |
| `parent_version` | STRING | Version branched from |
| `effective_start_ts` | TIMESTAMP | When version became active |
| `effective_end_ts` | TIMESTAMP | When superseded (NULL if current) |
| `is_current` | BOOLEAN | Active version flag |
| `completed_count` | INT | Count of COMPLETED records |
| `review_required_count` | INT | Count of MANUAL_REVIEW records |
| `needs_review` | BOOLEAN | TRUE if any source needs review |

### `md_version_registry`
**Purpose**: Lightweight metadata for all versions.

| Column | Type | Description |
|--------|------|-------------|
| `version_tag` | STRING | **PK** - Unique version identifier |
| `library_type` | STRING | transfer_variables, codelist |
| `version_type` | STRING | LIBRARY_MAJOR, DTA_MAJOR, DTA_DRAFT |
| `dta_id` | STRING | **FK** - Associated DTA (NULL for library major) |
| `parent_version` | STRING | Version branched from |
| `record_count` | INT | Number of records in version |
| `status` | STRING | ACTIVE, SUPERSEDED, ARCHIVED |

---

## 🔗 Relationships

```mermaid
erDiagram
    md_dta_history ||--o| md_document_status : "has status"
    md_dta_history ||--o{ md_dta_excel_file_raw : "contains sheets"
    md_dta_history ||--o{ md_transfer_variable_field_normalized : "produces"
    md_dta_history ||--o{ md_codelists_normalized : "produces"
    
    dta ||--o{ dta_workflow : "has workflows"
    dta ||--o{ md_version_registry : "owns versions"
    md_version_registry }|--|| md_transfer_variables_library : "references"
```

---

## 📋 Audit Columns

All tables include standard audit columns:

| Column | Type | Description |
|--------|------|-------------|
| `created_by_principal` | STRING | User who created the record |
| `created_ts` | TIMESTAMP | Record creation timestamp |
| `last_updated_by_principal` | STRING | User who last updated |
| `last_updated_ts` | TIMESTAMP | Last update timestamp |
| `databricks_job_id` | STRING | Job ID for lineage |
| `databricks_job_name` | STRING | Job name for lineage |
| `databricks_run_id` | STRING | Run ID for lineage |

---

## 🔑 Key Design Patterns

### 1. **Parent-Child Document Linking**
- `parent_document_id` links child documents to parent ZIPs
- Enables tracking of document lineage through extraction

### 2. **Trial Context**
- `trial_id`, `data_stream_type`, `data_provider_name` propagate through all layers
- Enables filtering and grouping by trial context

### 3. **SCD Type 2 Versioning**
- `effective_start_ts`, `effective_end_ts`, `is_current` enable point-in-time queries
- `library_version` + `definition_hash` form composite key

### 4. **Completion Tracking**
- `total_documents_count`, `required_documents_count`, `processed_documents_count`
- Enables completion gate pattern for orchestration

---

## 🤖 Genie AI Assistant Integration

This schema includes comprehensive table and column descriptions optimized for Databricks Genie AI Assistant. These descriptions enable natural language queries about DTAs, versioning, and approval workflows.

### Table Descriptions for Genie

#### 1. `dta` (Gold Layer)
> This table stores the core metadata for each Trial-Specific Data Transfer Agreement (tsDTA). Each record represents a unique data transfer contract between J&J and a data provider for a specific trial and data stream. The table includes identifiers for the trial and data stream, references to the parent document, the provider, the transfer type, and the current status of the DTA (e.g., Draft, Review, Approved). Version metadata and audit timestamps support governance and traceability. This table is the authoritative record of all active and historical DTAs used to drive ingestion rules and metadata validation.

#### 2. `dta_activity_log` (Gold Layer)
> This table captures the full audit history of all activities performed on the DTA and on related clinical metadata entities—including transfer variables, test concepts, code lists, visits, timepoints, ingestion parameters, and other metadata components. Each entry records the type of activity, the impacted entity, the old and new values, and the user who performed the action. It provides a detailed, field-level change history that supports compliance, auditing, and debugging of metadata updates.

#### 3. `dta_workflow` (Gold Layer)
> This table tracks the approval lifecycle for DTAs across all stakeholders involved in the metadata governance process. It models workflow steps between J&J reviewers, external data providers (vendors), and J&J librarians, who are responsible for promoting finalized metadata into the official library versions. The table captures workflow identifiers, statuses, and audit timestamps for initiation and updates. It provides the structured sequence of approval events required to move a DTA from Draft → Review → Approved → Published Metadata Library.

#### 4. `md_transfer_variables_library` (Gold Layer)
> This table stores the deduplicated, unified library of transfer variables used across all trials and data providers. While vendors may define the same variable differently across trials or data streams, this table contains a single, standardized definition per transfer variable for enterprise-wide use. It includes attributes such as variable names, definitions, formats, descriptions, associated code lists, and transfer order. This library serves as the harmonized reference model for downstream ingestion, documentation, governance, and metadata-driven processing.

#### 5. `md_version_registry` (Gold Layer)
> This table serves as the central registry for versioning of all DTA and clinical metadata library entities. It stores version tags, library or component type, publishing status, and contributor information. The registry supports SCD Type-2 style lifecycle management, ensuring governance, reproducibility, lineage tracking, and compliance across evolving metadata versions.

#### 6. `md_transfer_variable_field_normalized` (Silver Layer)
> This table stores the raw, non-deduplicated transfer variable definitions as provided across all trials, data streams, and vendors. Because multiple vendors may define the same variable differently, this table preserves the full variability of metadata coming from each source. Attributes include variable IDs, trial IDs, data stream types, provider names, and all vendor-specific variable characteristics. This table enables cross-trial harmonization analysis, vendor comparison, schema profiling, and preparation of data that feeds into the deduplicated md_transfer_variables_library.

---

### Purpose

The descriptions are designed to help Genie answer questions from three primary user groups:

1. **J&J Data Acquisition Experts (DAEs)** - DTA creation, workflow management, approval tracking
2. **Vendors/Data Providers** - Review drafts, add comments, understand variable requirements
3. **Librarians** - Version management, library promotion, canonical standards

### Enabled Query Types

With these descriptions, Genie can answer questions like:

| Question Type | Example |
|---------------|---------|
| **Finding DTAs** | "What is the latest DTA for trial VAC18193RSV3001 from LabCorp for Labs data?" |
| **Version Queries** | "Show me all approved major versions for transfer variables" |
| **Status Tracking** | "Which DTAs are currently pending approval?" |
| **Audit/History** | "What changes were made to DTA001 in the last week?" |
| **Cloning Source** | "Find the latest approved DTA for ECG data from Covance that I can clone" |

### Terminology in Descriptions

All descriptions use spelled-out business terms:

| Abbreviation | Full Term in Descriptions |
|--------------|---------------------------|
| DTA | Data Transfer Agreement |
| tsDTA | Trial-Specific Data Transfer Agreement |
| DAE | Data Acquisition Expert |
| OA | Operational Agreement |

### Key Tables for Genie Queries

```mermaid
flowchart TB
    subgraph "Primary Query Tables"
        DTA["gold_md.dta<br/>Find DTAs by trial/vendor/stream"]
        VER["gold_md.md_version_registry<br/>Find versions and lineage"]
        LIB["gold_md.md_transfer_variables_library<br/>Find approved variables"]
        ACT["gold_md.dta_activity_log<br/>Audit and history queries"]
    end
    
    subgraph "Supporting Tables"
        WF["gold_md.dta_workflow<br/>Approval cycle details"]
        DRAFT["silver_md.md_transfer_variable_field_normalized<br/>Draft variable details"]
    end
    
    DTA --> VER
    VER --> LIB
    DTA --> ACT
    DTA --> WF
    DTA --> DRAFT
```

---

*Last Updated: December 2025*


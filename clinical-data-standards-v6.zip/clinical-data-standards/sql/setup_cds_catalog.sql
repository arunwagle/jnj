
-- ============================================================================
-- Catalog and Schema Setup SQL
-- ============================================================================
-- Purpose: Create catalog, schemas, and volumes if they don't exist
-- Use Case: clinical_data_standards
--
-- Parameters (passed from job):
--   :catalog_name - The catalog to create/use
-- ============================================================================

-- Create catalog if it doesn't exist
CREATE CATALOG IF NOT EXISTS IDENTIFIER(:catalog_name)
COMMENT 'Catalog for clinical_data_standards use case';

-- Set current catalog
USE CATALOG IDENTIFIER(:catalog_name);

-- Create Bronze schema (raw/landing zone)
CREATE SCHEMA IF NOT EXISTS bronze_md
COMMENT 'Bronze layer - raw ingestion of Trial-Specific Data Transfer Agreement (tsDTA) files including ZIP archives, Excel documents, Operational Agreements (Word), and Protocol documents. Contains document manifest, extraction status, and Excel sheet metadata.';

-- Create Silver schema (cleaned/processed)
CREATE SCHEMA IF NOT EXISTS silver_md
COMMENT 'Silver layer - normalized draft data extracted from tsDTA files. Contains work-in-progress transfer variable definitions, codelists, test concepts, and visits/timepoints that are being reviewed by J&J Data Acquisition Experts (DAEs) and vendors before approval.';

-- Create Gold schema (curated metadata library)
CREATE SCHEMA IF NOT EXISTS gold_md
COMMENT 'Gold layer - approved Data Transfer Agreement (DTA) entities and versioned metadata library. Contains the DTA master table, workflow tracking, version registry, and approved transfer variable definitions. This is the source of truth for production data transfer specifications.';

-- ============================================================================
-- Create Volumes for file storage
-- ============================================================================
-- Volume for clinical data standards files (ZIP archives, Excel files, etc.)
-- Path: /Volumes/<catalog>/bronze_md/clinical_data_standards/
CREATE VOLUME IF NOT EXISTS bronze_md.clinical_data_standards
COMMENT 'Volume for clinical data standards files - ZIP archives, Excel files, documents';

-- ============================================================================
-- Create Gold Layer Tables
-- ============================================================================

-- DTA (Data Transfer Agreement) master table
-- Used by Genie for queries: "What is the latest DTA for trial X from vendor Y?"
CREATE TABLE IF NOT EXISTS gold_md.dta (
    dta_id STRING NOT NULL COMMENT 'Unique identifier (UUID) for this DTA. Primary key.',
    dta_number STRING NOT NULL COMMENT 'Human-readable DTA number (e.g., DTA001, DTA002). Auto-generated sequence.',
    dta_name STRING COMMENT 'User-friendly DTA name (e.g., VAC18193RSV3001_PF_Adaptive). Used for display in UI.',
    parent_document_id STRING COMMENT 'Reference to source document from which this DTA was created. Links to bronze layer.',
    trial_id STRING NOT NULL COMMENT 'Clinical trial identifier (e.g., VAC18193RSV3001). Foreign key to trial metadata.',
    data_stream_type STRING NOT NULL COMMENT 'Type of data stream: PF (Patient Flow), LB (Labs), AE (Adverse Events), etc.',
    data_provider_name STRING NOT NULL COMMENT 'Name of the external vendor providing the data (e.g., IQVIA, Adaptive, LabCorp).',
    status STRING NOT NULL COMMENT 'Current DTA status: DRAFT, PENDING_APPROVAL, APPROVED, PROMOTED, REJECTED.',
    workflow_state STRING NOT NULL COMMENT 'Workflow state: NOT_STARTED, IN_REVIEW, APPROVED, REJECTED.',
    workflow_iteration INT NOT NULL COMMENT 'Current approval cycle number. Increments when DTA is resubmitted after rejection.',
    current_version_tag STRING COMMENT 'Current version tag (e.g., 1.0-DTA001-draft1). Links to md_version_registry.',
    current_draft_version STRING COMMENT 'Current draft version tag. Same as current_version_tag for drafts.',
    latest_major_version STRING COMMENT 'Latest approved major version (e.g., 1.0-DTA001-v1.0). NULL until first approval.',
    base_library_version STRING COMMENT 'Library version this DTA was based on (e.g., 1.0). Links to md_version_registry.',
    notes STRING COMMENT 'Additional notes or comments about this DTA.',
    created_by_principal STRING NOT NULL COMMENT 'User who created this DTA. Email or service principal.',
    created_ts TIMESTAMP NOT NULL COMMENT 'Timestamp when DTA was created.',
    last_updated_by_principal STRING NOT NULL COMMENT 'User who last modified this DTA.',
    last_updated_ts TIMESTAMP NOT NULL COMMENT 'Timestamp of last modification.'
)
USING DELTA
COMMENT 'This table stores the core metadata for each Trial-Specific Data Transfer Agreement (tsDTA). Each record represents a unique data transfer contract between J&J and a data provider for a specific trial and data stream. The table includes identifiers for the trial and data stream, references to the parent document, the provider, the transfer type, and the current status of the DTA. Version metadata and audit timestamps support governance and traceability. This table is the authoritative record of all active and historical DTAs used to drive ingestion rules and metadata validation.';

-- DTA Workflow table - tracks approval lifecycle
-- Used by Genie for queries: "Which DTAs are pending approval?"
CREATE TABLE IF NOT EXISTS gold_md.dta_workflow (
    dta_workflow_id STRING NOT NULL COMMENT 'Unique identifier (UUID) for this workflow instance. Primary key.',
    dta_id STRING NOT NULL COMMENT 'Foreign key to dta.dta_id. Each DTA has one active workflow per iteration.',
    workflow_iteration INT NOT NULL COMMENT 'Approval cycle number. Starts at 1, increments on resubmission after rejection.',
    workflow_status STRING NOT NULL COMMENT 'Current workflow status: NOT_STARTED, IN_REVIEW, APPROVED, REJECTED.',
    summary_comment STRING COMMENT 'Summary comment or notes for this workflow iteration.',
    initiated_ts TIMESTAMP COMMENT 'Timestamp when workflow was initiated (DTA submitted for approval).',
    closed_ts TIMESTAMP COMMENT 'Timestamp when workflow was completed (all approvals done or rejected).',
    created_by_principal STRING NOT NULL COMMENT 'User who created this workflow record.',
    created_ts TIMESTAMP NOT NULL COMMENT 'Timestamp when workflow was created.',
    last_updated_by_principal STRING NOT NULL COMMENT 'User who last modified this workflow.',
    last_updated_ts TIMESTAMP NOT NULL COMMENT 'Timestamp of last modification.'
)
USING DELTA
COMMENT 'This table tracks the approval lifecycle for DTAs across all stakeholders involved in the metadata governance process. It models workflow steps between J&J reviewers, external data providers (vendors), and J&J librarians, who are responsible for promoting finalized metadata into the official library versions. It provides the structured sequence of approval events required to move a DTA from Draft to Review to Approved to Published Metadata Library.';

-- DTA Approval Task table - individual approval assignments
-- Used by Genie for queries: "Who needs to approve DTA001?"
CREATE TABLE IF NOT EXISTS gold_md.dta_approval_task (
    approval_task_id STRING NOT NULL COMMENT 'Unique identifier (UUID) for this approval task. Primary key.',
    dta_workflow_id STRING NOT NULL COMMENT 'Foreign key to dta_workflow.dta_workflow_id. Links task to workflow.',
    dta_id STRING NOT NULL COMMENT 'Foreign key to dta.dta_id. Denormalized for easier queries.',
    approver_role STRING NOT NULL COMMENT 'Role of the approver: JNJ_DAE (Data Acquisition Expert), VENDOR, LIBRARIAN.',
    assigned_to_principal STRING COMMENT 'Email of the user assigned to this task. NULL until assigned.',
    approval_status STRING NOT NULL COMMENT 'Task status: PENDING, APPROVED, REJECTED.',
    approval_order INT NOT NULL COMMENT 'Order in approval sequence. 1 = first approver, 2 = second, etc.',
    approval_comment STRING COMMENT 'Comment from approver when approving or rejecting.',
    approved_ts TIMESTAMP COMMENT 'Timestamp when task was approved or rejected.',
    created_by_principal STRING NOT NULL COMMENT 'User who created this task.',
    created_ts TIMESTAMP NOT NULL COMMENT 'Timestamp when task was created.',
    last_updated_by_principal STRING NOT NULL COMMENT 'User who last modified this task.',
    last_updated_ts TIMESTAMP NOT NULL COMMENT 'Timestamp of last modification.'
)
USING DELTA
COMMENT 'This table stores individual approval tasks within a DTA workflow. Each task represents one approvers responsibility to review and approve or reject the DTA. Tasks are assigned to specific users (JNJ DAE, Vendor contacts) and track their approval status. Multiple approvers can work in parallel, and all must approve before the DTA can be promoted to a Major version.';

-- DTA Activity Log table (comprehensive audit trail)
-- Used by Genie for audit queries: "What changes were made to DTA001 this week?"
CREATE TABLE IF NOT EXISTS gold_md.dta_activity_log (
    activity_id STRING NOT NULL COMMENT 'Unique identifier (UUID) for this activity record. Primary key.',
    dta_id STRING NOT NULL COMMENT 'Foreign key to dta.dta_id. All activities are associated with a specific Data Transfer Agreement.',
    activity_category STRING NOT NULL COMMENT 'High-level category: DATA_CHANGE (field modifications), WORKFLOW (approvals), STATUS_CHANGE (state transitions), VERSION (version operations).',
    activity_type STRING NOT NULL COMMENT 'Specific activity: INSERT, UPDATE, DELETE (data), APPROVED, REJECTED, SUBMITTED (workflow), DRAFT_CREATED, DTA_MAJOR_CREATED, PROMOTED_TO_LIBRARY (version).',
    library_type STRING COMMENT 'Metadata entity type affected: transfer_variables, test_concepts, codelists, visits_timepoints, metadata, data_ingestion_params, DTA.',
    entity_id STRING COMMENT 'Identifier of the specific entity modified (e.g., transfer_variable_order for variables). Used for drill-down.',
    entity_name STRING COMMENT 'Human-readable name of the entity (e.g., STUDYID for a variable). Used for display in history UI.',
    field_name STRING COMMENT 'Specific field that was modified (e.g., format, length, vendor_comment). NULL for non-field-level changes.',
    old_value STRING COMMENT 'Value before the change. NULL for inserts. Enables before/after comparison.',
    new_value STRING COMMENT 'Value after the change. NULL for deletes. Enables before/after comparison.',
    workflow_iteration INT COMMENT 'Approval cycle number for workflow events. Links to dta_workflow.workflow_iteration.',
    approver_role STRING COMMENT 'Role of the person for workflow events: jnj_dae (Data Acquisition Expert), vendor, librarian.',
    approver_name STRING COMMENT 'Name of the approver for workflow events. Used for audit and accountability.',
    comment STRING COMMENT 'Additional context or notes about the activity. May include rejection reasons or approval comments.',
    version_tag STRING COMMENT 'Version involved in version operations. Links to md_version_registry.version_tag.',
    parent_version STRING COMMENT 'Source version for version operations (branching, promotion). Shows version lineage.',
    activity_summary STRING NOT NULL COMMENT 'Human-readable description of the activity. Used for display in activity feeds and history panels.',
    performed_by_principal STRING NOT NULL COMMENT 'User identity who performed the action. Email or service principal. Used for audit and accountability.',
    performed_ts TIMESTAMP NOT NULL COMMENT 'Timestamp when the activity occurred. Used for chronological ordering and filtering.'
)
USING DELTA
COMMENT 'This table captures the full audit history of all activities performed on the DTA and on related clinical metadata entities—including transfer variables, test concepts, code lists, visits, timepoints, ingestion parameters, and other metadata components. Each entry records the type of activity, the impacted entity, the old and new values, and the user who performed the action. It provides a detailed, field-level change history that supports compliance, auditing, and debugging of metadata updates.';

-- Display setup summary
SELECT 
  '✅ Setup Complete' as status,
  :catalog_name as catalog,
  'bronze_md, silver_md, gold_md' as schemas_created,
  'bronze_md.clinical_data_standards' as volume_created,
  'gold_md.dta, gold_md.dta_workflow, gold_md.dta_approval_task, gold_md.dta_activity_log' as tables_created;

-- ============================================================================
-- NEXT STEPS: Add Table and Column Comments for Genie AI
-- ============================================================================
-- After tables are created by notebooks (DTA processing, version management),
-- run sql/add_table_comments.sql to add comprehensive descriptions for Genie.
--
-- These descriptions enable natural language queries like:
--   - "What is the latest DTA for trial X from vendor Y?"
--   - "Which DTAs are pending approval?"
--   - "Show me the transfer variables for Labs data stream"
--
-- See docs/02_schema_design.readme.md for full documentation.
-- ============================================================================


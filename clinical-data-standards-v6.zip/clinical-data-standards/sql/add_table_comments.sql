-- ============================================================================
-- Table and Column Comments for Databricks Genie AI Assistant
-- ============================================================================
-- Purpose: Add comprehensive descriptions to Silver and Gold layer tables
--          to enable Genie to answer natural language questions about DTAs
--
-- Usage: Run this script after initial table creation or schema changes
--        SET catalog_name = 'your_catalog';
--        Run all statements below
--
-- Tables Covered:
--   Silver Layer: md_transfer_variable_field_normalized
--   Gold Layer: dta, dta_workflow, md_version_registry, 
--               md_transfer_variables_library, dta_activity_log
-- ============================================================================

-- Set catalog (pass as parameter or replace with actual catalog name)
-- USE CATALOG IDENTIFIER(:catalog_name);

-- ============================================================================
-- SILVER LAYER: md_transfer_variable_field_normalized
-- ============================================================================

COMMENT ON TABLE silver_md.md_transfer_variable_field_normalized IS
'This table stores the raw, non-deduplicated transfer variable definitions as provided across all trials, data streams, and vendors. Because multiple vendors may define the same variable differently, this table preserves the full variability of metadata coming from each source. Attributes include variable IDs, trial IDs, data stream types, provider names, and all vendor-specific variable characteristics. This table enables cross-trial harmonization analysis, vendor comparison, schema profiling, and preparation of data that feeds into the deduplicated md_transfer_variables_library.';

-- Column comments for md_transfer_variable_field_normalized
ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN transfer_variable_id COMMENT 'Unique identifier (UUID) for this transfer variable record. Primary key.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN parent_document_id COMMENT 'Reference to the source tsDTA Excel document in bronze layer (md_dta_history.document_id). Used for lineage tracking.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN dta_id COMMENT 'Foreign key to the DTA entity (gold_md.dta.dta_id). Links this variable definition to its parent Data Transfer Agreement.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN trial_id COMMENT 'Clinical trial identifier (e.g., VAC18193RSV3001). Also known as study ID. Used to filter variables for a specific trial.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN data_stream_type COMMENT 'Type of clinical data being transferred (e.g., Labs, Adverse Events, Demographics, ECG, Biomarkers). Categorizes the data domain.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN data_provider_name COMMENT 'External vendor or data provider name (e.g., LabCorp, Covance, PPD). The organization sending data to J&J.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN transfer_variable_name COMMENT 'Technical name of the data element (e.g., STUDYID, SUBJID, VISITNUM). Must be unique within a DTA. Used for data mapping.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN codelist_values COMMENT 'Array of allowed values for coded variables. Contains the valid codelist entries that can appear in this field.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN transfer_variable_label COMMENT 'Human-readable label for the variable (e.g., Study Identifier, Subject ID, Visit Number). Used in reports and documentation.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN variable_description COMMENT 'Detailed description of the variable purpose, usage, and business rules. Helps data consumers understand the meaning.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN transfer_variable_order COMMENT 'Sequence number defining the display and processing order of variables within the DTA. Used to maintain consistent ordering.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN format COMMENT 'Data type specification (e.g., TEXT, NUMERIC, DATE, DATETIME). Defines how the variable value should be formatted.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN anticipated_max_length COMMENT 'Maximum character length allowed for this field. Used for validation and storage planning.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN populate_for_all_records COMMENT 'Indicates if this variable is required (TRUE) or optional (FALSE) for all data records. Required fields must be populated.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN transfer_file_key COMMENT 'Indicates if this variable is part of the unique key (TRUE) for identifying records. Key fields form the composite primary key.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN example_values COMMENT 'Sample values demonstrating expected format and content. Helps vendors understand the expected data.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN definition_hash COMMENT 'SHA-256 hash of the variable definition for deduplication. Identical definitions across DTAs share the same hash.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN categorization_notes COMMENT 'Processing notes from automated extraction, including warnings or issues that may need manual review.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN row_status COMMENT 'Processing status: COMPLETED (ready for approval) or MANUAL_REVIEW_REQUIRED (needs human verification). Filter for review tasks.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN vendor_comment COMMENT 'Comments added by the vendor during DTA review. Captures vendor feedback, clarifications, or concerns about the variable definition.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN version_tag COMMENT 'Version identifier linking to md_version_registry (e.g., 1.0-DTA001-draft1). Enables tracking of changes across draft iterations.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN version_status COMMENT 'Draft status: DRAFT (work in progress), APPROVED (ready for promotion). Indicates where this record is in the workflow.';

ALTER TABLE silver_md.md_transfer_variable_field_normalized 
ALTER COLUMN is_current_draft COMMENT 'TRUE if this is the active draft version of the variable. FALSE for superseded historical drafts.';


-- ============================================================================
-- GOLD LAYER: dta (Data Transfer Agreement)
-- ============================================================================

COMMENT ON TABLE gold_md.dta IS
'This table stores the core metadata for each Trial-Specific Data Transfer Agreement (tsDTA). Each record represents a unique data transfer contract between J&J and a data provider for a specific trial and data stream. The table includes identifiers for the trial and data stream, references to the parent document, the provider, the transfer type, and the current status of the DTA (e.g., Draft, Review, Approved). Version metadata and audit timestamps support governance and traceability. This table is the authoritative record of all active and historical DTAs used to drive ingestion rules and metadata validation.';

ALTER TABLE gold_md.dta 
ALTER COLUMN dta_id COMMENT 'Unique identifier (UUID) for this DTA. Primary key. Used to link to workflow, versions, and activity log.';

ALTER TABLE gold_md.dta 
ALTER COLUMN dta_number COMMENT 'Human-readable sequential DTA identifier (e.g., DTA001, DTA002). Generated automatically. Used for display and reference.';

ALTER TABLE gold_md.dta 
ALTER COLUMN dta_name COMMENT 'User-friendly name for the DTA. Format: {trial_id}_{data_stream_type}_{data_provider_name}. Editable by users for clarity.';

ALTER TABLE gold_md.dta 
ALTER COLUMN parent_document_id COMMENT 'Reference to source document for DTAs created from historical tsDTA files. NULL for UI-created DTAs. Used for lineage.';

ALTER TABLE gold_md.dta 
ALTER COLUMN trial_id COMMENT 'Clinical trial/study identifier (e.g., VAC18193RSV3001). Part of the unique business key for the DTA.';

ALTER TABLE gold_md.dta 
ALTER COLUMN data_stream_type COMMENT 'Category of clinical data (e.g., Labs, Adverse Events, ECG). Part of the unique business key for the DTA.';

ALTER TABLE gold_md.dta 
ALTER COLUMN data_provider_name COMMENT 'External vendor providing data (e.g., LabCorp, Covance). Part of the unique business key for the DTA.';

ALTER TABLE gold_md.dta 
ALTER COLUMN status COMMENT 'Overall DTA status: DRAFT (being created), ACTIVE (approved and in use), MANUAL_REVIEW (needs attention), ARCHIVED (no longer active).';

ALTER TABLE gold_md.dta 
ALTER COLUMN workflow_state COMMENT 'Current approval workflow state: NOT_STARTED, IN_REVIEW (pending approvals), APPROVED (all approvals complete), REJECTED (returned for revision).';

ALTER TABLE gold_md.dta 
ALTER COLUMN workflow_iteration COMMENT 'Current approval cycle number. Increments each time a DTA goes through the approval process. First submission is iteration 1.';

ALTER TABLE gold_md.dta 
ALTER COLUMN current_version_tag COMMENT 'Active version tag for this DTA. Points to the current draft (in Silver) or approved version (in Gold library). FK to md_version_registry.';

ALTER TABLE gold_md.dta 
ALTER COLUMN current_draft_version COMMENT 'Latest draft version tag in Silver layer (e.g., 1.0-DTA001-draft3). Used to find work-in-progress variable definitions.';

ALTER TABLE gold_md.dta 
ALTER COLUMN latest_major_version COMMENT 'Latest approved major version in Gold library (e.g., 1.0-DTA001-v1.0). NULL if never approved. Used for cloning.';

ALTER TABLE gold_md.dta 
ALTER COLUMN base_library_version COMMENT 'Library major version this DTA branched from (e.g., 1.0). NULL if created from scratch. Used for version lineage.';

ALTER TABLE gold_md.dta 
ALTER COLUMN notes COMMENT 'General notes about the DTA. May include creation context, special handling instructions, or historical information.';


-- ============================================================================
-- GOLD LAYER: dta_workflow
-- ============================================================================

COMMENT ON TABLE gold_md.dta_workflow IS
'This table tracks the approval lifecycle for DTAs across all stakeholders involved in the metadata governance process. It models workflow steps between J&J reviewers, external data providers (vendors), and J&J librarians, who are responsible for promoting finalized metadata into the official library versions. The table captures workflow identifiers, statuses, and audit timestamps for initiation and updates. It provides the structured sequence of approval events required to move a DTA from Draft to Review to Approved to Published Metadata Library.';

ALTER TABLE gold_md.dta_workflow 
ALTER COLUMN dta_workflow_id COMMENT 'Unique identifier (UUID) for this workflow iteration. Primary key.';

ALTER TABLE gold_md.dta_workflow 
ALTER COLUMN dta_id COMMENT 'Foreign key to dta.dta_id. Links this workflow record to its parent DTA.';

ALTER TABLE gold_md.dta_workflow 
ALTER COLUMN workflow_iteration COMMENT 'Iteration number (1, 2, 3...). First submission is 1, resubmission after rejection is 2, etc.';

ALTER TABLE gold_md.dta_workflow 
ALTER COLUMN workflow_status COMMENT 'Final status of this iteration: NOT_STARTED, IN_REVIEW, APPROVED, REJECTED. Only the current iteration is active.';

ALTER TABLE gold_md.dta_workflow 
ALTER COLUMN summary_comment COMMENT 'Overall summary or notes for this workflow cycle. May include rejection reasons or approval notes.';

ALTER TABLE gold_md.dta_workflow 
ALTER COLUMN initiated_ts COMMENT 'Timestamp when this workflow iteration started (DTA submitted for approval).';

ALTER TABLE gold_md.dta_workflow 
ALTER COLUMN closed_ts COMMENT 'Timestamp when this workflow iteration completed (approved, rejected, or cancelled). NULL if still active.';


-- ============================================================================
-- GOLD LAYER: md_version_registry
-- ============================================================================

COMMENT ON TABLE gold_md.md_version_registry IS
'This table serves as the central registry for versioning of all DTA and clinical metadata library entities. It stores version tags, library or component type, publishing status, and contributor information. The registry supports SCD Type-2 style lifecycle management, ensuring governance, reproducibility, lineage tracking, and compliance across evolving metadata versions.';

ALTER TABLE gold_md.md_version_registry 
ALTER COLUMN version_tag COMMENT 'Unique version identifier. Format varies by type: "1.0" (Library Major), "1.0-DTA001-v1.0" (DTA Major), "1.0-DTA001-draft1" (Draft). Primary key.';

ALTER TABLE gold_md.md_version_registry 
ALTER COLUMN library_type COMMENT 'Type of metadata library: transfer_variables, codelists, test_concepts, visits_timepoints, operational_agreements, data_ingestion_params.';

ALTER TABLE gold_md.md_version_registry 
ALTER COLUMN version_type COMMENT 'Version level: LIBRARY_MAJOR (canonical), DTA_MAJOR (approved DTA), DTA_DRAFT (work in progress). Use for filtering.';

ALTER TABLE gold_md.md_version_registry 
ALTER COLUMN is_latest_major COMMENT 'TRUE if this is the most recent Library Major version. Only one version per library_type has this set to TRUE.';

ALTER TABLE gold_md.md_version_registry 
ALTER COLUMN dta_id COMMENT 'Foreign key to dta.dta_id for DTA versions. NULL for Library Major versions. Links version to its owning DTA.';

ALTER TABLE gold_md.md_version_registry 
ALTER COLUMN dta_trial_id COMMENT 'Denormalized trial ID from the DTA. Enables filtering versions by trial without joining to dta table.';

ALTER TABLE gold_md.md_version_registry 
ALTER COLUMN dta_stream_type COMMENT 'Denormalized data stream type from the DTA. Enables filtering versions by stream without joining.';

ALTER TABLE gold_md.md_version_registry 
ALTER COLUMN dta_provider_name COMMENT 'Denormalized vendor name from the DTA. Enables filtering versions by vendor without joining.';

ALTER TABLE gold_md.md_version_registry 
ALTER COLUMN parent_version COMMENT 'Version this was branched or promoted from. Forms version lineage tree. NULL for first Library Major version.';

ALTER TABLE gold_md.md_version_registry 
ALTER COLUMN record_count COMMENT 'Number of records in this version. Quick reference for version size without querying the library table.';

ALTER TABLE gold_md.md_version_registry 
ALTER COLUMN status COMMENT 'Version lifecycle status: ACTIVE (current), SUPERSEDED (replaced by newer), ARCHIVED (no longer relevant).';

ALTER TABLE gold_md.md_version_registry 
ALTER COLUMN notes COMMENT 'Notes about this version. May include creation context, promotion notes, or special handling information.';


-- ============================================================================
-- GOLD LAYER: md_transfer_variables_library
-- ============================================================================

COMMENT ON TABLE gold_md.md_transfer_variables_library IS
'This table stores the deduplicated, unified library of transfer variables used across all trials and data providers. While vendors may define the same variable differently across trials or data streams, this table contains a single, standardized definition per transfer variable for enterprise-wide use. It includes attributes such as variable names, definitions, formats, descriptions, associated code lists, and transfer order. This library serves as the harmonized reference model for downstream ingestion, documentation, governance, and metadata-driven processing.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN definition_hash COMMENT 'SHA-256 hash of the variable definition. Part of composite key with library_version. Same hash across versions means identical definition.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN library_version COMMENT 'Version tag from md_version_registry. Part of composite key. Format: "1.0" (Library Major), "1.0-DTA001-v1.0" (DTA Major).';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN transfer_variable_name COMMENT 'Technical name of the data element (e.g., STUDYID, SUBJID). Matches the expected column name in data transfers.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN transfer_variable_label COMMENT 'Human-readable label for the variable. Used in reports, documentation, and user interfaces.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN format COMMENT 'Data type specification (TEXT, NUMERIC, DATE, DATETIME). Defines expected format for incoming data.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN anticipated_max_length COMMENT 'Maximum character length for the field. Used for validation of incoming data.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN transfer_file_key COMMENT 'TRUE if this variable is part of the unique record key. Key variables identify individual records.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN populate_for_all_records COMMENT 'TRUE if this is a required field that must be populated for every record. FALSE for optional fields.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN codelist_values COMMENT 'Array of valid values for coded fields. NULL for free-text fields. Used for data validation.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN variable_description COMMENT 'Detailed description of variable purpose and business rules. Reference documentation for data consumers.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN example_values COMMENT 'Sample values showing expected format. Helps vendors understand requirements.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN row_status COMMENT 'Quality status: COMPLETED (verified), MANUAL_REVIEW_REQUIRED (needs verification). Use for data quality filtering.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN dta_id COMMENT 'Source DTA for DTA Major versions. NULL for Library Major versions. Links to originating DTA.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN version_tag COMMENT 'Copy of library_version for convenience. Matches md_version_registry.version_tag.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN transfer_variable_order COMMENT 'Display/processing order of the variable. Maintains consistent ordering across uses.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN vendor_comment COMMENT 'Vendor feedback captured during DTA review. Historical record of vendor input.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN is_major_version COMMENT 'TRUE for Library Major versions (1.0, 2.0). These are canonical production versions.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN is_dta_major COMMENT 'TRUE for DTA Major versions (1.0-DTA001-v1.0). These are approved DTA-specific versions.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN parent_version COMMENT 'Version this record originated from. Enables version lineage tracking.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN effective_start_ts COMMENT 'SCD Type 2: When this version became effective. Used for point-in-time queries.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN effective_end_ts COMMENT 'SCD Type 2: When this version was superseded. NULL for current versions.';

ALTER TABLE gold_md.md_transfer_variables_library 
ALTER COLUMN is_current COMMENT 'TRUE for the currently active version of this variable. Use for finding latest definitions.';


-- ============================================================================
-- GOLD LAYER: dta_activity_log (already has some comments, enhancing)
-- ============================================================================

COMMENT ON TABLE gold_md.dta_activity_log IS
'This table captures the full audit history of all activities performed on the DTA and on related clinical metadata entities—including transfer variables, test concepts, code lists, visits, timepoints, ingestion parameters, and other metadata components. Each entry records the type of activity, the impacted entity, the old and new values, and the user who performed the action. It provides a detailed, field-level change history that supports compliance, auditing, and debugging of metadata updates.';

-- Update column comments for dta_activity_log
ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN activity_id COMMENT 'Unique identifier (UUID) for this activity record. Primary key.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN dta_id COMMENT 'Foreign key to dta.dta_id. All activities are associated with a specific DTA.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN activity_category COMMENT 'High-level category: DATA_CHANGE (field modifications), WORKFLOW (approvals), STATUS_CHANGE (state transitions), VERSION (version operations).';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN activity_type COMMENT 'Specific activity: INSERT, UPDATE, DELETE (data), APPROVED, REJECTED, SUBMITTED (workflow), DRAFT_CREATED, DTA_MAJOR_CREATED, PROMOTED_TO_LIBRARY (version).';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN library_type COMMENT 'Metadata entity type affected: transfer_variables, test_concepts, codelists, visits_timepoints, metadata, data_ingestion_params, DTA.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN entity_id COMMENT 'Identifier of the specific entity modified (e.g., transfer_variable_order for variables). Used for drill-down.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN entity_name COMMENT 'Human-readable name of the entity (e.g., STUDYID for a variable). Used for display in history UI.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN field_name COMMENT 'Specific field that was modified (e.g., format, length, vendor_comment). NULL for non-field-level changes.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN old_value COMMENT 'Value before the change. NULL for inserts. Enables before/after comparison.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN new_value COMMENT 'Value after the change. NULL for deletes. Enables before/after comparison.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN workflow_iteration COMMENT 'Approval cycle number for workflow events. Links to dta_workflow.workflow_iteration.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN approver_role COMMENT 'Role of the person for workflow events: jnj_dae (Data Acquisition Expert), vendor, librarian.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN approver_name COMMENT 'Name of the approver for workflow events. Used for audit and accountability.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN comment COMMENT 'Additional context or notes about the activity. May include rejection reasons or approval comments.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN version_tag COMMENT 'Version involved in version operations. Links to md_version_registry.version_tag.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN parent_version COMMENT 'Source version for version operations (branching, promotion). Shows version lineage.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN activity_summary COMMENT 'Human-readable description of the activity. Used for display in activity feeds and history panels.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN performed_by_principal COMMENT 'User identity who performed the action. Email or service principal. Used for audit and accountability.';

ALTER TABLE gold_md.dta_activity_log 
ALTER COLUMN performed_ts COMMENT 'Timestamp when the activity occurred. Used for chronological ordering and filtering.';


-- ============================================================================
-- Verification Query
-- ============================================================================
SELECT 
  '✅ Comments Added' as status,
  'silver_md.md_transfer_variable_field_normalized' as table1,
  'gold_md.dta' as table2,
  'gold_md.dta_workflow' as table3,
  'gold_md.md_version_registry' as table4,
  'gold_md.md_transfer_variables_library' as table5,
  'gold_md.dta_activity_log' as table6;


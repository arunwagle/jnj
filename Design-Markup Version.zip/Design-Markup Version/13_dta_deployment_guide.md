# 13. DTA Deployment Guide

Complete guide for deploying the Clinical Data Standards (DTA) application to Databricks workspaces using Databricks Asset Bundles.

## Table of Contents

1. [Purpose](#1-purpose)
2. [DTA Framework using Databricks Asset Bundle](#2-dta-framework-using-databricks-asset-bundle)
   - [What is Databricks Asset Bundle (DAB)?](#what-is-databricks-asset-bundle-dab)
   - [DAB in the DTA Project](#dab-in-the-dta-project)
   - [Key Benefits for DTA](#key-benefits-for-dta)
   - [Project Structure](#project-structure)
3. [DTA Configuration](#3-dta-configuration)
   - [3.1 Databricks Bundle Configuration (`databricks.yml`)](#31-databricks-bundle-configuration-databricksyml)
     - [3.1.1 `bundle` Node](#311-bundle-node)
     - [3.1.2 `artifacts` Node](#312-artifacts-node)
     - [3.1.3 `include` Node](#313-include-node)
     - [3.1.4 `variables` Node](#314-variables-node)
     - [3.1.5 `targets` Node](#315-targets-node)
   - [3.2 Application Configuration (`clinical_data_standards.yaml`)](#32-application-configuration-clinical_data_standardsyaml)
     - [3.2.1 `globals` Section](#321-globals-section)
     - [3.2.2 `services` Section](#322-services-section)
     - [3.2.3 `pipelines` Section](#323-pipelines-section)
     - [3.2.4 `streaming` Section](#324-streaming-section)
     - [3.2.5 `versioning` Section](#325-versioning-section)
     - [3.2.6 `export` Section](#326-export-section)
   - [Configuration File Relationship](#configuration-file-relationship)
4. [Environment Setup](#4-environment-setup)
   - [4.1 Prerequisites](#41-prerequisites)
   - [4.2 Developer Setup](#42-developer-setup)
     - [Step 1: Authenticate with Databricks](#step-1-authenticate-with-databricks)
     - [Step 2: Clone Repository](#step-2-clone-repository)
     - [Step 3: Validate Bundle](#step-3-validate-bundle)
     - [Step 4: Deploy to Dev](#step-4-deploy-to-dev)
     - [Step 5: Deploy Flask App (Using Helper Script)](#step-5-deploy-flask-app-using-helper-script)
     - [Step 6: Run Initialization Jobs](#step-6-run-initialization-jobs)
     - [Destroy Application](#destroy-application)
   - [4.3 Staging and Production Setup](#43-staging-and-production-setup)
5. [DTA Application Initialization](#5-dta-application-initialization)
   - [Initialization Sequence](#initialization-sequence)
   - [5.1 Job: `job_test_cdm_cleanup`](#51-job-job_test_cdm_cleanup)
   - [5.2 Job: `job_cdm_sql_setup`](#52-job-job_cdm_sql_setup)
   - [5.3 Job: `job_populate_config_cache`](#53-job-job_populate_config_cache)
   - [5.4 Job: `job_cdm_sql_load_reference_data`](#54-job-job_cdm_sql_load_reference_data)
   - [5.5 Job: `job_cdm_app_permissions`](#55-job-job_cdm_app_permissions)
   - [5.6 Deploy Flask App](#56-deploy-flask-app)
   - [Quick Initialization Script](#quick-initialization-script)
6. [Troubleshooting](#6-troubleshooting)
   - [Common Issues](#common-issues)
   - [Rollback](#rollback)
7. [Best Practices](#7-best-practices)
8. [Support](#8-support)
9. [Related Documentation](#9-related-documentation)

---

## 1. Purpose

This deployment guide provides comprehensive instructions for deploying and initializing the Clinical Data Standards (DTA) application across different environments (Dev, Staging, Production). The guide covers:

- **Infrastructure Setup**: Using Databricks Asset Bundles (DAB) for reproducible deployments
- **Configuration Management**: Understanding and customizing the `databricks.yml` configuration
- **Application Initialization**: Running prerequisite jobs to prepare the environment
- **Environment-Specific Deployments**: Dev, Staging, and Production setup procedures

**Target Audience**: Data Engineers, DevOps Engineers, Platform Administrators

**Prerequisites**: 
- Familiarity with Databricks workspaces
- Basic understanding of Unity Catalog (catalogs, schemas, volumes)
- Access to appropriate Databricks workspace permissions

---

## 2. DTA Framework using Databricks Asset Bundle

### What is Databricks Asset Bundle (DAB)?

Databricks Asset Bundle is a deployment framework that enables:
- **Infrastructure as Code**: Define all Databricks resources in YAML files
- **Multi-Environment Deployment**: Consistent deployments across dev/staging/prod
- **Version Control**: Track infrastructure changes in Git
- **Atomic Deployments**: Deploy entire application stack in one command
- **Resource Management**: Automatic lifecycle management of jobs, pipelines, apps, and notebooks

![Databricks Asset Bundle Workflow](./diagrams/13_dab_workflow.png)

**Figure**: Databricks Asset Bundle development and deployment workflow showing local development, version control, CI/CD integration, and multi-environment deployment.

### DAB in the DTA Project

The DTA project uses DAB to manage:

| Resource Type | Count | Purpose |
|---------------|-------|---------|
| **Workflows (Jobs)** | 15+ | Data processing, setup, cleanup, testing |
| **Apps** | 1 | Flask-based management UI |
| **Artifacts** | 1 | Python wheel package for framework code |

### Key Benefits for DTA

1. **Single Command Deployment**: Deploy all resources with `databricks bundle deploy`
2. **Environment Isolation**: Separate dev/staging/prod with unique catalogs
3. **Reproducible Builds**: Same codebase deploys consistently across environments
4. **Permission Management**: Centralized access control in YAML
5. **Rollback Support**: Revert to previous deployment states

### Project Structure

```
clinical-data-standards/
├── databricks.yml              # Main bundle configuration
├── resources/                  # Resource definitions
│   ├── data_engineering/       # Data engineering jobs
│   │   ├── clinical_data_standards/jobs/
│   │   ├── common/jobs/
│   │   └── test/jobs/
│   ├── sql/                    # SQL setup jobs
│   │   ├── common/jobs/
│   │   └── test/jobs/
│   └── apps/                   # Flask application
├── notebooks/                  # Databricks notebooks
├── sql/                        # SQL scripts
├── src/                        # Python framework code
└── apps/                       # Flask app source
```

---

## 3. DTA Configuration

The DTA application uses two configuration files that work together:

1. **`databricks.yml`**: Databricks Asset Bundle configuration for deployment and infrastructure
2. **`config/clinical_data_standards.yaml`**: Application-specific configuration for data processing pipelines

---

### 3.1 Databricks Bundle Configuration (`databricks.yml`)

The `databricks.yml` file defines the infrastructure and deployment settings for the DAB framework.

#### Configuration File Structure

```yaml
databricks.yml
├── bundle                      # Project identity
├── artifacts                   # Wheel packages to build/deploy
├── include                     # Resource files to include
├── variables                   # Reusable configuration values
└── targets                     # Environment-specific settings
```

#### 3.1.1 `bundle` Node

**Purpose**: Defines the project identity and metadata.

```yaml
bundle:
  name: clinical-data-standards
  uuid: a671c688-a7fb-4ed7-9577-cb94c14a6653
```

| Field | Description | Value |
|-------|-------------|-------|
| `name` | Project identifier | `clinical-data-standards` |
| `uuid` | Unique bundle identifier (auto-generated) | `a671c688-a7fb-4ed7-9577-cb94c14a6653` |

#### 3.1.2 `artifacts` Node

**Purpose**: Defines Python wheel packages to build and deploy.

```yaml
artifacts:
  clinical_data_standards_framework:
    type: whl
    path: .
```

| Field | Description | Value |
|-------|-------------|-------|
| `type` | Artifact type | `whl` (Python wheel) |
| `path` | Source directory for `setup.py` | `.` (project root) |

**What it does**:
- Builds the Python wheel from `setup.py`
- Uploads the wheel to workspace `/Workspace/Users/{user}/.bundles/{bundle}/{target}/files/`
- Makes framework code available to notebooks and jobs

#### 3.1.3 `include` Node

**Purpose**: Specifies YAML files to include in the bundle (jobs, apps).

```yaml
include:
  - resources/sql/**/jobs/*.yml              # SQL setup jobs
  - resources/data_engineering/**/jobs/*.yml # Data engineering jobs
  - resources/apps/*.yml                      # Flask app
```

**What it does**: Recursively includes all `.yml` files matching the patterns, which define:
- **Jobs**: Workflow definitions
- **Apps**: Databricks Apps (Flask UI)

#### 3.1.4 `variables` Node

**Purpose**: Defines reusable variables for all environments (can be overridden per target).

```yaml
variables:
  usecase:
    description: Use case identifier
    default: "clinical_data_standards"
  
  catalog:
    description: Unity Catalog name
    default: "aira"
  
  bronze_schema:
    description: Schema for bronze layer
    default: "bronze_md"
  
  silver_schema:
    description: Schema for silver layer
    default: "silver_md"
  
  gold_schema:
    description: Schema for gold layer
    default: "gold_md"
  
  use_serverless:
    description: Use serverless compute
    default: Y
  
  warehouse_id:
    description: SQL Warehouse ID for SQL execution
    default: "148ccb90800933a1"
  
  user_email:
    description: User email for notifications and permissions
    default: "arun.wagle@databricks.com"
  
  historical_upload_root:
    description: Path for historical batch imports
    default: "test/historical_data/uploads"
```

##### Key Variables Explained

| Variable | Purpose | Used By |
|----------|---------|---------|
| `catalog` | Unity Catalog name | All jobs/pipelines accessing tables |
| `bronze_schema` | Bronze layer schema | Ingestion pipelines, raw data storage |
| `silver_schema` | Silver layer schema | Draft versions, intermediate processing |
| `gold_schema` | Gold layer schema | Approved DTAs, production-ready data |
| `warehouse_id` | SQL Warehouse ID | SQL tasks in jobs |
| `use_serverless` | Serverless toggle | Job compute selection |
| `historical_upload_root` | Upload path | File arrival trigger for batch imports |

**SQL Job Dependency**: Many jobs require a **config cache table** (`md_config_cache`) that stores these variables. This table is populated by the `job_populate_config_cache` job (see [Section 5](#5-dta-application-initialization)).

#### 3.1.5 `targets` Node

**Purpose**: Defines environment-specific configurations (dev, staging, prod).

```yaml
targets:
  dev:
    mode: development
    default: true
    workspace:
      host: https://dbc-984752964297111.cloud.databricks.com
    permissions:
      - user_name: ${var.user_email}
        level: CAN_MANAGE
  
  staging:
    mode: development
    workspace:
      host: https://dbc-984752964297111.cloud.databricks.com
    variables:
      catalog: "clinical_data_standards_stg_ctlg"
    permissions:
      - user_name: ${var.user_email}
        level: CAN_MANAGE
  
  prod:
    mode: production
    workspace:
      host: https://dbc-984752964297111.cloud.databricks.com
    variables:
      catalog: "clinical_data_standards_prod_ctlg"
      table_suffix: ""
    permissions:
      - user_name: ${var.user_email}
        level: CAN_MANAGE
    run_as:
      user_name: ${var.user_email}
```

##### Environment Comparison

| Environment | Mode | Catalog | Purpose | Schedules |
|-------------|------|---------|---------|-----------|
| **dev** | development | `aira` | Active development, feature testing | Paused |
| **staging** | development | `clinical_data_standards_stg_ctlg` | Pre-production validation | Enabled for testing |
| **prod** | production | `clinical_data_standards_prod_ctlg` | Production workloads | Active |

##### Development vs Production Mode

| Feature | Development Mode | Production Mode |
|---------|------------------|-----------------|
| **Resource Naming** | Prefixed with `[dev user]` | No prefix (shared) |
| **Job Deletion** | Jobs deleted on `bundle destroy` | Jobs retained (manual deletion required) |
| **Access Control** | Individual user permissions | Service principal recommended |
| **Schedules** | Paused by default | Active |

---

### 3.2 Application Configuration (`clinical_data_standards.yaml`)

The `config/clinical_data_standards.yaml` file defines all application-specific settings for data processing pipelines, document types, versioning, and export configurations.

#### Configuration File Structure

```yaml
clinical_data_standards.yaml
├── globals                     # Project-wide settings
├── services                    # Reusable service configurations
├── pipelines                   # Pipeline definitions
│   ├── file_processor          # Generic file extraction and cataloging
│   ├── tsdta_processor         # tsDTA Excel processing
│   ├── protocol_processor      # Protocol document processing
│   └── operational_agreement_processor  # OA document processing
├── streaming                   # Document processing configuration
├── versioning                  # SCD Type 2 configuration
└── export                      # Export configuration
```

#### 3.2.1 `globals` Section

**Purpose**: Project-wide settings shared across all pipelines.

```yaml
globals:
  spark_app_name: "clinical_data_standards"
  catalog: "aira_test"
  bronze_schema: "bronze_md"
  silver_schema: "silver_md"
  gold_schema: "gold_md"
  volume_name: "clinical_data_standards"
  
  # Jobs Configuration for UI
  jobs:
    max_runs_display: 5
    strip_env_prefix: true
    production_jobs:
      - name: "job_cdm_dta_import"
        display_name: "DTA Import"
        category: "import"
      # ... (10+ additional jobs defined)
```

**Key Settings**:
- **Catalog/Schema names**: Unity Catalog hierarchy (bronze/silver/gold)
- **Volume name**: Unity Catalog Volume for file storage
- **Jobs configuration**: Controls which jobs appear in the UI Jobs panel

**Upload Paths**:
- **UI uploads**: Configured in `app.yaml` → `UI_UPLOAD_ROOT` (default: `test/ui/uploads`)
  - Structure: `{ui_upload_root}/{YYYY-MM-DD}/{type}/`
- **Historical batch imports**: Configured in `databricks.yml` → `historical_upload_root` (default: `test/historical_data/uploads`)
  - File trigger watches this folder for automatic processing

#### 3.2.2 `services` Section

**Purpose**: Reusable service configurations shared across multiple pipelines.

```yaml
services:
  # Document Parser Service
  document_parser_default:
    type: "document_parsing"
    engine: "ai_document_intelligence"
    extract_text: true
    extract_tables: true
    timeout_seconds: 120
    description: "Databricks AI Document Intelligence"
  
  # LLM Entity Extractor
  gpt_entity_extractor:
    type: "llm"
    endpoint: "https://..."
    model: "gpt-4.1-mini-global"
    secret_scope: "dta_poc_api_key"
    secret_key: "gpt_api_key"
    timeout_seconds: 120
    description: "Generic GPT-based entity extractor"
```

**Available Services**:
- **`document_parser_default`**: Databricks AI Document Intelligence for parsing PDFs/Word docs
- **`gpt_entity_extractor`**: Generic GPT-based entity extraction (reusable across document types)
- **`entity_extractor_default`**: Foundation model endpoint for entity extraction

#### 3.2.3 `pipelines` Section

**Purpose**: Defines multiple data processing pipelines.

##### Pipeline 1: `file_processor`

**Purpose**: Generic file processor for archives (ZIP) and regular document uploads.

```yaml
pipelines:
  file_processor:
    description: "Generic file processor for archives and regular uploads"
    mode: "streaming"
    source_volume: "clinical_data_standards"
    
    sources:
      historical_data:
        description: "Historical clinical trial data"
        root: "test/historical_data"
    
    file_types:
      archives:
        extensions: [".zip", ".tar.gz", ".7z"]
        action: "extract"
      documents:
        extensions: [".pdf", ".docx", ".xlsx"]
        action: "catalog"
    
    manifest_table: "md_file_history"
    document_types_table: "md_document_types"
```

**Key Features**:
- Extracts ZIP archives containing clinical trial documents
- Catalogs extracted documents with metadata
- Outputs to `md_file_history` manifest table
- Joins with `md_document_types` reference table for processing enablement

**Document Categories**:
- **Protocol**: Protocol documents (PDFs)
- **OperationalAgreement**: Operational Agreement documents (Word/PDF)
- **DTA**: Data Transfer Agreement documents with subcategories:
  - **Dictionary**: DTA data dictionaries
  - **SOW**: Statement of Work (archived)
  - **tsDTA**: Timestamped DTA (Excel files)
  - **OPERATIONAL_AGREEMENT**: OA documents (Word/PDF)
- **TDD**: Technical Design Documents

##### Pipeline 2: `tsdta_processor`

**Purpose**: Process tsDTA Excel files and extract transfer variables, test concepts, codelists.

```yaml
pipelines:
  tsdta_processor:
    description: "Process tsDTA Excel files from trial metadata"
    mode: "streaming"
    
    xls:
      standard:
        source:
          source_table: "md_file_history"
          filter_tags: ["tsDTA"]
          filter_status: "READY_FOR_PROCESSING"
        
        output:
          excel_sheets_table: "md_dta_excel_file_raw"
```

**Validation Rules**:
- **`transfer_metadata`**: Required columns (transfer_variable_name, format, max_length, etc.)
- **`codelists`**: Header detection patterns, required columns (codelist_reference, code_value)
- **`test_concepts`**: Dynamic header detection using transfer variables from silver table

##### Pipeline 3: `protocol_processor`

**Purpose**: Parse Protocol PDFs and extract Schedule of Activities tables (sandbox mode).

```yaml
pipelines:
  protocol_processor:
    description: "Parse Protocol documents and extract tables"
    mode: "sandbox"
    
    ai_processing:
      parse_document:
        enabled: true
        engine: "ai_document_intelligence"
        extract_tables: true
      
      section_filter:
        enabled: true
        process_all_if_no_match: false
      
      target_sections:
        - pattern: "Schedule of Activities"
          alias: "soa"
          extract_tables: true
    
    output:
      sandbox_table: "md_sandbox_documents"
```

**Key Features**:
- AI-powered document parsing using Databricks Document Intelligence
- Section filtering to extract only relevant sections
- Sandbox mode for UI preview before production processing

##### Pipeline 4: `operational_agreement_processor`

**Purpose**: Parse Operational Agreement Word/PDF documents and extract structured data using LLM.

```yaml
pipelines:
  operational_agreement_processor:
    documents:
      operational_agreement:
        source:
          source_table: "md_file_history"
          filter_tags: ["OPERATIONAL_AGREEMENT"]
          filter_status: "READY_FOR_PROCESSING"
        
        output:
          raw_table_name: "md_oa_file_raw"
        
        llm:
          service: "gpt_entity_extractor"
          output_fields:
            - trial_id
            - data_stream_type
            - data_provider_name
```

**Key Features**:
- LLM-based entity extraction from unstructured documents
- Extracts trial ID, data stream type, and data provider name
- Uses GPT-4 for high-accuracy extraction

#### 3.2.4 `streaming` Section

**Purpose**: Enables streaming-based document processing with status tracking using Delta CDF.

```yaml
streaming:
  enabled: true
  
  change_data_feed:
    enabled: true
    cdf_tables:
      - "md_file_history"
  
  status_values:
    ready_for_processing: "READY_FOR_PROCESSING"
    tsdta_in_process: "TSDTA_PROCESSING"
    tsdta_completed: "TSDTA_COMPLETED"
    tsdta_failed: "TSDTA_FAILED"
    ready_for_versioning: "READY_FOR_VERSIONING"
    versioned: "VERSIONED"
  
  trigger:
    mode: "availableNow"
    max_files_per_trigger: 100
```

**Status Lifecycle**:
```
READY_FOR_PROCESSING 
  → TSDTA_PROCESSING 
  → TSDTA_COMPLETED 
  → READY_FOR_VERSIONING 
  → VERSIONING_IN_PROCESS 
  → VERSIONED
```

**Completion Tracking**:
- Tracks child document processing for parent ZIP files
- Triggers versioning only after all required documents are processed
- Required tags: `tsDTA`, `OPERATIONAL_AGREEMENT` (future)

#### 3.2.5 `versioning` Section

**Purpose**: Enables SCD Type 2 versioning for metadata library tables (3-level versioning).

```yaml
versioning:
  enabled: true
  
  # Version tag format: {library_major}-{dta_id}-{version_type}{version_number}
  # Examples:
  #   - "1.0"                 → Library major v1
  #   - "1.0-DTA_A-draft1"    → DTA-A draft 1
  #   - "1.0-DTA_A-v1.0"      → DTA-A major v1.0 (approved)
  
  registry_table: "md_version_registry"
  registry_schema: "gold_md"
  
  # Definition hash configuration
  definition_hash_common_fields:
    - data_provider_name
    - data_stream_type
  
  library_tables:
    - name: "md_dta_transfer_variables"
      library_type: "transfer_variables"
      silver_table: "md_dta_transfer_variables_draft"
      enable_comment_feature: true
      business_keys: ["definition_hash"]
    
    - name: "md_dta_vendor_test_concepts"
      library_type: "test_concepts"
      silver_table: "md_dta_vendor_test_concepts_draft"
      enable_comment_feature: true
    
    - name: "md_dta_operational_agreement"
      library_type: "operational_agreement"
      silver_table: "md_dta_operational_agreement_draft"
      enable_comment_feature: true
      # Related tables promoted alongside main table
      related_tables:
        - silver_table: "md_dta_oa_attributes_draft"
          gold_table: "md_dta_oa_attributes"
        - silver_table: "md_dta_oa_options_draft"
          gold_table: "md_dta_oa_options"
        - silver_table: "md_dta_oa_other_draft"
          gold_table: "md_dta_oa_other"
    
    # Additional library tables: codelists, vendor_visit, data_ingestion_parameters
```

**Versioning Levels**:
1. **Library Major** (e.g., `1.0`, `2.0`): Production canonical data
2. **DTA Major** (e.g., `1.0-DTA_A-v1.0`): Approved DTA version
3. **DTA Draft** (e.g., `1.0-DTA_A-draft1`): Work in progress

**Library Tables with Versioning**:
- `md_dta_transfer_variables`: Transfer variable definitions
- `md_dta_vendor_test_concepts`: Test concept definitions with transfer variable mappings
- `md_dta_operational_agreement`: Operational agreements (with 3 related tables)
- `md_vendor_visit`: Vendor-specific visit implementations
- `md_dta_codelists`: Codelist definitions with value-to-SDTM mappings
- `md_dta_data_ingestion_parameters`: Data ingestion parameters

#### 3.2.6 `export` Section

**Purpose**: Defines how DTA metadata is exported to files (Excel, PDF, ZIP).

```yaml
export:
  enabled: true
  
  export_folder: "exports"
  date_format: "%Y-%m-%d"
  timestamp_format: "%Y%m%d_%H%M%S"
  
  document_types:
    - type: "tsDTA"
      label: "Trial Specific DTA (Excel)"
      format: "excel"
      file_extension: ".xlsx"
      is_enabled: true
      includes:
        - dta_summary
        - version_history
        - transfer_variables
        - test_concepts
      sheets_by_domain: true
    
    - type: "oa"
      label: "Operational Agreement (PDF)"
      format: "pdf"
      is_enabled: false  # Not implemented yet
    
    - type: "dta_full"
      label: "Complete DTA Package (ZIP)"
      format: "zip"
      is_enabled: false  # Enable when all document types ready
```

**Export Path Structure**:
```
/Volumes/{catalog}/bronze_md/{source_root}/exports/{date}/{dta_number}/
```

**Export Manifest**:
- Created in export folder to track what was exported
- JSON format with metadata about export operation

---

### Configuration File Relationship

The two configuration files work together:

| Configuration | Purpose | Managed By | When Changed |
|---------------|---------|------------|-------------|
| **`databricks.yml`** | Infrastructure, deployment, compute | DevOps/Platform team | Deployment changes, new environments |
| **`clinical_data_standards.yaml`** | Application logic, data pipelines | Data engineering team | New document types, pipeline updates |

**Dependency Flow**:
1. `databricks.yml` variables (catalog, schemas) → `clinical_data_standards.yaml` globals
2. `clinical_data_standards.yaml` → `md_config_cache` table (via `job_populate_config_cache`)
3. Jobs/notebooks read config from `md_config_cache` for fast access (~5 sec vs ~60 sec from YAML)

**Configuration Cache**:
The `job_populate_config_cache` job (see [Section 5.3](#53-job-job_populate_config_cache)) reads `clinical_data_standards.yaml` and stores it in the `md_config_cache` Delta table for fast runtime access by all jobs and notebooks.

---

## 4. Environment Setup

### 4.1 Prerequisites

Before deploying, ensure you have:

- ✅ **Databricks CLI v0.250.0 or above**
  ```bash
  curl -fsSL https://raw.githubusercontent.com/databricks/setup-cli/main/install.sh | sudo sh
  databricks --version
  ```

- ✅ **Access to Databricks Workspace**
  - Workspace admin or appropriate permissions
  - `CAN_MANAGE` permission on workspace resources

- ✅ **Unity Catalog Permissions**
  - `CREATE CATALOG` (for initial setup)
  - `USE CATALOG`, `CREATE SCHEMA`, `USE SCHEMA` (for ongoing operations)

- ✅ **Python 3.8+** (for local development and wheel building)

- ✅ **Git Access** (to clone the repository)

### 4.2 Developer Setup

#### Step 1: Authenticate with Databricks

```bash
# OAuth authentication (recommended)
databricks auth login --host <YOUR_DATABRICKS_WORKSPACE_URL>

# Or use personal access token
databricks configure --token
```

#### Step 2: Clone Repository

```bash
git clone <repository-url>
cd clinical-data-standards
```

#### Step 3: Validate Bundle

```bash
# Validate configuration
databricks bundle validate --target dev
```

#### Step 4: Deploy to Dev

```bash
# Deploy all resources
databricks bundle deploy --target dev

# Verify deployment
databricks bundle summary --target dev
```

#### Step 5: Deploy Flask App (Using Helper Script)

The `_deploy_app.sh` helper script ensures the Flask app is deployed with the correct source code path, working around a DAB bug where `source_code_path` isn't always respected.

```bash
# Deploy the Flask app
bash _deploy_app.sh clnl-data-std-mgmt-app

# Optional: specify target (defaults to dev)
bash _deploy_app.sh clnl-data-std-mgmt-app dev
```

**What the script does**:
1. Validates the app exists (requires prior `bundle deploy`)
2. Starts the app compute if not already active
3. Deploys with the correct source code path: `/Workspace/Users/{user}/.bundle/{bundle}/{target}/files/apps/{app_name}`
4. Retries deployment if needed

**Verify app deployment**:
```bash
# Check app status
databricks apps get clnl-data-std-mgmt-app

# Get app URL
databricks apps get clnl-data-std-mgmt-app --output json | jq -r '.url'

# View app logs
databricks apps logs clnl-data-std-mgmt-app
```

#### Step 6: Run Initialization Jobs

See [Section 5: DTA Application Initialization](#5-dta-application-initialization) for required setup jobs.

#### Destroy Application

To remove all deployed resources (jobs, apps, wheels) from the workspace:

```bash
# Destroy all resources for dev target
databricks bundle destroy --target dev

# With auto-approval (for CI/CD)
databricks bundle destroy --target dev --auto-approve
```

**⚠️ Behavior by Environment**: 
- In **development mode**, `bundle destroy` will **automatically delete all jobs and apps**.
- In **production mode**, `bundle destroy` can still be used, but resources are **retained by default** and require explicit deletion.
- Always verify the target before destroying: `databricks bundle summary --target <target>`

**Destroying Individual Resources (All Environments)**:

Instead of destroying the entire bundle, you can delete individual resources:

```bash
# Delete a specific job
databricks jobs delete <job-id>

# Delete a specific app
databricks apps delete <app-name>

# List all bundle-managed jobs to find job IDs
databricks bundle summary --target dev
```

**What gets deleted by `bundle destroy`**:
- All jobs defined in the bundle (dev mode only, unless manually deleted in prod)
- All Databricks Apps (dev mode only, unless manually deleted in prod)
- Uploaded wheel files
- Bundle metadata

**What is NOT deleted**:
- Delta tables and data (catalogs, schemas, tables)
- Unity Catalog volumes
- Secrets
- Service principals

### 4.3 Staging and Production Setup

> **TODO**: Document staging and production deployment procedures
> 
> Planned topics:
> - Service principal setup for prod `run_as`
> - CI/CD pipeline integration (Jenkins)
> - Blue-green deployment strategy
> - Rollback procedures
> - Production monitoring and alerting

**Placeholder Commands**:

```bash
# Staging deployment
databricks bundle deploy --target staging

# Production deployment (requires approval)
databricks bundle deploy --target prod
```

---

## 5. DTA Application Initialization

After deploying the bundle, run these initialization jobs **in order** to prepare the environment.

### Initialization Sequence

```
1. job_test_cdm_cleanup (optional - test only)
      ↓
2. job_cdm_sql_setup
      ↓
3. job_populate_config_cache
      ↓
4. job_cdm_sql_load_reference_data (optional)
      ↓
5. job_cdm_app_permissions
      ↓
6. Deploy Flask App (clnl-data-std-mgmt-app)
```

### 5.1 Job: `job_test_cdm_cleanup`

**Purpose**: Cleans up all tables and checkpoints for fresh testing.

**⚠️ WARNING**: Deletes all data! Only run in dev/test environments.

**What it does**:
1. Drops all bronze tables (`md_file_history`, etc.)
2. Drops all silver tables (`md_dta_transfer_variables_draft`, etc.)
3. Drops all gold tables (`dta`, `md_dta_transfer_variables`, etc.)
4. Deletes checkpoint folder from Volumes
5. Deletes ingested folder from `historical_data/`

**When to run**:
- Before running integration tests
- To reset development environment
- **NEVER in staging or production**

**Command**:
```bash
databricks bundle run job_test_cdm_cleanup --target dev
```

---

### 5.2 Job: `job_cdm_sql_setup`

**Purpose**: Creates Unity Catalog, schemas, volumes, and base tables.

**What it does**:
- Creates catalog (e.g., `aira`, `clinical_data_standards_stg_ctlg`)
- Creates schemas: `bronze_md`, `silver_md`, `gold_md`
- Creates volumes for file storage
- Creates base metadata tables

**Parameters**:
- `catalog_override`: Override default catalog (optional)

**When to run**:
- **First deployment** to any environment
- After running cleanup job
- When adding new schemas/volumes

**Command**:
```bash
# Use default catalog from databricks.yml
databricks bundle run job_cdm_sql_setup --target dev

# Override catalog
databricks bundle run job_cdm_sql_setup --target dev \
  --params '{"catalog_override": "my_custom_catalog"}'
```

---

### 5.3 Job: `job_populate_config_cache`

**Purpose**: Populates the `md_config_cache` Delta table from `clinical_data_standards.yaml`.

**Why it's needed**:
- Many jobs read configuration from `clinical_data_standards.yaml`
- Loading YAML from workspace files is slow (~60 seconds)
- Caching in Delta reduces load time to ~5 seconds

**What it does**:
- Reads `config/clinical_data_standards.yaml`
- Parses YAML configuration
- Writes to `md_config_cache` Delta table
- Stores version and timestamp

**When to run**:
- **After initial deployment**
- After modifying `clinical_data_standards.yaml`
- As part of CI/CD pipeline after config changes

**Command**:
```bash
databricks bundle run job_populate_config_cache --target dev
```

**Verify**:
```sql
SELECT * FROM aira.bronze_md.md_config_cache
ORDER BY updated_at DESC
LIMIT 10;
```

---

### 5.4 Job: `job_cdm_sql_load_reference_data`

**Purpose**: Loads reference data (vendors, data streams, etc.).

**What it does**:
- Loads vendor master data
- Loads data stream definitions
- Loads study metadata
- (Currently a placeholder - expand as needed)

**When to run**:
- After `job_cdm_sql_setup`
- When reference data is updated
- Optional for development environments

**Command**:
```bash
databricks bundle run job_cdm_sql_load_reference_data --target dev
```

---

### 5.5 Job: `job_cdm_app_permissions`

**Purpose**: Creates and seeds permission tables for the Flask management app.

**What it does**:
1. Creates permission tables:
   - `md_users`: Application users
   - `md_user_groups`: User groups (JNJ_DAE, VENDOR, JNJ_LIBRARIAN)
   - `md_permissions`: Permission definitions
   - `md_user_group_memberships`: User to group mappings
   - `md_group_permissions`: Group to permission mappings
2. Seeds default users and groups
3. Assigns default permissions

**When to run**:
- **After `job_cdm_sql_setup`** (to ensure schemas exist)
- **After CDM import job** (to ensure vendors exist)
- **Before deploying Flask app** (to enable user simulation)

**Command**:
```bash
databricks bundle run job_cdm_app_permissions --target dev
```

**Verify**:
```sql
-- Check users
SELECT * FROM aira.gold_md.md_users;

-- Check groups
SELECT * FROM aira.gold_md.md_user_groups;

-- Check memberships
SELECT * FROM aira.gold_md.md_user_group_memberships;
```

---

### 5.6 Deploy Flask App

**Purpose**: Deploy the web-based DTA management application.

**Prerequisites**:
- All initialization jobs completed
- Permission tables populated
- At least one vendor and study created (via DTA import job)

**What the app provides**:
- DTA template creation and configuration
- Document upload and ingestion
- Approval workflows
- Genie conversational UI
- User simulation (for testing different personas)

**Command**:
```bash
# App is automatically deployed with bundle
databricks bundle deploy --target dev

# Verify app is running
databricks apps list --target dev
```

**Access the app**:
1. Navigate to Databricks workspace
2. Go to **Apps** section
3. Find `clnl-data-std-mgmt-app`
4. Click to open the application

---

### Quick Initialization Script

For convenience, here's a script to run all initialization jobs in sequence:

```bash
#!/bin/bash
# File: init_dta_dev.sh
# Purpose: Initialize DTA application in development environment

set -e  # Exit on error

TARGET=${1:-dev}
echo "Initializing DTA application for target: $TARGET"

# Step 1: Cleanup (dev/test only)
if [ "$TARGET" == "dev" ] || [ "$TARGET" == "test" ]; then
  echo "Step 1: Cleaning up existing data..."
  databricks bundle run job_test_cdm_cleanup --target $TARGET
  sleep 5
fi

# Step 2: SQL Setup
echo "Step 2: Creating catalog, schemas, and volumes..."
databricks bundle run job_cdm_sql_setup --target $TARGET
sleep 5

# Step 3: Populate Config Cache
echo "Step 3: Populating config cache..."
databricks bundle run job_populate_config_cache --target $TARGET
sleep 5

# Step 4: Load Reference Data (optional)
echo "Step 4: Loading reference data..."
databricks bundle run job_cdm_sql_load_reference_data --target $TARGET || true
sleep 5

# Step 5: App Permissions
echo "Step 5: Setting up app permissions..."
databricks bundle run job_cdm_app_permissions --target $TARGET
sleep 5

echo "✅ Initialization complete!"
echo "Next steps:"
echo "  1. Run a DTA import job to create initial data"
echo "  2. Access the Flask app in Databricks workspace"
```

**Usage**:
```bash
chmod +x init_dta_dev.sh
./init_dta_dev.sh dev
```

---

## 6. Troubleshooting

### Common Issues

**1. Authentication Errors**
```bash
# Re-authenticate
databricks auth login --host <YOUR_DATABRICKS_WORKSPACE_URL>
```

**2. Permission Denied**
```
Error: User does not have CAN_MANAGE permission
```
**Solution**: Request workspace admin to grant permissions

**3. Resource Conflicts**
```
Error: Resource already exists
```
**Solution**: Use `--force-lock` flag (dev only) or coordinate with team

**4. Validation Failures**
```bash
# Debug validation
databricks bundle validate --debug --target dev
```

**5. Config Cache Not Found**
```
Error: Table md_config_cache not found
```
**Solution**: Run `job_populate_config_cache`

**6. Permission Tables Missing**
```
Error: Table md_users not found
```
**Solution**: Run `job_cdm_app_permissions`

**7. Need to Start Fresh**
```
Error: Inconsistent state or corrupted deployment
```
**Solution**: Destroy and redeploy (behavior depends on environment mode)

**For Development Mode**:
```bash
# Destroy all resources (auto-deletes jobs and apps)
databricks bundle destroy --target dev --auto-approve

# Redeploy from scratch
databricks bundle deploy --target dev

# Deploy Flask app
bash _deploy_app.sh clnl-data-std-mgmt-app

# Re-run initialization jobs (see Section 5)
```

**For Production Mode**:
```bash
# Destroy bundle (resources retained by default)
databricks bundle destroy --target prod --auto-approve

# Manually delete specific resources if needed
databricks jobs delete <job-id>
databricks apps delete <app-name>

# Redeploy
databricks bundle deploy --target prod

# Deploy Flask app
bash _deploy_app.sh clnl-data-std-mgmt-app prod

# Re-run initialization jobs (see Section 5)
```

**⚠️ Note**: This only removes DAB-managed resources (jobs, apps, wheels). Delta tables and data remain intact.

### Rollback

```bash
# List deployments
databricks bundle deployments list --target prod

# Rollback to previous version
databricks bundle deploy --target prod --deployment-id <previous-id>
```

---

## 7. Best Practices

1. **Test in Dev First**: Always test changes in dev before staging/prod
2. **Use Version Control**: Commit all changes before deploying
3. **Document Changes**: Update CHANGELOG.md
4. **Monitor Deployments**: Watch for errors during/after deployment
5. **Backup Configurations**: Keep backups of critical configs
6. **Coordinate with Team**: Communicate before prod deployments
7. **Run Initialization Jobs**: Always run setup jobs after first deployment
8. **Validate Config Cache**: Verify `md_config_cache` after config changes


---

## 9. Related Documentation

- [00. DTA Design Overview](./00_dta_design_overview.readme.md)
- [11. CDH Ingestion Pipeline Design](./11_cdh_ingestion_pipeline_design.readme.md)
- [Databricks Asset Bundles Documentation](https://docs.databricks.com/dev-tools/bundles/index.html)

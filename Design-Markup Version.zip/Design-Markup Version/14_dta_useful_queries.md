# Useful SQL Queries for Clinical Data Standards

This document contains SQL queries for testing, debugging, and validating the DTA versioning pipeline.

---

## Setup - Run First

Before running any queries, set your catalog context:

```sql
-- Set your catalog (change 'aira' to your catalog name)
USE CATALOG aira;

-- Verify catalog is set
SELECT current_catalog();
```

---

## Table of Contents
- [DTA Entity Queries](#dta-entity-queries)
- [Silver Layer Queries](#silver-layer-queries)
- [Gold Layer Queries](#gold-layer-queries)
- [Version Registry Queries](#version-registry-queries)
- [Cross-Table Validation](#cross-table-validation)
- [End-to-End Flow Validation](#end-to-end-flow-validation)
- [Troubleshooting Queries](#troubleshooting-queries)

---

## DTA Entity Queries

### List All DTAs with Version Status

```sql
SELECT 
    dta_id,
    dta_number,
    trial_id,
    data_stream_type,
    data_provider_name,
    status,
    workflow_state,
    version,
    current_draft_version,
    latest_major_version,
    base_template_version,
    parent_document_id,
    created_ts
FROM gold_md.dta
ORDER BY created_ts DESC;
```

### DTA Summary by Status

```sql
SELECT 
    status,
    workflow_state,
    COUNT(*) as count
FROM gold_md.dta
GROUP BY status, workflow_state
ORDER BY count DESC;
```

---

## Silver Layer Queries

### Silver Records with Versioning

```sql
SELECT 
    dta_id,
    version,
    version_status,
    is_current_draft,
    COUNT(*) as record_count,
    SUM(CASE WHEN status = 'COMPLETED' THEN 1 ELSE 0 END) as completed,
    SUM(CASE WHEN status = 'MANUAL_REVIEW_REQUIRED' THEN 1 ELSE 0 END) as manual_review
FROM silver_md.md_dta_transfer_variables_draft
WHERE dta_id IS NOT NULL
GROUP BY dta_id, version, version_status, is_current_draft
ORDER BY dta_id;
```

### Sample Silver Records

```sql
SELECT 
    id,
    dta_id,
    version,
    version_status,
    transfer_variable_name,
    transfer_variable_order,
    format,
    status,
    definition_hash
FROM silver_md.md_dta_transfer_variables_draft
WHERE dta_id IS NOT NULL
LIMIT 20;
```

### Unlinked Silver Records (No DTA)

```sql
SELECT 
    parent_document_id,
    COUNT(*) as orphan_records
FROM silver_md.md_dta_transfer_variables_draft
WHERE dta_id IS NULL OR dta_id = ''
GROUP BY parent_document_id;
```

---

## Gold Layer Queries

### Gold Library by Version

```sql
SELECT 
    version,
    is_major_version,
    is_dta_major,
    parent_version,
    is_current,
    COUNT(*) as record_count
FROM gold_md.md_dta_transfer_variables
GROUP BY version, is_major_version, is_dta_major, 
         parent_version, is_current
ORDER BY version;
```

### Sample Gold Records

```sql
SELECT 
    definition_hash,
    transfer_variable_name,
    version,
    dta_id,
    is_dta_major,
    is_current,
    effective_start_ts
FROM gold_md.md_dta_transfer_variables
ORDER BY version, transfer_variable_name
LIMIT 20;
```

### Current vs Historical Versions (SCD Type 2)

```sql
SELECT 
    definition_hash,
    transfer_variable_name,
    version,
    is_current,
    effective_start_ts,
    effective_end_ts
FROM gold_md.md_dta_transfer_variables
WHERE definition_hash IN (
    SELECT definition_hash 
    FROM gold_md.md_dta_transfer_variables 
    GROUP BY definition_hash 
    HAVING COUNT(*) > 1
)
ORDER BY definition_hash, effective_start_ts;
```

---

## Version Registry Queries

### All Registered Versions

```sql
SELECT 
    version,
    version_type,
    library_type,
    dta_id,
    status,
    record_count,
    parent_version,
    created_ts
FROM gold_md.md_version_registry
ORDER BY created_ts DESC;
```

### Version Progression by DTA

```sql
SELECT 
    dta_id,
    version_type,
    version,
    status,
    record_count,
    created_ts
FROM gold_md.md_version_registry
ORDER BY dta_id, created_ts;
```

### Active Versions Only

```sql
SELECT 
    version,
    version_type,
    dta_id,
    record_count
FROM gold_md.md_version_registry
WHERE status = 'ACTIVE'
ORDER BY version_type, version;
```

### Version Tag Format Validation

```sql
SELECT 
    version,
    version_type,
    CASE 
        WHEN version_type = 'DTA_DRAFT' 
             AND version RLIKE '^[0-9]+\\.[0-9]+-DTA[0-9]+-draft[0-9]+$' THEN '✓ Valid'
        WHEN version_type = 'DTA_APPROVED' 
             AND version RLIKE '^[0-9]+\\.[0-9]+-DTA[0-9]+-v[0-9]+\\.[0-9]+$' THEN '✓ Valid'
        WHEN version_type = 'DTA_TEMPLATE' 
             AND version RLIKE '^[0-9]+\\.[0-9]+$' THEN '✓ Valid'
        ELSE '✗ Invalid format'
    END as format_check
FROM gold_md.md_version_registry;
```

---

## Cross-Table Validation

### DTA-Registry Consistency

```sql
SELECT 
    d.dta_number,
    d.version as dta_version,
    r.version as registry_version,
    r.version_type,
    r.status,
    CASE WHEN d.version = r.version THEN '✓' ELSE '✗' END as match
FROM gold_md.dta d
LEFT JOIN gold_md.md_version_registry r 
    ON d.version = r.version AND d.dta_id = r.dta_id
WHERE r.status = 'ACTIVE'
ORDER BY d.dta_number;
```

### Silver Count Validation

```sql
SELECT 
    r.version,
    r.record_count as registry_count,
    COUNT(s.dta_id) as actual_count,
    CASE WHEN r.record_count = COUNT(s.dta_id) THEN '✓' ELSE '✗' END as match
FROM gold_md.md_version_registry r
LEFT JOIN silver_md.md_dta_transfer_variables_draft s
    ON r.dta_id = s.dta_id AND r.version = s.version
WHERE r.version_type = 'DTA_DRAFT'
GROUP BY r.version, r.record_count;
```

### Gold Count Validation

```sql
SELECT 
    r.version,
    r.record_count as registry_count,
    COUNT(g.definition_hash) as actual_count,
    CASE WHEN r.record_count = COUNT(g.definition_hash) THEN '✓' ELSE '✗' END as match
FROM gold_md.md_version_registry r
LEFT JOIN gold_md.md_dta_transfer_variables g
    ON r.version = g.version
WHERE r.version_type = 'DTA_APPROVED'
GROUP BY r.version, r.record_count;
```

---

## End-to-End Flow Validation

### Complete Pipeline Summary

```sql
SELECT 'Bronze (Source Files)' as layer, 
       COUNT(DISTINCT parent_document_id) as distinct_items,
       COUNT(*) as total_records
FROM bronze_md.md_file_history
WHERE document_tags LIKE '%tsDTA%'

UNION ALL

SELECT 'Silver (Normalized)' as layer,
       COUNT(DISTINCT dta_id) as distinct_dtas,
       COUNT(*) as total_records
FROM silver_md.md_dta_transfer_variables_draft
WHERE dta_id IS NOT NULL

UNION ALL

SELECT 'Gold (Library)' as layer,
       COUNT(DISTINCT version) as distinct_versions,
       COUNT(*) as total_records
FROM gold_md.md_dta_transfer_variables

UNION ALL

SELECT 'DTA Entities' as layer,
       COUNT(*) as dta_count,
       NULL
FROM gold_md.dta

UNION ALL

SELECT 'Version Registry' as layer,
       COUNT(*) as version_count,
       SUM(record_count)
FROM gold_md.md_version_registry;
```

### Data Lineage Trace

```sql
-- Trace a specific transfer variable through all layers
WITH variable_trace AS (
    SELECT 'Silver' as layer, 
           dta_id, version, transfer_variable_name, 
           definition_hash, status
    FROM silver_md.md_dta_transfer_variables_draft
    WHERE transfer_variable_name = 'ProjectName'  -- Replace with your variable
    
    UNION ALL
    
    SELECT 'Gold' as layer,
           dta_id, version as version, transfer_variable_name,
           definition_hash, status
    FROM gold_md.md_dta_transfer_variables
    WHERE transfer_variable_name = 'ProjectName'
)
SELECT * FROM variable_trace ORDER BY layer, version;
```

---

## Troubleshooting Queries

### Find DTAs Without Versions

```sql
SELECT 
    d.dta_id,
    d.dta_number,
    d.version
FROM gold_md.dta d
LEFT JOIN gold_md.md_version_registry r ON d.dta_id = r.dta_id
WHERE r.version IS NULL;
```

### Find Orphan Registry Entries

```sql
SELECT 
    r.version,
    r.dta_id
FROM gold_md.md_version_registry r
LEFT JOIN gold_md.dta d ON r.dta_id = d.dta_id
WHERE d.dta_id IS NULL AND r.dta_id IS NOT NULL;
```

### Check for Duplicate Version Tags

```sql
SELECT 
    version,
    COUNT(*) as count
FROM gold_md.md_version_registry
GROUP BY version
HAVING COUNT(*) > 1;
```

### Recent Job Runs with Errors

```sql
SELECT 
    document_id,
    status,
    notes,
    databricks_job_name,
    databricks_run_id,
    last_updated_ts
FROM bronze_md.md_file_history
WHERE status LIKE '%ERROR%'
ORDER BY last_updated_ts DESC
LIMIT 20;
```

### Records Needing Manual Review

```sql
SELECT 
    dta_id,
    version,
    transfer_variable_name,
    status,
    notes
FROM silver_md.md_dta_transfer_variables_draft
WHERE status = 'MANUAL_REVIEW_REQUIRED'
ORDER BY dta_id, transfer_variable_name;
```

---

## Cleanup Queries

> ⚠️ **DANGER**: These queries DELETE data. Use only in test environments.

### Clear Version Registry

```sql
DELETE FROM gold_md.md_version_registry;
```

### Clear Gold Library

```sql
DELETE FROM gold_md.md_dta_transfer_variables;
```

### Clear DTA Entities

```sql
DELETE FROM gold_md.dta;
```

### Reset Silver Versioning Columns

```sql
UPDATE silver_md.md_dta_transfer_variables_draft
SET dta_id = NULL, 
    version = NULL, 
    version_status = NULL, 
    is_current_draft = NULL;
```

---

## Test Job Helper Queries

### Find Active DTA Major Versions

`job_cdm_create_dta_template_test` will automatically merge ALL active DTA_APPROVED versions.
Use this query to preview which DTAs will be merged:

```sql
-- Find active DTA Major versions that will be merged
SELECT 
    r.dta_id,
    r.version as dta_version,
    r.record_count,
    r.dta_trial_id,
    r.dta_stream_type,
    r.dta_provider_name,
    r.created_ts
FROM gold_md.md_version_registry r
WHERE r.version_type = 'DTA_APPROVED'
  AND r.status = 'ACTIVE'
ORDER BY r.created_ts DESC;
```

### Get DTA Details for Promotion

```sql
-- Get DTA entity details with current versions
SELECT 
    dta_id,
    dta_number,
    trial_id,
    version,
    latest_major_version,
    base_template_version
FROM gold_md.dta
WHERE latest_major_version IS NOT NULL
ORDER BY created_ts DESC;
```

### Preview DTAs That Will Be Merged

`job_cdm_create_dta_template_test` automatically finds and merges all active DTA_APPROVEDs:

```sql
-- Preview which DTAs will be merged when you run promote
SELECT 
    version,
    dta_id,
    record_count,
    dta_trial_id,
    created_ts
FROM gold_md.md_version_registry
WHERE version_type = 'DTA_APPROVED' AND status = 'ACTIVE'
ORDER BY created_ts DESC;
```

---

## Queries After Library Merge

### Verify DTA Template Created from Merge

```sql
-- Check new library major version with merge info
SELECT 
    version,
    version_type,
    status,
    record_count,
    parent_version as merged_from,
    created_ts
FROM gold_md.md_version_registry
WHERE version_type = 'DTA_TEMPLATE'
ORDER BY created_ts DESC;
```

### Compare Merged Records vs Source DTAs

```sql
-- Validate merge deduplication
WITH source_counts AS (
    SELECT 
        version,
        COUNT(*) as records,
        COUNT(DISTINCT definition_hash) as unique_hashes
    FROM gold_md.md_dta_transfer_variables
    WHERE is_dta_major = true
    GROUP BY version
),
library_counts AS (
    SELECT 
        version,
        COUNT(*) as records,
        COUNT(DISTINCT definition_hash) as unique_hashes
    FROM gold_md.md_dta_transfer_variables
    WHERE is_major_version = true AND is_dta_major = false
    GROUP BY version
)
SELECT 'DTA Majors' as source, * FROM source_counts
UNION ALL
SELECT 'DTA Templates' as source, * FROM library_counts
ORDER BY source, version;
```

### Verify SCD Type 2 (Old Library Closed)

```sql
-- Check that old library major is closed
SELECT 
    version,
    is_current,
    effective_start_ts,
    effective_end_ts,
    COUNT(*) as record_count
FROM gold_md.md_dta_transfer_variables
WHERE is_major_version = true AND is_dta_major = false
GROUP BY version, is_current, effective_start_ts, effective_end_ts
ORDER BY effective_start_ts DESC;
```

---

## Expected Results Reference

### DTA Import Flow

| Check | Expected |
|-------|----------|
| DTAs created | 1+ with `dta_number` like DTA001 |
| Silver `version_status` | `APPROVED` (after full flow) |
| Gold `is_dta_major` | `true` for DTA Major records |
| Registry entries per DTA | 2 (DRAFT + DTA_APPROVED) |
| DRAFT status | `SUPERSEDED` |
| DTA_APPROVED status | `ACTIVE` |
| Version tag format (DRAFT) | `1.0-DTA001-draft1` |
| Version tag format (MAJOR) | `1.0-DTA001-v1.0` |

### Library Promotion / Merge Flow

| Check | Expected |
|-------|----------|
| New Library version | Incremented (e.g., `1.0` → `2.0`) |
| Old Library `is_current` | `false` |
| New Library `is_current` | `true` |
| Old Library `effective_end_ts` | Populated timestamp |
| Registry `DTA_TEMPLATE` | New version ACTIVE, old SUPERSEDED |
| Merge `parent_version` | Comma-separated source DTA versions |

---

## Migration Queries

### Rename current_version to version

If you have existing data in the `dta` table with the old column name `current_version`, run this migration:

```sql
-- Migration: Rename current_version column to version in DTA table
-- Run this ONCE if upgrading from older schema
ALTER TABLE gold_md.dta RENAME COLUMN current_version TO version;

-- Verify the migration
DESCRIBE gold_md.dta;
```

### Add SCD Type 2 Columns to DTA Table

If you have existing DTAs without the SCD Type 2 columns (`effective_start_ts`, `effective_end_ts`, `is_current`), run this migration:

```sql
-- Migration: Add SCD Type 2 columns to DTA table
-- Run this ONCE if upgrading from older schema

-- Step 1: Add new columns
ALTER TABLE gold_md.dta ADD COLUMNS (
    effective_start_ts TIMESTAMP,
    effective_end_ts TIMESTAMP,
    is_current BOOLEAN
);

-- Step 2: Backfill existing DTAs
-- Set effective_start_ts to created_ts, effective_end_ts to NULL (active), is_current to true
UPDATE gold_md.dta
SET 
    effective_start_ts = COALESCE(created_ts, current_timestamp()),
    effective_end_ts = CASE WHEN status = 'ARCHIVED' THEN last_updated_ts ELSE NULL END,
    is_current = CASE WHEN status = 'ARCHIVED' THEN false ELSE true END
WHERE effective_start_ts IS NULL;

-- Verify the migration
SELECT dta_number, status, effective_start_ts, effective_end_ts, is_current 
FROM gold_md.dta 
ORDER BY dta_number;
```

### Query Active DTAs Only (SCD Type 2)

After migration, use `is_current = true` to filter active DTAs:

```sql
-- Get all active DTAs (not archived)
SELECT * FROM gold_md.dta WHERE is_current = true;

-- Get archived DTAs with their archive date
SELECT dta_number, status, effective_start_ts, effective_end_ts 
FROM gold_md.dta 
WHERE is_current = false
ORDER BY effective_end_ts DESC;
```

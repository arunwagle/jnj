# Hash Generation Design

## Overview

The hash generation system creates deterministic, content-based identifiers (`definition_hash`) that uniquely identify metadata definitions regardless of their source. This enables:

- **Cross-trial deduplication**: Same variable definition used in multiple trials = single library entry
- **Change detection**: Modified definitions get new hashes, preserving history
- **Versioning support**: Hash + version forms composite key in gold layer

The hash fields are **configuration-driven** and defined in `config/clinical_data_standards.yaml` under the `versioning` section. This allows flexibility to adjust which fields contribute to uniqueness without code changes.

---

## Configuration-Driven Hash Fields

Hash generation is controlled by the configuration file (`config/clinical_data_standards.yaml`), which defines:

1. **Common fields** - Always included in ALL library type hashes
2. **Type-specific fields** - Additional fields per library type

### Common Fields (All Library Types)

These fields are automatically included in the hash for every library type:

| Field | Description |
|-------|-------------|
| `data_provider_name` | Vendor name (normalized) |
| `data_stream_type` | Data stream type (e.g., EDC, Lab, PK) |

**Configuration:**
```yaml
versioning:
  definition_hash_common_fields:
    - data_provider_name
    - data_stream_type
```

**Result:** All hashes are **vendor-scoped** - same definition from different vendors = different hash.

### Type-Specific Hash Fields

Each library type defines additional fields to include in the hash calculation:

#### Transfer Variables

| Field | Description |
|-------|-------------|
| `transfer_variable_name` | Variable name (e.g., SUBJECT_ID) |
| `transfer_variable_order` | Order/sequence in the transfer file |
| `format` | Data type (text, numeric, date, etc.) |
| `anticipated_max_length` | Maximum length for the field |
| `transfer_file_key` | Whether this is a key field |
| `populate_for_all_records` | Whether value is required for all records |
| `codelist_values` | Array of codelist values (serialized as sorted, lowercase, pipe-delimited) |

**Configuration:**
```yaml
definition_hash_fields_by_type:
  transfer_variables:
    - transfer_variable_name
    - transfer_variable_order
    - format
    - anticipated_max_length
    - transfer_file_key
    - populate_for_all_records
    - codelist_values
```

**Final Hash Includes:** Common fields (`data_provider_name`, `data_stream_type`) + Type-specific fields

#### Test Concepts

Test Concepts represent specific laboratory tests, assessments, or observations. Each test concept is uniquely defined by a **complete set of transfer variable values** that characterize that test.

**What is the "Tuple"?**

In this context, "tuple" refers to **the complete row of transfer variable mappings** for a single test concept. It's stored as a MAP<STRING, STRING> where:
- **Keys** = Transfer variable names (e.g., `LBTESTCD`, `LBTEST`, `LBCAT`, `LBMETHOD`)
- **Values** = Specific values for this test (e.g., `"ALB"`, `"Albumin"`, `"CHEMISTRY"`, `"Spectrophotometry"`)

The tuple captures **all the variables** that collectively define what makes this test concept unique.

**Example: Albumin Lab Test**

```json
{
  "LBTESTCD": "ALB",
  "LBTEST": "Albumin",
  "LBCAT": "CHEMISTRY",
  "LBMETHOD": "Spectrophotometry",
  "LBSTRESU": "g/L",
  "LBSTNRLO": "35",
  "LBSTNRHI": "52"
}
```

This entire MAP is what defines the test concept. Two test concepts are considered **identical** if and only if their complete tuple (all variable mappings) match exactly.

**Why Tuples Matter for Hashing:**

| Scenario | Result |
|----------|--------|
| Same test code, same method, same units | **Same hash** → Deduplicated |
| Different test codes (`ALB` vs `ALP`) | **Different hash** → Separate entries |
| Same test, different methods | **Different hash** → Vendor variations captured |
| Same test, different reference ranges | **Different hash** → Site-specific standards |

The **entire tuple** is included in the hash calculation - not just one or two fields. This enables precise deduplication across trials while preserving meaningful variations.

| Field | Description |
|-------|-------------|
| `transfer_tuple_map` | MAP<STRING, STRING> containing all transfer variable name-value pairs for this test concept (serialized as sorted JSON) |

**Configuration:**
```yaml
definition_hash_fields_by_type:
  test_concepts:
    - transfer_tuple_map
```

**Schema-Agnostic Design:**

Test concept schemas vary significantly across vendors and data streams. Using a MAP structure allows:
- ✅ Different vendors can have different variable sets
- ✅ New variables can be added without schema changes
- ✅ Hash remains stable for the same logical test definition
- ✅ No need to predict all possible columns upfront

#### Codelists

| Field | Description |
|-------|-------------|
| `transfer_variable_name` | Variable name the codelist applies to |
| `values` | Array of codelist values (serialized as sorted, lowercase, pipe-delimited) |

**Configuration:**
```yaml
definition_hash_fields_by_type:
  codelists:
    - transfer_variable_name
    - values
```

#### Operational Agreement

| Field | Description |
|-------|-------------|
| `operational_agreement_id` | Unique agreement identifier |

**Configuration:**
```yaml
definition_hash_fields_by_type:
  operational_agreement:
    - operational_agreement_id
```

#### Vendor Visit

| Field | Description |
|-------|-------------|
| `protocol_visit_id` | Reference to protocol visit |
| `visit_name` | Vendor-specific visit name |
| `visit_number` | Visit sequence number |
| `timepoint` | Visit timepoint (e.g., "Day 1", "Week 4") |
| `timepoint_number` | Numeric timepoint value |

**Configuration:**
```yaml
definition_hash_fields_by_type:
  vendor_visit:
    - protocol_visit_id
    - visit_name
    - visit_number
    - timepoint
    - timepoint_number
```

#### Data Ingestion Parameters

| Field | Description |
|-------|-------------|
| `data_ingestion_id` | Unique ingestion parameter identifier |

**Configuration:**
```yaml
definition_hash_fields_by_type:
  data_ingestion_parameters:
    - data_ingestion_id
```

---

---

## Hash Algorithm

### Transfer Variables

Uses `compute_definition_hash()` from `src/clinical_data_standards_framework/utils.py`:

**Steps:**
1. **Sort fields alphabetically** for deterministic ordering
2. **Normalize values**:
   - `None` → empty string `""`
   - `Boolean true` → `"1"`
   - `Boolean false` → `"0"`
   - `Numbers` → string representation
   - `Strings` → lowercase, trimmed whitespace
3. **Concatenate** with pipe `|` delimiter
4. **Compute SHA256** hash (64 hex characters)

**Example:**
```python
# Input
hash_record = {
    'data_provider_name': 'VendorA',
    'data_stream_type': 'EDC',
    'transfer_variable_name': 'SUBJECT_ID',
    'format': 'text',
    'anticipated_max_length': '50',
    ...
}

# After normalization and sorting, pipe-delimited:
# "50|vendora|edc|text|subject_id|..."

# Result: SHA256 hash (64 hex characters)
```

For Spark DataFrames, use `compute_definition_hash_spark()` which applies the same logic.

### Test Concepts

Uses an inline function in `nb_tsdta_test_concepts_processor.ipynb`:

**Steps:**
1. **Create dictionary** with keys: `data_provider`, `data_stream`, `tuple_map`
2. **Sort dictionary items** alphabetically
3. **JSON serialize** with `json.dumps(sorted_items, sort_keys=True)`
4. **Compute SHA256** hash (64 hex characters)

**Example:**
```python
# Input
hash_dict = {
    'data_provider': 'VendorA',
    'data_stream': 'Lab',
    'tuple_map': {'LBTESTCD': 'ALB', 'LBTEST': 'Albumin', ...}
}

# JSON serialized (sorted):
# '[["data_provider", "VendorA"], ["data_stream", "Lab"], ["tuple_map", {...}]]'

# Result: SHA256 hash (64 hex characters)
```

---

## Related Documentation

- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - Table schemas including hash columns
- [04_dta_versioning_design.readme.md](./04_dta_versioning_design.readme.md) - How hash + version forms composite keys
- `config/clinical_data_standards.yaml` - Hash field configuration (versioning section)
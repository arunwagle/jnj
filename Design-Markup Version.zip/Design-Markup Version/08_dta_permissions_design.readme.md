# Permissions & Access Control Design

## Overview

This document describes the **hierarchical permissions system** for the Clinical Data Standards Management application. The system provides role-based access control (RBAC) integrated with Unity Catalog and backed by database tables managed via the `job_cdm_app_permissions` job.

### Permission Levels

The design follows a two-level hierarchy:

1. **Page Access** - Which pages/menus can the user see?
2. **Action Execute** - Which buttons/actions can the user perform?

### Design Principles

- **Database-Driven**: All permissions stored in Unity Catalog tables (`md_users`, `md_user_groups`, `md_permissions`)
- **Hierarchical**: Page access controls action availability
- **Extensible**: Easy to add new roles, permissions, and UI elements
- **Job-Managed**: Permissions setup and updates via dedicated Databricks job
- **Vendor-Scoped**: Vendor users automatically filtered by `vendor_id`

---

## Architecture Diagram

![Permissions Hierarchy](./diagrams/08_dta_permissions_hierarchy.drawio.png)


📝 [Edit Diagram (Draw.io)](./diagrams/08_dta_permissions_hierarchy.drawio)

The diagram shows:
- **Top Section**: User groups (JNJ_DAE, VENDOR, JNJ_LIBRARIAN) and their mapped permissions
- **Bottom Section**: Database schema (ERD) showing 5 tables and their relationships

---

## User Groups

| Group | Description | Primary Use Case |
|-------|-------------|------------------|
| **JNJ_DAE** | Data Acquisition Engineer | Create, edit, clone, manage DTAs; submit for approval; promote to major version |
| **VENDOR** | External vendor user | View assigned DTAs; add comments; approve DTAs |
| **JNJ_LIBRARIAN** | Library maintainer | View DTAs, comment, and promote approved DTAs to templates |

### Vendor User Scoping

Vendor users are linked to a specific vendor via `vendor_id`:
- They only see DTAs associated with their vendor
- `vendor_id` references `md_vendor.vendor_id`
- Data queries are automatically filtered by vendor

---

## Complete Permissions Matrix

This table shows all permissions in the system and which user groups have access to each:

| Permission Key | Type | Description | Enforcement | JNJ_DAE | VENDOR | LIBRARIAN |
|----------------|------|-------------|-------------|---------|--------|-----------|
| **PAGE ACCESS PERMISSIONS** ||||||||
| `page_all` | PAGE_ACCESS | Access to all pages (wildcard) | HIDE | ✓ | ✗ | ✗ |
| `page_dashboard` | PAGE_ACCESS | Dashboard page | HIDE | ✓ via all | ✓ | ✓ |
| `page_dta_builder` | PAGE_ACCESS | DTA Builder page | HIDE | ✓ | ✓ | ✗ |
| `page_dta_workflow` | PAGE_ACCESS | DTA Workflow page | HIDE | ✓ via all | ✓ | ✓ |
| `page_dta_viewer` | PAGE_ACCESS | DTA Viewer page | HIDE | ✓ via all | ✓ | ✓ |
| `page_study_mgmt` | PAGE_ACCESS | Study Management pages | HIDE | ✓ via all | ✗ | ✗ |
| `page_doc_mgmt` | PAGE_ACCESS | Document Management pages | HIDE | ✓ via all | ✗ | ✗ |
| `page_admin` | PAGE_ACCESS | Administration pages | HIDE | ✗ | ✗ | ✓ |
| **ACTION PERMISSIONS** ||||||||
| `action_edit_dta` | ACTION_EXECUTE | Edit DTA fields and content | DISABLE | ✓ | ✗ | ✗ |
| `action_clone_dta` | ACTION_EXECUTE | Clone existing DTAs | HIDE | ✓ | ✗ | ✗ |
| `action_delete_library_item` | ACTION_EXECUTE | Delete library items | HIDE | ✓ | ✗ | ✗ |
| `action_add_comment` | ACTION_EXECUTE | Add comments to items | HIDE | ✓ | ✓ | ✓ |
| `action_approve_dta` | ACTION_EXECUTE | Approve DTAs in workflow | HIDE | ✗ | ✓ | ✗ |
| `action_promote_dta` | ACTION_EXECUTE | Promote DTA to major version | HIDE | ✓ | ✗ | ✗ |
| `action_promote_template` | ACTION_EXECUTE | Promote DTA to template | HIDE | ✗ | ✗ | ✓ |

**Legend:**
- ✓ = Has permission
- ✗ = No permission
- **HIDE** = Element removed from DOM if no permission
- **DISABLE** = Element visible but inactive if no permission

---

## Database Schema

### Tables

#### md_users
Stores application users with vendor associations.

| Column | Type | Description |
|--------|------|-------------|
| `user_id` | STRING | Primary key (UUID) |
| `email` | STRING | User email for authentication and notifications |
| `display_name` | STRING | User display name |
| `vendor_id` | STRING | FK to `md_vendor` for vendor users, NULL for internal |
| `is_active` | BOOLEAN | Active status |
| `created_ts` | TIMESTAMP | Record creation timestamp |
| `last_updated_ts` | TIMESTAMP | Last update timestamp |

#### md_user_groups
Defines user groups with permission sets.

| Column | Type | Description |
|--------|------|-------------|
| `group_id` | STRING | Primary key |
| `group_name` | STRING | Group name: JNJ_DAE, JNJ_LIBRARIAN, VENDOR |
| `description` | STRING | Group description |
| `is_active` | BOOLEAN | Active status |

#### md_permissions
Defines permission definitions with enforcement strategy.

| Column | Type | Description |
|--------|------|-------------|
| `permission_id` | STRING | Primary key |
| `permission_type` | STRING | Type: PAGE_ACCESS, ACTION_EXECUTE |
| `permission_key` | STRING | Unique key: page_dashboard, action_edit_dta, etc. |
| `enforcement_mode` | STRING | HIDE (remove from DOM) or DISABLE (show but inactive) |
| `description` | STRING | Human-readable description |
| `disabled_message` | STRING | Tooltip/message shown when element is disabled |

#### md_user_group_memberships
Maps users to groups (many-to-many).

| Column | Type | Description |
|--------|------|-------------|
| `membership_id` | STRING | Primary key |
| `user_id` | STRING | FK to `md_users` |
| `group_id` | STRING | FK to `md_user_groups` |
| `joined_ts` | TIMESTAMP | When user joined the group |

#### md_group_permissions
Maps groups to permissions (many-to-many).

| Column | Type | Description |
|--------|------|-------------|
| `group_permission_id` | STRING | Primary key |
| `group_id` | STRING | FK to `md_user_groups` |
| `permission_id` | STRING | FK to `md_permissions` |

---

## Permission Hierarchy

### Level 1: Page Access

Controls which pages/menu items the user can see.

| Permission Key | Description | Enforcement Mode |
|----------------|-------------|------------------|
| `page_all` | Access to all pages (Admin wildcard) | HIDE |
| `page_dashboard` | Access dashboard page | HIDE |
| `page_dta_builder` | Access DTA Builder page | HIDE |
| `page_dta_workflow` | Access DTA Workflow page | HIDE |
| `page_dta_viewer` | Access DTA Viewer page | HIDE |
| `page_study_mgmt` | Access Study Management pages | HIDE |
| `page_doc_mgmt` | Access Document Management pages | HIDE |
| `page_admin` | Access Administration pages | HIDE |

**Page Access Matrix:**

| Page | JNJ_DAE | VENDOR | JNJ_LIBRARIAN |
|------|---------|--------|---------------|
| Dashboard | ✓ (via page_all) | ✓ | ✓ |
| DTA Builder | ✓ | ✓ (read-only) | ✗ |
| DTA Workflow | ✓ (via page_all) | ✓ | ✓ |
| DTA Viewer | ✓ (via page_all) | ✓ | ✓ |
| Study Management | ✓ (via page_all) | ✗ | ✗ |
| Document Management | ✓ (via page_all) | ✗ | ✗ |
| Administration | ✗ | ✗ | ✓ |

### Level 2: Action Execute

Controls which buttons/actions the user can perform.

| Permission Key | Description | Enforcement Mode |
|----------------|-------------|------------------|
| `action_edit_dta` | Edit DTA fields | DISABLE |
| `action_add_comment` | Add comments to items | HIDE |
| `action_clone_dta` | Clone DTAs | HIDE |
| `action_delete_library_item` | Delete library items | HIDE |
| `action_promote_template` | Promote DTA to template | HIDE |
| `action_approve_dta` | Approve DTA | HIDE |
| `action_promote_dta` | Promote DTA to Major Version | HIDE |

**Action Permissions Matrix:**

| Action | JNJ_DAE | VENDOR | JNJ_LIBRARIAN |
|--------|---------|--------|---------------|
| Edit DTA | ✓ | ✗ | ✗ |
| Clone DTA | ✓ | ✗ | ✗ |
| Delete Item | ✓ | ✗ | ✗ |
| Add Comment | ✓ | ✓ | ✓ |
| Approve DTA | ✗ | ✓ | ✗ |
| Promote DTA to Major Version | ✓ | ✗ | ✗ |
| Promote DTA to Template | ✗ | ✗ | ✓ |

---

## Permissions Setup Job

### job_cdm_app_permissions

**Purpose**: Setup and seed permission tables for the CDM application

**Job Definition**: `resources/sql/common/jobs/job_cdm_app_permissions.job.yml`

**SQL Script**: `sql/setup_cdm_app_permissions.sql`

**Tasks:**
1. **setup_app_permissions** - SQL task that:
   - Drops existing permission tables (to ensure schema updates)
   - Creates 5 permission tables (`md_users`, `md_user_groups`, `md_permissions`, `md_user_group_memberships`, `md_group_permissions`)
   - Seeds 3 user groups (JNJ_DAE, VENDOR, JNJ_LIBRARIAN)
   - Seeds 15 permissions (8 PAGE_ACCESS + 7 ACTION_EXECUTE)
   - Assigns permissions to groups
   - Creates test users
   - Assigns users to groups

**Execution Order:**
- **After** `job_cdm_sql_setup` (to ensure schemas exist)
- **After** CDM import job (to ensure vendors exist in `md_vendor`)
- **Before** deploying the Flask app

**Parameters:**
- `catalog_override`: Target catalog (defaults to `${var.catalog}`)

**To Run:**
```bash
# Via Databricks UI
# Workflows → Jobs → job_cdm_app_permissions → Run Now

# Via CLI
databricks jobs run-now --job-name job_cdm_app_permissions
```

---

## Current Users

The following users are configured in the system:

### JNJ DAE Users

| Email | Display Name | Vendor | Group |
|-------|--------------|--------|-------|
| VKapoor9@its.jnj.com | Vikas Kapoor (DAE) | JNJ Internal | JNJ_DAE |
| gricca4@its.jnj.com | Giuseppe Ricca (DAE) | JNJ Internal | JNJ_DAE |

### Vendor Users

| Email | Display Name | Vendor | Group |
|-------|--------------|--------|-------|
| awagle4@its.jnj.com | Arun Wagle (LabCorp) | Labcorp | VENDOR |
| RRaoGude@its.jnj.com | Rohit Rao Gude (Clario) | Clario | VENDOR |

### JNJ Librarian

| Email | Display Name | Vendor | Group |
|-------|--------------|--------|-------|
| JHEERES1@its.jnj.com | Jennifer Heeres (Librarian) | JNJ Internal | JNJ_LIBRARIAN |

---

## Implementation

### Backend API

#### user_management_api.py

Service for managing users, groups, and permissions:

```python
class UserManagementService:
    """Service for managing users, groups, and permissions"""
    
    def __init__(self, sql_client, catalog="dta_poc_test", schema="gold_md"):
        self.client = sql_client
        self.catalog = catalog
        self.schema = schema
    
    def get_user_by_email(self, email: str) -> dict:
        """Get user details by email"""
        query = f"""
            SELECT 
                u.user_id, u.email, u.display_name,
                u.vendor_id, v.vendor_name, u.is_active
            FROM {self.catalog}.{self.schema}.md_users u
            LEFT JOIN {self.catalog}.{self.schema}.md_vendor v 
              ON u.vendor_id = v.vendor_id
            WHERE u.email = '{email}' AND u.is_active = true
        """
        results = self.client.execute_query(query)
        return results[0] if results else None
    
    def get_user_groups(self, email: str) -> list:
        """Get groups for a user"""
        query = f"""
            SELECT g.group_name
            FROM {self.catalog}.{self.schema}.md_users u
            JOIN {self.catalog}.{self.schema}.md_user_group_memberships m 
              ON u.user_id = m.user_id
            JOIN {self.catalog}.{self.schema}.md_user_groups g 
              ON m.group_id = g.group_id
            WHERE u.email = '{email}' AND u.is_active = true
        """
        results = self.client.execute_query(query)
        return [row['group_name'] for row in results]
    
    def get_user_permissions(self, email: str) -> dict:
        """Get all permissions for a user (organized by type)"""
        query = f"""
            SELECT DISTINCT p.permission_type, p.permission_key
            FROM {self.catalog}.{self.schema}.md_users u
            JOIN {self.catalog}.{self.schema}.md_user_group_memberships m 
              ON u.user_id = m.user_id
            JOIN {self.catalog}.{self.schema}.md_group_permissions gp 
              ON m.group_id = gp.group_id
            JOIN {self.catalog}.{self.schema}.md_permissions p 
              ON gp.permission_id = p.permission_id
            WHERE u.email = '{email}' AND u.is_active = true
        """
        results = self.client.execute_query(query)
        
        permissions = {'PAGE_ACCESS': [], 'ACTION_EXECUTE': []}
        for row in results:
            perm_type = row['permission_type']
            if perm_type in permissions:
                permissions[perm_type].append(row['permission_key'])
        
        return permissions
    
    def can(self, email: str, permission_key: str) -> bool:
        """Check if user has a specific permission"""
        perms = self.get_user_permissions(email)
        all_perms = perms['PAGE_ACCESS'] + perms['ACTION_EXECUTE']
        return permission_key in all_perms or 'page_all' in perms['PAGE_ACCESS']
    
    def get_user_with_permissions(self, email: str) -> dict:
        """Get complete user profile with permissions"""
        user = self.get_user_by_email(email)
        if not user:
            return None
        
        user['groups'] = self.get_user_groups(email)
        user['permissions'] = self.get_user_permissions(email)
        return user
```

### Flask Integration

#### app.py

```python
from apps.clnl_data_std_mgmt_app.api.user_management_api import UserManagementService
from databricks_sql_client import DatabricksSQLClient

# Initialize user service
def get_user_service():
    if not hasattr(g, 'user_service'):
        sql_client = DatabricksSQLClient(warehouse_id=WAREHOUSE_ID)
        g.user_service = UserManagementService(sql_client, catalog=CATALOG)
    return g.user_service

# Get current user (from SSO or session)
def get_current_user():
    if 'current_user' not in g:
        # In production: email = request.headers.get('X-Forwarded-User')
        email = session.get('user_email', 'VKapoor9@its.jnj.com')
        user_service = get_user_service()
        g.current_user = user_service.get_user_with_permissions(email)
    return g.current_user

# Permission checking helper
@app.context_processor
def utility_processor():
    def can(permission_key):
        """Check if current user has permission"""
        user = get_current_user()
        if not user:
            return False
        user_service = get_user_service()
        return user_service.can(user['email'], permission_key)
    
    return dict(can=can)

# API endpoint to get current user
@app.route('/api/current-user', methods=['GET'])
def api_current_user():
    """Get current user profile"""
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Not authenticated'}), 401
    return jsonify({'success': True, 'user': user})

# API endpoint to check permission
@app.route('/api/can/<permission_key>', methods=['GET'])
def api_can(permission_key):
    """Check if current user has a permission"""
    user_service = get_user_service()
    user = get_current_user()
    if not user:
        return jsonify({'success': False, 'has_permission': False})
    
    has_perm = user_service.can(user['email'], permission_key)
    return jsonify({'success': True, 'has_permission': has_perm})
```

### Frontend Templates

#### Checking Permissions in Templates

```html
<!-- Hide element if user doesn't have permission -->
{% if can('action_edit_dta') %}
<button class="btn btn-primary">Edit DTA</button>
{% endif %}

<!-- Disable element if user doesn't have permission -->
<button class="btn btn-primary" 
        {% if not can('action_clone_dta') %}disabled{% endif %}>
    Clone DTA
</button>

<!-- Show different content based on permission -->
{% if can('page_admin') %}
<li><a href="/admin">Administration</a></li>
{% endif %}
```

#### JavaScript Permission Checking

```javascript
// Check permission via API
async function checkPermission(permissionKey) {
    const response = await fetch(`/api/can/${permissionKey}`);
    const data = await response.json();
    return data.has_permission;
}

// Usage
const canEdit = await checkPermission('action_edit_dta');
if (canEdit) {
    showEditButton();
} else {
    hideEditButton();
}

// Get current user
async function getCurrentUser() {
    const response = await fetch('/api/current-user');
    const data = await response.json();
    return data.user;
}
```

---

## Enforcement Modes

### HIDE Mode

**Used for**: Most permissions (PAGE_ACCESS and ACTION_EXECUTE)

**Behavior**: Element is completely removed from DOM if user lacks permission

**Example**:
```html
{% if can('action_clone_dta') %}
<button id="clone-btn">Clone</button>
{% endif %}
```

**Result**: If user lacks `action_clone_dta`, the button doesn't render at all.

### DISABLE Mode

**Used for**: `action_edit_dta` (Edit DTA permission)

**Behavior**: Element is visible but inactive/disabled if user lacks permission

**Example**:
```html
<button id="edit-btn" 
        {% if not can('action_edit_dta') %}
        disabled 
        title="You do not have permission to edit DTAs"
        {% endif %}>
    Edit
</button>
```

**Result**: If user lacks `action_edit_dta`, button shows but is grayed out with tooltip.

**Rationale**: DISABLE mode for edit is used to provide progressive disclosure - users can see that editing exists but requires specific permissions.

---

## Adding New Permissions

### 1. Define Permission in SQL

Edit `sql/setup_cdm_app_permissions.sql`:

```sql
-- Add new permission
INSERT INTO md_permissions (permission_id, permission_type, permission_key, enforcement_mode, description, disabled_message) VALUES
('perm_action_export_dta', 'ACTION_EXECUTE', 'action_export_dta', 'HIDE', 'Export DTA to file', NULL);
```

### 2. Assign to Groups

```sql
-- Assign to JNJ_DAE group
INSERT INTO md_group_permissions (group_permission_id, group_id, permission_id)
SELECT uuid(), 'group_jnj_dae', 'perm_action_export_dta';
```

### 3. Run Job

```bash
databricks jobs run-now --job-name job_cdm_app_permissions
```

### 4. Use in Templates

```html
{% if can('action_export_dta') %}
<button onclick="exportDTA()">Export</button>
{% endif %}
```

---

## Adding New User Groups

### 1. Define Group in SQL

Edit `sql/setup_cdm_app_permissions.sql`:

```sql
-- Add new group
INSERT INTO md_user_groups (group_id, group_name, description, is_active) VALUES
('group_quality_assurance', 'QUALITY_ASSURANCE', 'QA team - Review and validate DTAs', true);
```

### 2. Assign Permissions

```sql
-- Assign permissions to new group
INSERT INTO md_group_permissions (group_permission_id, group_id, permission_id)
SELECT uuid(), 'group_quality_assurance', 'perm_page_dashboard'
UNION ALL
SELECT uuid(), 'group_quality_assurance', 'perm_page_dta_viewer'
UNION ALL
SELECT uuid(), 'group_quality_assurance', 'perm_action_comment';
```

### 3. Create Users and Assign

```sql
-- Create QA users
INSERT INTO md_users (user_id, email, display_name, vendor_id, is_active, created_ts, last_updated_ts)
SELECT uuid(), 'qa.user@jnj.com', 'QA User', NULL, true, current_timestamp(), current_timestamp();

-- Assign to group
INSERT INTO md_user_group_memberships (membership_id, user_id, group_id, joined_ts)
SELECT uuid(), user_id, 'group_quality_assurance', current_timestamp()
FROM md_users WHERE email = 'qa.user@jnj.com';
```

### 4. Run Job

```bash
databricks jobs run-now --job-name job_cdm_app_permissions
```

---

## Related Documentation

- [01_dta_job_architecture_design.readme.md](./01_dta_job_architecture_design.readme.md) - Job architecture including `job_cdm_app_permissions`
- [06_dta_workflow_design.readme.md](./06_dta_workflow_design.readme.md) - User groups and approval roles
- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - Permission table schemas
- `sql/setup_cdm_app_permissions.sql` - SQL script for permissions setup
- `resources/sql/common/jobs/job_cdm_app_permissions.job.yml` - Permissions job definition

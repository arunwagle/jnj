# Databricks AI Design

## Overview

The Clinical Data Standards platform leverages **Databricks AI** capabilities to enable intelligent document processing and conversational data access. This design covers two primary AI capabilities:

### 1. Databricks Model Serving (Future Recommendation)
Process clinical documents containing unstructured or semi-structured data. This architecture enables intelligent extraction of data from:


- **Operational Agreements** (PDF/Word) - Contract terms, vendor information, transfer requirements
- **Protocol Documents** (PDF/Word) - Study design, endpoints, Schedule of Activities tables

**In the current implementation we are directly calling the AI model.**

### 2. Databricks AI/BI Genie
Enable natural language querying of structured DTA metadata. Users can search and analyze DTAs using conversational questions instead of SQL:

- **DTA Discovery** - "Find all Labs DTAs from LabCorp"
- **Version Lookup** - "Show me DTAs approved in the last 30 days"
- **Template Search** - "What are the latest versions for vendor Clario?"

### AI Functions

The platform uses two primary AI functions provided by Databricks:

| Function | Purpose |
|----------|---------|
| `ai_parse_document` | Parse unstructured documents (PDF, Word, scanned images) into structured, queryable content using OCR, layout detection, and table extraction |
| `ai_query` | Extract specific entities, relationships, and structured data from parsed documents using natural language queries |

### Model Serving

Databricks Model Serving provides a flexible infrastructure for deploying and managing LLM endpoints. Key capabilities include:

- **Model Flexibility**: Switch between OpenAI GPT-4, Llama 3, Claude, or custom models without code changes
- **Cost Optimization**: Route simpler tasks to cost-effective models, reserve premium models for complex extraction
- **Custom Endpoints**: Deploy document-type specific endpoints with tailored prompts
- **Scalability**: Auto-scaling based on document processing volume
- **Version Control**: Deploy new model versions with rollback capability

### Prompt Engineering

Effective extraction relies on well-designed prompts that:

- Specify the exact output schema expected (JSON structure, field names, data types)
- Include confidence scoring requirements for extracted values
- Handle missing or ambiguous data gracefully (null values, low confidence flags)
- Provide context about document type and domain terminology
- Use few-shot examples when appropriate for complex extraction patterns

---

## Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| AI Processing Overview | End-to-end architecture showing input, processing, models, and output | [PNG](./diagrams/07_dta_ai_processing_overview.drawio.png) | [Draw.io](./diagrams/07_dta_ai_processing_overview.drawio) |
| Model Selection Strategy | Decision tree for routing documents to appropriate models | [PNG](./diagrams/07_dta_model_selection_strategy.drawio.png) | [Draw.io](./diagrams/07_dta_model_selection_strategy.drawio) |

### AI Processing Overview

![AI Processing Overview](./diagrams/07_dta_ai_processing_overview.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/07_dta_ai_processing_overview.drawio)

### Model Selection Strategy

![Model Selection Strategy](./diagrams/07_dta_model_selection_strategy.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/07_dta_model_selection_strategy.drawio)

---

## AI Capabilities

### `ai_parse_document` - Document Parsing

Parses unstructured documents into structured, queryable content. This function handles:

- **OCR Processing**: Converts scanned images and PDF text layers into machine-readable text
- **Layout Detection**: Identifies document structure including headers, paragraphs, lists, and sections
- **Table Detection**: Extracts tabular data preserving row/column relationships
- **Text Extraction**: Cleans and normalizes text content for downstream processing

### `ai_query` - Entity Extraction

Extracts specific entities and relationships from parsed documents using natural language queries. Supports:

- **Named Entity Recognition**: Identifies people, organizations, dates, locations
- **Key-Value Extraction**: Extracts specific fields based on query context
- **Relationship Extraction**: Identifies connections between entities (e.g., vendor-contact relationships)
- **Conditional Extraction**: Filters results based on specified criteria

### Model Serving - Custom Extraction

For complex extraction patterns, the platform uses Databricks Model Serving endpoints with custom prompts. This enables:

- **Schema-Guided Extraction**: Prompts that specify exact output structure
- **Multi-Model Routing**: Different models for different document types
- **Confidence Scoring**: Each extracted value includes a confidence score
- **Fallback Handling**: Automatic fallback to alternative models on failure

---

## Databricks Model Serving

**Databricks Model Serving** provides enterprise-grade infrastructure for deploying and managing Large Language Models (LLMs) at scale. The Clinical Data Standards platform leverages Model Serving as the recommended approach for AI-powered document processing.

### Why Databricks Model Serving?

| Capability | Benefit |
|------------|---------|
| **Unified Infrastructure** | Deploy any model (OpenAI, Llama, Claude, custom) through a single API |
| **A/B Testing** | Test multiple models simultaneously and route traffic based on performance |
| **Smart Routing** | Route requests to different models based on document type, complexity, or cost |
| **Auto-scaling** | Automatically scale endpoints based on demand |
| **Cost Optimization** | Monitor token usage and costs per model across your organization |
| **Version Control** | Deploy new model versions with zero-downtime rollback capability |
| **Security & Governance** | Centralized access control, audit logs, and compliance tracking |
| **Observability** | Built-in monitoring, metrics, and request tracing |

📚 **Official Documentation**: [Databricks Model Serving](https://docs.databricks.com/en/machine-learning/model-serving/index.html)

### Current Model Configuration

This project is configured to use:

| Model | Purpose | Configuration | Access Method |
|-------|---------|---------------|---------------|
| **GPT-4.1 Mini Global** 🟢 | Operational Agreement entity extraction | `gpt_entity_extractor` | External API endpoint |
| **Databricks Foundation Models** | Protocol processing, general extraction | `chatbot-endpoint-${bundle.target}` | Model Serving endpoint |

🟢 **Currently Active Model**

### Model Comparison

The following models are available through Databricks Model Serving endpoints:

| Model | Best For | Context Length | Cost | Latency |
|-------|----------|----------------|------|---------|
| **GPT-4.1 Mini** 🟢 | Balanced performance, cost-effective extraction | 128K | $ | Fast |
| **OpenAI GPT-4** | Complex reasoning, accuracy-critical extraction | 128K | $$$ | Medium |
| **OpenAI GPT-4o** | Balanced performance, general extraction | 128K | $$ | Fast |
| **Llama 3 70B** | Cost-effective processing, privacy-sensitive | 8K | $ | Fast |
| **Llama 3.1 405B** | Open-source, high capability | 128K | $$ | Medium |
| **Claude 3 Opus** | Very long documents (>100K tokens) | 200K | $$$ | Medium |
| **Claude 3 Sonnet** | Balanced, long context needs | 200K | $$ | Fast |
| **Custom Fine-tuned** | Domain-specific tasks (forms, checkboxes) | Varies | $ | Fast |

🟢 = Currently configured model for this project

### Switching Models

To switch to a different model, update `config/clinical_data_standards.yaml`:

```yaml
services:
  gpt_entity_extractor:
    type: "llm"
    endpoint: "https://your-endpoint"
    model: "gpt-4o"  # Change model here
    ...
```

No code changes required - the framework automatically routes requests to the configured model.

### Use Case Routing Strategy

When extending to multiple models, consider routing based on:

| Use Case | Recommended Model | Reason |
|----------|-------------------|---------|
| **Documents >100K tokens** | Claude 3 (200K context) | Handles very long protocols |
| **High-accuracy requirements** | GPT-4 | Best reasoning capability |
| **Cost-sensitive workloads** | Llama 3 70B | Open-source, self-hosted option |
| **Form/checkbox extraction** | Custom fine-tuned | Optimized for structured forms |
| **Privacy-sensitive data** | Self-hosted Llama | Data never leaves your infrastructure |
| **General extraction** | GPT-4.1 Mini / GPT-4o Mini 🟢 | Best balance of cost and performance |

---

## Databricks AI/BI Genie

**Databricks AI/BI Genie** is a conversational AI interface that enables users to query structured data using natural language instead of SQL. While Model Serving handles **document processing** (extraction), Genie handles **data querying** (search and analysis).

### Genie vs. Model Serving

| Aspect | Model Serving | Databricks Genie |
|--------|---------------|------------------|
| **Purpose** | Extract structured data from unstructured documents | Query structured data using natural language |
| **Input** | PDF, Word, Excel documents | User questions in plain English |
| **Output** | Structured metadata (JSON, tables) | Query results (tables, charts) |
| **Use Case** | Parse Protocol PDFs, extract OA entities | Search DTAs, query version history |
| **Backend** | LLM endpoints (GPT, Llama, Claude) | Unity Catalog + SQL generation |
| **Integration** | Document processing pipelines | DTA Builder search UI |

### Genie in DTA Builder

The DTA Builder UI integrates Genie to enable conversational search and discovery:

**Example Questions:**
- "Find all Labs DTAs from LabCorp"
- "Show me DTAs approved in the last 30 days"
- "What are the latest versions for vendor Clario?"
- "List all transfer variables for DTA001 that have status ACTIVE"

**Key Capabilities:**
- **Context-Aware**: Remembers conversation history for follow-up questions
- **Permission-Enforced**: Only shows data the user has access to via Unity Catalog
- **SQL Transparency**: Displays generated SQL for learning and validation
- **Multi-Table Joins**: Automatically joins across gold tables (DTA, workflows, versions)

### Genie Space Configuration

A **Genie Space** is preconfigured with:
- **Tables**: All gold layer tables (`dta`, `md_dta_transfer_variables`, `dta_workflow`, etc.)
- **Instructions**: Domain guidance on DTA terminology and query patterns
- **Sample Questions**: Pre-built questions to help users get started
- **Example Queries**: Parameterized SQL queries that train Genie on correct patterns

The `job_cdm_export_genie_assets` job automatically generates these assets by:
1. Discovering all relevant gold tables
2. Generating SQL comments for tables/columns
3. Creating 15+ example queries with natural language questions
4. Assembling the complete space configuration

📚 **Official Documentation**: [Databricks AI/BI Genie](https://docs.databricks.com/en/genie/index.html)

**For detailed implementation**: See [09_dta_genie_integration_design.readme.md](./09_dta_genie_integration_design.readme.md) for complete setup, asset generation, and API integration.

---

## Patterns

### Checkbox Extraction

Detects checked and unchecked boxes in scanned forms or PDFs. The model identifies checkbox symbols (☑, ☐, ✓, X) and their associated labels, returning structured JSON with:

- Label/description of each checkbox
- Checked state (true/false)
- Confidence score (0.0-1.0)

Used for processing clinical forms where requirements or options are indicated via checkboxes.

### Entity Extraction with Schema

Extracts entities matching a predefined schema from unstructured text. The prompt specifies the exact fields required (vendor name, contract dates, transfer frequency, data formats) and their expected data types. The model returns:

- Field values matching the schema
- Null values for fields not found in the document
- Confidence scores for each extracted field

Enables consistent, structured output regardless of how information is presented in source documents.

### Protocol Document Parsing

Processes clinical protocol documents to extract study design information. The model identifies section headers (Objectives, Endpoints, Inclusion/Exclusion Criteria) and extracts:

- Study title and identifiers
- Primary and secondary objectives
- Primary, secondary, and exploratory endpoints
- Inclusion and exclusion criteria as structured lists

### Schedule of Activities Table Extraction

Extracts Time and Visit data from Schedule of Activities (SoA) tables found in Protocol documents. These tables define:

- **Visits**: Study visit identifiers (Screening, Day 1, Week 4, etc.)
- **Timepoints**: Timing relative to study milestones
- **Procedures**: Activities performed at each visit (marked with X or specific codes)

The extraction uses a **multi-phase orchestration pipeline** with five specialized prompts:

1. **Table Classification**: Identifies table type (Guide Table, Detailed SoA, Transposed SoA, Assessment Table)
2. **Visit Extraction**: Parses column/row headers for visit identifiers and timing windows
3. **Procedure Extraction**: Extracts procedure names and categories from row/column headers
4. **Mapping Extraction**: Creates procedure-visit intersection matrix with markers (X, footnotes, conditions)
5. **Footnote Extraction**: Captures timing conditions, population criteria, and special instructions

The model preserves the tabular structure while extracting:

- Visit names and timing windows
- Procedure-to-visit mappings with conditional requirements
- Visit sequence and dependencies
- Footnote conditions that modify procedure requirements

This extraction is critical for generating study calendars and procedure schedules from protocol documents.

**For detailed implementation**: See [10_dta_protocol_document_design.readme.md](./10_dta_protocol_document_design.readme.md) for complete prompt engineering, data models, and UI workflows.

---

## Related Documentation

- [01_dta_job_architecture_design.readme.md](./01_dta_job_architecture_design.readme.md) - Overall pipeline architecture
- [02_dta_schema_design.readme.md](./02_dta_schema_design.readme.md) - Schema for extracted data
- [03_dta_status_lifecycle_design.readme.md](./03_dta_status_lifecycle_design.readme.md) - Document processing statuses
- [09_dta_genie_integration_design.readme.md](./09_dta_genie_integration_design.readme.md) - Detailed Genie integration, asset generation, and API
- [10_dta_protocol_document_design.readme.md](./10_dta_protocol_document_design.readme.md) - Detailed Schedule of Activities extraction implementation

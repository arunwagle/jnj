# Scalable CDH Clinical Data File Processing Architecture

## Table of Contents

1. [Overview](#overview)
   - [Problem Statement](#problem-statement)
   - [Architectural Enhancement Opportunities](#architectural-enhancement-opportunities)
2. [When Is Each Approach Most Effective?](#when-is-each-approach-most-effective)
   - [Per-Document Partitioning Effectiveness by Document Count](#per-document-partitioning-effectiveness-by-document-count)
   - [Adaptive Partitioning Strategy (Recommended Quick Win)](#adaptive-partitioning-strategy-recommended-quick-win)
   - [Streaming with foreachBatch (Long-Term Solution)](#streaming-with-foreachbatch-long-term-solution)
   - [Performance Comparison: Batch vs Streaming](#performance-comparison-batch-vs-streaming)
   - [Decision Matrix](#decision-matrix)
   - [Solution](#solution)
3. [Scalable CDH Clinical Data File Processing Architecture](#scalable-cdh-clinical-data-file-processing-architecture-1)
   - [Design Principles](#design-principles)
   - [1. Auto Loader for File Ingestion](#1-auto-loader-for-file-ingestion)
   - [2. Document Partitioning Strategy](#2-document-partitioning-strategy)
   - [3. Excel File Processing: Status-Based Parallel Architecture](#3-excel-file-processing-status-based-parallel-architecture)
   - [4. Protocol & Operational Agreement Processing: Parallel Entity Extraction](#4-protocol--operational-agreement-processing-parallel-entity-extraction)
   - [5. Scalability Analysis: 1 to 10,000+ Files](#5-scalability-analysis-1-to-10000-files)
   - [6. Failure Handling & Recovery](#6-failure-handling--recovery)
4. [Diagrams](#diagrams)
   - [Streaming Architecture Overview](#streaming-architecture-overview)
   - [Document-Level Parallelism](#document-level-parallelism)
   - [Checkpoint & Recovery Flow](#checkpoint--recovery-flow)
   - [Monitoring Dashboard Design](#monitoring-dashboard-design)

---

## Overview

This document describes the architecture that can enable scaling of ingestion further for CDH platform. The proposed solution enhances the current batch-based system by introducing **document-level parallelism** through Databricks Structured Streaming, unlocking 3-10x performance improvements for high-volume document ingestion.

### Problem Statement: Architectural Considerations for Clinical Data Ingestion at Scale

Clinical data ingestion platforms must handle diverse document types (Excel, PDF, Word) from multiple vendors across hundreds of studies. As volume scales from single uploads to thousands of files per day, several **architectural bottlenecks** can emerge that prevent linear cost scaling:

#### Common Architectural Bottlenecks

**1. Document Processing Granularity**
- **Challenge**: Grouping multiple documents into processing batches can create sequential processing within groups
- **Impact**: Even with parallel infrastructure, documents may wait for others in their group to complete
- **Scale Effect**: 100 documents grouped into 10 batches → 10 sequential processing cycles instead of 100 parallel operations

**2. Compute Resource Utilization**
- **Challenge**: Processing strategies that create too few work units (partitions) cannot fully utilize available compute capacity
- **Impact**: Auto-scaling infrastructure remains underutilized despite pending work
- **Example**: 5 work units on 20-worker serverless cluster → 75% capacity idle

**3. Monolithic Job Design**
- **Challenge**: Single orchestrator job handling all document types and processing stages
- **Impact**: Bottlenecks in one document type (e.g., large Excel files) block processing of others (e.g., PDFs)
- **Scale Effect**: Sequential job steps prevent concurrent processing of independent work streams

**4. Status and Workflow Coordination**
- **Challenge**: Without fine-grained status tracking, restart from failure requires reprocessing all documents
- **Impact**: Partial failures cause full reprocessing, wasting compute and time
- **Recovery Time**: 50 documents with 1 failure → reprocess all 50 instead of retrying 1

**5. Child Data Structure Creation**
- **Challenge**: Documents often require creating multiple child records (e.g., Excel sheets, PDF sections)
- **Impact**: Sequential child extraction limits parallelism opportunities
- **Example**: Excel with 100 sheets processing 1 sheet at a time vs. parallel sheet extraction

#### Architectural Requirements for Scale

To support **10,000+ files per day across 200+ studies**, the architecture must address:

| Requirement | Architectural Need | Enabler |
|-------------|-------------------|---------|
| **Linear Cost Scaling** | Processing time should not increase linearly with file count | Per-document parallelism + auto-scaling |
| **Study Isolation** | Work from different studies shouldn't block each other | Study-level partitioning |
| **Vendor Concurrency** | Multiple vendors can submit simultaneously | Distributed processing queue |
| **Failure Resilience** | One document failure doesn't block others | Status-driven workflow with independent processors |
| **Format Flexibility** | Excel, PDF, Word require different processing logic | Specialized processors per document type |
| **Exactly-Once Semantics** | No duplicate processing even with retries | Checkpoint-based idempotency |

### Architectural Solutions

The proposed architecture addresses these bottlenecks through three key strategies:

**1. Per-Document Partitioning**
- Create one partition per document instead of grouping
- Enables serverless to scale workers to match document count
- **Impact**: 50 documents process in parallel (20 workers × 3 rounds = 18 min) vs. sequential batches (60 min)

**2. Distributed Status-Driven Processors**
- Replace monolithic job with independent processors watching status table
- Each processor handles specific document type or processing stage
- **Impact**: Excel, Protocol, OA processing happens concurrently; failures isolated per processor

**3. Child Table Parallelism**
- Extract child structures (sheets, sections, entities) in parallel using `mapInPandas`
- Use `trigger(availableNow=True)` for exactly-once processing
- **Impact**: 100-sheet Excel processes all sheets concurrently instead of sequentially

**Result**: Platform can scale from single files to 10,000+ files/day with linear cost (not linear time) scaling.

---

## When Is Each Approach Most Effective?

### Quick Reference Summary

| Document Count | Current Approach | Recommended Solution | Expected Improvement | Implementation Effort |
|----------------|------------------|---------------------|---------------------|----------------------|
| **1 document** | ✅ Optimal | Keep current | None (0%) | No change needed |
| **2-9 documents** | ⚠️ Acceptable | Adaptive Partitioning | 2-3× faster | Low (1 line code change) |
| **10-50 documents** | ❌ Bottleneck | Adaptive Partitioning | 3-6× faster | Low (1 line code change) |
| **50-100 documents** | ❌ Bottleneck | Adaptive Partitioning | 6-10× faster | Low (1 line code change) |
| **100+ documents** | ❌ Bottleneck | Streaming + Adaptive | 10× faster | Medium (new job architecture) |
| **Continuous arrival** | ❌ Batching delays | Streaming with foreachBatch | 4-10× lower latency | Medium (new job architecture) |
| **Mixed workload** | ⚠️ Varies | Streaming with foreachBatch | Optimal for all cases | Medium (new job architecture) |

**Key Insights**:
- **Single documents**: No optimization needed - sheet-level parallelism already optimal
- **Small-medium batches (10-100 docs)**: Adaptive partitioning provides significant improvement with minimal effort
- **Large batches or continuous ingestion**: Full streaming architecture recommended for best performance

---

### Per-Document Partitioning Effectiveness by Document Count

The benefit of per-document partitioning varies significantly based on batch size:

#### Small Document Counts (1-5 documents)

**Current Approach:**
```python
num_partitions = doc_count // 10
# 1 document → 1 partition (optimal already)
# 5 documents → 1 partition (sequential processing)
```

**Per-Document Partitioning:**
```python
num_partitions = doc_count
# 1 document → 1 partition (same as current, NO improvement)
# 5 documents → 5 partitions (parallel processing)
```

| Documents | Current Time | Per-Doc Partition | Improvement | Worth It? |
|-----------|--------------|-------------------|-------------|-----------|
| 1 doc | 6 min | 6 min | 0% | ❌ No benefit |
| 2 docs | 12 min | 6-8 min | 33-50% | ⚠️ Marginal |
| 5 docs | 30 min | 6-8 min | 73-80% | ✅ Yes |
| 10 docs | 60 min | 20 min | 67% | ✅ Significant |
| 50 docs | 180 min | 25 min | 86% | ✅ Very significant |

**Key Insight for Single Document:**
For 1 document, per-document partitioning provides **ZERO benefit** because both approaches create 1 partition. The existing sheet-level parallelism (mapInPandas) already handles single documents optimally.

#### The Sweet Spot

Per-document partitioning is most effective for:
- ✅ **10-100 documents**: Dramatic improvement (3-10x faster)
- ⚠️ **5-9 documents**: Moderate improvement (2-3x faster)
- ⚠️ **2-4 documents**: Small improvement (< 2x faster)
- ❌ **1 document**: No improvement at all

### Adaptive Partitioning Strategy (Recommended Quick Win)

Instead of always using per-document partitioning, use an adaptive approach:

```python
# Smart partitioning based on document count
if doc_count == 1:
    # Single doc: Use default (sheet-level parallelism is sufficient)
    num_partitions = 1
    print("Single document: Using sheet-level parallelism only")
    
elif doc_count <= 10:
    # Small batch: 1 document per partition for full parallelism
    num_partitions = doc_count
    print(f"Small batch ({doc_count} docs): Per-document partitioning")
    
else:
    # Large batch: Cap partitions at serverless max to avoid excessive overhead
    # Serverless will auto-scale workers to match partition count
    max_serverless_workers = 200  # Serverless max workers configured
    num_partitions = min(doc_count, max_serverless_workers)
    print(f"Large batch ({doc_count} docs): Capped at {num_partitions} partitions")

# Repartition by document_id to ensure documents don't get grouped together
df_repartitioned = df_filtered.repartition(num_partitions, "document_id")
```

**Benefits:**
- ✅ No overhead for single documents (most common case for UI uploads)
- ✅ Optimal parallelism for small-medium batches
- ✅ Prevents over-partitioning for very large batches
- ✅ Single line of code change from current implementation

### Streaming with foreachBatch (Long-Term Solution)

For continuous ingestion or unpredictable batch sizes, streaming handles all cases optimally:

```python
# Streaming approach - works well for ANY document count
spark.readStream
  .format("delta")
  .table("md_file_history")
  .filter("status = 'READY_FOR_PROCESSING'")
  .writeStream
  .foreachBatch(lambda df, epoch_id: process_micro_batch(df, epoch_id))
  .trigger(processingTime="30 seconds")
  .start()

def process_micro_batch(df, epoch_id):
    doc_count = df.count()
    
    if doc_count == 0:
        return  # Skip empty batches
    
    print(f"Micro-batch {epoch_id}: Processing {doc_count} documents")
    
    # Streaming automatically optimizes per-batch
    # Each document gets its own partition within the micro-batch
    processed_df = df.repartition(doc_count, "document_id") \
                     .mapInPandas(process_excel_pandas, schema)
    
    processed_df.write.mode("append").saveAsTable("output")
```

**Advantages:**
- ✅ Handles 1 document or 100 documents equally well
- ✅ Processes documents **immediately** after arrival (5-30s latency vs 120s batch wait)
- ✅ Natural per-document partitioning in each micro-batch
- ✅ Built-in checkpointing and exactly-once semantics
- ✅ Auto-scaling based on queue depth
- ✅ Failed documents don't block entire batch

### Performance Comparison: Batch vs Streaming

| Scenario | Current Batch | Adaptive Partition | Streaming | Winner |
|----------|---------------|-------------------|-----------|--------|
| **1 document** | 6 min | 6 min | 6 min | ✅ **All equal** |
| **5 documents** | 30 min (sequential) | 6-8 min (parallel) | 6-8 min (parallel) | ✅ **Adaptive or Streaming** |
| **10 documents** | 60 min | 20 min | 20 min | ✅ **Adaptive or Streaming** |
| **50 documents** | 180 min (queuing) | 25 min | 25 min | ✅ **Adaptive or Streaming** |
| **100 documents** | 300 min | 30 min | 30 min | ✅ **Adaptive or Streaming** |
| **Continuous arrival** | Waits 120s | Waits 120s | 5-30s latency | ✅ **Streaming only** |
| **Mixed sizes (1-100)** | Varies (poor for large) | Optimal for each | Optimal for all | ✅ **Streaming** |

### Decision Matrix

Use this matrix to choose the right approach:

```
Batch Size        | Current Good? | Quick Win        | Long-Term
------------------|---------------|------------------|------------------
1 document        | ✅ Yes        | ⏸️ Keep current  | ⏸️ Streaming (future-proof)
2-9 documents     | ⚠️ OK        | ✅ Adaptive      | ✅ Streaming
10-50 documents   | ❌ No        | ✅ Adaptive      | ✅ Streaming
50+ documents     | ❌ No        | ✅ Adaptive      | ✅ Streaming
Continuous        | ❌ No        | ❌ N/A           | ✅ Streaming only
```

**Key Takeaway:** For single document uploads (common in UI), there is no performance benefit from per-document partitioning. The enhancement targets batch scenarios with 10+ documents where linear scaling becomes problematic.

---

### Solution

A **streaming-based ingestion architecture** that treats the Delta table (`md_file_history`) as a distributed work queue, enabling:

1. **Document-level parallelism**: Multiple documents processed simultaneously across Spark executors
2. **Continuous processing**: Eliminates file arrival trigger delays (60-120s → 5-30s latency)
3. **Auto-scaling**: Serverless compute scales workers based on queue depth
4. **Exactly-once semantics**: Checkpoint-based idempotency with optimistic locking
5. **Fault tolerance**: Failed documents don't block entire job run

---

## Scalable CDH Clinical Data File Processing Architecture

### Architecture Overview

The scalable CDH architecture **redesigns the monolithic `job_cdm_dta_import`** into a distributed, status-driven system. Instead of a single job processing all documents sequentially, the new architecture uses:

1. **Two-Stage Pipeline**: File ingestion → Status-driven processing
2. **Distributed Work Queue**: `md_file_history` table acts as a status-based queue
3. **Independent Processors**: Multiple specialized processors monitor status and process in parallel
4. **Adaptive Partitioning**: Each processor scales based on document count

This enables the platform to scale from single file uploads to **tens of thousands of files per day** across hundreds of studies with **linear cost** (not linear time) scaling.

---

### Design Principles

| Principle | Implementation | Benefit |
|-----------|----------------|---------|
| **Distributed Processing** | Independent processors watch status table | No single point of bottleneck |
| **Study Isolation** | Partition by study_id | 100 studies → 100 parallel streams |
| **Vendor Concurrency** | Partition by vendor_id | Multiple vendors don't block each other |
| **Document Type Specialization** | Separate processors for Excel, PDF, Word | Format-specific optimizations |
| **Status-Driven Flow** | Each processor updates status when complete | Enables checkpointing and recovery |
| **Exactly-Once Semantics** | trigger(availableNow=True) + checkpoints | No duplicate processing |

---

### 1. Two-Stage Pipeline Architecture

#### Stage 1: File Ingestion (Auto Loader → Metadata Table)

**Technology**: [Databricks Auto Loader](https://docs.databricks.com/aws/en/ingestion/cloud-object-storage/auto-loader/) with `trigger(availableNow=True)`

**Conceptual Flow**:
```
Landing Zone (Cloud Storage)
        ↓
   Auto Loader (readStream)
        ↓
  md_file_history table
   (status = 'UPLOADED')
```

**Why Auto Loader?**

| Capability | Benefit | Scale Impact |
|------------|---------|--------------|
| **Scalability** | Can discover billions of files efficiently | Handles 10,000+ files/day without degradation |
| **Cost Efficiency** | Uses native cloud APIs, file notification mode | Cost scales with files ingested, not total files |
| **Exactly-Once** | Built-in checkpoint mechanism (RocksDB) | No duplicate processing even with retries |
| **Schema Evolution** | Automatic schema detection and drift handling | New file columns handled gracefully |
| **Incremental** | Processes only new files since last checkpoint | Constant startup time regardless of history |

**Landing Zone Structure**:
```
/Volumes/{catalog}/{schema}/clinical_data_standards/
  └── landing/
      ├── study_123/vendor_A/upload_2026-02-03_10-30/
      │   ├── dta_template_v1.xlsx
      │   ├── protocol_document.pdf
      │   └── operational_agreement.docx
      └── study_456/vendor_B/upload_2026-02-03_14-15/
          └── dta_template_v2.xlsx
```

**Ingestion Process**:
1. Vendors upload files to study/vendor-specific folders
2. Auto Loader detects new files within 5-30 seconds
3. File metadata written to `md_file_history` with:
   - `status = 'UPLOADED'`
   - `document_type` (Excel, PDF, Word)
   - `study_id`, `vendor_id`, `document_id`
4. Stage 1 complete - file now visible to downstream processors

#### Stage 2: Status-Driven Distributed Processing

**The Core Innovation**: `md_file_history` becomes a **distributed work queue**. Multiple independent processors watch for documents at specific statuses and process them in parallel.

**Processor Architecture**:
```
md_file_history (Status-Driven Queue)
    │
    ├─→ Excel Processor → [status='UPLOADED' AND file_type='excel']
    │       ↓
    │   Extracts sheets → md_dta_excel_sheets (child tables)
    │       ↓
    │   Updates: status='SHEETS_EXTRACTED'
    │
    ├─→ Protocol Processor → [status='UPLOADED' AND file_type='pdf']
    │   ├── Task 1: Entity Extraction → md_protocol_entities
    │   └── Task 2: Section Processing → md_protocol_sections
    │       ↓
    │   Updates: status='PROTOCOL_PROCESSED'
    │
    ├─→ OA Processor → [status='UPLOADED' AND file_type='docx']
    │       ↓
    │   Extracts config tables → md_oa_attributes, md_oa_options
    │       ↓
    │   Updates: status='OA_PROCESSED'
    │
    ├─→ Validation Processor → [status='SHEETS_EXTRACTED']
    │       ↓
    │   Validates data quality → Updates: status='VALIDATED'
    │
    ├─→ Categorization Processor → [status='VALIDATED']
    │       ↓
    │   Classifies variables → Updates: status='CATEGORIZED'
    │
    └─→ DTA Creator → [status='CATEGORIZED']
            ↓
        Creates final DTA → Updates: status='COMPLETE'
```

**Key Difference from Monolithic Job**:

| Aspect | Old (Monolithic) | New (Distributed) |
|--------|------------------|-------------------|
| **Architecture** | Single job processes all steps | Multiple independent processors |
| **Bottleneck** | One job handles everything sequentially | Each processor scales independently |
| **Parallelism** | Limited by job design | Natural parallelism via status partitioning |
| **Failure Impact** | Entire job fails | Only affected processor fails, others continue |
| **Scalability** | Add more workers to one job | Add more processors watching different statuses |

---

### 2. Excel File Processing: Status-Based Workflow

**DTA Templates** (Excel files) require multi-stage processing: extraction, validation, categorization. Each stage is handled by an independent processor.

#### Complete Status Lifecycle

| Status | Processor | Action | Child Tables Created | Parallelism |
|--------|-----------|--------|---------------------|-------------|
| `UPLOADED` | Auto Loader | File metadata captured | — | File detection |
| `SHEETS_EXTRACTED` | Excel Processor | Extracts all sheets from Excel | `md_dta_excel_sheets` (one row per sheet) | **Document-level** (10 files → 10 parallel) |
| | | | | **Sheet-level** (50 sheets → mapInPandas parallel) |
| `VALIDATED` | Validation Processor | Applies business rules | `md_dta_validation_errors` | **Document-level** |
| `CATEGORIZED` | Categorization Processor | Classifies variables | `md_dta_transfer_variables` | **Document-level** |
| | | | `md_dta_test_concepts` | |
| `COMPLETE` | DTA Creator | Creates final DTA record | `md_dta_main` (Gold) | **Document-level** |
| `FAILED` | — | Error occurred | `error_message` populated | Manual review |

#### Excel Processor: Multi-Level Parallelism

**Processor Trigger**:
```python
# Runs with trigger(availableNow=True) - processes all available work, then stops
df_to_process = spark.readStream
  .table("md_file_history")
  .filter("status = 'UPLOADED' AND document_type = 'DTA_TEMPLATE'")
```

**Adaptive Partitioning**:
```python
doc_count = df_to_process.count()

if doc_count <= 10:
    num_partitions = doc_count  # 1 document per partition
else:
    num_partitions = min(doc_count, 200)  # Cap at serverless max

# Partition by document_id for document-level parallelism
df_partitioned = df_to_process.repartition(num_partitions, "document_id")
```

**Sheet Extraction with mapInPandas**:
```python
# Within each partition, sheets process in parallel
df_sheets = df_partitioned.mapInPandas(extract_sheets_pandas, output_schema)
df_sheets.write.mode("append").table("md_dta_excel_sheets")

# Update status
update_status(document_ids, new_status="SHEETS_EXTRACTED")
```

**Parallelism Example**:
- **Scenario**: 50 Excel files arrive (10 files from 5 different vendors)
- **Old Architecture**: 5 partitions (10 docs each) → 60 min per partition → 60 min total
- **New Architecture**: 50 partitions (1 doc each) → serverless scales to 20 workers → 3 rounds × 6 min → **18 min total**

---

### 3. Protocol & Operational Agreement: Parallel Task Processing

**Protocol (PDF)** and **Operational Agreement (Word)** documents require LLM-based extraction. The key innovation is **parallel task execution** within the processor.

#### Protocol Processor: Two Parallel Tasks

**Processor Design**:
```
Protocol Processor (triggered by status='UPLOADED' AND document_type='PROTOCOL')
    │
    ├─→ Task 1: Entity Extraction (parallel)
    │     ├── Study Title
    │     ├── Principal Investigator
    │     ├── NCT Number
    │     └── Therapeutic Area
    │       ↓
    │   Writes to: md_protocol_entities
    │
    └─→ Task 2: Section Processing (parallel)
          ├── Schedule of Activities (LLM extraction)
          ├── Endpoints & Assessments (LLM extraction)
          └── Study Population (LLM extraction)
            ↓
        Writes to: md_protocol_sections, md_protocol_soa

Both tasks run simultaneously → Total time: max(Task1, Task2) instead of Task1 + Task2
```

**Parallelism Benefits**:
- **Sequential**: Entity extraction (1 min) + Section processing (4 min) = **5 minutes**
- **Parallel**: max(1 min, 4 min) = **4 minutes** (20% faster)
- **With 10 protocols**: Old = 50 min, New (10 parallel docs × 4 min) = **4 minutes** (12× faster)

#### OA Processor: Parallel Configuration Extraction

**Processor Design**:
```
OA Processor (triggered by status='UPLOADED' AND document_type='OA')
    │
    ├─→ Extract Attributes table → md_oa_attributes
    ├─→ Extract Options table → md_oa_options
    └─→ Extract Other metadata → md_oa_other
          ↓
    All three tables extracted in parallel using mapInPandas
    Updates: status='OA_PROCESSED'
```

**Child Tables**:
- Each OA document creates 3 child tables
- Tables extracted in parallel (not sequential)
- 10 OA documents = 30 child tables created concurrently

---

### 4. Scalability Analysis: 1 to 10,000+ Files

The distributed processor architecture scales naturally from single uploads to production volumes of 10,000+ files per day.

#### Scaling by File Count

| Files | Processors Active | Serverless Workers | Processing Time | Bottleneck |
|-------|-------------------|-------------------|-----------------|------------|
| **1** | 1 (Excel OR Protocol OR OA) | 1-2 | 6-8 min | Sheet extraction |
| **10** | 3 (Excel, Protocol, OA parallel) | 5-10 | 8-12 min | None (distributed) |
| **50** | 3 processors × adaptive partitions | 15-20 | 15-20 min | None |
| **100** | 3 processors × 100 partitions | 20-30 | 20-25 min | Serverless max workers |
| **500** | All processors continuously active | 20-50 | **Continuous** | None (processes as arrive) |
| **10,000+** | All processors continuously active | Auto-scales | **Continuous** | None (distributed queue) |

**Key Insight**: Time does NOT increase linearly because:
1. **Multiple processors** handle different document types simultaneously
2. **Adaptive partitioning** maximizes parallelism within each processor
3. **Status-based queuing** eliminates job-level bottlenecks
4. **Serverless auto-scaling** matches worker count to partition count

#### Real-World Scenario: 50 Studies, 250 Vendor Uploads/Day

**Daily Load**:
- 50 active studies
- 5 vendors per study (250 vendor relationships)
- Each vendor sends 2-5 files/day
- **Total: 500-1,250 files/day** (mix of Excel, PDF, Word)

**Key Architecture Benefits**:
- **Distributed Processing**: Excel, Protocol, and OA processors run independently
- **Study-Level Parallelism**: 50 studies create 50 independent processing streams
- **Vendor-Level Parallelism**: 250 vendor uploads process without blocking each other
- **Auto-Scaling**: Serverless scales from 0 workers (idle) to 50+ workers (peak load) automatically
- **Status-Driven Recovery**: Failed documents retry independently without blocking others

**Result**: Files process as they arrive with minimal latency. The same architecture handles 10× volume increase with no redesign required.

---

### 5. Failure Handling & Recovery

The status-driven architecture provides **automatic recovery** and **failure isolation**.

#### Failure Isolation by Processor

| Failure Scenario | Impact | Recovery | Other Processors |
|------------------|--------|----------|------------------|
| **Excel processor fails** | Excel files stuck at status='UPLOADED' | Restart Excel processor only | Protocol & OA processors continue |
| **Protocol LLM timeout** | Protocol files stuck at status='UPLOADED' | Retry with exponential backoff | Excel & OA processors continue |
| **Validation processor fails** | Files stuck at status='SHEETS_EXTRACTED' | Restart validation processor | Upstream processors continue |

**Automatic Recovery**:
```sql
-- Orphaned Document Detection (scheduled every 30 min)
SELECT document_id, status, processing_start_ts
FROM md_file_history
WHERE status IN ('EXTRACTING_SHEETS', 'VALIDATING', 'CATEGORIZING')
  AND processing_start_ts < current_timestamp() - INTERVAL 30 MINUTES;

-- Automatic Reset Action
UPDATE md_file_history
SET status = (CASE 
    WHEN status = 'EXTRACTING_SHEETS' THEN 'UPLOADED'
    WHEN status = 'VALIDATING' THEN 'SHEETS_EXTRACTED'
    WHEN status = 'CATEGORIZING' THEN 'VALIDATED'
  END),
  retry_count = retry_count + 1
WHERE document_id IN (orphaned_document_ids)
  AND retry_count < 3;
```

#### Exactly-Once Semantics

**How it works**:
1. **Checkpoint per processor**: Each processor has its own checkpoint location
2. **Status update is atomic**: Document moves to next status only after successful processing
3. **Idempotent operations**: Reprocessing same document produces same result
4. **trigger(availableNow=True)**: Processes all available work, then stops (no duplicates)

**Example Recovery Flow**:
```
Excel file uploaded → status='UPLOADED'
    ↓
Excel processor starts extraction → status='EXTRACTING_SHEETS'
    ↓
[CRASH - Processor fails at 50% complete]
    ↓
Orphaned document detected (status still 'EXTRACTING_SHEETS' after 30 min)
    ↓
Automatic reset → status='UPLOADED'
    ↓
Excel processor restarts → Reprocesses from beginning → status='SHEETS_EXTRACTED' ✓
```

**No data loss** because:
- Original file retained in landing zone
- Checkpoint ensures restart from beginning of failed document
- Child tables use `mode="append"` with deduplication by document_id

---

## Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| Streaming Architecture Overview | End-to-end streaming pipeline with parallel processors | [PNG](./diagrams/11_streaming_architecture_overview.png) | [Draw.io](./diagrams/11_streaming_architecture_overview.drawio) |
| Document-Level Parallelism | Two-level parallelism: document AND sheet level | [PNG](./diagrams/11_document_level_parallelism.png) | [Draw.io](./diagrams/11_document_level_parallelism.drawio) |
| Checkpoint & Recovery Flow | Exactly-once processing with failure recovery | [PNG](./diagrams/11_checkpoint_recovery.png) | [Draw.io](./diagrams/11_checkpoint_recovery.drawio) |
| Monitoring Dashboard Design | Observability metrics and dashboards | [PNG](./diagrams/11_monitoring_dashboard.png) | [Draw.io](./diagrams/11_monitoring_dashboard.drawio) |

### Streaming Architecture Overview

![Streaming Architecture Overview](./diagrams/11_streaming_architecture_overview.png)

📝 [Edit Diagram (Draw.io)](./diagrams/11_streaming_architecture_overview.drawio)

### Document-Level Parallelism

![Document-Level Parallelism](./diagrams/11_document_level_parallelism.png)

📝 [Edit Diagram (Draw.io)](./diagrams/11_document_level_parallelism.drawio)

### Checkpoint & Recovery Flow

![Checkpoint & Recovery Flow](./diagrams/11_checkpoint_recovery.png)

📝 [Edit Diagram (Draw.io)](./diagrams/11_checkpoint_recovery.drawio)

### Monitoring Dashboard Design

![Monitoring Dashboard Design](./diagrams/11_monitoring_dashboard.png)

📝 [Edit Diagram (Draw.io)](./diagrams/11_monitoring_dashboard.drawio)

---


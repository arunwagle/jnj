"""
Configuration Manager for Pipeline Orchestration

Loads and manages YAML-based pipeline configurations with support for:
- Hierarchical pipeline structure (Use Case → Document Type → Sub-Type → Steps)
- Service definitions and reusability
- Variable substitution (${globals.*}, ${bundle.target})
- Environment-specific configurations
"""

import yaml
import re
import os
from typing import Dict, List, Optional, Any
from pathlib import Path


class ConfigManager:
    """
    Centralized configuration management for data pipelines.
    
    Provides simple API to:
    1. Get pipeline step configurations
    2. Get service configurations
    
    Example:
        config = ConfigManager("config/my_config.yaml", target="dev")
        
        # Get a specific step configuration
        step_config = config.get_pipeline_step(
            use_case="DOCUMENT_PROCESSING",
            document_type="pdf",
            document_subtype="standard",
            step_name="parse_document"
        )
        
        # Get service configuration
        service_config = config.get_service("document_parser_default")
    """
    
    def __init__(self, config_path: str, target: str = "dev"):
        """
        Initialize ConfigManager with a YAML configuration file.
        
        Args:
            config_path: Path to YAML configuration file (absolute or relative)
            target: Deployment target (dev/staging/prod) for variable substitution
        """
        self.config_path = config_path
        self.target = target
        self.config = self._load_config()
        self._validate_config()
    
    # ============================================================
    # CORE API METHODS
    # ============================================================
    
    def get_pipeline_step(
        self,
        use_case: str,
        document_type: str,
        document_subtype: str,
        step_name: str
    ) -> Dict[str, Any]:
        """
        Get configuration for a specific pipeline step.
        
        Returns the complete step configuration including:
        - service: Service name to use
        - All step-specific parameters
        - Resolved variables (${globals.*}, ${bundle.target})
        
        Args:
            use_case: Use case name (e.g., "DOCUMENT_PROCESSING")
            document_type: Document type (e.g., "pdf", "json", "excel")
            document_subtype: Document subtype (e.g., "standard", "complex")
            step_name: Step name (e.g., "parse_document", "extract_entities")
        
        Returns:
            Dictionary containing step configuration
            
        Raises:
            ValueError: If pipeline or step not found
            
        Example:
            >>> config.get_pipeline_step(
            ...     use_case="DOCUMENT_PROCESSING",
            ...     document_type="pdf",
            ...     document_subtype="standard",
            ...     step_name="parse_document"
            ... )
            {
                'step': 'parse_document',
                'service': 'document_parser_default',
                'source_path': '/Volumes/catalog/schema/landing/entity',
                'output_table': 'schema.entity_documents_raw',
                'partition_by': ['processing_date']
            }
        """
        # Navigate to the pipeline
        pipelines = self.config.get("pipelines", {})
        
        if use_case not in pipelines:
            raise ValueError(f"Use case '{use_case}' not found in configuration")
        
        pipeline = pipelines[use_case]
        
        if document_type not in pipeline:
            raise ValueError(
                f"Document type '{document_type}' not found in use case '{use_case}'"
            )
        
        doc_type_config = pipeline[document_type]
        
        if document_subtype not in doc_type_config:
            raise ValueError(
                f"Document subtype '{document_subtype}' not found in "
                f"'{use_case}.{document_type}'"
            )
        
        subtype_config = doc_type_config[document_subtype]
        
        # Get steps
        steps = subtype_config.get("steps", [])
        
        # Find the specific step
        for step in steps:
            if step.get("step") == step_name:
                # Perform variable substitution
                resolved_step = self._resolve_variables(step)
                return resolved_step
        
        raise ValueError(
            f"Step '{step_name}' not found in "
            f"'{use_case}.{document_type}.{document_subtype}'"
        )
    
    def get_service(self, service_name: str) -> Dict[str, Any]:
        """
        Get configuration for a specific service.
        
        Returns the complete service configuration with resolved variables.
        
        Args:
            service_name: Service name (e.g., "document_parser_default", 
                         "entity_extractor_default")
        
        Returns:
            Dictionary containing service configuration
            
        Raises:
            ValueError: If service not found
            
        Example:
            >>> config.get_service("document_parser_default")
            {
                'type': 'document_parsing',
                'engine': 'ai_document_intelligence',
                'extract_text': True,
                'extract_tables': True,
                'extract_images': False,
                'output_format': 'json',
                'timeout_seconds': 120,
                'description': '...'
            }
            
            >>> config.get_service("entity_extractor_default")
            {
                'type': 'model_serving',
                'endpoint_name': 'chatbot-endpoint-dev',
                'max_tokens': 1000,
                'temperature': 0.1,
                'timeout_seconds': 90,
                'retry_attempts': 3,
                'description': '...'
            }
        """
        services = self.config.get("services", {})
        
        if service_name not in services:
            available_services = ", ".join(services.keys())
            raise ValueError(
                f"Service '{service_name}' not found. "
                f"Available services: {available_services}"
            )
        
        service_config = services[service_name]
        
        # Perform variable substitution
        resolved_service = self._resolve_variables(service_config)
        
        return resolved_service
    
    # ============================================================
    # HELPER METHODS (Optional - for advanced use cases)
    # ============================================================
    
    def get_all_steps(
        self,
        use_case: str,
        document_type: str,
        document_subtype: str
    ) -> List[Dict[str, Any]]:
        """
        Get all steps for a specific pipeline configuration.
        
        Args:
            use_case: Use case name
            document_type: Document type
            document_subtype: Document subtype
        
        Returns:
            List of step configurations
        """
        pipelines = self.config.get("pipelines", {})
        
        if use_case not in pipelines:
            raise ValueError(f"Use case '{use_case}' not found")
        
        pipeline = pipelines[use_case]
        
        if document_type not in pipeline:
            raise ValueError(f"Document type '{document_type}' not found")
        
        doc_type_config = pipeline[document_type]
        
        if document_subtype not in doc_type_config:
            raise ValueError(f"Document subtype '{document_subtype}' not found")
        
        subtype_config = doc_type_config[document_subtype]
        steps = subtype_config.get("steps", [])
        
        # Resolve variables for all steps
        resolved_steps = [self._resolve_variables(step) for step in steps]
        
        return resolved_steps
    
    def get_globals(self) -> Dict[str, Any]:
        """
        Get global configuration settings.
        
        Returns:
            Dictionary containing global settings
            
        Example:
            >>> globals_dict = config.get_globals()
            >>> catalog = globals_dict['catalog']
        """
        return self.config.get("globals", {})
    
    def get_services(self) -> Dict[str, Any]:
        """
        Get all service configurations.
        
        Returns:
            Dictionary containing all service definitions
            
        Example:
            >>> services = config.get_services()
            >>> autoloader = services['autoloader_default']
        """
        return self.config.get("services", {})
    
    def get_pipelines(self) -> Dict[str, Any]:
        """
        Get all pipeline configurations.
        
        Returns:
            Dictionary containing all pipeline definitions
            
        Example:
            >>> pipelines = config.get_pipelines()
            >>> my_pipeline = pipelines['zip_processor']
        """
        return self.config.get("pipelines", {})
    
    def get_pipeline(self, pipeline_name: str) -> Dict[str, Any]:
        """
        Get configuration for a specific pipeline.
        
        Args:
            pipeline_name: Name of the pipeline (e.g., 'zip_processor', 'autoloader')
            
        Returns:
            Dictionary containing pipeline configuration
            
        Raises:
            ValueError: If pipeline not found
            
        Example:
            >>> pipeline = config.get_pipeline('zip_processor')
            >>> steps = pipeline['archives']['clinical_trial_data']['steps']
        """
        pipelines = self.get_pipelines()
        
        if pipeline_name not in pipelines:
            available = ", ".join(pipelines.keys())
            raise ValueError(
                f"Pipeline '{pipeline_name}' not found. "
                f"Available pipelines: {available}"
            )
        
        return pipelines[pipeline_name]
    
    def list_services(self) -> List[str]:
        """
        List all available service names.
        
        Returns:
            List of service names
        """
        return list(self.config.get("services", {}).keys())
    
    def list_use_cases(self) -> List[str]:
        """
        List all available use case names.
        
        Returns:
            List of use case names
        """
        return list(self.config.get("pipelines", {}).keys())
    
    # ============================================================
    # INTERNAL METHODS
    # ============================================================
    
    def _load_config(self) -> Dict[str, Any]:
        """Load YAML configuration file."""
        config_file = Path(self.config_path)
        
        if not config_file.exists():
            raise FileNotFoundError(
                f"Configuration file not found: {self.config_path}"
            )
        
        with open(config_file, 'r') as f:
            config = yaml.safe_load(f)
        
        return config
    
    def _validate_config(self) -> None:
        """Validate configuration structure."""
        required_sections = ["globals", "services", "pipelines"]
        
        for section in required_sections:
            if section not in self.config:
                raise ValueError(
                    f"Invalid configuration: missing required section '{section}'"
                )
        
        # Validate globals
        globals_config = self.config["globals"]
        required_globals = [
            "spark_app_name",
            "catalog",
            "bronze_schema",
            "silver_schema",
            "gold_schema"
        ]
        
        for key in required_globals:
            if key not in globals_config:
                raise ValueError(
                    f"Invalid configuration: missing required global '{key}'"
                )
    
    def _resolve_variables(self, obj: Any) -> Any:
        """
        Recursively resolve variables in configuration objects.
        
        Supports:
        - ${globals.key} -> Value from globals section
        - ${bundle.target} -> Deployment target (dev/staging/prod)
        - ${ENV_VAR} -> Environment variable
        """
        if isinstance(obj, dict):
            return {k: self._resolve_variables(v) for k, v in obj.items()}
        
        elif isinstance(obj, list):
            return [self._resolve_variables(item) for item in obj]
        
        elif isinstance(obj, str):
            return self._substitute_string(obj)
        
        else:
            return obj
    
    def _substitute_string(self, text: str) -> str:
        """
        Substitute variables in a string.
        
        Patterns:
        - ${globals.catalog} -> From globals section
        - ${bundle.target} -> Deployment target
        - ${ENV_VAR} -> Environment variable
        """
        # Pattern: ${globals.key}
        def replace_globals(match):
            key = match.group(1)
            globals_config = self.config.get("globals", {})
            if key in globals_config:
                return str(globals_config[key])
            return match.group(0)  # Return original if not found
        
        text = re.sub(r'\$\{globals\.(\w+)\}', replace_globals, text)
        
        # Pattern: ${bundle.target}
        text = text.replace("${bundle.target}", self.target)
        
        # Pattern: ${ENV_VAR} - environment variables
        def replace_env(match):
            env_var = match.group(1)
            return os.environ.get(env_var, match.group(0))
        
        text = re.sub(r'\$\{([A-Z_][A-Z0-9_]*)\}', replace_env, text)
        
        return text


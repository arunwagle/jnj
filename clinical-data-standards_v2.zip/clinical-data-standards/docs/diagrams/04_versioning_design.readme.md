# Version Manager - SCD Type 2 Versioning System

> **Related Documentation:**
> - [04_versioning_design.drawio](./04_versioning_design.drawio) - High-level versioning flow
> - [04b_versioning_technical_design.drawio](./04b_versioning_technical_design.drawio) - Detailed data flow with examples
> - [06_dta_approval_design.readme.md](./06_dta_approval_design.readme.md) - Approval chain, user assignment, and governance
> - [06_dta_approval_design.drawio](./06_dta_approval_design.drawio) - Visual approval flow diagram

## Overview

The Clinical Data Standards platform uses **SCD Type 2 (Slowly Changing Dimension)** versioning to track all changes to transfer variable definitions. This enables:

- **Full audit trail** of every change
- **Parallel DTA development** without collisions
- **Point-in-time queries** for any historical version
- **Approval workflows** with version promotion

---

## 📊 Version Types

The system supports three distinct version types:

### 1. **Library Major Version** (Canonical Production)
- **Format**: `1.0`, `2.0`, `3.0`, etc.
- **Purpose**: The canonical, production-ready standard
- **Characteristics**:
  - `is_major_version = TRUE`
  - `is_dta_major = FALSE`
  - New DTAs can branch from any Library Major version
- **Example**: `library_version = "1.0"`
- **Creation**: Requires **Librarian role** approval; can merge multiple approved DTAs

### 2. **DTA Draft Version** (Work in Progress)
- **Format**: `{library}-{dta_number}-draft{n}`
- **Example**: `1.0-DTA001-draft1`, `1.0-DTA001-draft2`
- **Purpose**: Editable working copies for a specific DTA
- **Characteristics**:
  - `is_major_version = FALSE`
  - `is_dta_major = FALSE`
  - Can have multiple sequential drafts (draft1, draft2, draft3...)
- **Lifecycle**: Created → Edited → Superseded → Closed

### 3. **DTA Major Version** (Approved DTA)
- **Format**: `{library}-{dta_number}-v{n}.0`
- **Example**: `1.0-DTA001-v1.0`, `1.0-DTA001-v2.0`
- **Purpose**: Approved, finalized version for a specific DTA
- **Characteristics**:
  - `is_major_version = FALSE`
  - `is_dta_major = TRUE`
  - Created when workflow approval completes
  - **Can be used as a source for new DTA branches** (reuse approved definitions)
- **Lifecycle**: Approved draft becomes DTA Major

---

## 🔄 Version Manager Operations

The `job_cdm_version_manager` supports five mutually exclusive operations:

### 1. `CREATE_BRANCH` - Start New DTA

**Trigger**: UI initiates new DTA creation

**Source Options** (user chooses one):
- **Library Major Version** (e.g., `1.0`, `2.0`) - Start from canonical standard
- **DTA Major Version** (e.g., `1.0-DTA001-v1.0`) - Reuse another DTA's approved definitions

**What it does**:
1. User selects source version (Library Major or DTA Major)
2. Copies all records from selected source
3. Creates new draft version (e.g., `1.0-DTA002-draft1`)
4. Registers version in `md_version_registry` with `parent_version` reference

**SCD Type 2**:
- Source records: Unchanged
- New draft records: `is_current = TRUE`, `effective_end_ts = NULL`

**Example 1: Branch from Library Major**

`Library v1.0` → **COPY** → `1.0-DTA001-draft1` *(parent_version = "1.0")*

**Example 2: Branch from DTA Major** (reuse approved DTA)

`1.0-DTA001-v1.0` → **COPY** → `1.0-DTA002-draft1` *(parent_version = "1.0-DTA001-v1.0")*

**Use Cases for DTA Major branching**:
- Similar trial needs same variable definitions
- Reuse vendor-specific customizations
- Start from a known-good configuration

---

### 2. `SAVE_DRAFT` - Save Changes

**Trigger**: User saves edits in the UI

**What it does**:
1. Closes current draft (set `is_current = FALSE`, `effective_end_ts = NOW()`)
2. Creates new draft with changes (e.g., `1.0-DTA001-draft2`)
3. Updates registry: old draft → `SUPERSEDED`, new draft → `ACTIVE`

**SCD Type 2**:
- Old draft: `is_current = FALSE`, `effective_end_ts = NOW()`
- New draft: `is_current = TRUE`, `effective_start_ts = NOW()`

`1.0-DTA001-draft1` → **SCD2 CLOSE** → `1.0-DTA001-draft2`
- Old: `is_current=FALSE`, `effective_end_ts` set
- New: `is_current=TRUE`, new records

**Note**: If a field value changes (e.g., `max_length: 20 → 50`), a new `definition_hash` is generated.

---

### 3. `APPROVE_DTA` - Promote Draft to DTA Major

**Trigger**: Workflow approval completes (all approvers in `DTA_APPROVAL_TASK` approve)

**What it does**:
1. Closes current draft
2. Creates DTA Major version (e.g., `1.0-DTA001-v1.0`)
3. Sets `is_dta_major = TRUE`
4. Updates DTA entity with `current_version_tag`

**SCD Type 2**:
- Draft: `is_current = FALSE`, `effective_end_ts = NOW()`
- DTA Major: `is_current = TRUE`, `is_dta_major = TRUE`

`1.0-DTA001-draft2` → **APPROVE** → `1.0-DTA001-v1.0` *(DTA Major, is_dta_major=TRUE)*

---

### 4. `CREATE_DTA_MAJOR` - Direct DTA Major Creation

**Trigger**: Historical data import or API call

**What it does**:
1. Creates DTA Major directly from silver data (skips draft phase)
2. Used for historical DTAs that are already approved
3. Registers version with `version_type = DTA_MAJOR`

**Use Case**: Processing historical tsDTA files that represent already-executed DTAs.

`Silver Data` → **DIRECT CREATE** → `1.0-DTA001-v1.0` *(DTA Major, is_dta_major=TRUE)*

---

### 5. `PROMOTE_TO_LIBRARY` - Elevate to Library Major

**Trigger**: Librarian role initiates promotion after review

**Authorization**: Requires **Librarian role** approval

**Promotion Options**:
- **Single DTA**: Promote one approved DTA Major to Library Major
- **Merge Multiple DTAs**: Combine definitions from multiple approved DTAs

**What it does**:
1. Librarian selects one or more approved DTA Major versions
2. If merging, resolves conflicts (Librarian decides which definition to use)
3. Closes current Library Major (e.g., `1.0`)
4. Creates new Library Major (e.g., `2.0`) with merged/promoted content
5. Sets `is_major_version = TRUE`
6. All future DTAs can branch from the new version

**SCD Type 2**:
- Old Library: `is_current = FALSE`, `effective_end_ts = NOW()`
- New Library: `is_current = TRUE`, `is_major_version = TRUE`

**Example 1: Single DTA Promotion**

`1.0-DTA001-v1.0` → **PROMOTE (Librarian)** → `Library v2.0` *(is_major_version=TRUE)*

**Example 2: Merge Multiple DTAs**

```mermaid
flowchart LR
    A["1.0-DTA001-v1.0<br/>(SubjectID=50)"] --> D
    B["1.0-DTA002-v1.0<br/>(Gender vals)"] --> D
    C["1.0-DTA003-v1.0<br/>(VisitType)"] --> D
    D{{"MERGE<br/>(Librarian)"}} --> E["📚 Library v2.0"]
    
    style E fill:#dae8fc,stroke:#6c8ebf,stroke-width:2px
```

**Merge Conflict Resolution**:
- If same field modified differently in multiple DTAs, Librarian chooses which version to include
- Merge creates audit trail of source DTAs in `md_version_registry`

---

## 📋 Version Tag Format

| Version Type | Format | Example |
|--------------|--------|---------|
| Library Major | `{major}.0` | `1.0`, `2.0` |
| DTA Draft | `{library}-{dta_number}-draft{n}` | `1.0-DTA001-draft1` |
| DTA Major | `{library}-{dta_number}-v{n}.0` | `1.0-DTA001-v1.0` |

**Components**:
- `{library}`: Parent library version (e.g., `1.0`)
- `{dta_number}`: Sequential DTA identifier (e.g., `DTA001`, `DTA002`)
- `draft{n}`: Draft sequence number (1, 2, 3...)
- `v{n}.0`: Major version within the DTA

---

## 🗄️ Key Tables

### `md_transfer_variables_library`
The main versioned table using SCD Type 2:

| Column | Description |
|--------|-------------|
| `definition_hash` | Unique hash of field definition |
| `library_version` | Version tag (e.g., `1.0`, `1.0-DTA001-draft1`) |
| `is_major_version` | `TRUE` only for Library Major versions |
| `is_dta_major` | `TRUE` for approved DTA versions |
| `parent_version` | Version this was branched from |
| `effective_start_ts` | When this version became active |
| `effective_end_ts` | When this version was closed (`NULL` = active) |
| `is_current` | `TRUE` for the active version of each record |

### `md_version_registry`
Lightweight metadata for all versions:

| Column | Description |
|--------|-------------|
| `version_tag` | Unique version identifier |
| `version_type` | `LIBRARY_MAJOR`, `DTA_DRAFT`, or `DTA_MAJOR` |
| `dta_id` | Associated DTA (NULL for library versions) |
| `parent_version_tag` | Version this was derived from |
| `record_count` | Number of records in this version |
| `status` | `ACTIVE` or `SUPERSEDED` |

---

## 🔀 State Transitions

### Basic Flow (Branch from Library)

```mermaid
flowchart TD
    A["📚 Library v1.0<br/>(Canonical)"] 
    
    A -->|"CREATE_BRANCH"| B["1.0-DTA001-draft1"]
    A -->|"CREATE_BRANCH"| C["1.0-DTA002-draft1"]
    A -->|"CREATE_BRANCH"| D["1.0-DTA003-draft1"]
    
    B -->|"SAVE_DRAFT<br/>APPROVE_DTA"| E["✅ 1.0-DTA001-v1.0<br/>(Approved)"]
    C -->|"SAVE_DRAFT<br/>APPROVE_DTA"| F["✅ 1.0-DTA002-v1.0<br/>(Approved)"]
    D -->|"SAVE_DRAFT<br/>APPROVE_DTA"| G["✅ 1.0-DTA003-v1.0<br/>(Approved)"]
    
    E --> H{{"📚 PROMOTE_TO_LIBRARY<br/>(Librarian merges)"}}
    F --> H
    G --> H
    
    H --> I["📚 Library v2.0<br/>(Merged from DTAs)"]
    
    style A fill:#dae8fc,stroke:#6c8ebf,stroke-width:2px
    style E fill:#d5e8d4,stroke:#82b366
    style F fill:#d5e8d4,stroke:#82b366
    style G fill:#d5e8d4,stroke:#82b366
    style I fill:#dae8fc,stroke:#6c8ebf,stroke-width:3px
```

### Branch from DTA Major (Reuse Approved Definitions)

```mermaid
flowchart TD
    A["📚 Library v1.0"] -->|"CREATE_BRANCH"| B["✅ 1.0-DTA001-v1.0<br/>(DTA Major)<br/>Approved with custom definitions"]
    
    B -->|"CREATE_BRANCH<br/>(from DTA Major)"| C["📝 1.0-DTA004-draft1<br/>parent=DTA001<br/>Reusing DTA001's definitions"]
    
    style A fill:#dae8fc,stroke:#6c8ebf
    style B fill:#d5e8d4,stroke:#82b366,stroke-width:2px
    style C fill:#fff2cc,stroke:#d6b656
```

### Merge Multiple DTAs to Library (Librarian Role)

```mermaid
flowchart TD
    subgraph approved["Approved DTAs with Different Changes"]
        A["✅ 1.0-DTA001-v1.0<br/>SubjectID=50"]
        B["✅ 1.0-DTA002-v1.0<br/>Gender=[M,F,O]"]
        C["✅ 1.0-DTA003-v1.0<br/>new VisitType"]
    end
    
    A --> D
    B --> D
    C --> D
    
    D["📚 LIBRARIAN<br/>Reviews Merge<br/>Resolves Conflicts"]
    
    D -->|"PROMOTE_TO_LIBRARY"| E["📚 Library v2.0<br/>• SubjectID=50<br/>• Gender=[M,F,O]<br/>• new VisitType"]
    
    style A fill:#d5e8d4,stroke:#82b366
    style B fill:#d5e8d4,stroke:#82b366
    style C fill:#d5e8d4,stroke:#82b366
    style D fill:#fff2cc,stroke:#d6b656,stroke-width:2px
    style E fill:#dae8fc,stroke:#6c8ebf,stroke-width:3px
```

---

## 🔄 Parallel DTA Development

Multiple DTAs can work simultaneously without conflicts:

```mermaid
flowchart LR
    A["📚 Library v1.0"]
    
    A --> B["DTA_A: draft1"] --> C["draft2"] --> D["✅ v1.0<br/>(approved)"]
    A --> E["DTA_B: draft1"] --> F["draft2<br/>(still drafting)"]
    A --> G["DTA_C: draft1<br/>(just started)"]
    
    style A fill:#dae8fc,stroke:#6c8ebf
    style D fill:#d5e8d4,stroke:#82b366
    style F fill:#fff2cc,stroke:#d6b656
    style G fill:#fff2cc,stroke:#d6b656
```

**Key Points**:
- Each DTA has isolated version tags
- Changes in one DTA don't affect others
- Multiple DTAs can be promoted to library (incrementing version numbers)

---

## 🔍 Querying Versions

### Get Current Library Version
```sql
SELECT * FROM md_transfer_variables_library
WHERE is_major_version = TRUE AND is_current = TRUE
```

### Get Specific DTA's Current Draft
```sql
SELECT * FROM md_transfer_variables_library
WHERE library_version LIKE '%-DTA001-%' AND is_current = TRUE
```

### Get Point-in-Time Version
```sql
SELECT * FROM md_transfer_variables_library
WHERE library_version = '1.0'
  AND effective_start_ts <= '2025-01-15'
  AND (effective_end_ts IS NULL OR effective_end_ts > '2025-01-15')
```

### Get Version History
```sql
SELECT version_tag, version_type, status, created_ts
FROM md_version_registry
WHERE dta_id = 'DTA001'
ORDER BY created_ts
```

---

## 📁 Related Files

### Job Definition
```
resources/data_engineering/clinical_data_standards/jobs/
└── job_cdm_version_manager.job.yml
```

### Notebooks (by action)
```
notebooks/data_engineering/common/
├── nb_version_create_branch.ipynb    # CREATE_BRANCH
├── nb_version_save_draft.ipynb       # SAVE_DRAFT
├── nb_version_approve_dta.ipynb      # APPROVE_DTA
├── nb_create_historical_dta_major.ipynb  # CREATE_DTA_MAJOR
└── nb_promote_to_library.ipynb       # PROMOTE_TO_LIBRARY
```

### Core Library
```
src/clinical_data_standards_framework/
└── versioning.py    # Core versioning functions
```

---

## 🔑 Design Principles

1. **Immutability**: Records are never updated in place; new versions are created
2. **Full History**: All changes are preserved with timestamps
3. **Isolation**: DTAs work in isolated version spaces
4. **Traceability**: Every version links to its parent via `parent_version`
5. **Atomic Operations**: Each operation is a complete, consistent state change


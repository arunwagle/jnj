# DTA Schema - Detailed Diagram

> **Diagram**: [02_schema_design.drawio](./02_schema_design.drawio)

## Overview

This document describes the complete database schema for the Clinical Data Standards DTA (Data Transfer Agreement) Management System, organized by the Medallion Architecture layers.

---

## 🏗️ Architecture Layers

```mermaid
flowchart LR
    subgraph Bronze["🟤 Bronze Layer"]
        A[Raw Data]
    end
    
    subgraph Silver["⚪ Silver Layer"]
        B[Normalized Data]
    end
    
    subgraph Gold["🟡 Gold Layer"]
        C[Business Entities]
    end
    
    A --> B --> C
    
    style Bronze fill:#FFE0B2,stroke:#E65100
    style Silver fill:#BBDEFB,stroke:#1565C0
    style Gold fill:#FFF59D,stroke:#F9A825
```

---

## 🟤 Bronze Layer (`bronze_md`)

Raw data ingestion and document tracking.

### `md_dta_history`
**Purpose**: Document manifest with extraction status and completion tracking.

| Column | Type | Description |
|--------|------|-------------|
| `document_id` | STRING | **PK** - Unique document identifier |
| `parent_document_id` | STRING | **FK** - Self-reference for parent ZIP |
| `zip_source_path` | STRING | Original ZIP file path |
| `extracted_path` | STRING | Extraction location |
| `content_base64` | STRING | Base64 encoded file content |
| `size_bytes` | LONG | File size |
| `file_extension` | STRING | File type extension |
| `document_tags` | ARRAY<STRING> | Classification tags (tsDTA, DTA, etc.) |
| `active` | BOOLEAN | Whether document is active |
| `current_status` | STRING | Processing status |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `total_documents_count` | INT | Total files in ZIP |
| `required_documents_count` | INT | Files requiring processing |
| `processed_documents_count` | INT | Processed file count |

### `md_document_status`
**Purpose**: Processing status tracking for each document.

| Column | Type | Description |
|--------|------|-------------|
| `document_id` | STRING | **PK** - References md_dta_history |
| `status` | STRING | Current processing status |
| `status_timestamp` | TIMESTAMP | When status changed |
| `error_message` | STRING | Error details if failed |
| `processing_duration_seconds` | DOUBLE | Processing time |
| `retry_count` | INT | Number of retry attempts |

### `md_dta_excel_file_raw`
**Purpose**: Excel sheet metadata for tsDTA files.

| Column | Type | Description |
|--------|------|-------------|
| `document_id` | STRING | **PK** - Unique sheet identifier |
| `parent_document_id` | STRING | **FK** - References parent Excel file |
| `sheet_name` | STRING | Excel sheet name |
| `sheet_index` | INT | Sheet position (0-based) |
| `sheet_category` | STRING | Categorized type (transfer_metadata, codelists, etc.) |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |

---

## ⚪ Silver Layer (`silver_md`)

Standardized and normalized data.

### `md_transfer_variable_field_normalized`
**Purpose**: Standardized transfer variable definitions from tsDTA.

| Column | Type | Description |
|--------|------|-------------|
| `transfer_variable_field_id` | STRING | **PK** - Unique record ID |
| `parent_document_id` | STRING | **FK** - References source document |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `transfer_variable_name` | STRING | Variable name |
| `transfer_variable_label` | STRING | Variable label |
| `variable_description` | STRING | Detailed description |
| `format` | STRING | Data type (text, numeric, date) |
| `anticipated_max_length` | INT | Maximum field length |
| `transfer_file_key` | BOOLEAN | Part of unique key |
| `populate_for_all_records` | BOOLEAN | Required for all records |
| `example_values` | STRING | Sample values |
| `codelist_values` | STRING | Associated codelist values |
| `definition_hash` | STRING | Hash for deduplication |
| `row_status` | STRING | COMPLETED or MANUAL_REVIEW_REQUIRED |
| `categorization_notes` | STRING | Processing notes |
| `transfer_file_order` | INT | Order in transfer file |

### `md_codelists_normalized`
**Purpose**: Standardized codelist values.

| Column | Type | Description |
|--------|------|-------------|
| `codelist_id` | STRING | **PK** - Unique codelist record ID |
| `parent_document_id` | STRING | **FK** - References source document |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `transfer_variable_name` | STRING | Associated variable |
| `codelist_reference` | STRING | Codelist identifier |
| `code_value` | STRING | Individual code value |
| `row_status` | STRING | Processing status |

---

## 🟡 Gold Layer (`gold_md`)

Business entities and versioned library.

### `dta`
**Purpose**: Core DTA entity representing a Data Transfer Agreement.

| Column | Type | Description |
|--------|------|-------------|
| `dta_id` | STRING | **PK** - UUID identifier |
| `dta_number` | STRING | Human-readable ID (DTA001, DTA002) |
| `trial_id` | STRING | Associated trial |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider |
| `status` | STRING | DRAFT, ACTIVE, MANUAL_REVIEW, ARCHIVED |
| `workflow_state` | STRING | NOT_STARTED, IN_REVIEW, APPROVED, REJECTED |
| `workflow_iteration` | INT | Current approval cycle |
| `current_version_tag` | STRING | **FK** - Active version in library |
| `notes` | STRING | General notes |

### `dta_workflow`
**Purpose**: Workflow cycle tracking for DTA approval.

| Column | Type | Description |
|--------|------|-------------|
| `dta_workflow_id` | STRING | **PK** - UUID identifier |
| `dta_id` | STRING | **FK** - References dta |
| `workflow_iteration` | INT | Iteration number (1, 2, 3...) |
| `workflow_status` | STRING | NOT_STARTED, IN_REVIEW, APPROVED, REJECTED |
| `summary_comment` | STRING | Workflow notes |
| `initiated_ts` | TIMESTAMP | When workflow started |
| `closed_ts` | TIMESTAMP | When workflow completed |

### `md_transfer_variables_library`
**Purpose**: SCD Type 2 versioned library of transfer variable definitions.

| Column | Type | Description |
|--------|------|-------------|
| `definition_hash` | STRING | **PK** - Unique definition hash |
| `library_version` | STRING | **PK** - Version tag (1.0, 1.0-DTA001-draft1) |
| `transfer_variable_name` | STRING | Variable name |
| `transfer_variable_label` | STRING | Variable label |
| `variable_description` | STRING | Detailed description |
| `format` | STRING | Data type |
| `anticipated_max_length` | INT | Maximum length |
| `codelist_values` | STRING | Associated codelists |
| `used_in_trials` | ARRAY<STRUCT> | Trial usage tracking |
| `usage_count` | INT | Usage frequency |
| **SCD Type 2 Columns** | | |
| `is_major_version` | BOOLEAN | TRUE for Library Major (1.0, 2.0) |
| `is_dta_major` | BOOLEAN | TRUE for DTA Major (1.0-DTA001-v1.0) |
| `parent_version` | STRING | Version branched from |
| `effective_start_ts` | TIMESTAMP | When version became active |
| `effective_end_ts` | TIMESTAMP | When superseded (NULL if current) |
| `is_current` | BOOLEAN | Active version flag |
| `completed_count` | INT | Count of COMPLETED records |
| `review_required_count` | INT | Count of MANUAL_REVIEW records |
| `needs_review` | BOOLEAN | TRUE if any source needs review |

### `md_version_registry`
**Purpose**: Lightweight metadata for all versions.

| Column | Type | Description |
|--------|------|-------------|
| `version_tag` | STRING | **PK** - Unique version identifier |
| `library_type` | STRING | transfer_variables, codelist |
| `version_type` | STRING | LIBRARY_MAJOR, DTA_MAJOR, DTA_DRAFT |
| `dta_id` | STRING | **FK** - Associated DTA (NULL for library major) |
| `parent_version` | STRING | Version branched from |
| `record_count` | INT | Number of records in version |
| `status` | STRING | ACTIVE, SUPERSEDED, ARCHIVED |

---

## 🔗 Relationships

```mermaid
erDiagram
    md_dta_history ||--o| md_document_status : "has status"
    md_dta_history ||--o{ md_dta_excel_file_raw : "contains sheets"
    md_dta_history ||--o{ md_transfer_variable_field_normalized : "produces"
    md_dta_history ||--o{ md_codelists_normalized : "produces"
    
    dta ||--o{ dta_workflow : "has workflows"
    dta ||--o{ md_version_registry : "owns versions"
    md_version_registry }|--|| md_transfer_variables_library : "references"
```

---

## 📋 Audit Columns

All tables include standard audit columns:

| Column | Type | Description |
|--------|------|-------------|
| `created_by_principal` | STRING | User who created the record |
| `created_ts` | TIMESTAMP | Record creation timestamp |
| `last_updated_by_principal` | STRING | User who last updated |
| `last_updated_ts` | TIMESTAMP | Last update timestamp |
| `databricks_job_id` | STRING | Job ID for lineage |
| `databricks_job_name` | STRING | Job name for lineage |
| `databricks_run_id` | STRING | Run ID for lineage |

---

## 🔑 Key Design Patterns

### 1. **Parent-Child Document Linking**
- `parent_document_id` links child documents to parent ZIPs
- Enables tracking of document lineage through extraction

### 2. **Trial Context**
- `trial_id`, `data_stream_type`, `data_provider_name` propagate through all layers
- Enables filtering and grouping by trial context

### 3. **SCD Type 2 Versioning**
- `effective_start_ts`, `effective_end_ts`, `is_current` enable point-in-time queries
- `library_version` + `definition_hash` form composite key

### 4. **Completion Tracking**
- `total_documents_count`, `required_documents_count`, `processed_documents_count`
- Enables completion gate pattern for orchestration

---

*Last Updated: December 2025*


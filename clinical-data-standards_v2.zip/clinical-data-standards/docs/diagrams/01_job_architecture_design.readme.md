# Job Architecture Flow

> **Related Documentation:**
> - [01_job_architecture_design.drawio](./01_job_architecture_design.drawio) - Visual job architecture diagram
> - [04_versioning_design.readme.md](./04_versioning_design.readme.md) - Version management operations
> - [06_dta_approval_design.readme.md](./06_dta_approval_design.readme.md) - Approval chain and governance

## Overview

This document describes the Clinical Data Standards job architecture for processing historical DTA (Data Transfer Agreement) data and managing versions.

---

## 🎯 Main Pipeline: `job_cdm_dta_import`

The main orchestrator job for importing historical clinical trial data end-to-end.

### **Trigger**
- **File Arrival**: Automatically triggers when new ZIP files land in `/Volumes/.../historical_data/uploads/`
- **Manual**: Can be run via Databricks CLI or UI

### **Pipeline Flow**

```mermaid
flowchart TD
    A["🚀 job_cdm_dta_import<br/>(Orchestrator)"]
    
    A --> B["📁 Task 1: job_cds_file_processor<br/>• Extracts ZIP files<br/>• Creates manifest<br/>• Counts documents by tag"]
    
    B --> C{{"📄 Task 2: Document Processing<br/>(PARALLEL)"}}
    
    subgraph parallel["Parallel Document Processing"]
        D["📊 job_cds_tsdta_xls_processor<br/>[Tag: tsDTA] ✅"]
        E["📄 job_cds_operational_agreements<br/>[Tag: OPERATIONAL_AGREEMENT] 🔜"]
        F["📖 job_cds_dictionary_processor<br/>[Tag: Dictionary] 🔜"]
    end
    
    C --> D
    C --> E
    C --> F
    
    D --> G
    E --> G
    F --> G
    
    G["⏳ Completion Gate<br/>processed_count == required_count"]
    
    G --> H["📦 Task 3: job_cdm_dta_create"]
    
    H --> I["create_dta_instance<br/>DTA001, DTA002..."]
    I --> J{"HISTORICAL?"}
    J -->|"Yes"| K["create_dta_major<br/>DTA Major version"]
    J -->|"No"| L["Draft for UI editing"]
    
    style A fill:#4a5568,stroke:#2d3748,color:#fff
    style B fill:#edf2f7,stroke:#a0aec0
    style D fill:#c6f6d5,stroke:#48bb78
    style E fill:#fefcbf,stroke:#d69e2e
    style F fill:#fefcbf,stroke:#d69e2e
    style G fill:#bee3f8,stroke:#3182ce
    style H fill:#e9d8fd,stroke:#805ad5
    style K fill:#c6f6d5,stroke:#48bb78
```

**Output Tables by Layer:**

| Layer | Tables |
|-------|--------|
| Bronze | `md_dta_history`, `md_document_status`, `md_dta_excel_file_raw` |
| Silver | `md_transfer_variable_field_normalized`, `md_codelists_normalized` |
| Gold | `dta`, `dta_workflow`, `md_transfer_variables_library`, `md_version_registry` |

---

## 📋 Job Reference

### Orchestrator Jobs

| Job | Description | Trigger |
|-----|-------------|---------|
| `job_cdm_dta_import` | End-to-end historical DTA import | File arrival / Manual |
| `job_cdm_dta_import_test` | Test job (cleanup + import) | Manual only |

### Processor Jobs

| Job | Description | Tag | Status |
|-----|-------------|-----|--------|
| `job_cds_file_processor` | Extract ZIPs, create manifest | - | ✅ Implemented |
| `job_cds_tsdta_xls_processor` | Process tsDTA Excel files | `tsDTA` | ✅ Implemented |
| `job_cds_operational_agreements_processor` | Process PDF/Word documents | `OPERATIONAL_AGREEMENT` | 🔜 Future |
| `job_cds_dictionary_processor` | Process dictionary files | `Dictionary` | 🔜 Future |
| `job_cdm_dta_create` | Create DTA instance + versioning | - | ✅ Implemented |

### Version Manager

| Job | Description | Called By |
|-----|-------------|-----------|
| `job_cdm_version_manager` | UI/API versioning operations | `job_cdm_dta_create` (UI mode) / Direct API calls |

---

## 📊 Tables Created

### Bronze Layer
| Table | Description |
|-------|-------------|
| `md_dta_history` | Document manifest with extraction status |
| `md_document_status` | Individual document processing status |
| `md_dta_excel_file_raw` | Raw Excel sheet data |

### Silver Layer
| Table | Description |
|-------|-------------|
| `md_transfer_variable_field_normalized` | Standardized transfer variable definitions |
| `md_codelists_normalized` | Standardized codelist values |

### Gold Layer
| Table | Description |
|-------|-------------|
| `dta` | DTA entity records |
| `dta_workflow` | DTA workflow status |
| `md_transfer_variables_library` | SCD Type 2 versioned variable definitions |
| `md_version_registry` | Version metadata registry |

---

## 🔀 Version Manager Actions

The `job_cdm_version_manager` supports these mutually exclusive actions:

| Action | Description | When Used |
|--------|-------------|-----------|
| `CREATE_BRANCH` | Create new DTA draft from library | UI initiates new DTA |
| `SAVE_DRAFT` | Save changes to draft | UI saves edits |
| `APPROVE_DTA` | Promote draft to DTA Major | Workflow approval |
| `CREATE_DTA_MAJOR` | Create DTA Major directly | Single DTA via API |
| `PROMOTE_TO_LIBRARY` | Promote DTA Major to Library Major | Admin promotion |

---

## 🔑 Design Decisions

1. **`job_cdm_dta_import`** is the main entry point for historical data processing
2. **`job_cdm_version_manager`** handles UI/API versioning operations (dta_id passed explicitly)
3. **For HISTORICAL source**: `job_cdm_dta_create` uses notebook directly (needs task_values)
4. **`run_job_task` limitation**: Cannot pass task_values between jobs (Databricks limitation)

---

## 🔄 Completion Gate Pattern

The pipeline uses a **completion gate** to ensure all required documents are processed before DTA creation.

### How It Works

1. **File Processor** counts documents with specific tags:
   - `total_documents_count`: All files in the ZIP
   - `required_documents_count`: Files with tags that trigger versioning
   - `processed_documents_count`: Files that have been processed

2. **Document Processors** run in parallel and update `processed_documents_count` as they complete

3. **Completion Check**: DTA creation only triggers when:
   ```
   processed_documents_count == required_documents_count
   ```

### Configuration

The required tags are configurable in `clinical_data_standards.yaml`:

```yaml
streaming:
  completion_tracking:
    enabled: true
    
    # Tags that must be completed before versioning triggers
    required_tags_for_versioning:
      - "tsDTA"                    # Excel processing (current)
      # - "OPERATIONAL_AGREEMENT"  # Future: PDF/Word processing
      # - "Dictionary"             # Future: Dictionary processing
```

### Adding New Document Processors

To add a new document processor:

1. **Uncomment or add the tag** in `required_tags_for_versioning`
2. **Create the processor job** (e.g., `job_cds_operational_agreements_processor.job.yml`)
3. **Add as parallel task** in `job_cdm_dta_import`
4. **The completion gate automatically includes** the new tag in counting

The file processor will automatically count documents with the new tag, and the completion gate will wait for all tagged documents to be processed before triggering DTA creation.

---

## 🧪 Testing

Run the test pipeline to clean up and re-import:

```bash
databricks jobs run-now --job-name job_cdm_dta_import_test
```

This will:
1. Drop all bronze, silver, gold tables
2. Delete checkpoint and ingested folders
3. Trigger `job_cdm_dta_import` to process test data

---

## 📁 File Locations

### Job Definitions
```
resources/data_engineering/
├── clinical_data_standards/jobs/
│   ├── job_cdm_dta_import.job.yml      # Main orchestrator
│   ├── job_cdm_dta_create.job.yml      # DTA creation
│   ├── job_cdm_version_manager.job.yml # Version operations
│   ├── job_file_processor.job.yml      # File extraction
│   └── job_tsdta_processor.job.yml     # Excel processing
├── common/jobs/
│   └── job_populate_config_cache.job.yml
└── test/jobs/
    └── job_cdm_dta_import_test.job.yml # Test pipeline
```

### Notebooks
```
notebooks/data_engineering/
├── common/
│   ├── nb_setup.ipynb                    # Configuration setup
│   ├── nb_create_dta_instance.ipynb      # DTA entity creation
│   ├── nb_create_historical_dta_major.ipynb # DTA Major versioning
│   ├── nb_version_create_branch.ipynb    # Create branch action
│   ├── nb_version_save_draft.ipynb       # Save draft action
│   └── nb_version_approve_dta.ipynb      # Approve DTA action
├── clinical_data_standards/jobs/
│   ├── nb_file_processor.ipynb           # ZIP extraction
│   ├── nb_extract_excel_sheets.ipynb     # Excel sheet extraction
│   ├── nb_tsdta_transfer_variables_processor.ipynb
│   ├── nb_tsdta_code_lists_processor.ipynb
│   └── nb_update_completion_status.ipynb
└── test/jobs/
    └── nb_cleanup_test_data.ipynb        # Test cleanup
```


# Schema Design

> **Status**: Implemented  
> **Last Updated**: January 2026

---

## Overview

This document describes the database schema for the Clinical Data Standards DTA (Data Transfer Agreement) Management System. The schema follows the Medallion Architecture with Bronze, Silver, and Gold layers.

Table and column descriptions are optimized for Databricks Genie AI Assistant integration. For detailed Genie training configuration, see [09_genie_integration_design.readme.md](./09_genie_integration_design.readme.md).

### Schema Layers

| Layer | Schema | Purpose |
|-------|--------|---------|
| Gold | `gold_md` | Approved DTA entities, workflows, and versioned metadata library |
| Silver | `silver_md` | Normalized draft data being reviewed before approval |
| Bronze | `bronze_md` | Raw ingestion of tsDTA files, document manifest, Excel metadata |

### Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| Schema Data Flow | Data flow overview (Gold → Silver → Bronze) | [PNG](./diagrams/02_schema_design_tables.drawio.png) | [Draw.io](./diagrams/02_schema_design_tables.drawio) |
| Entity Relationship Diagram | Detailed ERD with columns, keys, and relationships | [PNG](./diagrams/02_schema_erd.drawio.png) | [Draw.io](./diagrams/02_schema_erd.drawio) |

#### Schema Data Flow
![Schema Data Flow](./diagrams/02_schema_design_tables.drawio.png)

#### Entity Relationship Diagram (ERD)
![ERD Diagram](./diagrams/02_schema_erd.drawio.png)

---

## Tables Summary

### Gold Layer (`gold_md`)

| Table | Purpose |
|-------|---------|
| `dta` | Core DTA entity representing a Data Transfer Agreement |
| `dta_workflow` | Workflow cycle tracking for DTA approval |
| `dta_approval_task` | Individual approval tasks within a workflow |
| `dta_activity_log` | Activity audit log for all DTA operations |
| `md_version_registry` | Central registry for all version metadata |
| `md_dta_transfer_variables` | Approved transfer variable definitions (SCD Type 2) |
| `md_dta_vendor_test_concepts` | Approved vendor test concept definitions |

### Silver Layer (`silver_md`)

| Table | Purpose |
|-------|---------|
| `md_dta_transfer_variables_draft` | Draft transfer variable definitions being reviewed |
| `md_dta_vendor_test_concepts_draft` | Draft vendor test concepts being reviewed |
| `md_codelists_normalized` | Standardized codelist values extracted from tsDTA |

### Bronze Layer (`bronze_md`)

| Table | Purpose |
|-------|---------|
| `md_file_history` | Document manifest with extraction status and completion tracking |
| `md_document_types` | Reference table for document type enablement |
| `md_dta_excel_file_raw` | Excel sheet metadata for tsDTA files |

---

## Gold Layer Tables

### 1. dta

**Purpose**: Core DTA entity representing a Data Transfer Agreement between J&J and a data provider.

| Column | Type | Description |
|--------|------|-------------|
| `dta_id` | STRING | **PK** - UUID identifier |
| `dta_number` | STRING | Human-readable ID (DTA001, DTA002) |
| `dta_name` | STRING | Descriptive name for the DTA |
| `trial_id` | STRING | Associated trial identifier |
| `data_stream_type` | STRING | Data stream type (Labs, ECG, etc.) |
| `data_provider_name` | STRING | Vendor/provider name |
| `status` | STRING | DRAFT, ACTIVE, PROMOTED, ARCHIVED (1:1 with md_version_registry.status) |
| `workflow_state` | STRING | NOT_STARTED, IN_REVIEW, APPROVED, REJECTED |
| `workflow_iteration` | INT | Current approval cycle number |
| `version` | STRING | Active version for UI display |
| `current_draft_version` | STRING | Current draft version being edited |
| `base_template_version` | STRING | Library version this DTA was branched from |
| `parent_document_id` | STRING | **FK** - Reference to source document |
| `notes` | STRING | General notes |

**Note**: `latest_major_version` was removed - now derived from `md_version_registry` via:
```sql
SELECT version FROM md_version_registry 
WHERE dta_id = :dta_id AND version_type = 'DTA_APPROVED' AND status = 'ACTIVE'
```

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/common/nb_create_dta_instance.ipynb` |

---

### 2. dta_workflow

**Purpose**: Tracks the approval lifecycle for DTAs across stakeholders (J&J DAE, Vendor, Librarian).

| Column | Type | Description |
|--------|------|-------------|
| `dta_workflow_id` | STRING | **PK** - UUID identifier |
| `dta_id` | STRING | **FK** - References dta table |
| `workflow_iteration` | INT | Iteration number (1, 2, 3...) |
| `workflow_status` | STRING | NOT_STARTED, IN_REVIEW, APPROVED, REJECTED |
| `summary_comment` | STRING | Workflow summary notes |
| `initiated_ts` | TIMESTAMP | When workflow started |
| `closed_ts` | TIMESTAMP | When workflow completed |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/common/nb_create_dta_instance.ipynb` |

---

### 3. dta_approval_task

**Purpose**: Individual approval tasks within a workflow cycle, tracking each approver's action.

| Column | Type | Description |
|--------|------|-------------|
| `approval_task_id` | STRING | **PK** - UUID identifier |
| `dta_workflow_id` | STRING | **FK** - References dta_workflow |
| `dta_id` | STRING | **FK** - References dta table |
| `approver_role` | STRING | Role: jnj_dae, vendor, librarian |
| `assigned_to_principal` | STRING | Assigned approver email |
| `approval_order` | INT | Order in approval chain (1, 2, 3) |
| `approval_status` | STRING | PENDING, APPROVED, REJECTED, SKIPPED |
| `approval_comment` | STRING | Approver's comment |
| `approved_ts` | TIMESTAMP | When approved/rejected |
| `is_auto_approve` | BOOLEAN | Whether auto-approved |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/common/nb_create_dta_instance.ipynb` |

---

### 4. dta_activity_log

**Purpose**: Captures the full audit history of all activities performed on DTAs and related metadata entities.

| Column | Type | Description |
|--------|------|-------------|
| `activity_id` | STRING | **PK** - UUID identifier |
| `dta_id` | STRING | **FK** - References dta table |
| `entity_id` | STRING | ID of affected entity |
| `entity_name` | STRING | Name of entity (transfer_variables, test_concepts, etc.) |
| `activity_type` | STRING | CREATE, UPDATE, DELETE, APPROVE, REJECT |
| `activity_category` | STRING | Category grouping |
| `activity_summary` | STRING | Human-readable summary |
| `field_name` | STRING | Changed field name |
| `old_value` | STRING | Previous value |
| `new_value` | STRING | New value |
| `version_tag` | STRING | Version when change occurred |
| `parent_version` | STRING | Parent version reference |
| `workflow_iteration` | INT | Workflow cycle number |
| `library_type` | STRING | Library type affected |
| `approver_name` | STRING | Approver who made change |
| `approver_role` | STRING | Approver's role |
| `comment` | STRING | Activity comment |
| `performed_by_principal` | STRING | User who performed action |
| `performed_ts` | TIMESTAMP | When action was performed |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | Activity logging functions in `utils.py` |

---

### 5. md_version_registry

**Purpose**: Central registry for all version metadata, supporting SCD Type 2 lifecycle management.

**Status Alignment**: The `status` column aligns 1:1 with `dta.status`:
- **DRAFT**: Being edited (effective_end_ts = NULL)
- **ACTIVE**: Approved and in use (effective_end_ts = NULL)
- **PROMOTED**: Elevated to template (effective_end_ts = NULL)
- **ARCHIVED**: No longer active (effective_end_ts = timestamp when archived)

| Column | Type | Description |
|--------|------|-------------|
| `version` | STRING | **PK** - Unique version identifier |
| `library_type` | STRING | transfer_variables, test_concepts, codelists |
| `version_type` | STRING | DTA_TEMPLATE, DTA_APPROVED, DTA_DRAFT |
| `dta_id` | STRING | **FK** - Associated DTA (NULL for library templates) |
| `parent_version` | STRING | Version branched from |
| `record_count` | INT | Number of records in version |
| `status` | STRING | DRAFT, ACTIVE, PROMOTED, ARCHIVED (1:1 with dta.status) |
| `effective_end_ts` | TIMESTAMP | NULL unless ARCHIVED, then timestamp when archived |
| `data_provider_name` | STRING | Vendor name (for template scope) |
| `data_stream_type` | STRING | Data stream type (for template scope) |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | Versioning notebooks in `notebooks/data_engineering/common/` |

---

### 6. md_dta_transfer_variables

**Purpose**: SCD Type 2 versioned library of approved transfer variable definitions.

| Column | Type | Description |
|--------|------|-------------|
| `definition_hash` | STRING | **PK** - Unique definition hash |
| `version` | STRING | **PK** - Version tag |
| `dta_id` | STRING | **FK** - Associated DTA |
| `transfer_variable_name` | STRING | Variable name |
| `transfer_variable_label` | STRING | Variable label |
| `transfer_variable_order` | INT | Order in transfer file |
| `variable_description` | STRING | Detailed description |
| `format` | STRING | Data type |
| `anticipated_max_length` | INT | Maximum length |
| `transfer_file_key` | BOOLEAN | Part of unique key |
| `populate_for_all_records` | BOOLEAN | Required for all records |
| `example_values` | STRING | Sample values |
| `codelist_values` | STRING | Associated codelists (JSON) |
| `vendor_comment` | STRING | Vendor-provided comment |
| `domain_info` | STRING | Domain information |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `status` | STRING | COMPLETED, MANUAL_REVIEW_REQUIRED |
| `parent_version` | STRING | Version branched from |
| `is_major_version` | BOOLEAN | TRUE for DTA Template versions |
| `is_dta_major` | BOOLEAN | TRUE for DTA Approved versions |
| `is_current` | BOOLEAN | Active version flag |
| `effective_start_ts` | TIMESTAMP | When version became active |
| `effective_end_ts` | TIMESTAMP | When superseded (NULL if current) |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/common/nb_version_approve_dta.ipynb` |

---

### 7. md_dta_vendor_test_concepts

**Purpose**: Approved vendor test concept definitions with SCD Type 2 versioning.

| Column | Type | Description |
|--------|------|-------------|
| `definition_hash` | STRING | **PK** - Unique definition hash |
| `version` | STRING | **PK** - Version tag |
| `dta_id` | STRING | **FK** - Associated DTA |
| `test_concept_reference` | STRING | Test concept identifier |
| `variable_description` | STRING | Description of the test concept |
| `transfer_tuple_map` | MAP<STRING, STRING> | Dynamic mapping of transfer variables |
| `codelist_values` | STRING | Associated codelists (JSON) |
| `vendor_comment` | STRING | Vendor-provided comment |
| `domain_info` | STRING | Domain information |
| `notes` | STRING | Additional notes |
| `status` | STRING | COMPLETED, MANUAL_REVIEW_REQUIRED |
| `parent_version` | STRING | Version branched from |
| `is_major_version` | BOOLEAN | TRUE for DTA Template versions |
| `is_dta_major` | BOOLEAN | TRUE for DTA Approved versions |
| `is_current` | BOOLEAN | Active version flag |
| `effective_start_ts` | TIMESTAMP | When version became active |
| `effective_end_ts` | TIMESTAMP | When superseded (NULL if current) |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/common/nb_version_approve_dta.ipynb` |

---

## Silver Layer Tables

### 1. md_dta_transfer_variables_draft

**Purpose**: Draft transfer variable definitions being reviewed before approval.

| Column | Type | Description |
|--------|------|-------------|
| `transfer_variable_field_id` | STRING | **PK** - Unique record ID |
| `parent_document_id` | STRING | **FK** - References source document |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `transfer_variable_name` | STRING | Variable name |
| `transfer_variable_label` | STRING | Variable label |
| `transfer_variable_order` | INT | Order in transfer file |
| `variable_description` | STRING | Detailed description |
| `format` | STRING | Data type (text, numeric, date) |
| `anticipated_max_length` | INT | Maximum field length |
| `transfer_file_key` | BOOLEAN | Part of unique key |
| `populate_for_all_records` | BOOLEAN | Required for all records |
| `example_values` | STRING | Sample values |
| `codelist_values` | STRING | Associated codelist values |
| `vendor_comment` | STRING | Vendor-provided comment |
| `domain_info` | STRING | Domain information |
| `definition_hash` | STRING | Hash for deduplication |
| `status` | STRING | COMPLETED or MANUAL_REVIEW_REQUIRED |
| `notes` | STRING | Processing notes |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_transfer_variables_processor.ipynb` |

---

### 2. md_dta_vendor_test_concepts_draft

**Purpose**: Draft vendor test concepts being reviewed before approval.

| Column | Type | Description |
|--------|------|-------------|
| `test_concept_id` | STRING | **PK** - Unique record ID |
| `parent_document_id` | STRING | **FK** - References source document |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `test_concept_reference` | STRING | Test concept identifier |
| `variable_description` | STRING | Description |
| `transfer_tuple_map` | MAP<STRING, STRING> | Dynamic mapping of transfer variables |
| `codelist_values` | STRING | Associated codelists |
| `vendor_comment` | STRING | Vendor-provided comment |
| `domain_info` | STRING | Domain information |
| `notes` | STRING | Additional notes |
| `definition_hash` | STRING | Hash for deduplication |
| `status` | STRING | COMPLETED or MANUAL_REVIEW_REQUIRED |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_test_concepts_processor.ipynb` |

---

### 3. md_codelists_normalized

**Purpose**: Standardized codelist values extracted from tsDTA files.

| Column | Type | Description |
|--------|------|-------------|
| `codelist_id` | STRING | **PK** - Unique codelist record ID |
| `parent_document_id` | STRING | **FK** - References source document |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `transfer_variable_name` | STRING | Associated variable |
| `codelist_reference` | STRING | Codelist identifier |
| `code_value` | STRING | Individual code value |
| `status` | STRING | Processing status |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/clinical_data_standards/jobs/nb_tsdta_code_lists_processor.ipynb` |

---

## Bronze Layer Tables

### 1. md_file_history

**Purpose**: Document manifest with extraction status and completion tracking.

| Column | Type | Description |
|--------|------|-------------|
| `document_id` | STRING | **PK** - Unique document identifier |
| `parent_document_id` | STRING | **FK** - Self-reference for parent ZIP |
| `zip_source_path` | STRING | Original ZIP file path |
| `extracted_path` | STRING | Extraction location |
| `content_base64` | STRING | Base64 encoded file content |
| `size_bytes` | LONG | File size |
| `file_extension` | STRING | File type extension |
| `document_tags` | ARRAY<STRING> | Classification tags (tsDTA, DTA, etc.) |
| `active` | BOOLEAN | Whether document is active |
| `status` | STRING | Processing status |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |
| `total_documents_count` | INT | Total files in ZIP |
| `required_documents_count` | INT | Files requiring processing |
| `processed_documents_count` | INT | Processed file count |
| `is_enabled` | BOOLEAN | Whether document type is enabled |
| `source` | STRING | Document source: HISTORICAL or UI |
| `status_timestamp` | TIMESTAMP | When status changed |
| `error_message` | STRING | Error details if failed |
| `processing_duration_seconds` | DOUBLE | Processing time |
| `retry_count` | INT | Number of retry attempts |
| `processing_metadata` | STRING | JSON with processing details |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/clinical_data_standards/jobs/nb_file_processor.ipynb` |

---

### 2. md_document_types

**Purpose**: Reference table that controls which document types are enabled for processing.

| Column | Type | Description |
|--------|------|-------------|
| `document_type` | STRING | **PK** - Document type (tsDTA, Protocol, etc.) |
| `document_type_label` | STRING | Display name for UI |
| `is_enabled` | BOOLEAN | Whether this type should be processed |
| `description` | STRING | Documentation |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `sql/load_reference_data.sql` |

---

### 3. md_dta_excel_file_raw

**Purpose**: Excel sheet metadata for tsDTA files.

| Column | Type | Description |
|--------|------|-------------|
| `document_id` | STRING | **PK** - Unique sheet identifier |
| `parent_document_id` | STRING | **FK** - References parent Excel file |
| `sheet_name` | STRING | Excel sheet name |
| `sheet_index` | INT | Sheet position (0-based) |
| `sheet_category` | STRING | Categorized type (transfer_metadata, codelists, etc.) |
| `trial_id` | STRING | Trial identifier |
| `data_stream_type` | STRING | Data stream type |
| `data_provider_name` | STRING | Vendor/provider name |

**Low Level Design**

| Component | Path |
|-----------|------|
| Created By | `notebooks/data_engineering/clinical_data_standards/jobs/nb_extract_excel_sheets.ipynb` |

---

## Key Design Patterns

### 1. Parent-Child Document Linking

`parent_document_id` links child documents to parent ZIPs, enabling tracking of document lineage through extraction.

```
ZIP File (parent_document_id = NULL)
├── Excel File 1 (parent_document_id = ZIP.document_id)
│   ├── Sheet 1 (parent_document_id = Excel.document_id)
│   └── Sheet 2 (parent_document_id = Excel.document_id)
└── Excel File 2 (parent_document_id = ZIP.document_id)
```

### 2. Trial Context Propagation

`trial_id`, `data_stream_type`, and `data_provider_name` propagate through all layers, enabling filtering and grouping by trial context.

### 3. SCD Type 2 Versioning

Used in `md_dta_transfer_variables` and `md_dta_vendor_test_concepts`:

| Column | Purpose |
|--------|---------|
| `effective_start_ts` | When version became active |
| `effective_end_ts` | When superseded (NULL if current) |
| `is_current` | Active version flag |
| `version` + `definition_hash` | Composite primary key |

### 4. Audit Columns

All tables include standard audit columns:

| Column | Type | Description |
|--------|------|-------------|
| `created_by_principal` | STRING | User who created the record |
| `created_ts` | TIMESTAMP | Record creation timestamp |
| `last_updated_by_principal` | STRING | User who last updated |
| `last_updated_ts` | TIMESTAMP | Last update timestamp |
| `databricks_job_id` | STRING | Job ID for lineage |
| `databricks_job_name` | STRING | Job name for lineage |
| `databricks_run_id` | STRING | Run ID for lineage |

---

## Related Documentation

- [01_job_architecture_design.readme.md](./01_job_architecture_design.readme.md) - Job definitions and pipelines
- [04_versioning_design.readme.md](./04_versioning_design.readme.md) - Version management operations
- [06_dta_workflow_design.readme.md](./06_dta_workflow_design.readme.md) - Workflow, approval chain, and governance
- [09_genie_integration_design.readme.md](./09_genie_integration_design.readme.md) - Genie AI integration and training

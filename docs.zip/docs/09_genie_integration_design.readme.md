# Genie AI Integration Design

> **Status**: Implemented  
> **Last Updated**: January 2026

---

## Overview

### What is Databricks AI/BI Genie?

Databricks AI/BI Genie is a natural language interface that allows users to query data using conversational questions instead of writing SQL. Key capabilities include:

| Capability | Description |
|------------|-------------|
| **Natural Language Queries** | Users ask questions in plain English; Genie translates to SQL |
| **Unity Catalog Integration** | Queries tables directly from Unity Catalog with permission enforcement |
| **Conversation Context** | Supports follow-up questions within a conversation |
| **SQL Generation** | Generates and displays the SQL query for transparency |
| **Result Formatting** | Returns results as structured tables or markdown |

### Purpose in DTA Builder

The DTA Builder UI integrates Genie to enable:

- **DTA Discovery**: Search for existing DTAs using natural language (e.g., "Find all Labs DTAs from LabCorp")
- **Version Lookup**: Query version history and approval status
- **Template Search**: Find approved DTAs to use as templates for new work
- **Activity Tracking**: Query recent changes and user activity

### Genie Space Configuration

A Genie Space defines the tables, instructions, and examples that guide Genie's behavior. For DTA Builder:

| Component | Description |
|-----------|-------------|
| **Tables** | Gold layer tables (`dta`, `dta_workflow`, `md_dta_transfer_variables`, etc.) |
| **Instructions** | Domain-specific guidance on DTA terminology and query patterns |
| **Sample Questions** | Representative questions users might ask |
| **SQL Examples** | Parameterized queries that demonstrate correct patterns |

---

## Asset Generation Job

The `job_cdm_export_genie_assets` job dynamically generates all assets needed to configure and update a Genie space.

### Job Workflow

| Task | Notebook | Purpose |
|------|----------|---------|
| `export_genie_assets` | `nb_export_genie_assets.ipynb` | Discover tables, generate component files |
| `generate_serialized_space` | `nb_generate_serialized_space.ipynb` | Assemble final `serialized_space.json` |

### Output Files

```
/Volumes/{catalog}/bronze_md/{volume}/{source_root}/exports/genie/
├── sql/
│   ├── add_table_comments.sql       # Table and column descriptions
│   └── example_queries.sql          # 15 parameterized training queries
├── components/
│   ├── sample_questions.json        # Quick-start questions for users
│   ├── data_sources.json            # Tables with column configurations
│   ├── text_instructions.json       # Space instructions
│   └── example_queries.json         # SQL examples with questions
├── genie_instructions.txt           # Human-readable instructions
├── serialized_space.json            # Complete space configuration for API
└── export_manifest.json             # Export metadata and timestamps
```

### Running the Job

**Via Databricks UI:**
1. Navigate to **Workflows** → **Jobs**
2. Find `job_cdm_export_genie_assets`
3. Click **Run Now**
4. Set parameters:
   - `source_root`: Output folder (e.g., `test` or `prod`)

**Via Test Job:**
Run `job_test_cdm_export_genie_assets` which triggers the main job with test parameters.

### Updating a Genie Space

After generating assets, use the `nb_test_genie_api.ipynb` notebook to update an existing Genie space:

1. Reads `serialized_space.json` from the exports folder
2. Calls `PATCH /api/2.0/genie/spaces/{space_id}` with the configuration
3. Updates tables, instructions, sample questions, and SQL examples

### Job Configuration

**File**: `resources/data_engineering/clinical_data_standards/jobs/job_cdm_export_genie_assets.job.yml`

| Parameter | Default | Description |
|-----------|---------|-------------|
| `source_root` | `test` | Output subfolder in volumes |

---

## UI Design

### Conversational UI Flow Diagram

![Genie Conversational UI Flow](./diagrams/09_genie_conversational_ui.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/09_genie_conversational_ui.drawio)

### Search Mode Toggle

The DTA Builder UI provides two search modes:

```
[○ Standard Search]  [● AI Search with Genie] ✨
```

| Mode | Description |
|------|-------------|
| **Standard Search** | Traditional SQL-based search with field filters |
| **AI Search with Genie** | Natural language queries powered by Genie |

### Genie Conversation Panel

The conversational UI provides a chat-like experience with support for follow-up questions:

| Component | Description |
|-----------|-------------|
| **Chat History** | Scrollable history of user questions and Genie responses |
| **User Messages** | Displayed as blue bubbles on the right |
| **Genie Responses** | Displayed as gray bubbles on the left |
| **Clarification Requests** | Highlighted with amber border when Genie needs more details |
| **Follow-up Input** | Input box to continue the conversation |
| **Generated SQL** | Collapsible section showing the SQL query |
| **New Conversation** | Button to start a fresh conversation |

### Response Type Detection

The API automatically detects the type of response:

| Type | Detection Criteria | UI Behavior |
|------|-------------------|-------------|
| **DATA** | Response contains DTA results | Render DTA cards below conversation |
| **CLARIFICATION** | Response contains question patterns (?, "please specify", "which") | Highlight message, focus follow-up input |
| **INFO** | Text response without actionable data | Display message only |
| **EMPTY** | No meaningful response | Show "no results" message |

### User Experience Flow

**Initial Search:**
1. User selects **AI Search with Genie** toggle
2. User types natural language question
3. User clicks **Ask Genie**
4. Conversation panel opens with user message
5. Loading indicator shows while Genie processes

**Response Handling:**
- **If clarification needed**: Genie asks for more details, follow-up input is focused
- **If data returned**: DTA cards render below the conversation, follow-up available
- **If informational**: Message displayed, user can ask follow-ups

**Follow-up Questions:**
1. User types in follow-up input
2. Clicks **Send** or presses Enter
3. Message added to chat history
4. Genie processes using existing conversation context
5. Response added to history with appropriate formatting

### Error Handling

| Scenario | User Experience |
|----------|-----------------|
| Genie not configured | Toggle disabled with tooltip |
| Query too short | Prompt for more detail |
| No results | Suggestion to refine query |
| Timeout | Error message with retry suggestion |
| API error | Error displayed in chat history |

### JavaScript State Management

The conversational UI maintains state across interactions:

```javascript
let genieState = {
  conversationId: null,   // For follow-up questions
  messages: [],           // Chat history
  lastResponseType: null, // DATA, CLARIFICATION, INFO
  isLoading: false        // Prevent duplicate requests
};
```

### API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/genie/search` | GET | Start new conversation with initial question |
| `/api/genie/followup` | POST | Continue conversation with follow-up question |
| `/api/genie/status` | GET | Check if Genie is configured |

---

## Best Practices for Designing Genie Spaces

### Table Selection

- **Focus on Gold layer**: Include core business tables (`dta`, `dta_workflow`, `md_dta_transfer_variables`)
- **Include Bronze for context**: Add `md_file_history` for document lineage
- **Limit scope**: Too many tables can confuse Genie; start with essential tables
- **Add related tables**: Include lookup tables needed for JOINs

### Table and Column Comments

Rich descriptions help Genie understand data semantics:

- **Table comments**: Explain the purpose and business context
- **Column comments**: Describe what each column contains, valid values, relationships
- **Use `add_table_comments.sql`**: Generated automatically by the export job
- **Include examples**: "data_stream_type contains values like Labs, ECG, Biomarkers"

### Instructions

Write focused, domain-specific instructions:

- **Define terminology**: Explain what DTA, vendor, data stream mean
- **Specify required filters**: "Always ask for vendor and data stream or trial"
- **Clarify relationships**: Explain how tables relate (e.g., dta → dta_workflow)
- **Set expectations**: Define what questions the space can and cannot answer

### Sample Questions

Provide representative questions users might ask:

- Start with common use cases
- Include variations (by vendor, by trial, by status)
- Cover different query types (search, count, latest, history)
- Keep questions natural and conversational

### SQL Examples

Train Genie with parameterized queries:

- **Cover key patterns**: Filtering, joining, aggregating
- **Use consistent style**: Same column selection, JOIN patterns
- **Include comments**: Explain what each query does
- **Match to sample questions**: Each example should answer a sample question

### Column Configurations

Configure column behavior in `data_sources.json`:

| Setting | Purpose |
|---------|---------|
| `get_example_values: true` | Genie fetches sample values to understand column content |
| `build_value_dictionary: true` | Creates lookup for categorical columns (STRING types) |

**Note**: Sort columns alphabetically (Genie API requirement).

### Iterative Refinement

1. **Start simple**: Begin with core tables and basic instructions
2. **Monitor usage**: Review questions in Genie's Monitoring tab
3. **Identify gaps**: Note queries that fail or return wrong results
4. **Refine instructions**: Add clarifications for misunderstood queries
5. **Add examples**: Create SQL examples for problematic patterns
6. **Test variations**: Try different phrasings of the same question
7. **Collect feedback**: Use upvote/downvote to identify improvements

### Required Search Criteria

Configure Genie to ask clarifying questions when context is missing:

| Required Combination | Example |
|---------------------|---------|
| Vendor + Data Stream | "Show me Labs DTAs from LabCorp" |
| Vendor + Trial | "Find DTAs for Covance in trial VAC18193" |

**Instruction to add**: "To find relevant DTAs, please specify the vendor name AND either the data stream type (Labs, ECG, Biomarkers) OR trial ID."

---

## Related Documentation

- [01_job_architecture_design.readme.md](./01_job_architecture_design.readme.md) - Job pipeline architecture
- [02_schema_design.readme.md](./02_schema_design.readme.md) - Table schemas used by Genie
- [Databricks Genie Best Practices](https://docs.databricks.com/aws/en/genie/best-practices) - Official documentation

---

*Last Updated: January 2026*

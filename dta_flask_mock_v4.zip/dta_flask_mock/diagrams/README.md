# PDF Parser UI Flow - Draw.io Diagrams

This directory contains all the visual mockups and flow diagrams for the PDF Parser Databricks application UI design.

## 📁 Diagram Files

### 1. UI Flow Diagram
**File:** `01_UI_Flow_Diagram.drawio`

Shows the complete navigation flow between all screens, including:
- Main screen progression (Upload → Configuration → Processing → Results)
- Alternative flows (View History)
- Available actions from Results Dashboard

---

### 2. Screen 1: Landing / Upload Page
**File:** `02_Screen1_Landing_Upload.drawio`

Features:
- PDF upload area (drag & drop or browse)
- Recent documents list with status indicators
- Quick access to view results or check processing status

**API Endpoints Used:**
- `GET /api/v1/documents/recent`
- `POST /api/v1/upload`

---

### 3. Screen 2: Configuration
**File:** `03_Screen2_Configuration.drawio`

Features:
- Document information display
- Parsing strategy selection (Fast / High Resolution)
- Table extraction options
- Output settings (Catalog, Schema, Volume)
- Processing time estimation

**API Endpoints Used:**
- `POST /api/v1/process`
- `GET /api/v1/config/defaults`

---

### 4. Screen 3: Processing / Progress
**File:** `04_Screen3_Processing.drawio`

Features:
- Real-time progress tracking
- Step-by-step status display (Parsing, Extracting, Detecting, Saving)
- Individual progress bars for each step
- Overall progress indicator
- Time remaining estimation
- Cancel processing option

**API Endpoints Used:**
- `GET /api/v1/status/{job_id}`
- `DELETE /api/v1/process/{job_id}` (for cancellation)

---

### 5. Screen 4: Results Dashboard
**File:** `05_Screen4_Results_Dashboard.drawio`

Features:
- Success banner with completion summary
- Statistics cards (Pages, Sections, Tables, Size)
- Search and filter functionality
- Sections table with:
  - Section titles and excerpts
  - Page ranges
  - Table counts
  - File sizes
  - View and export actions

**API Endpoints Used:**
- `GET /api/v1/results/{document_id}`
- `GET /api/v1/sections?document_id={id}&filter={...}`
- `GET /api/v1/sections/{section_id}/download`

---

### 6. Screen 5: Section Detail View (Modal/Overlay)
**File:** `06_Screen5_Section_Detail_Modal.drawio`

Features:
- Full section content display
- Tabbed interface (Content / Tables / Metadata)
- Metadata summary (pages, tables, size)
- Expandable table previews with structured data
- Individual table download options
- Bulk export functionality

**API Endpoints Used:**
- `GET /api/v1/sections/{section_id}`
- `GET /api/v1/sections/{section_id}/tables`
- `GET /api/v1/tables/{table_id}/download`

---

## 🎨 Opening the Diagrams

These `.drawio` files can be opened with:

1. **draw.io Desktop App** (Recommended)
   - Download from: https://github.com/jgraph/drawio-desktop/releases
   
2. **Online Editor**
   - Visit: https://app.diagrams.net/
   - File → Open From → Device

3. **VS Code Extension**
   - Install "Draw.io Integration" extension
   - Open `.drawio` files directly in VS Code

---

## 📋 Design Notes

### Color Scheme
- **Primary Blue:** `#0066CC` - Actions, highlights, active states
- **Success Green:** `#10B981` - Completed states, positive indicators
- **Warning Orange:** `#F59E0B` - In-progress states, table indicators
- **Error Red:** `#DC2626` - Cancel actions, error states
- **Gray Scale:** `#F9FAFB`, `#F3F4F6`, `#E5E7EB` - Backgrounds, borders

### Typography
- **Headers:** 16-20px, Bold
- **Body Text:** 12-14px, Regular
- **Metadata/Secondary:** 11-12px, Gray (#666666)

### Layout
- **Screen Width:** 800-1240px (responsive)
- **Padding:** 20-40px margins
- **Border Radius:** 4-8px for cards and buttons
- **Spacing:** 20px between major sections

---

## 🔄 Related Documentation

- **UI Flow Design:** `../UI_FLOW_DESIGN.md` - Detailed specifications for each screen
- **API Architecture:** `../API_ARCHITECTURE.md` - Backend API endpoints and data models
- **Database Schema:** `../../sql/metadata_schema_v1.sql` - Data structure

---

## 📝 Version History

- **v1.0** - Initial UI mockups created from design document
  - All 6 screens with complete UI elements
  - Databricks-compatible color scheme
  - Interactive elements (buttons, tabs, modals) clearly marked


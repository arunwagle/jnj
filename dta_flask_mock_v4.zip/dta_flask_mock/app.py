
from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
from datetime import datetime
import json
import random
import re

# Import API layer and data storage
import api
import data
from data import WORKSPACES, MOCK_RUNS, MOCK_RESULTS

app = Flask(__name__)
app.secret_key = "dev-secret"  # for flashes (demo only)

# -------- Routes --------
@app.route("/")
def home():
    return redirect(url_for("dashboard"))

@app.route("/dashboard")
def dashboard():
    """Dashboard - shows all DTAs (pending approval and approved)"""
    # Call API to get dashboard data
    result = api.get_dashboard_dtas()
    
    if not result["success"]:
        flash(f"Error loading dashboard: {result.get('error')}", "error")
        return render_template("dashboard.html", pending_dtas=[], approved_dtas=[], total_count=0)
    
    api_data = result["data"]
    # Separate DTAs by status
    pending_dtas = [ws for ws in api_data["dtas"] if ws.get("status") == "Pending Approval"]
    approved_dtas = [ws for ws in api_data["dtas"] if ws.get("status") == "Approved"]
    
    return render_template("dashboard.html", 
                         pending_dtas=pending_dtas, 
                         approved_dtas=approved_dtas,
                         total_count=api_data["total_count"])

@app.route("/upload")
def upload():
    """Upload Documents page"""
    return render_template("upload.html")

@app.route("/document-editor/<doc_id>")
def document_editor(doc_id):
    """Document Editor for manual review"""
    doc_type = request.args.get("type", "Protocol")
    
    # Mock extracted data based on document type
    if doc_type == "Protocol":
        doc_data = {
            "id": doc_id,
            "type": "Protocol",
            "filename": "Clinical_Protocol_TRIAL-ABC_v3.2.pdf",
            "extracted": {
                "trial_id": "TRIAL-ABC",
                "protocol_number": "JNJ-ABC-2025-001",
                "study_title": "A Phase 3, Randomized, Double-Blind Study of Drug X in Patients with Condition Y",
                "study_phase": "Phase 3",
                "therapeutic_area": "Oncology",
                "transfer_variables": "STUDYID, USUBJID, DOMAIN, AGE, SEX, RACE, COUNTRY",
                "test_concepts": "LBTESTCD, LBTEST, LBCAT, LBORRES, LBORRESU"
            },
            "notes": ""
        }
    else:  # SOW
        doc_data = {
            "id": doc_id,
            "type": "SOW",
            "filename": "SOW_Vendor_XYZ_2025.docx",
            "extracted": {
                "vendor_name": "ABC Clinical Labs",
                "vendor_id": "VEND-2",
                "data_stream": "Laboratory Results",
                "agreement_date": "2025-01-15",
                "data_format": "CSV",
                "delivery_frequency": "Weekly"
            },
            "notes": ""
        }
    
    return render_template("document_editor.html", doc_data=doc_data)

@app.route("/ingestion")
def ingestion():
    status = request.args.get("status")
    if status:
        filtered = [r for r in MOCK_RUNS if r["status"] == status]
    else:
        filtered = MOCK_RUNS
    kpis = {
        "runs7d": 57,
        "successRate": "92%",
        "avgDuration": "13m",
        "entitiesProduced": ["Metadata", "Visits and Timepoints", "Transfer Variables", "Test Concepts", "Code Lists"]
    }
    return render_template("ingestion.html", runs=filtered, status=status, kpis=kpis)

def parse_search_query(q):
    """
    Parse free-form search query and extract trial, vendor, stream filters.
    Supports formats like:
    - "TRIAL-ABC"
    - "trial id = ABC"
    - "ABC"
    - "trial id = ABC and vendor id = VEND-1"
    - "ABC VEND-1"
    """
    import re
    
    q_lower = q.lower()
    filters = {
        'trial': [],
        'vendor': [],
        'stream': []
    }
    
    # Pattern for "field = value" or "field: value"
    field_patterns = [
        (r'trial\s*(?:id)?\s*[=:]\s*([a-z0-9\-]+)', 'trial'),
        (r'vendor\s*(?:id)?\s*[=:]\s*([a-z0-9\-]+)', 'vendor'),
        (r'(?:data\s*)?stream\s*[=:]\s*([a-z0-9\-]+)', 'stream'),
    ]
    
    for pattern, field in field_patterns:
        matches = re.findall(pattern, q_lower, re.IGNORECASE)
        for match in matches:
            # Add with or without prefix
            filters[field].append(match.upper())
            if field == 'trial' and not match.upper().startswith('TRIAL-'):
                filters[field].append(f'TRIAL-{match.upper()}')
            elif field == 'vendor' and not match.upper().startswith('VEND-'):
                filters[field].append(f'VEND-{match.upper()}')
    
    # If no structured patterns found, try to extract tokens
    if not any(filters.values()):
        # Remove common words
        stop_words = ['and', 'or', 'the', 'id', '=', ':']
        tokens = re.findall(r'[a-z0-9\-]+', q_lower)
        tokens = [t for t in tokens if t not in stop_words and len(t) > 1]
        
        for token in tokens:
            token_upper = token.upper()
            # Try to guess the field type
            if token.startswith('trial-') or re.match(r'^trial', token):
                filters['trial'].append(token_upper)
                if not token_upper.startswith('TRIAL-'):
                    filters['trial'].append(f'TRIAL-{token_upper}')
            elif token.startswith('vend-') or re.match(r'^vend', token):
                filters['vendor'].append(token_upper)
                if not token_upper.startswith('VEND-'):
                    filters['vendor'].append(f'VEND-{token_upper}')
            else:
                # Could be trial, vendor, or stream - add to all
                filters['trial'].append(token_upper)
                filters['trial'].append(f'TRIAL-{token_upper}')
                filters['vendor'].append(token_upper)
                filters['vendor'].append(f'VEND-{token_upper}')
                filters['stream'].append(token_upper)
    
    return filters

@app.route("/approvals")
def approvals():
    """Approvals page - shows DTAs pending approval"""
    # Get all workspaces with status "Pending Approval"
    pending_dtas = [ws for ws in WORKSPACES.values() if ws.get("status") == "Pending Approval"]
    # Sort by submitted_at (most recent first)
    pending_dtas.sort(key=lambda x: x.get("submitted_at", ""), reverse=True)
    return render_template("approvals.html", dtas=pending_dtas)

@app.route("/approvals/<path:key>")
def approval_detail(key):
    """Approval/View detail page - shows read-only DTA configuration for both pending and approved DTAs"""
    ws = WORKSPACES.get(key)
    if not ws:
        return "DTA not found", 404
    
    # Allow both Pending Approval and Approved statuses
    if ws.get("status") not in ["Pending Approval", "Approved"]:
        return "DTA is not available for review", 400
    
    # Determine which nav item should be active based on status
    # Pending Approval -> Approvals nav
    # Approved -> Dashboard nav
    nav_active = "approvals" if ws.get("status") == "Pending Approval" else "dashboard"
    
    # Get current tab
    current_tab = request.args.get("tab", "META")
    allowed_tabs = ["META", "TV", "TC", "CL", "VT", "DIP"]
    
    def label_for_tab(t):
        mapping = {
            "META": "Metadata",
            "TV": "Transfer Variables",
            "TC": "Test Concepts",
            "CL": "Code Lists",
            "VT": "Visit and Timepoints",
            "DIP": "Data Ingestion Parameters"
        }
        return mapping.get(t, t)
    
    return render_template("approval_detail.html", ws=ws, current_tab=current_tab, 
                         allowed_tabs=allowed_tabs, label_for_tab=label_for_tab,
                         nav_active=nav_active)

@app.route("/composer")
def composer():
    q = (request.args.get("q") or "").strip()
    if not q:
        # No query - show empty state
        results = []
    else:
        # Parse the search query for advanced syntax (e.g., "TRIAL =ABC")
        filters = parse_search_query(q)
        
        # Get all results from API (we'll filter them with advanced logic)
        api_result = api.search_workspaces("")  # Get all results
        
        if not api_result["success"]:
            flash(f"Search error: {api_result.get('error')}", "error")
            results = []
        else:
            all_results = api_result["data"]
            
            # Filter results based on extracted criteria
            def matches(r):
                # If we have specific filters from structured query, use them
                if filters['trial'] or filters['vendor'] or filters['stream']:
                    # Check if this is a token-based search (all fields populated) or structured search
                    is_token_search = (filters['trial'] and filters['vendor'] and filters['stream'])
                    
                    trial_match = not filters['trial'] or any(f in r["trial"].upper() or r["trial"].upper() in f for f in filters['trial'])
                    vendor_match = not filters['vendor'] or any(f in r["vendor"].upper() or r["vendor"].upper() in f for f in filters['vendor'])
                    stream_match = not filters['stream'] or any(f.upper() in r["stream"].upper() or r["stream"].upper() in f.upper() for f in filters['stream'])
                    
                    if is_token_search:
                        # For token-based search (like "ABC"), use OR logic
                        return trial_match or vendor_match or stream_match
                    else:
                        # For structured search (like "trial = ABC"), use AND logic
                        return trial_match and vendor_match and stream_match
                else:
                    # Fallback: simple substring search
                    q_lower = q.lower()
                    return (q_lower in r["trial"].lower() or 
                           q_lower in r["vendor"].lower() or 
                           q_lower in r["stream"].lower())
            
            results = [r for r in all_results if matches(r)]
    return render_template("composer.html", results=results, q=q)

@app.route("/workspace/<path:key>")
def workspace(key):
    res = next((r for r in MOCK_RESULTS if r["key"] == key), None)
    if not res:
        flash("DTA not found", "error")
        return redirect(url_for("composer"))
    ws = data.get_or_create_workspace(res)
    
    # Check if DTA is in Pending Approval or Approved state
    if ws.get("status") in ["Pending Approval", "Approved"]:
        # Both pending and approved DTAs use the approval_detail view
        # The view will show different buttons based on status
        return redirect(url_for("approval_detail", key=key))

    allowed_tabs = ["META","TV","TC","CL","VT","DIP"]  # VT and DIP are last two tabs
    tab = request.args.get("tab") or ws.get("editor_tab") or "META"
    if tab not in allowed_tabs:
        tab = "VT"
    ws["editor_tab"] = tab

    data._ensure_tv_init(ws)
    print(f"DBG tv_selected: {ws.get('tv_selected')}")
    print(f"DBG tv_state: {ws.get('tv_state')}")
    print(f"DBG TV entities count: {len(ws.get('entities', {}).get('TV', []))}")
    
    # Group codelists by reference for CL tab
    cl_grouped = data.group_codelists_by_ref(ws.get('entities', {}).get('CL', []))
    
    return render_template("workspace.html",
                           ws=ws,
                           current_tab=tab,
                           allowed_tabs=allowed_tabs,
                           label_for_tab=label_for_tab,
                           cl_grouped=cl_grouped)

@app.route("/api/workspace/<path:key>/save", methods=["POST"])
def api_save(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    return jsonify({"ok": True, "msg": f"Draft {ws['draft_id']} saved."})

@app.route("/api/approvers", methods=["GET"])
def get_approvers():
    """Return list of available approvers for each role"""
    approvers = {
        "jnj_dae": [
            {"id": "jnj_1", "name": "Sarah Johnson", "title": "DAE Lead", "email": "sarah.johnson@jnj.com"},
            {"id": "jnj_2", "name": "Michael Chen", "title": "Senior DAE", "email": "michael.chen@jnj.com"},
            {"id": "jnj_3", "name": "Emily Rodriguez", "title": "DAE Manager", "email": "emily.rodriguez@jnj.com"}
        ],
        "vendor": [
            {"id": "vnd_1", "name": "Alex Kumar", "title": "Data Manager", "email": "alex.kumar@vendor.com"},
            {"id": "vnd_2", "name": "David Park", "title": "Senior Data Scientist", "email": "david.park@vendor.com"},
            {"id": "vnd_3", "name": "Jennifer Lee", "title": "QC Lead", "email": "jennifer.lee@vendor.com"}
        ],
        "librarian": [
            {"id": "lib_1", "name": "Lisa Wong", "title": "Study Librarian", "email": "lisa.wong@jnj.com"},
            {"id": "lib_2", "name": "Robert Martinez", "title": "Senior Librarian", "email": "robert.martinez@jnj.com"},
            {"id": "lib_3", "name": "Patricia Taylor", "title": "Data Librarian", "email": "patricia.taylor@jnj.com"}
        ]
    }
    return jsonify({"success": True, "approvers": approvers})

@app.route("/api/workspace/<path:key>/submit", methods=["POST"])
def api_submit(key):
    # Get request data
    request_data = request.get_json() or {}
    approvers_list = request_data.get("approvers", [])
    
    # Call API to submit for approval
    result = api.submit_for_approval(key, approvers_list)
    
    if result["success"]:
        return jsonify({"success": True, "msg": result.get("message", "Submitted for approval.")})
    else:
        return jsonify({"ok": False, "msg": result.get("error", "Submission failed")}), 404

@app.route("/api/workspace/<path:key>/approve", methods=["POST"])
def api_approve(key):
    # Call API to approve DTA
    result = api.approve_dta(key)
    
    if result["success"]:
        return jsonify({"success": True, "msg": result.get("message", "DTA approved")})
    else:
        return jsonify({"ok": False, "msg": result.get("error", "Approval failed")}), 404

@app.route("/api/workspace/<path:key>/reject", methods=["POST"])
def api_reject(key):
    # Get rejection reason from request
    request_data = request.json or {}
    reason = request_data.get("reason", "No reason provided")
    
    # Call API to reject DTA
    result = api.reject_dta(key, reason)
    
    if result["success"]:
        return jsonify({"success": True, "msg": result.get("message", "DTA rejected")})
    else:
        return jsonify({"ok": False, "msg": result.get("error", "Rejection failed")}), 404

@app.route("/api/workspace/<path:key>/publish", methods=["POST"])
def api_publish(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    next_major = ws["base_major"] + 1
    return jsonify({
        "ok": True,
        "msg": f"Publishing Major v{next_major} (simulated). Prior is_current=false, SCD2 rows written."
    })

@app.route("/api/workspace/<path:key>/comment", methods=["POST"])
def api_comment(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    text = (request.json or {}).get("text", "").strip()
    if not text:
        return jsonify({"ok": False, "msg": "empty comment"}), 400
    ws["comments"].append({
        "text": text,
        "user": "you@jnj.com",
        "ts": datetime.utcnow().isoformat()
    })
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/entity/<tab>/<int:idx>/<col>", methods=["POST"])
def api_update_cell(key, tab, idx, col):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    value = (request.json or {}).get("value")
    try:
        ws["entities"][tab][idx][col] = value
    except Exception:
        return jsonify({"ok": False, "msg": "bad index/column"}), 400
    return jsonify({"ok": True})

def label_for_tab(t):
    return {
        "VT": "Visit and Timepoints",
        "DIP": "Data Ingestion Parameters",
        "TV": "Transfer Variables",
        "CL": "Code Lists",
        "TC": "Test Concepts",
        "META": "Metadata",
    }.get(t, t)

# === TC (Test Concepts) endpoints ===

@app.route("/api/workspace/<path:key>/tc/<int:idx>/edit", methods=["POST"])
def api_tc_edit(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: 
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    try:
        ws["tc_state"][idx]["editable"] = True
        ws["tc_state"][idx]["approved"] = False  # editing resets approval
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tc/<int:idx>/save", methods=["POST"])
def api_tc_save(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    # No-op for now (cells already saved via updateCell); just toggle editable off
    try:
        ws["tc_state"][idx]["editable"] = False
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tc/<int:idx>/cancel", methods=["POST"])
def api_tc_cancel(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    # Cancel edits without saving - just toggle editable off
    try:
        ws["tc_state"][idx]["editable"] = False
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tc/<int:idx>/approve", methods=["POST"])
def api_tc_approve(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    try:
        ws["tc_state"][idx]["approved"] = True
        ws["tc_state"][idx]["editable"] = False
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tc/<int:idx>/comment", methods=["POST"])
def api_tc_comment(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    payload = request.json or {}
    text = (payload.get("text") or "").strip()
    if not text:
        return jsonify({"ok": False, "msg": "empty comment"}), 400
    try:
        ws["tc_state"][idx]["comments"].insert(0, {
            "user": payload.get("user") or "vendor@example.com",
            "ts": datetime.utcnow().isoformat(),
            "text": text
        })
    except Exception:
        return jsonify({"ok": False, "msg": "bad index"}), 400
    return jsonify({"ok": True})

# === Transfer Variables (TV) endpoints ===

@app.route("/api/workspace/<path:key>/tv/select/<int:idx>", methods=["POST"])
def api_tv_select(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    ws["tv_selected"] = idx
    return jsonify({"ok": True, "selected": idx})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/update", methods=["POST"])
def api_tv_update(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    payload = request.json or {}
    for k in ["FILE_ORDER","FORMAT","LENGTH","REQUIRED","TEST_CONCEPTS","EXAMPLE_VALUES"]:
        if k in payload:
            ws["entities"]["TV"][idx][k] = payload[k]
    return jsonify({"ok": True, "row": ws["entities"]["TV"][idx]})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/edit", methods=["POST"])
def api_tv_edit(key, idx):
    print(f"API tv_edit called: key={key}, idx={idx}")
    ws = WORKSPACES.get(key)
    if not ws:
        print(f"Workspace not found: {key}")
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    print(f"TV state before edit: {ws.get('tv_state')}")
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        print(f"Bad index: {idx}, TV length: {len(ws['entities']['TV'])}")
        return jsonify({"ok": False, "msg": "bad index"}), 400
    ws["tv_state"][idx]["editable"] = True
    ws["tv_state"][idx]["approved"] = False  # editing resets approval
    print(f"TV state after edit: {ws['tv_state'][idx]}")
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/save", methods=["POST"])
def api_tv_save(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    # No-op for now (cells already saved via updateCell); just toggle editable off
    ws["tv_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/cancel", methods=["POST"])
def api_tv_cancel(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    # Cancel edits without saving - just toggle editable off
    ws["tv_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/approve", methods=["POST"])
def api_tv_approve(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    ws["tv_state"][idx]["approved"] = True
    ws["tv_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/<int:idx>/comment", methods=["POST"])
def api_tv_comment(key, idx):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    if idx < 0 or idx >= len(ws["entities"]["TV"]):
        return jsonify({"ok": False, "msg": "bad index"}), 400
    payload = request.json or {}
    text = (payload.get("text") or "").strip()
    if not text:
        return jsonify({"ok": False, "msg": "empty comment"}), 400
    ws["tv_state"][idx]["comments"].insert(0, {
        "user": payload.get("user") or "vendor@example.com",
        "ts": datetime.utcnow().isoformat(),
        "text": text
    })
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/tv/add", methods=["POST"])
def api_tv_add(key):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    data._ensure_tv_init(ws)
    new_idx = len(ws["entities"]["TV"]) + 1
    row = {
        "LABEL": "",  # Empty for user to fill
        "FILE_ORDER": new_idx,
        "FORMAT": "",
        "LENGTH": 0,
        "REQUIRED": False,
        "TEST_CONCEPTS": "",
        "EXAMPLE_VALUES": ""
    }
    ws["entities"]["TV"].append(row)
    ws["tv_state"].append({"approved": False, "editable": True, "comments": []})  # New row is editable
    ws["tv_selected"] = new_idx - 1
    return jsonify({"ok": True, "index": ws["tv_selected"], "row": row})

@app.route("/api/workspace/<path:key>/tc/add", methods=["POST"])
def api_tc_add(key):
    ws = WORKSPACES.get(key)
    if not ws: return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    # Get the first row to determine column structure
    if not ws.get("entities", {}).get("TC"):
        return jsonify({"ok": False, "msg": "No TC data exists"}), 400
    
    # Create a blank row with all columns set to empty strings
    first_row = ws["entities"]["TC"][0]
    row = {key: "" for key in first_row.keys()}
    
    ws["entities"]["TC"].append(row)
    
    # Initialize tc_state if it doesn't exist
    if "tc_state" not in ws:
        ws["tc_state"] = []
    
    # Add state for the new row - set as editable by default
    ws["tc_state"].append({"approved": False, "editable": True, "comments": []})
    
    return jsonify({"ok": True, "index": len(ws["entities"]["TC"]) - 1, "row": row})

# === Code Lists (CL) endpoints ===

def _get_cl_item_by_ref_idx(cl_list, ref, idx):
    """Get the idx-th item with given ref from CL list."""
    matching = [item for item in cl_list if item["ref"] == ref]
    if idx < 0 or idx >= len(matching):
        return None
    # Find the global index in cl_list
    count = 0
    for i, item in enumerate(cl_list):
        if item["ref"] == ref:
            if count == idx:
                return i, item
            count += 1
    return None

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/edit", methods=["POST"])
def api_cl_edit(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if ref not in ws.get("cl_state", {}):
        return jsonify({"ok": False, "msg": "reference not found"}), 404
    
    if idx < 0 or idx >= len(ws["cl_state"][ref]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["cl_state"][ref][idx]["editable"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/save", methods=["POST"])
def api_cl_save(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    code = payload.get("code", "")
    text = payload.get("text", "")
    
    result = _get_cl_item_by_ref_idx(ws.get("entities", {}).get("CL", []), ref, idx)
    if result is None:
        return jsonify({"ok": False, "msg": "code not found"}), 404
    
    global_idx, item = result
    item["code"] = code
    item["text"] = text
    
    ws["cl_state"][ref][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/cancel", methods=["POST"])
def api_cl_cancel(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if ref not in ws.get("cl_state", {}):
        return jsonify({"ok": False, "msg": "reference not found"}), 404
    
    if idx < 0 or idx >= len(ws["cl_state"][ref]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    # Simply set editable to false without saving changes
    ws["cl_state"][ref][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/approve", methods=["POST"])
def api_cl_approve(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if ref not in ws.get("cl_state", {}):
        return jsonify({"ok": False, "msg": "reference not found"}), 404
    
    if idx < 0 or idx >= len(ws["cl_state"][ref]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["cl_state"][ref][idx]["approved"] = True
    ws["cl_state"][ref][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/<int:idx>/comment", methods=["POST"])
def api_cl_comment(key, ref, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    text = payload.get("text", "")
    
    if not text:
        return jsonify({"ok": False, "msg": "comment text required"}), 400
    
    if ref not in ws.get("cl_state", {}):
        return jsonify({"ok": False, "msg": "reference not found"}), 404
    
    if idx < 0 or idx >= len(ws["cl_state"][ref]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    comment = {
        "user": "You",
        "ts": datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
        "text": text
    }
    ws["cl_state"][ref][idx]["comments"].append(comment)
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/cl/<path:ref>/add", methods=["POST"])
def api_cl_add(key, ref):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    cl_list = ws.get("entities", {}).get("CL", [])
    
    # Add new blank code entry
    new_item = {"ref": ref, "code": "", "text": ""}
    cl_list.append(new_item)
    
    # Initialize state for the new code
    if ref not in ws.get("cl_state", {}):
        ws["cl_state"][ref] = []
    
    ws["cl_state"][ref].append({"editable": True, "approved": False, "comments": []})
    
    return jsonify({"ok": True})


# === Transfer File Keys endpoints ===

@app.route("/api/workspace/<path:key>/transfer-keys/add", methods=["POST"])
def api_add_transfer_key(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    variable = payload.get("variable", "").strip()
    
    if not variable:
        return jsonify({"ok": False, "msg": "variable name is required"}), 400
    
    # Initialize transfer_file_keys if it doesn't exist
    if "transfer_file_keys" not in ws:
        ws["transfer_file_keys"] = []
    
    # Check if variable already exists in keys
    if variable in ws["transfer_file_keys"]:
        return jsonify({"ok": False, "msg": "variable already in keys"}), 400
    
    # Verify the variable exists in TV entities
    tv_labels = [row.get("LABEL", "") for row in ws.get("entities", {}).get("TV", [])]
    if variable not in tv_labels:
        return jsonify({"ok": False, "msg": "variable not found in Transfer Variables"}), 400
    
    ws["transfer_file_keys"].append(variable)
    return jsonify({"ok": True, "keys": ws["transfer_file_keys"]})

@app.route("/api/workspace/<path:key>/transfer-keys/remove", methods=["POST"])
def api_remove_transfer_key(key):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    payload = request.json or {}
    variable = payload.get("variable", "").strip()
    
    if not variable:
        return jsonify({"ok": False, "msg": "variable name is required"}), 400
    
    # Initialize transfer_file_keys if it doesn't exist
    if "transfer_file_keys" not in ws:
        ws["transfer_file_keys"] = []
    
    # Remove the variable if it exists
    if variable in ws["transfer_file_keys"]:
        ws["transfer_file_keys"].remove(variable)
        return jsonify({"ok": True, "keys": ws["transfer_file_keys"]})
    else:
        return jsonify({"ok": False, "msg": "variable not found in keys"}), 404

# === Metadata endpoints ===
@app.route("/api/workspace/<path:key>/meta/<int:idx>/edit", methods=["POST"])
def api_meta_edit(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata_state" not in ws or idx < 0 or idx >= len(ws["metadata_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["metadata_state"][idx]["editable"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/meta/<int:idx>/save", methods=["POST"])
def api_meta_save(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata" not in ws or idx < 0 or idx >= len(ws["metadata"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    data = request.json or {}
    value = data.get("value", "")
    
    # Update the metadata value
    ws["metadata"][idx]["value"] = value
    ws["metadata_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/meta/<int:idx>/cancel", methods=["POST"])
def api_meta_cancel(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata_state" not in ws or idx < 0 or idx >= len(ws["metadata_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["metadata_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/meta/<int:idx>/approve", methods=["POST"])
def api_meta_approve(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata_state" not in ws or idx < 0 or idx >= len(ws["metadata_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["metadata_state"][idx]["approved"] = True
    ws["metadata_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/meta/<int:idx>/comment", methods=["POST"])
def api_meta_comment(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "metadata_state" not in ws or idx < 0 or idx >= len(ws["metadata_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    data = request.json or {}
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"ok": False, "msg": "empty comment"}), 400
    
    comment = {
        "user": "Current User",
        "ts": datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
        "text": text
    }
    ws["metadata_state"][idx]["comments"].append(comment)
    return jsonify({"ok": True})

# === DIP (Data Ingestion Parameters) endpoints ===
@app.route("/api/workspace/<path:key>/dip/<int:idx>/edit", methods=["POST"])
def api_dip_edit(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip_state" not in ws or idx < 0 or idx >= len(ws["dip_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["dip_state"][idx]["editable"] = True
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/dip/<int:idx>/save", methods=["POST"])
def api_dip_save(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip" not in ws or idx < 0 or idx >= len(ws["dip"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    data = request.json or {}
    value = data.get("value", "")
    
    # Update the dip value
    ws["dip"][idx]["value"] = value
    ws["dip_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/dip/<int:idx>/cancel", methods=["POST"])
def api_dip_cancel(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip_state" not in ws or idx < 0 or idx >= len(ws["dip_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["dip_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/dip/<int:idx>/approve", methods=["POST"])
def api_dip_approve(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip_state" not in ws or idx < 0 or idx >= len(ws["dip_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    ws["dip_state"][idx]["approved"] = True
    ws["dip_state"][idx]["editable"] = False
    return jsonify({"ok": True})

@app.route("/api/workspace/<path:key>/dip/<int:idx>/comment", methods=["POST"])
def api_dip_comment(key, idx):
    ws = WORKSPACES.get(key)
    if not ws:
        return jsonify({"ok": False, "msg": "workspace not found"}), 404
    
    if "dip_state" not in ws or idx < 0 or idx >= len(ws["dip_state"]):
        return jsonify({"ok": False, "msg": "invalid index"}), 404
    
    data = request.json or {}
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"ok": False, "msg": "empty comment"}), 400
    
    comment = {
        "user": "Current User",
        "ts": datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
        "text": text
    }
    ws["dip_state"][idx]["comments"].append(comment)
    return jsonify({"ok": True})

# === Export and Publish Endpoints ===

@app.route("/api/workspace/<path:key>/export", methods=["POST"])
def api_export_dta(key):
    """Trigger Databricks job to export DTA configuration"""
    # Call API to create export job
    result = api.create_export_job(key)
    
    if result["success"]:
        job_data = result["data"]
        return jsonify({
            "success": True, 
            "job_id": job_data["job_id"],
            "run_id": job_data["run_id"],
            "msg": result.get("message", "Export job triggered successfully")
        })
    else:
        return jsonify({"success": False, "msg": result.get("error", "Export failed")}), 400

@app.route("/api/workspace/<path:key>/publish-major", methods=["POST"])
def api_publish_major(key):
    """Publish approved DTA as a new major version"""
    # Call API to publish major version
    result = api.publish_major_version(key)
    
    if result["success"]:
        version_data = result["data"]
        return jsonify({
            "success": True,
            "msg": result.get("message", "DTA published"),
            "new_major_version": version_data["new_major_version"],
            "published_at": version_data["published_at"]
        })
    else:
        return jsonify({"success": False, "msg": result.get("error", "Publish failed")}), 400

# === Start the Flask app ===

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

"""
SCD Type 2 Versioning Framework for Clinical Data Standards

This module provides generic versioning utilities for metadata library tables,
supporting 3-level versioning:
- Library Major (1.0, 2.0) - Production canonical data
- DTA Major (1.0-DTA_A-v1.0) - Approved DTA version  
- DTA Draft (1.0-DTA_A-draft1) - Work in progress

Integrates with DTA workflow system for approval tracking.
"""

import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, TimestampType, 
    IntegerType, BooleanType
)


# ============================================================================
# Schema Definitions
# ============================================================================

def get_version_registry_schema() -> StructType:
    """
    Get the schema for md_version_registry table.
    
    Central registry tracking all library versions across all library types.
    
    Returns:
        StructType schema for version registry table
    """
    return StructType([
        StructField("version_tag", StringType(), False),           # PK: "1.0", "1.0-DTA_A-draft1"
        StructField("library_type", StringType(), False),          # "transfer_variables", "codelist"
        StructField("version_type", StringType(), False),          # LIBRARY_MAJOR, DTA_MAJOR, DTA_DRAFT
        StructField("dta_id", StringType(), True),                 # NULL for library major, DTA ID for branches
        StructField("parent_version", StringType(), True),         # What version this branched from
        StructField("record_count", IntegerType(), True),          # Number of records in this version
        StructField("status", StringType(), False),                # ACTIVE, SUPERSEDED, ARCHIVED
        # Audit columns
        StructField("created_by_principal", StringType(), True),
        StructField("created_ts", TimestampType(), True),
        StructField("last_updated_by_principal", StringType(), True),
        StructField("last_updated_ts", TimestampType(), True),
        StructField("databricks_job_id", StringType(), True),
        StructField("databricks_job_name", StringType(), True),
        StructField("databricks_run_id", StringType(), True)
    ])


def get_versioning_columns() -> List[StructField]:
    """
    Get the versioning columns to add to any library table.
    
    These columns enable SCD Type 2 versioning on any table.
    
    Returns:
        List of StructFields for versioning columns
    """
    return [
        StructField("library_version", StringType(), False),       # Version tag
        StructField("is_major_version", BooleanType(), False),     # TRUE for 1.0, 2.0
        StructField("is_dta_major", BooleanType(), False),         # TRUE for 1.0-DTA_A-v1.0
        StructField("parent_version", StringType(), True),         # What version this branched from
        StructField("effective_start_ts", TimestampType(), False), # SCD Type 2 start
        StructField("effective_end_ts", TimestampType(), True),    # SCD Type 2 end (NULL if current)
        StructField("is_current", BooleanType(), False)            # Active version flag
    ]


# ============================================================================
# Version Tag Utilities
# ============================================================================

def parse_version_tag(version_tag: str) -> Dict[str, Any]:
    """
    Parse a version tag into its components.
    
    Format: {library_major}-{dta_id}-{version_type}{version_number}
    
    Examples:
        - "1.0" → {"library_major": "1.0", "dta_id": None, "version_type": "LIBRARY_MAJOR", "version_number": None}
        - "1.0-DTA_A-draft1" → {"library_major": "1.0", "dta_id": "DTA_A", "version_type": "DTA_DRAFT", "version_number": 1}
        - "1.0-DTA_A-v1.0" → {"library_major": "1.0", "dta_id": "DTA_A", "version_type": "DTA_MAJOR", "version_number": "1.0"}
    
    Args:
        version_tag: Version tag string
        
    Returns:
        Dictionary with parsed components
    """
    parts = version_tag.split("-")
    
    if len(parts) == 1:
        # Library major: "1.0"
        return {
            "library_major": parts[0],
            "dta_id": None,
            "version_type": "LIBRARY_MAJOR",
            "version_number": None
        }
    elif len(parts) >= 3:
        # DTA version: "1.0-DTA_A-draft1" or "1.0-DTA_A-v1.0"
        library_major = parts[0]
        dta_id = parts[1]
        version_part = "-".join(parts[2:])  # Handle cases like "v1.0"
        
        if version_part.startswith("draft"):
            version_type = "DTA_DRAFT"
            version_number = int(version_part.replace("draft", ""))
        elif version_part.startswith("v"):
            version_type = "DTA_MAJOR"
            version_number = version_part[1:]  # Remove 'v' prefix
        else:
            version_type = "UNKNOWN"
            version_number = version_part
            
        return {
            "library_major": library_major,
            "dta_id": dta_id,
            "version_type": version_type,
            "version_number": version_number
        }
    else:
        raise ValueError(f"Invalid version tag format: {version_tag}")


def build_version_tag(
    library_major: str,
    dta_number: Optional[str] = None,
    version_type: str = "LIBRARY_MAJOR",
    version_number: Optional[Any] = None
) -> str:
    """
    Build a version tag from components.
    
    Args:
        library_major: Library major version (e.g., "1.0")
        dta_number: Sequential DTA number (e.g., "DTA001", None for library major)
        version_type: LIBRARY_MAJOR, DTA_MAJOR, or DTA_DRAFT
        version_number: Version number (draft number or major version)
        
    Returns:
        Formatted version tag string
        
    Examples:
        - Library Major: "1.0"
        - DTA Draft: "1.0-DTA001-draft1"
        - DTA Major: "1.0-DTA001-v1.0"
    """
    if version_type == "LIBRARY_MAJOR":
        return library_major
    elif version_type == "DTA_DRAFT":
        return f"{library_major}-{dta_number}-draft{version_number}"
    elif version_type == "DTA_MAJOR":
        return f"{library_major}-{dta_number}-v{version_number}"
    else:
        raise ValueError(f"Unknown version type: {version_type}")


def get_dta_number(
    spark: SparkSession,
    dta_table: str,
    dta_id: str
) -> str:
    """
    Look up the sequential DTA number from the DTA table.
    
    Args:
        spark: SparkSession
        dta_table: Full name of DTA table
        dta_id: DTA UUID identifier
        
    Returns:
        Sequential DTA number (e.g., "DTA001")
        
    Raises:
        ValueError: If DTA not found
    """
    result = spark.sql(f"""
        SELECT dta_number FROM {dta_table}
        WHERE dta_id = '{dta_id}'
    """).first()
    
    if not result or not result.dta_number:
        raise ValueError(f"DTA not found or has no dta_number: {dta_id}")
    
    return result.dta_number


def get_next_draft_number(
    spark: SparkSession,
    registry_table: str,
    dta_number: str,
    library_major: str
) -> int:
    """
    Get the next draft number for a DTA.
    
    Args:
        spark: SparkSession
        registry_table: Full name of version registry table
        dta_number: Sequential DTA number (e.g., "DTA001")
        library_major: Library major version
        
    Returns:
        Next draft number (1 if no existing drafts)
    """
    try:
        result = spark.sql(f"""
            SELECT MAX(
                CAST(REGEXP_EXTRACT(version_tag, 'draft([0-9]+)', 1) AS INT)
            ) as max_draft
            FROM {registry_table}
            WHERE version_tag LIKE '{library_major}-{dta_number}-draft%'
        """).first()
        
        max_draft = result.max_draft if result and result.max_draft else 0
        return max_draft + 1
    except Exception:
        return 1


def get_next_dta_major_version(
    spark: SparkSession,
    registry_table: str,
    dta_number: str,
    library_major: str
) -> str:
    """
    Get the next DTA major version number for a DTA.
    
    Args:
        spark: SparkSession
        registry_table: Full name of version registry table
        dta_number: Sequential DTA number (e.g., "DTA001")
        library_major: Library major version
        
    Returns:
        Next DTA major version (e.g., "1.0", "2.0")
    """
    try:
        result = spark.sql(f"""
            SELECT MAX(
                CAST(REGEXP_EXTRACT(version_tag, 'v([0-9]+)\\.0', 1) AS INT)
            ) as max_major
            FROM {registry_table}
            WHERE version_tag LIKE '{library_major}-{dta_number}-v%'
        """).first()
        
        max_major = result.max_major if result and result.max_major else 0
        return f"{max_major + 1}.0"
    except Exception:
        return "1.0"


def get_next_library_major_version(
    spark: SparkSession,
    registry_table: str
) -> str:
    """
    Get the next library major version number.
    
    Args:
        spark: SparkSession
        registry_table: Full name of version registry table
        
    Returns:
        Next library major version (e.g., "2.0", "3.0")
    """
    try:
        result = spark.sql(f"""
            SELECT MAX(
                CAST(REGEXP_EXTRACT(version_tag, '^([0-9]+)\\.0$', 1) AS INT)
            ) as max_major
            FROM {registry_table}
            WHERE version_type = 'LIBRARY_MAJOR'
        """).first()
        
        max_major = result.max_major if result and result.max_major else 0
        return f"{max_major + 1}.0"
    except Exception:
        return "1.0"


# ============================================================================
# Core Versioning Operations
# ============================================================================

def create_library_branch(
    spark: SparkSession,
    library_table: str,
    registry_table: str,
    dta_table: str,
    dta_id: str,
    base_version: str,
    library_type: str,
    created_by_principal: str,
    databricks_job_id: Optional[str] = None,
    databricks_job_name: Optional[str] = None,
    databricks_run_id: Optional[str] = None
) -> str:
    """
    Create a new DTA branch from a library major version.
    
    Copies all records from the base version with a new version tag.
    
    Args:
        spark: SparkSession
        library_table: Full name of library table (e.g., catalog.schema.md_transfer_variables_library)
        registry_table: Full name of version registry table
        dta_table: Full name of DTA table (for looking up dta_number)
        dta_id: DTA identifier (UUID)
        base_version: Library major version to branch from (e.g., "1.0")
        library_type: Type of library (e.g., "transfer_variables")
        created_by_principal: User creating the branch
        databricks_job_id: Job ID for lineage
        databricks_job_name: Job name for lineage
        databricks_run_id: Run ID for lineage
        
    Returns:
        New version tag (e.g., "1.0-DTA001-draft1")
    """
    # Look up dta_number from DTA table
    dta_number = get_dta_number(spark, dta_table, dta_id)
    
    # Get next draft number
    draft_number = get_next_draft_number(spark, registry_table, dta_number, base_version)
    new_version_tag = build_version_tag(base_version, dta_number, "DTA_DRAFT", draft_number)
    
    now = datetime.now()
    
    # Copy records from base version with new version tag
    spark.sql(f"""
        INSERT INTO {library_table}
        SELECT 
            -- All existing columns except versioning columns
            * EXCEPT (library_version, is_major_version, is_dta_major, parent_version, 
                      effective_start_ts, effective_end_ts, is_current,
                      created_by_principal, created_ts, last_updated_by_principal, last_updated_ts,
                      databricks_job_id, databricks_job_name, databricks_run_id),
            -- New versioning columns
            '{new_version_tag}' as library_version,
            false as is_major_version,
            false as is_dta_major,
            '{base_version}' as parent_version,
            current_timestamp() as effective_start_ts,
            NULL as effective_end_ts,
            true as is_current,
            -- Audit columns
            '{created_by_principal}' as created_by_principal,
            current_timestamp() as created_ts,
            '{created_by_principal}' as last_updated_by_principal,
            current_timestamp() as last_updated_ts,
            '{databricks_job_id or ""}' as databricks_job_id,
            '{databricks_job_name or ""}' as databricks_job_name,
            '{databricks_run_id or ""}' as databricks_run_id
        FROM {library_table}
        WHERE library_version = '{base_version}' AND is_current = true
    """)
    
    # Get record count
    record_count = spark.sql(f"""
        SELECT COUNT(*) as cnt FROM {library_table} 
        WHERE library_version = '{new_version_tag}'
    """).first().cnt
    
    # Register new version
    registry_record = [{
        "version_tag": new_version_tag,
        "library_type": library_type,
        "version_type": "DTA_DRAFT",
        "dta_id": dta_id,
        "parent_version": base_version,
        "record_count": record_count,
        "status": "ACTIVE",
        "created_by_principal": created_by_principal,
        "created_ts": now,
        "last_updated_by_principal": created_by_principal,
        "last_updated_ts": now,
        "databricks_job_id": databricks_job_id,
        "databricks_job_name": databricks_job_name,
        "databricks_run_id": databricks_run_id
    }]
    
    registry_df = spark.createDataFrame(registry_record, schema=get_version_registry_schema())
    registry_df.write.format("delta").mode("append").saveAsTable(registry_table)
    
    print(f"✓ Created branch: {new_version_tag} from {base_version} ({record_count} records)")
    return new_version_tag


def save_dta_draft(
    spark: SparkSession,
    library_table: str,
    registry_table: str,
    dta_table: str,
    dta_id: str,
    changes_df: DataFrame,
    library_type: str,
    created_by_principal: str,
    databricks_job_id: Optional[str] = None,
    databricks_job_name: Optional[str] = None,
    databricks_run_id: Optional[str] = None
) -> str:
    """
    Save a new DTA draft version using SCD Type 2.
    
    Closes the current draft and creates a new one with the changes.
    
    Args:
        spark: SparkSession
        library_table: Full name of library table
        registry_table: Full name of version registry table
        dta_table: Full name of DTA table (for looking up dta_number)
        dta_id: DTA identifier (UUID)
        changes_df: DataFrame with updated records (should include all records, not just changed ones)
        library_type: Type of library
        created_by_principal: User saving the draft
        databricks_job_id: Job ID for lineage
        databricks_job_name: Job name for lineage
        databricks_run_id: Run ID for lineage
        
    Returns:
        New version tag (e.g., "1.0-DTA001-draft2")
    """
    now = datetime.now()
    
    # Look up dta_number from DTA table
    dta_number = get_dta_number(spark, dta_table, dta_id)
    
    # Get current active version for this DTA
    current_version_row = spark.sql(f"""
        SELECT version_tag, parent_version 
        FROM {registry_table}
        WHERE dta_id = '{dta_id}' AND status = 'ACTIVE'
        ORDER BY created_ts DESC
        LIMIT 1
    """).first()
    
    if not current_version_row:
        raise ValueError(f"No active version found for DTA: {dta_id}")
    
    current_version = current_version_row.version_tag
    parsed = parse_version_tag(current_version)
    library_major = parsed["library_major"]
    
    # Get next draft number
    next_draft = get_next_draft_number(spark, registry_table, dta_number, library_major)
    new_version_tag = build_version_tag(library_major, dta_number, "DTA_DRAFT", next_draft)
    
    # Step 1: Close current version records (SCD Type 2)
    spark.sql(f"""
        UPDATE {library_table}
        SET 
            effective_end_ts = current_timestamp(),
            is_current = false,
            last_updated_by_principal = '{created_by_principal}',
            last_updated_ts = current_timestamp()
        WHERE library_version = '{current_version}' AND is_current = true
    """)
    
    # Step 2: Insert new version records
    # Add versioning columns to changes_df
    changes_with_version = changes_df \
        .withColumn("library_version", F.lit(new_version_tag)) \
        .withColumn("is_major_version", F.lit(False)) \
        .withColumn("is_dta_major", F.lit(False)) \
        .withColumn("parent_version", F.lit(current_version)) \
        .withColumn("effective_start_ts", F.current_timestamp()) \
        .withColumn("effective_end_ts", F.lit(None).cast(TimestampType())) \
        .withColumn("is_current", F.lit(True)) \
        .withColumn("created_by_principal", F.lit(created_by_principal)) \
        .withColumn("created_ts", F.current_timestamp()) \
        .withColumn("last_updated_by_principal", F.lit(created_by_principal)) \
        .withColumn("last_updated_ts", F.current_timestamp()) \
        .withColumn("databricks_job_id", F.lit(databricks_job_id)) \
        .withColumn("databricks_job_name", F.lit(databricks_job_name)) \
        .withColumn("databricks_run_id", F.lit(databricks_run_id))
    
    changes_with_version.write.format("delta").mode("append").saveAsTable(library_table)
    
    record_count = changes_with_version.count()
    
    # Step 3: Update registry - mark old version as SUPERSEDED
    spark.sql(f"""
        UPDATE {registry_table}
        SET 
            status = 'SUPERSEDED',
            last_updated_by_principal = '{created_by_principal}',
            last_updated_ts = current_timestamp()
        WHERE version_tag = '{current_version}'
    """)
    
    # Step 4: Register new version
    registry_record = [{
        "version_tag": new_version_tag,
        "library_type": library_type,
        "version_type": "DTA_DRAFT",
        "dta_id": dta_id,
        "parent_version": current_version,
        "record_count": record_count,
        "status": "ACTIVE",
        "created_by_principal": created_by_principal,
        "created_ts": now,
        "last_updated_by_principal": created_by_principal,
        "last_updated_ts": now,
        "databricks_job_id": databricks_job_id,
        "databricks_job_name": databricks_job_name,
        "databricks_run_id": databricks_run_id
    }]
    
    registry_df = spark.createDataFrame(registry_record, schema=get_version_registry_schema())
    registry_df.write.format("delta").mode("append").saveAsTable(registry_table)
    
    print(f"✓ Saved draft: {new_version_tag} ({record_count} records)")
    print(f"  Previous version {current_version} closed (SCD Type 2)")
    return new_version_tag


def approve_dta_version(
    spark: SparkSession,
    library_table: str,
    registry_table: str,
    dta_table: str,
    dta_id: str,
    library_type: str,
    created_by_principal: str,
    databricks_job_id: Optional[str] = None,
    databricks_job_name: Optional[str] = None,
    databricks_run_id: Optional[str] = None
) -> str:
    """
    Promote current DTA draft to DTA major version.
    
    Called when workflow is approved. Creates a DTA major version from the current draft.
    
    Args:
        spark: SparkSession
        library_table: Full name of library table
        registry_table: Full name of version registry table
        dta_table: Full name of DTA table (for looking up dta_number)
        dta_id: DTA identifier (UUID)
        library_type: Type of library
        created_by_principal: User approving
        databricks_job_id: Job ID for lineage
        databricks_job_name: Job name for lineage
        databricks_run_id: Run ID for lineage
        
    Returns:
        New DTA major version tag (e.g., "1.0-DTA001-v1.0")
    """
    now = datetime.now()
    
    # Look up dta_number from DTA table
    dta_number = get_dta_number(spark, dta_table, dta_id)
    
    # Get current active draft
    current_version_row = spark.sql(f"""
        SELECT version_tag 
        FROM {registry_table}
        WHERE dta_id = '{dta_id}' AND status = 'ACTIVE' AND version_type = 'DTA_DRAFT'
        ORDER BY created_ts DESC
        LIMIT 1
    """).first()
    
    if not current_version_row:
        raise ValueError(f"No active draft found for DTA: {dta_id}")
    
    current_draft = current_version_row.version_tag
    parsed = parse_version_tag(current_draft)
    library_major = parsed["library_major"]
    
    # Get next DTA major version
    next_major = get_next_dta_major_version(spark, registry_table, dta_number, library_major)
    new_version_tag = build_version_tag(library_major, dta_number, "DTA_MAJOR", next_major)
    
    # Step 1: Copy current draft records as DTA major version
    spark.sql(f"""
        INSERT INTO {library_table}
        SELECT 
            * EXCEPT (library_version, is_major_version, is_dta_major, parent_version,
                      effective_start_ts, effective_end_ts, is_current,
                      created_by_principal, created_ts, last_updated_by_principal, last_updated_ts,
                      databricks_job_id, databricks_job_name, databricks_run_id),
            '{new_version_tag}' as library_version,
            false as is_major_version,
            true as is_dta_major,
            '{current_draft}' as parent_version,
            current_timestamp() as effective_start_ts,
            NULL as effective_end_ts,
            true as is_current,
            '{created_by_principal}' as created_by_principal,
            current_timestamp() as created_ts,
            '{created_by_principal}' as last_updated_by_principal,
            current_timestamp() as last_updated_ts,
            '{databricks_job_id or ""}' as databricks_job_id,
            '{databricks_job_name or ""}' as databricks_job_name,
            '{databricks_run_id or ""}' as databricks_run_id
        FROM {library_table}
        WHERE library_version = '{current_draft}' AND is_current = true
    """)
    
    # Get record count
    record_count = spark.sql(f"""
        SELECT COUNT(*) as cnt FROM {library_table} 
        WHERE library_version = '{new_version_tag}'
    """).first().cnt
    
    # Step 2: Close draft records (SCD Type 2)
    spark.sql(f"""
        UPDATE {library_table}
        SET 
            effective_end_ts = current_timestamp(),
            is_current = false,
            last_updated_by_principal = '{created_by_principal}',
            last_updated_ts = current_timestamp()
        WHERE library_version = '{current_draft}' AND is_current = true
    """)
    
    # Step 3: Update registry
    spark.sql(f"""
        UPDATE {registry_table}
        SET 
            status = 'SUPERSEDED',
            last_updated_by_principal = '{created_by_principal}',
            last_updated_ts = current_timestamp()
        WHERE version_tag = '{current_draft}'
    """)
    
    # Step 4: Register new DTA major version
    registry_record = [{
        "version_tag": new_version_tag,
        "library_type": library_type,
        "version_type": "DTA_MAJOR",
        "dta_id": dta_id,
        "parent_version": current_draft,
        "record_count": record_count,
        "status": "ACTIVE",
        "created_by_principal": created_by_principal,
        "created_ts": now,
        "last_updated_by_principal": created_by_principal,
        "last_updated_ts": now,
        "databricks_job_id": databricks_job_id,
        "databricks_job_name": databricks_job_name,
        "databricks_run_id": databricks_run_id
    }]
    
    registry_df = spark.createDataFrame(registry_record, schema=get_version_registry_schema())
    registry_df.write.format("delta").mode("append").saveAsTable(registry_table)
    
    print(f"✓ Approved DTA version: {new_version_tag} ({record_count} records)")
    print(f"  Previous draft {current_draft} closed")
    return new_version_tag


def promote_to_library_major(
    spark: SparkSession,
    library_table: str,
    registry_table: str,
    dta_id: str,
    dta_version: str,
    library_type: str,
    created_by_principal: str,
    databricks_job_id: Optional[str] = None,
    databricks_job_name: Optional[str] = None,
    databricks_run_id: Optional[str] = None
) -> str:
    """
    Promote a DTA major version to library major version.
    
    Creates a new library major version from the DTA major version.
    Uses SCD Type 2 to close the previous library major version.
    
    Args:
        spark: SparkSession
        library_table: Full name of library table
        registry_table: Full name of version registry table
        dta_id: DTA identifier
        dta_version: DTA major version to promote (e.g., "1.0-DTA_A-v1.0")
        library_type: Type of library
        created_by_principal: User promoting
        databricks_job_id: Job ID for lineage
        databricks_job_name: Job name for lineage
        databricks_run_id: Run ID for lineage
        
    Returns:
        New library major version tag (e.g., "2.0")
    """
    now = datetime.now()
    
    # Get next library major version
    new_version_tag = get_next_library_major_version(spark, registry_table)
    
    # Step 1: Close current library major version (SCD Type 2)
    spark.sql(f"""
        UPDATE {library_table}
        SET 
            effective_end_ts = current_timestamp(),
            is_current = false,
            last_updated_by_principal = '{created_by_principal}',
            last_updated_ts = current_timestamp()
        WHERE is_major_version = true AND is_current = true
    """)
    
    # Step 2: Copy DTA version records as new library major
    spark.sql(f"""
        INSERT INTO {library_table}
        SELECT 
            * EXCEPT (library_version, is_major_version, is_dta_major, parent_version,
                      effective_start_ts, effective_end_ts, is_current,
                      created_by_principal, created_ts, last_updated_by_principal, last_updated_ts,
                      databricks_job_id, databricks_job_name, databricks_run_id),
            '{new_version_tag}' as library_version,
            true as is_major_version,
            false as is_dta_major,
            '{dta_version}' as parent_version,
            current_timestamp() as effective_start_ts,
            NULL as effective_end_ts,
            true as is_current,
            '{created_by_principal}' as created_by_principal,
            current_timestamp() as created_ts,
            '{created_by_principal}' as last_updated_by_principal,
            current_timestamp() as last_updated_ts,
            '{databricks_job_id or ""}' as databricks_job_id,
            '{databricks_job_name or ""}' as databricks_job_name,
            '{databricks_run_id or ""}' as databricks_run_id
        FROM {library_table}
        WHERE library_version = '{dta_version}'
    """)
    
    # Get record count
    record_count = spark.sql(f"""
        SELECT COUNT(*) as cnt FROM {library_table} 
        WHERE library_version = '{new_version_tag}'
    """).first().cnt
    
    # Step 3: Update registry - mark old library major as SUPERSEDED
    spark.sql(f"""
        UPDATE {registry_table}
        SET 
            status = 'SUPERSEDED',
            last_updated_by_principal = '{created_by_principal}',
            last_updated_ts = current_timestamp()
        WHERE version_type = 'LIBRARY_MAJOR' AND status = 'ACTIVE'
    """)
    
    # Step 4: Register new library major version
    registry_record = [{
        "version_tag": new_version_tag,
        "library_type": library_type,
        "version_type": "LIBRARY_MAJOR",
        "dta_id": None,
        "parent_version": dta_version,
        "record_count": record_count,
        "status": "ACTIVE",
        "created_by_principal": created_by_principal,
        "created_ts": now,
        "last_updated_by_principal": created_by_principal,
        "last_updated_ts": now,
        "databricks_job_id": databricks_job_id,
        "databricks_job_name": databricks_job_name,
        "databricks_run_id": databricks_run_id
    }]
    
    registry_df = spark.createDataFrame(registry_record, schema=get_version_registry_schema())
    registry_df.write.format("delta").mode("append").saveAsTable(registry_table)
    
    print(f"✓ Promoted to library major: {new_version_tag} ({record_count} records)")
    print(f"  Source: {dta_version}")
    return new_version_tag


def merge_dtas_to_library_major(
    spark: SparkSession,
    library_table: str,
    registry_table: str,
    dta_versions: list,
    library_type: str,
    merge_strategy: str = "UNION_DEDUP",
    created_by_principal: str = None,
    databricks_job_id: Optional[str] = None,
    databricks_job_name: Optional[str] = None,
    databricks_run_id: Optional[str] = None
) -> str:
    """
    Merge multiple DTA major versions into a new library major version.
    
    This is used when a Librarian wants to combine variable definitions from
    multiple approved DTAs into a single canonical library version.
    
    Args:
        spark: SparkSession
        library_table: Full name of library table
        registry_table: Full name of version registry table
        dta_versions: List of DTA major version tags to merge
                      e.g., ["1.0-DTA001-v1.0", "1.0-DTA002-v1.0"]
        library_type: Type of library
        merge_strategy: How to handle duplicates:
            - "UNION_DEDUP": Keep unique records by definition_hash (default)
            - "LATEST_WINS": For same definition_hash, keep from latest DTA version
            - "FIRST_WINS": For same definition_hash, keep from first DTA version
        created_by_principal: User performing the merge
        databricks_job_id: Job ID for lineage
        databricks_job_name: Job name for lineage
        databricks_run_id: Run ID for lineage
        
    Returns:
        New library major version tag (e.g., "2.0")
    """
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window
    
    now = datetime.now()
    
    if not dta_versions or len(dta_versions) == 0:
        raise ValueError("At least one DTA version is required")
    
    print(f"Merging {len(dta_versions)} DTA versions:")
    for v in dta_versions:
        print(f"  - {v}")
    print(f"Strategy: {merge_strategy}")
    
    # Get next library major version
    new_version_tag = get_next_library_major_version(spark, registry_table)
    
    # Step 1: Read all DTA versions and union them
    dta_versions_sql = "', '".join(dta_versions)
    df_all_dtas = spark.sql(f"""
        SELECT * FROM {library_table}
        WHERE library_version IN ('{dta_versions_sql}')
    """)
    
    total_records = df_all_dtas.count()
    print(f"Total records from all DTAs: {total_records}")
    
    # Step 2: Apply merge strategy to handle duplicates
    if merge_strategy == "UNION_DEDUP":
        # Keep unique records by definition_hash (arbitrary pick for duplicates)
        df_merged = df_all_dtas.dropDuplicates(["definition_hash"])
        
    elif merge_strategy == "LATEST_WINS":
        # For same definition_hash, keep the one from latest DTA version
        window = Window.partitionBy("definition_hash").orderBy(F.col("effective_start_ts").desc())
        df_merged = df_all_dtas.withColumn("_rank", F.row_number().over(window)) \
            .filter(F.col("_rank") == 1) \
            .drop("_rank")
            
    elif merge_strategy == "FIRST_WINS":
        # For same definition_hash, keep the one from first DTA version
        window = Window.partitionBy("definition_hash").orderBy(F.col("effective_start_ts").asc())
        df_merged = df_all_dtas.withColumn("_rank", F.row_number().over(window)) \
            .filter(F.col("_rank") == 1) \
            .drop("_rank")
    else:
        raise ValueError(f"Unknown merge_strategy: {merge_strategy}. Use UNION_DEDUP, LATEST_WINS, or FIRST_WINS")
    
    merged_count = df_merged.count()
    print(f"Records after dedup: {merged_count}")
    
    # Step 3: Close current library major version (SCD Type 2)
    # Note: Only update columns that exist in the library table
    spark.sql(f"""
        UPDATE {library_table}
        SET 
            effective_end_ts = current_timestamp(),
            is_current = false
        WHERE is_major_version = true AND is_current = true AND is_dta_major = false
    """)
    
    # Step 4: Create new library major records
    parent_versions_str = ",".join(dta_versions)
    
    # Select only business columns that exist in the dataframe
    # (avoid hardcoding columns that might not exist)
    business_columns = [
        "definition_hash",
        "transfer_variable_name",
        "transfer_variable_label",
        "format",
        "anticipated_max_length",
        "transfer_file_key",
        "populate_for_all_records",
        "codelist_values",
        "variable_description",
        "example_values",
        "row_status"
    ]
    
    # Only select columns that actually exist in the merged dataframe
    existing_cols = df_merged.columns
    cols_to_select = [c for c in business_columns if c in existing_cols]
    
    df_new_library = df_merged.select(
        *[F.col(c) for c in cols_to_select]
    ).withColumn("dta_id", F.lit(None).cast("string")
    ).withColumn("version_tag", F.lit(None).cast("string")
    ).withColumn("library_version", F.lit(new_version_tag)
    ).withColumn("is_major_version", F.lit(True)
    ).withColumn("is_dta_major", F.lit(False)
    ).withColumn("parent_version", F.lit(parent_versions_str)
    ).withColumn("effective_start_ts", F.lit(now)
    ).withColumn("effective_end_ts", F.lit(None).cast("timestamp")
    ).withColumn("is_current", F.lit(True)
    )
    
    df_new_library.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(library_table)
    
    # Step 5: Update registry - mark old library major as SUPERSEDED
    # Note: Only update columns that exist in the registry table
    spark.sql(f"""
        UPDATE {registry_table}
        SET 
            status = 'SUPERSEDED'
        WHERE version_type = 'LIBRARY_MAJOR' AND status = 'ACTIVE'
    """)
    
    # Step 6: Register new library major version
    registry_record = [{
        "version_tag": new_version_tag,
        "library_type": library_type,
        "version_type": "LIBRARY_MAJOR",
        "dta_id": None,
        "parent_version": parent_versions_str,
        "record_count": merged_count,
        "status": "ACTIVE",
        "created_by_principal": created_by_principal,
        "created_ts": now,
        "last_updated_by_principal": created_by_principal,
        "last_updated_ts": now,
        "databricks_job_id": databricks_job_id,
        "databricks_job_name": databricks_job_name,
        "databricks_run_id": databricks_run_id
    }]
    
    print(f"  Merge info: {len(dta_versions)} DTA(s) using {merge_strategy}")
    
    # Debug: Print registry info
    print(f"  DEBUG: Writing to registry table: {registry_table}")
    print(f"  DEBUG: Registry record: {registry_record}")
    
    try:
        registry_df = spark.createDataFrame(registry_record, schema=get_version_registry_schema())
        print(f"  DEBUG: Registry DataFrame count: {registry_df.count()}")
        registry_df.show(truncate=False)
        
        registry_df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(registry_table)
        print(f"  DEBUG: Write completed successfully")
    except Exception as e:
        print(f"  ERROR: Failed to write to registry: {str(e)}")
        raise e
    
    print(f"✓ Merged to library major: {new_version_tag} ({merged_count} records)")
    print(f"  Sources: {dta_versions}")
    print(f"  Strategy: {merge_strategy}")
    return new_version_tag


# ============================================================================
# Query Utilities
# ============================================================================

def get_version_data(
    spark: SparkSession,
    library_table: str,
    version_tag: str
) -> DataFrame:
    """
    Get data for a specific version.
    
    Args:
        spark: SparkSession
        library_table: Full name of library table
        version_tag: Version to retrieve
        
    Returns:
        DataFrame with version data
    """
    return spark.sql(f"""
        SELECT * FROM {library_table}
        WHERE library_version = '{version_tag}'
    """)


def get_current_library_version(
    spark: SparkSession,
    library_table: str
) -> DataFrame:
    """
    Get the current library major version (production).
    
    Args:
        spark: SparkSession
        library_table: Full name of library table
        
    Returns:
        DataFrame with current production data
    """
    return spark.sql(f"""
        SELECT * FROM {library_table}
        WHERE is_major_version = true AND is_current = true
    """)


def get_dta_current_version(
    spark: SparkSession,
    library_table: str,
    registry_table: str,
    dta_id: str
) -> DataFrame:
    """
    Get the current working version for a DTA.
    
    Args:
        spark: SparkSession
        library_table: Full name of library table
        registry_table: Full name of version registry table
        dta_id: DTA identifier
        
    Returns:
        DataFrame with DTA's current working data
    """
    return spark.sql(f"""
        SELECT l.* 
        FROM {library_table} l
        JOIN {registry_table} v ON l.library_version = v.version_tag
        WHERE v.dta_id = '{dta_id}' 
          AND v.status = 'ACTIVE'
          AND l.is_current = true
    """)


def get_dta_version_history(
    spark: SparkSession,
    registry_table: str,
    dta_id: str
) -> DataFrame:
    """
    Get version history for a DTA.
    
    Args:
        spark: SparkSession
        registry_table: Full name of version registry table
        dta_id: DTA identifier
        
    Returns:
        DataFrame with version history
    """
    return spark.sql(f"""
        SELECT * FROM {registry_table}
        WHERE dta_id = '{dta_id}'
        ORDER BY created_ts DESC
    """)


def get_all_versions(
    spark: SparkSession,
    registry_table: str,
    library_type: Optional[str] = None
) -> DataFrame:
    """
    Get all versions from the registry.
    
    Args:
        spark: SparkSession
        registry_table: Full name of version registry table
        library_type: Optional filter by library type
        
    Returns:
        DataFrame with all versions
    """
    query = f"SELECT * FROM {registry_table}"
    if library_type:
        query += f" WHERE library_type = '{library_type}'"
    query += " ORDER BY created_ts DESC"
    
    return spark.sql(query)


# ============================================================================
# Initialization Utilities
# ============================================================================

def initialize_library_version(
    spark: SparkSession,
    library_table: str,
    registry_table: str,
    library_type: str,
    initial_version: str = "1.0",
    created_by_principal: str = "system",
    databricks_job_id: Optional[str] = None,
    databricks_job_name: Optional[str] = None,
    databricks_run_id: Optional[str] = None
) -> None:
    """
    Initialize versioning for a library table.
    
    Sets the initial library major version on existing records.
    Call this once when adding versioning to an existing table.
    
    Args:
        spark: SparkSession
        library_table: Full name of library table
        registry_table: Full name of version registry table
        library_type: Type of library
        initial_version: Initial version tag (default "1.0")
        created_by_principal: User initializing
        databricks_job_id: Job ID for lineage
        databricks_job_name: Job name for lineage
        databricks_run_id: Run ID for lineage
    """
    now = datetime.now()
    
    # Check if already initialized
    existing = spark.sql(f"""
        SELECT COUNT(*) as cnt FROM {registry_table}
        WHERE library_type = '{library_type}' AND version_type = 'LIBRARY_MAJOR'
    """).first().cnt
    
    if existing > 0:
        print(f"Library {library_type} already has version history. Skipping initialization.")
        return
    
    # Update existing records with version info
    spark.sql(f"""
        UPDATE {library_table}
        SET 
            library_version = '{initial_version}',
            is_major_version = true,
            is_dta_major = false,
            parent_version = NULL,
            effective_start_ts = COALESCE(created_ts, current_timestamp()),
            effective_end_ts = NULL,
            is_current = true
        WHERE library_version IS NULL OR library_version = ''
    """)
    
    # Get record count
    record_count = spark.sql(f"""
        SELECT COUNT(*) as cnt FROM {library_table} 
        WHERE library_version = '{initial_version}'
    """).first().cnt
    
    # Register initial version
    registry_record = [{
        "version_tag": initial_version,
        "library_type": library_type,
        "version_type": "LIBRARY_MAJOR",
        "dta_id": None,
        "parent_version": None,
        "record_count": record_count,
        "status": "ACTIVE",
        "created_by_principal": created_by_principal,
        "created_ts": now,
        "last_updated_by_principal": created_by_principal,
        "last_updated_ts": now,
        "databricks_job_id": databricks_job_id,
        "databricks_job_name": databricks_job_name,
        "databricks_run_id": databricks_run_id
    }]
    
    registry_df = spark.createDataFrame(registry_record, schema=get_version_registry_schema())
    registry_df.write.format("delta").mode("append").saveAsTable(registry_table)
    
    print(f"✓ Initialized {library_type} with version {initial_version} ({record_count} records)")


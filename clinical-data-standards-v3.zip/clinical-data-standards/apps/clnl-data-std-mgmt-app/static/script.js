
async function saveDraft(key){
  const r = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/save`)
  alert(r.msg || 'Saved')
}
// Global variable to store selected approvers
let selectedApprovers = {
  jnj: null,
  vendor: null,
  librarian: null
};
let currentWorkspaceKey = null;

async function submitApproval(key){
  currentWorkspaceKey = key;
  // Show the modal
  document.getElementById('approver-modal').style.display = 'flex';
  
  // Load approvers
  try {
    const response = await fetch('/api/approvers');
    const data = await response.json();
    
    if (data.success) {
      renderApprovers('jnj-approvers', data.approvers.jnj_dae, 'jnj');
      renderApprovers('vendor-approvers', data.approvers.vendor, 'vendor');
      renderApprovers('librarian-approvers', data.approvers.librarian, 'librarian');
    }
  } catch (e) {
    console.error('Failed to load approvers:', e);
    alert('Failed to load approvers');
  }
}

function renderApprovers(containerId, approvers, role) {
  const container = document.getElementById(containerId);
  container.innerHTML = '';
  
  approvers.forEach(approver => {
    const div = document.createElement('div');
    div.className = 'approver-option';
    div.innerHTML = `
      <input type="radio" 
             id="approver-${role}-${approver.id}" 
             name="approver-${role}" 
             value="${approver.id}"
             onchange="selectApprover('${role}', '${approver.id}', '${approver.name}', '${approver.title}', '${approver.email}')">
      <label for="approver-${role}-${approver.id}">
        <div class="approver-name">${approver.name}</div>
        <div class="approver-details">
          <span class="approver-title">${approver.title}</span>
          <span class="approver-email">${approver.email}</span>
        </div>
      </label>
    `;
    container.appendChild(div);
  });
}

function selectApprover(role, id, name, title, email) {
  selectedApprovers[role] = { id, name, title, email };
  
  // Show checkmark
  document.getElementById(`${role}-check`).style.display = 'inline';
  
  // Check if all selections are made
  const allSelected = selectedApprovers.jnj && selectedApprovers.vendor && selectedApprovers.librarian;
  document.getElementById('submit-approval-btn').disabled = !allSelected;
}

function closeApproverModal() {
  document.getElementById('approver-modal').style.display = 'none';
  // Reset selections
  selectedApprovers = { jnj: null, vendor: null, librarian: null };
  document.querySelectorAll('.selection-check').forEach(el => el.style.display = 'none');
  document.getElementById('submit-approval-btn').disabled = true;
}

async function confirmApprovalSubmission() {
  if (!currentWorkspaceKey) return;
  
  const approvers = [
    { ...selectedApprovers.jnj, role: 'JNJ DAE', order: 1 },
    { ...selectedApprovers.vendor, role: 'Vendor', order: 2 },
    { ...selectedApprovers.librarian, role: 'Librarian', order: 3 }
  ];
  
  const r = await window.API.post(`/api/workspace/${encodeURIComponent(currentWorkspaceKey)}/submit`, { approvers });
  
  if (r.success) {
    closeApproverModal();
    window.location.href = '/dashboard';
  } else {
    alert(r.msg || 'Failed to submit');
  }
}
async function addComment(key){
  const text = document.getElementById('commentText').value
  if(!text.trim()) return
  const r = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/comment`, {text})
  if(r.ok){
    const list = document.getElementById('comments')
    const item = document.createElement('div')
    item.className = 'list-item'
    const ts = new Date().toLocaleString()
    item.innerHTML = `<div class="item-title">you@jnj.com <span class="muted small">• ${ts}</span></div><div>${text}</div>`
    list.prepend(item)
    document.getElementById('commentText').value = ''
  }
}
async function updateCell(key, tab, idx, col, value){
  await window.API.post(`/api/workspace/${encodeURIComponent(key)}/entity/${tab}/${idx}/${col}`, { value })
}


function toggleRowComment(idx){
  const row = document.getElementById(`comment-row-${idx}`)
  if(row) row.style.display = (row.style.display === 'none' ? '' : 'none')
}

async function tcEdit(key, idx){
  const r = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/${idx}/edit`)
  if(r.ok) location.reload()
}

async function tcSave(key, idx){
  const r = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/${idx}/save`)
  if(r.ok) location.reload()
}

async function tcCancel(key, idx){
  const r = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/${idx}/cancel`)
  if(r.ok) location.reload()
}

async function tcApprove(key, idx){
  await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/${idx}/approve`)
  location.reload()
}

async function tcPostComment(key, idx){
  const el = document.getElementById(`tc-comment-${idx}`)
  const text = (el && el.value || '').trim()
  if(!text) return
  const r = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/${idx}/comment`, { text })
  if(r.ok){
    const thread = document.getElementById(`tc-thread-${idx}`)
    const ts = new Date().toLocaleString()
    const div = document.createElement('div')
    div.className = 'comment-item'
    div.innerHTML = `<b>vendor@example.com</b> <span class="muted small">• ${ts}</span><div>${text}</div>`
    thread.prepend(div)
    el.value = ''
  }
}


// ===== TV (Transfer Variables) Functions =====

async function tvEdit(key, idx){
  console.log('tvEdit called:', key, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/edit`);
    console.log('tvEdit response:', response);
    if (response.ok) {
      location.reload();
    } else {
      console.error('tvEdit failed:', response);
      alert('Failed to edit row: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('tvEdit error:', e);
    alert('Error editing row: ' + e.message);
  }
}

async function tvSave(key, idx){
  console.log('tvSave called:', key, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/save`);
    console.log('tvSave response:', response);
    if (response.ok) {
      location.reload();
    } else {
      console.error('tvSave failed:', response);
      alert('Failed to save row: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('tvSave error:', e);
    alert('Error saving row: ' + e.message);
  }
}

async function tvCancel(key, idx){
  console.log('tvCancel called:', key, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/cancel`);
    console.log('tvCancel response:', response);
    if (response.ok) {
      location.reload();
    } else {
      console.error('tvCancel failed:', response);
      alert('Failed to cancel: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('tvCancel error:', e);
    alert('Error canceling: ' + e.message);
  }
}

async function tvApprove(key, idx){
  console.log('tvApprove called:', key, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/approve`);
    console.log('tvApprove response:', response);
    if (response.ok) {
      location.reload();
    } else {
      console.error('tvApprove failed:', response);
      alert('Failed to approve row: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('tvApprove error:', e);
    alert('Error approving row: ' + e.message);
  }
}

function toggleTvRowComment(idx){
  const row = document.getElementById(`tv-comment-row-${idx}`)
  if(!row) return
  if(row.style.display === 'none'){
    row.style.display = ''
  } else {
    row.style.display = 'none'
  }
}

async function tvPostComment(key, idx){
  const el = document.getElementById(`tv-comment-${idx}`)
  const text = (el && el.value || '').trim()
  if(!text) return
  const r = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/comment`, { text })
  if(r.ok){
    const thread = document.getElementById(`tv-thread-${idx}`)
    const ts = new Date().toLocaleString()
    const div = document.createElement('div')
    div.className = 'comment-item'
    div.innerHTML = `<b>vendor@example.com</b> <span class="muted small">• ${ts}</span><div>${text}</div>`
    thread.prepend(div)
    el.value = ''
  }
}

// ===== Add Row Functions =====

async function addTcRow(key){
  console.log('addTcRow called:', key);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/add`);
    console.log('addTcRow response:', response);
    if (response.ok) {
      location.reload();
    } else {
      console.error('addTcRow failed:', response);
      alert('Failed to add row: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('addTcRow error:', e);
    alert('Error adding row: ' + e.message);
  }
}

async function addTvRow(key){
  console.log('addTvRow called:', key);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tv/add`);
    console.log('addTvRow response:', response);
    if (response.ok) {
      location.reload();
    } else {
      console.error('addTvRow failed:', response);
      alert('Failed to add variable: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('addTvRow error:', e);
    alert('Error adding variable: ' + e.message);
  }
}


// ===== Code Lists (CL) Functions =====

function toggleClRowComment(ref, idx) {
  const commentRow = document.getElementById(`cl-comment-row-${ref}-${idx}`);
  if (commentRow) {
    commentRow.style.display = commentRow.style.display === 'none' ? 'block' : 'none';
  }
}

async function clEdit(key, ref, idx) {
  console.log('clEdit:', key, ref, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/cl/${encodeURIComponent(ref)}/${idx}/edit`, {});
    console.log('clEdit response:', response);
    if (response.ok) {
      location.reload();
    } else {
      alert('Failed to edit: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('clEdit error:', e);
    alert('Error editing: ' + e.message);
  }
}

async function clSave(key, ref, idx) {
  const codeInput = document.getElementById(`cl-code-${ref}-${idx}`);
  const textInput = document.getElementById(`cl-text-${ref}-${idx}`);
  
  if (!codeInput || !textInput) {
    alert('Could not find input fields');
    return;
  }
  
  const code = codeInput.value;
  const text = textInput.value;
  
  console.log('clSave:', key, ref, idx, code, text);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/cl/${encodeURIComponent(ref)}/${idx}/save`, {
      code: code,
      text: text
    });
    console.log('clSave response:', response);
    if (response.ok) {
      location.reload();
    } else {
      alert('Failed to save: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('clSave error:', e);
    alert('Error saving: ' + e.message);
  }
}

async function clCancel(key, ref, idx) {
  console.log('clCancel:', key, ref, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/cl/${encodeURIComponent(ref)}/${idx}/cancel`, {});
    console.log('clCancel response:', response);
    if (response.ok) {
      location.reload();
    } else {
      alert('Failed to cancel: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('clCancel error:', e);
    alert('Error canceling: ' + e.message);
  }
}

async function clApprove(key, ref, idx) {
  console.log('clApprove:', key, ref, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/cl/${encodeURIComponent(ref)}/${idx}/approve`, {});
    console.log('clApprove response:', response);
    if (response.ok) {
      location.reload();
    } else {
      alert('Failed to approve: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('clApprove error:', e);
    alert('Error approving: ' + e.message);
  }
}

async function clPostComment(key, ref, idx) {
  const input = document.getElementById(`cl-comment-${ref}-${idx}`);
  if (!input) return;
  
  const text = input.value.trim();
  if (!text) {
    alert('Please enter a comment');
    return;
  }
  
  console.log('clPostComment:', key, ref, idx, text);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/cl/${encodeURIComponent(ref)}/${idx}/comment`, {
      text: text
    });
    console.log('clPostComment response:', response);
    if (response.ok) {
      location.reload();
    } else {
      alert('Failed to post comment: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('clPostComment error:', e);
    alert('Error posting comment: ' + e.message);
  }
}

async function addClCode(key, ref) {
  console.log('addClCode:', key, ref);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/cl/${encodeURIComponent(ref)}/add`, {});
    console.log('addClCode response:', response);
    if (response.ok) {
      location.reload();
    } else {
      alert('Failed to add code: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('addClCode error:', e);
    alert('Error adding code: ' + e.message);
  }
}


// ===== Transfer File Keys Functions =====

function toggleKeySelector(key) {
  const selector = document.getElementById('key-selector');
  if (selector) {
    selector.style.display = selector.style.display === 'none' ? 'block' : 'none';
  }
}

async function addKeyVariable(key) {
  const select = document.getElementById('key-variable-select');
  const variable = select.value;
  
  if (!variable) {
    alert('Please select a variable');
    return;
  }
  
  console.log('addKeyVariable called:', key, variable);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/transfer-keys/add`, { variable });
    console.log('addKeyVariable response:', response);
    if (response.ok) {
      location.reload();
    } else {
      console.error('addKeyVariable failed:', response);
      alert('Failed to add key variable: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('addKeyVariable error:', e);
    alert('Error adding key variable: ' + e.message);
  }
}

async function removeKeyVariable(key, variable) {
  console.log('removeKeyVariable called:', key, variable);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/transfer-keys/remove`, { variable });
    console.log('removeKeyVariable response:', response);
    if (response.ok) {
      location.reload();
    } else {
      console.error('removeKeyVariable failed:', response);
      alert('Failed to remove key variable: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('removeKeyVariable error:', e);
    alert('Error removing key variable: ' + e.message);
  }
}


// ===== DTA TC Inline Icon Logic (final version) =====

// Data rows are 0,2,4,... ; comment rows are 1,3,5,...
function getTcDataRow(idx){
  const rows = document.querySelectorAll('.tc-table tbody tr');
  return rows[idx * 2] || null;
}

// SVG Icons
function svgPencil(){ return `
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
     viewBox="0 0 24 24" fill="none" stroke="currentColor"
     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M12 20h9"/>
  <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z"/>
</svg>`; }
function svgSave(){ return `
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
     viewBox="0 0 24 24" fill="none" stroke="currentColor"
     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M7 3h10l4 4v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/>
  <path d="M12 17v-4"/>
</svg>`; }
function svgComment(){ return `
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
     viewBox="0 0 24 24" fill="none" stroke="currentColor"
     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/>
</svg>`; }

// Replace text “Comment” link with icon
function iconizeCommentLinks(scope=document){
  scope.querySelectorAll('.tc-actions .link-comment').forEach(a => {
    const onclick = a.getAttribute('onclick');
    const btn = document.createElement('button');
    btn.className = 'btn btn-icon sm btn-comment-icon';
    btn.title = 'Comment';
    btn.innerHTML = svgComment();
    if (onclick) btn.setAttribute('onclick', onclick);
    a.replaceWith(btn);
  });
}

// Core toggle logic for editable rows
function setRowEditable(idx, editable, key){
  const row = getTcDataRow(idx);
  if(!row) return;

  // Toggle readonly on inputs
  row.querySelectorAll('input').forEach(inp =>
    editable ? inp.removeAttribute('readonly') : inp.setAttribute('readonly','readonly')
  );

  // Visual state
  row.classList.toggle('row-editing', editable);
  row.classList.toggle('selected', editable);
  row.classList.toggle('row-readonly', !editable);

  // Action cell
  const cell = row.querySelector('.tc-actions');
  if (!cell) return;
  const editBtn    = cell.querySelector('button[title="Edit row"], button[title="Save edits"]');
  const approveBtn = cell.querySelector('button[title="Review Complete"]');

  if (editable) {
    // Switch Edit → Save icon
    if (editBtn){
      editBtn.title = 'Save edits';
      editBtn.innerHTML = svgSave();
      editBtn.classList.add('primary');
      editBtn.onclick = () => window.tcSave(key, idx);
    }
    if (approveBtn){
      approveBtn.disabled = true;
      approveBtn.style.opacity = 0.5;
    }
  } else {
    // Switch Save → Edit icon
    if (editBtn){
      editBtn.title = 'Edit row';
      editBtn.innerHTML = svgPencil();
      editBtn.classList.remove('primary');
      editBtn.onclick = () => window.tcEdit(key, idx);
    }
    if (approveBtn){
      approveBtn.disabled = false;
      approveBtn.style.opacity = 1;
    }
  }
}

// --- API Overrides ---
window.tcEdit = async function(key, idx){
  setRowEditable(idx, true, key);
  try { await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/${idx}/edit`); } catch(e){}
};

window.tcSave = async function(key, idx){
  setRowEditable(idx, false, key);
  try { await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/${idx}/save`); } catch(e){}
};

window.tcApprove = async function(key, idx){
  const row = getTcDataRow(idx);
  if (row) {
    row.classList.remove('row-editing','selected');
    row.classList.add('row-approved');
    row.querySelectorAll('input').forEach(i => i.setAttribute('readonly','readonly'));
    const cell = row.querySelector('.tc-actions');
    if (cell) {
      cell.innerHTML = ''; // remove edit/comment icons
      const chip = document.createElement('span');
      chip.className = 'btn review-complete sm';
      chip.title = 'Review Complete';
      chip.textContent = 'Review Complete';
      cell.appendChild(chip);
    }
  }
  try { await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/${idx}/approve`); } catch(e){}
};

// Initialize icons for existing comment links on load
document.addEventListener('DOMContentLoaded', () => iconizeCommentLinks());

// === TV functions ===
async function tvSelect(key, idx){
  const res = await API.post(`/api/workspace/${encodeURIComponent(key)}/tv/select/${idx}`);
  if(res && res.ok){
    window.location.href = `${window.location.pathname}?tab=TV`;
  }
}
async function tvSaveSelected(key){
  const payload = {
    FILE_ORDER: Number(document.querySelector('#tv-file-order')?.value || 0),
    FORMAT: document.querySelector('#tv-format')?.value || '',
    LENGTH: Number(document.querySelector('#tv-length')?.value || 0),
    REQUIRED: document.querySelector('#tv-required')?.checked || false,
    TEST_CONCEPTS: document.querySelector('#tv-test-concepts')?.value || '',
    EXAMPLE_VALUES: document.querySelector('#tv-example-values')?.value || ''
  };
  const list = document.querySelector('.tv-labels-list');
  const selected = document.querySelector('.tv-label-item.active');
  if(!list || !selected){ return; }
  const idx = Array.from(list.children).indexOf(selected);
  await API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/update`, payload);
}
async function tvApproveSelected(key){
  const list = document.querySelector('.tv-labels-list');
  const selected = document.querySelector('.tv-label-item.active');
  if(!list || !selected){ return; }
  const idx = Array.from(list.children).indexOf(selected);
  const res = await API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/approve`);
  if(res && res.ok){ selected.classList.add('approved'); }
}
async function tvAdd(key){
  const res = await API.post(`/api/workspace/${encodeURIComponent(key)}/tv/add`);
  if(res && res.ok){
    window.location.href = `${window.location.pathname}?tab=TV`;
  }
}

// === Metadata Functions ===
function metaEdit(key, idx) {
  fetch(`/api/workspace/${key}/meta/${idx}/edit`, { method: 'POST' })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error editing metadata: ' + e));
}

function metaSave(key, idx) {
  // Find the input in that row
  const inputs = document.querySelectorAll(`[id^="meta-"][id$="-${idx}"]`);
  let value = '';
  inputs.forEach(input => {
    if (input.value !== undefined) {
      value = input.value;
    }
  });
  
  fetch(`/api/workspace/${key}/meta/${idx}/save`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ value })
  })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error saving metadata: ' + e));
}

function metaCancel(key, idx) {
  fetch(`/api/workspace/${key}/meta/${idx}/cancel`, { method: 'POST' })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error canceling: ' + e));
}

function metaApprove(key, idx) {
  fetch(`/api/workspace/${key}/meta/${idx}/approve`, { method: 'POST' })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error approving metadata: ' + e));
}

function toggleMetaComment(idx) {
  const row = document.getElementById(`meta-comment-${idx}`);
  row.style.display = row.style.display === 'none' ? 'block' : 'none';
}

function metaPostComment(key, idx) {
  const input = document.getElementById(`meta-comment-input-${idx}`);
  const text = input.value.trim();
  if (!text) return;
  
  fetch(`/api/workspace/${key}/meta/${idx}/comment`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ text })
  })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error posting comment: ' + e));
}

// === DIP (Data Ingestion Parameters) Functions ===
function dipEdit(key, idx) {
  fetch(`/api/workspace/${key}/dip/${idx}/edit`, { method: 'POST' })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error editing DIP: ' + e));
}

function dipSave(key, idx) {
  const inputs = document.querySelectorAll(`[id^="dip-"][id$="-${idx}"]`);
  let value = '';
  inputs.forEach(input => {
    if (input.value !== undefined) {
      value = input.value;
    }
  });
  
  fetch(`/api/workspace/${key}/dip/${idx}/save`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ value })
  })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error saving DIP: ' + e));
}

function dipCancel(key, idx) {
  fetch(`/api/workspace/${key}/dip/${idx}/cancel`, { method: 'POST' })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error canceling: ' + e));
}

function dipApprove(key, idx) {
  fetch(`/api/workspace/${key}/dip/${idx}/approve`, { method: 'POST' })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error approving DIP: ' + e));
}

function toggleDipComment(idx) {
  const row = document.getElementById(`dip-comment-${idx}`);
  row.style.display = row.style.display === 'none' ? 'block' : 'none';
}

function dipPostComment(key, idx) {
  const input = document.getElementById(`dip-comment-input-${idx}`);
  const text = input.value.trim();
  if (!text) return;
  
  fetch(`/api/workspace/${key}/dip/${idx}/comment`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ text })
  })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error posting comment: ' + e));
}

// Export and Publish functions for Approved DTAs
async function exportDta(key) {
  try {
    const response = await fetch(`/api/workspace/${encodeURIComponent(key)}/export`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'}
    });
    
    const result = await response.json();
    
    if (result.success) {
      // Redirect to Jobs Status page with the job_id highlighted
      window.location.href = `/ingestion?highlight=${result.job_id}`;
    } else {
      alert(result.msg || 'Failed to trigger export job');
    }
  } catch (e) {
    console.error('Export error:', e);
    alert('Failed to trigger export job');
  }
}

async function publishMajorVersion(key) {
  const confirmed = confirm(
    'Are you sure you want to publish this DTA as a new major version?\n\n' +
    'This will:\n' +
    '• Increment the major version number\n' +
    '• Make this version available for use\n' +
    '• Archive the current draft'
  );
  
  if (!confirmed) return;
  
  try {
    const response = await fetch(`/api/workspace/${encodeURIComponent(key)}/publish-major`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'}
    });
    
    const result = await response.json();
    
    if (result.success) {
      alert(`Success! DTA published as Major v${result.new_major_version}`);
      window.location.href = '/dashboard';
    } else {
      alert(result.msg || 'Failed to publish major version');
    }
  } catch (e) {
    console.error('Publish error:', e);
    alert('Failed to publish major version');
  }
}

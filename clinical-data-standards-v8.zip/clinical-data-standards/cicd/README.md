# CI/CD for {{.project_name}}

CI/CD configuration for automated testing and deployment of Databricks Asset Bundles.

## Overview

This directory contains CI/CD pipeline definitions for:
- **Azure DevOps**: `azure_pipeline.yml.tmpl`
- **GitHub Actions**: (Add `.github/workflows/` if needed)

## Pipeline Stages

### 1. Validate
- Validates bundle configuration
- Runs unit tests
- Checks code quality
- Generates coverage reports

### 2. Deploy to Development
- Triggers on `develop` branch
- Deploys to dev workspace
- Runs smoke tests

### 3. Deploy to Staging
- Depends on successful dev deployment
- Deploys to staging workspace
- Runs integration tests

### 4. Deploy to Production
- Triggers on `main` branch
- Requires manual approval
- Deploys to production workspace
- Runs production jobs

## Setup

### Azure DevOps

1. **Create Service Connection**
   - Go to Project Settings > Service connections
   - Create new service connection
   - Type: Generic
   - Server URL: {{.workspace_host}}
   - Token: Create Databricks personal access token

2. **Set Pipeline Variables**
   ```yaml
   DATABRICKS_HOST: {{.workspace_host}}
   DATABRICKS_TOKEN_DEV: $(secret-variable)
   DATABRICKS_TOKEN_STAGING: $(secret-variable)
   DATABRICKS_TOKEN_PROD: $(secret-variable)
   ```

3. **Create Environments**
   - Go to Pipelines > Environments
   - Create: `dev`, `staging`, `production`
   - Add approvals for production

4. **Create Pipeline**
   - Go to Pipelines > Create Pipeline
   - Select Azure Repos Git
   - Choose this repository
   - Select existing Azure Pipelines YAML file
   - Select `/cicd/azure_pipeline.yml.tmpl`

### GitHub Actions

Create `.github/workflows/databricks-deploy.yml`:

```yaml
name: Deploy Databricks Bundle

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main, develop]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Databricks CLI
        run: |
          curl -fsSL https://raw.githubusercontent.com/databricks/setup-cli/main/install.sh | sh
      
      - name: Validate Bundle
        run: databricks bundle validate
        env:
          DATABRICKS_HOST: ${{ secrets.DATABRICKS_HOST }}
          DATABRICKS_TOKEN: ${{ secrets.DATABRICKS_TOKEN }}
      
      - name: Deploy to Dev
        if: github.ref == 'refs/heads/develop'
        run: databricks bundle deploy --target dev
        env:
          DATABRICKS_HOST: ${{ secrets.DATABRICKS_HOST }}
          DATABRICKS_TOKEN: ${{ secrets.DATABRICKS_TOKEN_DEV }}
      
      - name: Deploy to Prod
        if: github.ref == 'refs/heads/main'
        run: databricks bundle deploy --target prod
        env:
          DATABRICKS_HOST: ${{ secrets.DATABRICKS_HOST }}
          DATABRICKS_TOKEN: ${{ secrets.DATABRICKS_TOKEN_PROD }}
```

## Branch Strategy

### Gitflow Workflow

```
main (production)
  ├── develop (staging/dev)
  │   ├── feature/new-feature
  │   ├── feature/another-feature
  │   └── hotfix/critical-fix
```

### Branch Protection Rules

**Main Branch**:
- Require pull request reviews
- Require status checks to pass
- Require signed commits
- Restrict force pushes

**Develop Branch**:
- Require pull request reviews
- Require status checks to pass

## Secrets Management

### Azure DevOps

Store secrets in:
1. **Variable Groups**: For shared secrets
   - Library > Variable Groups
   - Link to Key Vault for production secrets

2. **Pipeline Variables**: For pipeline-specific secrets
   - Mark as secret
   - Use $(variable) syntax in YAML

### GitHub Actions

Store secrets in:
1. **Repository Secrets**: Settings > Secrets and variables > Actions
2. **Environment Secrets**: For environment-specific secrets

Required Secrets:
- `DATABRICKS_HOST`
- `DATABRICKS_TOKEN_DEV`
- `DATABRICKS_TOKEN_STAGING`
- `DATABRICKS_TOKEN_PROD`

## Testing

### Pre-commit Hooks

Install pre-commit hooks:

```bash
pip install pre-commit
pre-commit install
```

Create `.pre-commit-config.yaml`:

```yaml
repos:
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.4.0
    hooks:
      - id: trailing-whitespace
      - id: end-of-file-fixer
      - id: check-yaml
      - id: check-added-large-files
  
  - repo: https://github.com/psf/black
    rev: 23.3.0
    hooks:
      - id: black
  
  - repo: https://github.com/pycqa/flake8
    rev: 6.0.0
    hooks:
      - id: flake8
```

### Local Testing

Test bundle locally:

```bash
# Validate
databricks bundle validate

# Deploy to dev
databricks bundle deploy --target dev

# Run job
databricks bundle run job_name --target dev
```

## Monitoring

### Pipeline Monitoring

- View pipeline runs in Azure DevOps or GitHub Actions
- Set up notifications for failures
- Monitor deployment duration

### Databricks Monitoring

After deployment, monitor:
- Job run status
- Pipeline execution
- Model serving metrics
- App performance

## Rollback Strategy

### Automated Rollback

Add rollback step to pipeline:

```yaml
- script: |
    databricks bundle deploy --target prod --version $(PreviousVersion)
  condition: failed()
  displayName: 'Rollback on Failure'
```

### Manual Rollback

```bash
# Get previous deployment
databricks bundle deployments list --target prod

# Rollback to specific deployment
databricks bundle deploy --target prod --deployment-id <id>
```

## Best Practices

1. **Small, Frequent Deployments**: Deploy changes incrementally
2. **Feature Flags**: Use feature flags for gradual rollouts
3. **Automated Testing**: Ensure comprehensive test coverage
4. **Code Reviews**: Require reviews before merging
5. **Monitoring**: Set up alerts for deployment failures
6. **Documentation**: Keep runbooks updated
7. **Secrets Rotation**: Rotate tokens regularly

## Troubleshooting

### Common Issues

**Bundle Validation Fails**:
```bash
# Check YAML syntax
databricks bundle validate --debug
```

**Authentication Fails**:
```bash
# Verify token
databricks auth token
```

**Deployment Conflicts**:
```bash
# Force deployment (use with caution)
databricks bundle deploy --target dev --force
```

## Resources

- [Databricks CI/CD Best Practices](https://docs.databricks.com/dev-tools/bundles/ci-cd.html)
- [Azure DevOps Documentation](https://docs.microsoft.com/azure/devops/)
- [GitHub Actions Documentation](https://docs.github.com/actions)


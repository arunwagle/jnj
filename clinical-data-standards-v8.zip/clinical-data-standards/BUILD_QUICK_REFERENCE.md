# Build & Deploy Quick Reference

## 🚀 Quick Commands

### Deploy (Builds Wheel Automatically)
```bash
databricks bundle deploy --target dev
```

### Local Testing
```bash
# Build wheel locally
./build.sh

# Build and test install
./build.sh test

# Clean build artifacts
./build.sh clean
```

---

## 📦 What Gets Built

```
{{.usecase}}_framework-0.0.1+<timestamp>-py3-none-any.whl
```

**Includes:**
- `config_manager.py` - ConfigManager API
- `utils.py` - Common utilities
- Dependencies: `pyyaml>=6.0`

---

## 🔄 How It Works

### Build & Deploy Flow
```
1. databricks bundle deploy
   ↓
2. DAB reads databricks.yml → artifacts section
   ↓
3. Runs: python setup.py bdist_wheel
   ↓
4. Uploads wheel to Databricks workspace
   ↓
5. Attaches wheel to job clusters
   ↓
6. Driver node installs wheel
   ↓
7. Broadcasts to all worker nodes
   ↓
8. ✅ ConfigManager available on all nodes
```

### Runtime in Streaming Jobs
```python
# Works on driver and all workers
from {{.usecase}}_framework.config_manager import ConfigManager

config = ConfigManager("config/my_config.yaml", target="dev")
```

---

## 🛠️ Configuration

### databricks.yml
```yaml
artifacts:
  {{.usecase}}_framework:
    type: whl
    path: .
```

### Job Libraries
```yaml
resources:
  jobs:
    my_job:
      tasks:
        - task_key: my_task
          libraries:
            - whl: ../../../dist/*.whl  # Auto-attached
```

---

## ✅ Verification

### Check in Job Logs
```
Installing wheel: {{.usecase}}_framework-0.0.1+<timestamp>-py3-none-any.whl
Successfully installed {{.usecase}}_framework-0.0.1+<timestamp>
```

### Verify in Notebook
```python
import pkg_resources
version = pkg_resources.get_distribution("{{.usecase}}_framework").version
print(f"Framework version: {version}")
```

---

## 🐛 Troubleshooting

| Problem | Solution |
|---------|----------|
| `ModuleNotFoundError` | Check `libraries:` section in job YAML |
| Changes not reflected | Redeploy: `databricks bundle deploy --force` |
| Import error on workers | Verify wheel attached to job cluster |
| Build fails | Check `setup.py` and dependencies |

---

## 📝 After Making Framework Changes

```bash
# 1. Edit code in src/{{.usecase}}_framework/
vim src/{{.usecase}}_framework/config_manager.py

# 2. (Optional) Test locally
./build.sh test

# 3. Redeploy
databricks bundle deploy --target dev

# 4. ✅ New wheel automatically distributed
```

---

## 🎯 Key Points

✅ **Automatic** - DAB handles build and distribution  
✅ **All Nodes** - Driver + all workers get the wheel  
✅ **Versioned** - Timestamp-based versioning prevents conflicts  
✅ **Dependencies** - PyYAML included automatically  

---

## 📚 Full Documentation

See `BUILD_AND_DEPLOY.md` for detailed information.


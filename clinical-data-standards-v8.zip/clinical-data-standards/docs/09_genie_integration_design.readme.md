# Genie AI Integration Design

> **Status**: Implemented  
> **Last Updated**: December 2025

## Overview

This document describes the integration of Databricks Genie AI into the DTA Builder UI, enabling users to search for DTAs and clinical metadata using natural language queries.

---

## Architecture

```mermaid
flowchart LR
    subgraph "DTA Builder UI"
        UI[User Interface]
        Toggle[Search Mode Toggle]
        Results[Results Panel]
    end
    
    subgraph "Flask Backend"
        API["/api/genie/search"]
        Client[GenieClient]
    end
    
    subgraph "Databricks"
        SDK[Databricks SDK]
        Genie[Genie Space]
        Tables[(Unity Catalog Tables)]
    end
    
    UI --> Toggle
    Toggle -->|Standard| API
    Toggle -->|AI Search| API
    API --> Client
    Client --> SDK
    SDK --> Genie
    Genie --> Tables
    Tables --> Genie
    Genie --> SDK
    SDK --> Client
    Client --> API
    API --> Results
```

---

## Components

### 1. UI Components (`composer.html`)

#### Search Mode Toggle
```
[○ Standard Search]  [● AI Search with Genie] ✨
```

- **Standard Search**: Traditional SQL-based search with field matching
- **AI Search with Genie**: Natural language queries powered by Databricks Genie

#### Genie Response Panel
Displays:
- Genie's text response explaining the results
- Generated SQL query (expandable)
- Search results in DTA card format

### 2. Backend API (`api/genie_api.py`)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/genie/search` | GET | Send natural language query to Genie |
| `/api/genie/followup` | POST | Continue conversation with follow-up questions |
| `/api/genie/status` | GET | Check Genie configuration status |

### 3. Genie Wrapper (`api/genie.py`)

Uses `databricks_ai_bridge.genie` for clean API interaction:

```python
from api.genie import GenieWrapper, GenieResponse

genie = GenieWrapper(space_id)

# Ask initial question
response = genie.ask_first_question("Show me Labs DTAs")
result = genie.poll_result(response)  # Returns GenieResponse

# GenieResponse attributes:
# - result.description: Text explanation
# - result.query: Generated SQL
# - result.result: Markdown table results

# Follow-up questions
followup = genie.ask_followup_question("Filter by LabCorp", conversation_id)
followup_result = genie.poll_result(followup)
```

### 4. Configuration (`app.yaml`)

```yaml
env:
  - name: GENIE_SPACE_ID
    value: "your-genie-space-id"
  # Polling is handled internally by databricks-ai-bridge
```

---

## Genie Space Setup

### Prerequisites

1. Create a Genie Space in Databricks with the following tables:

| Table | Purpose |
|-------|---------|
| `gold_md.dta` | DTA entity records |
| `gold_md.dta_workflow` | Workflow tracking |
| `gold_md.md_version_registry` | Version registry |
| `gold_md.md_dta_transfer_variables` | Approved variable definitions |
| `gold_md.dta_activity_log` | Audit history |
| `silver_md.md_dta_transfer_variables_draft` | Draft variables |

2. Run `job_cdm_export_genie_assets` to generate table descriptions (outputs to Volumes)

3. Set the `GENIE_SPACE_ID` environment variable

4. Install required dependencies (in `requirements.txt`):
   ```
   databricks-ai-bridge>=0.1.0
   ```

### Creating a Genie Space

1. Navigate to **Workspace** → **Genie** in Databricks
2. Click **Create Space**
3. Add the DTA tables from the catalog
4. Configure sample questions (optional)
5. Copy the Space ID and add to `app.yaml`

---

## Example Queries

| User Query | Genie Interprets As |
|------------|---------------------|
| "Show me the latest Labs DTA from LabCorp" | Find DTAs where `data_stream_type = 'Labs'` and `data_provider_name LIKE '%LabCorp%'` |
| "Which DTAs for trial VAC18193 are pending approval?" | Filter by `trial_id LIKE '%VAC18193%'` and `workflow_state = 'IN_REVIEW'` |
| "Find approved transfer variable definitions for ECG" | Query `md_dta_transfer_variables` where `data_stream_type = 'ECG'` |
| "What changes were made to DTA001 this week?" | Query `dta_activity_log` for recent activity |
| "How many DTAs need manual review?" | Count DTAs where `status = 'MANUAL_REVIEW'` |

---

## Genie Training Sample Queries

Use these SQL queries to train your Genie space. They return DTAs with metadata entity counts, enabling the UI to render DTA cards.

> **Note**: Currently only Transfer Variables (`md_dta_transfer_variables`) is supported. Other entity counts return 0.

---

### 1. Find all approved DTAs

```sql
SELECT 
    d.dta_id,
    d.dta_number,
    d.dta_name,
    d.trial_id,
    d.data_stream_type,
    d.data_provider_name,
    d.version,
    d.workflow_state,
    d.status,
    d.last_updated_ts,
    COALESCE(tv.tv_count, 0) AS transfer_variables_count,
    0 AS test_concepts_count,
    0 AS codelists_count,
    0 AS visits_timepoints_count,
    0 AS operational_agreements_count,
    0 AS data_ingestion_params_count
FROM gold_md.dta d
LEFT JOIN (
    SELECT dta_id, COUNT(*) AS tv_count
    FROM gold_md.md_dta_transfer_variables
    WHERE is_current = true
    GROUP BY dta_id
) tv ON d.dta_id = tv.dta_id
WHERE d.workflow_state = 'APPROVED'
ORDER BY d.last_updated_ts DESC
LIMIT 20
```

---

### 2. Show all DTAs for trial VAC18193

```sql
SELECT 
    d.dta_id,
    d.dta_number,
    d.dta_name,
    d.trial_id,
    d.data_stream_type,
    d.data_provider_name,
    d.version,
    d.workflow_state,
    d.status,
    d.last_updated_ts,
    COALESCE(tv.tv_count, 0) AS transfer_variables_count,
    0 AS test_concepts_count,
    0 AS codelists_count,
    0 AS visits_timepoints_count,
    0 AS operational_agreements_count,
    0 AS data_ingestion_params_count
FROM gold_md.dta d
LEFT JOIN (
    SELECT dta_id, COUNT(*) AS tv_count
    FROM gold_md.md_dta_transfer_variables
    WHERE is_current = true
    GROUP BY dta_id
) tv ON d.dta_id = tv.dta_id
WHERE UPPER(d.trial_id) LIKE '%VAC18193%'
ORDER BY d.last_updated_ts DESC
LIMIT 20
```

---

### 3. List all DTAs from Adaptive

```sql
SELECT 
    d.dta_id,
    d.dta_number,
    d.dta_name,
    d.trial_id,
    d.data_stream_type,
    d.data_provider_name,
    d.version,
    d.workflow_state,
    d.status,
    d.last_updated_ts,
    COALESCE(tv.tv_count, 0) AS transfer_variables_count,
    0 AS test_concepts_count,
    0 AS codelists_count,
    0 AS visits_timepoints_count,
    0 AS operational_agreements_count,
    0 AS data_ingestion_params_count
FROM gold_md.dta d
LEFT JOIN (
    SELECT dta_id, COUNT(*) AS tv_count
    FROM gold_md.md_dta_transfer_variables
    WHERE is_current = true
    GROUP BY dta_id
) tv ON d.dta_id = tv.dta_id
WHERE UPPER(d.data_provider_name) LIKE '%ADAPTIVE%'
ORDER BY d.last_updated_ts DESC
LIMIT 20
```

---

### 4. Find DTAs for PF data stream

```sql
SELECT 
    d.dta_id,
    d.dta_number,
    d.dta_name,
    d.trial_id,
    d.data_stream_type,
    d.data_provider_name,
    d.version,
    d.workflow_state,
    d.status,
    d.last_updated_ts,
    COALESCE(tv.tv_count, 0) AS transfer_variables_count,
    0 AS test_concepts_count,
    0 AS codelists_count,
    0 AS visits_timepoints_count,
    0 AS operational_agreements_count,
    0 AS data_ingestion_params_count
FROM gold_md.dta d
LEFT JOIN (
    SELECT dta_id, COUNT(*) AS tv_count
    FROM gold_md.md_dta_transfer_variables
    WHERE is_current = true
    GROUP BY dta_id
) tv ON d.dta_id = tv.dta_id
WHERE UPPER(d.data_stream_type) LIKE '%PF%'
ORDER BY d.last_updated_ts DESC
LIMIT 20
```

---

### 5. Show DTAs from Adaptive for PF data stream

```sql
SELECT 
    d.dta_id,
    d.dta_number,
    d.dta_name,
    d.trial_id,
    d.data_stream_type,
    d.data_provider_name,
    d.version,
    d.workflow_state,
    d.status,
    d.last_updated_ts,
    COALESCE(tv.tv_count, 0) AS transfer_variables_count,
    0 AS test_concepts_count,
    0 AS codelists_count,
    0 AS visits_timepoints_count,
    0 AS operational_agreements_count,
    0 AS data_ingestion_params_count
FROM gold_md.dta d
LEFT JOIN (
    SELECT dta_id, COUNT(*) AS tv_count
    FROM gold_md.md_dta_transfer_variables
    WHERE is_current = true
    GROUP BY dta_id
) tv ON d.dta_id = tv.dta_id
WHERE UPPER(d.data_provider_name) LIKE '%ADAPTIVE%'
  AND UPPER(d.data_stream_type) LIKE '%PF%'
ORDER BY d.last_updated_ts DESC
LIMIT 20
```

---

### 6. Show DTAs for trial VAC18193 from Adaptive for PF data stream

```sql
SELECT 
    d.dta_id,
    d.dta_number,
    d.dta_name,
    d.trial_id,
    d.data_stream_type,
    d.data_provider_name,
    d.version,
    d.workflow_state,
    d.status,
    d.last_updated_ts,
    COALESCE(tv.tv_count, 0) AS transfer_variables_count,
    0 AS test_concepts_count,
    0 AS codelists_count,
    0 AS visits_timepoints_count,
    0 AS operational_agreements_count,
    0 AS data_ingestion_params_count
FROM gold_md.dta d
LEFT JOIN (
    SELECT dta_id, COUNT(*) AS tv_count
    FROM gold_md.md_dta_transfer_variables
    WHERE is_current = true
    GROUP BY dta_id
) tv ON d.dta_id = tv.dta_id
WHERE UPPER(d.trial_id) LIKE '%VAC18193%'
  AND UPPER(d.data_provider_name) LIKE '%ADAPTIVE%'
  AND UPPER(d.data_stream_type) LIKE '%PF%'
ORDER BY d.last_updated_ts DESC
LIMIT 20
```

---

### 7. What DTAs were updated recently?

```sql
SELECT 
    d.dta_id,
    d.dta_number,
    d.dta_name,
    d.trial_id,
    d.data_stream_type,
    d.data_provider_name,
    d.version,
    d.workflow_state,
    d.status,
    d.last_updated_ts,
    COALESCE(tv.tv_count, 0) AS transfer_variables_count,
    0 AS test_concepts_count,
    0 AS codelists_count,
    0 AS visits_timepoints_count,
    0 AS operational_agreements_count,
    0 AS data_ingestion_params_count
FROM gold_md.dta d
LEFT JOIN (
    SELECT dta_id, COUNT(*) AS tv_count
    FROM gold_md.md_dta_transfer_variables
    WHERE is_current = true
    GROUP BY dta_id
) tv ON d.dta_id = tv.dta_id
WHERE d.last_updated_ts >= DATE_ADD(CURRENT_DATE(), -30)
ORDER BY d.last_updated_ts DESC
LIMIT 20
```

---

### 8. Show draft DTAs

```sql
SELECT 
    d.dta_id,
    d.dta_number,
    d.dta_name,
    d.trial_id,
    d.data_stream_type,
    d.data_provider_name,
    d.version,
    d.workflow_state,
    d.status,
    d.last_updated_ts,
    COALESCE(tv.tv_count, 0) AS transfer_variables_count,
    0 AS test_concepts_count,
    0 AS codelists_count,
    0 AS visits_timepoints_count,
    0 AS operational_agreements_count,
    0 AS data_ingestion_params_count
FROM gold_md.dta d
LEFT JOIN (
    SELECT dta_id, COUNT(*) AS tv_count
    FROM silver_md.md_dta_transfer_variables_draft
    WHERE version_status = 'DRAFT'
    GROUP BY dta_id
) tv ON d.dta_id = tv.dta_id
WHERE d.status = 'DRAFT'
ORDER BY d.last_updated_ts DESC
LIMIT 20
```

---

### Expected Output Columns for UI Cards

| Column | Used For |
|--------|----------|
| `dta_number` | Card header (DTA001, DTA002) |
| `dta_name` | DTA friendly name |
| `version` | Version badge (1.0-DTA001-v1.0) |
| `trial_id` | Trial field |
| `data_stream_type` | Stream field |
| `data_provider_name` | Provider field |
| `workflow_state` | Status badge (APPROVED, DRAFT) |
| `status` | DTA lifecycle status |
| `last_updated_ts` | Date shown on card |
| `transfer_variables_count` | Icon with count (📊 85) |
| `test_concepts_count` | Returns 0 (not yet supported) |
| `codelists_count` | Returns 0 (not yet supported) |
| `visits_timepoints_count` | Returns 0 (not yet supported) |
| `operational_agreements_count` | Returns 0 (not yet supported) |
| `data_ingestion_params_count` | Returns 0 (not yet supported) |

---

## User Experience Flow

```mermaid
sequenceDiagram
    participant User
    participant UI as DTA Builder UI
    participant API as Flask API
    participant Genie as Databricks Genie
    
    User->>UI: Selects "AI Search with Genie"
    User->>UI: Types natural language question
    User->>UI: Clicks "Ask Genie"
    
    UI->>API: GET /api/genie/search?q=...
    API->>Genie: Start conversation
    Genie-->>API: Conversation ID
    
    API->>Genie: Send question
    Genie-->>API: Message ID
    
    loop Poll for response
        API->>Genie: Get message status
        Genie-->>API: Status (PENDING/COMPLETED)
    end
    
    Genie-->>API: Response (text + SQL + results)
    API-->>UI: Formatted response
    
    UI->>UI: Display Genie answer
    UI->>UI: Render DTA cards from results
```

---

## Error Handling

| Scenario | User Experience |
|----------|-----------------|
| Genie not configured | Toggle disabled with tooltip |
| Query too short | Alert message prompting more detail |
| Timeout | Error message with retry option |
| No results | Message suggesting query refinement |
| API error | Generic error with retry option |

---

## CSS Styling

The Genie integration uses a distinct visual style:

- **Purple gradient**: Indicates AI-powered functionality
- **Sparkle animation**: On the toggle label
- **Response panel**: Light purple gradient background
- **Loading spinner**: Animated during query processing

---

## Security Considerations

1. **Authentication**: Uses Databricks SDK with workspace credentials
2. **Authorization**: Respects Unity Catalog permissions on underlying tables
3. **Data Isolation**: Users only see data they have access to
4. **Audit Trail**: Genie conversations are logged in Databricks

---

## Future Enhancements

1. **Conversation History**: Save and resume Genie conversations
2. **Suggested Questions**: Pre-defined common queries
3. **Voice Input**: Microphone input for questions
4. **Multi-turn Conversations**: Follow-up questions in context
5. **Export Results**: Download Genie results as CSV/Excel

---

## Files Modified

| File | Changes |
|------|---------|
| `api/genie_api.py` | New file - Genie API endpoints |
| `templates/composer.html` | Search mode toggle + Genie response panel |
| `static/styles.css` | Genie-specific styles |
| `app.py` | Register genie_bp blueprint |
| `app.yaml` | Genie environment variables |

---

## Troubleshooting

### Genie toggle is disabled
- Check `GENIE_SPACE_ID` is set in `app.yaml`
- Verify the Space ID is correct and the space exists
- Check user has access to the Genie Space

### Query returns no results
- Verify the tables have data
- Check table permissions in Unity Catalog
- Try rephrasing the question

### Timeout errors
- Increase `GENIE_TIMEOUT` value
- Check Databricks cluster availability
- Simplify the query

---

## Best Practices for Training Genie (DTA-Specific)

This section provides DTA-specific guidance for training and curating the Genie space. Based on [Databricks Genie best practices](https://docs.databricks.com/aws/en/genie/best-practices).

### Required Search Criteria

Genie should always ask clarifying questions when users don't provide sufficient context. For DTA searches, require at minimum:

| Required Combination | Example Question |
|---------------------|------------------|
| Vendor + Data Stream | "Show me Labs DTAs from LabCorp" |
| Vendor + Trial | "Find DTAs for Covance in trial VAC18193" |

**Clarification Prompt to Configure:**
> "To find relevant DTAs, please specify the vendor name (data_provider_name) AND either the data stream type (e.g., Labs, ECG, Biomarkers) OR trial ID (e.g., VAC18193RSV3001)."

### DTA Business Terms and SQL Expressions

Configure these SQL expressions in your Genie space for consistent interpretation:

| Business Term | SQL Expression | Description |
|--------------|----------------|-------------|
| Active DTA | `status = 'ACTIVE' AND workflow_state = 'APPROVED'` | Production-ready DTA |
| Draft DTA | `status = 'DRAFT'` | Work-in-progress DTA |
| Pending Approval | `workflow_state = 'IN_REVIEW'` | Awaiting reviewer action |
| Latest Version | `is_current = true` | Most recent approved version |
| DTA Template | `version_type = 'DTA_TEMPLATE'` | Canonical template for cloning |
| Approved Version | `version_type = 'DTA_APPROVED'` | Finalized DTA version |

### DTA Workflow States

| State | Meaning | When Used |
|-------|---------|-----------|
| NOT_STARTED | Draft created, not yet submitted | Initial creation |
| IN_REVIEW | Submitted, awaiting approvals | After submission for review |
| APPROVED | All required approvals complete | Ready for production |
| REJECTED | Returned for revision with comments | Needs changes |

### Approver Roles

| Role | Description | Approval Order |
|------|-------------|----------------|
| jnj_dae | J&J Data Acquisition Expert | 1st (internal review) |
| vendor | External data provider representative | 2nd (vendor confirmation) |
| librarian | J&J Metadata Librarian | 3rd (template promotion) |

### Common Query Patterns for Example SQL

Add these parameterized queries to your Genie space (see `sql/example_queries.sql`):

1. **Find DTAs by vendor and data stream** - Core search pattern
2. **Find DTAs by trial** - Trial-based filtering
3. **Latest N versions for a DTA** - Version history queries
4. **DTAs modified by user** - User activity tracking
5. **Approval status for a DTA** - Workflow status queries
6. **DTAs pending approval** - Review queue
7. **Find similar DTAs for cloning** - Clone candidate discovery

### Data Stream Types

Common values to recognize:
- Labs
- ECG
- Adverse Events
- Biomarkers
- Demographics
- Vital Signs
- PF (Patient Flow)
- Medical History

### Table Relationships for Complex Queries

```
dta (core entity - search here first)
  ├── dta_workflow (1:N by dta_id)
  │     └── dta_approval_task (1:N by dta_workflow_id)
  ├── md_version_registry (1:N by dta_id)
  ├── md_dta_transfer_variables (1:N by dta_id, filter is_current=true)
  ├── md_dta_vendor_test_concepts (1:N by dta_id, filter is_current=true)
  └── dta_activity_log (1:N by dta_id)
```

### Important Query Tips

1. **Always filter for current versions**: When querying `md_dta_transfer_variables` or `md_dta_vendor_test_concepts`, add `is_current = true`
2. **Case-insensitive matching**: Use `UPPER()` or `ILIKE` for vendor/trial name searches
3. **DTA number format**: Sequential identifiers like DTA001, DTA002, etc.
4. **Version format**: 
   - Approved: `1.0-DTA001-v1.0`
   - Draft: `1.0-DTA001-draft1`

### Exporting Genie Assets

Use the `job_cdm_export_genie_assets` job to generate Genie training assets:

**Output Files:**
```
/Volumes/{catalog}/bronze_md/{source_root}/export/genie/
├── sql/
│   ├── add_table_comments.sql    # Table/column descriptions
│   └── example_queries.sql       # 15 parameterized queries
├── genie_instructions.txt        # Space instructions
└── export_manifest.json          # Export metadata
```

**Manual Trigger:**
```python
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()
run = w.jobs.run_now(
    job_id=<job_id>,
    job_parameters={
        "source_root": "clinical_data_standards/test",
        "catalog_override": "aira_test"
    }
)
```

### Iterative Refinement Process

1. **Start with core tables**: Begin with `dta`, `md_version_registry`, and `dta_workflow`
2. **Add example queries**: Use the generated `example_queries.sql` as a starting point
3. **Monitor user questions**: Review what users are asking in the Monitoring tab
4. **Refine instructions**: Add clarifications for commonly misunderstood queries
5. **Test with variations**: Try different phrasings of the same question
6. **Collect feedback**: Use upvote/downvote to identify improvement areas

---

*See also: [Schema Design](./02_schema_design.readme.md) for table descriptions used by Genie*


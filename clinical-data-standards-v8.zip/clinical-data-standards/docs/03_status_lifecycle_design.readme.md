# Status Lifecycle & Management

> **Purpose**: Document all status values, status columns, and their transitions across the Clinical Data Standards pipeline.

## Overview

The pipeline uses multiple status columns across different layers to track document processing and data validation.

```mermaid
flowchart TB
    subgraph Bronze["🟤 Bronze Layer"]
        B1["md_file_history<br/>status"]
        B2["md_file_history<br/>status"]
    end
    
    subgraph Silver["⚪ Silver Layer"]
        S1["md_dta_transfer_variables_draft<br/>status"]
        S2["md_codelists_normalized<br/>status"]
    end
    
    subgraph Gold["🟡 Gold Layer"]
        G1["DTA<br/>status"]
    end
    
    B1 --> S1 & S2
    S1 & S2 --> G1
    
    style Bronze fill:#D7CCC8,stroke:#5D4037
    style Silver fill:#BBDEFB,stroke:#1565C0
    style Gold fill:#FFF59D,stroke:#F9A825
```

---

## 📋 Status Columns Summary

| Table | Column | Layer | Purpose |
|-------|--------|-------|---------|
| `md_file_history` | `status` | Bronze | Document processing lifecycle |
| `md_file_history` | `status` | Bronze | Detailed status tracking with timestamps |
| `md_dta_transfer_variables_draft` | `status` | Silver | Row-level validation status |
| `md_codelists_normalized` | `status` | Silver | Row-level validation status |
| `DTA` | `status` | Gold | DTA entity lifecycle |

> **Note**: For workflow states, version registry status, and approval task status, see [06_dta_approval_design.readme.md](./06_dta_approval_design.readme.md) and [04_versioning_design.readme.md](./04_versioning_design.readme.md).

---

## 🔄 Bronze Layer: Document Processing

### `md_file_history.status`

Tracks the processing lifecycle of each document extracted from source files.

```mermaid
stateDiagram-v2
    [*] --> READY_FOR_PROCESSING: File extracted
    
    READY_FOR_PROCESSING --> TSDTA_PROCESSING: tsDTA processor starts
    TSDTA_PROCESSING --> EXCEL_EXTRACTION_COMPLETED: Sheets extracted
    EXCEL_EXTRACTION_COMPLETED --> READY_FOR_VERSIONING: All processing complete
    
    READY_FOR_PROCESSING --> DOC_PROCESSING: Doc processor starts
    DOC_PROCESSING --> DOC_COMPLETED: PDF/Word processed
    
    TSDTA_PROCESSING --> TSDTA_FAILED: Processing error
    DOC_PROCESSING --> DOC_FAILED: Processing error
    
    READY_FOR_VERSIONING --> VERSIONING_IN_PROCESS: DTA creation starts
    VERSIONING_IN_PROCESS --> VERSIONED: DTA created
    VERSIONING_IN_PROCESS --> VERSIONING_FAILED: DTA creation failed
    
    [*] --> EXTRACTION_ERROR: File extraction failed
```

#### Status Values

| Status | Description | Next Status |
|--------|-------------|-------------|
| `READY_FOR_PROCESSING` | File extracted, awaiting processing | TSDTA_PROCESSING, DOC_PROCESSING |
| `TSDTA_PROCESSING` | Excel sheets being extracted | EXCEL_EXTRACTION_COMPLETED, TSDTA_FAILED |
| `EXCEL_EXTRACTION_COMPLETED` | Sheets extracted, metadata loaded | READY_FOR_VERSIONING |
| `TSDTA_FAILED` | Excel processing failed | (Manual intervention) |
| `DOC_PROCESSING` | PDF/Word being processed | DOC_COMPLETED, DOC_FAILED |
| `DOC_COMPLETED` | Document processed successfully | READY_FOR_VERSIONING |
| `DOC_FAILED` | Document processing failed | (Manual intervention) |
| `READY_FOR_VERSIONING` | All required processing complete | VERSIONING_IN_PROCESS |
| `VERSIONING_IN_PROCESS` | DTA creation in progress | VERSIONED, VERSIONING_FAILED |
| `VERSIONED` | DTA created successfully | (Terminal) |
| `VERSIONING_FAILED` | DTA creation failed | (Manual intervention) |
| `EXTRACTION_ERROR` | File extraction failed | (Manual intervention) |

#### Status Transition Flow

```mermaid
flowchart LR
    subgraph Extraction["📦 File Extraction"]
        E1["READY_FOR_PROCESSING"]
        E2["EXTRACTION_ERROR"]
    end
    
    subgraph Processing["⚙️ Document Processing"]
        P1["TSDTA_PROCESSING"]
        P2["EXCEL_EXTRACTION_COMPLETED"]
        P3["DOC_PROCESSING"]
        P4["DOC_COMPLETED"]
        P5["TSDTA_FAILED"]
        P6["DOC_FAILED"]
    end
    
    subgraph Versioning["📋 DTA Creation"]
        V1["READY_FOR_VERSIONING"]
        V2["VERSIONING_IN_PROCESS"]
        V3["VERSIONED"]
        V4["VERSIONING_FAILED"]
    end
    
    E1 -->|"Excel"| P1
    E1 -->|"PDF/Word"| P3
    P1 -->|"Success"| P2
    P1 -->|"Error"| P5
    P3 -->|"Success"| P4
    P3 -->|"Error"| P6
    P2 --> V1
    P4 --> V1
    V1 --> V2
    V2 -->|"Success"| V3
    V2 -->|"Error"| V4
    
    style E2 fill:#FFCDD2,stroke:#C62828
    style P5 fill:#FFCDD2,stroke:#C62828
    style P6 fill:#FFCDD2,stroke:#C62828
    style V4 fill:#FFCDD2,stroke:#C62828
    style V3 fill:#C8E6C9,stroke:#388E3C
```

---

### `md_file_history` Table

Detailed status tracking with timestamps, error messages, and processing metadata.

```mermaid
erDiagram
    md_file_history {
        string document_id PK
        string status
        timestamp status_timestamp
        string error_message
        double processing_duration_seconds
        int retry_count
        string processing_metadata
    }
```

**Purpose**: Provides an **append-only audit log** of all status changes for each document, enabling:

```mermaid
flowchart LR
    subgraph Benefits["📊 Benefits"]
        B1["🕐 Processing History"]
        B2["🔍 Error Diagnostics"]
        B3["📈 Performance Monitoring"]
        B4["🔄 Retry Tracking"]
    end
    
    style Benefits fill:#E8F5E9,stroke:#388E3C
```

#### Example: Document Status History

```mermaid
sequenceDiagram
    participant Doc as Document
    participant Status as md_file_history
    
    Note over Doc: File extracted
    Doc->>Status: READY_FOR_PROCESSING (10:00:00)
    
    Note over Doc: Processing starts
    Doc->>Status: TSDTA_PROCESSING (10:01:00)
    
    Note over Doc: Error occurs
    Doc->>Status: TSDTA_FAILED (10:02:00)<br/>error: "Encrypted file"
    
    Note over Doc: Retry #1
    Doc->>Status: TSDTA_PROCESSING (10:05:00)<br/>retry_count: 1
    
    Note over Doc: Success!
    Doc->>Status: EXCEL_EXTRACTION_COMPLETED (10:06:00)
```

---

## ⚪ Silver Layer: Row Validation

### `status` Column

Both `md_dta_transfer_variables_draft` and `md_codelists_normalized` use the same `status` column to indicate validation results.

```mermaid
flowchart TD
    subgraph Input["📥 Input Row"]
        I1["transfer_variable_name"]
        I2["format"]
        I3["anticipated_max_length"]
        I4["transfer_file_key"]
    end
    
    subgraph Validation["🔍 Validation Rules"]
        V1{"Required<br/>fields<br/>present?"}
        V2{"Values<br/>valid?"}
    end
    
    subgraph Output["📤 status"]
        O1["✅ COMPLETED"]
        O2["⚠️ MANUAL_REVIEW_REQUIRED"]
    end
    
    Input --> V1
    V1 -->|"Yes"| V2
    V1 -->|"No"| O2
    V2 -->|"Yes"| O1
    V2 -->|"No"| O2
    
    style O1 fill:#C8E6C9,stroke:#388E3C
    style O2 fill:#FFF59D,stroke:#F9A825
```

#### Status Values

| Status | Description | Propagates to Gold? |
|--------|-------------|---------------------|
| `COMPLETED` | All required fields present and valid | ✅ Yes |
| `MANUAL_REVIEW_REQUIRED` | Missing/invalid fields needing review | ✅ Yes (flagged) |

---

### Why `MANUAL_REVIEW_REQUIRED`?

This status enables **non-blocking data flow** while ensuring quality:

```mermaid
flowchart LR
    subgraph Problem["❌ Traditional Approach"]
        P1["Invalid Row"] -->|"Rejected"| P2["Data Lost"]
    end
    
    subgraph Solution["✅ MANUAL_REVIEW Approach"]
        S1["Invalid Row"] -->|"Flagged"| S2["Data Preserved"]
        S2 --> S3["Review Queue"]
        S3 --> S4["Correction Applied"]
    end
    
    style P2 fill:#FFCDD2,stroke:#C62828
    style S4 fill:#C8E6C9,stroke:#388E3C
```

**Benefits**:
1. **Data Still Flows**: Records aren't rejected; they proceed to Gold layer
2. **Flagged for Review**: DTA is marked for manual review
3. **Full Visibility**: All validation issues captured in `notes`
4. **No Data Loss**: Even problematic records preserved for correction

#### Common Validation Failures

```mermaid
flowchart TD
    subgraph Failures["⚠️ Validation Failures"]
        F1["Missing required column<br/><i>e.g., No format value</i>"]
        F2["Invalid format value<br/><i>e.g., format = 'xyz'</i>"]
        F3["Missing codelist reference<br/><i>Empty codelist_reference</i>"]
        F4["Header detection failed<br/><i>Malformed Excel</i>"]
    end
    
    subgraph Notes["📝 notes"]
        N1["'Missing required values: format'"]
        N2["'Invalid format value: xyz'"]
        N3["'codelist_reference column missing'"]
        N4["'Could not detect header row'"]
    end
    
    F1 --> N1
    F2 --> N2
    F3 --> N3
    F4 --> N4
    
    style Failures fill:#FFF3E0,stroke:#EF6C00
```

---

## 🟡 Gold Layer: DTA Status

### `DTA.status`

DTA entity lifecycle status.

```mermaid
stateDiagram-v2
    [*] --> DRAFT: DTA created (UI)
    [*] --> ACTIVE: Historical DTA (all valid)
    [*] --> MANUAL_REVIEW: Historical DTA (has issues)
    
    DRAFT --> PENDING_APPROVAL: Submitted for review
    MANUAL_REVIEW --> PENDING_APPROVAL: Issues resolved, submitted
    
    PENDING_APPROVAL --> APPROVED: All approvers approved
    PENDING_APPROVAL --> REJECTED: Approver rejected
    
    REJECTED --> DRAFT: Revisions made
    APPROVED --> ARCHIVED: Superseded by new version
    
    MANUAL_REVIEW --> DRAFT: Issues resolved
```

#### Status Values

| Status | Description | Editable? | Color |
|--------|-------------|-----------|-------|
| `DRAFT` | DTA being created/edited | ✅ Yes | 🔵 Blue |
| `ACTIVE` | Fully validated, ready for use | ✅ Yes | 🟢 Green |
| `MANUAL_REVIEW` | Contains records needing review | ✅ Yes | 🟡 Yellow |
| `PENDING_APPROVAL` | Submitted, awaiting approval | ❌ No | 🟠 Orange |
| `APPROVED` | All approvers approved | ❌ No | 🟢 Green |
| `REJECTED` | Approver rejected | ✅ Yes (returns to DRAFT) | 🔴 Red |
| `ARCHIVED` | Superseded by newer version | ❌ No | ⚪ Gray |

```mermaid
flowchart LR
    subgraph Editable["✏️ Editable States"]
        E1["DRAFT"]
        E2["ACTIVE"]
        E3["MANUAL_REVIEW"]
        E4["REJECTED"]
    end
    
    subgraph ReadOnly["🔒 Read-Only States"]
        R1["PENDING_APPROVAL"]
        R2["APPROVED"]
        R3["ARCHIVED"]
    end
    
    style Editable fill:#E3F2FD,stroke:#1565C0
    style ReadOnly fill:#ECEFF1,stroke:#607D8B
```

---

## 🔀 Status Propagation

### Silver → Gold Status Mapping

```mermaid
flowchart TD
    subgraph Silver["⚪ Silver Layer Records"]
        S1["Row 1: COMPLETED ✅"]
        S2["Row 2: COMPLETED ✅"]
        S3["Row 3: MANUAL_REVIEW_REQUIRED ⚠️"]
        S4["Row 4: COMPLETED ✅"]
    end
    
    Check["Any MANUAL_REVIEW?"]
    
    subgraph Gold["🟡 Gold Layer"]
        G1["DTA.status = ACTIVE"]
        G2["DTA.status = MANUAL_REVIEW"]
    end
    
    Silver --> Check
    Check -->|"No"| G1
    Check -->|"Yes"| G2
    
    style S3 fill:#FFF59D,stroke:#F9A825
    style G1 fill:#C8E6C9,stroke:#388E3C
    style G2 fill:#FFF59D,stroke:#F9A825
```

| Silver `status` | Gold `DTA.status` | Impact |
|---------------------|-------------------|--------|
| All `COMPLETED` | `ACTIVE` | DTA fully validated |
| Any `MANUAL_REVIEW_REQUIRED` | `MANUAL_REVIEW` | DTA flagged for review |

### Aggregation in Gold

```mermaid
flowchart LR
    subgraph Silver["Silver Records"]
        S1["COMPLETED"]
        S2["COMPLETED"]
        S3["MANUAL_REVIEW_REQUIRED"]
        S4["COMPLETED"]
    end
    
    subgraph Aggregation["📊 Aggregation"]
        A1["completed_count: 3"]
        A2["review_required_count: 1"]
        A3["needs_review: TRUE"]
    end
    
    subgraph DTA["DTA Entity"]
        D1["status: MANUAL_REVIEW"]
    end
    
    Silver --> Aggregation --> DTA
    
    style S3 fill:#FFF59D,stroke:#F9A825
    style A3 fill:#FFF59D,stroke:#F9A825
    style D1 fill:#FFF59D,stroke:#F9A825
```

---

## 📊 Status Queries

### Find Documents by Processing Status

```sql
-- Documents stuck in processing (potential issues)
SELECT 
    document_id, 
    status, 
    status_timestamp,
    TIMESTAMPDIFF(MINUTE, status_timestamp, current_timestamp()) as minutes_stuck
FROM bronze_md.md_file_history
WHERE status IN ('TSDTA_PROCESSING', 'DOC_PROCESSING')
  AND status_timestamp < current_timestamp() - INTERVAL 1 HOUR
ORDER BY minutes_stuck DESC;
```

### Find Rows Needing Review

```sql
-- Transfer variables needing manual review
SELECT 
    trial_id,
    data_stream_type,
    transfer_variable_name,
    status,
    notes
FROM silver_md.md_dta_transfer_variables_draft
WHERE status = 'MANUAL_REVIEW_REQUIRED'
ORDER BY trial_id, transfer_variable_name;
```

### DTAs with Review Required

```sql
-- DTAs that need manual review
SELECT 
    dta_id,
    dta_number,
    trial_id,
    data_stream_type,
    data_provider_name,
    status,
    notes
FROM gold_md.DTA
WHERE status = 'MANUAL_REVIEW'
ORDER BY created_ts DESC;
```

### Processing Status Dashboard

```sql
-- Overall processing status distribution
SELECT 
    status,
    COUNT(*) as document_count,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 2) as percentage
FROM bronze_md.md_file_history
WHERE is_current = TRUE
GROUP BY status
ORDER BY document_count DESC;
```

---

## 🔗 Related Documentation

- [01_job_architecture_design.readme.md](./01_job_architecture_design.readme.md) - Processing pipeline flow
- [06_dta_approval_design.readme.md](./06_dta_approval_design.readme.md) - Approval workflow & workflow states
- [04_versioning_design.readme.md](./04_versioning_design.readme.md) - Version registry status
- [02_schema_design.readme.md](./02_schema_design.readme.md) - Full schema documentation

---

*Last Updated: December 2025*

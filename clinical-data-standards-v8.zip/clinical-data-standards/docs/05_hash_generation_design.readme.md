# Hash Generation Architecture

> **Purpose**: Enable deduplication and identification of semantically identical records across trials, vendors, and data streams in the Clinical Data Standards library.

## Overview

The hash generation system creates deterministic, content-based identifiers (`definition_hash`) that uniquely identify a variable definition regardless of its source. This enables:

- **Cross-trial deduplication**: Same variable definition used in multiple trials = single library entry
- **Change detection**: Modified definitions get new hashes, preserving history
- **Versioning support**: Hash + version forms composite key in gold layer

```mermaid
flowchart LR
    subgraph Silver["⚪ Silver Layer"]
        A["md_dta_transfer_variables_draft<br/>Full lineage (per trial/vendor)"]
    end
    
    subgraph Gold["🟡 Gold Layer"]
        B["md_dta_transfer_variables<br/>Deduplicated (by hash)"]
    end
    
    A -->|"GROUP BY definition_hash"| B
    
    style Silver fill:#BBDEFB,stroke:#1565C0
    style Gold fill:#FFF59D,stroke:#F9A825
```

---

## 🔑 Key Concepts

### What Gets Hashed?

The hash is computed from **semantic fields only** - the fields that define what a variable IS, not where it came from.

```mermaid
flowchart LR
    subgraph Included["✅ INCLUDED (Semantic)"]
        direction TB
        I1["transfer_variable_name"]
        I2["format"]
        I3["anticipated_max_length"]
        I4["transfer_file_key"]
        I5["populate_for_all_records"]
        I6["codelist_values"]
    end
    
    subgraph Excluded["❌ EXCLUDED (Context)"]
        direction TB
        E1["trial_id"]
        E2["data_stream_type"]
        E3["data_provider_name"]
        E4["parent_document_id"]
        E5["status"]
        E6["notes"]
    end
    
    Included -->|"SHA256"| Hash["#️⃣ definition_hash"]
    
    style Included fill:#C8E6C9,stroke:#388E3C
    style Excluded fill:#FFCDD2,stroke:#C62828
    style Hash fill:#FFF59D,stroke:#F9A825
```

| Included (Semantic) | Excluded (Context) |
|---------------------|-------------------|
| `transfer_variable_name` | `trial_id` |
| `format` | `data_stream_type` |
| `anticipated_max_length` | `data_provider_name` |
| `transfer_file_key` | `parent_document_id` |
| `populate_for_all_records` | `status` |
| `codelist_values` | `notes` |

### Same Definition = Same Hash

```mermaid
flowchart LR
    subgraph TrialA["Trial A, Vendor X"]
        A1["SubjectID<br/>text, 50, true, false"]
    end
    
    subgraph TrialB["Trial B, Vendor Y"]
        B1["SubjectID<br/>text, 50, true, false"]
    end
    
    subgraph TrialC["Trial C, Vendor X"]
        C1["SubjectID<br/>text, 100, true, false"]
    end
    
    A1 -->|"hash"| H1["abc123... ✅"]
    B1 -->|"hash"| H1
    C1 -->|"hash"| H2["def456... ❌"]
    
    H1 -.->|"SAME!"| Note1["Same semantic<br/>definition"]
    H2 -.->|"Different"| Note2["max_length<br/>changed"]
    
    style H1 fill:#C8E6C9,stroke:#388E3C
    style H2 fill:#FFCDD2,stroke:#C62828
    style TrialA fill:#E3F2FD,stroke:#1565C0
    style TrialB fill:#E3F2FD,stroke:#1565C0
    style TrialC fill:#FFF3E0,stroke:#EF6C00
```

---

## 📐 Silver Layer: Full Lineage

### Schema: `md_dta_transfer_variables_draft`

```mermaid
classDiagram
    class md_dta_transfer_variables_draft {
        🔑 transfer_variable_field_id PK
        ─────────────────────────────
        📎 parent_document_id FK
        📎 trial_id
        📎 data_stream_type
        📎 data_provider_name
        ─────────────────────────────
        🔶 transfer_variable_name
        🔶 format
        🔶 anticipated_max_length
        🔶 transfer_file_key
        🔶 populate_for_all_records
        🔶 codelist_values
        ─────────────────────────────
        #️⃣ definition_hash
        📋 status
    }
    
    note for md_dta_transfer_variables_draft "🔶 = Hashed Fields\n📎 = Context (not hashed)\n#️⃣ = Computed Hash"
```

**Silver stores EVERY row** from every trial/vendor/stream with full lineage.

### Example: Same Definition from Two Sources

| trial_id | provider | transfer_variable_name | format | max_length | definition_hash |
|----------|----------|------------------------|--------|------------|-----------------|
| TRIAL001 | VendorA | SubjectID | text | 50 | `abc123...` |
| TRIAL002 | VendorB | SubjectID | text | 50 | `abc123...` |
| TRIAL001 | VendorA | Age | numeric | 3 | `def456...` |

---

## 🏆 Gold Layer: Deduplicated Library

### Schema: `md_dta_transfer_variables`

```mermaid
classDiagram
    class md_dta_transfer_variables {
        🔑 definition_hash PK
        🔑 version PK
        ─────────────────────────────
        📝 transfer_variable_name
        📝 transfer_variable_label
        📝 format
        📝 anticipated_max_length
        📝 codelist_values
        ─────────────────────────────
        📊 used_in_trials ARRAY~STRUCT~
        📊 usage_count INT
        📊 completed_count INT
        📊 review_required_count INT
    }
    
    class used_in_trials_struct {
        trial_id
        data_stream_type
        data_provider_name
        status
    }
    
    md_dta_transfer_variables *-- used_in_trials_struct : contains
    
    note for md_dta_transfer_variables "📝 = Definition Fields\n📊 = Aggregated Usage Stats"
```

**Gold stores ONE row per unique definition**, with aggregated usage info.

### Aggregation Logic

```sql
-- Silver to Gold transformation
SELECT 
    definition_hash,                              -- GROUP BY key
    FIRST(transfer_variable_name),                -- Pick first (all same)
    FIRST(format),
    FIRST(anticipated_max_length),
    COLLECT_SET(STRUCT(                           -- Aggregate usage
        trial_id, 
        data_stream_type, 
        data_provider_name,
        status
    )) AS used_in_trials,
    COUNT(*) AS usage_count,
    SUM(CASE WHEN status = 'COMPLETED' THEN 1 ELSE 0 END) AS completed_count,
    SUM(CASE WHEN status = 'MANUAL_REVIEW_REQUIRED' THEN 1 ELSE 0 END) AS review_required_count
FROM silver_md.md_dta_transfer_variables_draft
WHERE definition_hash IS NOT NULL
GROUP BY definition_hash
```

### Example: Deduplicated Result

| definition_hash | variable_name | usage_count | used_in_trials |
|-----------------|---------------|-------------|----------------|
| `abc123...` | SubjectID | 2 | [{TRIAL001, VendorA}, {TRIAL002, VendorB}] |
| `def456...` | Age | 1 | [{TRIAL001, VendorA}] |

---

## ⚙️ Framework Implementation

### Hash Computation Functions

The framework provides two hash functions in `clinical_data_standards_framework`:

#### 1. `compute_definition_hash()` - Python Dict (Row-Level)

```python
from clinical_data_standards_framework import compute_definition_hash

record = {
    "transfer_variable_name": "SubjectID",
    "format": "text",
    "anticipated_max_length": 50,
    "transfer_file_key": True,
    "populate_for_all_records": False,
    "codelist_values": None
}

hash_fields = [
    "transfer_variable_name", 
    "format", 
    "anticipated_max_length",
    "transfer_file_key",
    "populate_for_all_records",
    "codelist_values"
]

hash_value = compute_definition_hash(record, hash_fields)
# Returns: "a1b2c3d4e5f6..." (64-char SHA256 hex)
```

#### 2. `compute_definition_hash_spark()` - Spark DataFrame (Batch)

```python
from clinical_data_standards_framework import compute_definition_hash_spark

df = spark.table("silver_md.md_dta_transfer_variables_draft")

hash_fields = [
    "transfer_variable_name", 
    "format", 
    "anticipated_max_length",
    "transfer_file_key",
    "populate_for_all_records",
    "codelist_values"
]

df_with_hash = compute_definition_hash_spark(df, hash_fields, "definition_hash")
```

### Hash Algorithm Details

```mermaid
flowchart LR
    A["📥 Input Fields"] --> B["🔤 Sort Alphabetically"]
    B --> C["🔧 Normalize Values"]
    C --> D["🔗 Concatenate with |"]
    D --> E["#️⃣ SHA256"]
    E --> F["📤 64-char hex"]
    
    style A fill:#E3F2FD,stroke:#1565C0
    style E fill:#FFF59D,stroke:#F9A825
    style F fill:#C8E6C9,stroke:#388E3C
```

#### Normalization Rules

| Input Type | Normalized Output |
|------------|-------------------|
| NULL | `""` (empty string) |
| Boolean TRUE | `"1"` |
| Boolean FALSE | `"0"` |
| Numbers | `str(value)` |
| Strings | `lowercase + trim` |

#### Example Walkthrough

```mermaid
flowchart TD
    subgraph Input["📥 Raw Input Values"]
        I1["anticipated_max_length: 50"]
        I2["codelist_values: NULL"]
        I3["format: 'Text'"]
        I4["populate_for_all_records: FALSE"]
        I5["transfer_file_key: TRUE"]
        I6["transfer_variable_name: ' SubjectID '"]
    end
    
    subgraph Sorted["🔤 Sorted Alphabetically"]
        S1["anticipated_max_length"]
        S2["codelist_values"]
        S3["format"]
        S4["populate_for_all_records"]
        S5["transfer_file_key"]
        S6["transfer_variable_name"]
    end
    
    subgraph Normalized["🔧 Normalized"]
        N1["'50'"]
        N2["''"]
        N3["'text'"]
        N4["'0'"]
        N5["'1'"]
        N6["'subjectid'"]
    end
    
    Input --> Sorted --> Normalized
    Normalized --> Concat["🔗 '50||text|0|1|subjectid'"]
    Concat --> Hash["#️⃣ SHA256 → 'a1b2c3d4e5f6789...'"]
    
    style Input fill:#E3F2FD,stroke:#1565C0
    style Sorted fill:#FFF3E0,stroke:#EF6C00
    style Normalized fill:#F3E5F5,stroke:#7B1FA2
    style Hash fill:#C8E6C9,stroke:#388E3C
```

---

## 📋 Configuration-Driven Approach

### Configuring Hash Fields (clinical_data_standards.yaml)

```yaml
pipelines:
  tsdta_processor:
    validation:
      transfer_metadata:
        # Enable hash computation
        compute_definition_hash: true
        
        # Fields to include in hash (semantic fields only)
        definition_hash_fields:
          - transfer_variable_name
          - transfer_variable_order
          - format
          - anticipated_max_length
          - transfer_file_key
          - populate_for_all_records
          - codelist_values
```

### Extending to Other Entities (e.g., Codelists)

The hash framework is **entity-agnostic**. To add hashing for codelists:

```mermaid
flowchart TB
    subgraph Framework["🔧 Hash Framework"]
        F1["compute_definition_hash()"]
        F2["compute_definition_hash_spark()"]
    end
    
    subgraph Config["⚙️ YAML Configuration"]
        C1["transfer_metadata:<br/>definition_hash_fields"]
        C2["codelists:<br/>definition_hash_fields"]
        C3["future_entity:<br/>definition_hash_fields"]
    end
    
    subgraph Entities["📦 Entity Types"]
        E1["Transfer Variables<br/>definition_hash"]
        E2["Codelists<br/>codelist_hash"]
        E3["Future Entity<br/>entity_hash"]
    end
    
    Config --> Framework
    Framework --> Entities
    
    style Framework fill:#E8F5E9,stroke:#388E3C
    style Config fill:#FFF3E0,stroke:#EF6C00
    style Entities fill:#E3F2FD,stroke:#1565C0
```

```yaml
pipelines:
  tsdta_processor:
    validation:
      codelists:
        # Enable hash computation for codelists
        compute_definition_hash: true
        definition_hash_fields:
          - codelist_reference
          - code_value
          - sdtm_value  # Optional: include if semantically important
```

Usage in notebook:

```python
# Read config
codelist_config = pipeline_config.get('validation', {}).get('codelists', {})
hash_enabled = codelist_config.get('compute_definition_hash', False)
hash_fields = codelist_config.get('definition_hash_fields', [])

# Compute hash if enabled
if hash_enabled and hash_fields:
    df = compute_definition_hash_spark(df, hash_fields, "codelist_hash")
```

### Generic Pattern for Any Entity

```python
def add_hash_column(df, entity_config, hash_column_name="definition_hash"):
    """
    Generic hash computation based on config.
    
    Args:
        df: Input DataFrame
        entity_config: Config dict with 'compute_definition_hash' and 'definition_hash_fields'
        hash_column_name: Output column name
    
    Returns:
        DataFrame with hash column added (or unchanged if hashing disabled)
    """
    if not entity_config.get('compute_definition_hash', False):
        return df
    
    hash_fields = entity_config.get('definition_hash_fields', [])
    if not hash_fields:
        return df
    
    return compute_definition_hash_spark(df, hash_fields, hash_column_name)
```

---

## 🔄 Data Flow: Insert Same Row Twice

### Scenario: Same variable from two different trials

**Step 1: First Trial Processed (TRIAL001)**

```mermaid
flowchart LR
    A["TRIAL001<br/>SubjectID"] -->|"hash: abc123"| B["Silver<br/>1 row"]
    B -->|"GROUP BY hash"| C["Gold<br/>1 row<br/>usage_count=1"]
```

Silver:
| field_id | trial_id | variable_name | definition_hash |
|----------|----------|---------------|-----------------|
| uuid-001 | TRIAL001 | SubjectID | `abc123...` |

Gold:
| definition_hash | variable_name | usage_count | used_in_trials |
|-----------------|---------------|-------------|----------------|
| `abc123...` | SubjectID | 1 | [{TRIAL001}] |

---

**Step 2: Second Trial Processed (TRIAL002, same definition)**

```mermaid
flowchart LR
    A["TRIAL002<br/>SubjectID"] -->|"hash: abc123"| B["Silver<br/>2 rows"]
    B -->|"GROUP BY hash"| C["Gold<br/>1 row<br/>usage_count=2"]
```

Silver: (APPENDED - full lineage preserved)
| field_id | trial_id | variable_name | definition_hash |
|----------|----------|---------------|-----------------|
| uuid-001 | TRIAL001 | SubjectID | `abc123...` |
| uuid-002 | **TRIAL002** | SubjectID | `abc123...` |

Gold: (MERGED - deduplicated by hash)
| definition_hash | variable_name | usage_count | used_in_trials |
|-----------------|---------------|-------------|----------------|
| `abc123...` | SubjectID | **2** | [{TRIAL001}, {**TRIAL002**}] |

### Key Points

```mermaid
flowchart TB
    subgraph Silver["⚪ SILVER LAYER"]
        direction TB
        S1["Write Mode: APPEND"]
        S2["Deduplication: None"]
        S3["Purpose: Full lineage preservation"]
    end
    
    subgraph Gold["🟡 GOLD LAYER"]
        direction TB
        G1["Write Mode: MERGE by hash"]
        G2["Deduplication: Yes"]
        G3["Purpose: Deduplicated library"]
    end
    
    Silver -->|"GROUP BY<br/>definition_hash"| Gold
    
    style Silver fill:#BBDEFB,stroke:#1565C0
    style Gold fill:#FFF59D,stroke:#F9A825
```

| Layer | Write Mode | Deduplication | Purpose |
|-------|------------|---------------|---------|
| **Silver** | APPEND | None | Full lineage preservation |
| **Gold** | MERGE by hash | Yes | Deduplicated library |

---

## 🧪 Validation Queries

### Find Duplicate Definitions Across Trials

```sql
SELECT 
    definition_hash,
    transfer_variable_name,
    COUNT(DISTINCT trial_id) as trial_count,
    COLLECT_SET(trial_id) as trials
FROM silver_md.md_dta_transfer_variables_draft
GROUP BY definition_hash, transfer_variable_name
HAVING COUNT(DISTINCT trial_id) > 1
ORDER BY trial_count DESC
```

### Verify Hash Consistency

```sql
-- All rows with same hash should have same semantic values
SELECT 
    definition_hash,
    COUNT(DISTINCT transfer_variable_name) as name_variants,
    COUNT(DISTINCT format) as format_variants,
    COUNT(DISTINCT anticipated_max_length) as length_variants
FROM silver_md.md_dta_transfer_variables_draft
GROUP BY definition_hash
HAVING name_variants > 1 OR format_variants > 1 OR length_variants > 1
-- Should return 0 rows if hashing is correct
```

### Check Hash Coverage

```sql
SELECT 
    COUNT(*) as total_rows,
    COUNT(definition_hash) as rows_with_hash,
    COUNT(*) - COUNT(definition_hash) as rows_without_hash,
    ROUND(COUNT(definition_hash) * 100.0 / COUNT(*), 2) as coverage_pct
FROM silver_md.md_dta_transfer_variables_draft
```

---

## 📁 Related Files

| File | Description |
|------|-------------|
| `src/clinical_data_standards_framework/utils.py` | `compute_definition_hash()`, `compute_definition_hash_spark()` |
| `config/clinical_data_standards.yaml` | Hash field configuration per entity |
| `notebooks/.../nb_tsdta_transfer_variables_processor.ipynb` | Silver hash computation |
| `notebooks/.../nb_create_historical_dta_major.ipynb` | Gold aggregation by hash |

---

## 🔑 Design Principles

```mermaid
mindmap
  root((Hash<br/>Generation))
    Deterministic
      Same input → Same hash
      Reproducible across runs
    Content-Based
      Semantic meaning only
      Not source context
    Config-Driven
      YAML configuration
      Per entity type
    Framework Function
      compute_definition_hash
      compute_definition_hash_spark
    Sorted Fields
      Alphabetical order
      Field order independent
    Null-Safe
      NULL → empty string
      Consistent handling
```

| Principle | Description |
|-----------|-------------|
| **Deterministic** | Same input always produces same hash |
| **Content-Based** | Hash reflects semantic meaning, not source context |
| **Config-Driven** | Hash fields configurable per entity type in YAML |
| **Framework Function** | Reusable `compute_definition_hash_spark()` for all entities |
| **Sorted Fields** | Field order doesn't affect hash (sorted internally) |
| **Null-Safe** | NULL values handled consistently (→ empty string) |

---

## 🔗 Related Documentation

- [02_schema_design.readme.md](./02_schema_design.readme.md) - Full schema documentation
- [04_versioning_design.readme.md](./04_versioning_design.readme.md) - How hash + version form composite key

---

*Last Updated: December 2025*


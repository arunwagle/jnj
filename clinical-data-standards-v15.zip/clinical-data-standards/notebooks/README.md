# Notebooks

This directory contains Databricks notebooks for the {{.project_name}} platform.

## Structure

```
notebooks/
├── data_engineering/       # Data engineering notebooks
│   ├── nb_dlt_{{.pipeline_name}}.py         # DLT pipeline
│   ├── nb_job_setup.py                     # Job setup utilities
│   └── nb_load_landing_zone.py             # Data loading
├── ml/                     # Machine learning notebooks
│   ├── 01_feature_engineering.py
│   ├── 02_model_training.py
│   ├── 03_model_evaluation.py
│   ├── 04_model_registration.py
│   └── 05_batch_inference.py
└── integration_tests/      # Integration test notebooks
    └── nb_{{.pipeline_name}}_integration_test.py
```

## Usage

### Data Engineering Notebooks

**DLT Pipeline** (`nb_dlt_{{.pipeline_name}}.py`):
- Defines bronze/silver/gold layers
- Implements data quality rules
- Supports CDC (Change Data Capture)

**Job Setup** (`nb_job_setup.py`):
- Initialize job parameters
- Set up configuration
- Create necessary schemas

**Load Landing Zone** (`nb_load_landing_zone.py`):
- Load data from external sources
- Stage data in landing zone
- Prepare for DLT processing

### ML Notebooks

**01 - Feature Engineering**:
- Create features from raw data
- Feature transformations
- Save feature tables

**02 - Model Training**:
- Train ML models
- Log experiments to MLflow
- Track parameters and metrics

**03 - Model Evaluation**:
- Evaluate model performance
- Generate metrics and visualizations
- Compare models

**04 - Model Registration**:
- Register models in Unity Catalog
- Create model versions
- Set model aliases

**05 - Batch Inference**:
- Load models from registry
- Run predictions on batch data
- Save results to tables

### Integration Tests

Test notebooks that validate:
- Pipeline execution
- Data quality
- Model performance
- End-to-end workflows

## Best Practices

1. **Parameterization**: Use widgets for notebook parameters
2. **Idempotency**: Make notebooks re-runnable
3. **Documentation**: Add markdown cells with explanations
4. **Error Handling**: Use try-except blocks
5. **Logging**: Log important operations and errors

## Development Workflow

1. **Develop locally** using Databricks Repos or VS Code
2. **Test** in development workspace
3. **Version control** through Git
4. **Deploy** via DAB bundle
5. **Schedule** through jobs

## Converting Notebooks

To convert between formats:

```bash
# Python to Databricks notebook
databricks workspace import notebook.py /Workspace/path --language PYTHON

# Databricks notebook to Python
databricks workspace export /Workspace/path notebook.py --format SOURCE
```

## Resources

- [Databricks Notebooks Guide](https://docs.databricks.com/notebooks/)
- [DLT Documentation](https://docs.databricks.com/delta-live-tables/)
- [MLflow on Databricks](https://docs.databricks.com/mlflow/)


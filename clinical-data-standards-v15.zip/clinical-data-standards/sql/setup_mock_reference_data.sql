-- ============================================================================
-- Setup Mock Reference Data for Study Management
-- ============================================================================
-- This script creates and populates the following tables:
--   1. md_study - Study registry with status tracking
--   2. md_vendor - Mock vendor list
--   3. md_data_stream - Mock data stream types
--   4. md_protocol - Protocol document registry
-- ============================================================================

-- Set catalog and schema context
USE CATALOG IDENTIFIER(:catalog_name);
USE SCHEMA gold_md;

-- ============================================================================
-- Table 1: md_study - Study Registry
-- ============================================================================
CREATE TABLE IF NOT EXISTS md_study (
    study_id STRING NOT NULL COMMENT 'Unique study identifier',
    study_title STRING COMMENT 'Study title/name',
    study_description STRING COMMENT 'Study description',
    status STRING COMMENT 'Study status: IN_PROGRESS, PARSING_IN_PROGRESS, PARSING_COMPLETED, PARSING_FAILED, COMPLETED',
    protocol_id STRING COMMENT 'Associated protocol document ID',
    created_by_principal STRING COMMENT 'User who created the study',
    created_ts TIMESTAMP COMMENT 'Creation timestamp',
    last_updated_by_principal STRING COMMENT 'User who last updated the study',
    last_updated_ts TIMESTAMP COMMENT 'Last update timestamp'
) USING DELTA
COMMENT 'Study registry for clinical data management';

-- ============================================================================
-- Table 2: md_vendor - Vendor Registry
-- ============================================================================
CREATE TABLE IF NOT EXISTS md_vendor (
    vendor_id STRING NOT NULL COMMENT 'Unique vendor identifier',
    vendor_name STRING NOT NULL COMMENT 'Vendor name',
    vendor_description STRING COMMENT 'Vendor description',
    is_active BOOLEAN COMMENT 'Whether vendor is active',
    created_ts TIMESTAMP COMMENT 'Creation timestamp'
) USING DELTA
COMMENT 'Vendor registry for data providers';

-- ============================================================================
-- Table 3: md_data_stream - Data Stream Types
-- ============================================================================
CREATE TABLE IF NOT EXISTS md_data_stream (
    data_stream_id STRING NOT NULL COMMENT 'Unique data stream identifier',
    data_stream_name STRING NOT NULL COMMENT 'Data stream name (e.g., ECG, Labs)',
    data_stream_description STRING COMMENT 'Data stream description',
    is_active BOOLEAN COMMENT 'Whether data stream type is active',
    created_ts TIMESTAMP COMMENT 'Creation timestamp'
) USING DELTA
COMMENT 'Data stream type registry';

-- ============================================================================
-- Table 4: md_protocol - Protocol Document Registry
-- ============================================================================
CREATE TABLE IF NOT EXISTS md_protocol (
    protocol_id STRING NOT NULL COMMENT 'Unique protocol identifier',
    document_id STRING COMMENT 'Associated document ID from file history',
    study_id STRING NOT NULL COMMENT 'Associated study ID',
    protocol_version STRING COMMENT 'Protocol version',
    status STRING COMMENT 'Protocol status: PENDING, PARSING, COMPLETED, FAILED',
    created_by_principal STRING COMMENT 'User who created the protocol entry',
    created_ts TIMESTAMP COMMENT 'Creation timestamp',
    last_updated_by_principal STRING COMMENT 'User who last updated',
    last_updated_ts TIMESTAMP COMMENT 'Last update timestamp'
) USING DELTA
COMMENT 'Protocol document registry linking studies to protocol documents';

-- ============================================================================
-- Insert Mock Vendors
-- ============================================================================
MERGE INTO md_vendor AS target
USING (
    SELECT 'V001' as vendor_id, 'LabCorp' as vendor_name, 'Central laboratory services' as vendor_description
    UNION ALL
    SELECT 'V002', 'Covance', 'Drug development services'
    UNION ALL
    SELECT 'V003', 'IQVIA', 'Clinical research and technology'
    UNION ALL
    SELECT 'V004', 'PPD', 'Contract research organization'
    UNION ALL
    SELECT 'V005', 'Medidata', 'Clinical data technology'
) AS source
ON target.vendor_id = source.vendor_id
WHEN NOT MATCHED THEN INSERT (vendor_id, vendor_name, vendor_description, is_active, created_ts)
VALUES (source.vendor_id, source.vendor_name, source.vendor_description, true, current_timestamp());

-- ============================================================================
-- Insert Mock Data Streams
-- ============================================================================
MERGE INTO md_data_stream AS target
USING (
    SELECT 'DS001' as data_stream_id, 'ECG' as data_stream_name, 'Electrocardiogram data' as data_stream_description
    UNION ALL
    SELECT 'DS002', 'Labs', 'Laboratory test results'
    UNION ALL
    SELECT 'DS003', 'Imaging', 'Medical imaging data'
    UNION ALL
    SELECT 'DS004', 'Biomarkers', 'Biomarker analysis data'
    UNION ALL
    SELECT 'DS005', 'PK/PD', 'Pharmacokinetic/Pharmacodynamic data'
    UNION ALL
    SELECT 'DS006', 'Safety', 'Safety monitoring data'
    UNION ALL
    SELECT 'DS007', 'ePRO', 'Electronic patient-reported outcomes'
    UNION ALL
    SELECT 'DS008', 'Genomics', 'Genomic sequencing data'
) AS source
ON target.data_stream_id = source.data_stream_id
WHEN NOT MATCHED THEN INSERT (data_stream_id, data_stream_name, data_stream_description, is_active, created_ts)
VALUES (source.data_stream_id, source.data_stream_name, source.data_stream_description, true, current_timestamp());

-- ============================================================================
-- Verification queries (commented out - run manually if needed)
-- ============================================================================
-- SELECT * FROM md_study;
-- SELECT * FROM md_vendor;
-- SELECT * FROM md_data_stream;
-- SELECT * FROM md_protocol;

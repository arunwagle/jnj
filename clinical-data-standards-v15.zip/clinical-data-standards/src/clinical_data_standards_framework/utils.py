"""
Common utilities for Clinical Data Standards Framework
"""

import io
import os
import re
import uuid
import base64
import zipfile
import hashlib
import logging
from datetime import datetime
from typing import Dict, List, Optional

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.functions import current_timestamp, lit
from pyspark.sql.types import (
    StructType, StructField, StringType, TimestampType, LongType, 
    BinaryType, IntegerType, BooleanType, ArrayType, DoubleType
)


# ============================================================================
# Logging Setup
# ============================================================================

def setup_logging(name: str = "clinical_data_standards") -> logging.Logger:
    """
    Setup logging configuration
    
    Args:
        name: Logger name
        
    Returns:
        Configured logger instance
    """
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    return logging.getLogger(name)


# ============================================================================
# Metadata Definition Hash Functions
# ============================================================================

def compute_definition_hash(record_dict: dict, hash_fields: list) -> str:
    """
    Compute SHA256 hash of metadata definition based on specified fields.
    
    Creates deterministic hash for clinical metadata definitions by:
    - Sorting fields alphabetically for consistency
    - Converting None to empty string
    - Lowercasing string values
    - Converting booleans to '1'/'0'
    - Using pipe delimiter
    
    This enables creating a "clinical metadata library" where the same variable
    definition across different trials/vendors/streams produces the same hash,
    allowing gold tables to deduplicate and track usage.
    
    Args:
        record_dict: Dictionary with field name -> value mappings
        hash_fields: List of field names to include in hash (order doesn't matter,
                    will be sorted internally for determinism)
        
    Returns:
        SHA256 hash string (64 hex characters)
        
    Example:
        >>> record = {
        ...     'transfer_variable_name': 'SUBJECT_ID',
        ...     'format': 'text',
        ...     'transfer_file_key': True,
        ...     'codelist_id': None
        ... }
        >>> fields = ['transfer_variable_name', 'format', 'transfer_file_key', 'codelist_id']
        >>> hash_val = compute_definition_hash(record, fields)
        >>> print(len(hash_val))
        64
        
    Note:
        - Hash includes data_provider_name and data_stream_type for vendor-specific templates
        - Same definition from same vendor/stream = same hash
        - Missing fields are treated as empty string
        - Field order in hash_fields doesn't matter (sorted internally)
    """
    values = []
    
    # Sort fields alphabetically for deterministic ordering
    for field in sorted(hash_fields):
        val = record_dict.get(field)
        
        # Normalize values for consistent hashing
        if val is None:
            values.append('')
        elif isinstance(val, bool):
            values.append('1' if val else '0')
        elif isinstance(val, (int, float)):
            values.append(str(val))
        else:
            # String values: lowercase and strip whitespace
            values.append(str(val).lower().strip())
    
    # Combine with pipe delimiter and hash
    combined = '|'.join(values)
    return hashlib.sha256(combined.encode('utf-8')).hexdigest()


def compute_definition_hash_spark(
    df: DataFrame, 
    hash_fields: list, 
    output_column: str = "definition_hash"
) -> DataFrame:
    """
    Add definition_hash column to Spark DataFrame using SHA2.
    
    Computes a deterministic SHA256 hash across specified columns for each row.
    This is the Spark DataFrame equivalent of compute_definition_hash() for
    batch processing in notebooks.
    
    Args:
        df: Spark DataFrame containing the columns to hash
        hash_fields: List of column names to include in hash (will be sorted)
        output_column: Name of the output hash column (default: "definition_hash")
        
    Returns:
        DataFrame with new hash column added
        
    Example:
        >>> df = spark.table("silver_md.md_dta_transfer_variables_draft")
        >>> hash_fields = ['transfer_variable_name', 'format', 'codelist_id']
        >>> df_with_hash = compute_definition_hash_spark(df, hash_fields)
        >>> df_with_hash.select('transfer_variable_name', 'definition_hash').show()
        
    Note:
        - Handles NULL values (converts to empty string)
        - Booleans converted to '1'/'0'
        - Numbers converted to strings
        - Strings are lowercased and trimmed
        - Fields are sorted alphabetically for determinism
    """
    # Sort fields for deterministic ordering
    sorted_fields = sorted(hash_fields)
    
    # Build concat expressions for each field (handle nulls, types)
    concat_exprs = []
    for field in sorted_fields:
        col_ref = F.col(field)
        
        # Handle different data types
        expr = (
            F.when(col_ref.isNull(), F.lit(''))
            .when(col_ref.cast('string') == 'true', F.lit('1'))  # Boolean true
            .when(col_ref.cast('string') == 'false', F.lit('0'))  # Boolean false
            .otherwise(F.lower(F.trim(col_ref.cast('string'))))  # Everything else
        )
        concat_exprs.append(expr)
    
    # Create pipe-delimited string and compute SHA256 hash
    return df.withColumn(
        output_column,
        F.sha2(F.concat_ws('|', *concat_exprs), 256)
    )


# ============================================================================
# Spark Session & Configuration
# ============================================================================

def get_spark_session(app_name: str = "clinical_data_standards") -> SparkSession:
    """
    Get or create Spark session
    
    Args:
        app_name: Name for the Spark application
        
    Returns:
        SparkSession instance
    """
    return SparkSession.builder.appName(app_name).getOrCreate()


def get_catalog_config(spark: SparkSession, 
                       catalog: str = "main",
                       bronze_schema: str = "bronze",
                       silver_schema: str = "silver",
                       gold_schema: str = "gold") -> Dict[str, str]:
    """
    Get catalog configuration from Spark conf with fallback defaults
    
    Args:
        spark: SparkSession instance
        catalog: Default catalog name
        bronze_schema: Default bronze schema name
        silver_schema: Default silver schema name
        gold_schema: Default gold schema name
        
    Returns:
        Dictionary with catalog configuration
    """
    return {
        "catalog": spark.conf.get("catalog", catalog),
        "bronze_schema": spark.conf.get("bronze_schema", bronze_schema),
        "silver_schema": spark.conf.get("silver_schema", silver_schema),
        "gold_schema": spark.conf.get("gold_schema", gold_schema),
        "table_suffix": spark.conf.get("table_suffix", "")
    }


# ============================================================================
# Path Utilities
# ============================================================================

def dbfs_to_local(dbfs_path: str) -> str:
    """
    Convert dbfs:/Volumes/... path to /Volumes/... local path
    On modern UC clusters, /Volumes is the correct writable path.
    
    Args:
        dbfs_path: Path starting with dbfs:/Volumes/
        
    Returns:
        Local filesystem path starting with /Volumes/
        
    Raises:
        ValueError: If path doesn't start with dbfs:/Volumes/
    """
    if dbfs_path.startswith("dbfs:/Volumes/"):
        return dbfs_path.replace("dbfs:/", "/")
    else:
        raise ValueError(f"Unexpected path (expected dbfs:/Volumes/...): {dbfs_path}")


def local_to_dbfs(local_path: str) -> str:
    """
    Convert /Volumes/... local path to dbfs:/Volumes/... path
    
    Args:
        local_path: Path starting with /Volumes/
        
    Returns:
        DBFS path starting with dbfs:/Volumes/
        
    Raises:
        ValueError: If path doesn't start with /Volumes/
    """
    if local_path.startswith("/Volumes/"):
        return local_path.replace("/", "dbfs:/", 1)
    else:
        raise ValueError(f"Unexpected local path (expected /Volumes/...): {local_path}")


def build_volume_path(catalog: str, 
                     schema: str, 
                     volume: str, 
                     subdir: str = "", 
                     use_dbfs_prefix: bool = True) -> str:
    """
    Build a Unity Catalog Volume path
    
    Args:
        catalog: Catalog name
        schema: Schema name
        volume: Volume name
        subdir: Optional subdirectory path within the volume
        use_dbfs_prefix: If True, returns dbfs:/Volumes/..., else /Volumes/...
        
    Returns:
        Constructed volume path
    """
    prefix = "dbfs:/Volumes" if use_dbfs_prefix else "/Volumes"
    base_path = f"{prefix}/{catalog}/{schema}/{volume}"
    
    if subdir:
        base_path = f"{base_path}/{subdir.strip('/')}"
    
    return base_path


# ============================================================================
# DataFrame Utilities
# ============================================================================

def add_audit_columns(df: DataFrame) -> DataFrame:
    """
    Add standard audit columns to DataFrame
    
    Args:
        df: Input DataFrame
        
    Returns:
        DataFrame with audit columns added
    """
    return df.withColumn("_processing_timestamp", F.current_timestamp()) \
             .withColumn("_processing_date", F.current_date())


def validate_schema(df: DataFrame, required_columns: List[str]) -> bool:
    """
    Validate that DataFrame has required columns
    
    Args:
        df: DataFrame to validate
        required_columns: List of required column names
        
    Returns:
        True if all required columns are present
        
    Raises:
        ValueError: If required columns are missing
    """
    df_columns = set(df.columns)
    missing = set(required_columns) - df_columns
    
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    
    return True


# ============================================================================
# Table I/O Utilities
# ============================================================================

def write_table(
    df: DataFrame,
    catalog: str,
    schema: str,
    table: str,
    mode: str = "append",
    partition_by: Optional[List[str]] = None
) -> None:
    """
    Write DataFrame to Unity Catalog table
    
    Args:
        df: DataFrame to write
        catalog: Catalog name
        schema: Schema name
        table: Table name
        mode: Write mode (append, overwrite, etc.)
        partition_by: Optional list of columns to partition by
    """
    full_table_name = f"{catalog}.{schema}.{table}"
    
    writer = df.write.mode(mode).format("delta")
    
    if partition_by:
        writer = writer.partitionBy(*partition_by)
    
    writer.saveAsTable(full_table_name)
    
    logging.info(f"Successfully wrote to {full_table_name}")


def read_table(
    spark: SparkSession,
    catalog: str,
    schema: str,
    table: str
) -> DataFrame:
    """
    Read table from Unity Catalog
    
    Args:
        spark: SparkSession instance
        catalog: Catalog name
        schema: Schema name
        table: Table name
        
    Returns:
        DataFrame with table data
    """
    full_table_name = f"{catalog}.{schema}.{table}"
    return spark.table(full_table_name)


def optimize_table(
    spark: SparkSession,
    catalog: str,
    schema: str,
    table: str,
    zorder_by: Optional[List[str]] = None
) -> None:
    """
    Optimize Delta table
    
    Args:
        spark: SparkSession instance
        catalog: Catalog name
        schema: Schema name
        table: Table name
        zorder_by: Optional columns to Z-ORDER by
    """
    full_table_name = f"{catalog}.{schema}.{table}"
    
    optimize_sql = f"OPTIMIZE {full_table_name}"
    if zorder_by:
        zorder_cols = ", ".join(zorder_by)
        optimize_sql += f" ZORDER BY ({zorder_cols})"
    
    spark.sql(optimize_sql)
    logging.info(f"Optimized {full_table_name}")


# ============================================================================
# ZIP Processing Utilities
# ============================================================================

def get_binary_file_schema() -> StructType:
    """
    Get the schema for cloudFiles + binaryFile format
    
    Returns:
        StructType schema for binary file streaming
    """
    return StructType([
        StructField("path",             StringType(),    True),
        StructField("modificationTime", TimestampType(), True),
        StructField("length",           LongType(),      True),
        StructField("content",          BinaryType(),    True)
    ])


def get_manifest_schema() -> StructType:
    """
    Get the schema for document manifest records (FEATURE COLUMNS ONLY).
    
    Audit columns are added automatically by save_with_audit().
    
    Includes versioning support to track multiple uploads of the same file:
    - version: Incrementing version number (1, 2, 3...)
    - is_current: True for the latest version, False for older versions
    - supersedes_document_id: Links to the previous version's document_id
    
    Includes completion tracking for streaming processing:
    - parent_document_id: Links child documents to parent ZIP
    - total_documents_count: Total files extracted from ZIP
    - required_documents_count: Files with required tags (configurable, to be processed)
    - processed_documents_count: Successfully processed required files
    
    Returns:
        StructType schema for manifest table (feature columns only)
    """
    return StructType([
        StructField("document_id",          StringType(),               False),
        StructField("parent_document_id",   StringType(),               True),   # For child→parent linking
        StructField("zip_source_path",      StringType(),               True),
        StructField("zip_root_name",        StringType(),               True),
        StructField("extracted_path",       StringType(),               True),
        StructField("content_base64",       StringType(),               True),
        StructField("size_bytes",           LongType(),                 True),
        StructField("nested_level",         IntegerType(),              True),
        StructField("is_from_nested_zip",   BooleanType(),              True),
        StructField("file_extension",       StringType(),               True),
        StructField("document_tags",        ArrayType(StringType()),    True),
        StructField("active",               BooleanType(),              True),
        StructField("notes", StringType(),               True),
        StructField("status",       StringType(),               True),
        StructField("status_timestamp", TimestampType(),        True),
        # Processing tracking columns (consolidated from md_document_status)
        StructField("is_enabled",               BooleanType(),          True),   # From md_document_types
        StructField("source",                   StringType(),           True),   # HISTORICAL or UI
        StructField("processing_duration_seconds", DoubleType(),        True),   # Processing time
        StructField("error_message",            StringType(),           True),   # Error details if failed
        StructField("retry_count",              IntegerType(),          True),   # Retry attempts
        StructField("processing_metadata",      StringType(),           True),   # JSON with processing details
        # Trial metadata (extracted from tsDTA)
        StructField("trial_id",             StringType(),               True),
        StructField("data_stream_type",     StringType(),               True),
        StructField("data_provider_name",   StringType(),               True),
        # Document versioning columns
        StructField("version",              IntegerType(),              False),
        StructField("is_current",           BooleanType(),              False),
        StructField("supersedes_document_id", StringType(),             True),
        # Completion tracking (for parent documents)
        StructField("total_documents_count",     IntegerType(),         True),  # Total files in ZIP
        StructField("required_documents_count",  IntegerType(),         True),  # Files with required tags
        StructField("processed_documents_count", IntegerType(),         True)   # Processed required files
        # NOTE: Audit columns are added automatically by save_with_audit()
    ])


def get_document_types_schema() -> StructType:
    """
    Get the schema for document types reference table (FEATURE COLUMNS ONLY).
    
    This table controls which document types are enabled for processing.
    Documents in md_file_history join with this table based on document_tags.
    
    Audit columns are added automatically by save_with_audit().
    
    Returns:
        StructType schema for document types reference table
    """
    return StructType([
        StructField("document_type",        StringType(),    False),  # PK: tsDTA, Protocol, etc.
        StructField("document_type_label",  StringType(),    True),   # Display name
        StructField("is_enabled",           BooleanType(),   False),  # Whether to process
        StructField("description",          StringType(),    True)    # Documentation
        # NOTE: Audit columns are added automatically by save_with_audit()
    ])


def get_dta_schema() -> StructType:
    """
    Get the schema for DTA (Data Transfer Agreement) entity table.
    
    This table is the authoritative record of all active and historical DTAs.
    Used to drive ingestion rules and metadata validation.
    
    Version Pointers:
        - version: Active version (draft or major) - what UI displays
        - current_draft_version: Latest draft in Silver (e.g., "1.0-DTA001-draft3")
        - base_template_version: Library version branched from (e.g., "1.0")
    
    Note: latest_major_version was removed - now derived from md_version_registry
    via: SELECT version FROM md_version_registry WHERE dta_id = :id AND version_type = 'DTA_APPROVED' AND status = 'ACTIVE'
    
    Status Alignment (1:1 with md_version_registry.status):
        - DRAFT: Being edited, not yet approved
        - ACTIVE: Approved and in use
        - PROMOTED: Elevated to template
        - ARCHIVED: No longer active (effective_end_ts is set)
    
    DTA Types:
        - Regular DTAs: DTA001, DTA002, etc. - trial-specific configurations
        - Template DTAs: TPL001, TPL002, etc. - reusable templates per vendor/stream
    
    SCD Type 2:
        - effective_start_ts: When this DTA version became active
        - effective_end_ts: When archived (NULL unless status=ARCHIVED)
        - is_current: Quick filter for active records
    
    Returns:
        StructType schema for DTA table
    """
    return StructType([
        # Primary & Business Keys
        StructField("dta_id", StringType(), False),  # UUID primary key
        StructField("dta_number", StringType(), False),  # Sequential ID (DTA001, TPL001) for display
        StructField("dta_name", StringType(), True),  # User-friendly name for UI
        # Lineage
        StructField("parent_document_id", StringType(), True),  # FK to source tsDTA document
        # Business Key: trial_id + data_stream_type + data_provider_name
        StructField("trial_id", StringType(), True),  # Clinical trial ID (e.g., VAC18193RSV3001)
        StructField("data_stream_type", StringType(), True),  # Data category (Labs, Adverse Events)
        StructField("data_provider_name", StringType(), True),  # Vendor (LabCorp, Covance, PPD)
        # Status & Workflow (status aligns 1:1 with md_version_registry.status)
        StructField("status", StringType(), False),  # DRAFT, ACTIVE, PROMOTED, ARCHIVED
        StructField("workflow_state", StringType(), False),  # NOT_STARTED, IN_REVIEW, APPROVED, REJECTED
        StructField("workflow_iteration", IntegerType(), True),  # Current approval cycle (1, 2, 3...)
        # Version Pointers (latest_major_version removed - derived from md_version_registry)
        StructField("version", StringType(), True),  # Active version for UI display
        StructField("current_draft_version", StringType(), True),  # Latest draft in Silver
        StructField("base_template_version", StringType(), True),  # Branched from library version
        StructField("notes", StringType(), True),  # General notes about the DTA
        # SCD Type 2 columns
        StructField("effective_start_ts", TimestampType(), False),  # When this DTA became active
        StructField("effective_end_ts", TimestampType(), True),  # When archived (NULL unless ARCHIVED)
        StructField("is_current", BooleanType(), False),  # Quick filter for active records
        # Audit columns
        StructField("created_by_principal", StringType(), True),  # User who created
        StructField("created_ts", TimestampType(), True),  # Creation timestamp
        StructField("last_updated_by_principal", StringType(), True),  # User who last modified
        StructField("last_updated_ts", TimestampType(), True),  # Last modification timestamp
        StructField("databricks_job_id", StringType(), True),  # Job ID for lineage
        StructField("databricks_job_name", StringType(), True),  # Job name for lineage
        StructField("databricks_run_id", StringType(), True)  # Run ID for lineage
    ])


def get_audit_columns_schema() -> StructType:
    """
    Get the schema for audit columns.
    
    These columns are added automatically by save_with_audit() to all tables.
    
    Returns:
        StructType schema for audit columns
    """
    return StructType([
        StructField("created_by_principal",       StringType(),      True),
        StructField("created_ts",                 TimestampType(),   True),
        StructField("last_updated_by_principal",  StringType(),      True),
        StructField("last_updated_ts",            TimestampType(),   True),
        StructField("databricks_job_id",          StringType(),      True),
        StructField("databricks_job_name",        StringType(),      True),
        StructField("databricks_run_id",          StringType(),      True)
    ])



# ============================================================================
# Excel Processing Functions (imported from excel_utils.py)
# ============================================================================

# Import all Excel-related functions from excel_utils module for backwards compatibility
from .excel_utils import (
    get_excel_sheets_schema,
    categorize_sheet_name,
    extract_version_history_metadata,
    find_excel_header_row,
    find_best_header_row,  # Generic robust header detection
    get_header_filter_patterns,
    parse_max_length,
    is_required_field,
    is_transfer_key_field,
    get_transfer_metadata_column_map,
    get_transfer_metadata_flexible_mapper,
    get_codelist_flexible_mapper
)



def extract_document_tags(
    extracted_path: str,
    archive_root: str,
    categories_config: Optional[Dict] = None,
    logger: Optional[logging.Logger] = None
) -> tuple:
    """
    Extract document tags, active flag, and categorization notes from file path.
    Searches through ALL path levels (case-insensitive) and supports both 
    folder-based and extension-based subcategory matching.
    
    Args:
        extracted_path: Full path to extracted file
                       e.g., /Volumes/.../extracted/64007957/DTA/xyz/file.xlsx
        archive_root: Root of the archive extraction
                     e.g., /Volumes/.../extracted/64007957
        categories_config: document_categories configuration from YAML (optional)
        logger: Logger instance for warnings/info (optional)
    
    Returns:
        tuple: (tags, active_flag, notes)
        
    Behavior:
        - Subcategory matching supports:
          * Folder-based: Match by subfolder name (e.g., "Dictionary", "SOW")
          * Extension-based: Match by file extension (e.g., .xlsx → "tsDTA")
        - Folder matches have priority over extension matches
        - Multiple subcategories → WARNING, first match wins, active=False
        - Unknown subfolder/extension → Fallback to top-level
        - No category match → tags=["UNKNOWN"], active=False, info note
        - No config provided → tags=[], active=True, None
    
    Examples:
        >>> # Folder-based match
        >>> extract_document_tags("/Volumes/.../archive1/DTA/Dictionary/file.pdf", 
        ...                       "/Volumes/.../archive1", categories_config)
        (["DTA", "Dictionary"], True, None)
        
        >>> # Extension-based match (Excel file in DTA)
        >>> extract_document_tags("/Volumes/.../archive1/DTA/xyz/data.xlsx",
        ...                       "/Volumes/.../archive1", categories_config)
        (["DTA", "tsDTA"], False, None)
        
        >>> # Extension-based match (PDF file in DTA)
        >>> extract_document_tags("/Volumes/.../archive1/DTA/agreement.pdf",
        ...                       "/Volumes/.../archive1", categories_config)
        (["DTA", "OPERATIONAL_AGREEMENT"], True, None)
        
        >>> # No match
        >>> extract_document_tags("/Volumes/.../archive1/RandomFolder/file.pdf",
        ...                       "/Volumes/.../archive1", categories_config)
        (["UNKNOWN"], False, "INFO: No matching category found.")
    """
    # If no config provided, return defaults
    if not categories_config:
        return ([], True, None)
    
    # Get relative path after archive root
    relative_path = extracted_path.replace(archive_root, '').lstrip('/')
    
    # Split into folder parts (exclude file name)
    parts = [p for p in relative_path.split('/') if p]
    if not parts:
        note = "INFO: File path has no parts."
        return (["UNKNOWN"], False, note)
    
    folder_parts = parts[:-1]  # Exclude the filename
    if not folder_parts:
        # File is directly in archive root (no folder structure)
        note = "INFO: File is directly in archive root with no folder structure."
        return (["UNKNOWN"], False, note)
    
    # Search for top-level category (case-insensitive)
    matched_category = None
    category_config = None
    
    for category_name, config in categories_config.items():
        match_name = config.get('match_name', '').upper()
        if not match_name:
            continue
        
        # Search through ALL folder parts
        for part in folder_parts:
            if part.upper() == match_name:
                matched_category = category_name
                category_config = config
                break
        
        if matched_category:
            break
    
    # No category found → tags=["UNKNOWN"], active=False, add note
    if not matched_category:
        note = "INFO: No matching category found."
        if logger:
            logger.info(f"{note} Path: {relative_path}")
        return (["UNKNOWN"], False, note)
    
    # Check for subcategories (supports both folder-based and extension-based matching)
    subcategories = category_config.get('subcategories', {})
    
    if subcategories:
        # Get file extension
        file_name = parts[-1]  # The filename is the last part
        file_ext = os.path.splitext(file_name.lower())[1]
        
        folder_matched_subcats = []
        extension_matched_subcats = []
        
        # Find ALL matching subcategories (both folder and extension-based)
        for subcat_name, subcat_config in subcategories.items():
            match_type = subcat_config.get('match_type', 'folder')  # Default to folder for backward compatibility
            
            if match_type == 'folder':
                # Folder-based matching
                submatch_name = subcat_config.get('match_name', '').upper()
                if submatch_name:
                    # Search through ALL folder parts (case-insensitive)
                    for part in folder_parts:
                        if part.upper() == submatch_name:
                            folder_matched_subcats.append({
                                'name': subcat_name,
                                'config': subcat_config,
                                'match_type': 'folder',
                                'match_value': part
                            })
                            break
            
            elif match_type == 'extension':
                # Extension-based matching
                match_extensions = subcat_config.get('match_extensions', [])
                # Normalize extensions to lowercase with dot prefix
                match_extensions = [ext.lower() if ext.startswith('.') else f'.{ext.lower()}' 
                                   for ext in match_extensions]
                
                if file_ext in match_extensions:
                    extension_matched_subcats.append({
                        'name': subcat_name,
                        'config': subcat_config,
                        'match_type': 'extension',
                        'match_value': file_ext
                    })
        
        # Prioritize folder matches over extension matches
        # If we have folder matches, use those. Otherwise, use extension matches.
        matched_subcats = folder_matched_subcats if folder_matched_subcats else extension_matched_subcats
        
        # Handle results
        if len(matched_subcats) > 1:
            # AMBIGUOUS - Multiple subcategories found
            subcat_names = [m['name'] for m in matched_subcats]
            match_types = [m['match_type'] for m in matched_subcats]
            note = (
                f"WARN: Multiple subcategories found ({', '.join(match_types)} match): "
                f"{', '.join(subcat_names)}. Using first match."
            )
            if logger:
                logger.warning(f"{note} Path: {relative_path}")
            
            # Use first match, but mark as INACTIVE due to ambiguity
            return (
                matched_subcats[0]['config'].get('tags', []),
                False,  # INACTIVE due to ambiguity
                note
            )
        
        elif len(matched_subcats) == 1:
            # Single subcategory found - perfect!
            return (
                matched_subcats[0]['config'].get('tags', []),
                matched_subcats[0]['config'].get('active', True),
                None  # No notes - successful categorization
            )
    
    # No subcategory found - return top-level
    return (
        category_config.get('tags', []),
        category_config.get('active', True),
        None  # No notes - successful categorization
    )


def check_existing_file_version(
    spark,
    manifest_table: str,
    extracted_path: str
) -> Optional[Dict]:
    """
    Check if a file already exists in the manifest table and return the current version info.
    
    Args:
        spark: Spark session
        manifest_table: Full table name (catalog.schema.table)
        extracted_path: Path to check for existing versions
    
    Returns:
        Dict with version info if file exists, None otherwise
        Example: {'document_id': 'uuid-123', 'version': 2, 'is_current': True}
    """
    try:
        # Check if table exists
        existing = spark.sql(f"""
            SELECT document_id, version, is_current
            FROM {manifest_table}
            WHERE extracted_path = '{extracted_path}'
              AND is_current = true
            LIMIT 1
        """).first()
        
        if existing:
            return {
                'document_id': existing.document_id,
                'version': existing.version,
                'is_current': existing.is_current
            }
        return None
    except Exception as e:
        # Table might not exist yet (first run)
        return None


def save_document_with_metadata(
    content_bytes: bytes,
    source_path: str,
    target_path: str,
    file_size: int,
    archive_root: str,
    categories_config: Optional[Dict] = None,
    created_by_principal: Optional[str] = None,
    databricks_job_id: Optional[str] = None,
    databricks_job_name: Optional[str] = None,
    databricks_run_id: Optional[str] = None,
    is_from_nested_zip: bool = False,
    nested_level: int = 0,
    logger: Optional[logging.Logger] = None,
    spark = None,
    manifest_table_full_name: Optional[str] = None
) -> dict:
    """
    Save a document to disk and create metadata record for manifest table.
    
    This function provides a unified way to handle document ingestion for both
    ZIP extraction and direct file uploads. It:
    1. Writes the file content to the target path
    2. Categorizes the document based on path structure
    3. Converts content to base64 for storage in manifest table
    4. Creates a complete metadata record with audit fields
    
    Args:
        content_bytes: Binary file content
        source_path: Original source path (can include dbfs: prefix)
        target_path: Destination path (parent directories will be created)
        file_size: File size in bytes
        archive_root: Root directory for categorization logic
        categories_config: Document categorization rules (optional)
        created_by_principal: User/principal who created the document
        databricks_job_id: Job ID for audit tracking
        databricks_job_name: Job name for audit tracking
        databricks_run_id: Run ID for audit tracking
        is_from_nested_zip: Whether file was extracted from nested ZIP
        nested_level: Nesting level (0 = root, 1+ = nested)
        logger: Logger instance (optional)
    
    Returns:
        dict: Manifest record ready to be added to md_file_history table
        
    Example:
        >>> record = save_document_with_metadata(
        ...     content_bytes=file_content,
        ...     source_path="/Volumes/.../file.pdf",
        ...     target_path="/Volumes/.../ingested/file.pdf",
        ...     file_size=12345,
        ...     archive_root="/Volumes/.../ingested",
        ...     categories_config=config_dict,
        ...     created_by_principal="user@example.com",
        ...     databricks_job_id="12345"
        ... )
        >>> manifest_records.append(record)
    """
    import os
    import base64
    import uuid
    from datetime import datetime
    
    # Write file to target path
    os.makedirs(os.path.dirname(target_path), exist_ok=True)
    with open(target_path, 'wb') as f:
        f.write(content_bytes)
    
    if logger:
        logger.info(f"Saved file: {os.path.basename(target_path)} ({file_size} bytes)")
    
    # Categorize document based on path
    tags, active, notes = extract_document_tags(
        extracted_path=target_path,
        archive_root=archive_root,
        categories_config=categories_config,
        logger=logger
    )
    
    # Convert content to base64 for manifest storage
    content_base64 = base64.b64encode(content_bytes).decode('utf-8')
    
    # Get file extension
    file_ext = os.path.splitext(target_path)[1].lower()
    
    # Generate unique document ID
    document_id = str(uuid.uuid4())
    
    # Clean source path (remove dbfs: prefix if present)
    clean_source_path = source_path.replace('dbfs:', '') if source_path.startswith('dbfs:') else source_path
    
    # Create timestamp
    now = datetime.now()
    
    # Check for existing versions (for duplicate file handling)
    version = 1
    supersedes_document_id = None
    
    if spark and manifest_table_full_name:
        existing = check_existing_file_version(spark, manifest_table_full_name, target_path)
        if existing:
            version = existing['version'] + 1
            supersedes_document_id = existing['document_id']
            if logger:
                logger.info(f"File update detected: {os.path.basename(target_path)} (v{existing['version']} → v{version})")
    
    # Create manifest record with versioning
    # NOTE: Audit columns are NOT included here - they are added automatically by save_with_audit()
    return {
        'document_id': document_id,
        'source_file_path': clean_source_path,
        'extracted_path': target_path,
        'file_extension': file_ext,
        'size_bytes': file_size,
        'document_tags': tags if tags else ['UNKNOWN'],
        'active': active,
        'content_base64': content_base64,
        'notes': notes,
        'status': 'READY_FOR_PROCESSING',
        'status_timestamp': now,
        # Processing tracking fields (consolidated from md_document_status)
        'is_enabled': True,  # Default to enabled, will be updated based on md_document_types
        'source': 'HISTORICAL',  # Default to HISTORICAL for batch processing
        'processing_duration_seconds': None,
        'error_message': None,
        'retry_count': 0,
        'processing_metadata': None,
        'is_from_nested_zip': is_from_nested_zip,
        'nested_level': nested_level,
        # Versioning fields
        'version': version,
        'is_current': True,  # New version is always current
        'supersedes_document_id': supersedes_document_id
        # NOTE: Audit columns are added automatically by save_with_audit()
    }


def extract_zip_recursive(
    zip_bytes: bytes,
    base_output_dir_local: str,
    base_output_dir_volumes: str,
    rel_prefix: str,
    manifest_records: List[Dict],
    zip_root_name: str,
    zip_source_path: str,
    level: int = 0,
    supported_extensions: Optional[List[str]] = None,
    categories_config: Optional[Dict] = None,
    logger: Optional[logging.Logger] = None
) -> None:
    """
    Recursively extract a ZIP into base_output_dir_local/rel_prefix.
    Nested ZIPs are extracted into subfolders named after the nested zip file (without extension).
    Each file is recorded into manifest_records with document tags and active flag.
    Only files with supported extensions are extracted (if specified).
    
    Args:
        zip_bytes: Binary content of the ZIP file
        base_output_dir_local: Local filesystem base output directory (/Volumes/...)
        base_output_dir_volumes: Volumes path for manifest (/Volumes/...)
        rel_prefix: Relative prefix for nested extraction
        manifest_records: List to collect manifest records
        zip_root_name: Root ZIP file name (without extension)
        zip_source_path: Source path of the ZIP file (/Volumes/... or dbfs:/Volumes/...)
        level: Nesting level (0 for root ZIP)
        supported_extensions: List of supported file extensions (e.g., ['.pdf', '.xlsx']). 
                            If None, all files are extracted.
        categories_config: Document categorization configuration (optional)
        logger: Logger instance for warnings/info (optional)
    """
    # Convert supported extensions to lowercase for case-insensitive comparison
    if supported_extensions:
        supported_extensions = [ext.lower() if ext.startswith('.') else f'.{ext.lower()}' 
                               for ext in supported_extensions]
    
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
        for info in z.infolist():
            name = info.filename

            # Skip directory entries
            if name.endswith('/'):
                continue
            
            # Skip macOS metadata files and folders
            if '__MACOSX' in name or name.startswith('._') or '/.DS_Store' in name or name == '.DS_Store':
                continue

            # Try to read the file content - handle encryption and other errors
            try:
                data = z.read(name)
            except RuntimeError as e:
                # Handle encrypted files
                error_msg = str(e)
                if 'encrypted' in error_msg.lower() or 'password' in error_msg.lower():
                    logger.error(f"⚠️  ENCRYPTED FILE SKIPPED: {name} - {error_msg}")
                    
                    # Create error record in manifest
                    rel_path_in_zip = name.lstrip('/')
                    relative_output_path = os.path.join(rel_prefix, rel_path_in_zip) if rel_prefix else rel_path_in_zip
                    relative_output_path = relative_output_path.replace("\\", "/")
                    
                    manifest_records.append({
                        "document_id": str(uuid.uuid4()),
                        "zip_source_path": zip_source_path,
                        "extracted_path": None,  # Not extracted
                        "file_extension": os.path.splitext(rel_path_in_zip.lower())[1],
                        "size_bytes": info.file_size,
                        "is_nested_zip": False,
                        "nesting_level": level,
                        "document_tags": [],
                        "active": False,
                        "notes": f"EXTRACTION_ERROR: {error_msg}",
                        "binary_content": None,
                        "status": "EXTRACTION_ERROR",
                        "status_timestamp": datetime.now(),
                        # Versioning fields (errors always create new records)
                        "version": 1,
                        "is_current": True,
                        "supersedes_document_id": None
                    })
                    continue  # Skip this file and continue with others
                else:
                    # Other runtime errors
                    logger.error(f"⚠️  ERROR READING FILE: {name} - {error_msg}")
                    continue
            except Exception as e:
                # Catch all other exceptions
                logger.error(f"⚠️  UNEXPECTED ERROR READING FILE: {name} - {str(e)}")
                continue

            # Normalize path inside zip
            rel_path_in_zip = name.lstrip('/')

            # If this entry is a nested zip -> recurse
            if rel_path_in_zip.lower().endswith('.zip'):
                nested_folder_name = os.path.splitext(os.path.basename(rel_path_in_zip))[0]
                nested_prefix = os.path.join(rel_prefix, nested_folder_name) if rel_prefix else nested_folder_name

                try:
                    extract_zip_recursive(
                        data,
                        base_output_dir_local=base_output_dir_local,
                        base_output_dir_volumes=base_output_dir_volumes,
                        rel_prefix=nested_prefix,
                        manifest_records=manifest_records,
                        zip_root_name=zip_root_name,
                        zip_source_path=zip_source_path,
                        level=level + 1,
                        supported_extensions=supported_extensions,
                        categories_config=categories_config,
                        logger=logger
                    )
                except Exception as e:
                    # If nested zip extraction fails, log and continue
                    logger.error(f"⚠️  ERROR EXTRACTING NESTED ZIP: {rel_path_in_zip} - {str(e)}")
                    
                    # Create error record for nested zip
                    manifest_records.append({
                        "document_id": str(uuid.uuid4()),
                        "zip_source_path": zip_source_path,
                        "extracted_path": None,
                        "file_extension": ".zip",
                        "size_bytes": info.file_size,
                        "is_nested_zip": True,
                        "nesting_level": level,
                        "document_tags": [],
                        "active": False,
                        "notes": f"EXTRACTION_ERROR: Nested ZIP extraction failed - {str(e)}",
                        "binary_content": None,
                        "status": "EXTRACTION_ERROR",
                        "status_timestamp": datetime.now(),
                        # Versioning fields (errors always create new records)
                        "version": 1,
                        "is_current": True,
                        "supersedes_document_id": None
                    })
                    continue
            else:
                # Check if file extension is supported
                file_ext = os.path.splitext(rel_path_in_zip.lower())[1]
                
                if supported_extensions and file_ext not in supported_extensions:
                    # Skip unsupported file types
                    print(f"  Skipping unsupported file type: {rel_path_in_zip} (extension: {file_ext})")
                    continue
                
                try:
                    # Regular file -> write to Volumes
                    relative_output_path = os.path.join(rel_prefix, rel_path_in_zip) if rel_prefix else rel_path_in_zip
                    # Normalize to POSIX-style path
                    relative_output_path = relative_output_path.replace("\\", "/")

                    output_path_local = os.path.join(base_output_dir_local, relative_output_path)
                    output_dir_local = os.path.dirname(output_path_local)
                    os.makedirs(output_dir_local, exist_ok=True)

                    with open(output_path_local, 'wb') as f:
                        f.write(data)

                    # Compute volumes path for the extracted file (without dbfs: prefix)
                    output_path_volumes = "/".join([base_output_dir_volumes.rstrip("/"), relative_output_path])
                    
                    # Clean zip_source_path (remove dbfs: prefix if present)
                    clean_source_path = zip_source_path.replace("dbfs:", "") if zip_source_path.startswith("dbfs:") else zip_source_path

                    # Extract document tags and active flag
                    # Archive root is base_output_dir_volumes
                    document_tags, active_flag, notes = extract_document_tags(
                        extracted_path=output_path_volumes,
                        archive_root=base_output_dir_volumes,
                        categories_config=categories_config,
                        logger=logger
                    )

                    # Generate unique document ID
                    document_id = str(uuid.uuid4())
                    
                    # Encode content to base64 for storage in manifest
                    content_base64 = base64.b64encode(data).decode('utf-8')
                    
                    # Get current timestamp for status
                    extraction_timestamp = datetime.now()

                    # Record into manifest list
                    manifest_records.append({
                        'document_id': document_id,
                        'zip_source_path': clean_source_path,
                        'zip_root_name': zip_root_name,
                        'extracted_path': output_path_volumes,
                        'content_base64': content_base64,
                        'size_bytes': len(data),
                        'nested_level': level,
                        'is_from_nested_zip': bool(level > 0),
                        'file_extension': file_ext,
                        'document_tags': document_tags,
                        'active': active_flag,
                        'notes': notes,
                        'status': 'READY_FOR_PROCESSING',
                        'status_timestamp': extraction_timestamp,
                        # Processing tracking fields
                        'is_enabled': True,  # Will be updated based on md_document_types
                        'source': 'HISTORICAL',
                        'processing_duration_seconds': None,
                        'error_message': None,
                        'retry_count': 0,
                        'processing_metadata': None,
                        # Versioning fields (ZIP extraction always creates new files, so version=1)
                        'version': 1,
                        'is_current': True,
                        'supersedes_document_id': None
                    })
                
                except Exception as e:
                    # Handle file writing, encoding, or tagging errors
                    logger.error(f"⚠️  ERROR PROCESSING FILE: {rel_path_in_zip} - {str(e)}")
                    
                    # Create error record
                    relative_output_path = os.path.join(rel_prefix, rel_path_in_zip) if rel_prefix else rel_path_in_zip
                    relative_output_path = relative_output_path.replace("\\", "/")
                    
                    manifest_records.append({
                        "document_id": str(uuid.uuid4()),
                        "zip_source_path": zip_source_path,
                        "extracted_path": None,
                        "file_extension": file_ext,
                        "size_bytes": info.file_size,
                        "is_nested_zip": False,
                        "nesting_level": level,
                        "document_tags": [],
                        "active": False,
                        "notes": f"EXTRACTION_ERROR: {str(e)}",
                        "binary_content": None,
                        "status": "EXTRACTION_ERROR",
                        "status_timestamp": datetime.now(),
                        # Versioning fields (errors always create new records)
                        "version": 1,
                        "is_current": True,
                        "supersedes_document_id": None
                    })
                    continue  # Continue processing other files


def create_zip_batch_processor(
    spark: SparkSession,
    target_root_path: str,
    manifest_table_full_name: str,
    created_by_principal: str,
    databricks_job_id: Optional[str] = None,
    databricks_job_name: Optional[str] = None,
    databricks_run_id: Optional[str] = None,
    supported_extensions: Optional[List[str]] = None,
    categories_config: Optional[Dict] = None,
    manifest_table_description: Optional[str] = None,
    required_tags_for_versioning: Optional[List[str]] = None,
    document_type_override: Optional[str] = None
):
    """
    Create a batch processor function for ZIP file processing.
    
    All document status and processing metadata is now consolidated in md_file_history
    (formerly md_dta_history). No separate status table is needed.
    
    Args:
        spark: SparkSession instance
        target_root_path: Target root path for extraction (/Volumes/... or dbfs:/Volumes/...)
        manifest_table_full_name: Full table name for file history (catalog.schema.md_file_history)
        created_by_principal: Principal (user/service account) running the job
        databricks_job_id: Job ID for lineage tracking
        databricks_run_id: Run ID for lineage tracking
        supported_extensions: List of supported file extensions (e.g., ['.pdf', '.xlsx']). 
                            If None, all files are extracted.
        categories_config: Document categorization configuration (optional)
        manifest_table_description: Description for file history table (optional)
        required_tags_for_versioning: List of document tags that must be processed before 
                                     versioning triggers (default: ['tsDTA'])
        document_type_override: When set from UI, overrides path-based tag extraction
                              (e.g., 'Protocol' or 'tsDTA'). All extracted files will
                              have this as their document_tags.
        
    Returns:
        Function to process ZIP file batches
    """
    # Setup logger
    logger = setup_logging("zip_processor")
    # Normalize path - remove dbfs: prefix if present and use /Volumes directly
    if target_root_path.startswith("dbfs:/Volumes/"):
        target_root_local = target_root_path.replace("dbfs:", "")
        target_root_volumes = target_root_path.replace("dbfs:", "")
    elif target_root_path.startswith("/Volumes/"):
        target_root_local = target_root_path
        target_root_volumes = target_root_path
    else:
        raise ValueError(f"Path must start with /Volumes/ or dbfs:/Volumes/, got: {target_root_path}")
    
    def process_zip_batch(batch_df: DataFrame, batch_id: int):
        """
        Process a batch of ZIP files: extract and update manifest
        
        Args:
            batch_df: Batch DataFrame with 'path' and 'content' columns
            batch_id: Batch identifier
        """
        rows = batch_df.select('path', 'content').collect()
        print(f'Processing batch {batch_id}, num files = {len(rows)}')
        
        if supported_extensions:
            print(f'Only extracting files with extensions: {", ".join(supported_extensions)}')

        all_manifest_records = []

        for row in rows:
            src_path_dbfs = row['path']
            content = row['content']

            zip_file_name = os.path.basename(src_path_dbfs)
            zip_base_name = os.path.splitext(zip_file_name)[0]

            # Create a folder under the target volume for this zip
            zip_output_dir_local = os.path.join(target_root_local, zip_base_name)
            os.makedirs(zip_output_dir_local, exist_ok=True)

            zip_output_dir_volumes = f'{target_root_volumes}/{zip_base_name}'.rstrip('/')

            print(f'Extracting {src_path_dbfs} -> {zip_output_dir_volumes}')

            manifest_records = []
            extract_zip_recursive(
                zip_bytes=content,
                base_output_dir_local=zip_output_dir_local,
                base_output_dir_volumes=zip_output_dir_volumes,
                rel_prefix='',
                manifest_records=manifest_records,
                zip_root_name=zip_base_name,
                zip_source_path=src_path_dbfs,
                level=0,
                supported_extensions=supported_extensions,
                categories_config=categories_config,
                logger=logger
            )

            all_manifest_records.extend(manifest_records)

        print(f'Finished extraction for batch {batch_id}. Files extracted: {len(all_manifest_records)}')

        if all_manifest_records:
            # =========================================================================
            # Create parent document record for the ZIP file and link children
            # =========================================================================
            # Generate parent document ID for this ZIP
            parent_document_id = str(uuid.uuid4())
            
            # Default required tags if not specified
            req_tags = required_tags_for_versioning or ['tsDTA']
            
            # Count total files and files with required tags
            total_count = len(all_manifest_records)
            required_count = sum(1 for r in all_manifest_records 
                                if any(tag in r.get('document_tags', []) for tag in req_tags))
            
            # Link all child records to this parent and apply document_type override if set
            for record in all_manifest_records:
                record['parent_document_id'] = parent_document_id
                # Override document_tags if document_type was set from UI
                if document_type_override:
                    record['document_tags'] = [document_type_override]
            
            # Create parent record for the ZIP itself
            clean_zip_path = src_path_dbfs.replace('dbfs:', '') if src_path_dbfs.startswith('dbfs:') else src_path_dbfs
            parent_record = {
                'document_id': parent_document_id,
                'parent_document_id': None,  # ZIP is the parent
                'zip_source_path': clean_zip_path,
                'zip_root_name': zip_base_name,
                'extracted_path': zip_output_dir_volumes,
                'content_base64': None,  # No content for ZIP itself
                'size_bytes': len(content),
                'nested_level': 0,
                'is_from_nested_zip': False,
                'file_extension': '.zip',
                'document_tags': ['ZIP_ARCHIVE'],
                'active': True,
                'notes': f"Parent archive with {len(all_manifest_records)} files",
                'status': 'PROCESSING',  # Parent starts as PROCESSING
                'status_timestamp': datetime.now(),
                # Processing tracking fields
                'is_enabled': True,  # ZIP archives are always enabled
                'source': 'HISTORICAL',
                'processing_duration_seconds': None,
                'error_message': None,
                'retry_count': 0,
                'processing_metadata': None,
                'trial_id': None,
                'data_stream_type': None,
                'data_provider_name': None,
                'version': 1,
                'is_current': True,
                'supersedes_document_id': None,
                # Completion tracking - initialized with counts
                'total_documents_count': total_count,
                'required_documents_count': required_count,
                'processed_documents_count': 0
            }
            all_manifest_records.append(parent_record)
            
            print(f'  Created parent document: {parent_document_id}')
            print(f'    - Total files: {total_count}')
            print(f'    - Required files (tags: {req_tags}): {required_count}')
            
            # Create DataFrame with explicit schema
            # All status tracking is now in md_file_history (no separate status table)
            manifest_df = spark.createDataFrame(all_manifest_records, schema=get_manifest_schema())
            manifest_df = manifest_df.withColumn('batch_id', lit(batch_id))
            
            # Write to file history table with ACID guarantees (Delta Lake ensures atomicity)
            save_with_audit(
                df=manifest_df,
                table_name=manifest_table_full_name,
                created_by_principal=created_by_principal,
                databricks_job_id=databricks_job_id,
                databricks_job_name=databricks_job_name,
                databricks_run_id=databricks_run_id,
                mode='append',
                table_description=manifest_table_description
            )
            print(f'Appended {manifest_df.count()} rows to file history table {manifest_table_full_name}.')
        else:
            print('No files extracted in this batch; manifest not updated.')
    
    return process_zip_batch


def create_binary_autoloader_stream(
    spark: SparkSession,
    source_path: str,
    schema: Optional[StructType] = None
) -> DataFrame:
    """
    Create an Auto Loader streaming DataFrame for ZIP files
    
    Args:
        spark: SparkSession instance
        source_path: Source path (/Volumes/... or dbfs:/Volumes/...) - both formats work
        schema: Optional schema (defaults to binary file schema)
        
    Returns:
        Streaming DataFrame configured for ZIP file ingestion
    """
    if schema is None:
        schema = get_binary_file_schema()
    
    return (
        spark.readStream
             .format("cloudFiles")
             .option("cloudFiles.format", "binaryFile")
             .option("cloudFiles.includeExistingFiles", "true")
             .schema(schema)
             .load(source_path)
    )


# ============================================================================
# Audit Column Management
# ============================================================================

def add_audit_columns(
    df: DataFrame,
    created_by_principal: str,
    databricks_job_id: Optional[str] = None,
    databricks_job_name: Optional[str] = None,
    databricks_run_id: Optional[str] = None,
    is_new_record_column: Optional[str] = None
) -> DataFrame:
    """
    Add audit columns to a DataFrame for tracking creation and updates.
    
    This function adds seven audit columns:
    - created_by_principal: User/service principal who created the record
    - created_ts: Timestamp when record was first created
    - databricks_job_id: Job ID that created the record
    - databricks_job_name: Job name that created the record
    - databricks_run_id: Run ID that created the record
    - last_updated_by_principal: User/service principal who last updated the record
    - last_updated_ts: Timestamp when record was last updated
    
    Logic:
    - For new records: Both created_* and last_updated_* are set to current values
    - For existing records: created_* values are preserved, last_updated_* are updated
    
        Args:
        df: Input DataFrame
        created_by_principal: Principal (user/service account) making the change
        databricks_job_id: Job ID for lineage tracking
        databricks_job_name: Job name for lineage tracking
        databricks_run_id: Run ID for lineage tracking
        is_new_record_column: Optional column name that indicates if record is new (True/False).
                             If None, assumes all records are new.
    
    Returns:
        DataFrame with audit columns added
        
    Example:
        # For new records (insert)
        df_with_audit = add_audit_columns(
            df, 
            created_by_principal="user@example.com",
            databricks_job_id="12345",
            databricks_job_name="job_cds_zip_processor_dev",
            databricks_run_id="67890"
        )
        
        # For merge operation with existing records
        df_with_audit = add_audit_columns(
            df, 
            created_by_principal="user@example.com",
            databricks_job_id="12345",
            databricks_job_name="job_cds_zip_processor_dev",
            databricks_run_id="67890",
            is_new_record_column="is_new"
        )
    """
    from pyspark.sql.functions import when, col, coalesce
    
    if is_new_record_column and is_new_record_column in df.columns:
        # Merge scenario: set created_* only for new records, always update last_updated_*
        df = df.withColumn(
            "created_by_principal",
            when(col(is_new_record_column), lit(created_by_principal))
            .otherwise(coalesce(col("created_by_principal"), lit(created_by_principal)))
        ).withColumn(
            "created_ts",
            when(col(is_new_record_column), current_timestamp())
            .otherwise(coalesce(col("created_ts"), current_timestamp()))
        ).withColumn(
            "databricks_job_id",
            when(col(is_new_record_column), lit(databricks_job_id))
            .otherwise(coalesce(col("databricks_job_id"), lit(databricks_job_id)))
        ).withColumn(
            "databricks_job_name",
            when(col(is_new_record_column), lit(databricks_job_name))
            .otherwise(coalesce(col("databricks_job_name"), lit(databricks_job_name)))
        ).withColumn(
            "databricks_run_id",
            when(col(is_new_record_column), lit(databricks_run_id))
            .otherwise(coalesce(col("databricks_run_id"), lit(databricks_run_id)))
        ).withColumn(
            "last_updated_by_principal",
            lit(created_by_principal)
        ).withColumn(
            "last_updated_ts",
            current_timestamp()
        )
    else:
        # Insert scenario: all records are new
        df = df.withColumn("created_by_principal", lit(created_by_principal)) \
               .withColumn("created_ts", current_timestamp()) \
               .withColumn("databricks_job_id", lit(databricks_job_id)) \
               .withColumn("databricks_job_name", lit(databricks_job_name)) \
               .withColumn("databricks_run_id", lit(databricks_run_id)) \
               .withColumn("last_updated_by_principal", lit(created_by_principal)) \
               .withColumn("last_updated_ts", current_timestamp())
    
    return df


def save_with_audit(
    df: DataFrame,
    table_name: str,
    created_by_principal: str,
    databricks_job_id: Optional[str] = None,
    databricks_job_name: Optional[str] = None,
    databricks_run_id: Optional[str] = None,
    mode: str = "append",
    merge_keys: Optional[List[str]] = None,
    table_description: Optional[str] = None
) -> None:
    """
    Save DataFrame to Delta table with AUTOMATIC audit column management.
    
    This is the SINGLE ENTRY POINT for writing data to Delta tables with audit tracking.
    
    The input DataFrame should contain ONLY feature/business columns - audit columns
    (created_by_principal, created_ts, last_updated_by_principal, last_updated_ts,
    databricks_job_id, databricks_job_name, databricks_run_id) are added automatically.
    
    Supports three modes:
    1. append: Adds audit columns and appends to table
    2. overwrite: Adds audit columns and overwrites table
    3. merge: Performs Delta merge to update existing records and insert new ones
    
    Args:
        df: Input DataFrame with FEATURE COLUMNS ONLY (no audit columns)
        table_name: Target table name (catalog.schema.table)
        created_by_principal: Principal making the change
        databricks_job_id: Job ID for lineage tracking
        databricks_job_name: Job name for lineage tracking
        databricks_run_id: Run ID for lineage tracking
        mode: Save mode - "append", "overwrite", or "merge"
        merge_keys: List of columns to use as merge keys (required for merge mode)
        table_description: Optional table description to set via TBLPROPERTIES comment
        
    Example:
        # Create DataFrame with feature columns only
        records = [{'document_id': 'abc', 'status': 'READY'}]
        df = spark.createDataFrame(records, schema=get_manifest_schema())
        
        # save_with_audit adds audit columns automatically
        save_with_audit(
            df, 
            "catalog.schema.table", 
            "user@example.com",
            databricks_job_id="12345",
            databricks_run_id="67890",
            mode="append"
        )
        
        # Merge/upsert
        save_with_audit(
            df, 
            "catalog.schema.table", 
            "user@example.com",
            databricks_job_id="12345",
            databricks_run_id="67890",
            mode="merge",
            merge_keys=["id"]
        )
    """
    from delta.tables import DeltaTable
    
    spark = df.sparkSession
    
    if mode in ["append", "overwrite"]:
        # Add audit columns for new records
        df_with_audit = add_audit_columns(
            df, 
            created_by_principal,
            databricks_job_id,
            databricks_job_name,
            databricks_run_id
        )
        
        # Check if table exists for schema merge option
        table_exists = spark.catalog.tableExists(table_name)
        
        # Save to table with schema merge enabled for append mode
        writer = df_with_audit.write.format("delta").mode(mode)
        if mode == "append" and table_exists:
            # Enable schema merge in case new columns are added
            writer = writer.option("mergeSchema", "true")
        
        writer.saveAsTable(table_name)
        print(f"Saved {df.count()} records to {table_name} (mode: {mode})")
        
        # Set table description and enable CDF if provided
        if table_description:
            # Escape single quotes in description
            escaped_description = table_description.replace("'", "''")
            spark.sql(f"""
                ALTER TABLE {table_name}
                SET TBLPROPERTIES ('comment' = '{escaped_description}')
            """)
            print(f"Table description set for {table_name}")
        
        # Enable Change Data Feed for streaming status change triggers
        try:
            spark.sql(f"""
                ALTER TABLE {table_name}
                SET TBLPROPERTIES (delta.enableChangeDataFeed = true)
            """)
            print(f"CDF enabled on {table_name}")
        except Exception as e:
            # CDF might already be enabled
            pass
        
    elif mode == "merge":
        if not merge_keys:
            raise ValueError("merge_keys required for merge mode")
        
        # Check if table exists
        table_exists = spark.catalog.tableExists(table_name)
        
        if not table_exists:
            # Table doesn't exist, create it
            df_with_audit = add_audit_columns(
                df, 
                created_by_principal,
                databricks_job_id,
                databricks_job_name,
                databricks_run_id
            )
            df_with_audit.write.format("delta").mode("overwrite").saveAsTable(table_name)
            print(f"Created new table: {table_name}")
            
            # Set table description if provided
            if table_description:
                escaped_description = table_description.replace("'", "''")
                spark.sql(f"""
                    ALTER TABLE {table_name}
                    SET TBLPROPERTIES ('comment' = '{escaped_description}')
                """)
                print(f"Table description set for {table_name}")
            return
        
        # Table exists, perform merge
        delta_table = DeltaTable.forName(spark, table_name)
        
        # Add audit columns to source
        source_with_audit = add_audit_columns(
            df, 
            created_by_principal,
            databricks_job_id,
            databricks_job_name,
            databricks_run_id
        )
        
        # Build merge condition
        merge_condition = " AND ".join([f"target.{key} = source.{key}" for key in merge_keys])
        
        # Get data columns (exclude audit columns for update set)
        data_columns = [c for c in df.columns]
        
        # Build update set - update data columns + last_updated_*
        # Preserve created_* from target
        update_set = {}
        for col in data_columns:
            update_set[col] = f"source.{col}"
        update_set["last_updated_by_principal"] = f"source.last_updated_by_principal"
        update_set["last_updated_ts"] = f"source.last_updated_ts"
        # created_by_principal and created_ts will keep target values (not in update_set)
        
        # Build insert set (all columns including audit)
        insert_columns = source_with_audit.columns
        insert_set = {col: f"source.{col}" for col in insert_columns}
        
        # Execute merge
        merge_builder = delta_table.alias("target").merge(
            source_with_audit.alias("source"),
            merge_condition
        )
        
        merge_builder = merge_builder.whenMatchedUpdate(set=update_set)
        merge_builder = merge_builder.whenNotMatchedInsert(values=insert_set)
        
        merge_builder.execute()
        print(f"Merged data into table: {table_name}")
        
    else:
        raise ValueError(f"Unsupported mode: {mode}. Use 'append', 'overwrite', or 'merge'")


# ============================================================================
# Activity Logging (for Jobs/Notebooks)
# ============================================================================

def log_dta_activity(
    spark: SparkSession,
    catalog: str,
    dta_id: str,
    activity_category: str,
    activity_type: str,
    activity_summary: str,
    performed_by: str,
    library_type: str = None,
    entity_id: str = None,
    entity_name: str = None,
    field_name: str = None,
    old_value: str = None,
    new_value: str = None,
    workflow_iteration: int = None,
    approver_role: str = None,
    approver_name: str = None,
    comment: str = None,
    version: str = None,
    parent_version: str = None,
    gold_schema: str = "gold_md"
) -> bool:
    """
    Log a single activity to the DTA activity log table.
    
    Activity Categories:
    - DATA_CHANGE: INSERT, UPDATE, DELETE, BULK_INSERT
    - WORKFLOW: SUBMITTED_FOR_APPROVAL, APPROVED, REJECTED, REASSIGNED, RECALLED
    - STATUS_CHANGE: STATUS_CHANGED
    - VERSION: DRAFT_CREATED, DTA_APPROVED_CREATED, PROMOTED_TO_TEMPLATE, CLONED_FROM
    
    Args:
        spark: SparkSession instance
        catalog: Catalog name (e.g., "aira_test")
        dta_id: DTA ID this activity relates to
        activity_category: Category of activity (DATA_CHANGE, WORKFLOW, etc.)
        activity_type: Specific type (INSERT, APPROVED, etc.)
        activity_summary: Human-readable summary
        performed_by: User/principal who performed the action
        library_type: Entity type (transfer_variables, test_concepts, etc.)
        entity_id: Entity identifier
        entity_name: Human-readable entity name
        field_name: Field that changed
        old_value: Previous value
        new_value: New value
        workflow_iteration: Approval cycle number
        approver_role: Role (jnj_dae, vendor, librarian)
        approver_name: Approver's name
        comment: Activity comment
        version: Version created/promoted
        parent_version: Source version
        gold_schema: Gold schema name (default: "gold_md")
        
    Returns:
        True if logged successfully, False otherwise
        
    Example:
        >>> log_dta_activity(
        ...     spark, "aira_test", "uuid-123",
        ...     activity_category="VERSION",
        ...     activity_type="CLONED_FROM",
        ...     activity_summary="Created by cloning from DTA008",
        ...     performed_by="user@company.com"
        ... )
    """
    try:
        from pyspark.sql.types import StructType, StructField, StringType, IntegerType
        
        activity_id = str(uuid.uuid4())
        table_name = f"{catalog}.{gold_schema}.dta_activity_log"
        
        # Define explicit schema to avoid inference issues with None values
        schema = StructType([
            StructField("activity_id", StringType(), False),
            StructField("dta_id", StringType(), False),
            StructField("activity_category", StringType(), False),
            StructField("activity_type", StringType(), False),
            StructField("library_type", StringType(), True),
            StructField("entity_id", StringType(), True),
            StructField("entity_name", StringType(), True),
            StructField("field_name", StringType(), True),
            StructField("old_value", StringType(), True),
            StructField("new_value", StringType(), True),
            StructField("workflow_iteration", IntegerType(), True),
            StructField("approver_role", StringType(), True),
            StructField("approver_name", StringType(), True),
            StructField("comment", StringType(), True),
            StructField("version", StringType(), True),
            StructField("parent_version", StringType(), True),
            StructField("activity_summary", StringType(), True),
            StructField("performed_by_principal", StringType(), True)
        ])
        
        # Create record as a tuple matching schema order
        record = (
            activity_id,
            dta_id,
            activity_category,
            activity_type,
            library_type,
            entity_id,
            entity_name,
            field_name,
            old_value,
            new_value,
            workflow_iteration,
            approver_role,
            approver_name,
            comment,
            version,
            parent_version,
            activity_summary,
            performed_by
        )
        
        # Create DataFrame with explicit schema
        df = spark.createDataFrame([record], schema=schema)
        df = df.withColumn("performed_ts", current_timestamp())
        
        df.write.format("delta").mode("append").saveAsTable(table_name)
        
        print(f"Activity logged: [{activity_category}] {activity_type} - {activity_summary[:50]}...")
        return True
        
    except Exception as e:
        print(f"Warning: Failed to log activity: {e}")
        import traceback
        traceback.print_exc()
        return False


def log_dta_bulk_insert(
    spark: SparkSession,
    catalog: str,
    dta_id: str,
    library_type: str,
    record_count: int,
    performed_by: str,
    source_dta_id: str = None,
    gold_schema: str = "gold_md"
) -> bool:
    """
    Log a bulk insert operation (e.g., initial import, clone).
    
    Args:
        spark: SparkSession instance
        catalog: Catalog name
        dta_id: DTA ID being created
        library_type: Entity type (transfer_variables, test_concepts, etc.)
        record_count: Number of records inserted
        performed_by: User/principal
        source_dta_id: Source DTA ID if cloning
        gold_schema: Gold schema name
        
    Example:
        >>> log_dta_bulk_insert(
        ...     spark, "aira_test", "uuid-new", 
        ...     "transfer_variables", 85, 
        ...     "user@company.com", 
        ...     source_dta_id="uuid-source"
        ... )
    """
    library_label = library_type.replace('_', ' ')
    if source_dta_id:
        summary = f"{record_count} {library_label} cloned from DTA {source_dta_id[:8]}"
    else:
        summary = f"{record_count} {library_label} imported"
    
    return log_dta_activity(
        spark=spark,
        catalog=catalog,
        dta_id=dta_id,
        activity_category="DATA_CHANGE",
        activity_type="BULK_INSERT",
        activity_summary=summary,
        performed_by=performed_by,
        library_type=library_type,
        comment=f"Source DTA: {source_dta_id}" if source_dta_id else None,
        gold_schema=gold_schema
    )


def log_dta_version_event(
    spark: SparkSession,
    catalog: str,
    dta_id: str,
    activity_type: str,
    version: str,
    performed_by: str,
    parent_version: str = None,
    source_dta_number: str = None,
    source_dta_name: str = None,
    gold_schema: str = "gold_md"
) -> bool:
    """
    Log a version-related event.
    
    Activity Types:
    - DRAFT_CREATED: New draft version created
    - DTA_APPROVED_CREATED: DTA approved and major version created
    - PROMOTED_TO_TEMPLATE: Promoted to library major version
    - CLONED_FROM: DTA created by cloning
    
    Args:
        spark: SparkSession instance
        catalog: Catalog name
        dta_id: DTA ID
        activity_type: Version event type
        version: Version being created
        performed_by: User/principal
        parent_version: Source version
        source_dta_number: Source DTA number (for CLONED_FROM, e.g., "DTA003")
        source_dta_name: Source DTA name (for CLONED_FROM)
        gold_schema: Gold schema name
        
    Example:
        >>> log_dta_version_event(
        ...     spark, "aira_test", "uuid-123",
        ...     activity_type="DTA_APPROVED_CREATED",
        ...     version="1.0-DTA001-v1.0",
        ...     performed_by="user@company.com"
        ... )
    """
    # Build clone source description with both number and name
    clone_source = "unknown"
    if source_dta_number:
        clone_source = source_dta_number
        if source_dta_name:
            clone_source = f"{source_dta_number} - {source_dta_name}"
    
    summaries = {
        "DRAFT_CREATED": f"Draft version {version} created",
        "DTA_APPROVED_CREATED": f"DTA Major version {version} created",
        "PROMOTED_TO_TEMPLATE": f"Promoted to DTA Template version {version}",
        "CLONED_FROM": f"Created by cloning from {clone_source}"
    }
    summary = summaries.get(activity_type, f"Version {version} - {activity_type}")
    
    return log_dta_activity(
        spark=spark,
        catalog=catalog,
        dta_id=dta_id,
        activity_category="VERSION",
        activity_type=activity_type,
        activity_summary=summary,
        performed_by=performed_by,
        version=version,
        parent_version=parent_version,
        comment=f"Source: {clone_source}" if source_dta_number else None,
        gold_schema=gold_schema
    )


def log_dta_workflow_event(
    spark: SparkSession,
    catalog: str,
    dta_id: str,
    activity_type: str,
    performed_by: str,
    workflow_iteration: int = None,
    approver_role: str = None,
    approver_name: str = None,
    comment: str = None,
    gold_schema: str = "gold_md"
) -> bool:
    """
    Log a workflow event.
    
    Activity Types:
    - SUBMITTED_FOR_APPROVAL: DTA submitted for review
    - APPROVED: Approved by an approver
    - REJECTED: Rejected by an approver
    - REASSIGNED: Reassigned to another approver
    - RECALLED: Recalled from approval
    
    Args:
        spark: SparkSession instance
        catalog: Catalog name
        dta_id: DTA ID
        activity_type: Workflow event type
        performed_by: User/principal
        workflow_iteration: Approval cycle number
        approver_role: Role (jnj_dae, vendor, librarian)
        approver_name: Approver's name
        comment: Comment from approver
        gold_schema: Gold schema name
        
    Example:
        >>> log_dta_workflow_event(
        ...     spark, "aira_test", "uuid-123",
        ...     activity_type="APPROVED",
        ...     performed_by="sarah.johnson@jnj.com",
        ...     approver_role="jnj_dae",
        ...     approver_name="Sarah Johnson"
        ... )
    """
    summaries = {
        "SUBMITTED_FOR_APPROVAL": "Submitted for approval",
        "APPROVED": f"Approved by {approver_name} ({approver_role})" if approver_name else "Approved",
        "REJECTED": f"Rejected by {approver_name} ({approver_role})" if approver_name else "Rejected",
        "REASSIGNED": f"Reassigned to {approver_name}" if approver_name else "Reassigned",
        "RECALLED": "Recalled from approval"
    }
    summary = summaries.get(activity_type, activity_type)
    if comment:
        summary = f"{summary}. Comment: {comment[:50]}..."
    
    return log_dta_activity(
        spark=spark,
        catalog=catalog,
        dta_id=dta_id,
        activity_category="WORKFLOW",
        activity_type=activity_type,
        activity_summary=summary,
        performed_by=performed_by,
        workflow_iteration=workflow_iteration,
        approver_role=approver_role,
        approver_name=approver_name,
        comment=comment,
        gold_schema=gold_schema
    )

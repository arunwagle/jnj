# Hash Generation Design

> **Status**: Implemented  
> **Last Updated**: January 2026

---

## Overview

The hash generation system creates deterministic, content-based identifiers (`definition_hash`) that uniquely identify metadata definitions regardless of their source. This enables:

- **Cross-trial deduplication**: Same variable definition used in multiple trials = single library entry
- **Change detection**: Modified definitions get new hashes, preserving history
- **Versioning support**: Hash + version forms composite key in gold layer

---

## Transfer Variables

Transfer variables use a **vendor-scoped semantic hash** that captures the definition fields along with vendor and data stream context.

### Hash Fields

The following fields are included in the hash calculation:

| Field | Description |
|-------|-------------|
| `data_provider_name` | Vendor name |
| `data_stream_type` | Data stream type (EDC, Lab, etc.) |
| `transfer_variable_name` | Variable name (e.g., SUBJECT_ID) |
| `transfer_variable_order` | Order/sequence in the transfer file |
| `format` | Data type (text, numeric, date, etc.) |
| `anticipated_max_length` | Maximum length for the field |
| `transfer_file_key` | Whether this is a key field |
| `populate_for_all_records` | Whether value is required for all records |
| `codelist_values_str` | Stringified codelist values |

### Result

- Same definition from same vendor+stream → **Same hash**
- Same definition from different vendors → **Different hash** (vendor-scoped)
- Any change to hash fields → **New hash**

---

## Test Concepts

Test concepts use a **vendor-scoped hash** that includes the complete transfer variable mapping for each row.

### Hash Fields

| Field | Description |
|-------|-------------|
| `data_provider_name` | Vendor name |
| `data_stream_type` | Data stream type |
| `transfer_tuple_map` | Complete JSON-serialized map of all transfer variable values for this test concept row |

### Result

- Same test concept from same vendor → **Same hash**
- Same test concept from different vendors → **Different hash** (vendor-scoped)
- Any change to the transfer variable mappings → **New hash**

---

## Hash Algorithm

### Transfer Variables

Uses `compute_definition_hash()` from `src/clinical_data_standards_framework/utils.py`:

**Steps:**
1. **Sort fields alphabetically** for deterministic ordering
2. **Normalize values**:
   - `None` → empty string `""`
   - `Boolean true` → `"1"`
   - `Boolean false` → `"0"`
   - `Numbers` → string representation
   - `Strings` → lowercase, trimmed whitespace
3. **Concatenate** with pipe `|` delimiter
4. **Compute SHA256** hash (64 hex characters)

**Example:**
```python
# Input
hash_record = {
    'data_provider_name': 'VendorA',
    'data_stream_type': 'EDC',
    'transfer_variable_name': 'SUBJECT_ID',
    'format': 'text',
    'anticipated_max_length': '50',
    ...
}

# After normalization and sorting, pipe-delimited:
# "50|vendora|edc|text|subject_id|..."

# Result: SHA256 hash (64 hex characters)
```

For Spark DataFrames, use `compute_definition_hash_spark()` which applies the same logic.

### Test Concepts

Uses an inline function in `nb_tsdta_test_concepts_processor.ipynb`:

**Steps:**
1. **Create dictionary** with keys: `data_provider`, `data_stream`, `tuple_map`
2. **Sort dictionary items** alphabetically
3. **JSON serialize** with `json.dumps(sorted_items, sort_keys=True)`
4. **Compute SHA256** hash (64 hex characters)

**Example:**
```python
# Input
hash_dict = {
    'data_provider': 'VendorA',
    'data_stream': 'Lab',
    'tuple_map': {'LBTESTCD': 'ALB', 'LBTEST': 'Albumin', ...}
}

# JSON serialized (sorted):
# '[["data_provider", "VendorA"], ["data_stream", "Lab"], ["tuple_map", {...}]]'

# Result: SHA256 hash (64 hex characters)
```

---

## Related Documentation

- [02_schema_design.readme.md](./02_schema_design.readme.md) - Table schemas including hash columns
- [04_versioning_design.readme.md](./04_versioning_design.readme.md) - How hash + version forms composite keys

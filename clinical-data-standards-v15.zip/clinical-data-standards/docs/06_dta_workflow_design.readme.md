# DTA Workflow Design

> **Status**: Implemented  
> **Last Updated**: January 2026

---

## Overview

The DTA approval flow manages the governance process from DTA creation through final approval. It supports:

- **Multi-party approval**: JNJ DAE, Vendor, Legal (future), Librarian
- **Ordered approval chain**: Approvers review in sequence based on `approval_order`
- **Rejection handling**: Any rejection returns DTA to editing state
- **Version creation**: Approval triggers DTA version creation
- **Multiple cycles**: Rejection increments `workflow_iteration` for resubmission

---

## Diagram

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| DTA Workflow Flow | Complete state transition diagram | [PNG](./diagrams/06_dta_workflow_flow.drawio.png) | [Draw.io](./diagrams/06_dta_workflow_flow.drawio) |

![DTA Workflow Flow](./diagrams/06_dta_workflow_flow.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/06_dta_workflow_flow.drawio)

---

## Approver Roles

| Role | Description | Mandatory |
|------|-------------|-----------|
| `JNJ_DAE` | JNJ Data Analytics Engineer | ✅ Yes |
| `VENDOR` | External Data Provider | ✅ Yes |
| `LEGAL` | Legal Review | ⚪ Optional (Future) |
| `LIBRARIAN` | Template creation (separate flow) | ✅ Yes |

Approvers are processed sequentially based on `approval_order` (1 → 2 → 3...).

---

## DTA Lifecycle States

### DTA Status

| Status | Description | Editable? |
|--------|-------------|-----------|
| `DRAFT` | DTA is being created/edited | ✅ Yes |
| `PENDING_APPROVAL` | Submitted, awaiting approval chain | ❌ No |
| `APPROVED` | All approvers approved | ❌ No |
| `REJECTED` | At least one approver rejected (returns to DRAFT) | ✅ Yes |
| `MANUAL_REVIEW` | Contains records needing manual review | ✅ Yes |

### Workflow Status

| Status | Description |
|--------|-------------|
| `NOT_STARTED` | Workflow created but not submitted |
| `IN_REVIEW` | Submitted and awaiting approvals |
| `APPROVED` | All approvers approved |
| `REJECTED` | At least one approver rejected |

### Approval Task Status

| Status | Description |
|--------|-------------|
| `PENDING` | Awaiting this approver's decision |
| `APPROVED` | Approver approved |
| `REJECTED` | Approver rejected |
| `SKIPPED` | Non-mandatory task skipped |

---

## State Transitions

| From | Trigger | To | Result |
|------|---------|-----|--------|
| DRAFT | Save changes | DRAFT | Draft version updated |
| DRAFT | Submit for review | PENDING_APPROVAL | First approver notified |
| PENDING_APPROVAL | Approver approves | PENDING_APPROVAL | Next approver notified |
| PENDING_APPROVAL | All approve | APPROVED | DTA version created |
| PENDING_APPROVAL | Any rejects | REJECTED → DRAFT | Returns for editing |
| APPROVED | Continue work | DRAFT | New workflow iteration |

---

## Librarian Flow (Template Creation)

Template creation is a **separate process** managed by the Librarian role, occurring **after** DTA approval.

### Key Concepts

- Templates are **scoped by (vendor, data_stream)** combination
- Each vendor+stream pair has its own independent template version sequence
- Multiple approved DTAs from the same vendor+stream are merged into a single template
- DTAs included in a template are marked as `PROMOTED`

### Differences from DTA Approval

| Aspect | DTA Approval | Template Creation |
|--------|--------------|-------------------|
| Trigger | User submits DTA | Librarian initiates |
| Approvers | JNJ_DAE → VENDOR → LEGAL | Librarian only |
| Scope | Single DTA | Multiple DTAs per vendor+stream |
| Result | DTA Approved version | DTA Template version |

---

## Related Documentation

- [03_status_lifecycle_design.readme.md](./03_status_lifecycle_design.readme.md) - Document and DTA status values
- [04_versioning_design.readme.md](./04_versioning_design.readme.md) - Version management and template creation

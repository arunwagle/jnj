"""
Study API - Provides endpoints for Study Management functionality.
Integrates with Databricks SQL to manage studies, vendors, and data streams.
"""

from flask import Blueprint, jsonify, request
from datetime import datetime
import os
import json
import uuid

# Import SQL client for database queries
from api.databricks_client import DatabricksSQLClient

study_bp = Blueprint('study_api', __name__, url_prefix='/api/study')


# ============================================================================
# DATABASE CONFIGURATION
# ============================================================================

def _get_db_config():
    """Get database configuration from environment variables"""
    return {
        "catalog": os.environ.get("CATALOG_NAME", "aira_test"),
        "gold_schema": os.environ.get("GOLD_SCHEMA", "gold_md"),
        "silver_schema": os.environ.get("SILVER_SCHEMA", "silver_md"),
        "bronze_schema": os.environ.get("BRONZE_SCHEMA", "bronze_md"),
        "warehouse_id": os.environ.get("DATABRICKS_WAREHOUSE_ID")
    }


def _get_sql_client():
    """Get SQL client instance - raises if not configured"""
    config = _get_db_config()
    if not config["warehouse_id"]:
        raise RuntimeError(
            "DATABRICKS_WAREHOUSE_ID environment variable not set. "
            "This app must run on Databricks with proper configuration in app.yaml."
        )
    return DatabricksSQLClient(config["warehouse_id"])


# ============================================================================
# STUDY QUERIES
# ============================================================================

def get_studies(client=None, config: dict = None, limit: int = 100) -> list:
    """
    Get all studies from the md_study table with protocol details from md_protocol_draft.
    
    Args:
        client: DatabricksSQLClient instance (optional)
        config: Database config dict (optional)
        limit: Maximum number of studies to return
    
    Returns:
        List of study records with protocol information
    """
    if config is None:
        config = _get_db_config()
    if client is None:
        client = _get_sql_client()
    
    study_table = f"{config['catalog']}.{config['gold_schema']}.md_study"
    protocol_table = f"{config['catalog']}.{config['silver_schema']}.md_protocol_draft"
    
    # Join with md_protocol_draft to get protocol status
    query = f"""
        SELECT 
            s.study_id,
            s.study_title,
            s.study_description,
            s.status as study_status,
            s.protocol_id,
            s.created_by_principal,
            CAST(s.created_ts AS STRING) as created_ts,
            CAST(s.last_updated_ts AS STRING) as last_updated_ts,
            -- Protocol details from silver
            p.status as protocol_status,
            p.protocol_title,
            p.protocol_version,
            p.section_count,
            p.document_id as protocol_document_id,
            p.databricks_job_id,
            p.databricks_run_id,
            CAST(p.last_updated_ts AS STRING) as protocol_updated_ts
        FROM {study_table} s
        LEFT JOIN {protocol_table} p ON s.protocol_id = p.protocol_id
        ORDER BY s.created_ts DESC
        LIMIT {limit}
    """
    
    try:
        results = client.execute_query(query)
        return results if results else []
    except Exception as e:
        print(f"Error fetching studies: {e}")
        # Fallback: try without protocol join if table doesn't exist yet
        try:
            fallback_query = f"""
                SELECT 
                    study_id,
                    study_title,
                    study_description,
                    status as study_status,
                    protocol_id,
                    created_by_principal,
                    CAST(created_ts AS STRING) as created_ts,
                    CAST(last_updated_ts AS STRING) as last_updated_ts,
                    NULL as protocol_status,
                    NULL as protocol_title,
                    NULL as protocol_version,
                    NULL as section_count,
                    NULL as protocol_document_id,
                    NULL as protocol_updated_ts
                FROM {study_table}
                ORDER BY created_ts DESC
                LIMIT {limit}
            """
            results = client.execute_query(fallback_query)
            return results if results else []
        except Exception as e2:
            print(f"Error with fallback query: {e2}")
            return []


def get_study_details(client, config: dict, study_id: str) -> dict:
    """
    Get details for a specific study including protocol info.
    
    Args:
        client: DatabricksSQLClient instance
        config: Database config dict
        study_id: The study ID to fetch
    
    Returns:
        Study details dict or None if not found
    """
    study_table = f"{config['catalog']}.{config['gold_schema']}.md_study"
    
    query = f"""
        SELECT 
            study_id,
            study_title,
            study_description,
            status,
            protocol_id,
            created_by_principal,
            CAST(created_ts AS STRING) as created_ts,
            CAST(last_updated_ts AS STRING) as last_updated_ts
        FROM {study_table}
        WHERE study_id = '{study_id}'
    """
    
    try:
        results = client.execute_query(query)
        if results and len(results) > 0:
            return results[0]
        return None
    except Exception as e:
        print(f"Error fetching study {study_id}: {e}")
        return None


def create_study(client, config: dict, study_title: str, study_description: str = None, 
                 created_by: str = None) -> dict:
    """
    Create a new study record in md_study table.
    
    Args:
        client: DatabricksSQLClient instance
        config: Database config dict
        study_title: Title of the study
        study_description: Optional description
        created_by: User creating the study
    
    Returns:
        Dict with study_id and status
    """
    study_table = f"{config['catalog']}.{config['gold_schema']}.md_study"
    
    # Generate study ID (simplified - in production might use a different format)
    study_id = f"STUDY-{uuid.uuid4().hex[:8].upper()}"
    protocol_id = f"PROTO-{uuid.uuid4().hex[:8].upper()}"
    
    # Escape single quotes in text fields
    safe_title = (study_title or '').replace("'", "''")
    safe_description = (study_description or '').replace("'", "''")
    safe_created_by = (created_by or 'unknown').replace("'", "''")
    
    insert_query = f"""
        INSERT INTO {study_table} (
            study_id,
            study_title,
            study_description,
            status,
            protocol_id,
            created_by_principal,
            created_ts,
            last_updated_by_principal,
            last_updated_ts
        )
        VALUES (
            '{study_id}',
            '{safe_title}',
            '{safe_description}',
            'IN_PROGRESS',
            '{protocol_id}',
            '{safe_created_by}',
            current_timestamp(),
            '{safe_created_by}',
            current_timestamp()
        )
    """
    
    try:
        client.execute_query(insert_query)
        return {
            "ok": True,
            "study_id": study_id,
            "protocol_id": protocol_id,
            "study_title": study_title,
            "status": "IN_PROGRESS"
        }
    except Exception as e:
        print(f"Error creating study: {e}")
        return {"ok": False, "error": str(e)}


def update_study_status(client, config: dict, study_id: str, status: str, 
                        updated_by: str = None) -> dict:
    """
    Update the status of a study.
    
    Args:
        client: DatabricksSQLClient instance
        config: Database config dict
        study_id: Study ID to update
        status: New status value
        updated_by: User making the update
    
    Returns:
        Dict with success status
    """
    study_table = f"{config['catalog']}.{config['gold_schema']}.md_study"
    safe_updated_by = (updated_by or 'unknown').replace("'", "''")
    
    update_query = f"""
        UPDATE {study_table}
        SET 
            status = '{status}',
            last_updated_by_principal = '{safe_updated_by}',
            last_updated_ts = current_timestamp()
        WHERE study_id = '{study_id}'
    """
    
    try:
        client.execute_query(update_query)
        return {"ok": True, "study_id": study_id, "status": status}
    except Exception as e:
        print(f"Error updating study status: {e}")
        return {"ok": False, "error": str(e)}


# ============================================================================
# VENDOR QUERIES
# ============================================================================

def get_vendors(client=None, config: dict = None) -> list:
    """
    Get all vendors from the md_vendor table.
    
    Returns:
        List of vendor records
    """
    if config is None:
        config = _get_db_config()
    if client is None:
        client = _get_sql_client()
    
    table = f"{config['catalog']}.{config['gold_schema']}.md_vendor"
    
    query = f"""
        SELECT 
            vendor_id,
            vendor_name,
            vendor_description,
            is_active
        FROM {table}
        WHERE is_active = true
        ORDER BY vendor_name
    """
    
    try:
        results = client.execute_query(query)
        return results if results else []
    except Exception as e:
        print(f"Error fetching vendors: {e}")
        return []


# ============================================================================
# DATA STREAM QUERIES
# ============================================================================

def get_data_streams(client=None, config: dict = None) -> list:
    """
    Get all data streams from the md_data_stream table.
    
    Returns:
        List of data stream records
    """
    if config is None:
        config = _get_db_config()
    if client is None:
        client = _get_sql_client()
    
    table = f"{config['catalog']}.{config['gold_schema']}.md_data_stream"
    
    query = f"""
        SELECT 
            data_stream_id,
            data_stream_name,
            data_stream_description,
            is_active
        FROM {table}
        WHERE is_active = true
        ORDER BY data_stream_name
    """
    
    try:
        results = client.execute_query(query)
        return results if results else []
    except Exception as e:
        print(f"Error fetching data streams: {e}")
        return []


# ============================================================================
# ACTIVITY QUERIES (from Protocol extraction)
# ============================================================================

def get_study_activities(client, config: dict, study_id: str) -> list:
    """
    Get activities extracted from protocol for a study.
    This queries the md_protocol_documents_details table for Schedule of Activities data.
    
    Args:
        client: DatabricksSQLClient instance
        config: Database config dict
        study_id: Study ID to get activities for
    
    Returns:
        List of activity records
    """
    details_table = f"{config['catalog']}.{config['bronze_schema']}.md_protocol_documents_details"
    
    # Query for Schedule of Activities sections
    query = f"""
        SELECT 
            section_id as activity_id,
            section_name as activity_name,
            content_order as timepoint,
            content_data,
            study_id,
            protocol_id
        FROM {details_table}
        WHERE study_id = '{study_id}'
          AND section_name LIKE '%Schedule%' OR section_name LIKE '%Activities%'
          AND content_type = 'table'
        ORDER BY content_order
    """
    
    try:
        results = client.execute_query(query)
        
        # Transform results to include mock vendor/stream assignments
        activities = []
        if results:
            for row in results:
                activities.append({
                    "activity_id": row.get("activity_id"),
                    "activity_name": row.get("activity_name", "Unknown Activity"),
                    "timepoint": row.get("timepoint"),
                    "vendor_id": None,  # To be assigned by user
                    "data_stream_id": None,  # To be assigned by user
                    "content_data": row.get("content_data")
                })
        
        return activities
    except Exception as e:
        print(f"Error fetching study activities: {e}")
        return []


def assign_activity_vendor_stream(client, config: dict, study_id: str, activity_id: str,
                                   vendor_id: str = None, data_stream_id: str = None) -> dict:
    """
    Assign vendor and/or data stream to an activity.
    Note: In this mock implementation, we just return success.
    In production, this would update a mapping table.
    
    Args:
        client: DatabricksSQLClient instance
        config: Database config dict
        study_id: Study ID
        activity_id: Activity ID to update
        vendor_id: Vendor ID to assign (optional)
        data_stream_id: Data stream ID to assign (optional)
    
    Returns:
        Dict with success status
    """
    # In a full implementation, this would update an activity_assignments table
    # For now, we just log and return success
    print(f"Assigning activity {activity_id} in study {study_id}: vendor={vendor_id}, stream={data_stream_id}")
    
    return {
        "ok": True,
        "activity_id": activity_id,
        "vendor_id": vendor_id,
        "data_stream_id": data_stream_id
    }


# ============================================================================
# JOB TRIGGER FUNCTIONS
# ============================================================================

def trigger_setup_study_job(study_id: str, study_title: str, study_description: str,
                            protocol_id: str, source_root: str = "test",
                            source_subdir: str = None, catalog_override: str = None) -> dict:
    """
    Trigger the job_cdm_setup_study Databricks job.
    
    Args:
        study_id: Study ID
        study_title: Study title
        study_description: Study description
        protocol_id: Protocol ID
        source_root: Source root path for file processing
    
    Returns:
        Dict with run_id and status
    """
    from databricks.sdk import WorkspaceClient
    
    try:
        w = WorkspaceClient()
        
        # Find the job by name - search for jobs containing "job_cdm_setup_study"
        # Jobs may have environment prefix like [test] or [dev]
        job_name_pattern = "job_cdm_setup_study"
        matching_job = None
        
        print(f"Searching for job containing: {job_name_pattern}")
        
        for job in w.jobs.list():
            job_name = job.settings.name if job.settings else ""
            if job_name_pattern in job_name:
                print(f"Found matching job: {job_name} (id: {job.job_id})")
                matching_job = job
                break
        
        if not matching_job:
            # List all jobs for debugging
            all_jobs = list(w.jobs.list())
            job_names = [j.settings.name for j in all_jobs[:20] if j.settings]
            print(f"Available jobs (first 20): {job_names}")
            return {"ok": False, "error": f"Job containing '{job_name_pattern}' not found. Available jobs: {job_names[:5]}"}
        
        job_id = matching_job.job_id
        
        # Get catalog from config if not provided
        if not catalog_override:
            config = _get_db_config()
            catalog_override = config.get("catalog", "dta_poc_test")
        
        print(f"Triggering job with catalog_override: {catalog_override}")
        
        # Trigger the job with parameters
        run = w.jobs.run_now(
            job_id=job_id,
            job_parameters={
                "catalog_override": catalog_override,
                "study_id": study_id,
                "study_title": study_title,
                "study_description": study_description or "",
                "protocol_id": protocol_id,
                "source_root": source_root,
                "source_subdir": source_subdir or ""
            }
        )
        
        return {
            "ok": True,
            "run_id": run.run_id,
            "job_id": job_id
        }
    except Exception as e:
        print(f"Error triggering setup study job: {e}")
        import traceback
        traceback.print_exc()
        return {"ok": False, "error": str(e)}


# ============================================================================
# BLUEPRINT ROUTES
# ============================================================================

@study_bp.route('/list', methods=['GET'])
def api_get_studies():
    """API endpoint to get all studies"""
    try:
        studies = get_studies()
        return jsonify({"ok": True, "studies": studies})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@study_bp.route('/vendors', methods=['GET'])
def api_get_vendors():
    """API endpoint to get all vendors"""
    try:
        vendors = get_vendors()
        return jsonify({"ok": True, "vendors": vendors})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@study_bp.route('/data-streams', methods=['GET'])
def api_get_data_streams():
    """API endpoint to get all data streams"""
    try:
        streams = get_data_streams()
        return jsonify({"ok": True, "data_streams": streams})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@study_bp.route('/<study_id>', methods=['GET'])
def api_get_study_details(study_id):
    """API endpoint to get study details"""
    try:
        config = _get_db_config()
        client = _get_sql_client()
        study = get_study_details(client, config, study_id)
        
        if study:
            return jsonify({"ok": True, "study": study})
        else:
            return jsonify({"ok": False, "error": "Study not found"}), 404
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@study_bp.route('/<study_id>/activities', methods=['GET'])
def api_get_study_activities(study_id):
    """API endpoint to get activities for a study"""
    try:
        config = _get_db_config()
        client = _get_sql_client()
        activities = get_study_activities(client, config, study_id)
        return jsonify({"ok": True, "activities": activities})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


# Version Manager - SCD Type 2 Versioning System

> **Related Documentation:**
> - [06_dta_workflow_design.readme.md](./06_dta_workflow_design.readme.md) - Workflow, approval chain, and governance

### Diagrams

| Diagram | Description | View | Edit |
|---------|-------------|------|------|
| Template Scoping | Vendor+Stream scope organization | [PNG](./diagrams/04_template_scoping.drawio.png) | [Draw.io](./diagrams/04_template_scoping.drawio) |
| Creating DTA Templates | Input DTAs → Merge → Output templates | [PNG](./diagrams/04_creating_dta_templates.drawio.png) | [Draw.io](./diagrams/04_creating_dta_templates.drawio) |
| Incremental Template Updates | Existing template + new DTA → v2.0 | [PNG](./diagrams/04_incremental_template_updates.drawio.png) | [Draw.io](./diagrams/04_incremental_template_updates.drawio) |
| Basic Flow - Branch from Template | Full lifecycle state transitions | [PNG](./diagrams/04_basic_flow_branch.drawio.png) | [Draw.io](./diagrams/04_basic_flow_branch.drawio) |
| Multi-Vendor Template Creation | Grouping DTAs by vendor+stream | [PNG](./diagrams/04_multi_vendor_template.drawio.png) | [Draw.io](./diagrams/04_multi_vendor_template.drawio) |
| Parallel DTA Development | Multiple DTAs working simultaneously | [PNG](./diagrams/04_parallel_dta_development.drawio.png) | [Draw.io](./diagrams/04_parallel_dta_development.drawio) |

## Overview

The Clinical Data Standards platform uses **SCD Type 2 (Slowly Changing Dimension)** versioning to track all changes to transfer variable definitions. This enables:

- **Full audit trail** of every change
- **Parallel DTA development** without collisions
- **Point-in-time queries** for any historical version
- **Approval workflows** with version promotion
- **Vendor+Stream scoped templates** for reusable standards

---

## 📊 Version Types

The system supports three distinct version types:

### 1. **DTA Template** (Canonical Standard per Vendor+Stream)
- **Format**: `1.0`, `2.0`, `3.0`, etc.
- **Purpose**: The canonical, production-ready standard **scoped by vendor and data stream**
- **Characteristics**:
  - `version_type = 'DTA_TEMPLATE'`
  - Each (vendor, data_stream) combination has its own version sequence
  - New DTAs can branch from any DTA Template version
- **Example**: `version = "1.0"` for Vendor_A / EDC_Data
- **Creation**: Requires **Librarian role** approval; merges multiple approved DTAs from the same vendor+stream

### 2. **DTA Draft Version** (Work in Progress)
- **Format**: `{template}-{dta_number}-draft{n}`
- **Example**: `1.0-DTA001-draft1`, `1.0-DTA001-draft2`
- **Purpose**: Editable working copies for a specific DTA
- **Characteristics**:
  - `version_type = 'DTA_DRAFT'`
  - Can have multiple sequential drafts (draft1, draft2, draft3...)
- **Lifecycle**: Created → Edited → Superseded → Closed

### 3. **DTA Approved Version** (Approved DTA)
- **Format**: `{template}-{dta_number}-v{n}.0`
- **Example**: `1.0-DTA001-v1.0`, `1.0-DTA001-v2.0`
- **Purpose**: Approved, finalized version for a specific DTA
- **Characteristics**:
  - `version_type = 'DTA_APPROVED'`
  - Created when workflow approval completes
  - **Can be used as a source for new DTA branches** (reuse approved definitions)
- **Lifecycle**: Approved draft becomes DTA Approved

---

## 🔄 Version Manager Operations

The `job_cdm_version_manager` supports five mutually exclusive operations using `condition_task` chain for true if-else branching:

### 1. `CREATE_BRANCH` - Start New DTA

**Trigger**: UI initiates new DTA creation

**Source Options** (user chooses one):
- **DTA Template** (e.g., `1.0`, `2.0`) - Start from canonical standard for a vendor+stream
- **DTA Approved Version** (e.g., `1.0-DTA001-v1.0`) - Reuse another DTA's approved definitions

**What it does**:
1. User selects source version (DTA Template or DTA Approved)
2. Copies all records from selected source
3. Creates new draft version (e.g., `1.0-DTA002-draft1`)
4. Registers version in `md_version_registry` with `parent_version` reference

**SCD Type 2**:
- Source records: Unchanged
- New draft records: `is_current = TRUE`, `effective_end_ts = NULL`

**Example 1: Branch from DTA Template**

`Template v1.0 (Vendor_A/EDC)` → **COPY** → `1.0-DTA001-draft1` *(parent_version = "1.0")*

**Example 2: Branch from DTA Approved** (reuse approved DTA)

`1.0-DTA001-v1.0` → **COPY** → `1.0-DTA002-draft1` *(parent_version = "1.0-DTA001-v1.0")*

**Use Cases for DTA Approved branching**:
- Similar trial needs same variable definitions
- Reuse vendor-specific customizations
- Start from a known-good configuration

---

### 2. `SAVE_DRAFT` - Save Changes

**Trigger**: User saves edits in the UI

**What it does**:
1. Closes current draft (set `is_current = FALSE`, `effective_end_ts = NOW()`)
2. Creates new draft with changes (e.g., `1.0-DTA001-draft2`)
3. Updates registry: old draft → `SUPERSEDED`, new draft → `ACTIVE`

**SCD Type 2**:
- Old draft: `is_current = FALSE`, `effective_end_ts = NOW()`
- New draft: `is_current = TRUE`, `effective_start_ts = NOW()`

`1.0-DTA001-draft1` → **SCD2 CLOSE** → `1.0-DTA001-draft2`
- Old: `is_current=FALSE`, `effective_end_ts` set
- New: `is_current=TRUE`, new records

**Note**: If a field value changes (e.g., `max_length: 20 → 50`), a new `definition_hash` is generated.

---

### 3. `APPROVE_DTA` - Promote Draft to DTA Approved

**Trigger**: Workflow approval completes (all approvers in `DTA_APPROVAL_TASK` approve)

**What it does**:
1. Closes current draft
2. Creates DTA Approved version (e.g., `1.0-DTA001-v1.0`)
3. Sets `version_type = 'DTA_APPROVED'`
4. Updates DTA entity with `version`

**SCD Type 2**:
- Draft: `is_current = FALSE`, `effective_end_ts = NOW()`
- DTA Approved: `is_current = TRUE`, `version_type = 'DTA_APPROVED'`

`1.0-DTA001-draft2` → **APPROVE** → `1.0-DTA001-v1.0` *(DTA Approved)*

---

### 4. `CREATE_DTA_APPROVED` - Direct DTA Approved Creation

**Trigger**: Historical data import or API call

**What it does**:
1. Creates DTA Approved directly from silver data (skips draft phase)
2. Used for historical DTAs that are already approved
3. Registers version with `version_type = DTA_APPROVED`

**Use Case**: Processing historical tsDTA files that represent already-executed DTAs.

`Silver Data` → **DIRECT CREATE** → `1.0-DTA001-v1.0` *(DTA Approved)*

---

### 5. `CREATE_DTA_TEMPLATE` - Create Vendor+Stream Scoped Templates

**Trigger**: Librarian role initiates template creation after review

**Authorization**: Requires **Librarian role** approval

**Key Behavior**: Templates are **scoped by (vendor, data_stream)** combination. Each vendor+stream pair has its own independent template version sequence.

**What it does**:
1. Groups all approved DTAs by `(data_provider_name, data_stream_type)`
2. For each group:
   - Finds the current DTA Template for that vendor+stream (if exists)
   - Identifies new approved DTAs not yet included in any template
   - Merges new DTAs with existing template records
   - Creates a new DTA_TEMPLATE version (e.g., "1.0" for first, "2.0" for next)
3. Closes previous template for that vendor+stream using SCD Type 2
4. Updates DTA `status` to `PROMOTED` for all merged DTAs
5. Tracks which DTAs were included in each template (`included_dta_ids`)

**SCD Type 2**:
- Old Template: `is_current = FALSE`, `effective_end_ts = NOW()`
- New Template: `is_current = TRUE`, `version_type = 'DTA_TEMPLATE'`

---

## 📚 DTA Template Creation - Vendor+Stream Scoped

This section provides detailed information about how DTA Templates are created using **vendor+stream scoping** and **incremental merging**.

### Template Scoping

**Key Concept**: Each `(data_provider_name, data_stream_type)` combination has its own independent template version sequence.

![Template Scoping](./diagrams/04_template_scoping.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/04_template_scoping.drawio)

**Benefits of Vendor+Stream Scoping**:
- ✅ Templates are tailored to specific vendor conventions
- ✅ Different data streams have independent standards
- ✅ No collision between vendors
- ✅ Incremental improvement per vendor+stream

### Example: Creating DTA Templates

**Scenario**: Three DTAs are approved:
- DTA001: Vendor_A / EDC_Data (85 records)
- DTA002: Vendor_A / EDC_Data (10 new records)
- DTA003: Vendor_B / Lab_Data (50 records)

**Result after `CREATE_DTA_TEMPLATE`**:

```
Created Templates:
┌─────────────────────────────────────────────────────────────┐
│ Vendor_A / EDC_Data                                         │
│   Template v1.0: 95 records (85 + 10, minus duplicates)     │
│   Included DTAs: [DTA001, DTA002]                           │
├─────────────────────────────────────────────────────────────┤
│ Vendor_B / Lab_Data                                         │
│   Template v1.0: 50 records                                 │
│   Included DTAs: [DTA003]                                   │
└─────────────────────────────────────────────────────────────┘

DTA Status Updates:
  - DTA001: APPROVED → PROMOTED
  - DTA002: APPROVED → PROMOTED  
  - DTA003: APPROVED → PROMOTED
```

![Creating DTA Templates](./diagrams/04_creating_dta_templates.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/04_creating_dta_templates.drawio)

### Incremental Template Updates

**Scenario**: Template v1.0 exists for Vendor_A/EDC_Data. DTA004 (same vendor+stream) is approved.

```
Before:
- Template v1.0: 95 records (from DTA001, DTA002)
- DTA001, DTA002: status = PROMOTED
- DTA004: status = APPROVED (new, not in template)

After CREATE_DTA_TEMPLATE:
- Template v1.0: CLOSED (is_current=FALSE)
- Template v2.0: 105 records (95 + 10 from DTA004, minus duplicates)
  - included_dta_ids: [DTA001, DTA002, DTA004]
- DTA004: status = PROMOTED
```

![Incremental Template Updates](./diagrams/04_incremental_template_updates.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/04_incremental_template_updates.drawio)

### Registry Metadata for Templates

The `md_version_registry` now stores vendor+stream scoping:

| Column | Value |
|--------|-------|
| `version` | `2.0` |
| `version_type` | `DTA_TEMPLATE` |
| `library_type` | `transfer_variables` |
| `data_provider_name` | `Vendor_A` |
| `data_stream_type` | `EDC_Data` |
| `included_dta_ids` | `["DTA001", "DTA002", "DTA004"]` |
| `parent_version` | `1.0` (previous template for this vendor+stream) |
| `record_count` | 105 |
| `status` | `ACTIVE` |

### Definition Hash Includes Vendor+Stream

The `definition_hash` now includes vendor and stream to ensure templates are properly scoped:

```python
definition_hash = SHA256(
    data_provider_name +
    data_stream_type +
    transfer_variable_name + 
    data_type + 
    max_length + 
    required_flag + 
    codelist_reference + ...
)
```

This means:
- Same variable definition for different vendors = **different hashes**
- Vendor-specific conventions are preserved
- No accidental cross-vendor merging

### Merge Strategies

When the same `definition_hash` exists in both current template and new DTAs, the strategy determines which record to keep:

| Strategy | Description | Use Case |
|----------|-------------|----------|
| `UNION_DEDUP` | Combine all records, deduplicate by `definition_hash` (arbitrary pick) | **Default** - preserves unique definitions |
| `LATEST_WINS` | On duplicate `definition_hash`, keep newest record (new DTA overrides template) | Prefer newer standards |
| `FIRST_WINS` | On duplicate `definition_hash`, keep oldest record (template preserved) | Preserve original definitions |

### Running Template Creation

**Via UI Approvals Page:**
The Approvals page shows cards for each vendor+stream combination with approved DTAs ready for template creation. Click "Create Template" to trigger the job.

**Via Test Job:**
```bash
databricks jobs run-now --job-name job_cdm_create_dta_template_test
```

**Via Version Manager:**
```bash
databricks jobs run-now --job-name job_cdm_version_manager \
  --job-parameters '{
    "action": "CREATE_DTA_TEMPLATE",
    "merge_strategy": "UNION_DEDUP",
    "library_type": "transfer_variables",
    "data_provider_name": "Vendor_A",
    "data_stream_type": "EDC_Data"
  }'
```

**Process ALL vendor+stream combinations:**
```bash
databricks jobs run-now --job-name job_cdm_version_manager \
  --job-parameters '{
    "action": "CREATE_DTA_TEMPLATE",
    "merge_strategy": "UNION_DEDUP"
  }'
```

### Post-Template Validation

Run these queries to verify template creation:

```sql
-- Check new templates by vendor+stream
SELECT version, library_type, data_provider_name, data_stream_type, 
       record_count, included_dta_ids, created_ts
FROM gold_md.md_version_registry
WHERE version_type = 'DTA_TEMPLATE'
ORDER BY created_ts DESC;

-- Verify DTAs are marked as PROMOTED
SELECT dta_id, dta_number, data_provider_name, data_stream_type, status
FROM gold_md.dta
WHERE status = 'PROMOTED';

-- Count records per template
SELECT version, data_provider_name, data_stream_type, COUNT(*) as record_count
FROM gold_md.md_dta_transfer_variables
WHERE is_current = TRUE AND is_major_version = TRUE
GROUP BY version, data_provider_name, data_stream_type;
```

---

## 📋 Version Tag Format

| Version Type | Format | Example |
|--------------|--------|---------|
| DTA Template | `{major}.0` | `1.0`, `2.0` (per vendor+stream) |
| DTA Draft | `{template}-{dta_number}-draft{n}` | `1.0-DTA001-draft1` |
| DTA Approved | `{template}-{dta_number}-v{n}.0` | `1.0-DTA001-v1.0` |

**Components**:
- `{template}`: Parent template version (e.g., `1.0`)
- `{dta_number}`: Sequential DTA identifier (e.g., `DTA001`, `DTA002`)
- `draft{n}`: Draft sequence number (1, 2, 3...)
- `v{n}.0`: Major version within the DTA

---

## 🗄️ Key Tables

### `md_dta_transfer_variables`
The main versioned table using SCD Type 2:

| Column | Description |
|--------|-------------|
| `definition_hash` | Unique hash of field definition (includes vendor+stream) |
| `version` | Version tag (e.g., `1.0`, `1.0-DTA001-draft1`) |
| `data_provider_name` | Vendor name for this record |
| `data_stream_type` | Data stream type for this record |
| `is_major_version` | `TRUE` only for DTA Template versions |
| `is_dta_major` | `TRUE` for approved DTA versions |
| `parent_version` | Version this was branched from |
| `effective_start_ts` | When this version became active |
| `effective_end_ts` | When this version was closed (`NULL` = active) |
| `is_current` | `TRUE` for the active version of each record |

### `md_version_registry`
Lightweight metadata for all versions:

| Column | Description |
|--------|-------------|
| `version` | Unique version identifier |
| `version_type` | `DTA_TEMPLATE`, `DTA_DRAFT`, or `DTA_APPROVED` |
| `library_type` | Type of metadata (e.g., `transfer_variables`, `test_concepts`) |
| `dta_id` | Associated DTA (NULL for template versions) |
| `data_provider_name` | Vendor name (for templates) |
| `data_stream_type` | Data stream type (for templates) |
| `included_dta_ids` | Array of DTA IDs merged into this template |
| `parent_version` | Version this was derived from |
| `record_count` | Number of records in this version |
| `status` | `ACTIVE` or `SUPERSEDED` |

---

## 🔀 State Transitions

### Basic Flow (Branch from Template)

![Basic Flow - Branch from Template](./diagrams/04_basic_flow_branch.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/04_basic_flow_branch.drawio)

### Multi-Vendor Template Creation

![Multi-Vendor Template Creation](./diagrams/04_multi_vendor_template.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/04_multi_vendor_template.drawio)

---

## 🔄 Parallel DTA Development

Multiple DTAs can work simultaneously without conflicts:

![Parallel DTA Development](./diagrams/04_parallel_dta_development.drawio.png)

📝 [Edit Diagram (Draw.io)](./diagrams/04_parallel_dta_development.drawio)

**Key Points**:
- Each DTA has isolated version tags
- Changes in one DTA don't affect others
- Multiple DTAs can be merged into template (incrementing version numbers)
- Templates are scoped by vendor+stream

---

## 🔍 Querying Versions

### Get Current Template for Vendor+Stream
```sql
SELECT * FROM gold_md.md_dta_transfer_variables
WHERE is_major_version = TRUE 
  AND is_current = TRUE
  AND data_provider_name = 'Vendor_A'
  AND data_stream_type = 'EDC_Data'
```

### Get Specific DTA's Current Draft
```sql
SELECT * FROM silver_md.md_dta_transfer_variables_draft
WHERE version LIKE '%-DTA001-%' AND is_current = TRUE
```

### Get Point-in-Time Version
```sql
SELECT * FROM gold_md.md_dta_transfer_variables
WHERE version = '1.0'
  AND data_provider_name = 'Vendor_A'
  AND effective_start_ts <= '2025-01-15'
  AND (effective_end_ts IS NULL OR effective_end_ts > '2025-01-15')
```

### Get Version History
```sql
SELECT version, version_type, status, data_provider_name, data_stream_type, created_ts
FROM gold_md.md_version_registry
WHERE dta_id = 'DTA001'
ORDER BY created_ts
```

### Get All Templates by Vendor
```sql
SELECT version, data_provider_name, data_stream_type, record_count, included_dta_ids, status
FROM gold_md.md_version_registry
WHERE version_type = 'DTA_TEMPLATE'
ORDER BY data_provider_name, data_stream_type, version DESC
```

---

## 📁 Related Files

### Job Definitions
```
resources/data_engineering/clinical_data_standards/jobs/
└── job_cdm_version_manager.job.yml

resources/data_engineering/test/jobs/
└── job_cdm_create_dta_template_test.job.yml  # Test job for template creation
```

### Notebooks (by action)
```
notebooks/data_engineering/common/
├── nb_version_create_branch.ipynb    # CREATE_BRANCH
├── nb_version_save_draft.ipynb       # SAVE_DRAFT
├── nb_version_approve_dta.ipynb      # APPROVE_DTA / CREATE_DTA_APPROVED
└── nb_promote_to_template.ipynb      # CREATE_DTA_TEMPLATE (auto-merge by vendor+stream)
```

### Core Library
```
src/clinical_data_standards_framework/
└── versioning.py    # Core versioning functions including:
                     #   - merge_dtas_to_template()
                     #   - get_next_template_version_for_vendor_stream()
                     #   - get_current_template_for_vendor_stream()
```

---

## 🔑 Design Principles

1. **Immutability**: Records are never updated in place; new versions are created
2. **Full History**: All changes are preserved with timestamps
3. **Isolation**: DTAs work in isolated version spaces
4. **Traceability**: Every version links to its parent via `parent_version`
5. **Atomic Operations**: Each operation is a complete, consistent state change
6. **Vendor+Stream Scoping**: Templates are independent per vendor+stream combination
7. **Incremental Merging**: Only new DTAs are merged; already-promoted DTAs are skipped

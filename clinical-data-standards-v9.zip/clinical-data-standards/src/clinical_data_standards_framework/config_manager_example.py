"""
Example usage of ConfigManager API

This file demonstrates how to use the ConfigManager to:
1. Get pipeline step configurations
2. Get service configurations
3. Process configurations in your notebooks/jobs
"""

from config_manager import ConfigManager


def example_usage():
    """Example demonstrating ConfigManager API usage."""
    
    # ============================================================
    # Initialize ConfigManager
    # ============================================================
    
    # Option 1: With default target (dev)
    config = ConfigManager(config_path="config/sales_data_config.yaml")
    
    # Option 2: With specific target
    config = ConfigManager(
        config_path="config/sales_data_config.yaml",
        target="prod"
    )
    
    print("✅ ConfigManager initialized")
    print(f"   Target: {config.target}")
    print(f"   Config: {config.config_path}\n")
    
    # ============================================================
    # API 1: Get Pipeline Step Configuration
    # ============================================================
    
    print("=" * 60)
    print("API 1: get_pipeline_step()")
    print("=" * 60)
    
    # Get parse_document step configuration
    step_config = config.get_pipeline_step(
        use_case="SALES_DATA_PROCESSING",
        document_type="pdf",
        document_subtype="standard",
        step_name="parse_document"
    )
    
    print("\n📋 Step: parse_document")
    print(f"   Service: {step_config.get('service')}")
    print(f"   Source Path: {step_config.get('source_path')}")
    print(f"   Output Table: {step_config.get('output_table')}")
    print(f"   Partition By: {step_config.get('partition_by')}")
    
    # Get extract_entities step configuration
    step_config = config.get_pipeline_step(
        use_case="SALES_DATA_PROCESSING",
        document_type="pdf",
        document_subtype="standard",
        step_name="extract_entities"
    )
    
    print("\n📋 Step: extract_entities")
    print(f"   Service: {step_config.get('service')}")
    print(f"   Input Column: {step_config.get('input_column')}")
    print(f"   Output Column: {step_config.get('output_column')}")
    print(f"   Output Table: {step_config.get('output_table')}")
    print(f"   Prompt Template: {step_config.get('prompt_template')[:50]}...")
    
    # ============================================================
    # API 2: Get Service Configuration
    # ============================================================
    
    print("\n" + "=" * 60)
    print("API 2: get_service()")
    print("=" * 60)
    
    # Get document parser service
    parser_service = config.get_service("document_parser_default")
    
    print("\n🔧 Service: document_parser_default")
    print(f"   Type: {parser_service.get('type')}")
    print(f"   Engine: {parser_service.get('engine')}")
    print(f"   Extract Text: {parser_service.get('extract_text')}")
    print(f"   Extract Tables: {parser_service.get('extract_tables')}")
    print(f"   Timeout: {parser_service.get('timeout_seconds')}s")
    
    # Get entity extractor service
    extractor_service = config.get_service("entity_extractor_default")
    
    print("\n🔧 Service: entity_extractor_default")
    print(f"   Type: {extractor_service.get('type')}")
    print(f"   Endpoint: {extractor_service.get('endpoint_name')}")
    print(f"   Max Tokens: {extractor_service.get('max_tokens')}")
    print(f"   Temperature: {extractor_service.get('temperature')}")
    print(f"   Timeout: {extractor_service.get('timeout_seconds')}s")
    
    # ============================================================
    # Helper Methods (Optional)
    # ============================================================
    
    print("\n" + "=" * 60)
    print("Helper Methods")
    print("=" * 60)
    
    # List all services
    services = config.list_services()
    print(f"\n📦 Available Services: {', '.join(services)}")
    
    # List all use cases
    use_cases = config.list_use_cases()
    print(f"📊 Available Use Cases: {', '.join(use_cases)}")
    
    # Get globals
    globals_config = config.get_globals()
    print(f"\n🌐 Globals:")
    print(f"   Catalog: {globals_config.get('catalog')}")
    print(f"   Bronze Schema: {globals_config.get('bronze_schema')}")
    print(f"   Silver Schema: {globals_config.get('silver_schema')}")
    print(f"   Gold Schema: {globals_config.get('gold_schema')}")
    
    # Get all steps for a pipeline
    all_steps = config.get_all_steps(
        use_case="SALES_DATA_PROCESSING",
        document_type="pdf",
        document_subtype="standard"
    )
    print(f"\n📝 All Steps in Pipeline: {len(all_steps)} steps")
    for i, step in enumerate(all_steps, 1):
        print(f"   {i}. {step.get('step')}")


def notebook_processing_example():
    """
    Example: How to use ConfigManager in a Databricks notebook
    for processing a specific step.
    """
    
    print("\n" + "=" * 60)
    print("Notebook Processing Example")
    print("=" * 60)
    
    # Initialize
    config = ConfigManager("config/sales_data_config.yaml", target="dev")
    
    # Notebook receives these parameters from job
    use_case = "SALES_DATA_PROCESSING"
    document_type = "pdf"
    document_subtype = "standard"
    step_name = "parse_document"
    
    print(f"\n📥 Processing Parameters:")
    print(f"   Use Case: {use_case}")
    print(f"   Document Type: {document_type}")
    print(f"   Document Subtype: {document_subtype}")
    print(f"   Step: {step_name}")
    
    # Step 1: Get step configuration
    step_config = config.get_pipeline_step(
        use_case=use_case,
        document_type=document_type,
        document_subtype=document_subtype,
        step_name=step_name
    )
    
    print(f"\n✅ Step Configuration Loaded")
    
    # Step 2: Get service configuration
    service_name = step_config.get("service")
    service_config = config.get_service(service_name)
    
    print(f"✅ Service Configuration Loaded: {service_name}")
    
    # Step 3: Process using configurations
    print(f"\n🚀 Processing:")
    print(f"   Service Type: {service_config.get('type')}")
    
    if service_config.get('type') == 'document_parsing':
        print(f"   Engine: {service_config.get('engine')}")
        print(f"   Extract Tables: {service_config.get('extract_tables')}")
        print(f"   Output: {step_config.get('output_table')}")
        
        # Your actual processing logic here
        # result = parse_document(
        #     source_path=step_config.get('source_path'),
        #     engine=service_config.get('engine'),
        #     extract_tables=service_config.get('extract_tables'),
        #     ...
        # )
        
    elif service_config.get('type') == 'model_serving':
        print(f"   Endpoint: {service_config.get('endpoint_name')}")
        print(f"   Max Tokens: {service_config.get('max_tokens')}")
        print(f"   Prompt: {step_config.get('prompt_template', 'N/A')[:50]}...")
        
        # Your actual processing logic here
        # result = call_model_serving(
        #     endpoint=service_config.get('endpoint_name'),
        #     prompt=step_config.get('prompt_template'),
        #     max_tokens=service_config.get('max_tokens'),
        #     ...
        # )
    
    print("✅ Processing Complete\n")


def error_handling_example():
    """
    Example: Error handling with ConfigManager
    """
    
    print("\n" + "=" * 60)
    print("Error Handling Example")
    print("=" * 60)
    
    config = ConfigManager("config/sales_data_config.yaml")
    
    # Example 1: Invalid use case
    try:
        step = config.get_pipeline_step(
            use_case="INVALID_USECASE",
            document_type="pdf",
            document_subtype="standard",
            step_name="parse_document"
        )
    except ValueError as e:
        print(f"\n❌ Error caught: {e}")
    
    # Example 2: Invalid service
    try:
        service = config.get_service("non_existent_service")
    except ValueError as e:
        print(f"❌ Error caught: {e}")
    
    # Example 3: Invalid step
    try:
        step = config.get_pipeline_step(
            use_case="SALES_DATA_PROCESSING",
            document_type="pdf",
            document_subtype="standard",
            step_name="invalid_step"
        )
    except ValueError as e:
        print(f"❌ Error caught: {e}")
    
    print("\n✅ All errors handled gracefully\n")


if __name__ == "__main__":
    """
    Run examples:
    python config_manager_example.py
    """
    
    print("\n" + "=" * 80)
    print(" ConfigManager API Examples")
    print("=" * 80)
    
    # Run examples
    example_usage()
    notebook_processing_example()
    error_handling_example()
    
    print("=" * 80)
    print("✅ All examples completed successfully!")
    print("=" * 80 + "\n")


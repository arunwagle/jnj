"""
Upload API - File Upload to Databricks Volumes and Job Triggering
=================================================================

This module provides endpoints for:
1. Uploading ZIP files to Unity Catalog Volumes
2. Triggering the job_cdm_dta_import job with parameters
3. Getting job run status and URL

Uses Databricks SDK for:
- w.files.upload() - Upload file to Unity Catalog Volume
- w.jobs.list() - Find job by name
- w.jobs.run_now() - Trigger job with parameters
"""

import os
import io
from datetime import datetime
from flask import Blueprint, request, jsonify
from databricks.sdk import WorkspaceClient

upload_bp = Blueprint('upload', __name__, url_prefix='/api/upload')


def get_workspace_client():
    """Get configured Databricks WorkspaceClient."""
    return WorkspaceClient()


def get_upload_config():
    """Get upload configuration from environment variables."""
    catalog = os.environ.get('CATALOG_NAME', 'aira_test')
    bronze_schema = os.environ.get('BRONZE_SCHEMA', 'bronze_md')
    
    return {
        'catalog': catalog,
        'bronze_schema': bronze_schema,
        'volume_name': 'clinical_data_standards',
        'source_root': 'test',  # Default source_root for job
        'job_name': 'job_cdm_dta_import'
    }


# Document type to folder mapping
DOCUMENT_TYPE_FOLDERS = {
    'tsDTA': 'dta',
    'Protocol': 'protocol',
    'ZIP Archive': 'zip',
    'Operational Agreement': 'operational_agreement',
    'SOW': 'sow',
    'Dictionary': 'dictionary'
}


def get_upload_folder(document_type: str, source_root: str) -> str:
    """
    Get the upload folder path based on document type and date.
    
    Structure: source_root/<type_folder>/<YYYY-MM-DD>/uploads/
    
    Args:
        document_type: Type of document (tsDTA, Protocol, etc.)
        source_root: Base source root (e.g., 'test', 'historical_data')
    
    Returns:
        Folder path like 'test/dta/2025-12-23/uploads'
    """
    # Get folder name for document type (default to 'other' if unknown)
    type_folder = DOCUMENT_TYPE_FOLDERS.get(document_type, 'other')
    
    # Get today's date
    today = datetime.now().strftime('%Y-%m-%d')
    
    # Build path: source_root/type_folder/date/uploads
    return f"{source_root}/{type_folder}/{today}/uploads"


@upload_bp.route('/file', methods=['POST'])
def upload_file():
    """
    Upload a ZIP file to Databricks Volume.
    
    Request:
        - file: ZIP file (multipart/form-data)
        - document_type: Type of document (e.g., 'tsDTA')
    
    Response:
        {
            "success": true,
            "message": "File uploaded successfully",
            "file_path": "/Volumes/catalog/schema/volume/path/filename.zip",
            "file_name": "filename.zip",
            "file_size": 12345
        }
    """
    try:
        # Validate file is present
        if 'file' not in request.files:
            return jsonify({
                'success': False,
                'error': 'No file provided'
            }), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({
                'success': False,
                'error': 'No file selected'
            }), 400
        
        # Validate file extension
        if not file.filename.lower().endswith('.zip'):
            return jsonify({
                'success': False,
                'error': 'Only ZIP files are supported'
            }), 400
        
        # Get configuration
        config = get_upload_config()
        
        # Build volume path
        volume_path = f"/Volumes/{config['catalog']}/{config['bronze_schema']}/{config['volume_name']}/{config['upload_subdir']}"
        
        # Generate unique filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        original_name = file.filename
        # Keep original name but add timestamp to avoid collisions
        base_name = original_name.rsplit('.', 1)[0]
        unique_filename = f"{base_name}_{timestamp}.zip"
        
        full_path = f"{volume_path}/{unique_filename}"
        
        print(f"UPLOAD: Uploading file to: {full_path}")
        
        # Read file content
        file_content = file.read()
        file_size = len(file_content)
        
        print(f"UPLOAD: File size: {file_size} bytes")
        
        # Upload to Databricks Volume using SDK
        w = get_workspace_client()
        
        # The files.upload method expects the path and file content
        w.files.upload(
            file_path=full_path,
            contents=io.BytesIO(file_content),
            overwrite=True
        )
        
        print(f"UPLOAD: ✓ File uploaded successfully")
        
        return jsonify({
            'success': True,
            'message': 'File uploaded successfully',
            'file_path': full_path,
            'file_name': unique_filename,
            'original_name': original_name,
            'file_size': file_size,
            'volume_path': volume_path
        })
        
    except Exception as e:
        print(f"UPLOAD ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@upload_bp.route('/trigger-job', methods=['POST'])
def trigger_job():
    """
    Trigger the job_cdm_dta_import job.
    
    Request JSON:
        {
            "source_root": "test",  # Optional, defaults to "test"
            "file_path": "/Volumes/..."  # Optional, for logging
        }
    
    Response:
        {
            "success": true,
            "message": "Job triggered successfully",
            "run_id": 12345,
            "run_url": "https://.../#job/.../run/..."
        }
    """
    try:
        data = request.get_json() or {}
        
        config = get_upload_config()
        
        # Get parameters
        source_root = data.get('source_root', config['source_root'])
        catalog_override = config['catalog']
        job_name = config['job_name']
        
        print(f"TRIGGER: Looking for job: {job_name}")
        print(f"TRIGGER: Parameters - catalog_override: {catalog_override}, source_root: {source_root}")
        
        w = get_workspace_client()
        
        # Find job by name - try exact match first, then pattern match
        # In dev mode, jobs are prefixed with "[dev username] "
        job_id = None
        found_job_name = None
        
        # First try exact match
        for job in w.jobs.list(name=job_name):
            job_id = job.job_id
            found_job_name = job.settings.name
            print(f"TRIGGER: Found exact match - Job ID: {job_id}, Name: {found_job_name}")
            break
        
        # If not found, search for jobs containing the name (dev mode has prefix)
        if not job_id:
            print(f"TRIGGER: Exact match not found, searching for jobs containing '{job_name}'...")
            for job in w.jobs.list(expand_tasks=False):
                if job_name in job.settings.name:
                    job_id = job.job_id
                    found_job_name = job.settings.name
                    print(f"TRIGGER: Found pattern match - Job ID: {job_id}, Name: {found_job_name}")
                    break
        
        if not job_id:
            return jsonify({
                'success': False,
                'error': f"Job '{job_name}' not found. Make sure the job is deployed."
            }), 404
        
        # Trigger the job with parameters
        run_response = w.jobs.run_now(
            job_id=job_id,
            job_parameters={
                'catalog_override': catalog_override,
                'source_root': source_root
            }
        )
        
        run_id = run_response.run_id
        
        # Get the run details to get the URL
        run_details = w.jobs.get_run(run_id=run_id)
        run_url = run_details.run_page_url
        
        print(f"TRIGGER: ✓ Job triggered successfully")
        print(f"TRIGGER: Run ID: {run_id}")
        print(f"TRIGGER: Run URL: {run_url}")
        
        return jsonify({
            'success': True,
            'message': 'Job triggered successfully',
            'run_id': run_id,
            'run_url': run_url,
            'job_id': job_id,
            'job_name': found_job_name or job_name,
            'parameters': {
                'catalog_override': catalog_override,
                'source_root': source_root
            }
        })
        
    except Exception as e:
        print(f"TRIGGER ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@upload_bp.route('/upload-and-process', methods=['POST'])
def upload_and_process():
    """
    Combined endpoint: Upload file and trigger processing job.
    
    Request:
        - file: ZIP file (multipart/form-data)
        - document_type: Type of document (e.g., 'tsDTA')
        - source_root: Optional source root (defaults to 'test')
    
    Response:
        {
            "success": true,
            "upload": { ... upload details ... },
            "job": { ... job trigger details ... }
        }
    """
    try:
        # Step 1: Upload the file
        if 'file' not in request.files:
            return jsonify({
                'success': False,
                'error': 'No file provided'
            }), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({
                'success': False,
                'error': 'No file selected'
            }), 400
        
        if not file.filename.lower().endswith('.zip'):
            return jsonify({
                'success': False,
                'error': 'Only ZIP files are supported'
            }), 400
        
        config = get_upload_config()
        
        # Get document type from form data
        document_type = request.form.get('document_type', 'ZIP Archive')
        source_root = request.form.get('source_root', config['source_root'])
        
        # Build upload folder based on document type and date
        # Structure: source_root/type_folder/date/uploads/
        upload_subdir = get_upload_folder(document_type, source_root)
        volume_path = f"/Volumes/{config['catalog']}/{config['bronze_schema']}/{config['volume_name']}/{upload_subdir}"
        
        # Generate unique filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        original_name = file.filename
        base_name = original_name.rsplit('.', 1)[0]
        unique_filename = f"{base_name}_{timestamp}.zip"
        full_path = f"{volume_path}/{unique_filename}"
        
        print(f"UPLOAD-PROCESS: Document type: {document_type}")
        print(f"UPLOAD-PROCESS: Uploading to: {full_path}")
        
        # Read and upload file
        file_content = file.read()
        file_size = len(file_content)
        
        w = get_workspace_client()
        
        w.files.upload(
            file_path=full_path,
            contents=io.BytesIO(file_content),
            overwrite=True
        )
        
        print(f"UPLOAD-PROCESS: ✓ File uploaded ({file_size} bytes)")
        
        upload_result = {
            'file_path': full_path,
            'file_name': unique_filename,
            'original_name': original_name,
            'file_size': file_size,
            'document_type': document_type,
            'upload_folder': upload_subdir
        }
        
        # Step 2: Trigger the job
        # Use the upload folder (without /uploads) as source_subdir for the job
        # This tells the job where to look for files
        catalog_override = config['catalog']
        job_name = config['job_name']
        
        print(f"UPLOAD-PROCESS: Triggering job: {job_name}")
        
        # Find job by name - try exact match first, then pattern match
        # In dev mode, jobs are prefixed with "[dev username] "
        job_id = None
        found_job_name = None
        
        # First try exact match
        for job in w.jobs.list(name=job_name):
            job_id = job.job_id
            found_job_name = job.settings.name
            break
        
        # If not found, search for jobs containing the name (dev mode has prefix)
        if not job_id:
            print(f"UPLOAD-PROCESS: Exact match not found, searching for jobs containing '{job_name}'...")
            for job in w.jobs.list(expand_tasks=False):
                if job_name in job.settings.name:
                    job_id = job.job_id
                    found_job_name = job.settings.name
                    print(f"UPLOAD-PROCESS: Found pattern match - Job ID: {job_id}, Name: {found_job_name}")
                    break
        
        if not job_id:
            return jsonify({
                'success': False,
                'error': f"Job '{job_name}' not found. File was uploaded but processing was not started. Make sure the job is deployed.",
                'upload': upload_result
            }), 404
        
        # Trigger the job with the specific upload folder
        # Pass source_subdir so the job knows where to look for files
        run_response = w.jobs.run_now(
            job_id=job_id,
            job_parameters={
                'catalog_override': catalog_override,
                'source_root': source_root,
                'source_subdir': upload_subdir  # e.g., test/dta/2025-12-23/uploads
            }
        )
        
        run_id = run_response.run_id
        run_details = w.jobs.get_run(run_id=run_id)
        run_url = run_details.run_page_url
        
        print(f"UPLOAD-PROCESS: ✓ Job triggered - Run ID: {run_id}")
        print(f"UPLOAD-PROCESS: Source subdir: {upload_subdir}")
        
        job_result = {
            'run_id': run_id,
            'run_url': run_url,
            'job_id': job_id,
            'job_name': found_job_name or job_name,
            'parameters': {
                'catalog_override': catalog_override,
                'source_root': source_root,
                'source_subdir': upload_subdir
            }
        }
        
        return jsonify({
            'success': True,
            'message': 'File uploaded and processing started',
            'upload': upload_result,
            'job': job_result
        })
        
    except Exception as e:
        print(f"UPLOAD-PROCESS ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@upload_bp.route('/job-status/<int:run_id>', methods=['GET'])
def get_job_status(run_id):
    """
    Get status of a job run.
    
    Response:
        {
            "run_id": 12345,
            "status": "RUNNING|COMPLETED|FAILED",
            "run_url": "https://...",
            "start_time": "2025-01-15 10:30:00",
            "end_time": "2025-01-15 10:35:00",
            "duration": "5m 30s"
        }
    """
    try:
        w = get_workspace_client()
        
        run = w.jobs.get_run(run_id=run_id)
        
        # Determine status
        status = 'UNKNOWN'
        if run.state and run.state.life_cycle_state:
            lifecycle = run.state.life_cycle_state.value
            if lifecycle in ['RUNNING', 'PENDING', 'QUEUED']:
                status = 'RUNNING'
            elif lifecycle == 'TERMINATED':
                if run.state.result_state and run.state.result_state.value == 'SUCCESS':
                    status = 'COMPLETED'
                else:
                    status = 'FAILED'
            else:
                status = lifecycle
        
        # Format times
        start_time = None
        end_time = None
        duration = None
        
        if run.start_time:
            start_time = datetime.fromtimestamp(run.start_time / 1000).strftime('%Y-%m-%d %H:%M:%S')
            
            if run.end_time:
                end_time = datetime.fromtimestamp(run.end_time / 1000).strftime('%Y-%m-%d %H:%M:%S')
                duration_secs = (run.end_time - run.start_time) / 1000
                if duration_secs < 60:
                    duration = f"{int(duration_secs)}s"
                else:
                    mins = int(duration_secs / 60)
                    secs = int(duration_secs % 60)
                    duration = f"{mins}m {secs}s"
        
        return jsonify({
            'success': True,
            'run_id': run_id,
            'status': status,
            'run_url': run.run_page_url,
            'start_time': start_time,
            'end_time': end_time,
            'duration': duration
        })
        
    except Exception as e:
        print(f"STATUS ERROR: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@upload_bp.route('/trigger-template-promotion', methods=['POST'])
def trigger_template_promotion():
    """
    Trigger the DTA Template creation job for a specific vendor+stream.
    
    Request JSON:
        {
            "data_provider_name": "Vendor_A",
            "data_stream_type": "EDC_Data",
            "library_type": "transfer_variables"  // optional, defaults to all
        }
    
    Response:
        {
            "success": true,
            "run_id": 12345,
            "run_url": "https://.../#job/.../run/...",
            "message": "Template creation job triggered"
        }
    """
    try:
        data = request.get_json() or {}
        
        # Required parameters
        data_provider_name = data.get('data_provider_name')
        data_stream_type = data.get('data_stream_type')
        
        if not data_provider_name or not data_stream_type:
            return jsonify({
                'success': False,
                'error': 'data_provider_name and data_stream_type are required'
            }), 400
        
        # Optional parameters
        library_type = data.get('library_type', '')  # empty = all library types
        merge_strategy = data.get('merge_strategy', 'UNION_DEDUP')
        
        config = get_upload_config()
        catalog_override = config['catalog']
        
        # Job to trigger
        job_name = 'job_cdm_version_manager'
        
        print(f"PROMOTE: Triggering template creation for {data_provider_name} / {data_stream_type}")
        
        w = get_workspace_client()
        
        # Find job by name - try exact match first, then pattern match
        job_id = None
        found_job_name = None
        
        for job in w.jobs.list(name=job_name):
            job_id = job.job_id
            found_job_name = job.settings.name
            break
        
        if not job_id:
            for job in w.jobs.list(expand_tasks=False):
                if job_name in job.settings.name:
                    job_id = job.job_id
                    found_job_name = job.settings.name
                    break
        
        if not job_id:
            return jsonify({
                'success': False,
                'error': f"Job '{job_name}' not found. Make sure the job is deployed."
            }), 404
        
        # Trigger the job with parameters for CREATE_DTA_TEMPLATE action
        run_response = w.jobs.run_now(
            job_id=job_id,
            job_parameters={
                'action': 'CREATE_DTA_TEMPLATE',
                'catalog_override': catalog_override,
                'data_provider_name': data_provider_name,
                'data_stream_type': data_stream_type,
                'library_type': library_type,
                'merge_strategy': merge_strategy
            }
        )
        
        run_id = run_response.run_id
        run_details = w.jobs.get_run(run_id=run_id)
        run_url = run_details.run_page_url
        
        print(f"PROMOTE: ✓ Job triggered - Run ID: {run_id}")
        
        return jsonify({
            'success': True,
            'message': f'Template creation job triggered for {data_provider_name} / {data_stream_type}',
            'run_id': run_id,
            'run_url': run_url,
            'job_id': job_id,
            'job_name': found_job_name or job_name,
            'parameters': {
                'action': 'CREATE_DTA_TEMPLATE',
                'data_provider_name': data_provider_name,
                'data_stream_type': data_stream_type,
                'library_type': library_type,
                'merge_strategy': merge_strategy
            }
        })
        
    except Exception as e:
        print(f"PROMOTE ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


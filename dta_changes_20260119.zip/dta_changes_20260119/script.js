
// Change tracking for Save Draft button
let hasUnsavedChanges = false;
let isIntentionalNavigation = false; // Flag to allow intentional page reloads
let beforeUnloadHandler = null; // Store reference to handler for removal

function markDirty() {
  hasUnsavedChanges = true;
  const saveBtn = document.getElementById('save-draft-btn');
  if (saveBtn) {
    saveBtn.disabled = false;
    saveBtn.title = 'Save your changes';
  }
}

function markClean() {
  hasUnsavedChanges = false;
  const saveBtn = document.getElementById('save-draft-btn');
  if (saveBtn) {
    saveBtn.disabled = true;
    saveBtn.title = 'Make changes to enable saving';
  }
}

// Disable the "Leave site?" warning (useful before intentional navigation)
function disableLeaveWarning() {
  isIntentionalNavigation = true;
  hasUnsavedChanges = false;
  if (beforeUnloadHandler) {
    window.removeEventListener('beforeunload', beforeUnloadHandler);
  }
  window.onbeforeunload = null;
}

// Safe reload that doesn't trigger warning
function safeReload() {
  isIntentionalNavigation = true;
  location.reload();
}

// Check if there are any rows currently in edit mode
function hasActiveEdits() {
  // Check for TC rows in edit mode
  const tcEditingRows = document.querySelectorAll('.tc-table tr.row-editing');
  // Check for TV rows in edit mode  
  const tvEditingRows = document.querySelectorAll('.tv-table tr.row-editing, .tv-selected-editing');
  // Check for metadata/dip rows in edit mode
  const metaEditingRows = document.querySelectorAll('.metadata-row.row-editing');
  
  return tcEditingRows.length > 0 || tvEditingRows.length > 0 || metaEditingRows.length > 0;
}

// Initialize change tracking on page load
document.addEventListener('DOMContentLoaded', function() {
  // Only enable change tracking on workspace page (has save-draft-btn)
  const isWorkspacePage = document.getElementById('save-draft-btn') !== null;
  
  if (isWorkspacePage) {
    // Track changes on all form inputs (only on workspace page)
    document.querySelectorAll('input, select, textarea').forEach(el => {
      el.addEventListener('input', markDirty);
      el.addEventListener('change', markDirty);
    });
    
    // Track changes on contenteditable elements
    document.querySelectorAll('[contenteditable="true"]').forEach(el => {
      el.addEventListener('input', markDirty);
    });
    
    // Warn before leaving with unsaved changes (but not for intentional navigation)
    beforeUnloadHandler = function(e) {
      if (hasUnsavedChanges && !isIntentionalNavigation) {
        e.preventDefault();
        e.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
        return e.returnValue;
      }
    };
    window.addEventListener('beforeunload', beforeUnloadHandler);
    
    // Mark subnav tab clicks as intentional navigation (data is preserved in server memory)
    document.querySelectorAll('.subnav-item').forEach(link => {
      link.addEventListener('click', function() {
        isIntentionalNavigation = true;
      });
    });
  }
});

// Handle focus on newly added row after page reload
document.addEventListener('DOMContentLoaded', function() {
  const urlParams = new URLSearchParams(window.location.search);
  const focusNew = urlParams.get('focus_new');
  const needsSave = urlParams.get('needs_save');
  
  // If needs_save is set, enable the save button
  if (needsSave === 'true') {
    console.log('needs_save parameter detected, enabling save button');
    markDirty();
  }
  
  if (focusNew) {
    console.log('focus_new parameter detected:', focusNew);
    
    // Remove the focus_new and needs_save parameters from URL to prevent re-focusing on refresh
    urlParams.delete('focus_new');
    urlParams.delete('needs_save');
    const newUrl = window.location.pathname + (urlParams.toString() ? '?' + urlParams.toString() : '');
    window.history.replaceState({}, '', newUrl);
    
    // Wait for page to fully render and domain filter to apply
    setTimeout(() => {
      let lastRow = null;
      let labelInput = null;
      
      if (focusNew === 'tv') {
        // Find all visible rows in TV table (the newly added one should be last)
        const tvRows = document.querySelectorAll('.tv-table tbody tr[data-row-idx]');
        console.log('Found TV rows:', tvRows.length);
        
        if (tvRows.length > 0) {
          lastRow = tvRows[tvRows.length - 1];
          console.log('Last row:', lastRow);
          
          // Find the LABEL input specifically (tv-label-input class)
          labelInput = lastRow.querySelector('.tv-label-input');
          console.log('Label input:', labelInput);
        }
      } else if (focusNew === 'tc') {
        // Find the last row in TC table
        const tcRows = document.querySelectorAll('.tc-table tbody tr:not(.comment-row)');
        console.log('Found TC rows:', tcRows.length);
        
        if (tcRows.length > 0) {
          lastRow = tcRows[tcRows.length - 1];
          labelInput = lastRow.querySelector('input.tc-input');
        }
      }
      
      if (lastRow) {
        // Make sure row is visible (not hidden by domain filter)
        lastRow.style.display = '';
        
        // Scroll the table container to show the row
        const scrollContainer = lastRow.closest('.table-wrap, .tv-scroll');
        if (scrollContainer) {
          // Scroll the container
          const rowTop = lastRow.offsetTop;
          scrollContainer.scrollTop = rowTop - 100;
          console.log('Scrolled container to:', rowTop);
        }
        
        // Also scroll into view for the page
        lastRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Add a visual highlight effect
        lastRow.classList.add('row-highlight-new');
        setTimeout(() => lastRow.classList.remove('row-highlight-new'), 3000);
        
        // Focus on the label input
        if (labelInput) {
          setTimeout(() => {
            labelInput.focus();
            if (labelInput.select) labelInput.select();
            console.log('Focused on label input');
          }, 500);
        }
      } else {
        console.log('No row found to focus');
      }
    }, 300);  // Increased timeout for domain filter to apply
  }
});

// ============================================================================
// DTA Name Editing
// ============================================================================

function enableDtaNameEdit() {
  const display = document.getElementById('dta-name-display');
  const input = document.getElementById('dta-name-input');
  if (display && input) {
    // Get the current name from display (without the edit icon SVG)
    const currentName = display.textContent.trim();
    input.value = currentName;
    
    display.style.display = 'none';
    input.style.display = 'inline-block';
    input.focus();
    input.select();
  }
}

async function saveDtaName(dtaId) {
  const display = document.getElementById('dta-name-display');
  const input = document.getElementById('dta-name-input');
  
  if (!input || !display) return;
  
  const newName = input.value.trim();
  const originalName = display.textContent.trim();
  
  // Hide input, show display first
  input.style.display = 'none';
  display.style.display = 'inline-flex';
  
  if (!newName || newName === originalName) {
    // No change or empty - just return without saving
    return;
  }
  
  try {
    // Save to backend
    const response = await window.API.post(`/api/dta/${dtaId}/update-name`, { dta_name: newName });
    
    if (response.ok) {
      // Update display - keep the edit icon
      display.innerHTML = `${newName} <svg class="edit-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>`;
      // Also update the input value for next edit
      input.value = newName;
    } else {
      console.error('Failed to save DTA name:', response.msg);
      // Revert input to original
      input.value = originalName;
    }
  } catch (e) {
    console.error('Error saving DTA name:', e);
    // Revert input to original
    input.value = originalName;
  }
}

// ============================================================================
// Draft Save
// ============================================================================

async function saveDraft(key){
  const saveBtn = document.getElementById('save-draft-btn');
  const originalText = saveBtn ? saveBtn.innerHTML : '';
  
  // Show loading state
  if (saveBtn) {
    saveBtn.disabled = true;
    saveBtn.innerHTML = `
      <svg class="spinner" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10" stroke-opacity="0.25"></circle>
        <path d="M12 2a10 10 0 0 1 10 10" stroke-linecap="round"></path>
      </svg>
      Saving...
    `;
  }
  
  try {
    // Get the selected domain for filtering which records to save
    const selectedDomain = getSelectedDomain ? getSelectedDomain() : null;
    const saveUrl = selectedDomain 
      ? `/api/workspace/${encodeURIComponent(key)}/save?domain_info=${encodeURIComponent(selectedDomain)}`
      : `/api/workspace/${encodeURIComponent(key)}/save`;
    
    const r = await window.API.post(saveUrl);
    
    if (r.ok) {
      // Show success message briefly, then redirect to edit-draft to reload fresh data
      showToast(r.msg || 'Draft saved successfully!', 'success');
      
      // Mark as intentional navigation to prevent "leaving site" popup
      isIntentionalNavigation = true;
      
      // Get current tab from URL to preserve it after redirect
      const urlParams = new URLSearchParams(window.location.search);
      const currentTab = urlParams.get('tab') || 'TV';
      
      setTimeout(() => {
        // Redirect to edit-draft route with current tab preserved
        if (r.dta_id) {
          window.location.href = `/edit-draft/${r.dta_id}?tab=${currentTab}`;
        } else {
          window.location.reload();
        }
      }, 1000);
    } else {
      showToast(r.msg || 'Failed to save draft', 'error');
      // Restore button
      if (saveBtn) {
        saveBtn.disabled = false;
        saveBtn.innerHTML = originalText;
      }
    }
  } catch (e) {
    showToast('Error saving draft: ' + e.message, 'error');
    // Restore button
    if (saveBtn) {
      saveBtn.disabled = false;
      saveBtn.innerHTML = originalText;
    }
  }
}

// Toast notification helper
function showToast(message, type = 'info') {
  // Remove existing toast
  const existingToast = document.getElementById('toast-notification');
  if (existingToast) existingToast.remove();
  
  const toast = document.createElement('div');
  toast.id = 'toast-notification';
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ'}</span>
    <span class="toast-message">${message}</span>
  `;
  document.body.appendChild(toast);
  
  // Auto-remove after 4 seconds
  setTimeout(() => {
    toast.classList.add('toast-fade-out');
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

async function showHistory(key){
  // Extract dta_id from the key (format: trial|stream|provider|dta_id)
  const parts = key.split('|');
  const dtaId = parts.length >= 4 ? parts[3] : key;
  
  // Show the panel
  const panel = document.getElementById('history-panel');
  const overlay = document.getElementById('history-overlay');
  const loading = document.getElementById('history-loading');
  const content = document.getElementById('history-content');
  const empty = document.getElementById('history-empty');
  
  panel.classList.add('open');
  overlay.classList.add('open');
  loading.style.display = 'flex';
  content.style.display = 'none';
  empty.style.display = 'none';
  
  try {
    const response = await fetch(`/api/history/${dtaId}`);
    const data = await response.json();
    
    loading.style.display = 'none';
    
    if (data.ok && data.history && data.history.length > 0) {
      content.style.display = 'block';
      renderHistoryTree(data);
    } else {
      empty.style.display = 'flex';
    }
  } catch (e) {
    console.error('Failed to load history:', e);
    loading.style.display = 'none';
    empty.style.display = 'flex';
    empty.querySelector('p').textContent = 'Failed to load history';
  }
}

function closeHistoryPanel() {
  const panel = document.getElementById('history-panel');
  const overlay = document.getElementById('history-overlay');
  panel.classList.remove('open');
  overlay.classList.remove('open');
}

function renderHistoryTree(data) {
  // Render DTA info header
  const dtaInfo = document.getElementById('history-dta-info');
  const info = data.dta_info || {};
  dtaInfo.innerHTML = `
    <div class="history-dta-header">
      <span class="history-dta-icon">📂</span>
      <div class="history-dta-details">
        <strong>DTA: ${info.dta_number || info.dta_id?.substring(0, 8) || 'Unknown'}</strong>
        <span class="history-dta-meta">${info.trial_id || ''} | ${info.data_stream_type || ''} | ${info.data_provider_name || ''}</span>
      </div>
    </div>
  `;
  
  // Render history tree
  const tree = document.getElementById('history-tree');
  tree.innerHTML = data.history.map((batch, idx) => {
    const timestamp = formatHistoryDate(batch.timestamp);
    const user = batch.user || 'Unknown';
    const isFirst = idx === 0;
    
    // Build sections for each activity type
    let sections = '';
    
    // Version events (highest priority - show first)
    if (batch.version_events && batch.version_events.length > 0) {
      sections += batch.version_events.map(evt => `
        <div class="history-activity version-activity">
          <span class="activity-icon">${getActivityIcon(evt.type)}</span>
          <span class="activity-summary">${evt.summary}</span>
        </div>
      `).join('');
    }
    
    // Workflow events
    if (batch.workflow_events && batch.workflow_events.length > 0) {
      sections += batch.workflow_events.map(evt => `
        <div class="history-activity workflow-activity">
          <span class="activity-icon">${getActivityIcon(evt.type)}</span>
          <span class="activity-summary">${evt.summary}</span>
        </div>
      `).join('');
    }
    
    // Data changes - group by library type and entity
    if (batch.data_changes && batch.data_changes.length > 0) {
      // Group by library_type
      const byLibrary = {};
      batch.data_changes.forEach(change => {
        const lib = change.library_type || 'other';
        if (!byLibrary[lib]) byLibrary[lib] = {};
        const entity = change.entity_name || change.entity_id || 'unknown';
        if (!byLibrary[lib][entity]) byLibrary[lib][entity] = [];
        byLibrary[lib][entity].push(change);
      });
      
      Object.entries(byLibrary).forEach(([libType, entities]) => {
        const entityIcon = getEntityIcon(libType.toUpperCase().replace('_', '_'));
        const entityLabel = getEntityLabel(libType.toUpperCase().replace('_', '_'));
        const totalChanges = Object.values(entities).reduce((sum, arr) => sum + arr.length, 0);
        
        // Check if this is a bulk insert
        const isBulkInsert = Object.values(entities).flat().some(c => c.type === 'BULK_INSERT');
        
        // Check if this is a batch update (consolidated save - show summary only)
        const isBatchUpdate = Object.values(entities).flat().some(c => c.type === 'BATCH_UPDATE');
        
        if (isBulkInsert) {
          const bulkChange = Object.values(entities).flat().find(c => c.type === 'BULK_INSERT');
          sections += `
            <div class="history-entity">
              <div class="history-entity-header">
                <span class="entity-icon">${entityIcon}</span>
                <span class="entity-label">${entityLabel}</span>
                <span class="entity-count">${bulkChange?.summary || `(${totalChanges} imported)`}</span>
              </div>
            </div>
          `;
        } else if (isBatchUpdate) {
          // Batch update - consolidate ALL batch updates under one header
          const batchChanges = Object.values(entities).flat().filter(c => c.type === 'BATCH_UPDATE');
          
          // Combine all change details from all batch updates
          let allDetailsHtml = '';
          batchChanges.forEach(batchChange => {
            const changeDetails = batchChange?.comment || '';
            if (changeDetails && changeDetails.trim().length > 0) {
              const detailsHtml = changeDetails.split('\n').map(line => {
                line = line.trim();
                if (!line) return '';
                
                // Header lines (CREATED: or UPDATED:)
                if (line === 'CREATED:' || line === 'UPDATED:') {
                  return '<div class="history-change-header">' + line + '</div>';
                }
                // List items (• variable details)
                if (line.startsWith('•')) {
                  return '<div class="history-change-item simple">' + line + '</div>';
                }
                // Legacy format support - parse old style change lines
                const changeMatch = line.match(/•\s*(.+?)\.(.+?):\s*'(.*)'\s*→\s*'(.*)'/);
                if (changeMatch) {
                  const [, ent, fld, oldV, newV] = changeMatch;
                  return '<div class="history-change-item">' +
                    '<span class="change-entity">' + ent + '</span>' +
                    '<span class="change-field">.' + fld + '</span>' +
                    '<span class="change-arrow">:</span>' +
                    '<span class="change-old">' + (oldV || '∅') + '</span>' +
                    '<span class="change-arrow">→</span>' +
                    '<span class="change-new">' + (newV || '∅') + '</span>' +
                  '</div>';
                }
                // Other info lines
                return '<div class="history-change-info">' + line + '</div>';
              }).join('');
              allDetailsHtml += detailsHtml;
            }
          });
          
          const hasDetails = allDetailsHtml.length > 0;
          
          // Single header for the library type, no summary text
          sections += `
            <div class="history-entity">
              <div class="history-entity-header${hasDetails ? ' clickable' : ''}" ${hasDetails ? 'onclick="toggleHistoryEntity(this)"' : ''}>
                ${hasDetails ? '<span class="expand-icon">▶</span>' : ''}
                <span class="entity-icon">${entityIcon}</span>
                <span class="entity-label">${entityLabel}</span>
              </div>
              ${hasDetails ? `
              <div class="history-entity-records" style="display:none;">
                <div class="history-batch-details">
                  ${allDetailsHtml}
                </div>
              </div>
              ` : ''}
            </div>
          `;
        } else {
          sections += `
            <div class="history-entity">
              <div class="history-entity-header" onclick="toggleHistoryEntity(this)">
                <span class="expand-icon">▶</span>
                <span class="entity-icon">${entityIcon}</span>
                <span class="entity-label">${entityLabel}</span>
                <span class="entity-count">(${totalChanges} field${totalChanges > 1 ? 's' : ''} updated)</span>
              </div>
              <div class="history-entity-records" style="display:none;">
                ${Object.entries(entities).map(([entityName, changes]) => `
                  <div class="history-record-group">
                    <div class="record-header">
                      <span class="record-icon">📝</span>
                      <span class="record-name">${entityName}</span>
                    </div>
                    <div class="field-changes">
                      ${changes.map(change => {
                        const isLongText = change.field_name === 'vendor_comment' || 
                                          (change.old_value && change.old_value.length > 50) || 
                                          (change.new_value && change.new_value.length > 50);
                        if (isLongText) {
                          return `
                            <div class="field-change field-change-block">
                              <div class="field-name">${change.field_name}:</div>
                              <div class="field-value-block">
                                <div class="old-value-block"><strong>From:</strong> <span class="old-text">${change.old_value || '(empty)'}</span></div>
                                <div class="new-value-block"><strong>To:</strong> <span class="new-text">${change.new_value || '(empty)'}</span></div>
                              </div>
                            </div>
                          `;
                        }
                        return `
                          <div class="field-change">
                            <span class="field-name">${change.field_name}:</span>
                            <span class="old-value">${change.old_value || '∅'}</span>
                            <span class="arrow">→</span>
                            <span class="new-value">${change.new_value || '∅'}</span>
                          </div>
                        `;
                      }).join('')}
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          `;
        }
      });
    }
    
    return `
      <div class="history-batch ${isFirst ? 'expanded' : ''}">
        <div class="history-batch-header" onclick="toggleHistoryBatch(this)">
          <span class="expand-icon">${isFirst ? '▼' : '▶'}</span>
          <span class="batch-date">📅 ${timestamp}</span>
          <span class="batch-user">- ${user.split('@')[0]}</span>
          <span class="batch-count">(${batch.total_activities} ${batch.total_activities === 1 ? 'activity' : 'activities'})</span>
        </div>
        <div class="history-batch-content" style="display:${isFirst ? 'block' : 'none'};">
          ${sections || '<div class="no-details">No details available</div>'}
        </div>
      </div>
    `;
  }).join('');
}

function getActivityIcon(activityType) {
  const icons = {
    // Workflow
    'SUBMITTED_FOR_APPROVAL': '📤',
    'APPROVED': '✅',
    'REJECTED': '❌',
    'REASSIGNED': '🔄',
    'RECALLED': '↩️',
    // Version
    'DRAFT_CREATED': '📝',
    'DTA_APPROVED_CREATED': '📦',
    'PROMOTED_TO_TEMPLATE': '🏆',
    'CLONED_FROM': '🔄',
    // Data
    'INSERT': '➕',
    'UPDATE': '✏️',
    'DELETE': '🗑️',
    'BULK_INSERT': '📥',
    'BATCH_UPDATE': '💾'
  };
  return icons[activityType] || '📋';
}

function toggleHistoryBatch(header) {
  const batch = header.parentElement;
  const content = batch.querySelector('.history-batch-content');
  const icon = header.querySelector('.expand-icon');
  
  if (content.style.display === 'none') {
    content.style.display = 'block';
    icon.textContent = '▼';
    batch.classList.add('expanded');
  } else {
    content.style.display = 'none';
    icon.textContent = '▶';
    batch.classList.remove('expanded');
  }
}

function toggleHistoryEntity(header) {
  const entity = header.parentElement;
  const records = entity.querySelector('.history-entity-records');
  const icon = header.querySelector('.expand-icon');
  
  if (records.style.display === 'none') {
    records.style.display = 'block';
    icon.textContent = '▼';
  } else {
    records.style.display = 'none';
    icon.textContent = '▶';
  }
}

function formatHistoryDate(timestamp) {
  if (!timestamp) return 'Unknown date';
  try {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  } catch (e) {
    return timestamp;
  }
}

function getEntityIcon(entityType) {
  const icons = {
    'TRANSFER_VARIABLE': '📊',
    'TEST_CONCEPT': '🧪',
    'CODELIST': '📋',
    'METADATA': '📝',
    'VISIT_TIMEPOINT': '📅',
    'DATA_INGESTION_PARAM': '⚙️'
  };
  return icons[entityType] || '📁';
}

function getEntityLabel(entityType) {
  const labels = {
    'TRANSFER_VARIABLE': 'Transfer Variables',
    'TEST_CONCEPT': 'Test Concepts',
    'CODELIST': 'Codelists',
    'METADATA': 'Metadata',
    'VISIT_TIMEPOINT': 'Visits & Timepoints',
    'DATA_INGESTION_PARAM': 'Data Ingestion Params'
  };
  return labels[entityType] || entityType;
}

// Global variable to store selected approvers
let selectedApprovers = {
  jnj: null,
  vendor: null,
  librarian: null
};
let currentWorkspaceKey = null;

async function submitApproval(key, buttonEl){
  currentWorkspaceKey = key;
  
  // Get the button element if not passed
  const btn = buttonEl || event?.target;
  const originalContent = btn ? btn.innerHTML : '';
  
  // Debug: Log URL and key
  console.log('[submitApproval] URL:', window.location.pathname);
  console.log('[submitApproval] Key:', key);
  
  // Get DTA ID from the page
  const dtaIdMatch = window.location.pathname.match(/\/workspace\/([^\/]+)/);
  let dtaId = null;
  
  // Try to get dta_id from the URL if editing a draft directly
  const editMatch = window.location.pathname.match(/\/edit-draft\/([^\/]+)/);
  if (editMatch) {
    dtaId = editMatch[1];
    console.log('[submitApproval] Found DTA ID from URL:', dtaId);
  }
  
  // Try to find the dta_id in the workspace data
  if (!dtaId) {
    // Look for dta_id in any data attribute or hidden input
    const dtaIdEl = document.querySelector('[data-dta-id]');
    if (dtaIdEl) {
      dtaId = dtaIdEl.getAttribute('data-dta-id');
      console.log('[submitApproval] Found DTA ID from data attribute:', dtaId);
    }
  }
  
  // Parse from the workspace key if possible (format: trial|provider|stream|dta_id)
  if (!dtaId && key) {
    const parts = key.split('|');
    if (parts.length >= 4) {
      dtaId = parts[3]; // DTA ID is the 4th part
      console.log('[submitApproval] Found DTA ID from key:', dtaId);
    }
  }
  
  if (!dtaId) {
    showToast('Could not determine DTA ID. Please save your draft first.', 'error');
    return;
  }
  
  console.log('[submitApproval] Using DTA ID:', dtaId);
  
  // Show loading state on button
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-small"></span> Submitting...';
  }
  
  try {
    const response = await fetch(`/api/approval/submit/${dtaId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ comment: '' })
    });
    
    const result = await response.json();
    
    if (result.ok) {
      showToast('DTA submitted for approval! Approvers have been notified.', 'success');
      // Redirect to approvals page
      window.location.href = `/approvals/${dtaId}`;
    } else {
      showToast('Error: ' + (result.error || 'Failed to submit for approval'), 'error');
      // Reset button
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = originalContent;
      }
    }
  } catch (e) {
    console.error('Failed to submit for approval:', e);
    showToast('Failed to submit for approval: ' + e.message, 'error');
    // Reset button
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = originalContent;
    }
  }
}

// Toast notification helper
function showToast(message, type = 'info') {
  // Check if toast container exists
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999;';
    document.body.appendChild(container);
  }
  
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.style.cssText = `
    padding: 12px 20px;
    margin-bottom: 10px;
    border-radius: 8px;
    color: white;
    font-size: 14px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    animation: slideIn 0.3s ease;
    background: ${type === 'success' ? '#22c55e' : type === 'error' ? '#ef4444' : '#3b82f6'};
  `;
  toast.textContent = message;
  container.appendChild(toast);
  
  // Auto remove after 4 seconds
  setTimeout(() => {
    toast.style.animation = 'fadeOut 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

function renderApprovers(containerId, approvers, role) {
  const container = document.getElementById(containerId);
  container.innerHTML = '';
  
  approvers.forEach(approver => {
    const div = document.createElement('div');
    div.className = 'approver-option';
    div.innerHTML = `
      <input type="radio" 
             id="approver-${role}-${approver.id}" 
             name="approver-${role}" 
             value="${approver.id}"
             onchange="selectApprover('${role}', '${approver.id}', '${approver.name}', '${approver.title}', '${approver.email}')">
      <label for="approver-${role}-${approver.id}">
        <div class="approver-name">${approver.name}</div>
        <div class="approver-details">
          <span class="approver-title">${approver.title}</span>
          <span class="approver-email">${approver.email}</span>
        </div>
      </label>
    `;
    container.appendChild(div);
  });
}

function selectApprover(role, id, name, title, email) {
  selectedApprovers[role] = { id, name, title, email };
  
  // Show checkmark
  document.getElementById(`${role}-check`).style.display = 'inline';
  
  // Check if all selections are made
  const allSelected = selectedApprovers.jnj && selectedApprovers.vendor && selectedApprovers.librarian;
  document.getElementById('submit-approval-btn').disabled = !allSelected;
}

function closeApproverModal() {
  document.getElementById('approver-modal').style.display = 'none';
  // Reset selections
  selectedApprovers = { jnj: null, vendor: null, librarian: null };
  document.querySelectorAll('.selection-check').forEach(el => el.style.display = 'none');
  document.getElementById('submit-approval-btn').disabled = true;
}

async function confirmApprovalSubmission() {
  if (!currentWorkspaceKey) return;
  
  const approvers = [
    { ...selectedApprovers.jnj, role: 'JNJ DAE', order: 1 },
    { ...selectedApprovers.vendor, role: 'Vendor', order: 2 },
    { ...selectedApprovers.librarian, role: 'Librarian', order: 3 }
  ];
  
  const r = await window.API.post(`/api/workspace/${encodeURIComponent(currentWorkspaceKey)}/submit`, { approvers });
  
  if (r.success) {
    closeApproverModal();
    window.location.href = '/dashboard';
  } else {
    alert(r.msg || 'Failed to submit');
  }
}
async function addComment(key){
  const text = document.getElementById('commentText').value
  if(!text.trim()) return
  const r = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/comment`, {text})
  if(r.ok){
    const list = document.getElementById('comments')
    const item = document.createElement('div')
    item.className = 'list-item'
    const ts = new Date().toLocaleString()
    item.innerHTML = `<div class="item-title">you@jnj.com <span class="muted small">• ${ts}</span></div><div>${text}</div>`
    list.prepend(item)
    document.getElementById('commentText').value = ''
  }
}
async function updateCell(key, tab, idx, col, value){
  await window.API.post(`/api/workspace/${encodeURIComponent(key)}/entity/${tab}/${idx}/${col}`, { value })
  markDirty(); // Enable save button
}


function toggleRowComment(idx){
  const row = document.getElementById(`comment-row-${idx}`)
  if(row) row.style.display = (row.style.display === 'none' ? '' : 'none')
}

// Helper function to get the TC data row (excluding comment rows)
function getTcRow(idx) {
  const table = document.querySelector('.tc-table tbody');
  if (!table) return null;
  // Filter out comment rows to get correct index
  const rows = table.querySelectorAll('tr:not(.tc-comment-row)');
  return rows[idx] || null;
}

// Helper to toggle TC row edit state via DOM (consistent with TV)
function setTcRowEditable(idx, editable, originalValues = null) {
  const row = getTcRow(idx);
  if (!row) return;
  
  // Update row classes
  row.classList.remove('row-readonly', 'row-editing', 'selected');
  row.classList.add(editable ? 'row-editing' : 'row-readonly');
  if (editable) row.classList.add('selected');
  
  // Find all editable inputs in this row
  const inputs = row.querySelectorAll('input.tc-input');
  inputs.forEach(input => {
    if (editable) {
      input.removeAttribute('readonly');
    } else {
      input.setAttribute('readonly', 'readonly');
    }
  });
  
  // Update action buttons - find the actions cell
  let actionsCell = row.querySelector('.tc-actions');
  if (!actionsCell) {
    actionsCell = row.querySelector('td.sticky-actions');
  }
  if (!actionsCell) {
    actionsCell = row.querySelector('td:first-child');
  }
  
  if (actionsCell) {
    // Get the current key from any existing onclick handler
    const existingBtn = actionsCell.querySelector('button');
    const onclickStr = existingBtn?.getAttribute('onclick') || '';
    const keyMatch = onclickStr.match(/'([^']+)'/);
    const key = keyMatch ? keyMatch[1] : '';
    
    if (editable) {
      // Show Save/Cancel/Comment buttons
      actionsCell.innerHTML = `
        <button class="btn btn-icon sm btn-action-save" title="Save changes" onclick="tcSave('${key}', ${idx})">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
        </button>
        <button class="btn btn-icon sm btn-action-cancel" title="Cancel" onclick="tcCancel('${key}', ${idx})">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
        <button class="btn btn-icon sm btn-action-comment" title="Add comment" onclick="toggleRowComment(${idx})">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
          </svg>
        </button>
      `;
    } else {
      // Show Edit/Comment buttons
      actionsCell.innerHTML = `
        <button class="btn btn-icon sm btn-action-edit" title="Edit row" onclick="tcEdit('${key}', ${idx})">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 20h9" />
            <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z" />
          </svg>
        </button>
        <button class="btn btn-icon sm btn-action-comment" title="Add comment" onclick="toggleRowComment(${idx})">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
          </svg>
        </button>
      `;
    }
  }
}

async function tcEdit(key, idx){
  console.log('tcEdit called:', key, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/${idx}/edit`);
    console.log('tcEdit response:', response);
    if (response.ok) {
      setTcRowEditable(idx, true);
      markDirty();
    } else {
      console.error('tcEdit failed:', response);
      alert('Failed to edit row: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('tcEdit error:', e);
    alert('Error editing row: ' + e.message);
  }
}

async function tcSave(key, idx){
  console.log('tcSave called:', key, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/${idx}/save`);
    console.log('tcSave response:', response);
    if (response.ok) {
      setTcRowEditable(idx, false);
      showToast('Row saved', 'success');
    } else {
      console.error('tcSave failed:', response);
      alert('Failed to save row: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('tcSave error:', e);
    alert('Error saving row: ' + e.message);
  }
}

async function tcCancel(key, idx){
  console.log('tcCancel called:', key, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/${idx}/cancel`);
    console.log('tcCancel response:', response);
    if (response.ok) {
      if (response.deleted) {
        // A new row was deleted, reload to update UI
        console.log('TC new row was deleted, reloading...');
        safeReload();
        return;
      }
      
      setTcRowEditable(idx, false, response.original);
      
      // Check if there are any other active edits
      setTimeout(() => {
        if (!hasActiveEdits()) {
          markClean();
        }
      }, 100);
    } else {
      console.error('tcCancel failed:', response);
      alert('Failed to cancel: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('tcCancel error:', e);
    alert('Error canceling: ' + e.message);
  }
}

async function tcApprove(key, idx){
  await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/${idx}/approve`)
  safeReload();
}

async function tcPostComment(key, idx){
  const el = document.getElementById(`tc-comment-${idx}`)
  const text = (el && el.value || '').trim()
  if(!text) return
  const r = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/${idx}/comment`, { text })
  if(r.ok){
    const thread = document.getElementById(`tc-thread-${idx}`)
    const ts = new Date().toLocaleString()
    const div = document.createElement('div')
    div.className = 'comment-item'
    div.innerHTML = `<b>vendor@example.com</b> <span class="muted small">• ${ts}</span><div>${text}</div>`
    thread.prepend(div)
    el.value = ''
  }
}


// ===== TV (Transfer Variables) Functions =====

// Helper function to get the TV data row
function getTvRow(idx) {
  // Find all TV table rows and get the one at idx (skipping header rows)
  const table = document.querySelector('.tv-table tbody');
  if (!table) return null;
  // Each record has 2 rows: data row + comment row
  const rows = table.querySelectorAll('tr:not(.tv-comment-row)');
  return rows[idx] || null;
}

// Helper to toggle row edit state via DOM
function setTvRowEditable(idx, editable, originalValues = null) {
  const row = getTvRow(idx);
  if (!row) return;
  
  // Update row classes
  row.classList.remove('row-readonly', 'row-editing', 'selected');
  row.classList.add(editable ? 'row-editing' : 'row-readonly');
  if (editable) row.classList.add('selected');
  
  // Find all editable inputs in this row
  const inputs = row.querySelectorAll('input');
  inputs.forEach(input => {
    if (editable) {
      input.removeAttribute('readonly');
    } else {
      input.setAttribute('readonly', 'readonly');
    }
    
    // If canceling and we have original values, restore them
    if (!editable && originalValues && input.dataset.field) {
      const fieldKey = input.dataset.field;
      if (originalValues[fieldKey] !== undefined) {
        if (input.type === 'checkbox') {
          input.checked = originalValues[fieldKey];
        } else {
          input.value = originalValues[fieldKey];
        }
      }
    }
  });
  
  // Update checkboxes
  const checkboxes = row.querySelectorAll('input[type="checkbox"]');
  checkboxes.forEach(cb => {
    cb.disabled = !editable;
  });
  
  // Update comment textarea
  const commentTextarea = document.getElementById(`tv-comment-${idx}`);
  if (commentTextarea) {
    if (editable) {
      commentTextarea.removeAttribute('readonly');
      commentTextarea.placeholder = 'Add vendor comment…';
    } else {
      commentTextarea.setAttribute('readonly', 'readonly');
      commentTextarea.placeholder = "Click 'Edit' on the row above to add a comment";
    }
  }
  
  // Hide the comment hint if editing
  const commentRow = document.getElementById(`tv-comment-row-${idx}`);
  if (commentRow) {
    const hint = commentRow.querySelector('.comment-hint');
    if (hint) {
      hint.style.display = editable ? 'none' : '';
    }
  }
  
  // Update action buttons - find the actions cell
  const actionsCell = row.querySelector('.tv-actions');
  if (actionsCell) {
    // Get the current key from any existing onclick handler
    const existingBtn = actionsCell.querySelector('button');
    const onclickStr = existingBtn?.getAttribute('onclick') || '';
    const keyMatch = onclickStr.match(/'([^']+)'/);
    const key = keyMatch ? keyMatch[1] : '';
    
    if (editable) {
      // Show Save/Cancel buttons
      actionsCell.innerHTML = `
        <button class="btn btn-icon sm btn-action-save" title="Save changes" onclick="tvSave('${key}', ${idx})">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
        </button>
        <button class="btn btn-icon sm btn-action-cancel" title="Cancel" onclick="tvCancel('${key}', ${idx})">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
        <button class="btn btn-icon sm btn-action-comment" title="Add comment" onclick="toggleTvRowComment(${idx})">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
          </svg>
        </button>
      `;
    } else {
      // Show Edit/Comment buttons (consistent with TC)
      actionsCell.innerHTML = `
        <button class="btn btn-icon sm btn-action-edit" title="Edit row" onclick="tvEdit('${key}', ${idx})">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 20h9" />
            <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z" />
          </svg>
        </button>
        <button class="btn btn-icon sm btn-action-comment" title="Add comment" onclick="toggleTvRowComment(${idx})">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
          </svg>
        </button>
      `;
    }
  }
}

async function tvEdit(key, idx){
  console.log('tvEdit called:', key, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/edit`);
    console.log('tvEdit response:', response);
    if (response.ok) {
      setTvRowEditable(idx, true);
      markDirty();
    } else {
      console.error('tvEdit failed:', response);
      alert('Failed to edit row: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('tvEdit error:', e);
    alert('Error editing row: ' + e.message);
  }
}

async function tvSave(key, idx){
  console.log('tvSave called:', key, idx);
  try {
    // Note: Field values are already synced to server via updateCell() on blur
    // This just toggles the edit state
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/save`);
    console.log('tvSave response:', response);
    if (response.ok) {
      setTvRowEditable(idx, false);
      showToast('Row saved', 'success');
    } else {
      console.error('tvSave failed:', response);
      alert('Failed to save row: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('tvSave error:', e);
    alert('Error saving row: ' + e.message);
  }
}

async function tvCancel(key, idx){
  console.log('tvCancel called:', key, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/cancel`);
    console.log('tvCancel response:', response);
    if (response.ok) {
      // Check if the row was deleted (new row cancel)
      if (response.deleted) {
        console.log('New row was deleted, reloading page');
        safeReload();
        return;
      }
      
      // For existing rows, restore original values
      setTvRowEditable(idx, false, response.original);
      
      // Check if there are any other active edits
      setTimeout(() => {
        if (!hasActiveEdits()) {
          markClean();
        }
      }, 100);
    } else {
      console.error('tvCancel failed:', response);
      alert('Failed to cancel: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('tvCancel error:', e);
    alert('Error canceling: ' + e.message);
  }
}

async function tvDelete(key, idx){
  console.log('tvDelete called:', key, idx);
  if (!confirm('Are you sure you want to delete this variable?')) {
    return;
  }
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/delete`);
    console.log('tvDelete response:', response);
    if (response.ok) {
      location.reload();
    } else {
      console.error('tvDelete failed:', response);
      alert('Failed to delete: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('tvDelete error:', e);
    alert('Error deleting: ' + e.message);
  }
}

async function tvApprove(key, idx){
  console.log('tvApprove called:', key, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/approve`);
    console.log('tvApprove response:', response);
    if (response.ok) {
      location.reload();
    } else {
      console.error('tvApprove failed:', response);
      alert('Failed to approve row: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('tvApprove error:', e);
    alert('Error approving row: ' + e.message);
  }
}

function toggleTvRowComment(idx){
  const row = document.getElementById(`tv-comment-row-${idx}`)
  if(!row) return
  if(row.style.display === 'none'){
    row.style.display = ''
  } else {
    row.style.display = 'none'
  }
}

// Update comment in-memory when textarea changes (follows row edit state)
async function updateTvComment(key, idx, value) {
  // Only update if the row is in edit mode (textarea is not readonly)
  const textarea = document.getElementById(`tv-comment-${idx}`);
  if (!textarea || textarea.readOnly) return;
  
  const text = (value || '').trim();
  
  // Update in-memory state via API
  const r = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/comment`, { text });
  
  if (r.ok) {
    markDirty();
  }
}

// ===== Add Row Functions =====

async function addTcRow(key){
  console.log('addTcRow called:', key);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tc/add`);
    console.log('addTcRow response:', response);
    if (response.ok) {
      // Reload with focus parameter to scroll to and focus the new row
      // Also set needs_save to enable the save button
      isIntentionalNavigation = true;
      const url = new URL(window.location.href);
      url.searchParams.set('focus_new', 'tc');
      url.searchParams.set('needs_save', 'true');
      window.location.href = url.toString();
    } else {
      console.error('addTcRow failed:', response);
      alert('Failed to add row: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('addTcRow error:', e);
    alert('Error adding row: ' + e.message);
  }
}

async function addTvRow(key){
  console.log('addTvRow called:', key);
  try {
    // Get the currently selected domain from the filter dropdown
    const domainSelect = document.getElementById('tv-domain-filter');
    const selectedDomain = domainSelect ? domainSelect.value : '';
    console.log('Selected domain for new variable:', selectedDomain);
    
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/tv/add`, {
      domain_info: selectedDomain
    });
    console.log('addTvRow response:', response);
    if (response.ok) {
      // Reload with focus parameter to scroll to and focus the new row
      // Also set needs_save to enable the save button
      isIntentionalNavigation = true;
      const url = new URL(window.location.href);
      url.searchParams.set('focus_new', 'tv');
      url.searchParams.set('needs_save', 'true');
      window.location.href = url.toString();
    } else {
      console.error('addTvRow failed:', response);
      alert('Failed to add variable: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('addTvRow error:', e);
    alert('Error adding variable: ' + e.message);
  }
}


// ===== Code Lists (CL) Functions =====

function toggleClRowComment(ref, idx) {
  const commentRow = document.getElementById(`cl-comment-row-${ref}-${idx}`);
  if (commentRow) {
    commentRow.style.display = commentRow.style.display === 'none' ? 'block' : 'none';
  }
}

async function clEdit(key, ref, idx) {
  console.log('clEdit:', key, ref, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/cl/${encodeURIComponent(ref)}/${idx}/edit`, {});
    console.log('clEdit response:', response);
    if (response.ok) {
      location.reload();
    } else {
      alert('Failed to edit: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('clEdit error:', e);
    alert('Error editing: ' + e.message);
  }
}

async function clSave(key, ref, idx) {
  const codeInput = document.getElementById(`cl-code-${ref}-${idx}`);
  const textInput = document.getElementById(`cl-text-${ref}-${idx}`);
  
  if (!codeInput || !textInput) {
    alert('Could not find input fields');
    return;
  }
  
  const code = codeInput.value;
  const text = textInput.value;
  
  console.log('clSave:', key, ref, idx, code, text);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/cl/${encodeURIComponent(ref)}/${idx}/save`, {
      code: code,
      text: text
    });
    console.log('clSave response:', response);
    if (response.ok) {
      location.reload();
    } else {
      alert('Failed to save: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('clSave error:', e);
    alert('Error saving: ' + e.message);
  }
}

async function clCancel(key, ref, idx) {
  console.log('clCancel:', key, ref, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/cl/${encodeURIComponent(ref)}/${idx}/cancel`, {});
    console.log('clCancel response:', response);
    if (response.ok) {
      location.reload();
    } else {
      alert('Failed to cancel: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('clCancel error:', e);
    alert('Error canceling: ' + e.message);
  }
}

async function clApprove(key, ref, idx) {
  console.log('clApprove:', key, ref, idx);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/cl/${encodeURIComponent(ref)}/${idx}/approve`, {});
    console.log('clApprove response:', response);
    if (response.ok) {
      location.reload();
    } else {
      alert('Failed to approve: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('clApprove error:', e);
    alert('Error approving: ' + e.message);
  }
}

async function clPostComment(key, ref, idx) {
  const input = document.getElementById(`cl-comment-${ref}-${idx}`);
  if (!input) return;
  
  const text = input.value.trim();
  if (!text) {
    alert('Please enter a comment');
    return;
  }
  
  console.log('clPostComment:', key, ref, idx, text);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/cl/${encodeURIComponent(ref)}/${idx}/comment`, {
      text: text
    });
    console.log('clPostComment response:', response);
    if (response.ok) {
      location.reload();
    } else {
      alert('Failed to post comment: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('clPostComment error:', e);
    alert('Error posting comment: ' + e.message);
  }
}

async function addClCode(key, ref) {
  console.log('addClCode:', key, ref);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/cl/${encodeURIComponent(ref)}/add`, {});
    console.log('addClCode response:', response);
    if (response.ok) {
      location.reload();
    } else {
      alert('Failed to add code: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('addClCode error:', e);
    alert('Error adding code: ' + e.message);
  }
}


// ===== Transfer File Keys Functions =====

function toggleKeySelector(key) {
  const selector = document.getElementById('key-selector');
  if (selector) {
    selector.style.display = selector.style.display === 'none' ? 'block' : 'none';
  }
}

async function addKeyVariable(key) {
  const select = document.getElementById('key-variable-select');
  const variable = select.value;
  
  if (!variable) {
    alert('Please select a variable');
    return;
  }
  
  console.log('addKeyVariable called:', key, variable);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/transfer-keys/add`, { variable });
    console.log('addKeyVariable response:', response);
    if (response.ok) {
      location.reload();
    } else {
      console.error('addKeyVariable failed:', response);
      alert('Failed to add key variable: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('addKeyVariable error:', e);
    alert('Error adding key variable: ' + e.message);
  }
}

async function removeKeyVariable(key, variable) {
  console.log('removeKeyVariable called:', key, variable);
  try {
    const response = await window.API.post(`/api/workspace/${encodeURIComponent(key)}/transfer-keys/remove`, { variable });
    console.log('removeKeyVariable response:', response);
    if (response.ok) {
      location.reload();
    } else {
      console.error('removeKeyVariable failed:', response);
      alert('Failed to remove key variable: ' + (response.msg || 'Unknown error'));
    }
  } catch(e) {
    console.error('removeKeyVariable error:', e);
    alert('Error removing key variable: ' + e.message);
  }
}


// ===== DTA TC Inline Icon Logic (final version) =====

// Data rows are 0,2,4,... ; comment rows are 1,3,5,...
function getTcDataRow(idx){
  const rows = document.querySelectorAll('.tc-table tbody tr');
  return rows[idx * 2] || null;
}

// SVG Icons
function svgPencil(){ return `
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
     viewBox="0 0 24 24" fill="none" stroke="currentColor"
     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M12 20h9"/>
  <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z"/>
</svg>`; }
function svgSave(){ return `
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
     viewBox="0 0 24 24" fill="none" stroke="currentColor"
     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M7 3h10l4 4v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/>
  <path d="M12 17v-4"/>
</svg>`; }
function svgComment(){ return `
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
     viewBox="0 0 24 24" fill="none" stroke="currentColor"
     stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/>
</svg>`; }

// Replace text “Comment” link with icon
function iconizeCommentLinks(scope=document){
  scope.querySelectorAll('.tc-actions .link-comment').forEach(a => {
    const onclick = a.getAttribute('onclick');
    const btn = document.createElement('button');
    btn.className = 'btn btn-icon sm btn-comment-icon';
    btn.title = 'Comment';
    btn.innerHTML = svgComment();
    if (onclick) btn.setAttribute('onclick', onclick);
    a.replaceWith(btn);
  });
}

// Core toggle logic for editable rows
function setRowEditable(idx, editable, key){
  const row = getTcDataRow(idx);
  if(!row) return;

  // Toggle readonly on inputs
  row.querySelectorAll('input').forEach(inp =>
    editable ? inp.removeAttribute('readonly') : inp.setAttribute('readonly','readonly')
  );

  // Visual state
  row.classList.toggle('row-editing', editable);
  row.classList.toggle('selected', editable);
  row.classList.toggle('row-readonly', !editable);

  // Action cell
  const cell = row.querySelector('.tc-actions');
  if (!cell) return;
  const editBtn    = cell.querySelector('button[title="Edit row"], button[title="Save edits"]');
  const approveBtn = cell.querySelector('button[title="Review Complete"]');

  if (editable) {
    // Switch Edit → Save icon
    if (editBtn){
      editBtn.title = 'Save edits';
      editBtn.innerHTML = svgSave();
      editBtn.classList.add('primary');
      editBtn.onclick = () => window.tcSave(key, idx);
    }
    if (approveBtn){
      approveBtn.disabled = true;
      approveBtn.style.opacity = 0.5;
    }
  } else {
    // Switch Save → Edit icon
    if (editBtn){
      editBtn.title = 'Edit row';
      editBtn.innerHTML = svgPencil();
      editBtn.classList.remove('primary');
      editBtn.onclick = () => window.tcEdit(key, idx);
    }
    if (approveBtn){
      approveBtn.disabled = false;
      approveBtn.style.opacity = 1;
    }
  }
}

// NOTE: Old window.tcEdit, window.tcSave, window.tcApprove overrides removed.
// Now using the main async functions (tcEdit, tcSave, tcCancel, tcApprove) defined above.

// Initialize icons for existing comment links on load
document.addEventListener('DOMContentLoaded', () => iconizeCommentLinks());

// === TV functions ===
async function tvSelect(key, idx){
  const res = await API.post(`/api/workspace/${encodeURIComponent(key)}/tv/select/${idx}`);
  if(res && res.ok){
    window.location.href = `${window.location.pathname}?tab=TV`;
  }
}
async function tvSaveSelected(key){
  const payload = {
    FILE_ORDER: Number(document.querySelector('#tv-file-order')?.value || 0),
    FORMAT: document.querySelector('#tv-format')?.value || '',
    LENGTH: Number(document.querySelector('#tv-length')?.value || 0),
    REQUIRED: document.querySelector('#tv-required')?.checked || false,
    TEST_CONCEPTS: document.querySelector('#tv-test-concepts')?.value || '',
    EXAMPLE_VALUES: document.querySelector('#tv-example-values')?.value || ''
  };
  const list = document.querySelector('.tv-labels-list');
  const selected = document.querySelector('.tv-label-item.active');
  if(!list || !selected){ return; }
  const idx = Array.from(list.children).indexOf(selected);
  await API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/update`, payload);
}
async function tvApproveSelected(key){
  const list = document.querySelector('.tv-labels-list');
  const selected = document.querySelector('.tv-label-item.active');
  if(!list || !selected){ return; }
  const idx = Array.from(list.children).indexOf(selected);
  const res = await API.post(`/api/workspace/${encodeURIComponent(key)}/tv/${idx}/approve`);
  if(res && res.ok){ selected.classList.add('approved'); }
}
async function tvAdd(key){
  // Get the currently selected domain from the filter dropdown
  const domainSelect = document.getElementById('tv-domain-filter');
  const selectedDomain = domainSelect ? domainSelect.value : '';
  
  const res = await API.post(`/api/workspace/${encodeURIComponent(key)}/tv/add`, {
    domain_info: selectedDomain
  });
  if(res && res.ok){
    // Reload with focus parameter to scroll to and focus the new row
    // Also set needs_save to enable the save button
    isIntentionalNavigation = true;
    const url = new URL(window.location.href);
    url.searchParams.set('tab', 'TV');
    url.searchParams.set('focus_new', 'tv');
    url.searchParams.set('needs_save', 'true');
    window.location.href = url.toString();
  }
}

// === Metadata Functions ===
function metaEdit(key, idx) {
  fetch(`/api/workspace/${key}/meta/${idx}/edit`, { method: 'POST' })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error editing metadata: ' + e));
}

function metaSave(key, idx) {
  // Find the input in that row
  const inputs = document.querySelectorAll(`[id^="meta-"][id$="-${idx}"]`);
  let value = '';
  inputs.forEach(input => {
    if (input.value !== undefined) {
      value = input.value;
    }
  });
  
  fetch(`/api/workspace/${key}/meta/${idx}/save`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ value })
  })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error saving metadata: ' + e));
}

function metaCancel(key, idx) {
  fetch(`/api/workspace/${key}/meta/${idx}/cancel`, { method: 'POST' })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error canceling: ' + e));
}

function metaApprove(key, idx) {
  fetch(`/api/workspace/${key}/meta/${idx}/approve`, { method: 'POST' })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error approving metadata: ' + e));
}

function toggleMetaComment(idx) {
  const row = document.getElementById(`meta-comment-${idx}`);
  row.style.display = row.style.display === 'none' ? 'block' : 'none';
}

function metaPostComment(key, idx) {
  const input = document.getElementById(`meta-comment-input-${idx}`);
  const text = input.value.trim();
  if (!text) return;
  
  fetch(`/api/workspace/${key}/meta/${idx}/comment`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ text })
  })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error posting comment: ' + e));
}

// === DIP (Data Ingestion Parameters) Functions ===
function dipEdit(key, idx) {
  fetch(`/api/workspace/${key}/dip/${idx}/edit`, { method: 'POST' })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error editing DIP: ' + e));
}

function dipSave(key, idx) {
  const inputs = document.querySelectorAll(`[id^="dip-"][id$="-${idx}"]`);
  let value = '';
  inputs.forEach(input => {
    if (input.value !== undefined) {
      value = input.value;
    }
  });
  
  fetch(`/api/workspace/${key}/dip/${idx}/save`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ value })
  })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error saving DIP: ' + e));
}

function dipCancel(key, idx) {
  fetch(`/api/workspace/${key}/dip/${idx}/cancel`, { method: 'POST' })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error canceling: ' + e));
}

function dipApprove(key, idx) {
  fetch(`/api/workspace/${key}/dip/${idx}/approve`, { method: 'POST' })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error approving DIP: ' + e));
}

function toggleDipComment(idx) {
  const row = document.getElementById(`dip-comment-${idx}`);
  row.style.display = row.style.display === 'none' ? 'block' : 'none';
}

function dipPostComment(key, idx) {
  const input = document.getElementById(`dip-comment-input-${idx}`);
  const text = input.value.trim();
  if (!text) return;
  
  fetch(`/api/workspace/${key}/dip/${idx}/comment`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ text })
  })
    .then(r => r.json())
    .then(() => location.reload())
    .catch(e => alert('Error posting comment: ' + e));
}

// Export and Publish functions for Approved DTAs
async function exportDta(key) {
  try {
    const response = await fetch(`/api/workspace/${encodeURIComponent(key)}/export`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'}
    });
    
    const result = await response.json();
    
    if (result.success) {
      // Redirect to Jobs Status page with the job_id highlighted
      window.location.href = `/ingestion?highlight=${result.job_id}`;
    } else {
      alert(result.msg || 'Failed to trigger export job');
    }
  } catch (e) {
    console.error('Export error:', e);
    alert('Failed to trigger export job');
  }
}

async function publishMajorVersion(key) {
  const confirmed = confirm(
    'Are you sure you want to publish this DTA as a new major version?\n\n' +
    'This will:\n' +
    '• Increment the major version number\n' +
    '• Make this version available for use\n' +
    '• Archive the current draft'
  );
  
  if (!confirmed) return;
  
  try {
    const response = await fetch(`/api/workspace/${encodeURIComponent(key)}/publish-major`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'}
    });
    
    const result = await response.json();
    
    if (result.success) {
      alert(`Success! DTA published as Major v${result.new_major_version}`);
      window.location.href = '/dashboard';
    } else {
      alert(result.msg || 'Failed to publish major version');
    }
  } catch (e) {
    console.error('Publish error:', e);
    alert('Failed to publish major version');
  }
}

// ==========================================
// Domain Info Filter for Transfer Variables
// ==========================================

// Store the currently selected domain for save operations
let currentSelectedDomain = null;

/**
 * Filter transfer variables by domain info
 * Shows only rows matching the selected domain
 */
function filterTvByDomain(domain) {
  console.log('Filtering TV by domain:', domain);
  currentSelectedDomain = domain;
  
  const tbody = document.querySelector('.tv-table tbody');
  if (!tbody) {
    console.warn('TV table tbody not found');
    return;
  }
  
  const rows = tbody.querySelectorAll('tr[data-domain]');
  let visibleCount = 0;
  
  rows.forEach(row => {
    const rowDomain = row.getAttribute('data-domain') || '';
    if (!domain || domain === '' || rowDomain === domain) {
      row.style.display = '';
      visibleCount++;
    } else {
      row.style.display = 'none';
    }
  });
  
  // Update visible count
  const countSpan = document.getElementById('tv-visible-count');
  if (countSpan) {
    countSpan.textContent = visibleCount;
  }
  
  console.log(`Showing ${visibleCount} rows for domain: ${domain}`);
}

/**
 * Get the currently selected domain for filtering
 */
function getSelectedDomain() {
  const dropdown = document.getElementById('tv-domain-filter');
  return dropdown ? dropdown.value : currentSelectedDomain;
}

// Initialize domain filter on page load
document.addEventListener('DOMContentLoaded', function() {
  const domainDropdown = document.getElementById('tv-domain-filter');
  if (domainDropdown && domainDropdown.value) {
    // Apply initial filter based on first selected domain
    filterTvByDomain(domainDropdown.value);
  }
});

// ==========================================
// Operational Agreements (OA) Functions
// ==========================================

/**
 * Toggle OA accordion section
 */
function toggleOaAccordion(contentId) {
  const content = document.getElementById(contentId);
  const chevron = document.getElementById('chevron-' + contentId);
  
  if (content.style.display === 'none') {
    content.style.display = 'block';
    if (chevron) chevron.style.transform = 'rotate(0deg)';
  } else {
    content.style.display = 'none';
    if (chevron) chevron.style.transform = 'rotate(-90deg)';
  }
}

/**
 * Mark OA changes - enables save button
 */
function markOaChanged() {
  if (typeof markDirty === 'function') {
    markDirty();
  }
}

// --- OA Parent Functions (Operational Agreement table) ---
function oaParentEdit(key, idx) {
  fetch(`/api/workspace/${encodeURIComponent(key)}/oa/parent/edit`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ idx: idx })
  }).then(() => location.reload());
}

function oaParentSave(key, idx) {
  const input = document.querySelector(`[id^="oa-parent-"][id$="-${idx}"]`);
  const value = input ? input.value : '';
  
  fetch(`/api/workspace/${encodeURIComponent(key)}/oa/parent/save`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ idx: idx, value: value })
  }).then(() => location.reload());
}

function oaParentCancel(key, idx) {
  fetch(`/api/workspace/${encodeURIComponent(key)}/oa/parent/cancel`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ idx: idx })
  }).then(() => location.reload());
}

// --- OA Attributes Functions ---
function oaAttrEdit(key, idx) {
  fetch(`/api/workspace/${encodeURIComponent(key)}/oa/attr/edit`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ idx: idx })
  }).then(() => location.reload());
}

function oaAttrSave(key, idx) {
  const input = document.querySelector(`[id^="oa-attr-"][id$="-${idx}"]`);
  const value = input ? input.value : '';
  
  fetch(`/api/workspace/${encodeURIComponent(key)}/oa/attr/save`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ idx: idx, value: value })
  }).then(() => location.reload());
}

function oaAttrCancel(key, idx) {
  fetch(`/api/workspace/${encodeURIComponent(key)}/oa/attr/cancel`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ idx: idx })
  }).then(() => location.reload());
}

// --- OA Options Functions ---
function oaOptEdit(key, idx) {
  fetch(`/api/workspace/${encodeURIComponent(key)}/oa/options/edit`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ idx: idx })
  }).then(() => location.reload());
}

function oaOptSave(key, idx) {
  const selectEl = document.getElementById(`oa-opt-select-${idx}`);
  const commentEl = document.getElementById(`oa-opt-comment-${idx}`);
  
  const selectedOption = selectEl ? selectEl.value : '';
  const vendorComments = commentEl ? commentEl.value : '';
  
  fetch(`/api/workspace/${encodeURIComponent(key)}/oa/options/save`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ 
      idx: idx, 
      selected_option: selectedOption,
      vendor_comments: vendorComments
    })
  }).then(() => location.reload());
}

function oaOptCancel(key, idx) {
  fetch(`/api/workspace/${encodeURIComponent(key)}/oa/options/cancel`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ idx: idx })
  }).then(() => location.reload());
}

// --- OA Other Functions ---
function oaOtherEdit(key, idx) {
  fetch(`/api/workspace/${encodeURIComponent(key)}/oa/other/edit`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ idx: idx })
  }).then(() => location.reload());
}

function oaOtherSave(key, idx) {
  const valueEl = document.getElementById(`oa-other-val-${idx}`);
  const commentEl = document.getElementById(`oa-other-comment-${idx}`);
  
  const itemValue = valueEl ? valueEl.value : '';
  const vendorComments = commentEl ? commentEl.value : '';
  
  fetch(`/api/workspace/${encodeURIComponent(key)}/oa/other/save`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ 
      idx: idx, 
      item_value: itemValue,
      vendor_comments: vendorComments
    })
  }).then(() => location.reload());
}

function oaOtherCancel(key, idx) {
  fetch(`/api/workspace/${encodeURIComponent(key)}/oa/other/cancel`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ idx: idx })
  }).then(() => location.reload());
}
